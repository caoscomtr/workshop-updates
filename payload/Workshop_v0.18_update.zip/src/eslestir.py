# -*- coding: utf-8 -*-
"""
eslestir.py — "Add a Mod": bir PNG yigininin HANGI kiyafetin HANGI slotu
oldugunu ICERIKTEN bulur (dosya adlari bozuk olabilir).

API:
    from eslestir import eslestir
    sonuc = eslestir(png_yollari)           # ya da eslestir(klasor_yolu)
    # -> [Eslesme(png, mat_id, slot, guven, durum, aday_listesi), ...]

Karar kurali (esikler dogruluk olcumuyle secildi — dogruluk_raporu.md):
  * skor >= ESIK_OTOMATIK ve ikinci icerik-grubuyla fark >= ESIK_FARK
    ve tek icerik-grubu onde  -> durum "otomatik" (mat_id+slot dolu)
  * skor >= ESIK_ADAY        -> durum "aday" (kullaniciya skorlu liste;
                                 OTOMATIK UYGULANMAZ)
  * degilse                  -> durum "eslesme_yok" (alakasiz goruntu;
                                 yanlis kiyafete yazmak en kotu sonuctur)

ICERIK-ES GRUBU: oyun ayni piksel icerigini farkli doku_id'lerle defalarca
kullanir (orn. Belt/Trinket normalleri 8 kiyafette birebir ayni — bc_sha ile
kanitli). Boyle grup tek "icerik" sayilir: grup icindeki TUM slotlar ayni
guvenle adaydir; otomatik secimde grubun ILK duzenlenebilir slotu doner ve
grup uyeleri aday_listesi'nde tasinir (GUI kullaniciya hangi kiyafet oldugunu
sectirebilir — yanlis secim zararsizdir, icerik zaten birebir aynidir).

Salt okuma: forge'a dokunmaz; yalnizca parmak_izi_indeksi.pkl + PNG okur.
"""
import os, sys, glob, pickle
from collections import namedtuple

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)
import parmak_izi as PI

PKL_VARSAYILAN = os.path.join(BURA, "parmak_izi_indeksi.pkl")

# --- karar esikleri (test kumeleriyle OLCULDU; dogruluk_raporu.md) -----------
ESIK_OTOMATIK = 0.85     # bu skorun ustunde tek grup onde ise otomatik
                         #   (duz-doku yolu 0.84'te TAVANLI -> duz girdi asla
                         #    otomatik olamaz; en yuksek duz-olmayan negatif
                         #    skor 0.691 olculdu -> 0.16 guvenlik payi)
ESIK_FARK     = 0.03     # birinci ile ikinci icerik-grubu skor farki alt siniri
ESIK_ADAY     = 0.70     # bunun altinda hic aday gosterilmez (eslesme_yok)
ADAY_EN_COK   = 5        # kullaniciya gosterilecek en fazla aday grubu

Eslesme = namedtuple("Eslesme", "png mat_id slot guven durum aday_listesi")
# aday_listesi: [ {"skor", "bc_sha", "slotlar":[{kiyafet, gorunen_ad, mat_id,
#                  parca_adi, slot_idx, rol, duzenlenebilir, doku_id}, ...]} ]

_INDEKS = None


def _indeks_yukle(pkl=PKL_VARSAYILAN):
    global _INDEKS
    if _INDEKS is None or _INDEKS.get("_pkl") != pkl:
        with open(pkl, "rb") as f:
            paket = pickle.load(f)
        # icerik-es gruplari: bc_sha -> [doku_id, ...]
        gruplar = {}
        for did, fp in paket["dokular"].items():
            gruplar.setdefault(fp.get("bc_sha") or did, []).append(did)
        paket["_gruplar"] = gruplar
        paket["_pkl"] = pkl
        _INDEKS = paket
    return _INDEKS


def _grup_slotlari(paket, uye_ids):
    out = []
    for did in uye_ids:
        for yer in paket["dokular"][did]["slotlar"]:
            k = dict(yer); k["doku_id"] = did
            out.append(k)
    # duzenlenebilir olanlar one
    out.sort(key=lambda y: (not y["duzenlenebilir"], y["kiyafet"], y["slot_idx"]))
    return out


def png_eslestir(png_yolu, pkl=PKL_VARSAYILAN):
    """tek PNG -> Eslesme."""
    paket = _indeks_yukle(pkl)
    try:
        fp = PI.png_parmak_izi(png_yolu)
    except Exception:
        return Eslesme(png_yolu, None, None, 0.0, "okunamadi", [])

    # 1) her doku ile skor (oran filtresi ile)
    doku_skor = {}
    for did, ifp in paket["dokular"].items():
        if not PI.oran_uyumlu(fp["oran"], ifp["oran"]):
            continue
        s, _ = PI.skor(fp, ifp)
        doku_skor[did] = s

    # 2) icerik-es gruplarina indirge (grup skoru = uyelerin en yuksegi)
    grup_skor = []
    for sha, uyeler in paket["_gruplar"].items():
        ss = [doku_skor[d] for d in uyeler if d in doku_skor]
        if ss:
            grup_skor.append((max(ss), sha, uyeler))
    grup_skor.sort(reverse=True)
    if not grup_skor or grup_skor[0][0] < ESIK_ADAY:
        return Eslesme(png_yolu, None, None,
                       grup_skor[0][0] if grup_skor else 0.0, "eslesme_yok", [])

    adaylar = []
    for s, sha, uyeler in grup_skor[:ADAY_EN_COK]:
        if s < ESIK_ADAY:
            break
        adaylar.append({"skor": round(s, 4), "bc_sha": sha,
                        "slotlar": _grup_slotlari(paket, uyeler)})

    en_iyi = adaylar[0]
    ikinci = grup_skor[1][0] if len(grup_skor) > 1 else 0.0
    ilk_duz = next((y for y in en_iyi["slotlar"] if y["duzenlenebilir"]), None)

    if (en_iyi["skor"] >= ESIK_OTOMATIK and
            en_iyi["skor"] - ikinci >= ESIK_FARK and
            ilk_duz is not None):
        return Eslesme(png_yolu, ilk_duz["mat_id"], ilk_duz["slot_idx"],
                       en_iyi["skor"], "otomatik", adaylar)
    return Eslesme(png_yolu, None, None, en_iyi["skor"], "aday", adaylar)


def eslestir(png_yollari, pkl=PKL_VARSAYILAN):
    """PNG yollari listesi YA DA tek klasor yolu -> [Eslesme, ...]."""
    if isinstance(png_yollari, str):
        if os.path.isdir(png_yollari):
            png_yollari = sorted(
                glob.glob(os.path.join(png_yollari, "**", "*.png"), recursive=True))
        else:
            png_yollari = [png_yollari]
    return [png_eslestir(p, pkl) for p in png_yollari]


if __name__ == "__main__":
    hedef = sys.argv[1] if len(sys.argv) > 1 else "."
    for e in eslestir(hedef):
        print("%-10s guven=%.3f  %s" % (e.durum, e.guven, os.path.basename(e.png)))
        if e.durum == "otomatik":
            print("    -> %s s%d" % (e.mat_id, e.slot))
        for a in e.aday_listesi[:3]:
            y = a["slotlar"][0]
            print("    aday %.3f  %s/%s s%d (%s)  [grup uyesi %d slot]" %
                  (a["skor"], y["kiyafet"], y["parca_adi"], y["slot_idx"],
                   y["rol"], len(a["slotlar"])))
