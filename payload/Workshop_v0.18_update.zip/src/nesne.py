# -*- coding: utf-8 -*-
"""NESNE -- forge ic dosya govdesindeki NESNE AGACI okuyucu/yazici (cekirdek).

Anvil'in "nesneyi XML olarak ac, duzenle, geri yaz" yolunun ALT KATMANI. Bu modul
XML uretmez; govdeyi KAYITLARA ayirir, agac kurar ve BIREBIR geri yazar. Alan
duzeyi (hangi bayt hangi alan) bu modulun isi DEGILDIR -- o katman sema
gerektirir; burada her yuk ham bayt olarak TASINIR ("opak").

=============================================================================
 OLCULEN BICIM  (kanitlar: bu modulun testi testler/test_nesne.py + SONUC_nesne.json)
=============================================================================
Govde = [ONEK][KAYIT][KAYIT]...  ve KAYIT = [u64 nesne_kimligi][u32 sinifCrc][yuk]

ONEK  : ilk kayittan onceki baytlar = kok nesnenin kayitlardan ONCE gelen alanlari.
KIMLIK: DAMGA DEGIL, TURETILIR (bayt kaniti: bu modul kimligi hic saklamaz,
        her yazmada (uzay, sira, icid)'den YENIDEN uretir ve okurken orijinal
        8 baytla karsilastirir):
            yerel      : 0x00000000FBF80000 | i          (i = ic dosya icinde 0..N-1)
            turetilmis : (0x8000000000000000 | (icid << 20) | i) & 2**64-1
sinifCrc: crc32(IcSinifAdi) -- ust-duzey tipCrc ile AYNI kural.
SAYAC : YEREL sira govde sirasinda artan bir yazma sayacidir -- degismezleri
        saglayan govdelerin 6.145/6.145'inde (%100) olculdu, bu yuzden ekleme /
        silmeden sonra YENIDEN URETILEBILIR (yeniden_numarala).
        TURETILMIS sira BOYLE DEGILDIR: WeaponStats_Sword_TotalAttack'ta govde
        sirasi 0,14,1,15,2,3,16,4,... gider (ic ice gecmis IKI sayac). Bu yuzden
        turetilmis sira KORUNUR, yeniden uretilmez.
SIRA    : seri DERINLIK-ONCELIKLIdir. Bir nesnenin kendi alanlari cocuklarindan
        ONCE (yuk) ve SONRA (yuk_son) iki parca halinde yazilir:
            kayit = [kimlik][crc][yuk] + cocuklarin serisi + [yuk_son]
        Bu sirayi bozan bir yazici tur donusunu KIRAR (test 6 bunu olcer).

⛔ ARASTIRMA DUZELTMESI -- "yuklerde baska kaydin kimligine referans YOK (0/369.528)"
   OLCUMU YANLISTI. O olcum, gomulu referanslari da KAYIT sayan bir taramanin
   uzerine kuruluydu (referans kayda donusunce payloadda gorunmez olur).  Bu
   modulun taramasi 9.871 ic dosyada 13.530 adet 12 B'den KISA "kayit araligi" ve
   397 govdede TEKRARLAYAN yerel indeks olctu; hex dokumu gomulu referansi acikca
   gosterdi (or. 0x2096D3568CD: 9 B'lik `[u64 kimlik][u8 etiket]` dizisi = 3,4,5,6
   nesnelerine referans, ardindan ayni nesnelerin GERCEK tanimlari geliyor).
   Bu yuzden tarama NAIF DEGIL, DEGISMEZ-DOGRULAMALIdir (asagida).

DEGISMEZLER (bir govdenin kayit bolumlemesi ancak bunlari saglarsa "temiz"dir):
   D1  ardisik kayitlarin araligi >= 12 B (kayit basliginin kendisi)
   D2  yerel indeksler tam olarak {0..N-1}, her biri BIR kez
   D3  turetilmis indeksler tam olarak {0..M-1}, her biri BIR kez
Olcum (9.871 ic dosya): 2.942 kayitsiz · 6.230 temiz · 699 degismezleri saglamiyor
(bunlarin 140'i sinif suzgeciyle kurtariliyor).  Kurtarilamayan govde "supheli"
isaretlenir -- KAYITLARI YINE URETILIR ve tur donusu YINE BIREBIRDIR, ama agaci
"bu bolumleme kesin" diye SATMAYIZ.

⛔ OYUN ARSIVINE TEK BAYT YAZMAZ. Forge yalnizca SALT-OKUNUR acilir; `yaz()`
bellekteki baytlari dondurur, dosyaya dokunmaz. Kurulum yolu (kur_mesh / yedek /
jurnal / "oyun acik" kapisi) bu modulun isi degildir.

Kullanici metinleri INGILIZCE; kod yorumlari TURKCE (ASCII).
"""
import json
import os
import struct
import zlib

BURA = os.path.dirname(os.path.abspath(__file__))
KOK = os.path.dirname(BURA)

__all__ = ["oku", "oku_govde", "yaz", "dogrula", "gez", "dugum_kur",
           "yeniden_numarala", "sinif_kumesi_ogren", "sinif_ad", "crc_ad",
           "sinif_ad_kaynak", "oyun_sinif_adlari",
           "kimlik", "veri_yolu", "YEREL_TABAN", "BASLIK_BOY"]

YEREL_TABAN = 0x00000000FBF80000
BASLIK_BOY = 12                      # [u64 kimlik][u32 sinifCrc]
_U64 = 0xFFFFFFFFFFFFFFFF


# =====================================================================================
#  KIMLIK -- turetilir, ezberlenmez
# =====================================================================================
def kimlik(kimlik_turu, sira, icid=None):
    """(uzay, sira, icid) -> u64 nesne kimligi. Uzay bilinmiyorsa ValueError."""
    i = int(sira)
    if i < 0:
        raise ValueError("object ordinal cannot be negative")
    if kimlik_turu == "yerel":
        if i > 0xFFFF:
            raise ValueError("local ordinal %d does not fit the 16-bit field" % i)
        return YEREL_TABAN | i
    if kimlik_turu == "turetilmis":
        if icid is None:
            raise ValueError("derived identity needs the inner-file id")
        if i > 0xFFFF:
            raise ValueError("derived ordinal %d does not fit the 16-bit field" % i)
        return (0x8000000000000000 | (int(icid) << 20) | i) & _U64
    raise ValueError("unknown identity space %r" % (kimlik_turu,))


def _onek(kimlik_turu, icid=None):
    """Kimligin ust 6 bayti -- kayit basi arayan desen (eski 'damga')."""
    return struct.pack("<Q", kimlik(kimlik_turu, 0, icid))[2:8]


def _cozumle(idd, icid):
    """u64 -> (uzay, sira) ya da (None, None). SIKI: geri turetip bayt karsilastirir."""
    if idd >> 63:
        i = idd & 0xFFFF
        if kimlik("turetilmis", i, icid) == idd:
            return "turetilmis", i
    else:
        i = idd - YEREL_TABAN
        if 0 <= i <= 0xFFFF and kimlik("yerel", i) == idd:
            return "yerel", i
    return None, None


# =====================================================================================
#  SINIF ADI (kozmetik -- crc32 TEK BASINA kanit degildir, bkz. sinif_adlari.json dersi)
# =====================================================================================
VERI_KLASOR = "nesne_veri"      # pakette: src/nesne_veri/ (build/kur.py kopyalar)


def veri_yolu(ad):
    """Sema / ad tablosu dosyasinin yolu (PAKET-GORELI cozum).

    Sira: 1) bu modulun YANINDAKI nesne_veri/<ad>  -- yayin paketi; build/kur.py
             tablolari oraya kopyalar (pakette build/ klasoru YOKTUR),
          2) ../build/<ad>                          -- gelistirme agaci; tablolarin
             KAYNAGI (uretici betikler build/ altina yazar, src/nesne_veri/ dev
             agacinda BILINCLI olarak yoktur ki kopya suruklenmesin).
    Ilk VAR OLAN yol doner; hicbiri yoksa build/ yolu doner ve cagiranin open()'i
    eskisi gibi duser -- tablolar ISTEGE BAGLIDIR, modul yine calisir.
    v0.15 dersi: tablolar build/'e sabitken pakette modul COKMUYOR ama tipli alan
    sayisi 0 kaliyordu -> ihracat okunmaz hex duvari (olculdu).
    """
    adaylar = (os.path.join(BURA, VERI_KLASOR, ad), os.path.join(KOK, "build", ad))
    for aday in adaylar:
        if os.path.isfile(aday):
            return aday
    return adaylar[-1]


_AD = None
_AD_KAYNAK = None
_OYUN = None


def oyun_sinif_adlari():
    """{crc:int -> ad} -- OYUNUN KENDI sinif sozlugu. Bos sozluk = tablo yok.

    KAYNAK: DataPC_boot_patch_01.forge icindeki GlobalMetaFile girisi (fid 0x10)
    her sinif adini KENDI crc32'siyle yan yana tasir; build/sinif_adlari_oyun.json
    o tablonun okunmus halidir (ureticisi build/sinif_adlari_oyun_uret.py).
    Ucuncu taraf sozluk, SchemaDict dokumu ya da baska bir modlama aracinin
    tablosu OKUNMAZ.

    KAPI: dosyadaki her ad BURADA da yeniden hesaplanir; crc32(ad) != anahtar
    olan hicbir ad tabloya girmez (dosya bozulsa bile yanlis ad gosterilmez).
    """
    global _OYUN
    if _OYUN is None:
        t = {}
        try:
            with open(veri_yolu("sinif_adlari_oyun.json"), encoding="utf-8") as f:
                ham = json.load(f)
            for k, v in (ham.get("siniflar") or {}).items():
                ad = v.get("ad") if isinstance(v, dict) else v
                if ad and crc_ad(ad) == int(k, 16):
                    t[int(k, 16)] = ad
        except Exception:
            pass                          # tablo YOKSA modul yine calisir
        _OYUN = t
    return _OYUN


def _ad_tablosu():
    """{crc -> ad}. SIRA YUKLUDUR: once OYUNUN KENDI tablosu, sonra bizimkiler.

    Olculdu (2026-09-09): eski build/sinif_adlari.json'daki 12 ad crc32
    CARPISMASIYDI (or. 0x1122101C icin "Cell 6307_MainGrid_DataBlock" yaziyordu,
    oyunun kendi tablosunda SoundVoiceNPCType). Oyunun tablosu once okundugu icin
    o 12 crc artik dogru adi gosterir.
    """
    global _AD, _AD_KAYNAK
    if _AD is None:
        t, kaynak = {}, {}
        for crc, ad in oyun_sinif_adlari().items():
            t[crc] = ad
            kaynak[crc] = "oyun"
        for dosya, kok_alan in (("sinif_adlari.json", "siniflar"),
                                ("alan_adlari.json", "ic_siniflar")):
            yol = veri_yolu(dosya)
            try:
                with open(yol, encoding="utf-8") as f:
                    ham = json.load(f)
                for k, v in (ham.get(kok_alan) or {}).items():
                    ad = v.get("ad") if isinstance(v, dict) else v
                    if ad and int(k, 16) not in t:
                        t[int(k, 16)] = ad
                        kaynak[int(k, 16)] = "tablo"
            except Exception:
                pass                      # ad tablosu YOKSA modul yine calisir
        _AD, _AD_KAYNAK = t, kaynak
    return _AD


def sinif_ad(crc):
    """Sinif crc'si -> bilinen ad ya da None. Yalniz gorunum icindir."""
    return _ad_tablosu().get(int(crc) & 0xFFFFFFFF)


def sinif_ad_kaynak(crc):
    """Adin NEREDEN geldigi: "oyun" | "tablo" | None (ad yok)."""
    _ad_tablosu()
    return (_AD_KAYNAK or {}).get(int(crc) & 0xFFFFFFFF)


def crc_ad(ad):
    """crc32(SinifAdi) -- ust-duzey tipCrc ile AYNI kural."""
    return zlib.crc32(ad.encode("ascii")) & 0xFFFFFFFF


# =====================================================================================
#  BOLUMLEME
# =====================================================================================
def _adaylar(gv, icid, kaydir=0):
    """[(off, uzay, sira, crc)] -- artan ofset. `kaydir` YALNIZ test sabotaji icindir."""
    n = len(gv)
    gor = set()
    out = []
    for uzay in ("turetilmis", "yerel"):
        try:
            desen = _onek(uzay, icid)
        except ValueError:
            continue
        q = gv.find(desen)
        while q >= 0:
            off = q - 2 + kaydir
            if off >= 0 and off + BASLIK_BOY <= n and off not in gor:
                idd = struct.unpack_from("<Q", gv, off)[0]
                u, i = _cozumle(idd, icid)
                if u is not None:
                    gor.add(off)
                    out.append((off, u, i, struct.unpack_from("<I", gv, off + 8)[0]))
                elif kaydir:
                    # SABOTAJ KAPISI: kaydirilmis ofsette kimlik TURETILEMEZ.
                    raise ValueError(
                        "record header at offset %d does not derive a valid object "
                        "identity - the record boundary is wrong" % off)
            q = gv.find(desen, q + 1)
    out.sort()
    return out


def _degismez(sec, boy):
    """D1/D2/D3. -> (ok, sebep)"""
    if not sec:
        return True, "kayitsiz"
    for j in range(len(sec) - 1):
        if sec[j + 1][0] - sec[j][0] < BASLIK_BOY:
            return False, "cakisma"
    if boy - sec[-1][0] < BASLIK_BOY:
        return False, "cakisma"
    for uzay in ("yerel", "turetilmis"):
        ix = [c[2] for c in sec if c[1] == uzay]
        if sorted(ix) != list(range(len(ix))):
            return False, "indeks_%s" % uzay
    return True, "temiz"


def _cakismasiz(sec, boy):
    """Araligi 12 B'den KISA olan adaylari atar (cakisan ciftte ONCEKI tutulur).

    ZORUNLU: bir kaydin kendi basligi 12 B'dir. Araligi daha kisa bir "kayit"
    yazildiginda 12 B baslik uretilir ve GOVDE UZAR -- tur donusu kirilir
    (olculdu: bu temizlik yokken 9.871 govdenin 264'u kirikti). Bu yuzden
    bolumleme SUPHELI kalsa bile cakisma temizligi HER ZAMAN uygulanir.
    """
    s = list(sec)
    while True:
        yeni, j, atildi = [], 0, False
        while j < len(s):
            son = s[j + 1][0] if j + 1 < len(s) else boy
            if son - s[j][0] < BASLIK_BOY:
                if j + 1 < len(s):
                    yeni.append(s[j])       # cifti at, ONCEKINI tut
                    j += 2
                else:
                    j += 1                  # govdenin sonuna sigmayan kuyruk adayi
                atildi = True
            else:
                yeni.append(s[j])
                j += 1
        s = yeni
        if not atildi:
            return s


def _suz(aday, boy, kume):
    """crc suzgeci + yinelemeli cakisma/tekrar temizligi. -> (secim, ok)"""
    s = [c for c in aday if c[3] in kume]
    for _ in range(12):
        ok, _n = _degismez(s, boy)
        if ok:
            return s, True
        onceki = len(s)
        s = _cakismasiz(s, boy)
        if len(s) == onceki:
            gor, yeni = set(), []
            for c in s:
                if (c[1], c[2]) in gor:
                    continue                # ayni indeksin IKINCI adayi = gomulu referans
                gor.add((c[1], c[2]))
                yeni.append(c)
            if len(yeni) == len(s):
                break
            s = yeni
    return s, _degismez(s, boy)[0]


def _bolumle(gv, icid, sinif_kumesi=None, kaydir=0):
    """Govde -> (secilen kayitlar, atilan adaylar, bicim).

    1) NAIF: butun adaylar kayit; degismezler tutuyorsa "temiz".
    2) KURTARMA: bir indeksin TEK adayi varsa o ZORUNLU tanimdir; onlarin sinif
       crc'leri (+ varsa disaridan ogrenilmis kume) suzgec olur.
    3) SUPHELI: naif bolumleme geri verilir (tur donusu YINE birebir), ama
       agacin dogrulugu iddia EDILMEZ.
    """
    aday = _adaylar(gv, icid, kaydir)
    if not aday:
        return [], [], "kayitsiz"
    ok, _sebep = _degismez(aday, len(gv))
    if ok:
        return aday, [], "temiz"
    say = {}
    for c in aday:
        say[(c[1], c[2])] = say.get((c[1], c[2]), 0) + 1
    kume = {c[3] for c in aday if say[(c[1], c[2])] == 1}
    if sinif_kumesi:
        kume |= set(sinif_kumesi)
    s, ok2 = _suz(aday, len(gv), kume)
    if ok2:
        return s, [c for c in aday if c not in s], "kurtarildi"
    # SUPHELI: degismezler tutmuyor. Kayitlari YINE veririz (tur donusu icin
    # zorunlu cakisma temizligiyle), ama bolumlemeyi "kanitlandi" diye satmayiz.
    s = _cakismasiz(aday, len(gv))
    return s, [c for c in aday if c not in s], "supheli"


def _refler(gv, kayit_off, son, icid, atilan):
    """Yukun ICINDE kalan nesne-kimligi referanslari [(goreli_off, kimlik)]."""
    return [(c[0] - kayit_off - BASLIK_BOY, kimlik(c[1], c[2], icid))
            for c in atilan if kayit_off < c[0] < son]


# =====================================================================================
#  OKUMA
# =====================================================================================
def dugum_kur(kimlik_turu, sira, sinif_crc, yuk=b"", cocuklar=None, yuk_son=b"",
              opak=True, off=None, ref=None):
    """Tek dugum sozlugu. `yuk` cocuklardan ONCE, `yuk_son` cocuklardan SONRA yazilir."""
    return {"kimlik_turu": kimlik_turu, "sira": int(sira),
            "sinif_crc": int(sinif_crc) & 0xFFFFFFFF,
            "sinif_ad": sinif_ad(sinif_crc),
            "yuk": bytes(yuk), "yuk_son": bytes(yuk_son),
            "cocuklar": list(cocuklar or []), "opak": bool(opak),
            "ref": list(ref or []), "off": off}


def oku_govde(govde, icid, gid=None, sinif=None, sinif_kumesi=None, _kaydir=0):
    """Ic dosya GOVDESI -> nesne agaci. Saf fonksiyon; forge gerekmez.

    Donen sozluk:
      ok, gid, icid, sinif, sinif_ad, onek, kok, opak_bayt, bicim, uyari, govde_boy
    `kok` DUZ bir listedir: bu modul alan semasi bilmedigi icin bir kaydin
    NEREDE bitip cocuklarinin NEREDE basladigini SOYLEYEMEZ; uydurma bir
    ic ice yerlesim URETMEZ. Nesting veri modelinde ve yazicida TAM
    desteklenir (bkz. dugum_kur / yaz), disaridan sema geldiginde kullanilir.
    """
    gv = bytes(govde)
    icid = int(icid)
    kayit, atilan, bicim = _bolumle(gv, icid, sinif_kumesi, _kaydir)
    uyari = []
    kok = []
    onek = gv if not kayit else gv[:kayit[0][0]]
    opak_bayt = 0
    for j, (off, uzay, sira, crc) in enumerate(kayit):
        son = kayit[j + 1][0] if j + 1 < len(kayit) else len(gv)
        yuk = gv[off + BASLIK_BOY:son]
        opak_bayt += len(yuk)
        kok.append(dugum_kur(uzay, sira, crc, yuk, off=off,
                             ref=_refler(gv, off, son, icid, atilan)))
    if bicim == "supheli":
        uyari.append("This body does not satisfy the record invariants (overlapping "
                     "records or repeated ordinals); the split is reported as-is and "
                     "must not be treated as a proven object tree.")
    return {"ok": True, "gid": gid, "icid": icid, "sinif": sinif,
            "sinif_ad": sinif_ad(sinif) if sinif is not None else None,
            "onek": onek, "kok": kok, "opak_bayt": opak_bayt,
            "bicim": bicim, "uyari": uyari, "govde_boy": len(gv),
            "atilan_aday": len(atilan)}


def _ic_dosyalar(gid, forge=None):
    """(icid, ic dosya baytlari) listesi -- SALT OKUMA."""
    from export3d import forge_giris as FG
    if forge:
        import sys
        # yalin_forge: pakette BU modulun yaninda; gelistirmede calisma agacinin
        # kardes klasorunde. Mutlak kisisel yol YAZILMAZ (kur.py 9/9c kapisi).
        for _p in (BURA, os.path.join(os.path.dirname(KOK), "BAYRAK_AVI", "scriptler")):
            if os.path.isdir(_p) and _p not in sys.path:
                sys.path.append(_p)
        from yalin_forge import LeanForge
        lf = LeanForge(forge)
        try:
            return FG.ic_dosyalar(lf, gid)
        finally:
            lf.close()               # Steam "Content file locked" riski birakma
    import outfit_core as C
    return FG.ic_dosyalar(C._forge(), gid)


def oku(gid, icid=None, forge=None, sinif_kumesi=None):
    """CANLI forge'dan TOC girisi 0xGID icindeki ic dosyayi nesne agacina cevirir.

    `icid` verilmezse gid ile AYNI kimlikli ic dosya, yoksa ilki secilir.
    `forge` bir yol verilirse KENDI salt-okuma taniticisi acilir ve KAPATILIR.
    """
    from export3d import forge_giris as FG
    lst = _ic_dosyalar(gid, forge)
    if not lst:
        raise KeyError("entry 0x%X has no inner files" % gid)
    if icid is None:
        sec = None
        for cid, g in lst:
            if cid == gid:
                sec = (cid, g)
                break
        cid, ham = sec or lst[0]
    else:
        icid = int(icid)
        for c, g in lst:
            if c == icid:
                cid, ham = c, g
                break
        else:
            raise KeyError("inner file 0x%X is not in entry 0x%X" % (icid, gid))
    # GOVDE = sarmalayici basligindan SONRAKI HER SEY (silah_stat._ic_govde ile AYNI
    # tanim). `boyut` alanini dilim sinirI olarak KULLANMA: olculdu (19.710 ic dosya,
    # 4 forge) -> len(ic_dosya) - govde_off == boyut - 12 + kuyruk, yani `boyut`
    # govdeden 12 B FAZLADIR ve `ham[govde_off:govde_off+boyut]` kuyruklu bir
    # girisin kuyrugundan 12 B yer. Buradaki tanimla `yaz()` basliktan sonraki
    # BUTUN baytlari geri uretir.
    w = FG.sarmalayici_coz(ham)
    gv = ham[w["govde_off"]:]
    a = oku_govde(gv, cid, gid=gid, sinif=w["tip"], sinif_kumesi=sinif_kumesi)
    a["sarmalayici"] = {"adLen": w["adLen"], "flag": w["flag"], "nid": w["nid"],
                        "boyut": w["boyut"], "kuyruk": w["kuyruk"],
                        "govde_off": w["govde_off"]}
    return a


# =====================================================================================
#  YAZMA -- DERINLIK-ONCELIKLI
# =====================================================================================
def yaz(agac):
    """Nesne agaci -> GOVDE baytlari. Kimlikler TURETILIR, saklanan deger kullanilmaz.

    Bir kaydin serisi: [kimlik][crc][yuk] + COCUKLARIN serisi + [yuk_son].
    Bu sira DERINLIK-ONCELIKLI kuralin ta kendisidir; cocuklari `yuk_son`dan
    SONRA yazan bir surum tur donusunu kirar (test 6).
    Ozyineleme YOK: derinligi binlerce olan agaclar da yazilir.

    ALAN KATMANIYLA SOZLESME: bu modul yuku COZMEZ (her dugum `opak=True`).
    Ustune sinif basina sema koyan katman, alanlari duzenledikten sonra dugumun
    `yuk` / `yuk_son` baytlarini KENDISI gunceller ve `opak=False` yapar; `yaz()`
    daima bu baytlari yazar. Boylece "sema bilinmiyor" durumu sessizce bozuk bayt
    uretmez, ham yuk aynen tasinir.
    """
    out = [bytes(agac.get("onek") or b"")]
    icid = agac.get("icid")
    cerceve = []                         # [dugum, sonraki_cocuk_indeksi]
    for kok in agac["kok"]:
        cerceve.append([kok, -1])
        while cerceve:
            d, i = cerceve[-1]
            if i < 0:
                out.append(struct.pack("<QI",
                                       kimlik(d["kimlik_turu"], d["sira"], icid),
                                       int(d["sinif_crc"]) & 0xFFFFFFFF))
                out.append(bytes(d["yuk"]))
                cerceve[-1][1] = 0
                continue
            coc = d["cocuklar"]
            if i < len(coc):
                cerceve[-1][1] = i + 1
                cerceve.append([coc[i], -1])
                continue
            if d.get("yuk_son"):
                out.append(bytes(d["yuk_son"]))
            cerceve.pop()
    return b"".join(out)


# =====================================================================================
#  GEZINME / DOGRULAMA / YENIDEN NUMARALAMA
# =====================================================================================
def gez(agac_ya_da_dugumler):
    """(dugum, derinlik) uretir -- DERINLIK-ONCELIKLI, YAZMA SIRASIYLA AYNI.
    Ozyineleme yok (derin agaclarda RecursionError uretmez)."""
    dl = agac_ya_da_dugumler["kok"] if isinstance(agac_ya_da_dugumler, dict) \
        else agac_ya_da_dugumler
    yigin = [(d, 0) for d in reversed(dl)]
    while yigin:
        d, dr = yigin.pop()
        yield d, dr
        for c in reversed(d["cocuklar"]):
            yigin.append((c, dr + 1))


def dogrula(agac, govde=None):
    """Agacin degismezleri + (govde verilirse) tur donusu. Kanit uretir, kod degil."""
    yerel, turet = [], []
    dugum = opak = 0
    derinlik = 0
    for d, dr in gez(agac):
        dugum += 1
        opak += 1 if d.get("opak") else 0
        derinlik = max(derinlik, dr + 1)
        (yerel if d["kimlik_turu"] == "yerel" else turet).append(d["sira"])
    r = {"dugum": dugum, "opak_dugum": opak, "derinlik": derinlik,
         "bicim": agac.get("bicim"),
         "yerel_sirali": yerel == list(range(len(yerel))),
         "yerel_tam_kume": sorted(yerel) == list(range(len(yerel))),
         "turetilmis_sirali": turet == list(range(len(turet))),
         "turetilmis_tam_kume": sorted(turet) == list(range(len(turet)))}
    if govde is not None:
        y = yaz(agac)
        r["tur_donusu"] = (y == bytes(govde))
        r["yazilan_boy"] = len(y)
    return r


def yeniden_numarala(agac, zorla=False):
    """YEREL sayaclari yazma sirasina gore 0..N-1 yapar (EKLEME/SILME sonrasi).

    ⭐ OLCUM (9.871 ic dosya): degismezleri saglayan govdelerin YEREL indeksleri
    govde sirasinda ARTAR -- 6.145/6.145 (%100). Yani yerel indeks gercekten
    yazma sirasi sayacidir ve yeniden uretilebilir.

    ⛔ TURETILMIS indeks BOYLE DEGILDIR ve BU ISLEM ONA DOKUNMAZ. Bayt kaniti
    (WeaponStats_Sword_TotalAttack): turetilmis siralar govde sirasinda
    0,14,1,15,2,3,16,4,... gider -- iki ayri sayac ic ice gecmistir, yazma sirasi
    sayaci DEGILDIR. Ornekte gorunmeyeni "0..M-1'dir" diye numaralamak UYDURMA
    olurdu; disaridan bir sema gelene kadar turetilmis sira KORUNUR.

    ⚠ Yerel siralari degistiren her cagri BAYT DEGISTIRIR, bu yuzden degisiklik
    varsa `zorla=True` istenir. Donen sayi degisen dugum sayisidir.
    """
    i = 0
    plan = []
    for d, _dr in gez(agac):
        if d["kimlik_turu"] != "yerel":
            continue
        if d["sira"] != i:
            plan.append((d, i))
        i += 1
    if plan and not zorla:
        raise ValueError("Renumbering would change %d local object ordinals, so it "
                         "would change the bytes of a body that is already valid; pass "
                         "zorla=True only when you added or removed objects."
                         % len(plan))
    for d, j in plan:
        d["sira"] = j
    return len(plan)


def sinif_kumesi_ogren(govdeler):
    """[(icid, govde)] -> DEGISMEZLERI saglayan ("temiz") govdelerin sinif crc kumesi.

    Temiz govdede gomulu referans OLAMAZ (referans, indeksi tekrarlatir ve D2'yi
    dusurur), bu yuzden oradaki her aday GERCEK bir kayittir -- kume boylece
    kendini dogrulayan bir kaynaktan gelir.
    """
    kume = set()
    for icid, gv in govdeler:
        a = _adaylar(bytes(gv), int(icid))
        if a and _degismez(a, len(gv))[0]:
            for c in a:
                kume.add(c[3])
    return kume
