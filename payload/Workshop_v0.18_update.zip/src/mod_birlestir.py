# -*- coding: utf-8 -*-
"""mod_birlestir -- KOPRU: Workshop mod motoru <-> MOD_BIRLESTIRICI (ACMB v1.3.1).

NEDEN VAR (Discord 7-8 Eylul 2026): "Sparrow + QAR ayni anda". Oyun tek
DataPC_boot_patch_02.forge tutar; ikinci hazir yamayi kurmak birincisini ezer.
xDXTERx iki yamayi ELLE birlestirip tasidi. ACMB tam bu isi yapiyor (TOC
girislerini tek patch_02'de toplar, 608 kontrol yesil); bu modul onu Workshop'un
mod motoruna baglar.

NE YAPAR
    birlestir_plani([yama, yama, ...]) -> ne olacagini SOYLER, hicbir sey YAZMAZ:
        {ok, girisler_toplam, catisan_gidler: [{gid, ad, modlar, kazanan}],
         uyari, mesaj, kaynaklar: [...]}
    birlestir([yama, ...], cikti_yolu, progress) -> birlesik forge'u cikti_yolu'na
        YAZAR (gecici bir klasore; oyuna DEGIL):
        {ok, yol, giris_sayisi, sha256, boyut, mesaj, catisan, notlar}

NE YAPMAZ
  * OYUN KLASORUNE YAZMAZ. Birlesik dosya gecici bir yola yazilir; oyuna koyan
    tek yol bugun de sunucu.Api._forge_kur_dosya -> mod_kayit'tir (yedek adiyla).
    mod_kayit'in "forge_birlesik" adaptoru bu modulu cagirir, ciktiyi o yaziciya
    verir. Ikinci bir patch_02 yazicisi ACILMAZ.
  * ACMB'nin kaynagini KOPYALAMAZ: `birlestirici.py` dosya yolundan import
    edilir (bkz. `motor()`), kapilari (yapisal dogrulama, sistem girisi seti,
    cakisma tespiti, cikti geri-okuma dogrulamasi, oyun klasoru reddi, SON KAPI
    sha256) oldugu gibi calisir. Hicbiri gevsetilmez.

CATISMA KURALI -- SONUNCU KAZANIR
  Iki yama ayni varligi (ayni TOC kimligini / ayni doku tabanini) degistiriyorsa
  ikisi birden yasayamaz; ACMB yalniz "hangisi kazansin" sorusunu sorar. Burada
  cevap SABIT ve ACIKTIR: listede SONUNCU verilen yama kazanir. Plan bu durumu
  `catisan_gidler` ile tek tek listeler ve `uyari` cumlesinde soyler; kullanici
  bunu gorup bilerek gecmelidir. (ACMB'nin kendi varsayilani alfabetik ilk moddur;
  o secim bilerek DEGISTIRILIYOR -- "alfabe" kullaniciya bir sey anlatmaz,
  "en son biraktigin kazanir" anlatir.) Sahte cakisma (ayni kimlik, ayni bayt)
  cakisma sayilmaz; ACMB onu ayirir, biz de listelemeyiz.

MOTORUN YERI
  Sirasiyla: ACMB_SRC ortam degiskeni -> src/acmb/birlestirici.py (paketle gelen
  kopya) -> src/birlestirici.py -> ..\\..\\MOD_BIRLESTIRICI\\src (gelistirme agaci).
  Bulunamazsa `motor()` ImportError atar; `birlestir_plani` bunu {ok: False,
  mesaj} olarak dondurur, mod_paket da paketi ESKI yoldan (tek yama) cozmeye
  devam eder. Yani motor yoksa urun cokmez, yalnizca birlestirme secenegi cikmaz.

OLCULDU (2026-09-08, gercek Nexus yamalari):
  Captain Jack Sparrow  59.179.008 B, 9 giris (5 sistem + 4 varlik)
  Black Beard            1.343.488 B, 6 giris (5 sistem + 1 varlik)
  ortak varlik: 0 -> birlesik 10 giris, 59.183.104 B, arsiv_dogrula(tam) 0 hata
  Sparrow + Carl Johnson: 4 GERCEK cakisma (ayni Edward govde/kiyafet varliklari)
  Nosso Senhor: boot + shared_00 -> FARKLI yuvalar, birlestirilmez (ACMB yalniz
  boot patch_02'yi birlestirir).
"""
import hashlib
import importlib.util
import os
import re
import time

__all__ = ["birlestir_plani", "birlestir", "motor", "motor_var_mi", "motor_yolu",
           "birlesik_dosya_adi", "YAMA_ADI", "EN_AZ_KAYNAK"]

BURA = os.path.dirname(os.path.abspath(__file__))
ACMB_ENV = "ACMB_SRC"
ACMB_DOSYA = "birlestirici.py"
YAMA_ADI = "DataPC_boot_patch_02.forge"
EN_AZ_KAYNAK = 2
_MOTOR = []          # yuklenen modul (bir kez)
_MOTOR_YOLU = []


# =============================================================== MOTOR
def _motor_adaylari():
    out = []
    env = os.environ.get(ACMB_ENV)
    if env:
        out.append(env)
    out.append(os.path.join(BURA, "acmb"))
    out.append(BURA)
    out.append(os.path.join(os.path.dirname(os.path.dirname(BURA)),
                            "MOD_BIRLESTIRICI", "src"))
    return out


def motor_yolu():
    """ACMB'nin `birlestirici.py` dosyasi nerede? Yoksa None."""
    if _MOTOR_YOLU:
        return _MOTOR_YOLU[0]
    for d in _motor_adaylari():
        y = os.path.join(d, ACMB_DOSYA) if os.path.isdir(d) else d
        if os.path.isfile(y) and os.path.basename(y).lower() == ACMB_DOSYA:
            return os.path.abspath(y)
    return None


def motor():
    """ACMB motorunu dosya yolundan yukle (bir kez). Doner: modul.

    sys.path'e dokunulmaz: modul kendi adiyla (`acmb_birlestirici`) yuklenir ki
    Workshop'un kendi `birlestir` adli bir seyiyle karismasin."""
    if _MOTOR:
        return _MOTOR[0]
    y = motor_yolu()
    if not y:
        raise ImportError("the patch-combining engine (%s) was not found next to the "
                          "Workshop" % ACMB_DOSYA)
    spec = importlib.util.spec_from_file_location("acmb_birlestirici", y)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    _MOTOR.append(m)
    _MOTOR_YOLU.append(y)
    return m


def motor_var_mi():
    try:
        motor()
        return True
    except Exception:                                           # noqa: BLE001
        return False


def motor_surumu():
    try:
        return str(getattr(motor(), "ARAC_SURUM", "") or "")
    except Exception:                                           # noqa: BLE001
        return ""


# =============================================================== KAYNAKLAR
def _kaynak_adi(dosya):
    """Ad verilmediyse: ust klasorun adi (Nexus modlari 'Mod/DataPC_boot_patch_02.forge'
    diye gelir), o da yoksa dosya govdesi."""
    ust = os.path.basename(os.path.dirname(os.path.abspath(dosya)))
    govde = os.path.splitext(os.path.basename(dosya))[0]
    if govde.lower() == os.path.splitext(YAMA_ADI)[0].lower() and ust:
        return ust
    return govde or ust or "patch"


def _kaynaklar(forge_yollari):
    """[yol | {dosya, ad, kaynak, adlar, ...}] -> [{dosya, ad, ...}]; adlar BENZERSIZ.

    Ad benzersizligi sart: ACMB modlari ADIYLA ayirt eder (cakisma cozumu ad
    uzerinden). Ayni ad iki kez gelirse ikincisine ' (2)' eklenir."""
    if not isinstance(forge_yollari, (list, tuple)):
        raise ValueError("a list of patch files is expected")
    out, gorulen = [], set()
    for k in forge_yollari:
        if isinstance(k, dict):
            d = dict(k)
        else:
            d = {"dosya": k}
        dosya = d.get("dosya")
        if not dosya:
            raise ValueError("one of the patches to combine has no file")
        d["dosya"] = os.path.abspath(str(dosya))
        ad = str(d.get("ad") or _kaynak_adi(d["dosya"])).strip() or "patch"
        taban, n = ad, 2
        while ad in gorulen:
            ad = "%s (%d)" % (taban, n)
            n += 1
        gorulen.add(ad)
        d["ad"] = ad
        out.append(d)
    if len(out) < EN_AZ_KAYNAK:
        raise ValueError("a combined patch needs at least %d patches" % EN_AZ_KAYNAK)
    yollar = [os.path.normcase(d["dosya"]) for d in out]
    if len(set(yollar)) != len(yollar):
        raise ValueError("the same patch file is listed twice")
    return out


def _ad_listesi(kaynaklar):
    """Defterde gorunecek adlar: bir kaynak onceki bir birlesimse (`adlar`) onun
    parcalari AYRI AYRI sayilir."""
    adlar = []
    for k in kaynaklar:
        for ad in (k.get("adlar") or [k.get("ad")]):
            if ad and ad not in adlar:
                adlar.append(str(ad))
    return adlar


_DOSYA_YASAK = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def birlesik_dosya_adi(adlar, en_cok=120):
    """Birlesik yamanin GECICI dosya adi: 'Captain Jack Sparrow + Black Beard.forge'.

    Bu ad kullaniciya gorunur ('... installed as DataPC_boot_patch_02.forge') ve
    charswap.json'da 'harici_mod' olarak durur; o yuzden okunur olmali. Dosya
    adinda gecersiz karakterler '_' olur, uzunluk sinirlanir."""
    govde = " + ".join(str(a) for a in (adlar or []) if a) or "Combined patch"
    govde = _DOSYA_YASAK.sub("_", govde).strip(" .") or "Combined patch"
    if len(govde) > en_cok:
        govde = govde[:en_cok].rstrip() + "..."
    return govde + ".forge"


# =============================================================== HAZIRLIK (ortak)
# ACMB'nin OLUMCUL kodlari -> kullanici cumlesi (ACMB mesajlari Turkce ve tekniktir;
# ekrana o haliyle GITMEZ). Bilinmeyen kod genel cumleye duser.
_OLUMCUL_CUMLE = {
    "DOSYA_YOK": "the file is missing",
    "COK_KISA": "the file is too short to be a game patch",
    "MAGIC": "the file is not a game archive",
    "BASLIK_OFF": "its header is not laid out the way the game expects",
    "GIRIS_SAYISI": "its table of contents is not laid out the way the game expects",
    "TOC_TASMA": "its table of contents runs past the end of the file",
    "GIRIS_TASMA": "one of its entries runs past its table of contents",
}


def _hata_ozeti(m):
    """Modun OLUMCUL hatalarini DUZ INGILIZCE tek cumleye cevir."""
    olumcul = [h for h in m.hatalar if h.seviye == "OLUMCUL"]
    cumleler = []
    for h in olumcul:
        c = _OLUMCUL_CUMLE.get(h.kod, "it is damaged")
        if c not in cumleler:
            cumleler.append(c)
    return "; ".join(cumleler)[:300]


def _hazirla(forge_yollari, progress=None):
    """Kaynaklari oku + dogrula + cakismalari SONUNCU-KAZANIR kuraliyla coz.

    Doner (motor, modlar, plan, sonuc). `sonuc` ACMB'nin bellek-ici birlesimidir
    (henuz hicbir sey yazilmadi). Hata durumunda plan["ok"] False, sonuc None."""
    plan = {"ok": False, "girisler_toplam": 0, "catisan_gidler": [], "uyari": None,
            "mesaj": "", "kaynaklar": [], "kural": "last wins", "notlar": [],
            "eksik_set": 0, "motor": None}
    try:
        B = motor()
    except Exception as e:                                      # noqa: BLE001
        plan["mesaj"] = ("The part of the Workshop that combines patches is missing "
                         "(%s), so these patches can only be installed one at a time."
                         % str(e)[:160])
        return None, [], plan, None
    plan["motor"] = {"yol": motor_yolu(), "surum": motor_surumu()}
    try:
        ks = _kaynaklar(forge_yollari)
    except ValueError as e:
        plan["mesaj"] = str(e)[:200]
        return B, [], plan, None

    modlar = []
    for k in ks:
        if progress:
            progress("- reading %s ..." % k["ad"])
        m = B.mod_oku(k["dosya"], ad=k["ad"])
        B.dogrula(m)
        plan["kaynaklar"].append({
            "ad": m.ad, "dosya": k["dosya"], "boyut": m.boyut,
            "giris": len(m.girisler), "varlik": len(m.varlik_girisleri),
            "sistem_tam": bool(m.sistem_tam), "sha256": m.sha256,
            "hatalar": [(h.seviye, h.kod) for h in m.hatalar],
            "kurulu_mod_id": k.get("kurulu_mod_id")})
        if m.olumcul_mu:
            plan["mesaj"] = ("%s is not a patch this tool can combine (%s)."
                             % (m.ad, _hata_ozeti(m) or "damaged archive"))
            return B, modlar, plan, None
        if not m.varlik_girisleri:
            plan["mesaj"] = ("%s does not change anything in the game (it holds only "
                             "the system entries), so there is nothing to combine."
                             % m.ad)
            return B, modlar, plan, None
        modlar.append(m)
    if not any(m.sistem_tam for m in modlar):
        plan["mesaj"] = ("None of these patches carries the game's five system entries; "
                         "a combined patch made from them would stop the game from "
                         "starting. Nothing was written.")
        return B, modlar, plan, None

    # --- cakisma: ACMB bulur, kazanani BIZ soyleriz (listede SONUNCU)
    sira = [m.ad for m in modlar]
    cz = B.IsimCozucu()
    try:
        cakismalar = B.cakisma_bul(modlar, cz)
        cozumler = {}
        for c in cakismalar:
            ortak = [ad for ad in sira if ad in c.modlar]
            kazanan = ortak[-1] if ortak else c.modlar[-1]
            cozumler[c.taban_fid] = kazanan
            if not c.gercek:
                continue            # ayni bayt: secilecek bir sey yok
            plan["catisan_gidler"].append({
                "gid": "0x%012X" % c.taban_fid,
                "ad": c.ad if c.ad and c.ad != "(adi bilinmiyor)" else None,
                "modlar": ortak, "kazanan": kazanan,
                "kaybeden": [ad for ad in ortak if ad != kazanan]})
        try:
            sonuc = B.birlestir(modlar, cozumler=cozumler, cozucu=cz)
        except (ValueError, AssertionError) as e:
            plan["mesaj"] = "These patches could not be combined: %s" % str(e)[:200]
            return B, modlar, plan, None
    finally:
        cz.kapat()

    plan["girisler_toplam"] = len(sonuc.girisler)
    plan["notlar"] = list(sonuc.notlar)
    plan["eksik_set"] = len(sonuc.eksik_girisler)
    # Sistem girisleri (0x10 0x91 0xC1 0xFF8 0xFFA) LISTEDE ILK tam setli moddan
    # gelir (ACMB kurali; degistirilmedi). OLCULDU: Sparrow ile Black Beard'in
    # sistem girisleri 4/5'te FARKLI (0x10, 0x91, 0xFF8, 0xFFA) -- yani sira
    # yalniz cakismayi degil, sistem girisi bagiscisini da secer. Hangisinin
    # oyunda "daha dogru" oldugu OLCULMEDI (oyun ici kanit yok); plan bunu
    # saklamaz, `sistem_kaynak` + `sistem_farki` ile soyler.
    plan["sistem_kaynak"] = sonuc.sistem_kaynak
    plan["sistem_farki"] = any("sistem girisleri farkli" in n for n in sonuc.notlar)
    plan["ok"] = True
    n = len(modlar)
    if plan["catisan_gidler"]:
        kazananlar = []
        for c in plan["catisan_gidler"]:
            if c["kazanan"] not in kazananlar:
                kazananlar.append(c["kazanan"])
        plan["uyari"] = ("%d part(s) of the game are changed by more than one of these "
                         "patches. Where that happens the patch listed last wins (%s), "
                         "and the other patch's change to that part is lost."
                         % (len(plan["catisan_gidler"]), ", ".join(kazananlar)))
    plan["mesaj"] = ("Combines %d ready-made patches into one (%s): %d entries."
                     % (n, " + ".join(sira), len(sonuc.girisler)))
    if plan["eksik_set"]:
        plan["uyari"] = ((plan["uyari"] + " ") if plan["uyari"] else "") + (
            "%d of the winning patches do not carry every piece the losing patch "
            "carried, so the combined patch may show a broken texture there."
            % plan["eksik_set"])
    return B, modlar, plan, sonuc


# =============================================================== DIS API
def birlestir_plani(forge_yollari, progress=None):
    """NE OLACAGINI soyle; YAZMA.

    forge_yollari: [yol | {dosya, ad, kaynak, adlar, kurulu_mod_id}] -- SIRA ONEMLI:
                   cakismada SONUNCU kazanir.
    Doner: {ok, girisler_toplam, catisan_gidler: [{gid, ad, modlar, kazanan,
            kaybeden}], uyari, mesaj, kaynaklar, kural, notlar, eksik_set, motor}"""
    _b, _m, plan, _s = _hazirla(forge_yollari, progress)
    return plan


def birlestir(forge_yollari, cikti_yolu, progress=None):
    """Birlesik forge'u `cikti_yolu`na YAZ (oyun klasorune DEGIL) ve geri okuyup dogrula.

    Yazan ACMB'nin kendi `yaz`idir: once <cikti>.tmp, geri-okuma dogrulamasi,
    ancak temizse os.replace; oyun klasoru hedefleniyorsa reddeder (oyun_korumasi);
    hedefte duran dosya kaynaklardan biriyse reddeder (SON KAPI sha256).
    Doner: {ok, yol, giris_sayisi, sha256, boyut, mesaj, catisan, uyari, notlar,
            kaynaklar, dogrulama_kaldi, sure}"""
    t0 = time.time()
    r = {"ok": False, "yol": None, "giris_sayisi": 0, "sha256": None, "boyut": 0,
         "mesaj": "", "catisan": [], "uyari": None, "notlar": [], "kaynaklar": [],
         "dogrulama_kaldi": []}
    B, modlar, plan, sonuc = _hazirla(forge_yollari, progress)
    r["catisan"] = plan.get("catisan_gidler") or []
    r["uyari"] = plan.get("uyari")
    r["notlar"] = plan.get("notlar") or []
    r["kaynaklar"] = [k["ad"] for k in (plan.get("kaynaklar") or [])]
    if not plan.get("ok") or sonuc is None:
        r["mesaj"] = plan.get("mesaj") or "These patches could not be combined."
        return r
    cikti = os.path.abspath(str(cikti_yolu))
    if progress:
        progress("- writing the combined patch (%d entries) ..." % len(sonuc.girisler))
    try:
        y = B.yaz(sonuc, cikti, oyun_korumasi=True,
                  defter=os.path.join(os.path.dirname(cikti), "acmb_defter.json"),
                  yan_dosya=False,
                  kaynaklar=[m.ad for m in modlar],
                  kaynak_shalari=[m.sha256 for m in modlar])
    except ValueError as e:
        r["mesaj"] = "The combined patch was not written: %s" % str(e)[:300]
        return r
    except OSError as e:
        r["mesaj"] = ("The combined patch could not be written (%s)."
                      % (getattr(e, "strerror", None) or str(e))[:160])
        return r
    r["dogrulama_kaldi"] = [msg for ok, msg in (y.get("dogrulama") or []) if not ok]
    if not y.get("yazildi") or y.get("kaldi"):
        r["mesaj"] = ("The combined patch failed its own check after writing (%s), so it "
                      "was thrown away. Nothing was installed."
                      % "; ".join(r["dogrulama_kaldi"])[:300])
        return r
    r.update(ok=True, yol=cikti, giris_sayisi=int(y.get("giris") or 0),
             sha256=y.get("sha256"), boyut=int(y.get("boyut") or 0),
             sure=round(time.time() - t0, 2))
    r["mesaj"] = ("Combined %d patches into one (%s): %d entries, %.1f MB."
                  % (len(modlar), " + ".join(m.ad for m in modlar),
                     r["giris_sayisi"], r["boyut"] / 1e6))
    if progress:
        progress("- combined patch ready: %d entries, %.1f MB"
                 % (r["giris_sayisi"], r["boyut"] / 1e6))
    return r


def dosya_sha256(yol, blok=1 << 20):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for p in iter(lambda: f.read(blok), b""):
            h.update(p)
    return h.hexdigest()


if __name__ == "__main__":                                      # elle yoklama
    import json
    import sys
    if len(sys.argv) < 3:
        print("usage: mod_birlestir.py <patch.forge> <patch.forge> [...] [-o cikti]")
        sys.exit(64)
    argv = list(sys.argv[1:])
    cikti = None
    if "-o" in argv:
        i = argv.index("-o")
        cikti = argv[i + 1]
        del argv[i:i + 2]
    print(json.dumps(birlestir_plani(argv), indent=1, ensure_ascii=False))
    if cikti:
        print(json.dumps(birlestir(argv, cikti, progress=print), indent=1,
                         ensure_ascii=False))
