# -*- coding: utf-8 -*-
"""kur_mesh — duzenlenmis ic dosyayi (mesh) forge'a KURAR ve GERI ALIR.

Bu modul export3d hattinin SON halkasi:
    forge -> glb_yaz (export) -> Blender -> glb_oku (import) -> mesh_yaz (yeni ic
    dosya baytlari) -> **kur_mesh (arsive yaz + geri alma kaydi)**

Neden ayri bir modul: `mesh_yaz` yalnizca IC DOSYA baytlarini uretir, forge'a tek
bayt yazmaz (bilincli). Deney betikleri o baytlari kum forge'unun sonuna ekleyip
TOC satirini yonlendiriyordu; kayit tutmuyor, yedek almiyor, oyun acikken
reddetmiyordu. Yayinlanacak arac icin o yol YETMEZ.

TASARIM — projedeki IKI olculmus kayitciyi ornek alir:
  * `ses_core.sustur/sesi_ac`  -> WAL: kayit ILK BAYTTAN ONCE yazilir, yazimdan
    sonra DOGRULANIR, giris "uygulandi" olarak isaretlenir.
  * `doku_enjekte2.uygula/gerial` -> forge kimligi, ham TOC satirinin saklanmasi,
    eklenen bloklarin listesi ve geri almada kuyruk kirpma.

DEGISMEZ KURALLAR (ac4-mod-guvenlik-kurallari):
  1. Oyun acikken TEK BAYT yazilmaz.
  2. Yazilacak her sey once BELLEKTE kurulur ve KENDI OKUYUCUMUZLA cozulerek
     dogrulanir; kap cozulemiyorsa dosyaya dokunulmaz.
  3. Kayit (journal) ilk bayttan ONCE diske fsync'lenir.
  4. Ustune yazilan her sey once YEDEKLENIR.
  5. Yazimdan sonra DISKTEN geri okunup niyetle karsilastirilir; tutmazsa
     otomatik geri alma denenir ve giris "yarim" isaretlenir.
  6. TOC satiri geri yazilmadan once HALA bizim yazdigimiz satir mi diye bakilir
     (baska bir arac araya girdiyse geri alma reddedilir).

YERINDE mi EK mi? -> `YONTEM_NOTU` (olcumle secildi; varsayilan "ek").

2026-09-07 KAPANAN IKI KUSUR (kapilar: testler/test_kur_mesh_kuyruk.py)
  K1 KUYRUK MUHASEBESI. Fazlalik, kaydin KENDI `forge_boyut_once`undan hesaplaniyordu;
     o alan yalniz ILK yamada arsivin tabanina esittir. Sonuc: "Revert all" arsivi
     kucultmedigi halde tek kelime etmiyordu (olculdu: 29.917.184 -> 29.970.627 B,
     {"ok": true}), ve A kuruluyken B'yi geri almak {"oksuz_bayt": 0} diyordu.
     Simdi her kayit `vanilla_boyut` (bu arsive ILK yazisimizdan onceki boyut) tasir;
     `geri_al`/`geri_al_hepsi`/`saglik` `kuyruk_bayt` dondurur, kirpilamayan blok icin
     SEBEP soylenir, `kuyruk_temizle` yabanci arac cekilince supurur ve kirpma
     TABANIN ALTINA inmez (temiz forge'un sonunda TOC'un gostermedigi kuyruk verisi var:
     WhiteRoom'da 39.849 B).
  K3 "ARSIV VANILLA" YALANI (2026-09-07, kapilar 11..15). `kuyruk_bayt` gercek
     DataPC_boot.forge'da 0 -- yani "bizden hicbir sey kalmamis" -- diyordu, oysa
     dosyanin son 1.089.981 bayti bizim CANLI bloklarimizdi (canli TOC ile olculdu:
     scratchpad\\e1_yalan_kuyruk.py). Taban yalniz `vanilla_boyut` ALANI TASIYAN
     kayitlardan turetiliyordu; o depodaki 26 kaydin 20'sinde alan yoktu, kalan 6'nin
     alani ise dosyanin BUGUNKU sonuydu. Simdi taban uc kaynaktan turetilir
     (alan / gozlem / CANLI TOC), hicbiri yoksa "bilinmiyor" (None) donulur -- 0 DEGIL --
     ve `kuyruk_olc()` sebebi + kullaniciya basilacak cumleyi verir. Rapor tabani ile
     KIRPMA ZEMINI artik ayri iki fonksiyon: rapor yanilirsa fazlaligi abartir, kirpma
     yanilirsa az keser. Donus semasi icin "DONUS SEMASI (cagiranlar icin)" basligina bak.
  K2 BAYAT YEDEK KILIDI. Yedek BIR KEZ yaziliyor, tazelenmiyordu; oyun guncellenince
     (ya da Steam dogrulamasindan sonra) yedek arsivle ebediyen tutmuyor ve kurulum
     "backup ... damaged" ile KALICI reddediliyordu -- plan "ok" derken. Simdi
     `_yedek_durumu` uc durumu ayirir: "taze" / "bayat" (oyun degismis -> kayit gecersiz
     isaretlenir, yedek tazelenir, kurulum GECER) / "catisma" (arsivde CANLI yama ->
     REDDEDILIR). doku_enjekte2 catismasi da reddedilmeye devam eder.

2026-09-13 HAM GIRIS YOLU (`kur_ham`; kapilar: testler/test_kur_ham_kum.py)
  BMS olmayan sistem girisleri (0x091 giris-basina bagimlilik tablosu: ilk 8 bayt BMS
  degil, `kur_plani` "Not a BMS block at offset 0." der -- olculdu) `kur` ile YAZILAMIYORDU;
  ALT_GUVERTE/src/hucre_bagimlilik.py planladigi baytlari _tmp'ye birakip reddediyordu.
  `kur_ham` var olan TOC girisini HAM baytlarla degistirir: giris_kur / ic dosya cozumu
  YOK, gerisi `kur`un zinciri (kilit + oyun kapisi, bayat/catisma ayiklamasi, yedek, WAL,
  "ek" yazma, TOC yonlendirme, diskten geri okuma, `geri_al` ile bayt-birebir donus).
  Zincirin halkalari artik ORTAK alt fonksiyonlarda durur (`_yazma_kapisi`,
  `_onceki_ayikla`, `_yedek_hazirla`, `_kayit_girisi`, `_giris_yaz`, `_dogrula_giris`,
  `_dogrulama_dustu`, `_kurulum_bitir`); `kur`un yazdigi baytlar ve kaydi bu ayrimdan
  ONCE neyse odur. Kayitta `yontem: "ham"`; kuyruk muhasebesi (`EKLI_YONTEMLER`) bu
  kayitlari da gorur.
"""
import hashlib
import io
import json
import os
import struct
import subprocess
import sys
import tempfile
import time

try:
    from yalin_forge import LeanForge, read_block, BMS, oodle_dll_yolu
except ImportError:                       # gelistirme agacinda yalin_forge,
    import outfit_core                    # noqa: F401  outfit_core'un sys.path'e
    from yalin_forge import LeanForge, read_block, BMS, oodle_dll_yolu

try:
    from . import forge_giris as FG
except ImportError:                       # duz betik olarak da calissin
    import forge_giris as FG

__all__ = ["oyun_acik_mi", "kur_plani", "kur", "kur_ham_plani", "kur_ham", "geri_al",
           "geri_al_hepsi", "durum", "saglik", "veri_yolu_ayarla", "kuyruk_bayt",
           "kuyruk_olc", "kuyruk_temizle", "KAYIT", "VERI_KOK", "KUYRUK_SEBEP", "HAM",
           "etkin_arsiv", "zincir_arsivleri", "GOLGE_YONLENDIR"]

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
MESH_TIPI = 0x415D9568
TOC_SATIR = 24                     # off u64 | fid u64 | len u32 | ext u32
PARCA_BOY = 262144                 # BMS blok parcasi (olculdu: 10/10 parca 262144)
KAYIT_SURUM = 1

# --- geri-alma verisi NEREDE durur -------------------------------------------
# doku_enjekte2 ile AYNI kok (`ACBFR_Modding`) ama AYRI alt klasor: iki arac ayni
# arsive yaziyor, kayitlari karismamali. Ayni kokte durmalari `saglik()`in ikisini
# birden listeleyebilmesi icindir (Health Check "hangi yamalar duruyor" der).
VERI_KOK = os.path.join(os.environ.get("LOCALAPPDATA") or
                        os.path.join(os.path.expanduser("~"), "AppData", "Local"),
                        "ACBFR_Modding", "mesh")
KAYIT = os.path.join(VERI_KOK, "mesh_kayit.json")
YEDEK_KOK = os.path.join(VERI_KOK, "yedek")

# doku_enjekte2'nin deposu (SALT OKUNUR olarak bakariz — catisma kontrolu icin)
DOKU_KOK = os.path.dirname(VERI_KOK)
DOKU_KAYIT_ADI = "doku_enjekte2_kayit.json"

YONTEM_NOTU = (
    "Default is 'append': the original entry is never overwritten, so a crash "
    "during the write leaves the archive readable. 'in place' avoids growing the "
    "file but destroys the only copy of the original bytes while writing."
)


KILIT_ADI = "YAZMA_KILIDI"


def yazma_kilidi():
    """Oyun arsivine yazma kilitli mi? Doner kilit dosyasinin yolu ya da None.

    Kilit VARSA `kur`/`geri_al` reddeder; salt-okuma (kur_plani, durum, saglik) calisir.
    Amac: olcum yapan otomatik ajanlarin gercek oyuna yazmasini KODLA engellemek (2026-09-05'te
    bir ajan talimata ragmen yazdi). Son kullanicida bu dosya olusmaz."""
    ov = os.environ.get("ACBFR_YAZMA_KILIDI")
    if ov:
        return ov if os.path.exists(ov) else None
    p = os.path.join(os.path.dirname(VERI_KOK), KILIT_ADI)
    return p if os.path.exists(p) else None


def _kilit_mesaji(k):
    return ("writing to the game archive is locked on this machine (%s). Delete that file to write "
            "again. (The lock exists so automated measurement runs cannot touch the game.)" % k)


def veri_yolu_ayarla(kok=None):
    """Kayit/yedek yollarini yeniden hesapla (testler baska bir koke isaret eder)."""
    global VERI_KOK, KAYIT, YEDEK_KOK, DOKU_KOK
    if kok:
        VERI_KOK = os.path.abspath(kok)
    KAYIT = os.path.join(VERI_KOK, "mesh_kayit.json")
    YEDEK_KOK = os.path.join(VERI_KOK, "yedek")
    DOKU_KOK = os.path.dirname(VERI_KOK)
    return KAYIT


# ------------------------------------------------------------------ yardimcilar
def _sha(b):
    return hashlib.sha256(b).hexdigest()


def dosya_sha(yol):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for blok in iter(lambda: f.read(1 << 24), b""):
            h.update(blok)
    return h.hexdigest()


def _forge_anahtari(forge):
    """doku_enjekte2._forge_anahtari ile AYNI formul: iki depo ayni arsivi ayni
    anahtarla adlandirir, boylece Health Check ikisini yan yana koyabilir."""
    return hashlib.sha256(os.path.normcase(os.path.abspath(forge)).encode("utf-8")
                          ).hexdigest()[:12]


# ------------------------------------------------------------------ YAMA ZINCIRI (golge)
# Oyun ayni kimligi hem X.forge'da hem X_patch_NN.forge'da bulursa UST halkayi okur
# (cok_forge.zincir_kur ile AYNI kural). Golgeli bir kimligi alt halkaya yazmak BASARILI
# gorunur ama oyunda HICBIR SEY DEGISMEZ -- sessiz kusur (Nexus, LordOfThe9 2026-09-13:
# Connor/Altair Patch_01'de guncellendi; OLCULDU 2026-10-12: boot'un 876 mesh kimligi
# patch_01'de golgeli, 242 kimlik YALNIZ patch_01'de; Altair'in 10 parcasinin 10'u golgeli).
# Bu yuzden `kur`/`kur_ham` (ve planlari) hedefi, kimligi iceren EN YUKSEK halkaya
# yonlendirir ve bunu donuste `yonlendi_arsiv` ile soyler; kayit o arsive yazilir ve
# `istenen_forge` alaniyla cagiranin verdigi arsivi de saklar. `durum`/`saglik`/
# `geri_al_hepsi` bir arsiv istenince o arsivin BUTUN zincirini gorur.
# Kapatma anahtari (ayirt edicilik kapisi + acil durum dugmesi): GOLGE_YONLENDIR = False.
GOLGE_YONLENDIR = True
_GID_ONBELLEK = {}             # normcase(yol) -> (boyut, mtime_ns, frozenset(gid))


def _zincir_grubu(ad):
    """'DataPC_boot_patch_01.forge' -> ('datapc_boot', 1) (cok_forge.zincir_grubu ile AYNI)."""
    try:
        from . import cok_forge as CF
    except ImportError:                       # duz betik olarak da calissin
        import cok_forge as CF
    return CF.zincir_grubu(ad)


def _arsiv_gidleri(yol):
    """Bir arsivin kimlik kumesi (CANLI TOC; boyut+mtime degisince yeniden okunur).
    Acilamayan dosya (kum havuzu yer tutucusu, bozuk arsiv) = BOS kume."""
    try:
        st = os.stat(yol)
    except OSError:
        return frozenset()
    nc = os.path.normcase(os.path.abspath(yol))
    hit = _GID_ONBELLEK.get(nc)
    if hit is not None and hit[0] == st.st_size and hit[1] == st.st_mtime_ns:
        return hit[2]
    try:
        lf = LeanForge(yol)
    except Exception:                                           # noqa: BLE001
        return frozenset()
    try:
        gidler = frozenset(int(e[1]) for e in lf.entries)
    finally:
        lf.close()
    if len(_GID_ONBELLEK) > 16:
        _GID_ONBELLEK.clear()
    _GID_ONBELLEK[nc] = (st.st_size, st.st_mtime_ns, gidler)
    return gidler


def zincir_arsivleri(forge):
    """`forge`un yama grubundaki, diskte VAR OLAN arsivler -- EN YUKSEK yama ONCE, taban en
    sonda (`forge` klasorde yoksa basa eklenir). Ezber liste yok: klasor her cagrida okunur."""
    forge = os.path.abspath(forge)
    kok = os.path.dirname(forge)
    taban, _n = _zincir_grubu(os.path.basename(forge))
    try:
        adlar = os.listdir(kok)
    except OSError:
        adlar = []
    adaylar = []
    for ad in adlar:
        if not ad.lower().endswith(".forge"):
            continue
        t, n = _zincir_grubu(ad)
        if t == taban:
            adaylar.append((n, ad))
    sira = [os.path.join(kok, ad) for _n, ad in sorted(adaylar, reverse=True)
            if os.path.isfile(os.path.join(kok, ad))]
    if os.path.normcase(forge) not in {os.path.normcase(p) for p in sira}:
        sira.insert(0, forge)
    return sira


def etkin_arsiv(forge, gid):
    """Oyunun `gid` icin GERCEKTEN okudugu arsiv: kimligi iceren EN YUKSEK halka.
    Hicbir halka icermiyorsa `forge` (kur_plani zaten 'not in the table of contents' der)."""
    for p in zincir_arsivleri(forge):
        if int(gid) in _arsiv_gidleri(p):
            return p
    return os.path.abspath(forge)


def _zincir_anahtarlari(forge):
    """Zincirdeki her arsivin kayit anahtari: durum/saglik/geri_al_hepsi butun halkayi gorur."""
    return {_forge_anahtari(p) for p in zincir_arsivleri(forge)}


def _hedef_coz(forge, gid, yonlendir, r):
    """kur / kur_ham / plan girisi: yazilacak arsivi coz. `yonlendir` None ise GOLGE_YONLENDIR.
    Yonlendiyse `r`ye yazar: yonlendi_arsiv (dosya adi), yonlendi_yol, yonlendi_mesaj;
    her durumda r['istenen_arsiv'] = cagiranin verdigi, r['forge'] = gercek hedef."""
    forge = os.path.abspath(forge)
    r["istenen_arsiv"] = forge
    if yonlendir is None:
        yonlendir = GOLGE_YONLENDIR
    hedef = etkin_arsiv(forge, gid) if yonlendir else forge
    if os.path.normcase(hedef) != os.path.normcase(forge):
        r["yonlendi_arsiv"] = os.path.basename(hedef)
        r["yonlendi_yol"] = hedef
        r["yonlendi_mesaj"] = ("Written to %s instead of %s: the game loads this entry from "
                               "the patch archive, so a change in %s would never show up."
                               % (os.path.basename(hedef), os.path.basename(forge),
                                  os.path.basename(forge)))
    r["forge"] = hedef
    return hedef


def oyun_acik_mi():
    """Oyun calisiyor mu? (ses_core / ship_core ile ayni bayt-karsilastirmasi:
    OEM kod sayfasindan bagimsiz, `tasklist` ciktisini METIN'e cevirmez.)"""
    try:
        c = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ACBlackFlag.exe"],
                           capture_output=True, timeout=10, creationflags=NO_WINDOW)
        return b"ACBlackFlag.exe" in (c.stdout or b"")
    except Exception:                                           # noqa: BLE001
        return False


def _json_oku(yol, bos=None):
    if os.path.isfile(yol):
        try:
            # `with`: acik tanitici birakmak Windows'ta dosyanin silinmesini/
            # degistirilmesini engelliyor (release_forge dersinin kucuk kardesi).
            with io.open(yol, encoding="utf-8") as f:
                return json.load(f)
        except Exception:                                       # noqa: BLE001
            pass
    return bos if bos is not None else {"surum": KAYIT_SURUM, "arac": "kur_mesh",
                                        "girisler": []}


def _kayit_oku():
    k = _json_oku(KAYIT)
    k.setdefault("girisler", [])
    return k


def _kayit_yaz(k):
    """ATOMIK + fsync. Bu dosya arsivin tek geri donus yolu; yarim yazilamaz."""
    os.makedirs(VERI_KOK, exist_ok=True)
    fd, gecici = tempfile.mkstemp(dir=VERI_KOK, prefix=".mesh_kayit_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(k, f, indent=1)
            f.flush()
            os.fsync(f.fileno())
        os.replace(gecici, KAYIT)
    except BaseException:
        try:
            os.remove(gecici)
        except OSError:
            pass
        raise


# ------------------------------------------------------------------ Oodle sikistirma
_SIK = {}


def _oodle_sik_fn():
    import ctypes
    if "fn" not in _SIK:
        yol = oodle_dll_yolu()
        if not yol:
            from yalin_forge import OODLE_YOK   # ceviri sozlugunde ZATEN duran metin
            raise RuntimeError(OODLE_YOK)
        lib = ctypes.CDLL(yol)
        fn = lib.OodleLZ_Compress
        fn.restype = ctypes.c_int
        fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p,
                       ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, ctypes.c_size_t]
        _SIK["lib"] = lib
        _SIK["fn"] = fn
    return _SIK["fn"]


# Sikistirma seviyesi. 6 = projedeki diger yazicilarin (doku_enjekte2, Ship
# Workshop) kullandigi ve OYUNDA CALISTIGI GORULMUS seviye; varsayilan odur.
# OLCUM (5 WhiteRoom mesh girisi, ayni ic dosyayla yeniden paketleme):
#     seviye 4 -> vanilla'nin x1,0967'si   (0/5 giris orijinal yuvasina siger)
#     seviye 6 -> x1,0407                  (0/5)
#     seviye 7 -> x0,9977                  (4/5)   <- vanilla ile basa bas
#     seviye 8 -> x0,9977                  (4/5)
#     seviye 9 -> x0,9977                  (4/5)
# Yani 7 arsivi neredeyse hic buyutmez ve YERINDE yolu erisilebilir kilar; ama
# oyun icinde HENUZ DENENMEDI. Kanit gelene kadar varsayilan 6 kalir (kural:
# "kod varligi kanit degil"). Degistirmek isteyen: KUM kopyasinda dene, sonra ac.
SIKISTIRMA_SEVIYESI = 6


def oodle_sik(veri, codec=9, seviye=None):
    import ctypes
    seviye = SIKISTIRMA_SEVIYESI if seviye is None else seviye
    fn = _oodle_sik_fn()
    out = ctypes.create_string_buffer(len(veri) + 65536)
    n = fn(codec, veri, len(veri), out, seviye, None, None, None, None, 0)
    if n <= 0:
        raise RuntimeError("Oodle compression failed.")
    return out.raw[:n]


def lzo_adler32(a2):
    """BMS parca saglama toplami — init 0 (hafiza: ac4-forge-format-referansi)."""
    num = num2 = i = 0
    n = len(a2)
    while n:
        n5 = min(n, 5552)
        n -= n5
        while n5:
            num = (num + a2[i]) & 0xFFFFFFFF
            num2 = (num2 + num) & 0xFFFFFFFF
            i += 1
            n5 -= 1
        num %= 65521
        num2 %= 65521
    return (num | (num2 << 16)) & 0xFFFFFFFF


# ------------------------------------------------------------------ BMS kap
def blok_coz(raw, off):
    """BMS blogunun basligini ayristir (yalin_forge.read_block ile AYNI kural).

    Doner: dict(ver, bayrak, d4, pc, pc_genis, veri_bas, son, sizes)
    """
    if raw[off:off + 8] != BMS:
        raise ValueError("Not a BMS block at offset {0}.".format(off))
    p = off + 8
    ver = struct.unpack_from("<H", raw, p)[0]; p += 2
    bayrak = raw[p]; p += 1
    d4 = struct.unpack_from("<I", raw, p)[0]; p += 4
    t = struct.unpack_from("<I", raw, p)[0]
    if t >= 0x10000:
        pc = struct.unpack_from("<H", raw, p)[0]; p += 2
        pc_genis = False
    else:
        pc = t; p += 4
        pc_genis = True
    sizes = []
    for _ in range(pc):
        if ver <= 1:
            u, c = struct.unpack_from("<HH", raw, p); p += 4
        else:
            u, c = struct.unpack_from("<II", raw, p); p += 8
        sizes.append((u, c))
    veri_bas = p
    for _u, c in sizes:
        p += 4 + c
    return dict(off=off, ver=ver, bayrak=bayrak, d4=d4, pc=pc, pc_genis=pc_genis,
                veri_bas=veri_bas, son=p, sizes=sizes)


def blok_kur(govde, sablon, parca_boy=PARCA_BOY):
    """`govde`yi `sablon` blogunun bicimiyle (ver/bayrak/d4/parca genisligi) paketle.

    Parca boyu ORIJINALDEN alinir: cok parcali bir blokta en buyuk sikistirilmamis
    parca ne ise (olculdu: 262144) yenisi de o. Tek parcali kucuk bloklarda
    orijinal parca boyu govde kadardir; yeni govde buyurse 262144'e boluruz.
    """
    ver, pc_genis = sablon["ver"], sablon["pc_genis"]
    if ver <= 1 and parca_boy > 0xFFFF:
        parca_boy = 0xFFFF
    dilimler = [govde[i:i + parca_boy] for i in range(0, len(govde), parca_boy)] or [b""]
    parcalar = []
    for d in dilimler:
        cv = oodle_sik(d) if d else b""
        if len(cv) >= len(d):
            cv = d                                  # sikismadi -> STORED (u == c)
        parcalar.append((len(d), cv))
    bas = bytearray(BMS)
    bas += struct.pack("<H", ver)
    bas += bytes([sablon["bayrak"]])
    bas += struct.pack("<I", sablon["d4"])
    if pc_genis:
        bas += struct.pack("<I", len(parcalar))
    else:
        bas += struct.pack("<H", len(parcalar))
    for u, cv in parcalar:
        bas += struct.pack("<HH", u, len(cv)) if ver <= 1 else struct.pack("<II", u, len(cv))
    for _u, cv in parcalar:
        bas += struct.pack("<I", lzo_adler32(cv)) + cv
    return bytes(bas)


def _parca_boy_sec(sablon, govde_boy):
    """Sablonun kullandigi parca boyu; tek parcaliysa varsayilan 262144."""
    if sablon["pc"] > 1:
        return max(u for u, _c in sablon["sizes"])
    u = sablon["sizes"][0][0] if sablon["sizes"] else govde_boy
    return u if u >= govde_boy else PARCA_BOY


def giris_kur(raw, icid, yeni_ic):
    """Giris ham baytlari + hedef ic dosyanin YENI govdesi -> YENI giris baytlari.

    * K1 (kayit tablosu) BAYT BAZINDA korunur; yalnizca hedef kaydin u32 uzunluk
      alani degisir (ekstra alanlar, kuyruk, sira aynen kalir). Kayit sinirlari
      forge_giris.k1_yerler'den gelir: k1_coz'un UC aday kurali, KATI secim
      (tablo tam bitmeli + Σlen == K2). 2026-09-13'e kadar burada tek kural
      (18 + a) yuruyordu; 2b alanli girislerde (CaribbeanSea_patch_01 Cell122802,
      129 ic dosya, K1 2.502 B) ofset 2.701'den okumaya kalkip struct.error veriyor,
      kur_mesh.kur / explorer_core.geri_yukle o girisleri yeniden dizemiyordu.
      Kap dizimi artik forge_giris.k1_k2_yeniden_diz'de (TEK K1 yamalayici); eski
      kuralla cozulen girislerde cikti bayt-birebir AYNI (kapi: test_k1_yerler_yazici).
    * K2 govdeleri birlestirilirken hedef olanin yerine yenisi konur.
    * Iki blok da orijinal blogun bicimiyle yeniden paketlenir.
    Doner: (yeni_giris, bilgi)
    """
    s1 = blok_coz(raw, 0)
    k1, n1 = read_block(raw, 0)
    if k1 is None:
        raise ValueError("This archive entry is not a BMS container.")
    s2 = blok_coz(raw, n1)
    k2, _n2 = read_block(raw, n1)
    if k2 is None:
        raise ValueError("This archive entry has no body container.")

    # --- K1: hedef kaydin uzunlugunu degistir (4 bayt), gerisi aynen · K2: yeniden seri
    try:
        k1_yeni, k2_yeni, oz = FG.k1_k2_yeniden_diz(k1, k2, {icid: yeni_ic})
    except KeyError:
        raise KeyError("Inner file 0x{0:X} is not in this entry.".format(icid))
    kayitlar = [(c, l) for c, l, _q in oz["yerler"]]
    eski_ic = oz["eski"][icid]

    yeni = blok_kur(bytes(k1_yeni), s1, _parca_boy_sec(s1, len(k1_yeni))) + \
        blok_kur(bytes(k2_yeni), s2, _parca_boy_sec(s2, len(k2_yeni)))

    # --- KURAL 2: yazmadan once KENDI okuyucumuzla coz ve karsilastir
    d1, m1 = read_block(yeni, 0)
    d2, _m2 = read_block(yeni, m1)
    if d1 != bytes(k1_yeni) or d2 != bytes(k2_yeni):
        raise RuntimeError("The rebuilt entry does not decode back to what we packed - nothing was written.")
    try:
        kontrol, _kural = FG.k1_yerler(d1, len(d2))     # KATI: ayni sinirlar, yeni uzunluk
    except ValueError:
        kontrol = None
    beklenen = [(c, (len(yeni_ic) if c == icid else l), q) for c, l, q in oz["yerler"]]
    if kontrol != beklenen:
        raise RuntimeError("The rebuilt entry has an inconsistent file table - nothing was written.")
    if len(yeni) > 0xFFFFFFFF:
        raise RuntimeError("The rebuilt entry is too large for this archive format.")
    bilgi = {"eski_ic_bayt": len(eski_ic), "yeni_ic_bayt": len(yeni_ic),
             "eski_ic_sha": _sha(eski_ic), "yeni_ic_sha": _sha(yeni_ic),
             "eski_giris_bayt": len(raw), "yeni_giris_bayt": len(yeni),
             "k1_kayit": len(kayitlar), "k1_kural": oz["kural_adi"],
             "k2_parca_eski": s2["pc"],
             "k2_bayt_eski": len(k2), "k2_bayt_yeni": len(k2_yeni)}
    return yeni, bilgi


# ------------------------------------------------------------------ TOC erisimi
def _toc_bilgi(forge, gid):
    """(toc_i, toc_pos, off, len, ext, ham_satir) — CANLI TOC'tan, ezber yok."""
    lf = LeanForge(forge)
    try:
        toc_i = None
        for i, (off, fid, ln, ext) in enumerate(lf.entries):
            if fid == gid:
                toc_i = i
                off0, ln0, ext0 = off, ln, ext
                break
        if toc_i is None:
            raise KeyError("Entry 0x{0:X} is not in the table of contents of {1}."
                           .format(gid, os.path.basename(forge)))
        lf.f.seek(0)
        hdr = lf.f.read(64)
        hoff = struct.unpack_from("<Q", hdr, 13)[0]
        lf.f.seek(hoff)
        toc_bas = struct.unpack_from("<Q", lf.f.read(12), 4)[0]
        toc_pos = toc_bas + toc_i * TOC_SATIR
        lf.f.seek(toc_pos)
        satir = lf.f.read(TOC_SATIR)
    finally:
        lf.close()
    o_, f_, l_, e_ = struct.unpack("<QQII", satir)
    if (o_, f_, l_, e_) != (off0, gid, ln0, ext0):
        raise RuntimeError("The table-of-contents row at {0} does not describe entry "
                           "0x{1:X} - refused.".format(toc_pos, gid))
    return toc_i, toc_pos, off0, ln0, ext0, satir


def _giris_oku(forge, off, ln):
    with open(forge, "rb") as f:
        f.seek(off)
        return f.read(ln)


# ------------------------------------------------------------------ YENI TOC SATIRI
YENI_SATIR = "yeni_satir"          # `yontem` degeri: TOC'a YENI bir satir eklendi
HAM = "ham"                        # `yontem` degeri: giris HAM baytlarla degisti (BMS/K1 cozumu YOK)
# Arsivi BUYUTEN yontemler: blok dosyanin SONUNA yazilir, TOC yonlendirilir. Kuyruk
# muhasebesi (taban adaylari, kirpma, "bu yamadan kalan") yalniz bunlarin ofsetlerine
# bakar; "yerinde" dosyayi buyutmez, ofseti taban degildir.
EKLI_YONTEMLER = ("ek", YENI_SATIR, HAM)

TOC_YER_YOK = (
    "There is no free room after the table of contents of this archive, so a new "
    "entry cannot be added without moving the whole table. Moving it would break "
    "the revert data of every patch that already records a row position, so it is "
    "refused here.")


def _toc_yerlesim(forge):
    """SALT OKUMA: TOC nerede ve sonunda kac bayt BOS yer var?

    Doner {boy, hoff, count, toc_bas, toc_son, bosluk, sifir, satir_yeri, uc}.
      `bosluk`     : TOC'un bittigi yer ile ONDAN SONRAKI ilk canli bayt (bir girisin
                     ofseti, yoksa dosya sonu) arasindaki mesafe.
      `sifir`      : o boslugun ilk TOC_SATIR bayti tamamen 0x00 mi (yeni satirin
                     yazilacagi yer GERCEKTEN bos mu).
      `satir_yeri` : bosluga kac tam satir sigar.

    OLCULDU (2026-09-09, salt okuma, kum havuzu kopyalari):
      DataPC_boot.forge   126.249 satir, TOC 25.637.483.878'de (dosyanin ORTASINDA),
                          TOC sonrasi 227.352 bayt sifir -> 9.473 satirlik yer.
      DataPC_WhiteRoom    495 satir, TOC sonrasi 27.969 bayt sifir -> 1.165 satir.
      topluluk patch_02   6-9 satir, TOC sonrasi 2.771-27.810 bayt sifir.
    Yani "TOC'u tasi" yoluna (TR yamasinin yaptigi) GEREK YOK; satir YERINDE eklenir
    ve baska araclarin kaydettigi satir konumlari gecerli kalir.
    """
    boy = os.path.getsize(forge)
    lf = LeanForge(forge)
    try:
        count = lf.count
        lf.f.seek(0)
        hdr = lf.f.read(64)
        hoff = struct.unpack_from("<Q", hdr, 13)[0]
        lf.f.seek(hoff)
        toc_bas = struct.unpack_from("<Q", lf.f.read(12), 4)[0]
        toc_son = toc_bas + count * TOC_SATIR
        sonraki, uc = boy, 0
        for off, _fid, ln, _ext in lf.entries:
            if off + ln > uc:
                uc = off + ln
            if toc_son <= off < sonraki:
                sonraki = off
            elif off < toc_son + TOC_SATIR and off + ln > toc_son:
                sonraki = min(sonraki, toc_son)          # giris satirin yerine tasiyor
        bosluk = max(0, sonraki - toc_son)
        sifir = False
        if bosluk >= TOC_SATIR:
            lf.f.seek(toc_son)
            sifir = (lf.f.read(TOC_SATIR) == b"\x00" * TOC_SATIR)
    finally:
        lf.close()
    return {"boy": boy, "hoff": hoff, "count": count, "toc_bas": toc_bas,
            "toc_son": toc_son, "bosluk": bosluk, "sifir": sifir,
            "satir_yeri": bosluk // TOC_SATIR, "uc": uc}


def giris_ekle_plani(forge, yeni_gid, giris):
    """SALT OKUMA: bu arsive YENI bir TOC satiri eklenebilir mi? Tek bayt yazmaz."""
    r = {"ok": False, "forge": os.path.abspath(forge), "gid": "0x%012X" % yeni_gid,
         "yontem": YENI_SATIR}
    if not os.path.isfile(forge):
        r["mesaj"] = "Game archive not found: {0}".format(forge)
        return r
    if not giris:
        r["mesaj"] = "There are no entry bytes to add."
        return r
    if len(giris) > 0xFFFFFFFF:
        r["mesaj"] = "The new entry is too large for this archive format."
        return r
    try:
        y = _toc_yerlesim(forge)
    except Exception as e:                                      # noqa: BLE001
        r["mesaj"] = "This archive could not be read ({0}).".format(e)
        return r
    r.update(y)
    lf = LeanForge(forge)
    try:
        var = yeni_gid in lf.by_id
    finally:
        lf.close()
    if var:
        r["mesaj"] = ("Entry 0x{0:X} is already in this archive - a new entry needs an id "
                      "that nothing uses yet.".format(yeni_gid))
        return r
    if y["bosluk"] < TOC_SATIR or not y["sifir"]:
        r["mesaj"] = TOC_YER_YOK
        return r
    r["ok"] = True
    r["toc_pos"] = y["toc_son"]
    r["plan_off"] = y["boy"]
    r["yeni_len"] = len(giris)
    return r


def giris_ekle(forge, yeni_gid, ext, giris, etiket="", kaynak_gid=None, icid=None):
    """Arsive YENI bir TOC satiri ekle (baytlar dosyanin sonuna, satir TOC'un sonuna).

    Mevcut hicbir girise dokunulmaz: ne baytlari, ne TOC satiri. Eklenen satirin
    yeri TOC'un HEMEN ARDINDAKI bos (sifir) alandir, yani TOC TASINMAZ ve baska
    araclarin (doku_enjekte2 / ship_yerinde / bu modul) kaydettigi satir konumlari
    gecerli kalir.

    YAZMA SIRASI (cokme guvenli): (1) baytlar dosya sonuna, (2) 24 baytlik satir,
    (3) EN SON baslik sayaci. Sayac yazilana kadar arsiv eski haliyle okunur;
    yarim kalirsa eklenen satiri hicbir okuyucu gormez.

    DURUSTLUK: yeni giris arsive girer ama OYUN ONU KULLANMAZ; kullanmasi icin ona
    isaret eden bir veri kaydi (kiyafet/silah tablosu vb.) gerekir. Bu modul o
    kayitlari yazmaz.
    """
    _k = yazma_kilidi()
    if _k:
        return {"ok": False, "mesaj": _kilit_mesaji(_k)}
    r = {"ok": False, "yontem": YENI_SATIR}
    if oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        return r
    plan = giris_ekle_plani(forge, yeni_gid, giris)
    if not plan.get("ok"):
        return plan
    forge = os.path.abspath(forge)
    fa = _forge_anahtari(forge)
    kayit = _kayit_oku()
    boy_once = plan["boy"]
    hoff, toc_pos = plan["hoff"], plan["toc_pos"]
    with open(forge, "rb") as f:
        f.seek(hoff)
        baslik_orij = f.read(12)
        f.seek(toc_pos)
        satir_orij = f.read(TOC_SATIR)
    if satir_orij != b"\x00" * TOC_SATIR:
        r["mesaj"] = TOC_YER_YOK
        return r
    kimlik = _yeni_kimlik(kayit, giris)
    g = {"id": kimlik, "zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
         "etiket": etiket or "", "durum": "yaziliyor", "arac": "kur_mesh",
         "surum": KAYIT_SURUM, "forge": forge, "forge_anahtar": fa,
         "forge_boyut_once": boy_once,
         "gid": "0x%012X" % yeni_gid, "gid_sayi": yeni_gid,
         "icid": "0x%012X" % (icid if icid is not None else yeni_gid),
         "icid_sayi": (icid if icid is not None else yeni_gid),
         "kaynak_gid": ("0x%012X" % kaynak_gid) if kaynak_gid is not None else None,
         "kaynak_gid_sayi": kaynak_gid,
         "toc_i": plan["count"], "toc_pos": toc_pos, "toc_bas": plan["toc_bas"],
         "hoff": hoff, "baslik_orij": baslik_orij.hex(),
         "eski_count": plan["count"], "yeni_count": plan["count"] + 1,
         "ext": "0x%08X" % ext, "yontem": YENI_SATIR, "onceki_id": None,
         # Eklenen satirin ESKI hali 24 sifir bayttir; geri alma tam olarak onu yazar.
         "toc_satir_orij": satir_orij.hex(),
         "yeni_giris_sha": _sha(giris), "yeni_giris_bayt": len(giris),
         "yeni_off": None, "yeni_len": len(giris),
         "plan_off": boy_once,
         "vanilla_boyut": _vanilla_taban(kayit, fa, boy_once, forge=forge),
         "ek_buyume": 0}
    kayit["girisler"].append(g)
    _kayit_yaz(kayit)                                    # WAL: ILK BAYTTAN ONCE
    try:
        with open(forge, "r+b") as f:
            f.seek(0, os.SEEK_END)
            yeni_off = f.tell()
            if yeni_off != g["plan_off"]:
                g["plan_off_gercek"] = yeni_off
                g["plan_off"] = yeni_off
                _kayit_yaz(kayit)
            f.write(giris)
            f.flush()
            os.fsync(f.fileno())
            f.seek(toc_pos)
            f.write(struct.pack("<QQII", yeni_off, yeni_gid, len(giris), ext))
            f.flush()
            os.fsync(f.fileno())
            f.seek(hoff)                                 # SAYAC EN SON
            f.write(struct.pack("<I", plan["count"] + 1))
            f.flush()
            os.fsync(f.fileno())
    except OSError as e:
        g["durum"] = "yarim"
        g["hata"] = str(e)
        _kayit_yaz(kayit)
        r["mesaj"] = "The archive could not be written ({0}) - nothing was confirmed.".format(e)
        r["kayit_id"] = kimlik
        return r
    g["yeni_off"] = yeni_off
    g["ek_buyume"] = max(0, os.path.getsize(forge) - boy_once)
    g["forge_boyut_sonra"] = os.path.getsize(forge)
    sorun = _dogrula_yeni(forge, g)
    if sorun:
        return _dogrulama_dustu(forge, kayit, g, sorun, r)
    g["durum"] = "uygulandi"
    _kayit_yaz(kayit)
    _olc = kuyruk_olc(forge, kayit)
    r.update(ok=True, kayit_id=kimlik, gid="0x%012X" % yeni_gid, gid_sayi=yeni_gid,
             yeni_off=yeni_off, yeni_len=len(giris), toc_pos=toc_pos,
             toc_i=plan["count"], count=plan["count"] + 1,
             buyume=g["ek_buyume"], forge_boyut=g["forge_boyut_sonra"], kayit=KAYIT,
             kuyruk_bayt=_olc["bayt"], kuyruk_taban=_olc["taban"],
             kuyruk_biliniyor=_olc["biliniyor"], kuyruk_kaynak=_olc["kaynak"])
    return r


def _dogrula_yeni(forge, g):
    """Yeni satir DISKTEN geri okunur, niyetle karsilastirilir. Sorun varsa metin."""
    try:
        lf = LeanForge(forge)
    except Exception as e:                                      # noqa: BLE001
        return "the archive cannot be opened again (%s)" % e
    try:
        if lf.count != g["yeni_count"]:
            return ("the entry count is %d, expected %d" % (lf.count, g["yeni_count"]))
        satir = lf.by_id.get(g["gid_sayi"])
        if satir is None:
            return "the new entry is not in the table of contents"
        if satir != (g["yeni_off"], g["yeni_len"], int(g["ext"], 16)):
            return ("the new row does not point at what we wrote (%r)" % (satir,))
        ham = lf.read_raw(g["gid_sayi"])
        if _sha(ham) != g["yeni_giris_sha"]:
            return "the entry read back from disk is not the entry we wrote"
        try:
            icler = FG.ic_dosyalar(lf, g["gid_sayi"])
        except Exception as e:                                  # noqa: BLE001
            return "the new entry cannot be decoded again (%s)" % e
        if not icler:
            return "the new entry decodes to no inner files"
        hedef = [b for c, b in icler if c == g["icid_sayi"]]
        if not hedef:
            return "the new entry does not contain inner file 0x%X" % g["icid_sayi"]
        # KIMLIK IKI YERDE DURUR: K1 kaydinda (yukarida) ve ic dosyanin
        # SARMALAYICISINDA (nid). Ikisi ayrisirsa giris kendi adina degil eski
        # varligin adina yazilmis olur; disk uzerinden ikisi de dogrulanir.
        # (Bu kapi olmadan sabotaj testi GECIYORDU -- kapi E9.)
        try:
            w = FG.sarmalayici_coz(hedef[0])
        except Exception:                                       # noqa: BLE001
            w = None                                            # ham varlik: sarmalayici yok
        if w is not None and w["nid"] != g["icid_sayi"]:
            return ("the inner file still carries id 0x%X, not 0x%X"
                    % (w["nid"], g["icid_sayi"]))
    finally:
        lf.close()
    return None


# ------------------------------------------------------------------ catisma
def _doku_kaydi(forge):
    """doku_enjekte2'nin AYNI arsive ait kaydi (varsa). SALT OKUMA."""
    yol = os.path.join(DOKU_KOK, _forge_anahtari(forge), DOKU_KAYIT_ADI)
    if not os.path.isfile(yol):
        return None, yol
    return _json_oku(yol, bos={}), yol


def _catisma(forge, gid):
    """Bu TOC girisi doku yolunun (doku_enjekte2) elinde mi?

    Ayni girise iki arac birden yazarsa geri alma birbirinin baytlarini ezer:
    doku'nun 'vanilla off/len'i bizim yazdigimiz blogu gosterir hale gelir.
    """
    k, yol = _doku_kaydi(forge)
    if not k:
        return None
    anahtar = "0x%X" % gid
    for g in (k.get("gomulu") or []):
        if str(g.get("mat", "")).upper() == anahtar.upper():
            return ("This archive entry is already patched by the texture tool "
                    "(Outfit/Ship textures). Revert that patch first: {0}").format(yol)
    return None


# ------------------------------------------------------------------ plan (salt okuma)
def _plan_kayit_bakisi(r, forge, gid, ham_sha):
    """Plan icin kayit deposuna ON-BAKIS (salt okuma): mevcut yama / bayat / catisma + kuyruk.

    `kur`/`kur_ham` ile AYNI olcum, ama tek bayt yazmadan. Eski surumde plan "ok" der,
    uygula "backup ... damaged" derdi; ikisi artik ayni seyi soyluyor (olculdu:
    scratchpad/kusur/d5_bayat_yedek.py adim 5 ve 6). `r`yi yerinde doldurur ve dondurur;
    catismada `ok` False olur.
    """
    kayit = _kayit_oku()
    fa = _forge_anahtari(forge)
    v = _aktif_giris(forge, gid, kayit)
    r["mevcut_yama"] = (v or {}).get("id")
    if v and not _kayit_arsivle_tutuyor_mu(v, ham_sha):
        r["bayat"] = True
        r["uyari"] = BAYAT_MESAJ
    elif not v:
        yedek = os.path.join(YEDEK_KOK, fa, "%012X.giris" % gid)
        yd, ayrinti = _yedek_durumu(kayit, fa, gid, yedek, ham_sha)
        if yd == "catisma":
            r["ok"] = False
            r["mesaj"] = CATISMA_MESAJ.format(ayrinti)
            r["catisan_kayit"] = ayrinti
        elif yd == "bayat":
            r["bayat"] = True
            r["uyari"] = BAYAT_MESAJ
    _olc = kuyruk_olc(forge, kayit)
    r["kuyruk_bayt"] = _olc["bayt"]              # None = BILINMIYOR, "temiz" DEGIL
    r["kuyruk_biliniyor"] = _olc["biliniyor"]
    r["kuyruk_taban"] = _olc["taban"]
    r["kuyruk_kaynak"] = _olc["kaynak"]
    r["kuyruk_sebep"] = _olc["sebep"]
    return r


def kur_plani(forge, gid, icid, yeni_ic, yontem="ek", yonlendir=None):
    """SALT OKUMA: kurulum mumkun mu, ne yazilacak? Forge'a tek bayt yazmaz.
    `yonlendir` (bkz. GOLGE_YONLENDIR): hedef, kimligi iceren en yuksek yama halkasina cozulur."""
    r = {"ok": False, "forge": os.path.abspath(forge), "gid": "0x%012X" % gid,
         "icid": "0x%012X" % icid, "yontem": yontem}
    forge = _hedef_coz(forge, gid, yonlendir, r)
    if not os.path.isfile(forge):
        r["mesaj"] = "Game archive not found: {0}".format(forge)
        return r
    if yontem not in ("ek", "yerinde"):
        r["mesaj"] = "Unknown install method (use 'append' or 'in place')."
        return r
    try:
        toc_i, toc_pos, off0, ln0, ext0, satir = _toc_bilgi(forge, gid)
    except (KeyError, RuntimeError) as e:
        r["mesaj"] = str(e)
        return r
    raw = _giris_oku(forge, off0, ln0)
    try:
        yeni, bilgi = giris_kur(raw, icid, yeni_ic)
    except (ValueError, KeyError, RuntimeError) as e:
        r["mesaj"] = str(e)
        return r
    cat = _catisma(forge, gid)
    if cat:
        r["mesaj"] = cat
        return r
    boy = os.path.getsize(forge)
    r.update(ok=True, toc_i=toc_i, toc_pos=toc_pos, orij_off=off0, orij_len=ln0,
             ext="0x%08X" % ext0, mesh_mi=(ext0 == MESH_TIPI),
             yeni_len=len(yeni), sigar_mi=len(yeni) <= ln0,
             forge_boyut=boy, buyume=(0 if (yontem == "yerinde" and len(yeni) <= ln0)
                                      else len(yeni)),
             orij_giris_sha=_sha(raw), yeni_giris_sha=_sha(yeni), **bilgi)
    if yontem == "yerinde" and len(yeni) > ln0:
        r["ok"] = False
        r["mesaj"] = ("The edited mesh no longer fits its original slot "
                      "({0} B needed, {1} B available) - use the append method."
                      ).format(len(yeni), ln0)
    # zaten kayitli bir yama var mi? + BAYAT / CATISMA on-bakisi (kur_ham_plani ile ORTAK)
    return _plan_kayit_bakisi(r, forge, gid, r["orij_giris_sha"])


def _yeni_kimlik(kayit, yeni):
    """Kayit kimligi — DEPODA BENZERSIZ olmak ZORUNDA.

    Ilk surum `zaman + icerik sha`si kullaniyordu: ayni saniyede AYNI baytlarla
    yapilan ikinci kurulum (kullanicinin ayni tasarimi iki kez uygulamasi ya da
    nicemleme tavani iki farkli olcegi ayni sonuca kirptigi icin) BIREBIR AYNI
    kimligi uretiyordu. `geri_al` o kimlikte ILK girisi buluyor -- o da ustune
    yazilmis olan -- ve "bu yama etkin degil" deyip reddediyordu: CANLI yama
    kayittan erisilemez hale geliyor, arsivi geri almanin API yolu kalmiyordu
    (olculdu: kanit B). Artik kimlik bir sayacla benzersizlestirilir."""
    var = {g.get("id") for g in kayit.get("girisler", [])}
    taban = "%s_%s" % (time.strftime("%Y%m%d_%H%M%S"), _sha(yeni)[:6])
    if taban not in var:
        return taban
    i = 2
    while "%s_%d" % (taban, i) in var:
        i += 1
    return "%s_%d" % (taban, i)


def _aktif_giris(forge, gid, kayit=None):
    k = kayit or _kayit_oku()
    fa = _forge_anahtari(forge)
    for g in k["girisler"]:
        if (g.get("forge_anahtar") == fa and int(g.get("gid_sayi", -1)) == gid
                and g.get("durum") in ("uygulandi", "yaziliyor", "yarim")):
            return g
    return None


# ------------------------------------------------------------------ BAYAT KAYIT
# "bayat" = kaydin anlattigi arsiv artik ORTADA YOK. Oyun guncellendi ya da Steam
# "dosyalari dogrula" dedi; forge yeniden yazildi. Kaydin `orij_*` alanlari ve yedek
# dosyasi eski oyun surumune ait; onlarla geri almak arsive ESKI SURUMUN baytlarini
# yazmak olurdu. OLCULDU (scratchpad\kusur\d5_bayat_yedek.py): eski surumde bu durum
# `kur()`u KALICI olarak kilitliyordu -- plan "ok" der, uygula "backup ... damaged"
# deyip reddederdi ve cikis yolu yoktu.
#
# GUVENLIK KAPISI: "vanilla degilse yine de yaz" YAPILMAZ. Yalniz BAYAT durum ayiklanir;
# GERCEK catisma (baska aracin ya da bizim CANLI yamamiz) reddedilmeye devam eder.
BAYAT_MESAJ = (
    "The stored backup for this mesh no longer matches the game archive, so the old "
    "patch records were marked out of date. This normally means the game was updated "
    "or its files were verified after the patch was installed. The current archive "
    "bytes have been backed up again and this install can go ahead, but the old "
    "records can no longer be reverted.")

CATISMA_MESAJ = (
    "The archive entry still contains a patch this tool wrote ({0}), even though the "
    "record says it was reverted. The record and the archive disagree, so the original "
    "bytes cannot be identified and nothing was written. Revert that patch properly, or "
    "verify the game files in Steam, and try again.")

YEDEK_BOZUK_MESAJ = (
    "The stored backup of the original bytes for this mesh is missing or damaged while "
    "a patch from this tool is still installed, so the archive can no longer be brought "
    "back safely. Verify the game files in Steam to restore the archive, then install "
    "again.")


def _kayit_arsivle_tutuyor_mu(onceki, ham_sha):
    """ETKIN kayit, arsivde SU AN duran girisi hala anlatiyor mu?

    Etkin bir yamamiz varsa TOC'un gosterdigi baytlar BIZIM yazdigimiz blok olmalidir.
    Degilse arsiv altimizdan degismistir (oyun guncellemesi / Steam dogrulamasi) ve
    kaydin sakladigi "orijinal" baytlar baska bir surume aittir.

    Ayri fonksiyon cunku testler bunu ESKI (kontrolsuz) haline dondurup kapinin
    gercekten ayirt edici oldugunu olcuyor."""
    return bool(onceki) and onceki.get("yeni_giris_sha") == ham_sha


def _kayit_gecmisi(kayit, fa, gid):
    """Bu arsiv + bu TOC girisi icin BUTUN kayitlar (durum farketmez)."""
    return [g for g in kayit.get("girisler", [])
            if g.get("forge_anahtar") == fa and int(g.get("gid_sayi", -1)) == gid]


def _yedek_durumu(kayit, fa, gid, yedek, ham_sha):
    """Yedek dosyasi arsivdeki GIRISLE tutuyor mu? Doner (durum, ayrinti).

    "yok"     : yedek dosyasi yok (ilk kurulum) -> tazeden yazilir.
    "taze"    : yedek arsivdeki girisin ta kendisi -> dokunulmaz.
    "catisma" : arsivdeki giris BIZIM yazdigimiz bir yamanin ta kendisi; kayit
                "etkin degil" diyor ama baytlar CANLI. Yedegi tazelemek o yamayi
                "orijinal" diye dondururdu -> REDDEDILIR.
    "bayat"   : yedek ne arsivle ne de bizim herhangi bir yamamizla tutuyor ->
                oyun degismis; kayit gecersiz, yedek tazelenebilir.
    """
    if not os.path.isfile(yedek):
        return "yok", None
    if dosya_sha(yedek) == ham_sha:
        return "taze", None
    for g in _kayit_gecmisi(kayit, fa, gid):
        if g.get("durum") == "bayat":
            continue
        if g.get("yeni_giris_sha") == ham_sha:
            return "catisma", g.get("id")
    return "bayat", None


def _bayat_isaretle(kayit, fa, gid, sebep):
    """Bu arsiv + giris icin butun kayitlari "bayat" yap. Doner: isaretlenen id'ler.

    Bayat kayitlar `_aktif_giris`, `geri_al_hepsi`, `_kuyruk_geri_kazan` ve
    `_vanilla_taban` tarafindan GORMEZDEN gelinir: hicbiri artik arsivi anlatmiyor,
    ozellikle `yeni_off`lari baska bir dosya duzenine ait -- oradan kirpmak yikici olur.
    """
    ids = []
    simdi = time.strftime("%Y-%m-%d %H:%M:%S")
    for g in _kayit_gecmisi(kayit, fa, gid):
        if g.get("durum") == "bayat":
            continue
        g["bayat_onceki_durum"] = g.get("durum")
        g["durum"] = "bayat"
        g["bayat_sebep"] = sebep
        g["bayat_zamani"] = simdi
        ids.append(g.get("id"))
    return ids


# ------------------------------------------------------------------ kuyruk olcumu
#
# 2026-09-07 KAPANAN KUSUR — "ARSIV VANILLA" YALANI (kapilar 11..15)
# ------------------------------------------------------------------------------
# OLCULDU (gercek makine, salt okuma, scratchpad\e1_yalan_kuyruk.py):
#     DataPC_boot.forge = 25.642.659.481 B
#     kuyruk_bayt()     = 0                      <- "arsivde bizden hicbir sey kalmamis"
#     CANLI TOC ise su 4 ETKIN kaydimizi BIREBIR gosteriyordu:
#         off=25.641.569.500 len=85.193
#         off=25.641.654.693 len=755.859
#         off=25.642.410.552 len=80.766
#         off=25.642.491.318 len=168.163   -> 25.642.659.481 = DOSYA SONU
#     yani dosyanin son 1.089.981 bayti BIZIM CANLI bloklarimizdi.
# KOK NEDEN: taban yalniz `vanilla_boyut` ALANI TASIYAN kayitlardan min() ile
#     turetiliyordu. Bu depodaki 26 kaydin 20'sinde o alan YOK (araci alan eklenmeden
#     onceki surumden beri kullanan herkeste ayni durum). Geriye kalan 6 kaydin alani
#     25.642.659.481 -- yani dosyanin BUGUNKU sonu. Taban oraya kayinca fark 0 cikti.
#     Alan tasimayan 20 kaydin `forge_boyut_once` degerlerinin min()'i 25.641.569.500,
#     yani GERCEK taban, kayitta ZATEN duruyordu; yalnizca okunmuyordu.
# NEDEN CIDDI: v0.13'te tam bu sinif hata yandi ("geri alindi" denip dosya buyuyordu).
#     `mod_kayit`in kaldirma raporu da bu sayiyi kullaniyor: 0 gorunce "Nothing this
#     tool added is left in it." yaziyor.
# DUZELTME: taban artik EKSIK ALANDAN turetilmiyor. Uc kaynak ayri ayri toplanir
#     (alan / gozlem / canli TOC), alan yoksa GOZLEM kullanilir, hicbiri yoksa
#     "bilinmiyor" (None) donulur -- 0 DENMEZ. Bkz. `_taban_adaylari`.


def _toc_haritasi(forge):
    """CANLI TOC -> {giris_kimligi: (ofset, uzunluk)} + TOC'un gosterdigi en uc bayt.

    Diskten okur, kayittan DEGIL (hafiza kurali: konum icin daima canli TOC, ezber
    deger degil). Olculdu: 25 GB'lik DataPC_boot.forge'un 126.249 girisi 0,04 sn'de
    okunuyor, yani olcum yolunda tutulabilecek kadar ucuz.

    Arsiv okunamazsa (None, 0) doner: taban olcumu kayit kaynagina duser, hata vermez.
    """
    try:
        lf = LeanForge(forge)
    except Exception:                                           # noqa: BLE001
        return None, 0
    try:
        harita, uc = {}, 0
        for off, fid, ln, _ext in lf.entries:
            harita[fid] = (off, ln)
            if off + ln > uc:
                uc = off + ln
        return harita, uc
    except Exception:                                           # noqa: BLE001
        return None, 0
    finally:
        lf.close()


def _taban_adaylari(kayit, fa, forge=None):
    """Bu arsiv icin "BIZ ilk yazmadan once dosya kac bayttiydi" ADAYLARI.

    Doner: {"alan": [...], "gozlem": [...], "canli": [...]} — hepsi bayt sayisi.

      "alan"   : kaydin ACIKCA tasidigi `vanilla_boyut`. Yalniz YENI kayitlarda var.
      "gozlem" : yazmadan HEMEN ONCE OLCULMUS dosya boyu (`forge_boyut_once`), ya da
                 "ek" yonteminde blogun yazildigi ofset (`yeni_off` / `plan_off`).
                 Ikisi de "o an dosya bu kadardi"nin DOGRUDAN olcumudur: bir blogu
                 dosyanin sonuna X ofsetine yazdiysak, dosya o an X bayttiydi.
      "canli"  : "gozlem"in DISKTEN DOGRULANMIS alt kumesi -- CANLI TOC satiri hala
                 tam olarak bizim blogumuzu (ayni ofset, ayni uzunluk) gosteriyorsa.
                 En guclu kanit budur; `kaynak` alaninda kullaniciya da soylenir.

    Eski kayitlari yok saymak tabani dosyanin BUGUNKU sonuna kaydirir ve `kuyruk_bayt`
    sahte 0 dondurur (yukaridaki olcum). Bu yuzden "alan" YOKSA "gozlem" kullanilir.

    Bayat kayitlar disarida: onlarin duzeni baska bir oyun surumune ait.
    """
    alan, gozlem, canli = [], [], []
    gir = [g for g in kayit.get("girisler", [])
           if g.get("forge_anahtar") == fa and g.get("durum") != "bayat"]
    if not gir:
        return {"alan": alan, "gozlem": gozlem, "canli": canli}
    harita = None
    if forge and os.path.isfile(forge):
        harita = _toc_haritasi(forge)[0]
    for g in gir:
        if g.get("vanilla_boyut") is not None:
            alan.append(int(g["vanilla_boyut"]))
        if g.get("forge_boyut_once") is not None:
            gozlem.append(int(g["forge_boyut_once"]))
        if g.get("yontem") not in EKLI_YONTEMLER:
            continue                       # "yerinde" dosyayi buyutmez: ofset taban degil
        off = g.get("yeni_off")
        off = g.get("plan_off") if off is None else off
        if off is None:
            continue
        gozlem.append(int(off))
        if harita is None:
            continue
        satir = harita.get(int(g.get("gid_sayi", -1)))
        if satir == (int(off), int(g.get("yeni_len") or -1)):
            canli.append(int(off))         # disk BIZI gosteriyor: taban <= bu ofset
    return {"alan": alan, "gozlem": gozlem, "canli": canli}


def _vanilla_taban(kayit, fa, varsayilan=None, forge=None):
    """RAPOR TABANI: adaylarin EN DUSUGU, ya da bilinmiyorsa `varsayilan`.

    NEDEN EN DUSUK: taban ne kadar dusukse `kuyruk_bayt` o kadar BUYUK cikar. Yon
    bilinclidir -- bu sayi "arsiv temiz mi" sorusunu yanitliyor ve yanilacaksa
    FAZLALIGI ABARTARAK yanilmali, asla "temiz" diye yanilmamali.

    `kur()` bu degeri yeni kaydin `vanilla_boyut` alanina yazar: alan tasimayan eski
    kayitlardan turetilen dogru taban boylece kayda GECER ve depo kendi kendini onarir.
    """
    a = _taban_adaylari(kayit, fa, forge)
    hepsi = a["alan"] + a["gozlem"] + a["canli"]
    return min(hepsi) if hepsi else varsayilan


def _kirpma_zemini(kayit, fa):
    """KIRPMA ZEMINI: adaylarin EN YUKSEGI (kaynak basina min, sonra aralarinda max).

    Bu, `_vanilla_taban`in TERS yonu ve bilerek oyle. Iki soru ayridir:
      * rapor  ("arsiv kac bayt buyuk?")   -> yanilirsa FAZLA soylemeli  -> en dusuk taban
      * kirpma ("nereye kadar kesebilirim?") -> yanilirsa AZ kesmeli     -> en yuksek taban
    Zemin cok DUSUK olursa temiz arsivin sonundaki, TOC'un gostermedigi veriyi keseriz
    (olculdu: WhiteRoom 29.917.184 B ama canli TOC 29.877.335 B -> 39.849 B kuyruk verisi).
    Zemin cok YUKSEK olursa yalnizca kirpmayi reddederiz: dosya buyuk kalir ama SAGLAM,
    ve `kuyruk_bayt` bunu zaten dogru sayiyla soyler.
    """
    a = _taban_adaylari(kayit, fa)
    kok = [min(v) for v in (a["alan"], a["gozlem"], a["canli"]) if v]
    return max(kok) if kok else None


# --- DONUS SEMASI (cagiranlar icin) -------------------------------------------
# kuyruk_bayt(forge) -> int | None
#     int  : OLCULDU. Arsiv, bu arac ilk kez yazmadan onceki boyutunun tam bu kadar
#            bayt USTUNDE. 0 = bu aractan geriye hicbir sey kalmamis (TEMIZ).
#     None : BILINMIYOR. "Temiz" DEMEK DEGILDIR. Arsiv buyumus de olabilir.
#            `if kuyruk_bayt(f) == 0:` yaz -- `if not kuyruk_bayt(f):` YAZMA.
#     Nedenini ve kullaniciya basilacak cumleyi isteyen `kuyruk_olc()` cagirsin.
KUYRUK_SEBEP = {
    "arsiv_yok":  "The game archive was not found, so its size could not be measured.",
    "kayit_yok":  "This tool has no record of ever writing to this archive, so there is "
                  "nothing it can measure.",
    "taban_yok":  "The records for this archive do not say how big it was before this "
                  "tool first wrote to it, so the extra bytes cannot be counted. Reverting "
                  "every patch and installing once more will record it.",
    "arsiv_kuculdu": "The archive is smaller than it was before this tool first wrote to "
                     "it, so the game files were replaced (an update, or Steam verifying "
                     "them). The old records no longer describe this file.",
}


def kuyruk_olc(forge, kayit=None):
    """`kuyruk_bayt`in AYRINTILI hali: sayiyi, tabani, KAYNAGINI ve sebebini verir.

    Doner:
      {"bayt": int|None,      # None = BILINMIYOR (temiz DEGIL)
       "biliniyor": bool,     # False ise "bayt" yok, "sebep" ve "mesaj" doludur
       "taban": int|None, "boyut": int|None,
       "kaynak": "canli_toc" | "kayit" | "yok",
       "sebep": str|None,     # KUYRUK_SEBEP anahtari
       "mesaj": str}          # kullaniciya oldugu gibi basilabilir INGILIZCE cumle
    """
    o = {"bayt": None, "biliniyor": False, "taban": None, "boyut": None,
         "kaynak": "yok", "sebep": None, "mesaj": ""}
    if not forge or not os.path.isfile(forge):
        o["sebep"] = "arsiv_yok"
        o["mesaj"] = KUYRUK_SEBEP["arsiv_yok"]
        return o
    kayit = kayit if kayit is not None else _kayit_oku()
    fa = _forge_anahtari(forge)
    boy = os.path.getsize(forge)
    o["boyut"] = boy
    a = _taban_adaylari(kayit, fa, forge)
    hepsi = a["alan"] + a["gozlem"] + a["canli"]
    if not hepsi:
        # Hic kayit mi yok, yoksa kayit var ama taban tasimiyor mu? Ikisi kullaniciya
        # FARKLI is verir: birincisinde yapacak bir sey yok, ikincisinde onarilabilir.
        var = any(g.get("forge_anahtar") == fa and g.get("durum") != "bayat"
                  for g in kayit.get("girisler", []))
        o["sebep"] = "taban_yok" if var else "kayit_yok"
        o["mesaj"] = KUYRUK_SEBEP[o["sebep"]]
        return o
    taban = min(hepsi)
    o["taban"] = taban
    o["kaynak"] = "canli_toc" if (a["canli"] and min(a["canli"]) == taban) else "kayit"
    if taban > boy:
        # Arsiv, tabanimizin ALTINA inmis: dosya bizim bildigimiz dosya degil.
        # `max(0, ...)` burada 0 dondururdu -- yani tam da soylememiz gereken seyi
        # gizleyip "temiz" derdi. Onun yerine BILINMIYOR deriz.
        o["sebep"] = "arsiv_kuculdu"
        o["mesaj"] = KUYRUK_SEBEP["arsiv_kuculdu"]
        return o
    o["bayt"] = boy - taban
    o["biliniyor"] = True
    o["mesaj"] = (
        "Nothing this tool added is left in %s." % os.path.basename(forge)
        if o["bayt"] == 0 else
        "%s is %d bytes larger than it was before this tool first wrote to it."
        % (os.path.basename(forge), o["bayt"]))
    return o


def kuyruk_bayt(forge, kayit=None):
    """Arsivin sonunda BIZDEN kalan fazlalik (bayt). None = BILINMIYOR, "temiz" DEGIL.

    Health Check ve "Revert all" bunu basar: 0 degilse arsiv hala buyumustur ve
    kullaniciya bunun SOYLENMESI gerekir. Sebebi/cumleyi isteyen `kuyruk_olc()`
    cagirsin -- imza ve donus TIPI bilerek degismedi (mod_kayit.py, toplu.py,
    explorer_core.py ve sunucu.py bunu cagiriyor)."""
    return kuyruk_olc(forge, kayit)["bayt"]


# ------------------------------------------------------------------ ORTAK KURULUM HALKALARI
# `kur` (BMS kap: ic dosya degisir) ve `kur_ham` (giris HAM baytlarla degisir) AYNI zinciri
# yurur: kilit + oyun kapisi -> bayat/catisma ayiklamasi -> yedek -> WAL kaydi -> yazma ->
# diskten geri okuma -> "uygulandi". Iki yol yalniz (a) yeni giris baytlarinin NASIL
# uretildigi (giris_kur / oldugu gibi) ve (b) geri okumada ic dosyanin da cozulup
# cozulmedigi ile ayrilir. Halkalar burada TEK kopya durur (kural 9: oyun dosyasina yazan
# her yol tek fonksiyondan gecsin); `kur`un yazdigi baytlar ve kaydi bu ayrimdan ONCE
# neyse odur (kapilar: test_kur_mesh*, test_k1_yerler_yazici, test_restore_all_kum).
def _yazma_kapisi(r):
    """Kilit + oyun-acik kapisi. RED ise donecek sozluk (tek bayt yazilmadan), yoksa None."""
    _k = yazma_kilidi()
    if _k:
        return {"ok": False, "mesaj": _kilit_mesaji(_k)}
    if oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        return r
    return None


def _onceki_ayikla(kayit, forge, fa, gid, ham_sha, ustune, r, ne="mesh"):
    """ETKIN kaydi bul; arsivle tutmuyorsa BAYAT isaretle; tutuyorsa ve `ustune` degilse RED.

    Doner (onceki, bayat_ids, red). red True ise `r` mesaji tasir, hicbir sey yazilmamistir.
    BAYAT ayiklamasi "zaten yamali" REDDINDEN ONCE: etkin bir yamamiz varsa arsivdeki giris
    BIZIM yazdigimiz blok OLMALI. Degilse oyun guncellendi/dogrulandi: kaydin `orij_*`
    alanlari ve yedegi eski surume ait. Bu ayiklama once yapilmazsa kullanici kilitlenir:
    `kur` "revert it first" der, `geri_al` de "the archive changed - refused" der ve cikis
    yolu kalmaz (olculdu: scratchpad/kusur/d5_bayat_yedek.py).
    """
    onceki = _aktif_giris(forge, gid, kayit)
    bayat_ids = []
    if onceki and not _kayit_arsivle_tutuyor_mu(onceki, ham_sha):
        bayat_ids = _bayat_isaretle(kayit, fa, gid,
                                    "the archive entry no longer matches this record")
        onceki = None
    if onceki and not ustune:
        r["mesaj"] = ("This {0} already carries a patch ({1}). Revert it first, or "
                      "install over it on purpose.").format(ne, onceki["id"])
        r["mevcut_yama"] = onceki["id"]
        return onceki, bayat_ids, True
    return onceki, bayat_ids, False


def _yedek_hazirla(kayit, forge, fa, gid, onceki, bayat_ids, off0, ln0, satir, raw, ham_sha,
                   orij_ic_sha, orij_ic_bayt, r):
    """KURAL 4: ustune yazilacak girisin orijinali YEDEKTE durmadan tek bayt yazilmaz.

    Doner (van, zincir); van None ise `r` RED mesajini tasir. `van` = yeni kaydin vanilla
    alanlari: ustune yaziyorsak ILK kaydinkiler devralinir (doku_enjekte2 dersi: o anki
    -yamali- off/len'i "orijinal" diye kaydetmek geri almayi vanilla'ya degil onceki
    tasarima dondururdu), degilse simdi yedeklenen girisinkiler. `bayat_ids` YERINDE buyur.
    """
    # (2026-09-18, palet_tipi) onceki bir YENI SATIR kaydiysa (giris_ekle: girisin vanilla'si YOK)
    # devralinacak orij_* alani yoktur (olculdu: KeyError 'orij_off'). Zincirin tabani o kaydin
    # yazdigi giristir: su an arsivde duran baytlar yedeklenir, kayit `zincir_taban=yeni_satir`
    # tasir ve geri alma tam o hale doner (geri_al onceki kaydi yeniden ETKIN yapar).
    taban_yeni = bool(onceki) and onceki.get("yontem") == YENI_SATIR
    if onceki and not taban_yeni:
        van = {k_: onceki[k_] for k_ in ("orij_off", "orij_len", "orij_giris_sha",
                                         "orij_ic_sha", "orij_ic_bayt",
                                         "toc_satir_orij", "yedek", "yedek_sha")}
        if onceki.get("zincir_taban"):                    # taban bilgisi zincir boyunca tasinir
            van["zincir_taban"] = onceki["zincir_taban"]
        # Bu kapi GEVSETILMEDI: etkin bir yama dururken yedek bozuksa arsivi geri
        # getirmenin yolu kalmamistir; kor yazmak durumu kotulestirir.
        if dosya_sha(van["yedek"]) != van["orij_giris_sha"]:
            r["mesaj"] = YEDEK_BOZUK_MESAJ
            return None, None
        return van, onceki["id"]
    os.makedirs(os.path.join(YEDEK_KOK, fa), exist_ok=True)
    yedek = os.path.join(YEDEK_KOK, fa, "%012X.giris" % gid)
    yd, ayrinti = (("taban_yeni", None) if taban_yeni
                   else _yedek_durumu(kayit, fa, gid, yedek, ham_sha))
    if taban_yeni and os.path.isfile(yedek) and dosya_sha(yedek) != ham_sha:
        # ayni gid'li ESKI bir yeni-satir zincirinin tabani: bayat, sakla ve tazele
        os.replace(yedek, yedek + ".bayat")
    if yd == "catisma":
        # GERCEK catisma: baytlar canli, kayit yalan soyluyor. Yedegi tazelemek
        # yamali bir girisi "orijinal" diye dondururdu -> reddet.
        r["mesaj"] = CATISMA_MESAJ.format(ayrinti)
        r["catisan_kayit"] = ayrinti
        return None, None
    if yd == "bayat":
        # Kullanicinin hatasi degil: oyun degismis. Kaydi gecersiz isaretle,
        # eski yedegi `.bayat` diye SAKLA (silme -- adli inceleme icin durur),
        # sonra tazesini yaz. Sira WAL: once kayit, sonra dosya.
        bayat_ids += _bayat_isaretle(kayit, fa, gid,
                                     "the backup no longer matches the archive entry")
        _kayit_yaz(kayit)
        try:
            os.replace(yedek, yedek + ".bayat")
        except OSError:
            pass
    if not os.path.isfile(yedek):                    # KURAL 4: once yedek
        gec = yedek + ".tmp"
        with open(gec, "wb") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        os.replace(gec, yedek)
    van = {"orij_off": off0, "orij_len": ln0, "orij_giris_sha": ham_sha,
           "orij_ic_sha": orij_ic_sha, "orij_ic_bayt": orij_ic_bayt,
           "toc_satir_orij": satir.hex(), "yedek": yedek,
           "yedek_sha": dosya_sha(yedek)}
    if van["yedek_sha"] != ham_sha:
        r["mesaj"] = "The backup of the original entry could not be written - refused."
        return None, None
    if taban_yeni:
        van["zincir_taban"] = "yeni_satir"
        return van, onceki["id"]
    return van, None


def _kayit_girisi(kayit, forge, fa, gid, icid, toc_i, toc_pos, ext0, yontem, zincir, yeni,
                  yeni_ic_sha, yeni_ic_bayt, plan_off, boy_once, etiket, van, bayat_ids,
                  onceki):
    """WAL kaydi: giris sozlugu kurulur, defter ILK BAYTTAN ONCE diske fsync'lenir.

    `icid` None = ic dosya yok (ham yol). Doner giris (kayit["girisler"]in son elemani;
    `id` alani kimliktir).
    """
    kimlik = _yeni_kimlik(kayit, yeni)
    giris = {"id": kimlik, "zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
             "etiket": etiket or "", "durum": "yaziliyor", "arac": "kur_mesh",
             "surum": KAYIT_SURUM, "forge": forge, "forge_anahtar": fa,
             "forge_boyut_once": boy_once,
             "gid": "0x%012X" % gid, "gid_sayi": gid,
             "icid": ("0x%012X" % icid) if icid is not None else None, "icid_sayi": icid,
             "toc_i": toc_i, "toc_pos": toc_pos, "ext": "0x%08X" % ext0,
             "yontem": yontem, "onceki_id": zincir,
             "yeni_giris_sha": _sha(yeni), "yeni_giris_bayt": len(yeni),
             "yeni_ic_sha": yeni_ic_sha, "yeni_ic_bayt": yeni_ic_bayt,
             "yeni_off": None, "yeni_len": len(yeni),
             # NIYET EDILEN konum, TEK BAYT YAZILMADAN ONCE kayda gecer. Eski surumde
             # yalnizca `yeni_off` vardi ve o da yazmadan SONRA doluyordu: yazma ile
             # kaydin tamamlanmasi arasinda cokme olursa `yeni_off` None kaliyor,
             # `_kuyruk_geri_kazan` blogu taniyamiyor ve geri alma "basarili" derken
             # arsivde OKSUZ blok birakiyordu (olculdu: 215.960 B, kirpilan=0, ok=True).
             "plan_off": plan_off,
             # KUYRUK TABANI: bu arsive ILK yazisimizdan onceki boyut. Kayitta durur
             # cunku diskten TURETILEMEZ -- temiz bir forge'un sonunda da TOC'un
             # gostermedigi kuyruk verisi vardir (olculdu: WhiteRoom'da 39.849 B).
             # Bu alan olmadan "arsiv vanilla boyuta dondu mu" sorusu YANITLANAMAZ.
             # ALANI OLMAYAN ESKI KAYITLAR: `_vanilla_taban` artik onlarin
             # `forge_boyut_once`/`plan_off` gozlemlerinden de turetiyor, yani dogru
             # taban BURADA kayda gecer ve depo kendi kendini onarir (alan tasimayan
             # 20 kayitlik gercek depoda olculdu).
             "vanilla_boyut": _vanilla_taban(kayit, fa, boy_once, forge=forge),
             "ek_buyume": 0}
    giris.update(van)
    if bayat_ids:
        giris["bayat_devraldi"] = bayat_ids
    if onceki:
        onceki["durum"] = "ustune_yazildi"
        onceki["ustune_yazan"] = kimlik
    kayit["girisler"].append(giris)
    _kayit_yaz(kayit)                                    # WAL: ILK BAYTTAN ONCE
    return giris


def _giris_yaz(forge, kayit, giris, yeni, toc_pos, yontem, off0, r):
    """Giris baytlari (yerinde: orijinal yuvaya / digerleri: dosyanin SONUNA), sonra TOC
    satiri EN SON. Doner yeni_off; OSError'da kaydi "yarim" isaretler, `r`yi doldurur,
    None doner."""
    try:
        with open(forge, "r+b") as f:
            if yontem == "yerinde":
                yeni_off = off0
                f.seek(off0)
                f.write(yeni)
            else:
                f.seek(0, os.SEEK_END)
                yeni_off = f.tell()
                if yeni_off != giris["plan_off"]:
                    # Kayit ile disk ayristi: kayittan sonra baskasi dosyaya ekleme yapti.
                    # Kaydi DUZELT (yoksa geri alma yanlis yeri kirpar).
                    giris["plan_off_gercek"] = yeni_off
                    giris["plan_off"] = yeni_off
                    _kayit_yaz(kayit)
                f.write(yeni)
            f.flush()
            os.fsync(f.fileno())
            # TOC satiri EN SON: bu ana kadar arsiv hala ESKI girisi gosterir.
            f.seek(toc_pos)
            f.write(struct.pack("<Q", yeni_off))
            f.seek(toc_pos + 16)
            f.write(struct.pack("<I", len(yeni)))
            f.flush()
            os.fsync(f.fileno())
    except OSError as e:
        giris["durum"] = "yarim"
        giris["hata"] = str(e)
        _kayit_yaz(kayit)
        r["mesaj"] = "The archive could not be written ({0}) - nothing was confirmed.".format(e)
        r["kayit_id"] = giris["id"]
        return None
    giris["yeni_off"] = yeni_off
    giris["ek_buyume"] = max(0, os.path.getsize(forge) - giris["forge_boyut_once"])
    giris["forge_boyut_sonra"] = os.path.getsize(forge)
    return yeni_off


def _dogrulama_dustu(forge, kayit, giris, sorun, r):
    """Diskten geri okuma niyetle TUTMADI: kayit "yarim", otomatik geri alma denenir."""
    giris["durum"] = "yarim"
    giris["dogrulama"] = sorun
    _kayit_yaz(kayit)
    gr = geri_al(giris["id"], _zorla_yarim=True)
    r["mesaj"] = ("Write verification failed ({0}). {1}").format(
        sorun, "The archive was rolled back." if gr.get("ok")
        else "AUTOMATIC ROLLBACK FAILED: {0}".format(gr.get("mesaj")))
    r["kayit_id"] = giris["id"]
    r["geri_alma"] = gr
    return r


def _kurulum_bitir(forge, kayit, giris, r, off0, ln0, bayat_ids, **ek):
    """Kayit "uygulandi", kuyruk olcumu, donus sozlugu (`ek`: yola ozel alanlar)."""
    giris["durum"] = "uygulandi"
    _kayit_yaz(kayit)
    _olc = kuyruk_olc(forge, kayit)
    r.update(ok=True, kayit_id=giris["id"], yeni_off=giris["yeni_off"],
             yeni_len=giris["yeni_len"], orij_off=off0, orij_len=ln0,
             buyume=giris["ek_buyume"], forge_boyut=giris["forge_boyut_sonra"], kayit=KAYIT,
             kuyruk_bayt=_olc["bayt"], kuyruk_biliniyor=_olc["biliniyor"],
             kuyruk_taban=_olc["taban"], kuyruk_kaynak=_olc["kaynak"], **ek)
    if bayat_ids:
        # Kurulum GECTI ama kullanici bunu bilmeli: eski kayitlari artik geri alamaz.
        r["bayat_kayitlar"] = bayat_ids
        r["uyari"] = BAYAT_MESAJ
    return r


# ------------------------------------------------------------------ KURULUM
def kur(forge, gid, icid, yeni_ic, etiket="", yontem="ek", ustune=False, yonlendir=None):
    """Duzenlenmis ic dosyayi arsive kur. WAL: kayit ILK BAYTTAN ONCE yazilir.

    yonlendir: None -> GOLGE_YONLENDIR; True -> hedef, kimligi iceren EN YUKSEK yama halkasina
               cozulur ve donuste `yonlendi_arsiv` bildirilir (golgeli / yalniz-yama kimlikler);
               False -> verilen arsive yazilir, golgede olsa da (Explorer `golge_yoksay`).

    yontem: "ek"      -> yeni giris dosyanin SONUNA eklenir, TOC yonlendirilir.
                         Orijinal baytlar YERINDE DURUR (cokme guvenli).
            "yerinde" -> yeni giris orijinal yuvaya yazilir (dosya buyumez);
                         yalnizca sigiyorsa. Orijinal baytlar YEDEKTEN doner.
    """
    r = {"ok": False, "yontem": yontem}
    red = _yazma_kapisi(r)
    if red is not None:
        return red
    forge = _hedef_coz(forge, gid, yonlendir, r)          # GOLGE: oyunun okudugu halka
    plan = kur_plani(forge, gid, icid, yeni_ic, yontem=yontem, yonlendir=False)
    if not plan.get("ok"):
        return plan
    kayit = _kayit_oku()
    forge = os.path.abspath(forge)
    fa = _forge_anahtari(forge)

    # --- BAYAT KAYIT AYIKLAMA — "zaten yamali" REDDINDEN ONCE (bkz. _onceki_ayikla).
    onceki, bayat_ids, red = _onceki_ayikla(kayit, forge, fa, gid,
                                            plan.get("orij_giris_sha"), ustune, r)
    if red:
        return r

    toc_i, toc_pos, off0, ln0, ext0, satir = (plan["toc_i"], plan["toc_pos"],
                                              plan["orij_off"], plan["orij_len"],
                                              int(plan["ext"], 16), None)
    with open(forge, "rb") as f:
        f.seek(toc_pos)
        satir = f.read(TOC_SATIR)
    raw = _giris_oku(forge, off0, ln0)
    yeni, bilgi = giris_kur(raw, icid, yeni_ic)
    ham_sha = _sha(raw)

    # --- VANILLA alanlari + KURAL 4 (once yedek): ustune yaziyorsak ILK girisinkiler
    #     donduruldu (bkz. _yedek_hazirla).
    van, zincir = _yedek_hazirla(kayit, forge, fa, gid, onceki, bayat_ids, off0, ln0, satir,
                                 raw, ham_sha, bilgi["eski_ic_sha"], bilgi["eski_ic_bayt"], r)
    if van is None:
        return r

    boy_once = os.path.getsize(forge)
    giris = _kayit_girisi(kayit, forge, fa, gid, icid, toc_i, toc_pos, ext0, yontem, zincir,
                          yeni, bilgi["yeni_ic_sha"], bilgi["yeni_ic_bayt"],
                          (off0 if yontem == "yerinde" else boy_once), boy_once, etiket,
                          van, bayat_ids, onceki)          # WAL: ILK BAYTTAN ONCE
    if r.get("yonlendi_arsiv"):
        giris["istenen_forge"] = r["istenen_arsiv"]      # cagiranin verdigi (golgeli) arsiv

    # --------------------------------------------------------------- yazma
    yeni_off = _giris_yaz(forge, kayit, giris, yeni, toc_pos, yontem, off0, r)
    if yeni_off is None:
        return r

    # --------------------------------------------------------------- DOGRULAMA
    sorun = _dogrula(forge, giris)
    if sorun:
        return _dogrulama_dustu(forge, kayit, giris, sorun, r)
    return _kurulum_bitir(forge, kayit, giris, r, off0, ln0, bayat_ids,
                          yeni_ic_bayt=bilgi["yeni_ic_bayt"], eski_ic_bayt=bilgi["eski_ic_bayt"])


def _dogrula_giris(forge, giris):
    """TOC satiri + giris baytlari DISKTEN geri okunur, niyetle karsilastirilir. Ic dosya
    COZULMEZ (ham yol yalniz bunu kullanir). Sorun varsa metin, yoksa None."""
    try:
        toc_i, toc_pos, off, ln, ext, satir = _toc_bilgi(forge, giris["gid_sayi"])
    except (KeyError, RuntimeError) as e:
        return "the TOC no longer describes this entry (%s)" % e
    if toc_pos != giris["toc_pos"]:
        return "the TOC row moved (%d -> %d)" % (giris["toc_pos"], toc_pos)
    if off != giris["yeni_off"] or ln != giris["yeni_len"]:
        return ("the TOC row does not point at what we wrote (off %d/%d, len %d/%d)"
                % (off, giris["yeni_off"], ln, giris["yeni_len"]))
    ham = _giris_oku(forge, off, ln)
    if _sha(ham) != giris["yeni_giris_sha"]:
        return "the entry read back from disk is not the entry we wrote"
    return None


def _dogrula(forge, giris):
    """DISKTEN geri oku, niyetle karsilastir: TOC + giris + IC DOSYA. Sorun varsa metin."""
    sorun = _dogrula_giris(forge, giris)
    if sorun:
        return sorun
    try:
        lf = LeanForge(forge)
        try:
            ic = FG.ic_dosya(lf, giris["gid_sayi"], giris["icid_sayi"])
        finally:
            lf.close()
    except Exception as e:                                      # noqa: BLE001
        return "the patched entry cannot be decoded again (%s)" % e
    if _sha(ic) != giris["yeni_ic_sha"]:
        return "the inner file read back is not the one we installed"
    if len(ic) != giris["yeni_ic_bayt"]:
        return "the inner file read back has the wrong size"
    return None


# ------------------------------------------------------------------ HAM GIRIS (BMS'siz)
def kur_ham_plani(forge, gid, yeni_giris, yonlendir=None):
    """SALT OKUMA: var olan TOC girisi HAM baytlarla degistirilebilir mi? Tek bayt yazmaz.

    `kur_plani`nin BMS'siz kardesi: giris COZULMEZ (giris_kur yok), yalnizca TOC satiri,
    yeni baytlarin sinirlari, doku aracinin catismasi ve kayit deposu (mevcut yama / bayat /
    catisma / kuyruk) olculur. Yontem daima "ek" gibidir: dosya `len(yeni_giris)` buyur.
    """
    r = {"ok": False, "forge": os.path.abspath(forge), "gid": "0x%012X" % gid, "yontem": HAM}
    forge = _hedef_coz(forge, gid, bool(yonlendir), r)   # ham yol: varsayilan yonlendirme YOK
    if not os.path.isfile(forge):
        r["mesaj"] = "Game archive not found: {0}".format(forge)
        return r
    if not yeni_giris:
        r["mesaj"] = "There are no entry bytes to write."
        return r
    if len(yeni_giris) > 0xFFFFFFFF:
        r["mesaj"] = "The new entry is too large for this archive format."
        return r
    try:
        toc_i, toc_pos, off0, ln0, ext0, satir = _toc_bilgi(forge, gid)
    except (KeyError, RuntimeError) as e:
        r["mesaj"] = str(e)
        return r
    cat = _catisma(forge, gid)
    if cat:
        r["mesaj"] = cat
        return r
    raw = _giris_oku(forge, off0, ln0)
    if len(raw) != ln0:
        r["mesaj"] = ("Entry 0x{0:X} could not be read in full ({1} of {2} bytes) - refused."
                      .format(gid, len(raw), ln0))
        return r
    r.update(ok=True, toc_i=toc_i, toc_pos=toc_pos, orij_off=off0, orij_len=ln0,
             ext="0x%08X" % ext0, bms_mi=(raw[:8] == BMS), yeni_len=len(yeni_giris),
             ayni_mi=(raw == yeni_giris), forge_boyut=os.path.getsize(forge),
             buyume=len(yeni_giris), orij_giris_sha=_sha(raw), yeni_giris_sha=_sha(yeni_giris))
    return _plan_kayit_bakisi(r, forge, gid, r["orij_giris_sha"])


def kur_ham(forge, gid, yeni_giris, etiket="", ustune=False, yonlendir=None):
    """Var olan TOC girisini HAM baytlarla degistir: BMS/K1 cozumu YOK, giris_kur YOK.

    Kim icin: BMS olmayan sistem girisleri. Olculen ornek 0x091 (giris basina bagimlilik
    tablosu, ALT_GUVERTE/src/hucre_bagimlilik.py): ilk 8 bayti BMS degil, `kur_plani`
    "Not a BMS block at offset 0." diyor. Yeni baytlarin ANLAMI burada dogrulanmaz --
    cagiran kendi semasiyla (orn. hucre_bagimlilik.s091_ac) once dogrular; burasi bayt
    esitligini garanti eder.

    `kur` ile AYNI zincir, ayni ortak halkalar: kilit + oyun-acik kapisi -> bayat/catisma
    ayiklamasi -> orijinal girisin yedegi -> WAL kaydi (ilk bayttan once fsync) -> baytlar
    dosyanin SONUNA (orijinal yerinde durur, cokme guvenli) -> TOC satiri yeni off/len'e ->
    diskten geri okuma == niyet (tutmazsa otomatik geri alma). Kayitta `yontem: "ham"`,
    `icid` None; `geri_al(kayit_id)` TOC satirini aynen geri koyar ve ekli blogu kirpar
    (bayt-birebir), `geri_al_hepsi`/`durum`/`saglik`/`kuyruk_bayt` bu kayitlari da gorur.
    Doner: `kur`un alanlari (ok, kayit_id, kayit, yeni_off, yeni_len, orij_off, orij_len,
    buyume, forge_boyut, kuyruk_*) + `ayni_mi` (yeni == eski) + `bms_mi` (eski giris BMS'ti).
    """
    r = {"ok": False, "yontem": HAM}
    red = _yazma_kapisi(r)
    if red is not None:
        return red
    # HAM yol: yonlendirme VARSAYILAN KAPALI (None -> False). Cagiranlar (ALT_GUVERTE) hangi
    # halkaya yazdigini bilerek verir; test_kur_ham_kum a2 "TOC satiri BU arsivin sonuna" der.
    forge = _hedef_coz(forge, gid, bool(yonlendir), r)
    plan = kur_ham_plani(forge, gid, yeni_giris, yonlendir=False)
    if not plan.get("ok"):
        return plan
    kayit = _kayit_oku()
    forge = os.path.abspath(forge)
    fa = _forge_anahtari(forge)
    onceki, bayat_ids, red = _onceki_ayikla(kayit, forge, fa, gid, plan["orij_giris_sha"],
                                            ustune, r, ne="archive entry")
    if red:
        return r
    toc_i, toc_pos, off0, ln0, ext0 = (plan["toc_i"], plan["toc_pos"], plan["orij_off"],
                                       plan["orij_len"], int(plan["ext"], 16))
    with open(forge, "rb") as f:
        f.seek(toc_pos)
        satir = f.read(TOC_SATIR)
    raw = _giris_oku(forge, off0, ln0)
    ham_sha = _sha(raw)
    yeni = bytes(yeni_giris)                      # OLDUGU GIBI: cozum yok, yeniden paketleme yok
    van, zincir = _yedek_hazirla(kayit, forge, fa, gid, onceki, bayat_ids, off0, ln0, satir,
                                 raw, ham_sha, None, None, r)
    if van is None:
        return r
    boy_once = os.path.getsize(forge)
    giris = _kayit_girisi(kayit, forge, fa, gid, None, toc_i, toc_pos, ext0, HAM, zincir,
                          yeni, None, None, boy_once, boy_once, etiket, van, bayat_ids,
                          onceki)                          # WAL: ILK BAYTTAN ONCE
    if r.get("yonlendi_arsiv"):
        giris["istenen_forge"] = r["istenen_arsiv"]      # cagiranin verdigi (golgeli) arsiv
    yeni_off = _giris_yaz(forge, kayit, giris, yeni, toc_pos, HAM, off0, r)
    if yeni_off is None:
        return r
    sorun = _dogrula_giris(forge, giris)          # TOC + baytlar; ic dosya YOK
    if sorun:
        return _dogrulama_dustu(forge, kayit, giris, sorun, r)
    return _kurulum_bitir(forge, kayit, giris, r, off0, ln0, bayat_ids,
                          ayni_mi=(raw == yeni), bms_mi=plan["bms_mi"])


# ------------------------------------------------------------------ GERI ALMA
def geri_al(kayit_id, _zorla_yarim=False):
    """Tek bir kurulumu geri al: TOC satiri + (yerinde ise) orijinal baytlar."""
    _k = yazma_kilidi()
    if _k:
        return {"ok": False, "mesaj": _kilit_mesaji(_k)}
    r = {"ok": False, "kayit_id": kayit_id}
    if oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        return r
    kayit = _kayit_oku()
    # ETKIN olani tercih et: eski surumler ayni kimligi iki girise verebiliyordu
    # (bkz. _yeni_kimlik). Kor `next()` o depolarda CANLI yamayi bulamiyordu.
    esler = [x for x in kayit["girisler"] if x.get("id") == kayit_id]
    g = next((x for x in esler if x.get("durum") in ("uygulandi", "yarim", "yaziliyor")),
             (esler[0] if esler else None))
    if g is None:
        r["mesaj"] = "There is no such patch record."
        return r
    if g.get("durum") == "bayat":
        # Kor yazma YOK: bu kaydin sakladigi "orijinal" baytlar baska bir oyun
        # surumune ait; geri yazmak arsivi BOZARDI.
        r["bayat"] = True
        r["kirpildi"] = 0
        r["kirpilan"] = 0
        r["mesaj"] = ("This patch record is out of date and cannot be reverted: the game "
                      "archive changed (it was updated or its files were verified) after "
                      "the patch was installed, so the original bytes this record stores "
                      "no longer belong to it. Nothing was written. The archive entry is "
                      "whatever the game last shipped.")
        return r
    if g.get("durum") not in ("uygulandi", "yarim", "yaziliyor"):
        r["mesaj"] = "This patch is not active ({0}).".format(g.get("durum"))
        return r
    forge = g["forge"]
    if not os.path.isfile(forge):
        r["mesaj"] = "Game archive not found: %s" % forge
        return r
    if g.get("yontem") == YENI_SATIR:
        return _geri_al_yeni_satir(kayit, g, r, _zorla_yarim)
    satir_orij = bytes.fromhex(g["toc_satir_orij"])
    with open(forge, "rb") as f:
        f.seek(g["toc_pos"])
        simdiki = f.read(TOC_SATIR)
    if simdiki == satir_orij:
        beklenen = None                                  # zaten vanilla'yi gosteriyor
    else:
        o_, f_, l_, e_ = struct.unpack("<QQII", simdiki)
        if f_ != g["gid_sayi"]:
            r["mesaj"] = "The TOC row no longer belongs to this mesh - refused."
            return r
        # Cokme sonrasi `yeni_off` bos kalabilir; niyet edilen konum `plan_off`ta durur.
        _bek_off = g.get("yeni_off") if g.get("yeni_off") is not None else g.get("plan_off")
        if _bek_off is not None and (o_, l_) != (_bek_off, g["yeni_len"]) \
                and not _zorla_yarim:
            r["mesaj"] = ("The archive changed since this patch (another tool wrote "
                          "here) - refused.")
            return r
        beklenen = (o_, l_)

    # 1) yerinde yazdiysak orijinal baytlar YEDEKTEN doner
    if g["yontem"] == "yerinde":
        if not os.path.isfile(g["yedek"]) or dosya_sha(g["yedek"]) != g["orij_giris_sha"]:
            r["mesaj"] = "The backup of the original entry is missing or damaged - refused."
            return r
        with open(g["yedek"], "rb") as f:
            van = f.read()
        with open(forge, "r+b") as f:
            f.seek(g["orij_off"])
            f.write(van)
            f.flush()
            os.fsync(f.fileno())

    # 2) TOC satiri aynen geri
    with open(forge, "r+b") as f:
        f.seek(g["toc_pos"])
        f.write(satir_orij)
        f.flush()
        os.fsync(f.fileno())

    # 3) DOGRULA: giris gercekten vanilla mi? (kirpma DOGRULAMADAN SONRA)
    ham = _giris_oku(forge, g["orij_off"], g["orij_len"])
    if _sha(ham) != g["orij_giris_sha"]:
        g["durum"] = "yarim"
        g["geri_alma_hatasi"] = "the restored entry is not the original one"
        _kayit_yaz(kayit)
        r["mesaj"] = "Revert did not restore the original bytes - the record was kept."
        return r
    g["durum"] = "geri_alindi"
    g["geri_alma_zamani"] = time.strftime("%Y-%m-%d %H:%M:%S")
    # Zincirin onceki halkalari da artik olu: ayni vanilla'ya donduk, onlarin
    # ekledigi bloklar OKSUZ. Isaretlenmezlerse kuyruk geri kazanimi onlari
    # "canli" sayip arsivi kalici olarak buyumus birakiyordu (olculdu: kanit B).
    for x in _zincir(kayit, g):
        if x.get("durum") == "ustune_yazildi":
            if g.get("zincir_taban") == "yeni_satir" and x.get("yontem") == YENI_SATIR:
                # (2026-09-18) taban bir YENI SATIR kaydi: arsiv tam onun yazdigi hale dondu,
                # kayit yeniden ETKIN (kuyruk kirpma onun blogunu canli sayar; kendi geri_al'i
                # ile sonra kaldirilir).
                x["durum"] = "uygulandi"
                x.pop("ustune_yazan", None)
                x["yeniden_etkin"] = g["geri_alma_zamani"]
                continue
            x["durum"] = "geri_alindi"
            x["geri_alma_zamani"] = g["geri_alma_zamani"]

    # 4) KUYRUK GERI KAZANIMI: dosyanin sonu OLU bir bloksa kirp, tekrarla.
    kirpildi = _kuyruk_geri_kazan(forge, kayit)
    g["kirpilan"] = kirpildi
    g["forge_boyut_geri"] = os.path.getsize(forge)
    # DURUSTLUK KAPISI: "ok" demek arsivin BASLANGIC BOYUNA dondugu anlamina GELMEZ.
    # Eski surum bunu sessiz geciyordu; olculdu: ic ice kurulumda ilk yamayi geri
    # alinca 317.932 B, cokme benzetiminde 215.960 B oksuz kaldigi halde
    # {"ok": true, "kirpilan": 0} donuyordu -- kullanici arsivin temiz oldugunu saniyordu.
    #
    # OLCUM (KUYRUK TABANI): fazlalik artik kaydin KENDI `forge_boyut_once`undan degil,
    # bu arsivin TABANINDAN hesaplanir. Ikisi yalniz ILK yamada aynidir; zincirin ikinci
    # halkasinda `forge_boyut_once` zaten buyumus dosyayi gosterir ve fazlalik
    # OLDUGUNDAN KUCUK cikardi.
    # Olcum TEK KAPIDAN (`kuyruk_olc`) gecer: taban artik `vanilla_boyut` ALANINA bagli
    # degil (alan tasimayan eski kayitlar sahte 0 uretiyordu -- bkz. kuyruk olcumu basligi).
    olcum = kuyruk_olc(forge, kayit)
    taban = olcum["taban"]
    oksuz = olcum["bayt"]                      # None = BILINMIYOR, "temiz" DEGIL
    g["oksuz_bayt"] = oksuz
    g["kuyruk_taban"] = taban
    g["kuyruk_kaynak"] = olcum["kaynak"]
    # BU yamanin blogu hala dosyada mi? (kirpilamadiysa evet)
    _off = g.get("yeni_off") if g.get("yeni_off") is not None else g.get("plan_off")
    kalan_bizim = (int(g.get("yeni_len") or 0)
                   if (g["yontem"] in ("ek", HAM) and _off is not None
                       and int(_off) < g["forge_boyut_geri"]) else 0)
    g["bu_yamadan_kalan"] = kalan_bizim
    g["kuyruk_notu"] = _kuyruk_notu(kayit, forge, g, kirpildi, oksuz, kalan_bizim,
                                    olcum=olcum)
    if not g["kuyruk_notu"]:
        g.pop("kuyruk_notu", None)
    _kayit_yaz(kayit)
    r.update(ok=True, kirpildi=kirpildi, kirpilan=kirpildi,
             forge_boyut=g["forge_boyut_geri"],
             beklenen=beklenen, yontem=g["yontem"], oksuz_bayt=oksuz,
             kuyruk_bayt=oksuz, kuyruk_taban=taban,
             kuyruk_biliniyor=olcum["biliniyor"], kuyruk_kaynak=olcum["kaynak"],
             kuyruk_sebep=olcum["sebep"],
             bu_yamadan_kalan=kalan_bizim,
             vanilla_boyut=taban,
             kuyruk_notu=g.get("kuyruk_notu"))
    if g.get("kuyruk_notu"):
        r["mesaj"] = g["kuyruk_notu"]
    return r


def _geri_al_yeni_satir(kayit, g, r, zorla):
    """YENI TOC SATIRI geri alma: sayac geri, satir sifirlanir, baytlar kirpilir.

    SIRA KURULUSUN TERSI: once BASLIK SAYACI (o an yeni satir hicbir okuyucu icin
    yoktur), sonra satirin kendisi. Yarida kalirsa arsiv yine tutarlidir.
    """
    forge = g["forge"]
    hoff, toc_pos = int(g["hoff"]), int(g["toc_pos"])
    baslik_orij = bytes.fromhex(g["baslik_orij"])
    satir_orij = bytes.fromhex(g["toc_satir_orij"])
    with open(forge, "rb") as f:
        f.seek(hoff)
        baslik = f.read(12)
        f.seek(toc_pos)
        simdiki = f.read(TOC_SATIR)
    try:
        count, toc_bas = struct.unpack("<IQ", baslik)
    except struct.error:
        r["mesaj"] = "The archive header could not be read - refused."
        return r
    if toc_bas != int(g["toc_bas"]):
        # KONUM KAPISI (ship_yerinde dersi): TOC tasindiysa kaydettigimiz satir
        # konumu artik baska bir seye isaret eder; kor yazma arsivi BOZAR.
        r["mesaj"] = ("The table of contents of this archive was moved by another tool - "
                      "refused. Nothing was written.")
        return r
    if baslik != baslik_orij or simdiki != satir_orij:
        if count not in (int(g["yeni_count"]), int(g["eski_count"])):
            r["mesaj"] = ("The archive now lists %d entries, not the %d this record was "
                          "written against - refused." % (count, g["yeni_count"]))
            return r
        if simdiki != satir_orij:
            o_, f_, l_, _e = struct.unpack("<QQII", simdiki)
            if f_ != g["gid_sayi"]:
                r["mesaj"] = "The added row no longer belongs to this entry - refused."
                return r
            _bek = g.get("yeni_off") if g.get("yeni_off") is not None else g.get("plan_off")
            if _bek is not None and (o_, l_) != (int(_bek), int(g["yeni_len"])) and not zorla:
                r["mesaj"] = ("The archive changed since this entry was added (another tool "
                              "wrote here) - refused.")
                return r
        with open(forge, "r+b") as f:
            f.seek(hoff)                              # 1) SAYAC ONCE
            f.write(baslik_orij)
            f.flush()
            os.fsync(f.fileno())
            f.seek(toc_pos)                           # 2) satir sonra
            f.write(satir_orij)
            f.flush()
            os.fsync(f.fileno())
    try:
        lf = LeanForge(forge)
        try:
            hala = (lf.count, g["gid_sayi"] in lf.by_id)
        finally:
            lf.close()
    except Exception as e:                                      # noqa: BLE001
        hala = None
        g["geri_alma_hatasi"] = str(e)
    if hala is not None and (hala[0] != int(g["eski_count"]) or hala[1]):
        g["durum"] = "yarim"
        g["geri_alma_hatasi"] = ("the entry is still listed (count %d, present %s)"
                                 % (hala[0], hala[1]))
        _kayit_yaz(kayit)
        r["mesaj"] = "Revert did not remove the added entry - the record was kept."
        return r
    g["durum"] = "geri_alindi"
    g["geri_alma_zamani"] = time.strftime("%Y-%m-%d %H:%M:%S")
    kirpildi = _kuyruk_geri_kazan(forge, kayit)
    g["kirpilan"] = kirpildi
    g["forge_boyut_geri"] = os.path.getsize(forge)
    olcum = kuyruk_olc(forge, kayit)
    g["oksuz_bayt"] = olcum["bayt"]
    g["kuyruk_taban"] = olcum["taban"]
    g["kuyruk_kaynak"] = olcum["kaynak"]
    _off = g.get("yeni_off") if g.get("yeni_off") is not None else g.get("plan_off")
    kalan_bizim = (int(g.get("yeni_len") or 0)
                   if (_off is not None and int(_off) < g["forge_boyut_geri"]) else 0)
    g["bu_yamadan_kalan"] = kalan_bizim
    g["kuyruk_notu"] = _kuyruk_notu(kayit, forge, g, kirpildi, olcum["bayt"], kalan_bizim,
                                    olcum=olcum)
    if not g["kuyruk_notu"]:
        g.pop("kuyruk_notu", None)
    _kayit_yaz(kayit)
    r.update(ok=True, kirpildi=kirpildi, kirpilan=kirpildi, yontem=YENI_SATIR,
             forge_boyut=g["forge_boyut_geri"], oksuz_bayt=olcum["bayt"],
             kuyruk_bayt=olcum["bayt"], kuyruk_taban=olcum["taban"],
             kuyruk_biliniyor=olcum["biliniyor"], kuyruk_kaynak=olcum["kaynak"],
             kuyruk_sebep=olcum["sebep"], bu_yamadan_kalan=kalan_bizim,
             vanilla_boyut=olcum["taban"], kuyruk_notu=g.get("kuyruk_notu"))
    if g.get("kuyruk_notu"):
        r["mesaj"] = g["kuyruk_notu"]
    return r


def _kuyruk_notu(kayit, forge, g, kirpildi, oksuz, kalan_bizim, olcum=None):
    """Geri almadan sonra kullaniciya soylenecek DURUST cumle (ya da None).

    Dort ayri gercek var, dort ayri cumle: (a) her sey temizlendi, (b) BU yamanin blogu
    dosyada kaldi cunku uzerine baska bir blok yazilmis, (c) bu yamanin blogu kirpildi
    ama arsiv hala buyuk cunku BASKA yamalar duruyor, (d) OLCULEMEDI. Eski surum (a),
    (b) ve (c)'yi tek cumleyle ve yanlis sayiyla anlatiyor, (d)'yi ise (a) sanip
    SUSUYORDU -- yani "bilmiyorum"u "temiz" diye gosteriyordu."""
    if oksuz is None:
        # BILINMIYOR. Sessiz kalmak "temiz" demekle ayni sey; sebebi soyle.
        return ((olcum or {}).get("mesaj") or "") + (
            " The mesh was put back to its original bytes, but how much this tool has "
            "left in the archive could not be measured.")
    if not oksuz:
        return None
    if kalan_bizim:
        # NEDEN kirpilamadi? Ustunde bizim CANLI bir yamamiz mi var, yoksa baska bir
        # aracin blogu mu? Ikisi kullaniciya FARKLI is verir, ayirt et.
        _off = g.get("yeni_off") if g.get("yeni_off") is not None else g.get("plan_off")
        son = int(_off or 0) + int(g.get("yeni_len") or 0)
        fa = _forge_anahtari(forge)
        ustumuzde = [x.get("id") for x in kayit["girisler"]
                     if x.get("forge_anahtar") == fa
                     and x.get("durum") in ("uygulandi", "yarim", "yaziliyor")
                     and (x.get("yeni_off") if x.get("yeni_off") is not None
                          else x.get("plan_off")) is not None
                     and int(x.get("yeni_off") if x.get("yeni_off") is not None
                             else x.get("plan_off")) >= son]
        if ustumuzde:
            sebep = ("a newer mesh patch ({0}) was written after it. Revert that patch "
                     "too and the space comes back.").format(", ".join(ustumuzde))
        elif _canli_kuyruk(forge) > son:
            sebep = ("another tool wrote to the end of the archive after it (for example "
                     "the texture patcher). Revert that patch too and the space comes back.")
        else:
            sebep = ("something else was written to the end of the archive after it, so "
                     "the space cannot be reclaimed without risking that data.")
        return ("The mesh is back to its original bytes, but the archive is still {0} "
                "bytes larger than before this tool first wrote to it: this patch's "
                "{1} bytes are still in the file because {2}").format(
                    oksuz, g.get("yeni_len"), sebep)
    return ("This patch was removed and {0} bytes were reclaimed, but the archive is "
            "still {1} bytes larger than before this tool first wrote to it because "
            "other patches are still installed. Revert those too and the space comes "
            "back.").format(kirpildi, oksuz)


def _zincir(kayit, g):
    """`g`ye giden ustune-yazma zincirinin ONCEKI halkalari."""
    out, gor = [], set()
    kim = g.get("onceki_id")
    while kim and kim not in gor:
        gor.add(kim)
        x = next((y for y in kayit["girisler"]
                  if y.get("id") == kim and y.get("durum") == "ustune_yazildi"), None)
        if x is None:
            break
        out.append(x)
        kim = x.get("onceki_id")
    # eski kayitlarda zincir alani olmayabilir: ustune_yazan geriye isaret eder
    for y in kayit["girisler"]:
        if y.get("ustune_yazan") == g.get("id") and y not in out:
            out.append(y)
    return out


def _canli_kuyruk(forge):
    """TOC'un GERCEKTEN gosterdigi en uc bayt. Bunun otesindeki her sey oksuzdur.
    Kayda degil DISKE bakar -- baska bir aracin ekledigi blok da dogru sayilir."""
    lf = LeanForge(forge)
    try:
        return max((off + ln) for off, _fid, ln, _ext in lf.entries) if lf.entries else 0
    finally:
        lf.close()


def _kuyruk_geri_kazan(forge, kayit):
    """Dosyanin SONU OLU bir ek blok oldugu surece kirp.

    doku_enjekte2'nin `ek_bloklar` dersi: her uygula/gerial cevrimi arsivi kalici
    buyutmesin. Kirpma kosulu IKI KATLIDIR:
      (a) kaydimizda duran, artik canli olmayan (geri_alindi / ustune_yazildi) bir blok,
      (b) VE bloktan sonra CANLI TOC satiri kalmamis olmasi (`_canli_kuyruk`).
    (b) diskten olculur, kayittan degil: kaydin `yeni_off`u eksik olsa bile
    (yazma ile kayit arasinda cokme) `plan_off` ile blok yine taninir -- eski surumde
    bu durumda blok SONSUZA KADAR oksuz kaliyordu (olculdu: 215.960 B).
    """
    fa = _forge_anahtari(forge)
    # TABAN ZEMINI: hicbir kosulda bu arsivin ILK yazisimizdan onceki boyutunun ALTINA
    # inilmez. Temiz forge'un sonunda TOC'un gostermedigi kuyruk verisi vardir (olculdu:
    # WhiteRoom'da 39.849 B); `_canli_kuyruk` tek basina o veriyi korumaz. Bozuk/eski bir
    # kaydin `plan_off`u oraya duserse kirpma OYUN VERISI SILERDI.
    # RAPOR TABANI DEGIL, KIRPMA ZEMINI kullanilir: rapor yanilirsa fazlaligi ABARTMALI
    # (en dusuk taban), kirpma yanilirsa AZ KESMELI (en yuksek taban). Ayni sayiyi iki ise
    # birden kosmak, kuyruk raporunu duzeltirken kirpmayi da asagi cekerdi.
    taban = _kirpma_zemini(kayit, fa)
    toplam = 0
    while True:
        boy = os.path.getsize(forge)
        canli = _canli_kuyruk(forge)
        if canli >= boy:
            return toplam                            # kuyrukta canli veri var: dur
        aday = None
        for x in kayit["girisler"]:
            if x.get("forge_anahtar") != fa or x.get("yontem") not in EKLI_YONTEMLER:
                continue
            if x.get("durum") == "bayat":
                continue                             # baska bir oyun surumunun duzeni
            off = x.get("yeni_off")
            if off is None:
                off = x.get("plan_off")              # cokme: yazma tamamlandi mi bilinmiyor
            if off is None or off >= boy or off < canli:
                continue
            if taban is not None and int(off) < int(taban):
                continue                             # taban zemininin altina inme
            if x.get("durum") in ("uygulandi",):
                return toplam                        # kuyruktaki blok CANLI: dur
            aday = (x, int(off))
            break
        if aday is None:
            return toplam
        x, off = aday
        try:
            with open(forge, "r+b") as f:
                f.truncate(off)
                f.flush()
                os.fsync(f.fileno())
        except OSError as e:                                    # zararsiz: oksuz kalir
            x["kuyruk_notu"] = str(e)
            return toplam
        x["kirpildi"] = True
        toplam += boy - off


def geri_al_hepsi(forge=None):
    """Tum aktif kurulumlari geri al. EN YENIDEN ESKIYE: ekli bloklar ancak bu
    sirada dosyanin sonundan sirayla kirpilabilir."""
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    kayit = _kayit_oku()
    # ZINCIR (2026-10-12): bir arsiv istenince onun yama grubundaki HER halkanin kaydi
    # (boot istenince boot_patch_01'e yonlendirilmis yamalar da) geri alinir.
    zan = _zincir_anahtarlari(forge) if forge else None
    hedef = [g for g in kayit["girisler"]
             if g.get("durum") in ("uygulandi", "yarim", "yaziliyor")
             and (zan is None or g.get("forge_anahtar") in zan)]
    # Cokme sonrasi `yeni_off` bos olabilir -> `plan_off` ile sirala, yoksa en yeni
    # blok en sona dusmez ve kuyruk sirayla kirpilamaz.
    hedef.sort(key=lambda g: (g.get("yeni_off") if g.get("yeni_off") is not None
                              else (g.get("plan_off") or 0)), reverse=True)
    sonuc = {"ok": True, "geri_alindi": 0, "kirpilan": 0, "basarisiz": []}
    for g in hedef:
        rr = geri_al(g["id"])
        if rr.get("ok"):
            sonuc["geri_alindi"] += 1
            sonuc["kirpilan"] += rr.get("kirpilan", 0)
        else:
            sonuc["ok"] = False
            sonuc["basarisiz"].append({"id": g["id"], "mesaj": rr.get("mesaj")})
    # SON SUPURME: tek tek geri almalar sirasinda "sonra gelen blok canli" diye
    # birakilan oksuzler, hepsi olunce artik kirpilabilir.
    sonuc["kirpildi"] = sonuc["kirpilan"]
    if forge and os.path.isfile(forge):
        kayit = _kayit_oku()
        ek = 0
        sonuc["zincir_kuyruk"] = {}
        nc_f = os.path.normcase(os.path.abspath(forge))
        for p in zincir_arsivleri(forge):                 # her halka KENDI kuyrugunu supurur
            if os.path.normcase(p) == nc_f or not os.path.isfile(p):
                continue
            if not _arsiv_gidleri(p):
                continue                                  # acilamayan halka (kum yer tutucusu) / bos
            ek += _kuyruk_geri_kazan(p, kayit)
            sonuc["zincir_kuyruk"][os.path.basename(p)] = kuyruk_olc(p, kayit)["bayt"]
        ek += _kuyruk_geri_kazan(forge, kayit)
        if ek:
            _kayit_yaz(kayit)
        sonuc["kirpilan"] += ek
        sonuc["kirpildi"] = sonuc["kirpilan"]
        sonuc["son_supurme"] = ek
        sonuc["forge_boyut"] = os.path.getsize(forge)
        # DURUSTLUK: "Revert all" bitti demek "arsiv eski boyuna dondu" demek DEGIL.
        # OLCULDU (scratchpad\kusur\d3b_iki_ithal.py): iki IMPORT 3D'den sonra
        # 29.917.184 -> 29.970.627 B kalmisti ve donus {"ok": true} diyordu.
        olcum = kuyruk_olc(forge, kayit)
        art = olcum["bayt"]
        sonuc["kuyruk_bayt"] = art
        sonuc["kuyruk_taban"] = olcum["taban"]
        sonuc["kuyruk_biliniyor"] = olcum["biliniyor"]
        sonuc["kuyruk_kaynak"] = olcum["kaynak"]
        sonuc["kuyruk_sebep"] = olcum["sebep"]
        if art:
            sonuc["mesaj"] = (
                "Every mesh patch was reverted, but the archive is still {0} bytes "
                "larger than before this tool first wrote to it. Blocks written by "
                "another tool (for example the texture patcher) sit at the end of the "
                "file, so that space cannot be reclaimed yet. Revert those patches too, "
                "then run this again and the space comes back.").format(art)
        elif art is None:
            # BILINMIYOR: susmak "arsiv temiz" demekle ayni sey olurdu.
            sonuc["mesaj"] = (
                "Every mesh patch was reverted, but whether the archive is back to its "
                "old size could not be measured. " + olcum["mesaj"])
    return sonuc


def kuyruk_temizle(forge):
    """Arsivin sonunda kalan OKSUZ bloklari (varsa) kirp — hicbir yamayi geri almaz.

    Neden ayri bir kapi: bir yamanin blogu, uzerine BASKA bir aracin blogu yazildigi
    icin geri alma aninda kirpilamaz. O arac da yamasini geri aldiktan sonra bu cagri
    kuyrugu supurur. Yalniz KENDI kayitlarimizdaki olu bloklari ve yalniz TOC'un
    gostermedigi baytlari kirpar; taban zemininin altina inmez."""
    _k = yazma_kilidi()
    if _k:
        return {"ok": False, "mesaj": _kilit_mesaji(_k)}
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    if not forge or not os.path.isfile(forge):
        return {"ok": False, "mesaj": "Game archive not found: %s" % forge}
    kayit = _kayit_oku()
    n = _kuyruk_geri_kazan(forge, kayit)
    if n:
        _kayit_yaz(kayit)
    olcum = kuyruk_olc(forge, kayit)
    return {"ok": True, "kirpildi": n, "kirpilan": n,
            "forge_boyut": os.path.getsize(forge),
            "kuyruk_bayt": olcum["bayt"], "kuyruk_taban": olcum["taban"],
            "kuyruk_biliniyor": olcum["biliniyor"], "kuyruk_kaynak": olcum["kaynak"],
            "kuyruk_sebep": olcum["sebep"], "kuyruk_mesaj": olcum["mesaj"],
            "kirpma_zemini": _kirpma_zemini(kayit, _forge_anahtari(forge))}


# ------------------------------------------------------------------ durum / saglik
def durum(forge=None):
    """Bu aracin kayitli yamalari (salt okuma)."""
    kayit = _kayit_oku()
    # ZINCIR (2026-10-12): verilen arsivin yama grubundaki HER halkanin kaydi gorunur (boot
    # istenince boot_patch_01'e yonlendirilmis yamalar da; Health Check / Restore All / Hide
    # Parts / Explorer hepsi buradan okur). Kuyruk olcumu ARSIV BASINADIR: `kuyruk_*` verilen
    # arsiv icin, `zincir` listesi halka basina (ad, aktif sayisi, kuyruk bayti).
    zan = _zincir_anahtarlari(forge) if forge else None
    gir = [g for g in kayit["girisler"] if zan is None or g.get("forge_anahtar") in zan]
    aktif = [g for g in gir if g.get("durum") in ("uygulandi", "yarim", "yaziliyor")]
    bayat = [g for g in gir if g.get("durum") == "bayat"]
    olcum = (kuyruk_olc(forge, kayit) if forge else
             {"bayt": None, "biliniyor": False, "taban": None, "kaynak": "yok",
              "sebep": None, "mesaj": ""})
    return {"kayit": KAYIT, "kayit_var": os.path.isfile(KAYIT),
            "toplam": len(gir), "aktif": len(aktif),
            "zincir": ([{"forge": os.path.basename(p), "yol": p,
                         "aktif": sum(1 for g in aktif
                                      if g.get("forge_anahtar") == _forge_anahtari(p)),
                         "kuyruk_bayt": kuyruk_olc(p, kayit)["bayt"]}
                        for p in zincir_arsivleri(forge)] if forge else []),
            "buyume": sum(g.get("ek_buyume", 0) for g in aktif),
            # KUYRUK: arsiv, bizim ilk yazisimizdan once ne kadardiysa ondan kac bayt
            # buyuk. None = BILINMIYOR ve bu "temiz" DEMEK DEGILDIR -- ayirt etmek icin
            # `kuyruk_biliniyor`a bak, kullaniciya basmak icin `kuyruk_mesaj`i kullan.
            "kuyruk_bayt": olcum["bayt"],
            "kuyruk_taban": olcum["taban"],
            "kuyruk_biliniyor": olcum["biliniyor"],
            "kuyruk_kaynak": olcum["kaynak"],
            "kuyruk_sebep": olcum["sebep"],
            "kuyruk_mesaj": olcum["mesaj"],
            "bayat": len(bayat),
            "bayat_yamalar": [{"id": g.get("id"), "gid": g.get("gid"),
                               "sebep": g.get("bayat_sebep"),
                               "onceki_durum": g.get("bayat_onceki_durum")}
                              for g in bayat],
            "yamalar": [{"id": g["id"], "zaman": g["zaman"], "etiket": g.get("etiket", ""),
                         "gid": g["gid"], "icid": g["icid"], "durum": g["durum"],
                         "yontem": g["yontem"], "forge": os.path.basename(g["forge"]),
                         "ic_bayt": "%s -> %s" % (g.get("orij_ic_bayt"), g.get("yeni_ic_bayt"))}
                        for g in aktif]}


def saglik(forge=None):
    """Health Check: MESH ve DOKU yamalarini YAN YANA listeler.

    Iki depo ayridir ama birbirinden haberdardir: ayni arsive iki arac da
    yaziyorsa kullanici bunu TEK ekranda gormeli, yoksa birini geri alip
    "temiz" sanir."""
    out = {"mesh": durum(forge), "doku": None}
    if forge:
        k, yol = _doku_kaydi(forge)
        out["doku"] = {"kayit": yol, "kayit_var": bool(k),
                       "harici": len((k or {}).get("harici") or []),
                       "gomulu": len((k or {}).get("gomulu") or []),
                       "ek_bloklar": len((k or {}).get("ek_bloklar") or []),
                       "durum": (k or {}).get("durum")}
    else:
        depolar = []
        if os.path.isdir(DOKU_KOK):
            for ad in sorted(os.listdir(DOKU_KOK)):
                y = os.path.join(DOKU_KOK, ad, DOKU_KAYIT_ADI)
                if os.path.isfile(y):
                    k = _json_oku(y, bos={})
                    depolar.append({"kayit": y, "forge": k.get("forge"),
                                    "harici": len(k.get("harici") or []),
                                    "gomulu": len(k.get("gomulu") or []),
                                    "durum": k.get("durum")})
        out["doku"] = depolar
    # Sozlesme alani, ust duzeyde de: arayuz `saglik(f)["kuyruk_bayt"]` ya da
    # `saglik(f)["mesh"]["kuyruk_bayt"]` desin, ayni sayiyi bulsun.
    for _alan in ("kuyruk_bayt", "kuyruk_taban", "kuyruk_biliniyor", "kuyruk_kaynak",
                  "kuyruk_sebep", "kuyruk_mesaj"):
        out[_alan] = out["mesh"].get(_alan)
    out["not"] = YONTEM_NOTU
    return out


if __name__ == "__main__":
    import pprint
    pprint.pprint(saglik(sys.argv[1] if len(sys.argv) > 1 else None))
