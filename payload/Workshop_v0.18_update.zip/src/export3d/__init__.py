# -*- coding: utf-8 -*-
"""export3d — Outfit Workshop 3D paketi (oyun -> GLB -> Blender -> OYUNA GERI).

DISA AKTARMA (EXPORT 3D) tek yondur ve oyuna dokunmaz. ICE AKTARMA (IMPORT 3D)
duzenlenmis GLB'yi ve yeniden boyanmis PNG'leri geri yazar: dogrulama (salt okuma
rapor) -> kullanici onayi -> yazma (geri alma kaydi + yazma sonrasi dogrulama).

Plan: tasarim\\3D_DISA_AKTARMA_PLANI.md. Tek dis giris:
    export_3d(anahtar, out_dir=None, lod=0, progress=None) -> sonuc sozlugu
        anahtar : onizleme3d indeks anahtari ('U_Edward_Fire', 'Edward_Assassin', 'CHR_...')
        out_dir : kok klasor (varsayilan ~\\Documents\\OutfitWorkshop\\3D); cikti <out_dir>\\<anahtar>[_N]
        lod     : indeks LOD sirasi (0 = en ayrintili)
        progress: satir satir ilerleme geri cagrisi (sunucu._log)
        Doner {ok, klasor, glb, parca_sayisi, cikan, atlanan[{ad,gid,icid,sebep}], rig{hiyerarsik,duz}, sure, ...}
Oyun dosyasina DOKUNMAZ (paylasilan LeanForge, 'rb'); is bitince release_forge(onbellek=False).

Alt moduller:
  forge_giris   — paylasilan LeanForge uzerinden TOC girisi -> ic dosyalar (K1/K2)
  mesh_yapisal  — Mesh (0x415D9568) yapisal okuyucu + 7 tamponluk bayt kapisi
  mesh_yaz      — AYNI TOPOLOJIDE geri yazici: duzenlenmis geometri -> ic dosya baytlari
                  (uzunluk sabit; turetilmis tablolar yeniden hesaplanir, fail-closed)
  iskelet       — pisirilmis rig (rigler/edward_326.json) + rig/palet uygunluk kapisi
  glb_yaz       — GLB yazici (JOINTS_0/1, gomulu PNG) + glb_geri_oku (kapi b)
  glb_oku       — ITHALATCI: Blender'dan cikmis GLB -> numpy geometri + manifest baglantisi;
                  parca/prim eslesmesi (ad -> geometri imzasi), vertex permutasyonu,
                  IDENTICAL/CHANGED topoloji karari, iskelet hizalamasi (Kabsch)
  kur_mesh      — KURULUM/GERI ALMA: yeni ic dosya -> forge (WAL kayit + yedek +
                  yazma sonrasi dogrulama + geri_al/geri_al_hepsi). Oyun acikken
                  reddeder; kayit %LOCALAPPDATA%\\ACBFR_Modding\\mesh altinda,
                  doku yolunun (doku_enjekte2) kaydindan AYRI ama ondan haberdar.
  doku_png      — materyal dokulari -> PNG (TEX_ onekli; apply akisina bulasmaz)
  mesh_ithal    — ITHALATIN MESH TARAFI (KOPRU): glb_oku.eslestir -> parca basina ROTA
                  karari (atla / ayni topoloji -> mesh_yaz.yaz / topoloji degisti ->
                  mesh_yaz.yaz_serbest / red) -> yeni ic dosya baytlari DOGRULAMADA
                  uretilir -> kur_mesh.kur. Yazicinin kendi kapilari (dejenere ucgen,
                  65535 vertex tavani, konum bandi, tablo oz-denetimi) boylece onay
                  ekraninda gorunur, yazarken degil.
  doku_ithal    — ITHALATIN DOKU TARAFI: textures\\ icinde BOYANMIS PNG'leri bulur
                  (manifest'teki sha256 ile karsilastirir, dokunulmayani atlar),
                  her birini manifest'in yazdigi (kap, TM indeksi) hedefine baglar,
                  rol tersini kurar (normal: G geri cevrilir, B vanilla'dan, A=gloss;
                  diffuse: alfa alfa_politika ile vanilla'dan) ve APPLY ile AYNI
                  hatta verir: TexEncode -> DDS -> doku_enjekte2.uygula (tek yazici,
                  ayni geri alma kaydi). Boyut/format uymayani SEBEBIYLE reddeder.
  sahne         — hepsini diken hat: kur() -> GLB + manifest.json + README.txt
"""
SURUM = "1.0"

__all__ = ["export_3d", "SURUM"]


def export_3d(anahtar, out_dir=None, lod=0, progress=None, gevsek_kopya=None):
    """Plan §5 Adim 6: sahne.kur sarmalayicisi (tembel import: sunucu acilisini agirlastirmasin).
    gevsek_kopya: None -> sahne.GEVSEK_GOMULU_KOPYA (gomulen diffuse/normal'in gevsek kopyasi)."""
    from . import sahne
    return sahne.kur(anahtar, out_dir=out_dir, lod=lod, progress=progress, gevsek_kopya=gevsek_kopya)
