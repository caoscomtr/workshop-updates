# -*- coding: utf-8 -*-
"""forge_giris — TOC girisi -> ic dosyalar (SALT OKUMA).

Plan §5 Adim 1. Forge'a IKINCI bir tanitici ACILMAZ: `lf` daima
`outfit_core._forge()`in dondurdugu paylasilan LeanForge'dur (Steam
"Content file locked" riski tek tanitici ile sinirli kalir; birakma isi
cagiranin `outfit_core.release_forge(onbellek=False)` cagrisidir).

Giris yerlesimi (bayt-dogrulanmis, hafiza: ac4-forge-format-referansi §4):
  raw = [BMS kap K1][BMS kap K2]
  K1  = [u16 n] + n x ( [u64 ic_id][u32 len][u16 a @+12][u16 ?][u16 b @+16] + a + 2b B )
        -> kayit SABIT 18 B DEGIL; adim 18+a+2b / 18+a / 18+2b (UC ADAY; k1_coz iki
        degismezle dogrular, YAZICI k1_yerler ile AYNI secimi kullanir).
        Eski tek terimli 18+a varsayimi ic[3] icin 378 MB uzunluk uretiyordu (Material /
        figurehead) ve 2b'li girislerde (GridCell bloklari, 129 ic dosya) K1 disina tasiyordu.
  K2  = ic dosya govdelerinin ardisik birlesimi;  sum(len) == len(K2)  ZORUNLU.
Her ic dosya = sarmalayici [u32 tip][u32 boyut][u32 adLen][ad adLen B][u8 flag][u64 nid][u32 tip] + govde.
"""
import struct
import zlib

try:
    from yalin_forge import read_block, BMS
except ImportError:                       # gelistirme agacinda yalin_forge, outfit_core'un
    import outfit_core                    # noqa: F401  sys.path'e ekledigi klasordedir
    from yalin_forge import read_block, BMS

__all__ = ["ic_dosyalar", "ic_dosya", "sarmalayici_coz", "sarmalayici_boyut_duzelt",
           "sarmalayici_kur", "k1_coz", "k1_yerler", "k1_k2_yeniden_diz", "blok_basligi",
           "bms_yaz", "giris_kur"]


# K1 KAYIT ADIMI — IKI TERIMLI (2026-09-07 olcumu).
# Eski tek terimli kural (18 + u16@+12) 2.241 girisi hic cozemiyordu; ikinci terim
# eklenince oyunun ic dosya sayisi 2.091.958 -> 2.165.458 oldu (+73.500, ~42.500'u
# ADLI varlik). Kural EZBERLENMEZ, DOGRULANIR: uc aday denenip iki yapisal degismezi
# saglayan secilir (tablo tam bitmeli + uzunluk toplami K2'nin acik boyuna esit).
#   a = u16@+12, b = u16@+16;  (True, True) -> 18+a+2b · (True, False) -> 18+a ·
#   (False, True) -> 18+2b.
# 2026-09-13: YAZICI DA BU LISTEYI KULLANIR (k1_yerler -> k1_k2_yeniden_diz). Eski yazici
# yalniz (True, False) kuralini biliyordu; 2b'li girislerde (CaribbeanSea_patch_01
# Cell122802: 129 ic dosya, K1 2.502 B) uzunluk alanini ofset 2.709'a yazmaya kalkip
# struct.error veriyor, kur_mesh.kur / explorer_core.geri_yukle o girisleri yeniden
# dizemiyordu (olculdu; kapi: testler/test_k1_yerler_yazici.py).
_K1_ADAYLAR = ((True, True), (True, False), (False, True))


def _kural_adi(kural):
    """(a_say, b_say) -> '18+a+2b' gibi okunur ad (rapor / kayit icin)."""
    a_say, b_say = kural
    return "18" + ("+a" if a_say else "") + ("+2b" if b_say else "")


def _k1_tara(k1, a_say, b_say):
    """Tek aday kuralla tabloyu coz -> ([(ic_id, uzunluk, kayit_ofs)], tablo_sonu).

    `kayit_ofs` kaydin K1 icindeki BASLANGICI: u64 ic_id orada, u32 uzunluk alani
    `kayit_ofs + 8`de. Okuyucu (k1_coz) ofseti atar; yazici (k1_yerler ->
    k1_k2_yeniden_diz) uzunluk alanini TAM o yere yazar."""
    n = struct.unpack_from("<H", k1, 0)[0]
    out = []
    q = 2
    sinir = len(k1)
    for _ in range(n):
        if q + 18 > sinir:
            raise ValueError("K1 table truncated")
        icid, ln = struct.unpack_from("<QI", k1, q)
        adim = 18
        if a_say:
            adim += struct.unpack_from("<H", k1, q + 12)[0]
        if b_say:
            adim += 2 * struct.unpack_from("<H", k1, q + 16)[0]
        out.append((icid, ln, q))
        q += adim
    if q > sinir:
        raise ValueError("K1 table truncated")
    return out, q


def k1_coz(k1, k2_boy=None):
    """K1 kayit tablosu -> [(ic_id, len)].

    `k2_boy` verilirse (K2'nin ACIK boyu) kural DOGRULANIR: tablo tam bitmeli ve
    uzunluk toplami k2_boy'a esit olmali. Verilmezse tabloyu tam bitiren ilk aday
    secilir. Hicbiri cozemezse ValueError.
    OKUMA tarafi: hicbir aday iki degismezi saglamazsa yine de cozulebilen ILK aday
    donulur (bir sey gostermek hic gostermemekten iyidir). YAZMA tarafi bu geri
    dususu KULLANMAZ -> k1_yerler.
    """
    ilk = None
    for a_say, b_say in _K1_ADAYLAR:
        try:
            kayit, q = _k1_tara(k1, a_say, b_say)
        except (ValueError, struct.error):
            continue
        kayit = [(c, l) for c, l, _q in kayit]
        if ilk is None:
            ilk = kayit
        if q != len(k1):
            continue
        if k2_boy is None or sum(l for _, l in kayit) == k2_boy:
            return kayit
    if ilk is None:
        raise ValueError("K1 table unparsable under any record-stride rule")
    return ilk


def k1_yerler(k1, k2_boy):
    """K1 -> ([(ic_id, len, kayit_ofs)], kural) — YAZICININ KAYIT SINIRLARI. KATI.

    k1_coz ile AYNI aday kurallar (_K1_ADAYLAR), ama k1_coz'un "ilk aday" geri dususu
    YOK: iki degismezi (tablo TAM biter + Σlen == K2 boyu) birden saglamayan aday
    reddedilir, hicbiri saglamazsa ValueError. Sebep: yanlis kuralla bulunan "kayit
    basi" baska bir kaydin ortasidir; oraya yazilan u32 uzunluk K1'i sessizce bozar
    (eski yazicida ofset tasmasi struct.error verdiginden fark edildi; tasmayan
    girislerde sessiz bozulma olurdu). Iki degismezi birden saglayan iki aday FARKLI
    kayit sinirlari uretirse de reddedilir (belirsiz tablo). a=0 ya da b=0 olan
    girislerde adaylar zaten AYNI sinirlari verir; bu cakisma degildir, ilk aday
    `kural` olarak bildirilir. `kural` = (a_say, b_say); `_kural_adi` okunur ada cevirir.
    """
    if len(k1) < 2:
        raise ValueError("K1 block is shorter than its own record count field")
    secilen = kural = None
    for a_say, b_say in _K1_ADAYLAR:
        try:
            kayit, q = _k1_tara(k1, a_say, b_say)
        except (ValueError, struct.error):
            continue
        if q != len(k1) or sum(l for _, l, _q in kayit) != k2_boy:
            continue
        if secilen is None:
            secilen, kural = kayit, (a_say, b_say)
        elif kayit != secilen:
            raise ValueError("This entry's file table is ambiguous: two record layout rules "
                             "(%s, %s) both fit but give different record boundaries - refused."
                             % (_kural_adi(kural), _kural_adi((a_say, b_say))))
    if secilen is None:
        raise ValueError("This entry's file table cannot be resolved: no record layout rule "
                         "makes the table end exactly at its block end with the lengths "
                         "adding up to the body block (%d B) - refused." % k2_boy)
    return secilen, kural


def k1_k2_yeniden_diz(k1, k2, degisim):
    """Acik K1 + acik K2 + {ic_id: yeni_govde} -> (yeni_k1, yeni_k2, bilgi). TEK K1 YAMALAYICI.

    forge_giris.giris_kur (STORED yeniden sarma) ve kur_mesh.giris_kur (sablon/Oodle
    yeniden sarma) kabi BURADAN dizer; ikisinin K1/K2 baytlari birebir aynidir.
      * Kayit sinirlari k1_yerler'den gelir (k1_coz ile ayni aday kurallar, KATI secim).
      * Uzunlugu DEGISEN her kaydin u32 uzunluk alani (kayit_ofs + 8) yerinde yazilir;
        K1'in baska HICBIR bayti degismez (ekstra alanlar, 2b kayitlari, sira, kuyruk).
        Degisim bossa ya da uzunluk ayniysa K1 bayt-birebir aynen doner.
      * K2, K1 sirasiyla yeniden birlestirilir; degisen ic dosya BASKA uzunlukta olabilir.
      * KAPI: yeni K1 ayni kati cozucuyle geri okunur; ayni kayit sinirlari + yeni
        uzunluklar cikmazsa RuntimeError, cagirana tek bayt donmez.
    Bilinmeyen ic_id -> KeyError. Ayni ic_id tabloda iki kez varsa ve degistiriliyorsa
    ValueError (hangisi yamalanacak belirsiz).
    bilgi = {yerler, kural, kural_adi, eski, degisen_ofsetler};
    `eski` = {ic_id: eski_govde} yalniz degisenler icin, `degisen_ofsetler` = K1'de
    yazilan uzunluk alanlarinin ofsetleri (her biri 4 B).
    """
    yerler, kural = k1_yerler(k1, len(k2))
    sayac = {}
    for c, _l, _q in yerler:
        sayac[c] = sayac.get(c, 0) + 1
    bilinmeyen = [c for c in degisim if c not in sayac]
    if bilinmeyen:
        raise KeyError("inner file(s) not in this entry: %s" % ["0x%X" % x for x in bilinmeyen])
    tekrar = [c for c in degisim if sayac[c] > 1]
    if tekrar:
        raise ValueError("Inner file 0x%X appears twice in this entry." % tekrar[0])
    yeni_k1 = bytearray(k1)
    govdeler, eski, ofsetler = [], {}, []
    p = 0
    for icid, ln, q in yerler:
        govde = k2[p:p + ln]
        p += ln
        if icid in degisim:
            yeni = bytes(degisim[icid])
            eski[icid] = govde
            if len(yeni) != ln:
                if len(yeni) > 0xFFFFFFFF:
                    raise ValueError("inner file 0x%X is %d B, too large for a u32 length field"
                                     % (icid, len(yeni)))
                struct.pack_into("<I", yeni_k1, q + 8, len(yeni))
                ofsetler.append(q + 8)
            govde = yeni
        govdeler.append(govde)
    yeni_k1 = bytes(yeni_k1)
    yeni_k2 = b"".join(govdeler)
    # KAPI: yeni tablo ayni kati cozucuyle, AYNI sinirlarla, YENI uzunluklarla cozulmeli.
    beklenen = [(c, len(g), q) for (c, _l, q), g in zip(yerler, govdeler)]
    try:
        kontrol, _kural2 = k1_yerler(yeni_k1, len(yeni_k2))
    except ValueError as e:
        raise RuntimeError("The rebuilt file table does not resolve with our own reader "
                           "(%s) - nothing was written." % e)
    if kontrol != beklenen:
        raise RuntimeError("The rebuilt file table resolves to different record boundaries "
                           "than the original - nothing was written.")
    return yeni_k1, yeni_k2, dict(yerler=yerler, kural=kural, kural_adi=_kural_adi(kural),
                                 eski=eski, degisen_ofsetler=ofsetler)


def ic_dosyalar(lf, gid):
    """TOC girisi `gid` -> [(ic_id:int, govde:bytes), ...] (K1 sirasiyla).

    `lf`: paylasilan LeanForge (outfit_core._forge()). Giris canli TOC'ta yoksa KeyError.
    Giris BMS kabi degilse (ham RawAsset vb.) ValueError.
    """
    if gid not in lf.by_id:
        raise KeyError("entry 0x%X not in live TOC" % gid)
    raw = lf.read_raw(gid)
    k1, n1 = read_block(raw, 0)
    if k1 is None:
        raise ValueError("entry 0x%X is not a BMS container (raw asset?)" % gid)
    k2, _n2 = read_block(raw, n1)
    if k2 is None:
        raise ValueError("entry 0x%X has no K2 body container" % gid)
    kayitlar = k1_coz(k1, len(k2))
    toplam = sum(ln for _, ln in kayitlar)
    # Sum(len) == len(K2): K1 cozumu yanlissa (ekstra alani atlanmadiysa) burada dusulur.
    assert toplam == len(k2), ("K1/K2 length mismatch for entry 0x%X: sum(len)=%d len(K2)=%d"
                               % (gid, toplam, len(k2)))
    out = []
    p = 0
    for icid, ln in kayitlar:
        out.append((icid, k2[p:p + ln]))
        p += ln
    return out


def ic_dosya(lf, gid, icid):
    """Girisin icinden TEK ic dosyanin govdesi (bytes). Yoksa KeyError."""
    for cid, govde in ic_dosyalar(lf, gid):
        if cid == icid:
            return govde
    raise KeyError("inner file 0x%X not in entry 0x%X" % (icid, gid))


def sarmalayici_coz(govde):
    """Ic dosya sarmalayicisi -> {tip, boyut, adLen, flag, nid, govde_off}.
    `boyut == len(govde) - 13 - adLen` dogrulanir (8/8 dosyada olculdu); tutmazsa ValueError."""
    tip, boyut, adLen = struct.unpack_from("<III", govde, 0)
    p = 12 + adLen
    flag = govde[p]
    nid = struct.unpack_from("<Q", govde, p + 1)[0]
    tip2 = struct.unpack_from("<I", govde, p + 9)[0]
    p += 13
    if tip != tip2:
        raise ValueError("wrapper type mismatch: 0x%08X vs 0x%08X" % (tip, tip2))
    # BOYUT ESITLIGI DEGIL, SINIR KONTROLU (2026-09-07 olcumu): Animation girislerinin
    # sonunda `boyut`a dahil OLMAYAN 55-199 baytlik kuyruk var (or. OBD_Animals_Flamingo:
    # l=4859, boyut=4673, adLen=46). Esitlik sart kosulunca boot'ta 43.560 GECERLI varlik
    # eleniyordu. Fark artik REDDETME sebebi degil, olculup `kuyruk` alaninda bildiriliyor.
    govde_boy = len(govde) - 13 - adLen
    if boyut > govde_boy:
        raise ValueError("wrapper size overruns the entry: header %d vs body %d"
                         % (boyut, govde_boy))
    return dict(tip=tip, boyut=boyut, adLen=adLen, flag=flag, nid=nid, govde_off=p,
                kuyruk=govde_boy - boyut)


def sarmalayici_boyut_duzelt(ham, kuyruk=0):
    """Ic dosyanin [u32 boyut] alanini (ofset 4) BUGUNKU uzunlugundan yeniden yazar:
    boyut = len(ham) - 13 - adLen - kuyruk. Doner (bayt, eski_boyut, yeni_boyut).

    SARMALAYICI BOYUT DERSI (2026-09-05 silah_stat, 16 kapi kacirmisti): uzunluk degistiren
    yazmada kabin KENDI boyut alani da yazilmali; yoksa oyun girisi reddeder. Ham put-back
    (Explorer / Unpack all) 2026-09-09'a kadar buyuyen dosyayi kabul edip bu alani bayat
    birakiyordu. `kuyruk` = ORIJINAL ic dosyanin `boyut`a dahil olmayan kuyrugu (Animation
    girislerinde 55-199 B); kullanicinin ekledigi/cikardigi baytlar govdeye sayilir."""
    tip, boyut, adLen = struct.unpack_from("<III", ham, 0)
    beklenen = len(ham) - 13 - adLen - kuyruk
    if beklenen < 0:
        raise ValueError("the file is shorter than its own wrapper (%d B, name %d B, tail %d B)"
                         % (len(ham), adLen, kuyruk))
    if beklenen == boyut:
        return bytes(ham), boyut, boyut
    b = bytearray(ham)
    struct.pack_into("<I", b, 4, beklenen)
    return bytes(b), boyut, beklenen


def sarmalayici_kur(ham, govde_off, yeni_govde, duzelt=None):
    """ORIJINAL ic dosyanin sarmalayicisi + YENI govde -> tam ic dosya (bytes).

    TEK SARMALAYICI KURUCUSU: nesne_yaz._ic_dosya_kur, silah_stat._ic_dosya_kur ve
    explorer_core'un ham put-back'i AYNI baytlari uretmek zorunda (test K6(i) esitligi
    olcer). Uzunluk degisebilir; `boyut` alani (ofset 4) YENIDEN hesaplanir ve
    ORIJINALIN kuyrugu (boyuta dahil OLMAYAN 55-199 B, Animation girisleri) korunur.
    `duzelt(bytearray, beklenen)` verilirse boyut alanini O yazar -- testler bu kancayi
    sokup kapinin gercekten dustugunu olcer. Sonuc KENDI cozucumuzle geri okunur;
    esitlik tutmazsa ValueError/RuntimeError -- hicbir sey yazilmaz."""
    w0 = sarmalayici_coz(ham)
    kuyruk = int(w0.get("kuyruk") or 0)
    yeni = bytearray(ham[:govde_off]) + bytes(yeni_govde)
    adLen = struct.unpack_from("<III", bytes(yeni), 0)[2]
    beklenen_boyut = len(yeni) - 13 - adLen - kuyruk
    if beklenen_boyut < 0:
        raise ValueError("The new body (%d B) is shorter than the tail this inner file "
                         "carries (%d B) - nothing was written." % (len(yeni_govde), kuyruk))
    if duzelt is None:
        struct.pack_into("<I", yeni, 4, beklenen_boyut)
    else:
        duzelt(yeni, beklenen_boyut)
    yeni = bytes(yeni)
    # KAPI: kendi cozucumuzle geri oku. sarmalayici_coz esitlik degil SINIR kontrolu
    # yapar (kuyruklu girisler yuzunden); esitligi BURADA, kendi kurdugumuz dosyada
    # ariyoruz -- kabin tamamini biz kurduk, boyutu tam bilmemiz gerekir.
    try:
        w = sarmalayici_coz(yeni)
    except ValueError as e:
        raise ValueError("The rebuilt inner file does not decode with our own reader "
                         "(%s) - nothing was written." % e)
    if w["boyut"] != beklenen_boyut or int(w.get("kuyruk") or 0) != kuyruk:
        raise ValueError("wrapper size mismatch: header %d, expected %d (tail %d) - "
                         "nothing was written." % (w["boyut"], beklenen_boyut, kuyruk))
    if w["govde_off"] != govde_off:
        raise RuntimeError("The rebuilt inner file has a different header layout - "
                           "nothing was written.")
    if yeni[govde_off:] != bytes(yeni_govde):
        raise RuntimeError("The rebuilt inner file does not carry the body we packed - "
                           "nothing was written.")
    return yeni


# =====================================================================================
#  KURULUM YOLU (YAZMA) — giris kabinin (BMS K1/K2) yeniden dizilmesi
# =====================================================================================
# `mesh_yaz.yaz_serbest` cikti UZUNLUGUNU DEGISTIRIR (kume tablolari dustugu icin skinned
# mesh'lerde medyan %44,8'e iner). Ayni-uzunluk yamalarindan farkli olarak bu, giris kabini
# (K1 kayit uzunlugu + K2 govdesi) ve forge TOC'undaki giris boyutunu ilgilendirir.
# Burada kabin YARISI vardir; forge tarafi (TOC boyut alani) BILINCLI OLARAK YOKTUR --
# kaptanin ayri karari, ve bu turda oyuna tek bayt yazilmaz.
#
# BMS blok yerlesimi (yalin_forge.read_block'un okudugu bicim, bayt-dogrulandi):
#   [8 B BMS imzasi][u16 ver][5 B opak][u32 t]  ->  t >= 0x10000 ise parca sayisi u16 (2 B),
#   degilse t'nin kendisi parca sayisidir (4 B) · sonra parca basina (ver<=1: u16 u, u16 c |
#   ver>=2: u32 u, u32 c) · sonra parca basina [u32 adler][c B veri].
# ADLER: adler32(parca_baytlari, init=0) -- 8/8 gercek parcada dogrulandi (hem stored hem
# Oodle'li parcalarda, SIKISTIRILMIS baytlar uzerinden). c == u olan parca STORED'dir, yani
# Oodle OLMADAN yazilabilir (BLOWPIPE isinde de bu yol kullanilmisti).
_VARSAYILAN_PARCA = 0x10000          # vanilla bloklarda gorulen ust sinir


def blok_basligi(d, off=0):
    """BMS blok basligini cozer -> {ver, opak5, parca, boyutlar, veri_off, son} ya da None."""
    if d[off:off + 8] != BMS:
        return None
    p = off + 8
    ver = struct.unpack_from("<H", d, p)[0]; p += 2
    opak5 = bytes(d[p:p + 5]); p += 5
    t = struct.unpack_from("<I", d, p)[0]
    if t >= 0x10000:
        pc = struct.unpack_from("<H", d, p)[0]; p += 2
    else:
        pc = t; p += 4
    boyut = []
    for _ in range(pc):
        if ver <= 1:
            boyut.append(struct.unpack_from("<HH", d, p)); p += 4
        else:
            boyut.append(struct.unpack_from("<II", d, p)); p += 8
    cur = p
    for u, c in boyut:
        cur += 4 + c
    return dict(ver=ver, opak5=opak5, parca=pc, boyutlar=boyut, veri_off=p, son=cur)


def bms_yaz(govde, ver=3, opak5=b"\x08\x00\x00\x04\x80", parca=_VARSAYILAN_PARCA):
    """`govde` baytlarini STORED (sikistirmasiz) BMS blogu olarak yazar.
    Oodle GEREKMEZ: c == u olan parca vanilla'da da vardir ve `read_block` onu aynen dondurur."""
    n = max(1, (len(govde) + parca - 1) // parca)
    dilim = [govde[i * parca:(i + 1) * parca] for i in range(n)]
    out = bytearray(BMS)
    out += struct.pack("<H", ver) + opak5
    # Parca sayisi u32 olarak yazilir; okuyucu 0x10000'den KUCUK bir degeri dogrudan parca
    # sayisi sayar (>= 0x10000 baska bir kodlamadir ve burada URETILMEZ -> fail-closed).
    if n >= 0x10000:
        raise ValueError("BMS chunk count %d does not fit this writer's u32-count form" % n)
    out += struct.pack("<I", n)
    for v in dilim:
        out += struct.pack("<II", len(v), len(v)) if ver >= 2 else struct.pack("<HH", len(v), len(v))
    for v in dilim:
        out += struct.pack("<I", zlib.adler32(v, 0) & 0xFFFFFFFF) + v
    return bytes(out)


def giris_kur(raw, degisim):
    """TOC girisinin HAM baytlari + {ic_id: yeni_govde} -> YENI ham giris baytlari.

    Kap (K1/K2) k1_k2_yeniden_diz ile dizilir: kayit sinirlari k1_coz'un aday
    kurallarindan KATI secimle (k1_yerler) gelir, yalniz uzunlugu degisen kaydin u32
    uzunluk alani yazilir, K1'in geri kalani (ekstra alanlar dahil) bayt-birebir
    korunur, K2 yeniden dizilir. Iki blok da STORED yazilir, bu yuzden sonuc genelde
    orijinalden BUYUKTUR -- forge'a yazmak, TOC'taki giris boyutunu da guncellemeyi
    gerektirir ve bu modulun isi DEGILDIR. Bos degisimle K1 ve K2 aynen doner (yalniz
    sarma STORED'a cevrilir).
    Bilinmeyen bir ic_id verilirse KeyError; K1 tablosu hicbir kuralla iki degismezi
    saglamiyorsa ValueError (2026-09-13'e kadar buradaki tek kuralli yuruyus 2b'li
    girislerde K1 disina yazip struct.error veriyordu)."""
    b1 = blok_basligi(raw, 0)
    if b1 is None:
        raise ValueError("entry is not a BMS container")
    k1, n1 = read_block(raw, 0)
    b2 = blok_basligi(raw, n1)
    k2, _n2 = read_block(raw, n1)
    if k1 is None or k2 is None or b2 is None:
        raise ValueError("entry has no K1/K2 blocks")
    yeni_k1, yeni_k2, _bilgi = k1_k2_yeniden_diz(k1, k2, degisim)
    return (bms_yaz(yeni_k1, ver=b1["ver"], opak5=b1["opak5"])
            + bms_yaz(yeni_k2, ver=b2["ver"], opak5=b2["opak5"]))
