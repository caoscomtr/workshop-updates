# -*- coding: utf-8 -*-
"""glb_oku -- DUZENLENMIS GLB'yi geri okuyucu (ithalatci / importer).

glb_yaz.py'nin ters yonu. `glb_yaz.glb_geri_oku` KENDI yazdigimiz dosyayi DENETLER
(kapi b: hiza, min/max, agirlik toplami...). Bu modul ise kullanicinin BLENDER'DAN
CIKARDIGI dosyayi OKUR ve bizim geometri yapilarimiza dondurur -- yani ikisi ayni is
degil: geri_oku "dosya saglam mi?" der, glb_oku "bu dosya hangi parcanin nesi ve ne
degismis?" der.

Blender'in yeniden disa aktardigi dosya bizim yazdigimizla BAYT-BIREBIR DEGILDIR.
Olculen/beklenen farklar ve bu modulun her birine karsiligi:

  (1) Sahne donusumu uygulanir / dugum agaci yeniden kurulur.
      -> Her dugumun DUNYA matrisi sahne kokunden zincirle hesaplanir; skinli
         primitiflerde etkin donusum spec geregi `globalJoint_j @ IBM_j` (mesh
         dugumunun donusumu skinlemede YOK SAYILIR). Sonra kok Y-up dondurmesi
         GERI ALINIR (Rx(+90)), yani cikan konumlar yine oyunun Z-up mesh uzayinda,
         metre cinsindendir. `glb_yaz.KOK_ZUP_YUP_ROTATION` dugumu bulunmasa bile
         dogru calisir: dunya matrisinin kendisi cevrilir.
  (1b) ISKELET KOKU DUNYAYI KAYDIRIR (2026-09-04'te olculdu, Blender 5.2.39).
      Bizim `SkeletonRoot` dugumumuz bos degil, kendi matrisini tasir (Z ekseninde 90
      derece + 0,964 m yukari). Blender skinli mesh'i armature'e KEMIK-GORELI baglar,
      bu yuzden ice aktarilan nesnenin dunya matrisi bu kok kemigi icerir ve yeniden
      disa aktarimda POSITION dizisi ARTIK BASKA BIR DUNYADADIR: olculen sapma parca
      basina 1,0-1,3 m ve donusum tahmini "olcek 0,06" gibi anlamsiz cikiyordu.
      -> Cozum `hizala()`: iki dosyanin KEMIK BIND KONUMLARI (inverse(IBM), ADLA
         eslenir) arasinda Kabsch/Procrustes ile KATI (dondurme+oteleme) donusum
         cikarilir ve yeni sahneye uygulanir. Kemik konumlari kullanicinin mesh
         duzenlemesinden ETKILENMEZ, bu yuzden 2 cm'lik bir oteleme hizalamaya
         SIZMAZ -- fark olcumunde duzenleme olarak kalir. Olcek fitlenmez, yalnizca
         RAPORLANIR (armature'u olceklemis bir kullanici sessizce yutulmasin).
         Skinsiz (rigid) dosyada kemik yoktur -> `hizala()` MESH'lerden coz
         (`_mesh_hizala`, yontem 'mesh (kemik yok)'); dugum zinciri dogru olsa da
         fit KOSULUR (2026-09-05 olculdu: rijit kimlikte aci 1,9e-5 derece, oteleme
         ~1e-16 m). Bu sayede +Y Up KAPALI export'un 90 derecesi yazilmaz (senaryo 09).
  (1c) SAHNE YERLESIMI: hizalama, kullanicinin BUTUN modeli tasimasini/dondurmesini de
      geri alir (rijitte mesh fiti, skinlide kemik fiti). Bu bir sekil duzenlemesi degil,
      sahne yerlesimidir ve YAZILMAZ -- ama SOYLENMELIDIR. 2026-09-05'e kadar sessizdi:
      butun modeli 5 cm tasimak "2 unchanged in shape" veriyordu (tek parcayi tasimak
      50 mm yazilirken). `sahne_yerlesimi()` hizalamanin kullaniciya ait kismini cikarir:
        rijit / mesh fiti : E = A (taban birim)
        kemik fiti        : E = M_kok @ A; M_kok = kaynak dosyanin skin.skeleton dugumunun
                            oyun uzayindaki yerlesimi (SkeletonRoot: Rz(-90) + 0,964 m).
                            Blender armature'u bu dugume koyup kemik dinlenme matrislerine
                            de ayni matrisi kattigi icin dokunulmamis tur-donusunde
                            A = inv(M_kok) cikar (olculdu: kilic + BlackBeard kimlik,
                            E aci 1e-5 derece, |t| 0,001 mm; senaryo 16 -> 50,0 mm;
                            17 -> 90,0 derece; 09 -> 90,0 derece). `A @ M_kok` YANLIS
                            (09'da 1363 mm sahte oteleme verdi).
      A zaten birimse (Blender'in ileride kemik matrisini katlamamasi ihtimali) E = birim.
  (1d) BAYAT EXPORT'UN IBM'I VERTEXLERI KAYDIRIR (2026-09-05'te olculdu).
      glTF spec: skinli mesh'te `globalJoint_j @ IBM_j` BUTUN eklemlerde aynidir. 2026-09-05'te
      kapanan sahne.py K-1a kusuru bunu bozuyordu: palet IBM'i verbatim yazilinca rig dugum
      hiyerarsisiyle tutarsiz kaliyordu. Blender tutarsizligi ice aktarirken bakiyor
      (kemik dinlenme pozunu dugum agacindan kurar, IBM'i yeniden yazar), bu yuzden
      DOKUNULMAMIS bir tur-donusunde vertexler kayiyor -- yani fark KULLANICININ DEGIL,
      export'un. Olculdu (U_Edward_Diplomat, 02:03 export'u):
        skin 2 HumanBody_Mannequin  tutarsizlik 4,228e-03 (eklem P_O_BV_Abs) -> vertex 1,6115 mm
        skin 3 Pants_Edward_Assassin tutarsizlik 4,228e-03 (ayni eklem)      -> vertex 0,4868 mm
        saglam 10 skin              tutarsizlik <= 3,5e-05                   -> vertex <= 0,0019 mm
      Blender'in geri verdigi dosyada gozlenen kayma 1,61 mm / 0,49 mm: UST SINIRLA ucuncu
      haneye kadar AYNI. Bu yuzden tutarsizlik artik TUM eklemlerde olculur (2026-09-05'e kadar
      yalniz ILK 8 eklem taraniyordu -- 60. eklemdeki kusur GORUNMUYOR, ayni dosyada 1,354e-06
      okunuyordu) ve tetigi asan skinin her parcasi icin
        ibm_kayma_m = maks_v | SUM_j w_vj (G_ic E_j inv(G_ic E_0) - I) p_v |
      hesaplanir: "bu tutarsizlik bu parcanin vertexlerini en fazla ne kadar kaydirir".
      mesh_ithal bunu ROTA kapisi olarak kullanir (dokunulmamis parca YAZILMAZ).
  (2) Primitifler yeniden siralanir, materyal adi degisir, nesneler yeniden adlandirilir.
      -> Parca eslesmesi once ADLA (birebir -> Blender '.001' soneki atilmis -> mesh adi ->
         kucuk harf), kalanlar GEOMETRI IMZASIYLA (NV, NT, sinir kutusu). Sonunda 2-OPT
         duzeltmesi: kullanici iki nesnenin ADINI TAKAS ettiyse ad eslesmesi sessizce
         yanlis parcayi baglar; yalnizca KABA iyilesmede (esik 0,5 puan -- 2 cm oteleme
         ~0,02, %5 olcek ~0,05 uretir) takas edilir. Primitifler parca icinde (NV,NT) ->
         materyal adi -> imza sirasiyla eslenir (Blender'in materyal yuvasi sirasi degisir).
      K-2: ADLA eslesen parca 2-opt'a GIRMEZ (ad = kullanicinin acik talimati). Bunun
         bedeli (K-4, 2026-09-05, Blender 5.2 senaryo 10a/10b/10c, CHR_BlackBeard ile
         olculdu): kullanici iki nesnenin adini takas ederse geometri YANLIS arsiv girisine
         gider ve hicbir kapi konusmazdi -- 10c'de HeadAcc'in opak mesh'i Brow'un (MASK sac
         karti) girisine, sac kartlari HeadAcc'in opak materyaline yaziliyordu; 10a/10b'nin
         reddi konum bandindan gelen TESADUFTU (Boots poz_olcek 1, digerleri 2: 15 ciftin
         10'u kapisiz gecer). Esleme kurali DEGISMEDI; `eslestir()` iki ucuz sinyali
         OLCUP kayda yazar, mesh_ithal.plan bunlari NOTE yapar:
           `ad_celiskisi` : nesne adi ile mesh adi iki FARKLI kaynak parcaya cozuluyor
                            (`ad_celiskileri`; 10a'da 2 parca; kaynak export'ta 6/6 parcada
                            mesh_ad == ad ve Blender tur-donusu bunu koruyor -> guvenilir);
           `takas_imzasi` : adla eslesmis, CHANGED iki parcada NV ve NT CAPRAZ birebir
                            (`takas_imzalari`; 10a/10b Boots<->Pants 4832/2304, 10c
                            Brow<->HeadAcc 3282/1530 + 2188/2840; kaynak sayilari ayniysa
                            imza sayilmaz). Iki CHANGED parcanin karsilikli TAM esitligi
                            gerektigi icin yanlis alarm pratikte sifir.
  (3) Vertex bolunur / birlestirilir, vertex sirasi degisir.
      -> Vertex esleme katmanli denenir: ucgen dizisi birebir -> ANAHTAR merdiveni
         (_ANAHTAR_SIRASI) -> WL (ucgen grafiyle renk ayristirma) -> en yakin komsu.
         Anahtarlarin ustteki basamaklari (UV0, deri = kemik ADI crc + u8 agirlik)
         OTELEME ve OLCEK duzenlemesinden ETKILENMEZ, bu yuzden tasinmis bir parcada da
         esleme kurulur. Olculdu (Blender 5.2, ters siralanmis U_Edward_Fire): UV0 tek
         basina 27.271 vertexin yalniz 11.425'ini ayiriyor (ayna UV adalari), normal ve
         konum anahtarlari da tur-donusunde nicemleme sinirinda kayiyor -> 14 parcanin
         10'u anahtarla cozulemiyordu; WL turu 14/14'e cikardi.
  (4) Kullanilmayan nitelikler dusurulur.
      -> Eksik nitelik hata degil; sozlukte None kalir.

Topoloji karari (parca ve primitif basina):
  IDENTICAL  : indeks tamponu bir VERTEX PERMUTASYONUNA kadar ayni (ucgenler kanonik
               siralanip kiyaslanir). Iki BLENDER NORMALIZASYONU da IDENTICAL sayilir
               (2026-09-05, Blender 5.2 kimlik turu, rijit Weapon_Pistol_11/_01 ile olculdu;
               eski surum ikisini de CHANGED sayip dokunulmamis parcayi kume-siz rijit
               bicimde, birinde 206 vanilla ucgen EKSIK yeniden kuruyordu):
               (a) dikis vertexi bolunmesi (NV +2/+4): `_anahtar_surjeksiyon` GLB'yi kaynaga
                   (pos,uv) ile baglar, her (pos,uv) grubu tek kanonik indekse iner -- ikiz
                   secimi farki ucgen kumesini degistirmez (34/34 "farkli" ucgen kapandi);
               (b) kaynaktaki KOPYA ucgenlerin dusmesi (NT -206): Blender importeri
                   `mesh.validate()` ile atar; benzersiz ucgen kumeleri birebirse IDENTICAL,
                   oyunun kendi indeks tamponu (kopyalariyla) yerinde kalir (`_kopya_dususu`).
               Parca kaydinda `ikiz_bolunme` / `kopya_ucgen_dustu` sayilari tasinir.
  CHANGED    : ucgen kumesi tutmuyor, ya da NV/NT farki (a)/(b) ile aciklanamiyor
               (gercek vertex kaybi -> surjeksiyon kurulmaz; gercek ucgen silme/ekleme ->
               benzersiz kumeler farkli). Parca sebebi primitif sebebini MASKELEMEZ.
               Permutasyon kurulamayan primitif/parca `kaba_donusum` tasir (`_kaba_donusum`:
               agirlik merkezi kaymasi, RMS yaricap orani = olcek, ana eksen donmesi, sinir
               kutusu boy orani) -- esleme GEREKTIRMEYEN tahmin; onay ekrani "ne degisti"yi
               bununla soyler. (2026-09-05'e kadar `poz_fark_maks_m`/`donusum_tahmini` None
               kaliyor, mesh_ithal bunu 0,0 mm basiyordu: Weapon_Pistol_11'de 5 cm tasima,
               2x, 0,5x, 90 derece senaryolari kimlik turuyla ayni onay satirini veriyordu.
               Surjeksiyon mutlak konum anahtarli (2e-5 m) oldugu icin tasinan/olceklenen
               rijit parcada permutasyon HIC kurulmaz; 7 senaryoyla olculdu.)
  BILINMIYOR : vertex eslemesi kurulamadi (permutasyon bulunamadi).

Disa acilan giris noktalari:
    oku(yol)                       -> sahne sozlugu (numpy diziler, OYUN uzayinda)
    hizala(yeni, kaynak)           -> kemik adlariyla kati donusum (Kabsch) + artik olcumu
    sahne_yerlesimi(hiz, kaynak)   -> hizalamanin kullaniciya ait kismi (butun model tasindi/dondu mu)
    donusum_uygula(sahne, A)       -> sahnenin tum dizilerini yerinde donusturur
    eslestir(yeni, kaynak)         -> parca/primitif eslesmesi + topoloji + fark olcumu
    manifest_bagla(rapor, yol)     -> manifest.json kaydini (gid/icid/sha256) rapora diker
    karsilastir(yeni_yol, kaynak_yol, manifest_yolu=None) -> ucunu birden kosan sarmalayici
    rapor_ozet(rapor)              -> JSON'a yazilabilir hale getirir

Hicbir oyun dosyasina dokunmaz; yalniz verilen .glb yollarini 'rb' ile okur.
"""
import hashlib
import json
import os
import struct
import zlib

import numpy as np

from . import glb_yaz as GY

SURUM = "1.0"

__all__ = ["oku", "hizala", "sahne_yerlesimi", "donusum_uygula", "eslestir", "manifest_bagla",
           "karsilastir", "rapor_ozet", "SURUM", "RX_YUP_ZUP", "IDENTICAL", "CHANGED", "BILINMIYOR"]

IDENTICAL, CHANGED, BILINMIYOR = "IDENTICAL", "CHANGED", "UNKNOWN"

# glTF Y-up -> oyun Z-up: X ekseni etrafinda +90 derece (glb_yaz'in kok dugumunun TERSI)
RX_YUP_ZUP = np.array([[1.0, 0.0, 0.0, 0.0],
                       [0.0, 0.0, -1.0, 0.0],
                       [0.0, 1.0, 0.0, 0.0],
                       [0.0, 0.0, 0.0, 1.0]], dtype=np.float64)

# Vertex esleme anahtarlarinin nicemleme adimlari (1 birim = kac ondalik basamak)
Q_UV = 6            # UV0/UV1  (f32 tur-donusunde bozulmaz)
Q_NRM = 3           # normal   (Blender ozel bolunmus normalleri korur, kucuk f32 gurultusu olur)
Q_POZ = 5           # konum, metre -> 10 mikron
EN_YAKIN_ESIK = 1e-4   # en yakin komsu yedegi icin kabul esigi (metre)
# IBM TUTARSIZLIGI (bkz. baslik "(1d)"): bu esigin UZERINDEKI skinde parca basina
# `ibm_kayma_m` de olculur. Taban gurultusu olculdu (2026-09-05, U_Edward_Diplomat):
# saglam export'ta 12/12 skin 7,265e-08; K-1a oncesi export'ta saglam 10 skin
# 1,4e-06 .. 3,5e-05, kusurlu 2 skin 4,228e-03. 1e-6 taban gurultusunun 14 kati
# ustunde, en kucuk gercek kusurun 4200 kati altinda.
IBM_OLCUM_TETIK = 1e-6


# =============================================================== dusuk seviye GLB
def _chunk_ayikla(d, hata):
    """GLB baytlari -> (json_sozluk, BIN baytlari). Hatalar listeye yazilir."""
    if len(d) < 20 or d[:4] != b"glTF":
        hata.append("not a GLB (magic)")
        return None, b""
    ver, ln = struct.unpack_from("<II", d, 4)
    if ver != 2:
        hata.append("glTF version %d != 2" % ver)
    if ln != len(d):
        hata.append("header length %d != file size %d" % (ln, len(d)))
    js, binb = None, b""
    off = 12
    while off + 8 <= len(d):
        cl, ct = struct.unpack_from("<II", d, off)
        if off + 8 + cl > len(d):
            hata.append("chunk 0x%08X overruns file" % ct)
            break
        govde = d[off + 8:off + 8 + cl]
        if ct == GY.CHUNK_JSON and js is None:
            try:
                js = json.loads(govde.decode("utf-8"))
            except Exception as e:                       # noqa: BLE001 -- olcum, kapi dusurulur
                hata.append("JSON parse error: %s" % e)
        elif ct == GY.CHUNK_BIN and not binb:
            binb = govde
        off += 8 + cl
    if js is None:
        hata.append("no JSON chunk")
    return js, binb


def _bv_bayt(js, binb, bv_idx, hata, etiket):
    bv = js["bufferViews"][bv_idx]
    o = bv.get("byteOffset", 0)
    n = bv["byteLength"]
    if o + n > len(binb):
        hata.append("%s: bufferView %d exceeds BIN chunk" % (etiket, bv_idx))
        return b""
    return bytes(binb[o:o + n])


def _acc_oku(js, binb, idx, hata, etiket, normalize=False):
    """Accessor -> numpy (count, n) float64/int64. byteStride (araligi gecmeli tampon) ve
    sparse (seyrek) accessor DESTEKLENIR; Blender ikisini de yazabilir."""
    a = js["accessors"][idx]
    n = GY.TYPE_N[a["type"]]
    ct = a["componentType"]
    if ct not in GY.BILESEN_DTYPE:
        hata.append("%s: unknown componentType %s" % (etiket, ct))
        return None, a
    dt = np.dtype(GY.BILESEN_DTYPE[ct])
    bs = GY.BILESEN_BOYUT[ct]
    say = a["count"]
    if "bufferView" not in a:                              # tumu sifir + sparse ustune biner
        arr = np.zeros((say, n), dt)
    else:
        bv = js["bufferViews"][a["bufferView"]]
        temel = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
        stride = bv.get("byteStride") or (n * bs)
        gerek = temel + (say - 1) * stride + n * bs if say else temel
        if gerek > len(binb):
            hata.append("%s: accessor exceeds BIN chunk" % etiket)
            return None, a
        if stride == n * bs:
            arr = np.frombuffer(binb, dtype=dt, count=say * n, offset=temel).reshape(say, n)
        else:                                              # araligi gecmeli: satir satir dilimle
            ham = np.frombuffer(binb, dtype=np.uint8, count=(say - 1) * stride + n * bs, offset=temel)
            pen = np.lib.stride_tricks.as_strided(ham, shape=(say, n * bs), strides=(stride, 1))
            arr = np.ascontiguousarray(pen).view(dt).reshape(say, n)
    if "sparse" in a:                                      # seyrek yamalar (Blender morph/shape key)
        sp = a["sparse"]
        si = sp["indices"]
        sv = sp["values"]
        idt = np.dtype(GY.BILESEN_DTYPE[si["componentType"]])
        ibv = js["bufferViews"][si["bufferView"]]
        vbv = js["bufferViews"][sv["bufferView"]]
        ii = np.frombuffer(binb, dtype=idt, count=sp["count"],
                           offset=ibv.get("byteOffset", 0) + si.get("byteOffset", 0))
        vv = np.frombuffer(binb, dtype=dt, count=sp["count"] * n,
                           offset=vbv.get("byteOffset", 0) + sv.get("byteOffset", 0)).reshape(sp["count"], n)
        arr = np.array(arr, copy=True)
        arr[ii.astype(np.int64)] = vv
    if normalize and a.get("normalized") and dt.kind in "ui":
        enb = float(np.iinfo(dt).max)
        return arr.astype(np.float64) / enb, a
    return arr, a


def _eklem_kimlik_tablosu(sk, dugum_adlari):
    """Skinin eklem indekslerini KEMIK ADI crc32'sine ceviren tablo (dosyalar arasi kiyas icin).
    Adi olmayan eklem kendi indeksinin negatifiyle isaretlenir (asla ada carpismasin)."""
    t = sk.get("_kimlik")
    if t is None:
        t = np.array([(zlib.crc32(dugum_adlari[jn].encode("utf-8", "replace"))
                       if 0 <= jn < len(dugum_adlari) and dugum_adlari[jn] else -(j + 1))
                      for j, jn in enumerate(sk["eklemler"])], dtype=np.int64)
        sk["_kimlik"] = t
    return t


def _quat_matris(q):
    """glTF quaternion (x, y, z, w) -> 3x3 dondurme matrisi."""
    x, y, z, w = [float(v) for v in q]
    nn = x * x + y * y + z * z + w * w
    if nn <= 0:
        return np.eye(3)
    s = 2.0 / nn
    return np.array([
        [1 - s * (y * y + z * z), s * (x * y - z * w), s * (x * z + y * w)],
        [s * (x * y + z * w), 1 - s * (x * x + z * z), s * (y * z - x * w)],
        [s * (x * z - y * w), s * (y * z + x * w), 1 - s * (x * x + y * y)]], dtype=np.float64)


def _dugum_matris(nd):
    """Dugumun YEREL 4x4 matrisi (satir-major, sutun vektore soldan uygulanir: v' = M @ v).
    glTF 'matrix' SUTUN-major saklanir -> reshape(4,4).T. TRS verilirse M = T @ R @ S."""
    if "matrix" in nd:
        return np.array(nd["matrix"], dtype=np.float64).reshape(4, 4).T
    M = np.eye(4)
    if "scale" in nd:
        M[:3, :3] = np.diag(np.array(nd["scale"], dtype=np.float64))
    if "rotation" in nd:
        M = np.eye(4) @ np.block([[_quat_matris(nd["rotation"]), np.zeros((3, 1))],
                                  [np.zeros((1, 3)), np.ones((1, 1))]]) @ M
    if "translation" in nd:
        T = np.eye(4)
        T[:3, 3] = np.array(nd["translation"], dtype=np.float64)
        M = T @ M
    return M


def _dunya_matrisler(js, hata):
    """Her dugumun DUNYA matrisi (sahne koklerinden zincirleme). Dongu korumali."""
    dugumler = js.get("nodes", [])
    n = len(dugumler)
    yerel = [_dugum_matris(nd) for nd in dugumler]
    dunya = [None] * n
    sc = js.get("scenes", [])
    kokler = list(sc[js.get("scene", 0)].get("nodes", [])) if sc else []
    if not kokler:                                        # sahne yoksa ebeveyni olmayan dugumler kok
        cocuk = set()
        for nd in dugumler:
            cocuk.update(nd.get("children", []))
        kokler = [i for i in range(n) if i not in cocuk]
    yigin = [(k, np.eye(4)) for k in kokler]
    gorulen = set()
    while yigin:
        i, ust = yigin.pop()
        if not (0 <= i < n):
            hata.append("node index %d out of range" % i)
            continue
        if i in gorulen:
            hata.append("node %d visited twice (cycle or shared subtree)" % i)
            continue
        gorulen.add(i)
        M = ust @ yerel[i]
        dunya[i] = M
        for c in dugumler[i].get("children", []):
            yigin.append((c, M))
    for i in range(n):
        if dunya[i] is None:                              # sahneye bagli olmayan dugum
            dunya[i] = yerel[i]
    return dunya


def _normal_matris(M):
    """Konum matrisinden normal matrisi: inverse(M3)^T (olcek/yansima dogru tasinir)."""
    M3 = M[:3, :3]
    try:
        return np.linalg.inv(M3).T
    except np.linalg.LinAlgError:
        return M3


def _uygula_nokta(M, P):
    return (P @ M[:3, :3].T) + M[:3, 3]


def _ibm_kayma(parca, F):
    """Skinin IBM TUTARSIZLIGININ bu parcanin vertexlerini kaydirabilecegi maks mesafe (m).
    F: eklem basina fark matrisi (oku icinde kurulur, 0. eklem referans).
    Vertex basina agirlikli toplam alinir -- Blender'in yeniden baglamada biraktigi fark
    tam budur (bkz. baslik "(1d)": olculen ust sinir 1,6115 mm, gozlenen tur-donus 1,61 mm).
    Deri bilgisi olmayan primitif kayma uretmez."""
    maks = 0.0
    for q in parca["primler"]:
        J, W = q.get("eklem"), q.get("agirlik")
        if J is None or W is None or not q.get("NV"):
            continue
        P = np.concatenate([np.asarray(q["pos"], np.float64),
                            np.ones((q["NV"], 1))], axis=1)
        d = np.zeros((q["NV"], 3))
        Jc = np.clip(J, 0, len(F) - 1)
        for s in range(min(Jc.shape[1], W.shape[1])):
            d += W[:, s, None] * np.einsum("nij,nj->ni", F[Jc[:, s]], P)[:, :3]
        n = np.linalg.norm(d, axis=1)
        if n.size:
            maks = max(maks, float(n.max()))
    return maks


# =============================================================== ana okuma
def oku(yol, oyun_uzayi=True):
    """Bir .glb dosyasini okur. Doner:

    {dosya, boyut, sha256, uretici, hatalar[], ok,
     sayim{...}, materyaller[{ad,...}], goruntuler[{ad, bayt}],
     dugum_adlari[], skinler[{ad, eklem_sayisi, skeleton, ibm_satir}],
     parcalar[ {
        ad            : mesh tasiyan DUGUMUN adi (Blender'da nesne adi)
        mesh_ad       : mesh'in adi
        dugum, mesh   : glTF indeksleri
        skinli        : bool
        donusum       : (4,4) uygulanan toplam donusum (dunya + Y-up geri alma)
        donusum_kaynagi: 'skin' | 'dugum'
        skin_tutarsizlik: skinli parcada globalJoint_j@IBM_j eklemler arasi maks sapma
                          (TUM eklemler; bkz. baslik "(1d)")
        ibm_kayma_m   : o tutarsizligin BU parcanin vertexlerini kaydirabilecegi maks
                        mesafe (m); tetigin altindaki saglam dosyada None
        NV, NT        : parcanin toplamlari
        bbox_min/max  : oyun uzayinda parca sinir kutusu (metre)
        primler[ {i, material, material_ad, NV, NT,
                  pos (n,3) f64 OYUN uzayi, nrm (n,3)|None, uv0 (n,2)|None, uv1, renk,
                  eklem (n,k) i64|None, agirlik (n,k) f64|None, tri (t,3) i64,
                  bbox_min, bbox_max, mode} ]
        pos, tri, nrm, uv0 : primitifler ard arda dizilmis PARCA duzeyinde diziler
                             (tri, parca-genelinde vertex indeksler -- mesh_yapisal G['ibg'] gibi)
     } ] }

    oyun_uzayi=False verilirse konumlar HAM glTF uzayinda (dunya donusumu uygulanmadan) kalir."""
    with open(yol, "rb") as f:
        d = f.read()
    hata = []
    out = {"dosya": yol, "boyut": len(d), "sha256": hashlib.sha256(d).hexdigest(),
           "hatalar": hata, "ok": False, "oyun_uzayi": bool(oyun_uzayi), "parcalar": []}
    js, binb = _chunk_ayikla(d, hata)
    if js is None:
        return out
    out["uretici"] = js.get("asset", {}).get("generator")
    out["sayim"] = {k: len(js.get(k, [])) for k in
                    ("accessors", "bufferViews", "meshes", "materials", "textures",
                     "images", "samplers", "skins", "nodes", "scenes")}
    out["sayim"]["primitives"] = sum(len(m.get("primitives", [])) for m in js.get("meshes", []))
    out["materyaller"] = [{"ad": m.get("name"), "alphaMode": m.get("alphaMode", "OPAQUE"),
                           "doubleSided": m.get("doubleSided", False),
                           "baseColorFactor": m.get("pbrMetallicRoughness", {}).get("baseColorFactor")}
                          for m in js.get("materials", [])]
    out["goruntuler"] = [{"ad": im.get("name"), "mime": im.get("mimeType"),
                          "bayt": (js["bufferViews"][im["bufferView"]]["byteLength"]
                                   if "bufferView" in im else None),
                          "uri": im.get("uri")} for im in js.get("images", [])]
    dugumler = js.get("nodes", [])
    out["dugum_adlari"] = [nd.get("name") for nd in dugumler]
    dunya = _dunya_matrisler(js, hata)

    # --- skinler (IBM'ler SATIR-major'a cevrilir) + skinin ETKIN donusumu
    #     glTF spec: skinli mesh'te dugum donusumu YOK SAYILIR; POSITION'in gittigi uzay
    #     `globalJoint_j @ IBM_j` ile verilir (bind'de tum j icin AYNI).
    G_ic = RX_YUP_ZUP if oyun_uzayi else np.eye(4)
    skinler = []
    for si, sk in enumerate(js.get("skins", [])):
        e = {"ad": sk.get("name"), "eklem_sayisi": len(sk.get("joints", [])),
             "skeleton": sk.get("skeleton"), "eklemler": list(sk.get("joints", [])),
             "ibm_satir": None, "etkin": None, "tutarsizlik": None, "kok_yerlesim": None,
             "tutarsizlik_eklem": None, "fark": None}
        # iskelet KOK dugumunun oyun uzayindaki yerlesimi (sahne_yerlesimi'nin tabani;
        # bkz. modul basligi 1c). Yalniz skin.skeleton verilmisse (bizim export'ta hep var).
        kok = sk.get("skeleton")
        if isinstance(kok, int) and 0 <= kok < len(dunya):
            e["kok_yerlesim"] = G_ic @ dunya[kok]
        if "inverseBindMatrices" in sk:
            arr, a = _acc_oku(js, binb, sk["inverseBindMatrices"], hata, "skin %d IBM" % si)
            if arr is not None and a["type"] == "MAT4":
                e["ibm_satir"] = np.transpose(np.asarray(arr, np.float64).reshape(-1, 4, 4), (0, 2, 1))
        if e["ibm_satir"] is not None and e["eklemler"]:
            # TUM eklemler taranir (2026-09-05'e kadar ilk 8'di; bkz. baslik "(1d)":
            # kusur 60. eklemdeydi ve ilk 8 ile GORUNMUYORDU).
            gec = [(j, jn) for j, jn in enumerate(e["eklemler"][:len(e["ibm_satir"])])
                   if 0 <= jn < len(dunya)]
            if gec:
                A = np.stack([dunya[jn] @ e["ibm_satir"][j] for j, jn in gec])
                e["etkin"] = G_ic @ A[0]
                sap = np.abs(A - A[0][None]).reshape(len(A), -1).max(axis=1)
                e["tutarsizlik"] = float(sap.max())
                jw, jnw = gec[int(np.argmax(sap))]
                e["tutarsizlik_eklem"] = (out["dugum_adlari"][jnw]
                                          if 0 <= jnw < len(out["dugum_adlari"]) else None)
                if e["tutarsizlik"] > IBM_OLCUM_TETIK:
                    # Eklem basina FARK matrisi: oyun uzayindaki bir konumu, o eklemin kendi
                    # bind uzayindaki karsiligina goturur (0. eklem referans -> Q_0 = 0).
                    # Konumlara zaten `etkin` uygulandigi icin dogrudan p_oyun'a uygulanir.
                    try:
                        ters = np.linalg.inv(e["etkin"])
                    except np.linalg.LinAlgError:
                        hata.append("skin %d: effective transform not invertible" % si)
                    else:
                        Q = np.einsum("ab,nbc->nac", G_ic, A) @ ters - np.eye(4)[None]
                        F = np.zeros((len(e["eklemler"]), 4, 4))
                        F[[j for j, _ in gec]] = Q
                        e["fark"] = F
        skinler.append(e)
    out["skinler"] = skinler

    # --- kemik BIND matrisleri, PARCA KONUMLARIYLA AYNI UZAYDA.
    #     bind_j = etkin_skin @ inverse(IBM_j). Konumlara da `etkin` uygulandigi icin
    #     kemikler ve vertexler DAIMA ayni uzayda olur -- iki dosyanin kemik BULUTLARI
    #     boylece dogrudan Kabsch ile eslesir (hizala()). `inverse(IBM_j)` tek basina
    #     KULLANILMAZ: kaynak dosyada IBM oyun uzayindadir, Blender'in yazdiginda ise
    #     Y-up dunyada -- ayni G_ic'i ikisine uygulamak 90 derecelik sahte donme uretir
    #     (olculdu: fit artigi 1,7e-6 m ama tamamen yanlis eksende).
    #     Kemik ADI dosya boyunca tekil degilse ILK gorulen kazanir.
    kemik_bind = {}
    for sk in skinler:
        if sk["ibm_satir"] is None or sk["etkin"] is None:
            continue
        for j, jn in enumerate(sk["eklemler"]):
            ad = out["dugum_adlari"][jn] if 0 <= jn < len(out["dugum_adlari"]) else None
            if not ad or ad in kemik_bind or j >= len(sk["ibm_satir"]):
                continue
            try:
                kemik_bind[ad] = sk["etkin"] @ np.linalg.inv(sk["ibm_satir"][j])
            except np.linalg.LinAlgError:
                hata.append("skin joint %s: IBM not invertible" % ad)
    out["kemik_bind"] = kemik_bind
    out["kemik_konum"] = {a: M[:3, 3].copy() for a, M in kemik_bind.items()}

    # --- dugum -> mesh esleme (ayni mesh birden cok dugumde olabilir: her biri ayri parca)
    for ni, nd in enumerate(dugumler):
        if "mesh" not in nd:
            continue
        mi = nd["mesh"]
        if not (0 <= mi < len(js.get("meshes", []))):
            hata.append("node %d mesh %d out of range" % (ni, mi))
            continue
        mesh = js["meshes"][mi]
        skin_idx = nd.get("skin")
        # --- etkin donusum (skinli: skinin `etkin`i; skinsiz/rigid: dugum zinciri)
        if skin_idx is not None and 0 <= skin_idx < len(skinler) and skinler[skin_idx]["etkin"] is not None:
            M = skinler[skin_idx]["etkin"]
            tutarsiz = skinler[skin_idx]["tutarsizlik"]
            kaynak = "skin"
        else:
            M = G_ic @ dunya[ni]
            tutarsiz = None
            kaynak = "dugum"
        Nm = _normal_matris(M)
        p = {"ad": nd.get("name"), "mesh_ad": mesh.get("name"), "dugum": ni, "mesh": mi,
             "skin": skin_idx, "skinli": skin_idx is not None, "donusum": M,
             "donusum_kaynagi": kaynak, "skin_tutarsizlik": tutarsiz, "primler": []}
        taban = 0
        pl, tl, nl, ul = [], [], [], []
        for pi, pr in enumerate(mesh.get("primitives", [])):
            et = "%s prim %d" % (nd.get("name"), pi)
            at = pr.get("attributes", {})
            mod = pr.get("mode", 4)
            if mod != 4:
                hata.append("%s: mode %d != TRIANGLES" % (et, mod))
            q = {"i": pi, "material": pr.get("material"), "mode": mod,
                 "material_ad": (js["materials"][pr["material"]].get("name")
                                 if pr.get("material") is not None
                                 and pr["material"] < len(js.get("materials", [])) else None)}
            if "POSITION" not in at:
                hata.append("%s: no POSITION" % et)
                continue
            pos, pa = _acc_oku(js, binb, at["POSITION"], hata, et + " POSITION")
            if pos is None:
                continue
            pos = _uygula_nokta(M, np.asarray(pos, np.float64))
            nv = len(pos)
            q["NV"] = nv
            q["pos"] = pos
            q["bbox_min"] = [float(x) for x in pos.min(0)] if nv else None
            q["bbox_max"] = [float(x) for x in pos.max(0)] if nv else None
            for ad, anah in (("NORMAL", "nrm"), ("TANGENT", "tan"),
                             ("TEXCOORD_0", "uv0"), ("TEXCOORD_1", "uv1"),
                             ("COLOR_0", "renk")):
                q[anah] = None
                if ad in at:
                    arr, _a = _acc_oku(js, binb, at[ad], hata, et + " " + ad, normalize=True)
                    if arr is None:
                        continue
                    if len(arr) != nv:
                        hata.append("%s: %s count %d != NV %d" % (et, ad, len(arr), nv))
                    arr = np.asarray(arr, np.float64)
                    if ad == "NORMAL":
                        arr = arr @ Nm.T
                        u = np.linalg.norm(arr, axis=1, keepdims=True)
                        arr = np.divide(arr, u, out=np.zeros_like(arr), where=u > 1e-12)
                    elif ad == "TANGENT":
                        # glTF TANGENT vec4: xyz KONUM matrisiyle (normal matrisiyle DEGIL)
                        # tasinir, w el kurali isaretidir ve tasinmaz.
                        if arr.ndim == 2 and arr.shape[1] >= 4:
                            q["tan_w"] = arr[:, 3].copy()
                            arr = arr[:, :3]
                        t = arr @ M[:3, :3].T
                        u = np.linalg.norm(t, axis=1, keepdims=True)
                        arr = np.divide(t, u, out=np.zeros_like(t), where=u > 1e-12)
                    q[anah] = arr
            # --- eklem / agirlik (JOINTS_0/1 + WEIGHTS_0/1 birlestirilir)
            jl, wl = [], []
            for s in range(8):
                if "JOINTS_%d" % s not in at:
                    break
                ja, _ = _acc_oku(js, binb, at["JOINTS_%d" % s], hata, et + " JOINTS_%d" % s)
                if "WEIGHTS_%d" % s not in at:
                    hata.append("%s: JOINTS_%d without WEIGHTS_%d" % (et, s, s))
                    break
                wa, _ = _acc_oku(js, binb, at["WEIGHTS_%d" % s], hata, et + " WEIGHTS_%d" % s,
                                 normalize=True)
                if ja is None or wa is None:
                    break
                jl.append(np.asarray(ja, np.int64))
                wl.append(np.asarray(wa, np.float64))
            q["eklem"] = np.concatenate(jl, 1) if jl else None
            q["agirlik"] = np.concatenate(wl, 1) if wl else None
            # eklem indeksi DOSYAYA OZELDIR (Blender 14 skini tek armature'de birlestirdi:
            # 326 -> 679 eklem, indeksler kaydi). Iki dosya arasinda anahtar olarak
            # kullanilabilmesi icin indeks -> KEMIK ADI crc'sine cevrilir.
            q["eklem_kimlik"] = None
            if q["eklem"] is not None and skin_idx is not None and 0 <= skin_idx < len(skinler):
                tablo = _eklem_kimlik_tablosu(skinler[skin_idx], out["dugum_adlari"])
                gec = np.clip(q["eklem"], 0, len(tablo) - 1) if len(tablo) else None
                q["eklem_kimlik"] = tablo[gec] if gec is not None else None
            # --- indeksler
            if "indices" in pr:
                ia, iaa = _acc_oku(js, binb, pr["indices"], hata, et + " indices")
                idx = np.asarray(ia, np.int64).ravel() if ia is not None else np.zeros(0, np.int64)
                q["indeks_tip"] = {GY.UBYTE: "u8", GY.USHORT: "u16",
                                   GY.UINT: "u32"}.get(iaa["componentType"])
            else:
                idx = np.arange(nv, dtype=np.int64)
                q["indeks_tip"] = None
            if idx.size % 3:
                hata.append("%s: index count %d not a multiple of 3" % (et, idx.size))
                idx = idx[:idx.size - idx.size % 3]
            if idx.size and (idx.min() < 0 or idx.max() >= nv):
                hata.append("%s: index out of range (NV=%d)" % (et, nv))
                idx = np.clip(idx, 0, max(nv - 1, 0))
            tri = idx.reshape(-1, 3)
            q["tri"] = tri
            q["NT"] = len(tri)
            p["primler"].append(q)
            pl.append(pos)
            tl.append(tri + taban)
            nl.append(q["nrm"] if q["nrm"] is not None else np.zeros((nv, 3)))
            ul.append(q["uv0"] if q["uv0"] is not None else np.zeros((nv, 2)))
            taban += nv
        p["NV"] = int(sum(x["NV"] for x in p["primler"]))
        p["NT"] = int(sum(x["NT"] for x in p["primler"]))
        p["pos"] = np.concatenate(pl) if pl else np.zeros((0, 3))
        p["tri"] = np.concatenate(tl) if tl else np.zeros((0, 3), np.int64)
        p["nrm"] = np.concatenate(nl) if nl else np.zeros((0, 3))
        p["uv0"] = np.concatenate(ul) if ul else np.zeros((0, 2))
        p["bbox_min"] = [float(x) for x in p["pos"].min(0)] if p["NV"] else None
        p["bbox_max"] = [float(x) for x in p["pos"].max(0)] if p["NV"] else None
        # (1d) BAYAT EXPORT: skinin IBM tutarsizligi bu parcanin vertexlerini ne kadar
        # kaydirabilir? Tetigin altindaki (saglam) dosyada HIC hesaplanmaz -> ek maliyet yok.
        p["ibm_kayma_m"] = (_ibm_kayma(p, skinler[skin_idx]["fark"])
                            if (skin_idx is not None and 0 <= skin_idx < len(skinler)
                                and skinler[skin_idx].get("fark") is not None) else None)
        out["parcalar"].append(p)
    out["toplam_NV"] = int(sum(p["NV"] for p in out["parcalar"]))
    out["toplam_NT"] = int(sum(p["NT"] for p in out["parcalar"]))
    out["ok"] = not hata
    return out


# =============================================================== vertex eslesmesi
def _nicem(A, basamak):
    """Kayan noktali diziyi tam sayiya nicemler (-0.0 -> 0)."""
    q = np.round(np.asarray(A, np.float64) * (10.0 ** basamak)).astype(np.int64)
    return q + 0


def _perm_anahtardan(ky, kk):
    """Iki anahtar dizisinden (n,k) BIJEKTIF permutasyon: yeni[i] -> kaynak indeksi.
    Anahtarlar iki tarafta da TEKIL degilse (kopya varsa) None doner -- belirsiz esleme
    sessizce yanlis olcum uretmesin diye fail-closed."""
    if ky.shape[0] != kk.shape[0] or ky.shape[1] != kk.shape[1]:
        return None
    n = ky.shape[0]
    if n == 0:
        return np.zeros(0, np.int64)
    ky = np.ascontiguousarray(ky, np.int64)
    kk = np.ascontiguousarray(kk, np.int64)
    hepsi = np.concatenate([ky, kk])
    _u, inv, say = np.unique(hepsi, axis=0, return_inverse=True, return_counts=True)
    inv = inv.ravel()
    gy, gk = inv[:n], inv[n:]
    if say.shape[0] != n:                                # grup sayisi n degilse birebir degil
        return None
    if np.bincount(gy, minlength=len(say)).max() != 1 or np.bincount(gk, minlength=len(say)).max() != 1:
        return None
    g2s = np.empty(len(say), np.int64)
    g2s[gk] = np.arange(n, dtype=np.int64)
    return g2s[gy]


def _deri_anahtar(pr, agirlikla):
    """Vertexin deri baglantisi -> (n, 8) ya da (n, 16) i64 anahtar: kemik ADI crc'sine gore
    SIRALI (yuva sirasi dosyadan dosyaya degisir), agirliksiz yuvalar atilir, 8'e sifir dolgu.
    Oteleme/olcek duzenlemesinden ETKILENMEZ; ayrica ayna UV adalarini (sol/sag bot ayni UV,
    FARKLI kemik) birbirinden ayirir -- 'zor' turunda 10 parcayi cozen sey budur."""
    j = pr.get("eklem_kimlik")
    w = pr.get("agirlik")
    if j is None or w is None:
        return None
    j = np.asarray(j, np.int64)
    wq = np.round(np.asarray(w, np.float64) * 255.0).astype(np.int64)
    j = np.where(wq > 0, j, np.int64(0))
    wq = np.where(wq > 0, wq, np.int64(0))
    sira = np.lexsort((wq, j), axis=1) if j.shape[1] else np.zeros_like(j)
    js = np.take_along_axis(j, sira, 1)
    ws = np.take_along_axis(wq, sira, 1)
    k = 8
    if js.shape[1] < k:
        pad = np.zeros((len(js), k - js.shape[1]), np.int64)
        js, ws = np.concatenate([js, pad], 1), np.concatenate([ws, pad], 1)
    js, ws = js[:, :k], ws[:, :k]
    return np.concatenate([js, ws], 1) if agirlikla else js


def _poz_norm(pos):
    """Konumu agirlik merkezine goturup RMS yaricapa boler: OTELEME ve TEKBICIMLI OLCEK
    altinda degismez. Duzenlenmis (tasinmis/olceklenmis) bir parcada bile anahtar olur."""
    p = np.asarray(pos, np.float64)
    if not len(p):
        return np.zeros((0, 3), np.int64)
    c = p.mean(0)
    d = p - c
    r = float(np.sqrt((d * d).sum() / max(len(p), 1)))
    return _nicem(d / (r if r > 1e-12 else 1.0), 4)


def _anahtar(pr, alanlar):
    """Bir primitiften nicemlenmis anahtar sutunlari toplar; alan eksikse None."""
    sut = []
    for ad in alanlar:
        if ad == "uv0":
            if pr.get("uv0") is None:
                return None
            sut.append(_nicem(pr["uv0"], Q_UV))
        elif ad == "nrm":
            if pr.get("nrm") is None:
                return None
            sut.append(_nicem(pr["nrm"], Q_NRM))
        elif ad in ("deri", "deri_w"):
            k = _deri_anahtar(pr, ad == "deri_w")
            if k is None:
                return None
            sut.append(k)
        elif ad == "pos":
            sut.append(_nicem(pr["pos"], Q_POZ))
        elif ad == "pos_norm":
            sut.append(_poz_norm(pr["pos"]))
        elif ad == "uv1":
            if pr.get("uv1") is None:
                return None
            sut.append(_nicem(pr["uv1"], Q_UV))
    return np.concatenate(sut, 1) if sut else None


def _karistir(x):
    """splitmix64 karistirici -- WL imzalarini toplarken sira bagimsiz ama carpismasiz olsun."""
    u = x.astype(np.uint64) + np.uint64(0x9E3779B97F4A7C15)
    u = (u ^ (u >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
    u = (u ^ (u >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
    return u ^ (u >> np.uint64(31))


def _komsu_csr(tri, nv):
    """Ucgenlerden yonsuz komsuluk (CSR): (sirali_hedef, baslangic_indeksleri)."""
    if not len(tri):
        return np.zeros(0, np.int64), np.zeros(nv + 1, np.int64)
    a = tri[:, [0, 1, 2]].ravel()
    b = tri[:, [1, 2, 0]].ravel()
    src = np.concatenate([a, b])
    dst = np.concatenate([b, a])
    o = np.argsort(src, kind="stable")
    src, dst = src[o], dst[o]
    bas = np.zeros(nv + 1, np.int64)
    np.cumsum(np.bincount(src, minlength=nv), out=bas[1:])
    return dst, bas


def _wl_tur(renk, dst, bas, nv):
    """Bir Weisfeiler-Lehman turu: (kendi rengi, komsu renklerinin coklu kumesi) -> yeni imza."""
    h = _karistir(renk)
    top = np.zeros(nv, np.uint64)
    dolu = bas[1:] > bas[:-1]
    if dolu.any():
        top[dolu] = np.add.reduceat(h[dst], bas[:-1][dolu])
    derece = (bas[1:] - bas[:-1]).astype(np.int64)
    return np.stack([renk.astype(np.int64), derece,
                     top.view(np.int64)], 1)


def _perm_wl(yp, kp, tohum_alanlari=(("uv0", "deri_w"), ("uv0", "deri"), ("uv0",), ("pos_norm",)),
             tur=6):
    """Anahtar TEKIL degilken (ayna UV adalari, kopya vertexler) permutasyonu UCGEN GRAFI
    ile ayirir: baslangic rengi = coklu-kume olarak ESIT olan ilk anahtar, sonra WL turlari.
    Kalan belirsiz sinifalar konuma gore siralanarak eslenir (topoloji kapisi zaten sonra
    dogrular). Doner (perm, yontem) ya da (None, None)."""
    nv = yp["NV"]
    if nv == 0 or yp["NT"] != kp["NT"]:
        return None, None
    tohum = None
    for alanlar in tohum_alanlari:
        ay, ak = _anahtar(yp, alanlar), _anahtar(kp, alanlar)
        if ay is None or ak is None or ay.shape != ak.shape:
            continue
        _u, inv = np.unique(np.concatenate([ay, ak]), axis=0, return_inverse=True)
        inv = inv.ravel()
        gy, gk = inv[:nv], inv[nv:]
        if np.array_equal(np.bincount(gy, minlength=len(_u)), np.bincount(gk, minlength=len(_u))):
            tohum = (gy.astype(np.int64), gk.astype(np.int64), "+".join(alanlar))
            break
    if tohum is None:
        return None, None
    cy, ck, ad = tohum
    dy, by = _komsu_csr(yp["tri"], nv)
    dk, bk = _komsu_csr(kp["tri"], nv)
    onceki = -1
    for _t in range(tur):
        sy = _wl_tur(cy, dy, by, nv)
        sk = _wl_tur(ck, dk, bk, nv)
        _u, inv = np.unique(np.concatenate([sy, sk]), axis=0, return_inverse=True)
        inv = inv.ravel()
        ny, nk = inv[:nv], inv[nv:]
        if not np.array_equal(np.bincount(ny, minlength=len(_u)), np.bincount(nk, minlength=len(_u))):
            break                                   # renkler ayristi ama iki taraf tutmuyor -> dur
        cy, ck = ny.astype(np.int64), nk.astype(np.int64)
        if len(_u) == nv or len(_u) == onceki:
            break
        onceki = len(_u)
    # --- sinif sinif esle; coklu siniflarda konuma gore sirala (deterministik)
    oy = np.lexsort((yp["pos"][:, 2], yp["pos"][:, 1], yp["pos"][:, 0], cy))
    ok = np.lexsort((kp["pos"][:, 2], kp["pos"][:, 1], kp["pos"][:, 0], ck))
    if not np.array_equal(cy[oy], ck[ok]):
        return None, None
    perm = np.empty(nv, np.int64)
    perm[oy] = ok
    tekil = int((np.bincount(cy) == 1).sum())
    return perm, "WL(%s, %d tur, %d/%d tekil sinif)" % (ad, _t + 1, tekil, nv)


def _en_yakin_perm(py, pk):
    """Son care: konumla en yakin komsu (scipy varsa). Bijektif ve esik altinda degilse None."""
    try:
        from scipy.spatial import cKDTree
    except ImportError:
        return None, None
    if len(py) != len(pk) or not len(py):
        return None, None
    dd, ii = cKDTree(pk).query(py)
    if len(np.unique(ii)) != len(ii):
        return None, None
    return ii.astype(np.int64), float(dd.max())


# Anahtar merdiveni: ustteki ADAYLAR duzenlemeden (oteleme/olcek) ETKILENMEZ, alttakiler
# geometriye dayanir. Ilk BIJEKTIF olan kazanir; hicbiri tutmazsa en yakin komsu denenir.
_ANAHTAR_SIRASI = (
    ("uv0",),                      # cogu parcada tek basina yeter
    ("uv0", "deri"),               # ayna UV adalari (sol/sag) kemikle ayrisir
    ("uv0", "deri_w"),             # + agirliklar
    ("uv0", "nrm"),                # deri yoksa (rigid) normal ayirir
    ("uv0", "nrm", "deri"),
    ("uv0", "uv1"),
    ("uv0", "pos_norm"),           # oteleme+tekbicimli olcek altinda degismez
    ("pos_norm",),
    ("uv0", "pos"),                # duzenlenmemis dosyada kesin ayirici
    ("pos",),
)


def _anahtar_surjeksiyon(yeni_pr, kaynak_pr, poz_tol=2e-5, uv_tol=2e-4):
    """GLB'de FAZLA vertex varsa (Blender dikisleri baska boldu) toleransli (konum, uv0)
    eslemesiyle GLB -> kaynak haritasi. Kapsanmayan kaynak vertexleri (kopya ikizi GLB'de tek
    vertexe inmis) ikizine baglanir: kaynak_pr["_ikiz_kanonik"] (nk,) her vertex icin ayni
    (pos,uv) grubunun en kucuk KAPSANAN indeksi (kapsanan kopyalar da ayni kanonige iner).
    Doner perm (len ny) ya da None."""
    ny, nk = yeni_pr["NV"], kaynak_pr["NV"]
    if ny <= nk or nk == 0 or ny - nk > max(64, nk // 50):
        return None                                        # yalniz kucuk, "dikis" farklari
    uy = yeni_pr.get("uv0")
    uk = kaynak_pr.get("uv0")
    if uy is None or uk is None:
        return None
    py = np.asarray(yeni_pr["pos"], np.float64)
    pk = np.asarray(kaynak_pr["pos"], np.float64)
    uy = np.asarray(uy, np.float64)
    uk = np.asarray(uk, np.float64)
    ny_n = yeni_pr.get("nrm")
    nk_n = kaynak_pr.get("nrm")
    perm = np.full(ny, -1, np.int64)
    p2 = poz_tol * poz_tol
    for s in range(0, ny, 256):
        d2 = ((py[s:s + 256, None, :] - pk[None, :, :]) ** 2).sum(-1)      # (c, nk)
        for r in range(d2.shape[0]):
            ad = np.where(d2[r] <= p2)[0]
            if not len(ad):
                return None
            if len(ad) > 1:
                du = np.abs(uk[ad] - uy[s + r]).max(1)
                if (du <= uv_tol).any():
                    ad = ad[du <= uv_tol]
                else:
                    return None
                if len(ad) > 1 and ny_n is not None and nk_n is not None:
                    n_i = np.asarray(ny_n[s + r], np.float64)
                    ad = np.array([max(ad.tolist(), key=lambda j: float(np.dot(n_i, np.asarray(nk_n[j], np.float64))))])
            else:
                if np.abs(uk[ad[0]] - uy[s + r]).max() > uv_tol:
                    return None
            perm[s + r] = ad[0]
    # --- ikiz haritasi: (pos,uv) ayni kaynak vertexleri tek kanonik indekse.
    # Kanonik = grubun EN KUCUK KAPSANAN indeksi. Iki is birden gorur:
    #   * kapsanmayan kopya (Blender'in tek vertexe indirdigi ikiz) kapsanan ikizine
    #     baglanir -> `mesh_ithal._ayni_diziler` konumunu oradan doldurur (kapsanan olmali);
    #   * KAPSANAN kopyalar da ayni kanonige iner -> `eslestir`in ucgen kumesi kiyasi
    #     ikiz-indeks secimine duyarsiz olur.
    # Eski surumde ikinci is bos bir dongude kalmisti (2026-09-05'te olculdu, Blender 5.2
    # kimlik turu, Weapon_Pistol_11 LOD0: 395 kopyanin 249'u kapsanan ikizdi; 34 ucgen
    # yalniz ikiz secimiyle "farkli" cikiyor ve dokunulmamis parca CHANGED sayilip
    # kume-siz rijit bicimde yeniden kuruluyordu). Tam kanonik eslemeyle iki kume birebir.
    kapsanan = np.zeros(nk, bool)
    kapsanan[perm] = True
    grup = np.arange(nk, dtype=np.int64)
    n2k = (pk * pk).sum(1)
    for s in range(0, nk, 128):
        blok = pk[s:s + 128]
        # |a-b|^2 = |a|^2 + |b|^2 - 2 a.b  ((c,nk) ara dizi; (c,nk,3) yerine)
        d2 = n2k[s:s + 128, None] + n2k[None, :] - 2.0 * (blok @ pk.T)
        yakin = d2 <= p2
        rr, cc = np.nonzero(yakin)
        if len(rr):
            uzak = np.abs(uk[cc] - uk[s + rr]).max(1) > uv_tol
            yakin[rr[uzak], cc[uzak]] = False
        yakin[np.arange(len(blok)), np.arange(s, s + len(blok))] = True     # kendisi daima (f64 gurultusu)
        grup[s:s + len(blok)] = np.argmax(yakin, axis=1)      # ilk True = en kucuk indeks
    while True:                                                # tolerans gecisken degil: zinciri kapat
        g2 = grup[grup]
        if np.array_equal(g2, grup):
            break
        grup = g2
    temsil = np.full(nk, nk, np.int64)
    np.minimum.at(temsil, grup[kapsanan], np.where(kapsanan)[0])
    ikiz = temsil[grup]
    if (ikiz >= nk).any():
        return None                                    # gercekten kayip vertex: grubunda kapsanan yok
    kaynak_pr["_ikiz_kanonik"] = ikiz
    return perm


def vertex_perm(yeni_pr, kaynak_pr):
    """Yeni primitifin vertexlerini kaynagin vertexlerine baglar.
    Doner (perm, yontem): perm[i] = kaynaktaki indeks; kurulamazsa (None, sebep).
    NV farkliysa ve fark yalniz Blender'in dikis bolmesinden geliyorsa (konum,uv0) anahtarli
    SURJEKSIYON doner (len = yeni NV; kaynak vertexleri birden cok kez gecebilir)."""
    ny, nk = yeni_pr["NV"], kaynak_pr["NV"]
    if ny != nk:
        s = _anahtar_surjeksiyon(yeni_pr, kaynak_pr)
        if s is not None:
            return s, "anahtar surjeksiyonu (GLB %d -> oyun %d, dikis kopyalari)" % (ny, nk)
        return None, "NV %d != %d" % (ny, nk)
    if ny == 0:
        return np.zeros(0, np.int64), "bos"
    # 1) ucgen dizisi birebir ayni -> vertex sirasi da ayni (Blender bunu nadiren korur ama bedava)
    if (yeni_pr["NT"] == kaynak_pr["NT"] and yeni_pr["NT"]
            and np.array_equal(yeni_pr["tri"], kaynak_pr["tri"])):
        return np.arange(ny, dtype=np.int64), "birim (indeks tamponu birebir)"
    for alanlar in _ANAHTAR_SIRASI:
        ky = _anahtar(yeni_pr, alanlar)
        kk = _anahtar(kaynak_pr, alanlar)
        if ky is None or kk is None:
            continue
        p = _perm_anahtardan(ky, kk)
        if p is not None:
            return p, "+".join(alanlar)
    p, yontem = _perm_wl(yeni_pr, kaynak_pr)         # anahtar tekil degilse ucgen grafiyle ayir
    if p is not None:
        return p, yontem
    p, dmaks = _en_yakin_perm(yeni_pr["pos"], kaynak_pr["pos"])
    if p is not None and dmaks is not None and dmaks <= EN_YAKIN_ESIK:
        return p, "en yakin komsu (%.2g m)" % dmaks
    return None, "permutasyon bulunamadi"


def _kanonik(tri):
    """Ucgen dizisini kanonik hale getirir: her ucgenin kose sirasi + ucgenlerin sirasi sabitlenir."""
    if not len(tri):
        return tri.reshape(0, 3)
    t = np.sort(np.asarray(tri, np.int64), axis=1)
    return t[np.lexsort((t[:, 2], t[:, 1], t[:, 0]))]


def _kopya_dususu(ay, ak):
    """NT farkliyken: fark YALNIZ kaynaktaki KOPYA ucgenlerin (ayni 3 vertex) dusmesi mi?

    Blender'in glTF importeri `mesh.validate()` ile primitive ici kopya yuzleri ATAR; oyun
    mesh'leri bunlari tasiyabilir (olculdu 2026-09-05: Weapon_Pistol_01 Small 206/16857
    sirali-birebir kopya, sahne.py'nin manifest'e yazdigi `yinelenen_ucgen` ile ayni sayi;
    Yasuke Armorplate 1). Eski surum bunu "NT 16651 != 16857" ile CHANGED sayip 206 vanilla
    ucgeni EKSIK bir mesh yazmaya hazirlaniyordu.

    ay, ak : `_kanonik` ciktilari (yeni / kaynak; surjeksiyonda ikiz-kanonik indeksli).
    Kosul (coklu-kume): iki tarafin benzersiz ucgen KUMESI birebir esit ve hicbir ucgen
    yeni tarafta kaynaktakinden FAZLA tekrarlanmiyor. Yeni tarafta kopya kalabilir: Blender
    yalniz ayni Blender-vertex-indeksli kopyayi atar, (pos,uv) ikizi uzerinden kurulan
    kopyayi tutar (olculdu: Pistol_01 Small, kanonik 210 kopyanin 206'si dustu, 4'u kaldi).
    Degilse None (fail-closed: gercek bir ucgen silinmisse/eklenmisse CHANGED kalir).
    Doner: dusen kopya sayisi."""
    if not len(ay) or len(ay) >= len(ak):
        return None
    _u, inv = np.unique(np.concatenate([ay, ak]), axis=0, return_inverse=True)
    inv = inv.ravel()
    cy = np.bincount(inv[:len(ay)], minlength=len(_u))
    ck = np.bincount(inv[len(ay):], minlength=len(_u))
    if (cy == 0).any() or (ck == 0).any():
        return None                                        # ucgen kumesi farkli (silme/ekleme)
    if (cy > ck).any():
        return None                                        # yeni tarafta fazladan tekrar: eklenmis
    return int((ck - cy).sum())


def _donusum_tahmini(py, pk):
    """Eslesmis konumlardan oteleme + tekbicimli olcek tahmini + artik hata (metre)."""
    if not len(py):
        return None
    cy, ck = py.mean(0), pk.mean(0)
    dy, dk = py - cy, pk - ck
    payda = float((dk * dk).sum())
    s = float((dy * dk).sum() / payda) if payda > 1e-18 else 1.0
    artik = float(np.linalg.norm(dy - s * dk, axis=1).max())
    return {"oteleme_m": [float(x) for x in (cy - s * ck)],
            "oteleme_buyuklugu_m": float(np.linalg.norm(cy - s * ck)),
            "olcek": s, "olcek_sonrasi_artik_maks_m": artik}


def _kaba_donusum(py, pk, ayrim=1.2, carpiklik_esik=0.1):
    """Vertex eslemesi OLMADAN iki nokta bulutu arasindaki kaba benzerlik donusumu (oteleme +
    tekbicimli olcek + donme). Esleme kurulamayan CHANGED parcalarda onay ekranina "ne
    degisti"yi soylemek icin; sonuc bir TAHMINDIR, yazma karari bundan etkilenmez.

    Yontem (permutasyona duyarsiz buyuklukler):
      olcek    = RMS yaricap orani (agirlik merkezine gore) -- donme/otelemeden bagimsiz
      donme    = kovaryans ana eksenleri (eigh); eksen ISARETLERI ucuncu momentin (carpiklik)
                 isaretiyle cozulur, tek belirsiz eksen det=+1 ile sabitlenir; birden cok eksen
                 belirsizse (simetrik govde) ya da isaretler yansima veriyorsa yalniz EN BUYUK
                 eksenin katlanmis acisi (0-90 derece) verilir; o da ayrik degilse None
      oteleme  = merkez_y - olcek * R @ merkez_k   (R cozulmediyse R = birim)
      bbox_boy_orani = eksen basina sinir kutusu boyu orani (donme yoksa eksenel olcek)
    Olculdu (2026-09-05, Blender 5.2, Weapon_Pistol_11 LOD0, 7 senaryo): 5 cm tasima -> 50,0 mm;
    2x / 0,5x -> olcek 2,000 / 0,500, oteleme 0; 90 derece donme -> 90,0 derece, oteleme 0,0 mm;
    tek vertex 3 mm -> merkez 0,4 mm, olcek 1,000, aci 0,01 (yerel duzenleme). Doner sozluk ya da
    None (4'ten az nokta / sifir yaricap)."""
    py = np.asarray(py, np.float64)
    pk = np.asarray(pk, np.float64)
    if len(py) < 4 or len(pk) < 4:
        return None
    cy, ck = py.mean(0), pk.mean(0)
    dy, dk = py - cy, pk - ck
    ry = float(np.sqrt((dy * dy).sum(1).mean()))
    rk = float(np.sqrt((dk * dk).sum(1).mean()))
    if rk <= 1e-9 or ry <= 1e-9:
        return None
    s = ry / rk
    boy_y, boy_k = py.max(0) - py.min(0), pk.max(0) - pk.min(0)
    boy_orani = [float(boy_y[i] / boy_k[i]) if boy_k[i] > 1e-9 else None for i in range(3)]
    wy, Vy = np.linalg.eigh(dy.T @ dy / len(dy))
    wk, Vk = np.linalg.eigh(dk.T @ dk / len(dk))
    wy, Vy, wk, Vk = np.maximum(wy[::-1], 0.0), Vy[:, ::-1], np.maximum(wk[::-1], 0.0), Vk[:, ::-1]
    R, aci, aci_yontemi = None, None, None
    ayrik = (wk[2] > 1e-18 and wy[2] > 1e-18
             and all(wk[i] >= ayrim * wk[i + 1] and wy[i] >= ayrim * wy[i + 1] for i in range(2)))
    if ayrik:
        sy = ((dy @ Vy) ** 3).mean(0) / wy ** 1.5           # carpiklik: isaretli, olcekten bagimsiz
        sk = ((dk @ Vk) ** 3).mean(0) / wk ** 1.5
        S = np.ones(3)
        belirsiz = []
        for i in range(3):
            if abs(sy[i]) > carpiklik_esik and abs(sk[i]) > carpiklik_esik:
                S[i] = 1.0 if (sy[i] > 0) == (sk[i] > 0) else -1.0
            else:
                belirsiz.append(i)
        if len(belirsiz) == 1:
            if np.linalg.det(Vy @ np.diag(S) @ Vk.T) < 0:
                S[belirsiz[0]] = -1.0                        # det=+1 belirsiz ekseni sabitler
            belirsiz = []
        if not belirsiz:
            Rk = Vy @ np.diag(S) @ Vk.T
            if np.linalg.det(Rk) > 0:                        # yansima cikarsa cozulmemis say
                R = Rk
                iz = float(np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0))
                aci = float(np.degrees(np.arccos(iz)))
                aci_yontemi = "ana eksenler + carpiklik isareti"
    if R is None and wk[1] > 1e-18 and wy[1] > 1e-18 \
            and wk[0] >= 1.5 * wk[1] and wy[0] >= 1.5 * wy[1]:
        c = min(1.0, abs(float(Vy[:, 0] @ Vk[:, 0])))
        aci = float(np.degrees(np.arccos(c)))
        aci_yontemi = "en buyuk eksen (katlanmis 0-90)"
    ot = cy - s * ((R @ ck) if R is not None else ck)
    return {"merkez_kayma_m": [float(x) for x in (cy - ck)],
            "merkez_kayma_buyuklugu_m": float(np.linalg.norm(cy - ck)),
            "olcek": float(s), "bbox_boy_orani": boy_orani,
            "aci_derece": aci, "aci_yontemi": aci_yontemi,
            "oteleme_m": [float(x) for x in ot],
            "oteleme_buyuklugu_m": float(np.linalg.norm(ot)),
            "nokta": [int(len(py)), int(len(pk))]}


# =============================================================== iskelet hizalamasi
def _kabsch(P, Q):
    """|R@P + t - Q| en kucuk yapan KATI donusumu bulur (yansima duzeltmeli SVD).
    Doner (A 4x4, artik_maks, artik_rms, olcek_tahmini)."""
    cp, cq = P.mean(0), Q.mean(0)
    X, Y = P - cp, Q - cq
    U, S, Vt = np.linalg.svd(X.T @ Y)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    D = np.diag([1.0, 1.0, d])
    R = Vt.T @ D @ U.T
    t = cq - R @ cp
    A = np.eye(4)
    A[:3, :3] = R
    A[:3, 3] = t
    art = np.linalg.norm((P @ R.T + t) - Q, axis=1)
    var = float((X * X).sum())
    olcek = float((S * np.array([1.0, 1.0, d])).sum() / var) if var > 1e-18 else 1.0
    return A, float(art.max()), float(np.sqrt((art ** 2).mean())), olcek


def _mesh_hizala(yeni, kaynak, en_az_nokta=200, kabul_rms_m=5e-3, ornek=40000):
    """KEMIK YOKKEN kati donusumu MESH'lerin kendisinden cikarir.

    Neden var: Blender'da armature'u silmek yaygin (kullanicilar onu "garip yuvarlak
    seyler" saniyor). Armature gidince skin de gider, mesh'ler kaynak uzayindan KATI
    bir donusumle kayar. Olculen ornek: Diplomat kiyafeti, X ekseninde 4,7787 derece
    saf donme, oteleme 0, artik 0,036 mm rms. Hizalama yapilmazsa bu kayma
    "kullanici 154 mm oynatti" diye yazilir ve karakter oyunda parcalanir.

    Yontem: adi ayni parcalarin NV'si ESIT primitiflerini `vertex_perm` ile baglar,
    havuzda Kabsch cozer, sonra ARTIGA GORE BUDAYIP yeniden fitler -- kullanicinin
    GERCEK duzenlemesi (bir yeri sisirmesi) fite sizmasin diye. Olcek yalniz OLCULUR,
    uygulanmaz (kemik yolundaki politikanin aynisi).

    Fit guvenilmezse (artik buyuk, nokta az) A=birim ve 'yok...' yontemi doner --
    cagiran taraf bunu bir RED sebebi olarak kullanir, sessizce yazmaz.
    """
    bos = {"A": np.eye(4), "kemik": 0, "artik_maks_m": None, "artik_rms_m": None,
           "olcek_tahmini": None, "oteleme_m": None, "aci_derece": None,
           "nokta": 0, "prim": 0}
    try:
        pe = _parca_esle(yeni, kaynak)
    except Exception:                                          # noqa: BLE001
        pe = {}
    if not pe:
        d = dict(bos); d["yontem"] = "yok (parca eslesmedi)"
        return d
    PY, PK = [], []
    kullanilan_prim = 0
    for yi, (ki, _y) in pe.items():
        if ki is None:
            continue
        y = yeni["parcalar"][yi]
        k = kaynak["parcalar"][ki]
        pm = _prim_esle(y["primler"], k["primler"])
        for pi, yp in enumerate(y["primler"]):
            kpi = pm.get(pi)
            if kpi is None:
                continue
            kp = k["primler"][kpi]
            if yp["NV"] != kp["NV"] or yp["NV"] < 4:
                continue                                        # yeniden modellenmis: fite girmez
            perm, _ = vertex_perm(yp, kp)
            if perm is None:
                continue
            PY.append(np.asarray(yp["pos"], np.float64))
            PK.append(np.asarray(kp["pos"], np.float64)[perm])
            kullanilan_prim += 1
    if not PY:
        d = dict(bos); d["yontem"] = "yok (esit vertexli primitif yok)"
        return d
    P = np.concatenate(PY)
    Q = np.concatenate(PK)
    if len(P) < en_az_nokta:
        d = dict(bos); d["yontem"] = "yok (nokta %d < %d)" % (len(P), en_az_nokta)
        d["nokta"] = len(P); d["prim"] = kullanilan_prim
        return d
    if len(P) > ornek:                                          # buyuk kiyafette hiz icin seyrelt
        idx = np.linspace(0, len(P) - 1, ornek).astype(np.int64)
        P, Q = P[idx], Q[idx]
    # rank kontrolu: tum noktalar bir dogru/duzlem uzerindeyse donme belirsizdir
    if np.linalg.matrix_rank(P - P.mean(0), tol=1e-6) < 3:
        d = dict(bos); d["yontem"] = "yok (noktalar es duzlemli)"
        d["nokta"] = len(P); d["prim"] = kullanilan_prim
        return d
    A, amax, arms, olcek = _kabsch(P, Q)
    # --- BUDAMA: kullanicinin gercek duzenlemesini fitten at, sonra yeniden coz
    for _ in range(2):
        art = np.linalg.norm(P @ A[:3, :3].T + A[:3, 3] - Q, axis=1)
        ort = float(np.median(art))
        esik = max(2e-3, 4.0 * ort)
        tut = art <= esik
        if tut.sum() < max(en_az_nokta, int(0.2 * len(P))) or tut.all():
            break
        P, Q = P[tut], Q[tut]
        A, amax, arms, olcek = _kabsch(P, Q)
    iz = float(np.clip((np.trace(A[:3, :3]) - 1.0) / 2.0, -1.0, 1.0))
    ok = (arms is not None and arms <= kabul_rms_m)
    return {"A": A if ok else np.eye(4),
            "yontem": ("mesh (kemik yok)" if ok else
                       "yok (mesh artigi %.1f mm > %.1f mm)" % ((arms or 0) * 1000,
                                                               kabul_rms_m * 1000)),
            "kemik": 0, "artik_maks_m": amax, "artik_rms_m": arms,
            "olcek_tahmini": olcek, "oteleme_m": [float(x) for x in A[:3, 3]],
            "aci_derece": float(np.degrees(np.arccos(iz))),
            "nokta": int(len(P)), "prim": kullanilan_prim}


def hizala(yeni, kaynak, en_az_kemik=3):
    """Kaynak ve yeni sahnenin ADI AYNI kemiklerinin bind konumlarindan, yeni sahneyi
    kaynagin uzayina tasiyan KATI donusumu cikarir (bkz. modul basligi 1b).

    Kemik konumlari mesh duzenlemesinden bagimsizdir; kullanicinin 2 cm'lik otelemesi
    buraya sizmaz. Olcek FITLENMEZ, yalniz olculur -- armature'u olceklemis bir kullanici
    'olcek_tahmini' ile gorulur. Doner:
        {"A": (4,4), "yontem", "kemik", "artik_maks_m", "artik_rms_m", "olcek_tahmini",
         "oteleme_m", "aci_derece"}"""
    ky = yeni.get("kemik_konum") or {}
    kk = kaynak.get("kemik_konum") or {}
    ortak = [a for a in ky if a in kk]
    if len(ortak) < en_az_kemik:
        sade_y = {}
        for a, v in ky.items():
            sade_y.setdefault(_ad_sadelestir(a), (a, v))
        sade_k = {}
        for a, v in kk.items():
            sade_k.setdefault(_ad_sadelestir(a), (a, v))
        cift = [(sade_y[s][1], sade_k[s][1]) for s in sade_y if s in sade_k]
        if len(cift) < en_az_kemik:
            # Kemik yok: armature silinmis olabilir (yaygin). Mesh'lerden coz.
            mh = _mesh_hizala(yeni, kaynak)
            mh["kemik_sebep"] = "ortak kemik %d < %d" % (len(cift), en_az_kemik)
            return mh
        P = np.array([c[0] for c in cift], np.float64)
        Q = np.array([c[1] for c in cift], np.float64)
        yontem = "kemik adi (sadelestirilmis)"
    else:
        P = np.array([ky[a] for a in ortak], np.float64)
        Q = np.array([kk[a] for a in ortak], np.float64)
        yontem = "kemik adi"
    if len(P) < en_az_kemik or np.linalg.matrix_rank(P - P.mean(0), tol=1e-6) < 2:
        mh = _mesh_hizala(yeni, kaynak)
        mh["kemik_sebep"] = "kemikler dogrusal (%d)" % len(P)
        return mh
    A, amax, arms, olcek = _kabsch(P, Q)
    iz = float(np.clip((np.trace(A[:3, :3]) - 1.0) / 2.0, -1.0, 1.0))
    return {"A": A, "yontem": yontem, "kemik": len(P), "artik_maks_m": amax, "artik_rms_m": arms,
            "olcek_tahmini": olcek, "oteleme_m": [float(x) for x in A[:3, 3]],
            "aci_derece": float(np.degrees(np.arccos(iz)))}


def _kati_aci_oteleme(E):
    """4x4 kati donusumun donme acisi (derece) ve oteleme vektoru (metre)."""
    iz = float(np.clip((np.trace(E[:3, :3]) - 1.0) / 2.0, -1.0, 1.0))
    t = [float(x) for x in E[:3, 3]]
    return float(np.degrees(np.arccos(iz))), t, float(np.linalg.norm(E[:3, 3]))


def sahne_yerlesimi(hiz, kaynak, birim_aci_derece=1e-3, birim_oteleme_m=1e-5):
    """Hizalamanin GERI ALDIGI donusumun KULLANICIYA AIT kismi = sahne yerlesimi
    (butun model Blender'da tasindi/donduruldu mu, ya da baska up ekseniyle export edildi mi).
    Bkz. modul basligi 1c. Hicbir seyi degistirmez; cagiran taraf (mesh_ithal.plan) bunu
    yalniz NOT olarak kullanir -- yazma karari buna bakmaz.

    Doner None (hizalama yok/kapali: A birim ve anlamsiz) ya da
        {"taban": "birim" | "iskelet koku" | "birim (A zaten birim)",
         "aci_derece", "oteleme_m": [x,y,z], "oteleme_buyuklugu_m"}"""
    yontem = str(hiz.get("yontem") or "")
    if yontem.startswith("yok") or yontem == "kapali" or hiz.get("A") is None:
        return None
    A = np.asarray(hiz["A"], np.float64)
    aci_A, _t, buy_A = _kati_aci_oteleme(A)
    if int(hiz.get("kemik") or 0) > 0:
        M = None
        for sk in kaynak.get("skinler") or []:
            if sk.get("kok_yerlesim") is not None:
                M = np.asarray(sk["kok_yerlesim"], np.float64)
                break
        if aci_A <= birim_aci_derece and buy_A <= birim_oteleme_m:
            E, taban = np.eye(4), "birim (A zaten birim)"
        elif M is None:
            return None                              # taban bilinmiyor: susmak yanlis alarmdan iyi
        else:
            E, taban = M @ A, "iskelet koku"
    else:
        E, taban = A, "birim"
    aci, t, buy = _kati_aci_oteleme(E)
    return {"taban": taban, "aci_derece": aci, "oteleme_m": t, "oteleme_buyuklugu_m": buy}


def donusum_uygula(sahne, A):
    """Sahnenin tum konum/normal dizilerini (parca ve primitif duzeyinde) A ile YERINDE
    donusturur ve sinir kutularini tazeler. A birim ise hicbir sey yapmaz."""
    A = np.asarray(A, np.float64)
    if np.allclose(A, np.eye(4)):
        return sahne
    Nm = _normal_matris(A)
    for p in sahne["parcalar"]:
        for q in p["primler"]:
            q["pos"] = _uygula_nokta(A, q["pos"])
            q["bbox_min"] = [float(x) for x in q["pos"].min(0)] if q["NV"] else None
            q["bbox_max"] = [float(x) for x in q["pos"].max(0)] if q["NV"] else None
            if q.get("nrm") is not None:
                n = q["nrm"] @ Nm.T
                u = np.linalg.norm(n, axis=1, keepdims=True)
                q["nrm"] = np.divide(n, u, out=np.zeros_like(n), where=u > 1e-12)
            if q.get("tan") is not None:                  # tanjant KONUM gibi tasinir
                t = q["tan"] @ A[:3, :3].T
                u = np.linalg.norm(t, axis=1, keepdims=True)
                q["tan"] = np.divide(t, u, out=np.zeros_like(t), where=u > 1e-12)
        p["pos"] = _uygula_nokta(A, p["pos"])
        p["nrm"] = p["nrm"] @ Nm.T
        p["donusum"] = A @ p["donusum"]
        p["bbox_min"] = [float(x) for x in p["pos"].min(0)] if p["NV"] else None
        p["bbox_max"] = [float(x) for x in p["pos"].max(0)] if p["NV"] else None
    for a in list(sahne.get("kemik_bind", {})):
        sahne["kemik_bind"][a] = A @ sahne["kemik_bind"][a]
        sahne["kemik_konum"][a] = sahne["kemik_bind"][a][:3, 3].copy()
    onceki = np.asarray(sahne.get("hizalama_matrisi", np.eye(4)), np.float64)
    sahne["hizalama_matrisi"] = A @ onceki           # birikimli (birden fazla cagrilirsa)
    return sahne


# =============================================================== eslestirme
def _ad_sadelestir(ad):
    """Blender'in ekledigi '.001' sonekini ve buyuk/kucuk harfi atar."""
    if not ad:
        return ""
    a = str(ad)
    if len(a) > 4 and a[-4] == "." and a[-3:].isdigit():
        a = a[:-4]
    return a.strip().lower()


def _geometri_imza_puani(y, k):
    """Iki parca arasinda geometri imzasi uzakligi (kucuk = iyi). NV/NT agirlikli + bbox."""
    nv = abs(y["NV"] - k["NV"]) / max(k["NV"], 1)
    nt = abs(y["NT"] - k["NT"]) / max(k["NT"], 1)
    bb = 0.0
    if y["bbox_min"] and k["bbox_min"]:
        bb = float(max(np.abs(np.array(y["bbox_min"]) - np.array(k["bbox_min"])).max(),
                       np.abs(np.array(y["bbox_max"]) - np.array(k["bbox_max"])).max()))
    return 4.0 * nv + 4.0 * nt + bb


def _kaynak_ad_indeksi(kaynak):
    """Kaynak parca adi / mesh adi (ve sadelestirilmis halleri) -> kaynak parca indeksi."""
    kaynak_ad = {}
    for i, k in enumerate(kaynak["parcalar"]):
        for anah in (k["ad"], k["mesh_ad"]):
            if anah:
                kaynak_ad.setdefault(anah, i)
                kaynak_ad.setdefault(_ad_sadelestir(anah), i)
    return kaynak_ad


def _ad_coz(kaynak_ad, ad):
    """Tek bir adi (once birebir, sonra '.001'siz/kucuk harf) kaynak indeksine cozer; yoksa None."""
    if not ad:
        return None
    if ad in kaynak_ad:
        return kaynak_ad[ad]
    return kaynak_ad.get(_ad_sadelestir(ad))


def ad_celiskileri(yeni, kaynak):
    """K-4 sinyal (i): NESNE adi ile MESH adi iki FARKLI kaynak parcaya cozuluyorsa celiski.

    Blender'da outliner'dan yalniz nesne adi degistirilince mesh verisi eski adini tasir
    (senaryo 10a: nesne Boots -> mesh_ad Pants, nesne Pants -> mesh_ad Boots). _parca_esle
    ilk 'ad' isabetinde durur ve mesh_ad'a bakmaz; bu fonksiyon o bilgiyi kaybetmez.
    Kaynak export'ta 6/6 parcada mesh_ad == ad olculdu ve Blender 5.2 tur-donusu bunu
    koruyor; '.001' soneki sadelestirmeyle dusuyor -> kopyalanmis nesne celiski uretmez.
    Doner {yeni_idx: {"ad_kaynak": <kaynak ad>, "mesh_ad_kaynak": <kaynak ad>}}."""
    kaynak_ad = _kaynak_ad_indeksi(kaynak)
    out = {}
    for i, y in enumerate(yeni["parcalar"]):
        ia = _ad_coz(kaynak_ad, y.get("ad"))
        im = _ad_coz(kaynak_ad, y.get("mesh_ad"))
        if ia is not None and im is not None and ia != im:
            out[i] = {"ad_kaynak": kaynak["parcalar"][ia]["ad"],
                      "mesh_ad_kaynak": kaynak["parcalar"][im]["ad"]}
    return out


def takas_imzalari(kayitlar):
    """K-4 sinyal (ii): ADLA eslesmis ve CHANGED iki parcanin NV ve NT'si CAPRAZ birebirse
    (NV_y(A)==NV_k(B), NV_y(B)==NV_k(A); NT ayni sekilde) bu bir AD TAKASI imzasidir.
    Kaynak sayilari zaten ayniysa takas ayirt edilemez, imza sayilmaz. Imzayla ya da
    2-opt'la baglanan parcalar disarida: onlarin takasini 2-opt zaten duzeltir.
    Olculdu (2026-09-05): 10a/10b Boots<->Pants 4832/2304, 10c Brow<->HeadAcc 3282/1530 +
    2188/2840 -> ucunde de tek cift; kimlik/subdivide/join senaryolarinda sifir.
    Kayitlara `takas_imzasi` = diger parcanin adi yazilir; doner [(i, j)]."""
    aday = [i for i, r in enumerate(kayitlar)
            if r.get("kaynak_ad") is not None and r.get("topoloji") == CHANGED
            and str(r.get("eslesme_yontemi") or "").startswith(("ad", "mesh_ad"))]
    ciftler = []
    for a in range(len(aday)):
        for b in range(a + 1, len(aday)):
            A, B = kayitlar[aday[a]], kayitlar[aday[b]]
            if (A["kaynak_NV"], A["kaynak_NT"]) == (B["kaynak_NV"], B["kaynak_NT"]):
                continue
            if (A["NV"] == B["kaynak_NV"] and B["NV"] == A["kaynak_NV"]
                    and A["NT"] == B["kaynak_NT"] and B["NT"] == A["kaynak_NT"]):
                ciftler.append((aday[a], aday[b]))
    for a, b in ciftler:
        kayitlar[a]["takas_imzasi"] = kayitlar[b]["ad"]
        kayitlar[b]["takas_imzasi"] = kayitlar[a]["ad"]
    return ciftler


def _parca_esle(yeni, kaynak):
    """Parcalari once ADLA, kalanlari GEOMETRI IMZASIYLA baglar. Doner {yeni_idx: (kaynak_idx, yontem)}."""
    esleme = {}
    kullanilan = set()
    kaynak_ad = _kaynak_ad_indeksi(kaynak)
    for i, y in enumerate(yeni["parcalar"]):
        for anah, yontem in ((y["ad"], "ad"), (y["mesh_ad"], "mesh_ad"),
                             (_ad_sadelestir(y["ad"]), "ad_sadelestirilmis"),
                             (_ad_sadelestir(y["mesh_ad"]), "mesh_ad_sadelestirilmis")):
            if anah and anah in kaynak_ad and kaynak_ad[anah] not in kullanilan:
                esleme[i] = (kaynak_ad[anah], yontem)
                kullanilan.add(kaynak_ad[anah])
                break
    kalan_y = [i for i in range(len(yeni["parcalar"])) if i not in esleme]
    kalan_k = [i for i in range(len(kaynak["parcalar"])) if i not in kullanilan]
    # geometri imzasi: en iyi ciftten baslayarak acgozlu bagla
    ciftler = sorted(((_geometri_imza_puani(yeni["parcalar"][a], kaynak["parcalar"][b]), a, b)
                      for a in kalan_y for b in kalan_k), key=lambda t: t[0])
    ky, kk = set(), set()
    for puan, a, b in ciftler:
        if a in ky or b in kk:
            continue
        esleme[a] = (b, "geometri imzasi (puan %.4g)" % puan)
        ky.add(a)
        kk.add(b)
    # --- 2-opt duzeltmesi: ADLAR YER DEGISTIRMISSE (kullanici iki nesnenin adini takas etti)
    #     ad eslesmesi sessizce yanlis parcayi baglar. Yalnizca KABA iyilesme varsa takas
    #     edilir (esik 0,5; 2 cm oteleme ~0,02, %5 olcek ~0,05 puan uretir -- onlar dokunulmaz).
    # K-2 (2026-09-05, Blender senaryo 14 ile olculdu): bir parca SUBDIVIDE edilince NV/NT
    # terimleri 10-25 puan uretiyor ve takas AD ESLESMESINI EZIYORDU -- dokunulmamis Head
    # mesh'i Pocket'in arsiv girisine yazilacakti. Ad, kullanicinin acik talimatidir:
    # adla eslesen parca ASLA takas edilmez; takas yalniz imzayla baglanan (adsiz/yeniden
    # adlandirilmis) parcalar arasinda yapilir.
    def _takas_edilebilir(i):
        y = esleme[i][1] or ""
        return y.startswith("geometri imzasi") or y.startswith("2-opt")
    for _tur in range(len(esleme)):
        en_iyi = None
        anahtarlar = [i for i in esleme if _takas_edilebilir(i)]
        for ii in range(len(anahtarlar)):
            for jj in range(ii + 1, len(anahtarlar)):
                a, b = anahtarlar[ii], anahtarlar[jj]
                ka, kb = esleme[a][0], esleme[b][0]
                ya, yb = yeni["parcalar"][a], yeni["parcalar"][b]
                pa, pb = kaynak["parcalar"][ka], kaynak["parcalar"][kb]
                onc = _geometri_imza_puani(ya, pa) + _geometri_imza_puani(yb, pb)
                son = _geometri_imza_puani(ya, pb) + _geometri_imza_puani(yb, pa)
                if onc - son > 0.5 and (en_iyi is None or onc - son > en_iyi[0]):
                    en_iyi = (onc - son, a, b, ka, kb)
        if en_iyi is None:
            break
        _k, a, b, ka, kb = en_iyi
        esleme[a] = (kb, "2-opt takas (%s -> %s, kazanc %.3g)" % (esleme[a][1], "imza", _k))
        esleme[b] = (ka, "2-opt takas (%s -> %s, kazanc %.3g)" % (esleme[b][1], "imza", _k))
    return esleme


def _prim_esle(yp, kp):
    """Bir parca icinde primitifleri baglar: (NV,NT) ciftine -> materyal adina -> imzaya."""
    esleme = {}
    kullanilan = set()
    # 1) (NV, NT) ikisinde de TEKIL ise dogrudan
    for kaynak_anahtar in (lambda p: (p["NV"], p["NT"]), lambda p: p.get("material_ad")):
        yh, kh = {}, {}
        for i, p in enumerate(yp):
            yh.setdefault(kaynak_anahtar(p), []).append(i)
        for i, p in enumerate(kp):
            kh.setdefault(kaynak_anahtar(p), []).append(i)
        for anah, ys in yh.items():
            ks = kh.get(anah, [])
            if anah is None or len(ys) != 1 or len(ks) != 1:
                continue
            if ys[0] in esleme or ks[0] in kullanilan:
                continue
            esleme[ys[0]] = ks[0]
            kullanilan.add(ks[0])
    kalan_y = [i for i in range(len(yp)) if i not in esleme]
    kalan_k = [i for i in range(len(kp)) if i not in kullanilan]
    ciftler = sorted(((_geometri_imza_puani(yp[a], kp[b]), a, b)
                      for a in kalan_y for b in kalan_k), key=lambda t: t[0])
    ky, kk = set(), set()
    for _puan, a, b in ciftler:
        if a in ky or b in kk:
            continue
        esleme[a] = b
        ky.add(a)
        kk.add(b)
    return esleme


def _parca_donustur(p, A):
    """Tek bir parcanin konum/normal/tanjantini A ile YERINDE donustur."""
    Nm = _normal_matris(A)
    for q in p["primler"]:
        q["pos"] = _uygula_nokta(A, q["pos"])
        q["bbox_min"] = [float(x) for x in q["pos"].min(0)] if q["NV"] else None
        q["bbox_max"] = [float(x) for x in q["pos"].max(0)] if q["NV"] else None
        if q.get("nrm") is not None:
            n = q["nrm"] @ Nm.T
            u = np.linalg.norm(n, axis=1, keepdims=True)
            q["nrm"] = np.divide(n, u, out=np.zeros_like(n), where=u > 1e-12)
        if q.get("tan") is not None:
            v = q["tan"] @ A[:3, :3].T
            u = np.linalg.norm(v, axis=1, keepdims=True)
            q["tan"] = np.divide(v, u, out=np.zeros_like(v), where=u > 1e-12)
    return p


def _parca_ince_hizala(yeni, kaynak, tol_m=5e-4):
    """Armature kaybi teshis edilen dosyalarda parca basina kalan KATI kaymayi giderir.

    Her parcanin kaynakta KENDI skini vardir; skinlerin etkin donusumleri milimetre
    mertebesinde farklidir, bu yuzden tek bir kuresel fit yetmez (olculdu: Mannequin
    1,58 mm, Pants 0,47 mm artik kalmisti).

    Bir parca ancak SU KOSULLA duzeltilir: kendi Kabsch fitinin artik MAKSIMUMU
    `tol_m` altinda kalmali, yani parca yalniz KAYMIS, bicimi degismemis olmali.
    Bicimi degismis parcaya (kullanicinin gercek duzenlemesi) DOKUNULMAZ.

    Doner: [{ad, once_maks_m, sonra_maks_m, aci_derece, oteleme_m}] (uygulananlar).
    """
    try:
        pe = _parca_esle(yeni, kaynak)
    except Exception:                                          # noqa: BLE001
        return []
    out = []
    for yi, (ki, _y) in pe.items():
        if ki is None:
            continue
        y = yeni["parcalar"][yi]
        k = kaynak["parcalar"][ki]
        pm = _prim_esle(y["primler"], k["primler"])
        PY, PK = [], []
        for pi, yp in enumerate(y["primler"]):
            kpi = pm.get(pi)
            if kpi is None:
                continue
            kp = k["primler"][kpi]
            if yp["NV"] != kp["NV"] or yp["NV"] < 4:
                continue
            perm, _ = vertex_perm(yp, kp)
            if perm is None:
                continue
            PY.append(np.asarray(yp["pos"], np.float64))
            PK.append(np.asarray(kp["pos"], np.float64)[perm])
        if not PY:
            continue
        Pp = np.concatenate(PY)
        Qq = np.concatenate(PK)
        if len(Pp) < 4 or np.linalg.matrix_rank(Pp - Pp.mean(0), tol=1e-6) < 3:
            continue
        once = float(np.linalg.norm(Pp - Qq, axis=1).max())
        A, amax, arms, _olcek = _kabsch(Pp, Qq)
        if amax is None or amax > tol_m or amax >= once:
            continue                                            # bicim degismis ya da fayda yok
        _parca_donustur(y, A)
        iz = float(np.clip((np.trace(A[:3, :3]) - 1.0) / 2.0, -1.0, 1.0))
        out.append({"ad": y["ad"], "once_maks_m": once, "sonra_maks_m": amax,
                    "aci_derece": float(np.degrees(np.arccos(iz))),
                    "oteleme_m": [float(x) for x in A[:3, 3]]})
    return out


def eslestir(yeni, kaynak, iskelet_hizala=True):
    """Iki `oku()` sonucunu karsilastirir. Doner {parcalar:[...], ozet:{...}, hizalama:{...}}.

    iskelet_hizala=True: once `hizala()` ile Blender'in tasidigi kati donusum GERI ALINIR
    (yeni sahne YERINDE guncellenir); yoksa iskelet koku olan her modelde parca basina
    metrelerce sahte "fark" olculur (bkz. modul basligi 1b).

    Her parca kaydi: ad, kaynak_ad, eslesme_yontemi, NV/NT ikisi, topoloji (IDENTICAL/
    CHANGED/UNKNOWN), poz_fark_maks_m, donusum_tahmini (esleme varsa), kaba_donusum (bir
    primitifte esleme kurulamadiysa; esleme gerektirmeyen tahmin), primler[...],
    ad_celiskisi (K-4 (i): nesne adi ile mesh adi farkli kaynak parcalara cozuluyor, yoksa
    None), takas_imzasi (K-4 (ii): NV/NT'si bu parcayla capraz birebir olan diger CHANGED
    parcanin adi, yoksa None). ozet: ad_celiskisi (sayi), takas_imzasi [(ad, ad)]."""
    hiz = hizala(yeni, kaynak) if iskelet_hizala else {"A": np.eye(4), "yontem": "kapali",
                                                       "kemik": 0, "artik_maks_m": None,
                                                       "artik_rms_m": None, "olcek_tahmini": None,
                                                       "oteleme_m": None, "aci_derece": None}
    # Butun modelin tasinmasi/donmesi (sahne yerlesimi) hizalamayla geri alinir; kullaniciya
    # ait kismi burada olculur ki plan() NOT yazabilsin (bkz. modul basligi 1c).
    hiz["yerlesim"] = sahne_yerlesimi(hiz, kaynak) if iskelet_hizala else None
    if iskelet_hizala:
        donusum_uygula(yeni, hiz["A"])
    # Armature kaybi teshis edildiyse (kemik yok, kuresel fit mesh'ten geldi) parca
    # basina kalan milimetrelik kaymayi da gider: her parcanin kaynakta AYRI skini
    # vardir, tek kuresel fit hepsini sifirlayamaz (olculdu).
    hiz["parca_ince"] = (_parca_ince_hizala(yeni, kaynak)
                         if (iskelet_hizala and hiz.get("yontem") == "mesh (kemik yok)")
                         else [])
    pe = _parca_esle(yeni, kaynak)
    # K-4 (i): ad eslesmesi kazandi, ama mesh adi baska parcayi gosteriyor mu? (kayda gider)
    celiski = ad_celiskileri(yeni, kaynak)
    kayitlar = []
    for i, y in enumerate(yeni["parcalar"]):
        ki, yontem = pe.get(i, (None, None))
        k = kaynak["parcalar"][ki] if ki is not None else None
        r = {"ad": y["ad"], "mesh_ad": y["mesh_ad"], "NV": y["NV"], "NT": y["NT"],
             "prim": len(y["primler"]), "skinli": y["skinli"],
             "kaynak_ad": k["ad"] if k else None,
             "kaynak_NV": k["NV"] if k else None, "kaynak_NT": k["NT"] if k else None,
             "kaynak_prim": len(k["primler"]) if k else None,
             "eslesme_yontemi": yontem, "topoloji": BILINMIYOR, "topoloji_sebep": None,
             "poz_fark_maks_m": None, "poz_fark_ort_m": None, "donusum_tahmini": None,
             "kaba_donusum": None, "ad_celiskisi": celiski.get(i), "takas_imzasi": None,
             "skin_tutarsizlik": y["skin_tutarsizlik"],
             # (1d) BAYAT EXPORT: kusur KAYNAK export'tadir (Blender tek armature'e indirip
             # IBM'leri yeniden yazar -> duzenlenmis dosyada izi kalmaz, olculdu: 12 skin ->
             # 1 skin, tutarsizlik 1,2e-05). Bu yuzden KAYNAK parcanin olcusu tasinir.
             "kaynak_ibm_kayma_m": (k.get("ibm_kayma_m") if k else None),
             "primler": []}
        if k is None:
            r["topoloji_sebep"] = "kaynakta karsiligi yok"
            kayitlar.append(r)
            continue
        pm = _prim_esle(y["primler"], k["primler"])
        fark_maks = 0.0
        fark_top = 0.0
        fark_n = 0
        # NT esitligi parca duzeyinde ARANMAZ: primitif kapisi kaynaktaki kopya ucgenlerin
        # dususunu (Blender normalizasyonu) IDENTICAL sayabilir; o zaman parca NT'si farkli
        # olsa da sekil degismemistir.
        tum_ok = (len(y["primler"]) == len(k["primler"]))
        bilinmiyor = False
        tp_y, tp_k = [], []
        hp_y, hp_k = [], []                  # eslesen HER primitifin konumlari (esleme sartsiz)
        kaba_gerek = False                   # en az bir primitifte permutasyon kurulamadi
        ikiz_bolunme = 0                     # Blender'in boldugu dikis vertexleri (surjeksiyon fazlasi)
        kopya_dustu = 0                      # Blender'in dusurdugu kaynak kopya ucgenleri
        for pi, yp in enumerate(y["primler"]):
            kpi = pm.get(pi)
            kp = k["primler"][kpi] if kpi is not None else None
            q = {"i": pi, "kaynak_i": kpi, "NV": yp["NV"], "NT": yp["NT"],
                 "kaynak_NV": kp["NV"] if kp else None, "kaynak_NT": kp["NT"] if kp else None,
                 "material_ad": yp.get("material_ad"),
                 "kaynak_material_ad": kp.get("material_ad") if kp else None,
                 "esleme_yontemi": None, "topoloji": BILINMIYOR,
                 "poz_fark_maks_m": None, "uv_fark_maks": None, "donusum_tahmini": None}
            if kp is None:
                q["topoloji"] = CHANGED
                tum_ok = False
                r["primler"].append(q)
                continue
            perm, yontem = vertex_perm(yp, kp)
            q["esleme_yontemi"] = yontem
            hp_y.append(np.asarray(yp["pos"], np.float64))
            hp_k.append(np.asarray(kp["pos"], np.float64))
            if perm is None:
                q["topoloji"] = CHANGED if yp["NV"] != kp["NV"] or yp["NT"] != kp["NT"] else BILINMIYOR
                if q["topoloji"] == BILINMIYOR:
                    bilinmiyor = True
                # Esleme yok -> oynama olculemez; yine de "ne degisti" esleme GEREKTIRMEYEN
                # tahminle soylenir (agirlik merkezi / RMS yaricap / ana eksenler). Eski surum
                # hicbir sey olcmuyor, onay ekrani 5 cm tasima ile 2x buyutmeyi ayni satirla
                # gosteriyordu (2026-09-05, Weapon_Pistol_11: tasinan rijit parcada konum
                # anahtarli surjeksiyon kurulamaz).
                q["kaba_donusum"] = _kaba_donusum(yp["pos"], kp["pos"])
                kaba_gerek = True
                tum_ok = False
                r["primler"].append(q)
                continue
            # konum farki (eslesen vertexler arasinda)
            dv = np.linalg.norm(yp["pos"] - kp["pos"][perm], axis=1)
            q["poz_fark_maks_m"] = float(dv.max()) if dv.size else 0.0
            q["poz_fark_ort_m"] = float(dv.mean()) if dv.size else 0.0
            fark_maks = max(fark_maks, q["poz_fark_maks_m"])
            fark_top += float(dv.sum())
            fark_n += dv.size
            if yp.get("uv0") is not None and kp.get("uv0") is not None:
                q["uv_fark_maks"] = float(np.abs(yp["uv0"] - kp["uv0"][perm]).max())
            q["donusum_tahmini"] = _donusum_tahmini(yp["pos"], kp["pos"][perm])
            # topoloji: indeks tamponu permutasyona kadar ayni mi? Surjeksiyonda (Blender
            # dikis vertexlerini boldu) her iki taraf da ikiz-kanonik indekse indirilir.
            ik = kp.get("_ikiz_kanonik")
            surjeksiyon = (ik is not None and len(perm) != kp["NV"])
            if surjeksiyon:
                ay = _kanonik(ik[perm[yp["tri"]]])
                ak = _kanonik(ik[np.asarray(kp["tri"], np.int64)])
                q["ikiz_bolunme"] = int(len(perm) - kp["NV"])
                ikiz_bolunme += q["ikiz_bolunme"]
            else:
                ay = _kanonik(perm[yp["tri"]])
                ak = _kanonik(kp["tri"])
            if yp["NT"] != kp["NT"]:
                kopya = _kopya_dususu(ay, ak)
                if kopya is None:
                    q["topoloji"] = CHANGED
                    q["topoloji_sebep"] = "NT %d != %d" % (yp["NT"], kp["NT"])
                    tum_ok = False
                else:
                    # Blender importerinin dusurdugu KAYNAK kopya ucgenleri: sekil ayni,
                    # oyunun kendi indeks tamponu (kopyalariyla) yerinde kalir.
                    q["topoloji"] = IDENTICAL
                    q["kopya_ucgen_dustu"] = kopya
                    q["topoloji_sebep"] = ("kaynaktaki %d kopya ucgen Blender'da dustu; benzersiz "
                                           "ucgen kumesi birebir" % kopya)
                    q["ucgen_sirasi_ayni"] = False
                    kopya_dustu += kopya
            elif np.array_equal(ay, ak):
                q["topoloji"] = IDENTICAL
                q["ucgen_sirasi_ayni"] = bool(np.array_equal(perm[yp["tri"]], kp["tri"]))
            else:
                q["topoloji"] = CHANGED
                # ortak ucgen sayisi: void gorunumu SIRALANAMAZ, bu yuzden birlesik
                # np.unique(axis=0) + bincount ile sayilir (fail-close degil, olcum)
                _u, _inv = np.unique(np.concatenate([ay, ak]), axis=0, return_inverse=True)
                _inv = _inv.ravel()
                _cy = np.bincount(_inv[:len(ay)], minlength=len(_u))
                _ck = np.bincount(_inv[len(ay):], minlength=len(_u))
                ortak = int(np.minimum(_cy, _ck).sum())
                q["topoloji_sebep"] = "ucgen kumesi farkli (%d/%d ortak)" % (ortak, len(ak))
                tum_ok = False
            tp_y.append(yp["pos"])
            tp_k.append(kp["pos"][perm])
            r["primler"].append(q)
        r["poz_fark_maks_m"] = fark_maks if fark_n else None
        r["poz_fark_ort_m"] = (fark_top / fark_n) if fark_n else None
        r["ikiz_bolunme"] = ikiz_bolunme
        r["kopya_ucgen_dustu"] = kopya_dustu
        if tp_y:
            r["donusum_tahmini"] = _donusum_tahmini(np.concatenate(tp_y), np.concatenate(tp_k))
        if kaba_gerek and hp_y:
            # butun parca uzerinden (eslesen + eslesmeyen primitifler birlikte)
            r["kaba_donusum"] = _kaba_donusum(np.concatenate(hp_y), np.concatenate(hp_k))
        if tum_ok and all(q["topoloji"] == IDENTICAL for q in r["primler"]) and r["primler"]:
            r["topoloji"] = IDENTICAL
            if ikiz_bolunme or kopya_dustu:
                # NV/NT farki Blender normalizasyonundan: raporda gorunsun, yazim tetiklemesin
                r["topoloji_sebep"] = "Blender normalizasyonu: %d bolunmus dikis vertexi, %d dusen kopya ucgen" \
                                      % (ikiz_bolunme, kopya_dustu)
        elif bilinmiyor and not any(q["topoloji"] == CHANGED for q in r["primler"]):
            r["topoloji"] = BILINMIYOR
            r["topoloji_sebep"] = "vertex eslemesi kurulamadi"
        else:
            r["topoloji"] = CHANGED
            if r["topoloji_sebep"] is None:
                # Primitif sebebi parca sebebiyle MASKELENMEZ: NV/NT sayilari yalniz baslik,
                # asil karar primitif kapisindan gelir (olculdu: "NV 12535->12537" metni
                # arkasindaki "ucgen kumesi farkli" sebebini gizliyordu).
                prim_sebep = "; ".join(
                    "prim %d: %s" % (q["i"], q.get("topoloji_sebep") or q["topoloji"])
                    for q in r["primler"] if q["topoloji"] != IDENTICAL)
                if y["NV"] != k["NV"] or y["NT"] != k["NT"]:
                    r["topoloji_sebep"] = "NV %d->%d, NT %d->%d%s" % (
                        k["NV"], y["NV"], k["NT"], y["NT"], ("; " + prim_sebep) if prim_sebep else "")
                else:
                    r["topoloji_sebep"] = prim_sebep
        kayitlar.append(r)
    # K-4 (ii): adla eslesmis CHANGED ciftlerde NV/NT capraz birebir mi? (kayda gider)
    takas = takas_imzalari(kayitlar)
    eslesmemis_kaynak = [k["ad"] for i, k in enumerate(kaynak["parcalar"])
                         if i not in {v[0] for v in pe.values()}]
    ozet = {"parca": len(kayitlar), "kaynak_parca": len(kaynak["parcalar"]),
            "ad_celiskisi": len(celiski),
            "takas_imzasi": [(kayitlar[a]["ad"], kayitlar[b]["ad"]) for a, b in takas],
            "eslesen": sum(1 for r in kayitlar if r["kaynak_ad"] is not None),
            "identical": sum(1 for r in kayitlar if r["topoloji"] == IDENTICAL),
            "changed": sum(1 for r in kayitlar if r["topoloji"] == CHANGED),
            "bilinmiyor": sum(1 for r in kayitlar if r["topoloji"] == BILINMIYOR),
            "eslesmemis_kaynak": eslesmemis_kaynak,
            "poz_fark_maks_m": max([r["poz_fark_maks_m"] for r in kayitlar
                                    if r["poz_fark_maks_m"] is not None] or [None]),
            "NV_toplam": yeni["toplam_NV"], "kaynak_NV_toplam": kaynak["toplam_NV"],
            "NT_toplam": yeni["toplam_NT"], "kaynak_NT_toplam": kaynak["toplam_NT"]}
    hiz_ozet = {k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in hiz.items()}
    return {"parcalar": kayitlar, "ozet": ozet, "hizalama": hiz_ozet}


# =============================================================== manifest baglantisi
def manifest_bagla(rapor, manifest_yolu):
    """manifest.json'daki parca kaydini (gid/icid/sha256/NV/NT/materyaller/rigid) rapora diker.
    Eslesme kaynak parca adiyla yapilir -- manifest'i URETEN export'un GLB'si kaynak oldugu icin
    adlar birebirdir. Doner: rapor (yerinde guncellenir)."""
    with open(manifest_yolu, "r", encoding="utf-8") as f:
        man = json.load(f)
    kayit = {p["ad"]: p for p in man.get("parcalar", [])}
    for r in rapor["parcalar"]:
        m = kayit.get(r.get("kaynak_ad")) or kayit.get(r.get("ad"))
        r["manifest"] = None if m is None else {
            "ad": m.get("ad"), "gid": m.get("gid"), "icid": m.get("icid"), "lod": m.get("lod"),
            "durum": m.get("durum"), "rigid": m.get("rigid"), "sha256": m.get("sha256"),
            "ic_bayt": m.get("ic_bayt"), "NV": m.get("NV"), "NT": m.get("NT"),
            "prim": m.get("prim"), "materyaller": m.get("materyaller"),
            "kemik": m.get("kemik"), "kemik_per_vertex": m.get("kemik_per_vertex"),
            "fmt": m.get("fmt"), "bbox_min": m.get("bbox_min"), "bbox_max": m.get("bbox_max")}
        if m is not None:
            r["manifest_NV_uyum"] = (r["kaynak_NV"] == m.get("NV"))
            r["manifest_NT_uyum"] = (r["kaynak_NT"] == m.get("NT"))
    rapor["manifest_dosya"] = manifest_yolu
    rapor["manifest_anahtar"] = man.get("anahtar")
    rapor["manifest_kategori"] = man.get("kategori")
    rapor["manifest_baglanan"] = sum(1 for r in rapor["parcalar"] if r.get("manifest"))
    return rapor


def karsilastir(yeni_yol, kaynak_yol, manifest_yolu=None):
    """Duzenlenmis GLB'yi kaynak GLB ile karsilastiran tek cagri.
    manifest_yolu verilmezse kaynak GLB'nin yanindaki manifest.json denenir."""
    yeni = oku(yeni_yol)
    kaynak = oku(kaynak_yol)
    r = eslestir(yeni, kaynak)
    r["yeni"] = {"dosya": yeni_yol, "boyut": yeni["boyut"], "uretici": yeni.get("uretici"),
                 "hatalar": yeni["hatalar"], "sayim": yeni.get("sayim")}
    r["kaynak"] = {"dosya": kaynak_yol, "boyut": kaynak["boyut"], "uretici": kaynak.get("uretici"),
                   "hatalar": kaynak["hatalar"], "sayim": kaynak.get("sayim")}
    if manifest_yolu is None:
        aday = os.path.join(os.path.dirname(os.path.abspath(kaynak_yol)), "manifest.json")
        manifest_yolu = aday if os.path.isfile(aday) else None
    if manifest_yolu:
        manifest_bagla(r, manifest_yolu)
    return r


def yazici_primleri(rapor_parca, yeni_parca, prim_sayisi):
    """ESLESTIRILMIS bir parcayi `mesh_yaz.yaz_serbest`in bekledigi `primler` listesine
    cevirir. TEK URETIM YOLU budur -- elle sozluk kurmak, Blender'in NORMALLERINI
    tasimayi unutmanin yolu oldu (olculdu: yazici kendi hesaplayinca Blender'a sapma
    medyan 9,37 / p95 57,79 derece; normal verilince 0,107 derece = oktahedral taban).

    rapor_parca : `eslestir()` raporunun parcalar[] ogesi (kaynak_i baglantilari icin)
    yeni_parca  : `oku()` ciktisindaki AYNI SIRADAKI parca (gercek diziler burada)
    prim_sayisi : hedef mesh'in orijinal primitif sayisi

    -> primler listesi.  Eksik primitif varsa `KeyError` yerine ACIK hata."""
    esle = {}
    for q, yp in zip(rapor_parca.get("primler", []), yeni_parca.get("primler", [])):
        ki = q.get("kaynak_i")
        if ki is not None:
            esle[int(ki)] = yp
    eksik = [i for i in range(prim_sayisi) if i not in esle]
    if eksik:
        raise ValueError("the edited part does not cover the original primitive(s) %s - the "
                         "writer cannot leave a primitive undefined" % eksik)
    out = []
    for i in range(prim_sayisi):
        yp = esle[i]
        d = {"pos": np.asarray(yp["pos"], np.float64),
             "tri": np.asarray(yp["tri"], np.int64).reshape(-1, 3)}
        for gk, yk in (("uv0", "uv0"), ("uv1", "uv1"), ("normal", "nrm"),
                       ("tangent", "tan"), ("renk", "renk")):
            v = yp.get(yk)
            if v is not None:
                d[gk] = np.asarray(v, np.float64) if gk != "renk" else np.asarray(v)
        # DERI (kemik_idx/agirlik) BILEREK TASINMAZ: GLB'deki eklem indeksi DOSYA
        # genelindedir (Blender 14 skini tek armature'de birlestirdi: 326 -> 679 eklem),
        # mesh'in kendi paleti ise 22 kemiklik yerel bir listedir. Ham indeksi vermek
        # "bone index 401 is outside this mesh's 22-bone palette" ile REDDEDILIR (olculdu).
        # Palet eslemesi cozulene kadar yazici agirligi EN YAKIN KOMSUDAN tasir.
        out.append(d)
    return out


def rapor_ozet(r):
    """Raporu JSON'a yazilabilir hale getirir (numpy tipleri Python tipine cevrilir)."""
    def d(v):
        if isinstance(v, np.ndarray):
            return v.tolist()
        if isinstance(v, (np.floating, np.integer)):
            return v.item()
        if isinstance(v, dict):
            return {k: d(x) for k, x in v.items()}
        if isinstance(v, (list, tuple)):
            return [d(x) for x in v]
        return v
    return d(r)
