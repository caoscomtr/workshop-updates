# -*- coding: utf-8 -*-
"""gizle — bir mesh PARCASINI (MeshPrimitive / Blender'daki materyal grubu) oyunda
GORUNMEZ yapar.

NEDEN: Kullanici Blender'da Edward'in paltosunu siliyor ve oyunda da yok olmasini
bekliyor. Bugun `mesh_yaz.yaz_serbest` bos bir primitifi REDDEDIYOR ("a primitive
cannot be emptied") -> silinen parca sessizce yok sayiliyor. Bu modul o bosluğu
doldurur: parcayi SILMEZ, CIZILEMEZ hale getirir.

--------------------------------------------------------------------------------
SECILEN YONTEM — "DEJENERE INDEKS" (ucgenin uc kosesi de AYNI vertex)
--------------------------------------------------------------------------------
Hedef prim'in her ucgeni (a, b, c) -> (a, a, a) yapilir. Boyle bir ucgenin
tarama (rasterization) alani TAM SIFIRDIR: uc kosenin kirpma uzayindaki konumu
BIT-BIREBIR aynidir (ayni vertex -> ayni vertex shader ciktisi), dolayisiyla
kenar fonksiyonlari her ornekte sifir cikar ve HICBIR piksel uretilmez. Golge
gecisinde de ayni sey olur -> golge de dusmez.

KANIT (bu oyunun KENDI dosyalarindan olculdu, 2026-09-05):
  * Rigid (fmt 3/4) mesh'lerin IndexBuffer'i kume-dolguludur (ClusterCount*192
    indeks). 39 kumeli rigid mesh'te DOLGU olarak yazilmis 2977 ucgenin
    **2977'si de (v, v, v) bicimindedir — %100**. Yani AC4'un kendi varlik
    paketleyicisi "bu ucgen hicbir sey cizmesin" demek icin TAM OLARAK bizim
    urettigimiz bicimi kullaniyor. Oyunun bu bicimi kabul ettigi, kendi
    dosyalarinda tasidigi icin kanitlidir.
  * Ayni korpusta CIZILEN araliklarda 197.170 ucgenin 0'i dejeneredir -> bicim
    "cizilmeyen ucgen" anlamina ozgudur, kaza sonucu olusmus bir sey degildir.

NEDEN KONUM COKERTME (aday A) DEGIL — OLCULDU:
  * Tum vertexleri tek noktaya cokertmek sinir kutusunu SIFIR genislige indiriyor;
    `mesh_yapisal.oku` konum olcegini kutu/ham oranindan turettigi icin uretilen
    dosya KENDI OKUYUCUMUZLA GERI OKUNAMIYOR ("konum olcegi turetilemedi").
    38 mesh'te olculdu: 18'i geri okunamadi (%47). Geri okunamayan dosya
    `kur_mesh`in kurulum-sonrasi dogrulama kapisini dusurur.
  * SKINNED mesh'te daha kotusu var: ayni bind konumundaki vertexler FARKLI
    kemiklere bagliysa deri donusumunden sonra AYRI noktalara gider
    (pos = sum w_i * M_i * p). Yani "tek noktaya cokerttik" dedigimiz parca
    oyunda iskelet boyunca dagilmis, gerilmis ucgenlere donusur — silinmek
    yerine daha da gorunur olur. Bunu onlemek icin butun vertexleri tek kemige
    baglamak (VBidxWeight'i da bozmak) gerekirdi.
  * Ayrica konumlar degistigi icin turetilmis tablolar (bbox / CMD kutusu / CPI /
    SurfaceArea) yeniden yazilmak zorunda kalir ve `mesh_yaz.tablo_oz_denetim`
    kapisi devreye girer (Hat_U_Edward_Morgan_LOD0 sinifi mesh'ler orada duser).
  Dejenere indeks yolunda bunlarin HICBIRI olmaz: konumlar hic degismez.

NEDEN 3 VERTEXLIK MINIK MESH (aday B) DEGIL:
  * `yaz_serbest` gerekir; o da mesh'i KUME-SIZ bicime cevirir (ClusteredMeshData
    nesnesi tumden silinir), ic dosya uzunlugu degisir, K1 kayit uzunlugu +
    forge TOC satiri guncellenmek zorunda kalir. Kiyasla dejenere indeks yolunda
    ic dosya uzunlugu BIREBIR sabittir ve degisen baytlar YALNIZCA IndexBuffer'in
    icindedir (olculdu, asagidaki kapi bunu her cagrida dogrular).
  * `_prim_dogrula` bos primitifi zaten reddediyor (nv < 3 / nt < 1) ve
    `dejenere="reddet"` varsayilani bizim uretecegimiz ucgenleri de reddederdi ->
    B yolu kendi kapilariyla catisiyor.
  * Ayrica B, geri kalan primitiflerin geometrisini de yeniden nicemler (kayipli).

NEDEN LODSelector'dan CIZIM KAYDI SILME (aday C) DEGIL:
  * O kayit mesh IC DOSYASINDA degil, varlik grafinin baska bir nesnesinde durur;
    bicimi bu projede COZULMEDI ve API sozlesmesi (ic dosya -> ic dosya) disina
    cikar. Cozulmemis bir yapiyi duzenlemek [[ac4-mod-guvenlik-kurallari]] 1.
    kuralina aykiridir.

--------------------------------------------------------------------------------
GERI ALMA
--------------------------------------------------------------------------------
Vertex tamponlarina, tablolara, materyal baglantilarina, kemik tablosuna TEK BAYT
dokunulmaz; degisen tek sey hedef prim'in IndexBuffer dilimidir ve uzunluk sabittir.
Kurulum `kur_mesh.kur` ile yapilir -> `kur_mesh.geri_al` orijinal girisi aynen
geri koyar. Ayrica `gizli_mi()` bir dosyanin hangi parcalarinin gizli oldugunu
diskten OLCEREK soyler (bayrak dosyasina degil, baytlara bakar).

--------------------------------------------------------------------------------
DENENMEYENLER (durust liste)
--------------------------------------------------------------------------------
  * OYUNDA DENENMEDI. Bu modulun urettigi hicbir dosya oyuna kurulmadi.
  * TURETILMIS TABLOLAR BILINCLI OLARAK BAYAT BIRAKILIR: CPI kutusu ve SurfaceArea
    artik cizilmeyen ucgenleri anlatir. Bu YONDE hata guvenlidir (kutu gercekte
    olandan BUYUK -> parca "gorunur olabilir" sayilir, cizim yapilir, sifir piksel
    uretilir). Ters yonde (kutuyu kucultmek) yanlis kirpmaya yol acardi. Kutuyu
    guncellemek ayrica `mesh_yaz.tablo_oz_denetim` kapisini devreye sokar ve o
    kapinin dustugu mesh sinifinda gizlemeyi de gereksiz yere reddederdi.
  * Kumas fizigi (MotionCloth) simulasyonu gizlenen parcayi hala simule edebilir;
    gorunmedigi icin gorsel etkisi yoktur ama olculmedi.
  * Kume-siz (gate_CMD=3) RIGID mesh'ler REDDEDILIR: `mesh_yaz._tamponlar_rigid`
    o bicimde CPI listesine bakiyor ve liste bos oluyor. Vanilla korpusta bu
    bilesim yok; ucuncu-sahis dosyalarda olabilir -> fail-closed.
"""
import numpy as np

try:
    from . import mesh_yapisal as MY
    from . import mesh_yaz as MZ
except ImportError:                       # duz betik olarak da calissin
    import mesh_yapisal as MY
    import mesh_yaz as MZ

__all__ = ["gizle_bayt", "gizle", "gizli_mi", "gizleme_plani", "GizlemeHatasi", "SURUM"]

SURUM = "1.0"


class GizlemeHatasi(Exception):
    """Gizleme reddedildi. str() = kullaniciya gosterilecek (Ingilizce) sebep."""

    def __init__(self, sebep, ayrinti=None):
        Exception.__init__(self, sebep)
        self.sebep = sebep
        self.ayrinti = ayrinti

    def __str__(self):
        return self.sebep


# --------------------------------------------------------------------- yardimcilar
def _oku(data):
    """Ic dosya -> (R, G). Rigid (fmt 3/4) mesh'ler de cozulur; gizleme derisiz
    mesh'te de anlamlidir (silah/gemi parcasi)."""
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise GizlemeHatasi("gizle_bayt() expects the raw bytes of a mesh internal file")
    try:
        return MY.oku(bytes(data), rigid=True)
    except MY.DesteklenmiyorHatasi as e:
        raise GizlemeHatasi(
            "this mesh cannot be parsed, so it cannot be edited safely (%s)" % e, e.ayrinti)


def _prim_ucgen_araligi(R, G, i):
    """prim i'nin IndexBuffer'daki UCGEN araligi [t0, t1).

    skinned: MeshPrimitive.firstIdx mantiksal ucgen akisina bakar (firstIdx/3).
    rigid  : ucgenler prim sirasina gore ardisik cozulur (`mesh_yapisal._geo_rigid`
             dolguyu atarak yeniden dizer) -> taban onceki NT'lerin toplamidir.
    Ikisi de `mesh_yaz._prim_ucgenleri` ile AYNI kurali kullanir; yazicinin
    IndexBuffer'i hangi dilime yazacagiyla birebir ortusmek zorunda."""
    prims = G["prims"]
    pr = prims[i]
    if R.get("rigid"):
        t0 = int(sum(p["NT"] for p in prims[:i]))
    else:
        t0 = int(pr["firstIdx"]) // 3
    return t0, t0 + int(pr["NT"])


def _hedef_prim_listesi(prim, n):
    """`prim` argumanini dogrulanmis, sirali, tekrarsiz indeks listesine cevirir.
    None = TUM primitifler (butun mesh gorunmez olur)."""
    if prim is None:
        return list(range(n))
    if isinstance(prim, (int, np.integer)) and not isinstance(prim, bool):
        idx = [int(prim)]
    elif isinstance(prim, (str, bytes)):
        # Dize de yinelenebilir: yakalanmazsa "palto" -> ['p','a',...] diye ilerleyip
        # anlamsiz bir ValueError verirdi. Parca ADIYLA secim bu modulun isi degil.
        raise GizlemeHatasi("'prim' must be None, a part index, or a list of part indices "
                            "(part names are not supported here)")
    else:
        try:
            idx = [int(x) for x in prim]
        except (TypeError, ValueError):
            raise GizlemeHatasi("'prim' must be None, an integer, or a list of integers")
    for i in idx:
        if not 0 <= i < n:
            raise GizlemeHatasi(
                "part index %d is out of range: this mesh has %d part(s) (0..%d)"
                % (i, n, n - 1))
    return sorted(set(idx))


def _cakisma_kapisi(R, G, hedef):
    """KISMI gizlemede hedef prim'in ucgen araligi BASKA bir prim'in araligiyla
    ortusuyorsa reddet. Ortusen prim yerlesimi olculdu (Hat_U_Edward_Morgan_LOD0'da
    vertex araliklari cakisiyor); orada bir parcayi gizlemek gorunur kalmasi gereken
    parcayi da silerdi. Sessizce yanlis is yapmaktansa sebep gostererek reddedilir."""
    n = len(G["prims"])
    if len(hedef) >= n:
        return None                                   # hepsi gizleniyor: cakisma zararsiz
    ara = [_prim_ucgen_araligi(R, G, i) for i in range(n)]
    kalan = [i for i in range(n) if i not in hedef]
    for i in hedef:
        a0, a1 = ara[i]
        for j in kalan:
            b0, b1 = ara[j]
            if a0 < b1 and b0 < a1:
                return (i, j, ara[i], ara[j])
    return None


def _dejenere_maske(ibg):
    """(NT,) bool — ucgenin UC KOSESI de ayni vertex mi (oyunun dolgu bicimi)."""
    ib = np.asarray(ibg)
    if ib.size == 0:
        return np.zeros(0, bool)
    return (ib[:, 0] == ib[:, 1]) & (ib[:, 1] == ib[:, 2])


# --------------------------------------------------------------------- kesif / rapor
def gizli_mi(data):
    """Bir ic dosyanin hangi parcalarinin GIZLI oldugunu BAYTLARDAN olcer.
    (Bayrak dosyasina degil dosyanin kendisine bakar -- 'kod varligi kanit degil'.)

    -> {"prim_sayi": n, "prim": [ {sira, NT, dejenere, gizli, ucgen_araligi}, ... ],
        "hepsi_gizli": bool, "gizli_prim": [i, ...]}"""
    R, G = _oku(data)
    ibg = np.asarray(G["ibg"])
    dej = _dejenere_maske(ibg)
    out = []
    for i in range(len(G["prims"])):
        t0, t1 = _prim_ucgen_araligi(R, G, i)
        nt = t1 - t0
        nd = int(dej[t0:t1].sum()) if nt else 0
        out.append(dict(sira=i, NT=int(nt), dejenere=nd,
                        gizli=bool(nt > 0 and nd == nt), ucgen_araligi=(int(t0), int(t1))))
    return dict(prim_sayi=len(out), prim=out,
                hepsi_gizli=bool(out) and all(p["gizli"] for p in out),
                gizli_prim=[p["sira"] for p in out if p["gizli"]])


def gizleme_plani(data, prim=None):
    """Yazmadan once NE OLACAGINI soyler (GUI onizlemesi icin). Reddedilecekse
    ayni sebeple `GizlemeHatasi` firlatir -> plan gecerse gizleme de gecer."""
    R, G = _oku(data)
    hedef = _hedef_prim_listesi(prim, len(G["prims"]))
    _kapilar(R, G, hedef)
    dej = _dejenere_maske(np.asarray(G["ibg"]))
    ayrinti = []
    top = 0
    # `gizlenecek_ucgen` ZATEN dejenere olanlari saymaz -> 0 cikmasi "bu parca zaten
    # gizli" demektir (GUI dugmeyi buna gore etiketleyebilir).
    for i in hedef:
        t0, t1 = _prim_ucgen_araligi(R, G, i)
        zaten = int(dej[t0:t1].sum())
        top += (t1 - t0) - zaten
        ayrinti.append(dict(sira=i, NT=int(t1 - t0), zaten_gizli=zaten,
                            NV=int(G["prims"][i]["NV"])))
    T = R["CMD"]["tampon"]["IndexBuffer"]
    return dict(prim_sayi=len(G["prims"]), hedef=hedef, prim=ayrinti,
                gizlenecek_ucgen=int(top), NV=int(G["NV"]), NT=int(G["NT"]),
                fmt=int(R["CMD"]["fmt"]), rigid=bool(R.get("rigid")),
                dosya_B=len(data), degisecek_bolge=(int(T["off"]), int(T["len"])))


def _kapilar(R, G, hedef):
    """Gizlemeden ONCE kosan fail-closed kapilar (plan ve yazma ayni kapilari gorur)."""
    if R.get("rigid") and R.get("kumesiz"):
        raise GizlemeHatasi(
            "this is a cluster-free rigid mesh; the index buffer layout for that "
            "combination is unverified, so hiding is refused")
    if not G["prims"]:
        raise GizlemeHatasi("this mesh has no drawable parts")
    if int(G["NT"]) <= 0:
        raise GizlemeHatasi("this mesh has no triangles")
    cak = _cakisma_kapisi(R, G, hedef)
    if cak is not None:
        i, j, ai, aj = cak
        raise GizlemeHatasi(
            "part %d shares triangles with part %d (ranges %s and %s), so hiding one "
            "would also erase the other. Hide all parts of this mesh together, or "
            "leave it as it is." % (i, j, ai, aj))


# --------------------------------------------------------------------- ana giris
def gizle(data, prim=None):
    """Gizlenmis ic dosya baytlari + olcum raporu -> (bytes, rapor).

    data : ORIJINAL ic dosya baytlari (sarmalayici dahil)
    prim : None  -> TUM parcalar gizlenir (mesh tumden gorunmez olur)
           int   -> yalniz o parca (Blender'daki materyal grubu sirasi)
           liste -> o parcalar.  BOS liste -> hicbir sey gizlenmez; cikti
                    orijinalle BIREBIR ayni olmak ZORUNDADIR (kimlik kapisi).

    Cikti uzunlugu girdiyle BIREBIR aynidir ve degisen baytlarin HEPSI
    IndexBuffer'in icindedir (her cagrida dogrulanir). Reddedilirse
    `GizlemeHatasi`."""
    R, G = _oku(data)
    hedef = _hedef_prim_listesi(prim, len(G["prims"]))
    _kapilar(R, G, hedef)

    # --- ucgenleri dejenere et: (a,b,c) -> (a,a,a). Konumlara, UV'ye, deriye,
    #     normale, tablolara TEK BAYT dokunulmaz.
    ibg = np.array(G["ibg"], copy=True)
    dilim = []
    for i in hedef:
        t0, t1 = _prim_ucgen_araligi(R, G, i)
        if t1 > t0:
            ibg[t0:t1, 1] = ibg[t0:t1, 0]
            ibg[t0:t1, 2] = ibg[t0:t1, 0]
        dilim.append((i, t0, t1))
    G2 = dict(G)
    G2["ibg"] = ibg

    # `tablolar="never"`: konumlar degismedigi icin bbox / CMD kutusu / CPI /
    # SurfaceArea ZATEN dogrudur. Yeniden yazmak (a) gereksiz, (b) mesh_yaz'in
    # tablo oz-denetim kapisini devreye sokar ve o kapinin dustugu mesh sinifinda
    # gizlemeyi de gereksiz yere reddederdi.
    try:
        yeni, rap = MZ.yaz(data, R, G2, tablolar="never")
    except MZ.YazmaHatasi as e:
        raise GizlemeHatasi("the mesh writer refused this file: %s" % e, e.ayrinti)

    # ---------------- YAZIM SONRASI KAPILAR (fail-closed, her cagrida kosar) ----
    if len(yeni) != len(data):
        raise GizlemeHatasi("internal error: output length %d != input length %d"
                            % (len(yeni), len(data)))
    # 1) IndexBuffer DISINDA hicbir tampon degismemis olmali. Degistiyse yazici bu
    #    mesh'te kimlik testini gecmiyor demektir -> sessizce baska veri yazmayiz.
    #    (Bos kume de gecerlidir: zaten gizli bir parcayi tekrar gizlemek DEGISIKLIK
    #    URETMEZ ve bu bir hata degil, ETKISIZLIKTIR -- islem tekrarlanabilir olmali.)
    degisen = list(rap.get("degisen_tampon") or [])
    disari = [nm for nm in degisen if nm != "IndexBuffer"]
    if disari:
        raise GizlemeHatasi(
            "refusing: rebuilding this mesh would also change %s, not just its index "
            "buffer" % ", ".join(disari), dict(degisen=degisen))
    # 2) Degisen her bayt IndexBuffer araliginda mi (yaziciya degil BAYTLARA sor)
    T = R["CMD"]["tampon"]["IndexBuffer"]
    o0, o1 = int(T["off"]), int(T["off"]) + int(T["len"])
    a = np.frombuffer(bytes(data), np.uint8)
    b = np.frombuffer(bytes(yeni), np.uint8)
    fark = np.nonzero(a != b)[0]
    if fark.size and (int(fark.min()) < o0 or int(fark.max()) >= o1):
        raise GizlemeHatasi("internal error: %d byte(s) changed outside the index buffer"
                            % int(((fark < o0) | (fark >= o1)).sum()))
    # 3) Cikti KENDI OKUYUCUMUZLA geri okunabilmeli (kur_mesh dogrulamasinin sarti)
    try:
        R3, G3 = MY.oku(yeni, rigid=True)
    except MY.DesteklenmiyorHatasi as e:
        raise GizlemeHatasi("internal error: the hidden mesh no longer parses (%s)" % e,
                            e.ayrinti)
    if int(G3["NV"]) != int(G["NV"]) or int(G3["NT"]) != int(G["NT"]):
        raise GizlemeHatasi("internal error: vertex/triangle count changed (%d/%d -> %d/%d)"
                            % (G["NV"], G["NT"], G3["NV"], G3["NT"]))
    # 4) Hedef ucgenlerin HEPSI dejenere ve alani TAM SIFIR; hedef DISI ucgenler
    #    bit-birebir korunmus olmali.
    ib3 = np.asarray(G3["ibg"])
    dej3 = _dejenere_maske(ib3)
    P = np.asarray(G3["pos"], np.float64)
    kapsanan = np.zeros(int(G["NT"]), bool)
    maks_alan = 0.0
    for i, t0, t1 in dilim:
        if t1 <= t0:
            continue
        kapsanan[t0:t1] = True
        if not bool(dej3[t0:t1].all()):
            raise GizlemeHatasi("internal error: part %d still has non-degenerate triangles" % i)
        tri = ib3[t0:t1]
        x = P[tri[:, 0]]; y = P[tri[:, 1]]; z = P[tri[:, 2]]
        maks_alan = max(maks_alan, float(np.abs(np.cross(y - x, z - x)).max()) if len(tri) else 0.0)
    if maks_alan != 0.0:
        raise GizlemeHatasi("internal error: hidden triangles are not exactly zero-area "
                            "(max |cross| = %r)" % maks_alan)
    ib0 = np.asarray(G["ibg"])
    if kapsanan.size and not np.array_equal(ib0[~kapsanan], ib3[~kapsanan]):
        raise GizlemeHatasi("internal error: triangles outside the hidden parts changed")

    rapor = dict(surum=SURUM, hedef=hedef, prim_sayi=len(G["prims"]),
                 NV=int(G["NV"]), NT=int(G["NT"]), fmt=int(R["CMD"]["fmt"]),
                 rigid=bool(R.get("rigid")), alt_varyant=bool(R.get("alt_varyant")),
                 dosya_B=len(data), ayni_bayt=bool(fark.size == 0),
                 # hedef parca(lar) VARDI ama tek bayt degismediyse zaten gizliydiler
                 zaten_gizliydi=bool(fark.size == 0 and kapsanan.any()),
                 degisen_bayt=int(fark.size), degisen_tampon=degisen,
                 indeks_tampon=(o0, o1 - o0),
                 gizlenen_ucgen=int(kapsanan.sum()), maks_ucgen_alani=maks_alan,
                 sha_eski=rap["sha_eski"], sha_yeni=rap["sha_yeni"])
    return bytes(yeni), rapor


def gizle_bayt(data, prim=None, rigid=None):
    """ISTENEN API: forge ic dosyasi baytlari -> GORUNMEZ hali (YALNIZ BAYTLAR).
    Olcum raporu da isteyen cagiran `gizle()` kullanmali -- bu islev tek deger doner.

    `rigid`: cagiran uyumlulugu icin KABUL EDILIR ve YOK SAYILIR. Okuyucu bu modulde
    daima `rigid=True` ile calisir: gizleme derili (fmt 0/1) ve derisiz (fmt 3/4)
    mesh'te AYNI islemdir (indeks dejenerasyonu), dolayisiyla ayirmanin anlami yok.
    Yanlis bir `rigid` degeri yuzunden cagri patlamasin diye sessizce yutulur."""
    return gizle(data, prim=prim)[0]
