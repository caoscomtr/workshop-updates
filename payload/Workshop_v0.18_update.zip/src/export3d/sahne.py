# -*- coding: utf-8 -*-
"""sahne — indeks anahtari -> GLB (mesh + iskelet/skin + gomulu doku) + manifest + README.

Plan: tasarim\\3D_DISA_AKTARMA_PLANI.md §3.2 / §5 Adim 6. Bu modul diger bes modulu
tek hatta diker; oyun dosyasina DOKUNMAZ (paylasilan LeanForge, 'rb'; is bitince
`outfit_core.release_forge(onbellek=False)` finally icinde).

Veri akisi (parca = indeks grubunun lodlar[lod] kaydi):
  forge_giris.ic_dosya -> mesh_yapisal.oku -> bayt_kapisi (hepsi=False -> parca GLB'ye
  GIRMEZ, manifest 'atlandi' + sebep) -> primitive'ler (MeshPrimitive.base/firstIdx ile
  dilimlenir; CPI DEGIL, Hat_Morgan olcumu) -> doku_png (materyal basina 1 kez) -> skin
  (iskelet.rig_uygunluk: hata <= tol ise HIYERARSIK: palet kemigi rig dugumune baglanir;
  degilse DUZ: her palet kemigi SkeletonRoot altinda matrix = Cm.inv(IBM)) ->
  Root_Zup_to_Yup -> write -> manifest.json + README.txt.

Skin kurali (P0/P0b olcumleri): 8 etki/vertex JOINTS_0+JOINTS_1 olarak yazilir; rigin
326 dugumunun TAMAMI her skin'in joints listesinde (aksi Blender'da 272 EMPTY);
palet kemiklerinin IBM'i daima paletten VERBATIM (16 float bayt-birebir), palet disi
rig dugumlerinin IBM'i inv(Cinv.G_rig) (hicbir vertex onlara bagli degil).

Cikti klasoru ASLA ezilmez: `serbest_ad` -> <ad>, <ad>_2, <ad>_3 ...  Kok klasor
~\\Documents\\OutfitWorkshop\\3D, yani OUTPUT\\<ad> (APPLY akisinin taradigi yer) ile AYRIK;
PNG'ler TEX_ onekli (outfit_core._SLOT_RE tanimaz -> apply adayi uretmez).

GEVSEK KOPYA (plan §8 acik karar, 2026-09-03 olcumu): GLB'ye gomulen diffuse+normal PNG'lerin
textures\\ altinda AYRICA durmasi toplami ~2x yapiyordu (Edward_Assassin 223 MB, U_Edward_Yasuke
253 MB; plan kapisi (f) < 150 MB, 09-03'te olculen maksimuma gore 160 MB'a cekildi: U_Edward_Yasuke
155,4 MB = GLB 112,1 + gevsek referans 43,3). 2026-09-04'TE KARAR DONDU: `GEVSEK_GOMULU_KOPYA = True`,
cunku ITHALAT (doku_ithal.py) acildi ve kullanicinin boyayacagi yuzey `textures\\` klasorudur --
gomulu kalan diffuse/normal geri getirilemiyordu. `kur(..., gevsek_kopya=False)` eski davranisi
verir (gomulen goruntunun gevsek kopyasi GLB yazildiktan sonra SILINIR); testler icin ortam
degiskeni `EXPORT3D_GEVSEK_KOPYA=0` ayni sonucu kod degistirmeden verir.
"""
import functools
import hashlib
import json
import os
import time

import numpy as np

import outfit_core as C

try:
    from . import cok_forge as CF
    from . import forge_giris as FG
    from . import mesh_yapisal as MY
    from . import iskelet as ISK
    from . import glb_yaz as GY
    from . import doku_png as DP
except ImportError:                                   # modul dosya yolundan yuklendiyse
    import cok_forge as CF
    import forge_giris as FG
    import mesh_yapisal as MY
    import iskelet as ISK
    import glb_yaz as GY
    import doku_png as DP

__all__ = ["kur", "parcalar", "serbest_ad", "indeks_yukle", "silah_indeks_yukle",
           "silah_parcalar", "VARSAYILAN_KOK", "SURUM"]

# 1.1 (2026-09-05): K-1a -- eslesen palet kemiginin IBM'i artik RIG'IN DUNYA MATRISINDEN
# turetilir (bkz. _skin_kur). 1.0 export'lari IBM'i verbatim yaziyordu ve Blender tur-donusunde
# dokunulmamis parcalar 1,6 mm kayiyordu; ithalatci bunu artik OLCEREK ayikliyor
# (glb_oku "(1d)" + mesh_ithal "BAYAT EXPORT KAPISI"), damga ise manifest'te kayit birakir.
SURUM = "1.1"
BURA = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(BURA)
KOK = os.path.dirname(SRC)
# OUTPUT\3D: sunucu.OUTPUT = ~\Documents\OutfitWorkshop ile ayni kok, "3D" alt klasoru
VARSAYILAN_KOK = os.path.join(os.path.expanduser("~"), "Documents", "OutfitWorkshop", "3D")
RIG_AD = "edward_326"
RIG_TOL = 5e-3                    # metre; plan §1.2 (4) rig uygunluk kapisi
SKELETON_ROOT_AD = "SkeletonRoot"
TEXTURES_KLASOR = "textures"
MANIFEST_AD = "manifest.json"
README_AD = "README.txt"
# Silah indeksi (tools\silah_indeks_kur.py uretir): kiyafet indeksinden AYRI dosya
SILAH_INDEKS_AD = "silah_indeks.json"
# GLB'ye gomulen diffuse/normal PNG'nin textures\ altinda ayrica kopyasi kalsin mi? (modul docstring)
#
# 2026-09-04 KARARI DEGISTI -> True. Gerekce OLCUM: ITHALAT (doku_ithal.py) acildi ve
# kullanicinin boyayacagi yuzey `textures\` klasorudur. False iken en onemli iki harita
# (diffuse + normal) GLB'nin ICINDE kaliyordu; kullanici onlari Blender'dan disari
# cikarip geri koyamadigi icin "dokuyu da boya" hedefi PRATIKTE OLUSMUYORDU.
# Bedeli olculdu (bu makinedeki 10 export): en buyuk klasor U_Edward_Yasuke
# 112,1 MB GLB + 141,0 MB gevsek = 253 MB. Ithalat olmadan bu bedel bosunaydi;
# ithalatla birlikte gevsek PNG artik CIKTININ KENDISI.
GEVSEK_GOMULU_KOPYA = True


# ------------------------------------------------------------------ yardimcilar
def serbest_ad(klasor, kok):
    """Var olmayan klasor yolu: <kok>, <kok>_2, <kok>_3 ... (ship_motor.serbest_ad kalibi,
    plan §3.3: '<ad>_2\\'). Ikinci export bir oncekini ASLA ezmez."""
    aday = os.path.join(klasor, kok)
    if not os.path.exists(aday):
        return aday
    n = 2
    while True:
        aday = os.path.join(klasor, "%s_%d" % (kok, n))
        if not os.path.exists(aday):
            return aday
        n += 1


def indeks_yukle():
    """(kiyafetler_sozlugu, kaynak_yolu). Once onizleme3d.indeks() (pakette src\\onizleme3d.py +
    src\\onizleme3d_indeks.json), yoksa JSON dogrudan (gelistirme agaci: KOK\\onizleme3d\\)."""
    try:
        import onizleme3d as O3
        d = O3.indeks()
        if d:
            return d, getattr(O3, "INDEKS_YOL", None)
    except Exception:                                 # noqa: BLE001 -- yedek yola dusulur
        pass
    adaylar = [os.path.join(SRC, "onizleme3d_indeks.json"),
               os.path.join(KOK, "onizleme3d", "onizleme3d_indeks.json")]
    for a in adaylar:
        if os.path.isfile(a):
            with open(a, encoding="utf-8") as f:
                return json.load(f)["kiyafetler"], a
    raise FileNotFoundError("3D index not found: %s" % adaylar)


ENVANTER_AD = "parca_envanteri.json"
_ENVANTER = {}


def envanter_yukle():
    """(kayitlar_sozlugu, yol) -- parca_envanteri.json (446 kayit: player/npc kiyafetleri,
    npc karakterleri, murettebat). onizleme3d_indeks.json'un KARDESI; yoksa bos sozluk."""
    if "veri" in _ENVANTER:
        return _ENVANTER["veri"], _ENVANTER.get("yol")
    for a in (os.path.join(SRC, ENVANTER_AD), os.path.join(KOK, "onizleme3d", ENVANTER_AD)):
        if os.path.isfile(a):
            try:
                with open(a, encoding="utf-8") as f:
                    d = json.load(f).get("kayitlar") or {}
                _ENVANTER["veri"], _ENVANTER["yol"] = d, a
                return d, a
            except Exception:                                 # noqa: BLE001 -- bozuk dosya = yok
                break
    _ENVANTER["veri"], _ENVANTER["yol"] = {}, None
    return {}, None


def _envanter_kaydi(anahtar):
    """Envanter kaydini INDEKS bicimine cevirir: {gruplar:[{taban, lodlar}], mesh_mat:{},
    gorunen_ad, kategori}. Kayit yoksa None."""
    env, _y = envanter_yukle()
    v = env.get(anahtar)
    if not v:
        return None
    gruplar = []
    for p in v.get("parcalar") or []:
        lodlar = [list(x) for x in (p.get("lodlar") or []) if x and x[1] is not None]
        if not lodlar:
            continue
        gruplar.append({"taban": p.get("taban"), "lodlar": lodlar,
                        "materyaller": p.get("materyaller") or [],
                        "okunur": bool(p.get("okunur", p.get("okunabilir", True)))})
    return {"gruplar": gruplar, "mesh_mat": {}, "gorunen_ad": v.get("gorunen_ad"),
            "kategori": v.get("kategori"), "kaynak": "envanter"}


def kayit_bul(anahtar):
    """Indeks kaydi ya da (yoksa) envanter kaydi; hicbiri yoksa KeyError."""
    idx, _yol = indeks_yukle()
    if anahtar in idx:
        return idx[anahtar]
    k = _envanter_kaydi(anahtar)
    if k is None:
        raise KeyError("'%s' not in 3D index" % anahtar)
    return k


def anahtar_var(anahtar, silah=False):
    """Bu anahtar disa aktarilabilir mi (indeks ya da envanterde var mi)?"""
    try:
        if silah:
            idx, _y = silah_indeks_yukle()
            return anahtar in idx
        kayit_bul(anahtar)
        return True
    except (KeyError, FileNotFoundError):
        return False


def parcalar(anahtar, lod=0):
    """kayit.gruplar[*].lodlar[lod] -> [{ad, gid, icid, boyut, taban, sebep}].
    Kayit indeksten ya da envanterden gelir (kayit_bul). LOD yoksa kayit `sebep` ile
    gelir (parca atlanir, sessiz dusme yok)."""
    kayit = kayit_bul(anahtar)
    out = []
    for g in kayit.get("gruplar", []):
        lodlar = g.get("lodlar") or []
        if lod < len(lodlar):
            boyut, gid, icid, ad = lodlar[lod]
            out.append(dict(ad=str(ad), gid=int(gid), icid=int(icid), boyut=int(boyut),
                            taban=g.get("taban"), sebep=None))
        else:
            out.append(dict(ad=str(g.get("taban") or "?"), gid=None, icid=None, boyut=None,
                            taban=g.get("taban"),
                            sebep="LOD %d not available (%d LODs in index)" % (lod, len(lodlar))))
    return out


def silah_indeks_yukle():
    """(silahlar_sozlugu, kaynak_yolu). Silahlar KIYAFETLERDEN AYRI bir indekste durur
    (src\\export3d\\silah_indeks.json); dosya yoksa FileNotFoundError."""
    adaylar = [os.path.join(BURA, SILAH_INDEKS_AD), os.path.join(SRC, SILAH_INDEKS_AD)]
    for a in adaylar:
        if os.path.isfile(a):
            with open(a, encoding="utf-8") as f:
                return json.load(f)["silahlar"], a
    raise FileNotFoundError("weapon 3D index not found: %s" % adaylar)


def silah_parcalar(anahtar, lod=0):
    """silah_indeks[anahtar].gruplar[*] -> [{ad, gid, icid, boyut, taban, sebep, adaylar}].

    `adaylar` = istenen LOD'dan BASLAYAN (gid, icid, ad) listesi: silah zincirlerinde
    LOD0 canli TOC'ta olmayabiliyor ya da MPH varyanti cikabiliyor (olculdu: 5 aile),
    o zaman `kur` bir sonraki LOD'a duser -- sessiz dusme yok, manifest'e yazilir."""
    idx, _yol = silah_indeks_yukle()
    if anahtar not in idx:
        raise KeyError("'%s' not in weapon 3D index" % anahtar)
    out = []
    for g in idx[anahtar].get("gruplar", []):
        lodlar = g.get("lodlar") or []
        bas = lod if lod < len(lodlar) else (g.get("lod_secilen") or 0)
        if bas < len(lodlar):
            boyut, gid, icid, ad = lodlar[bas]
            out.append(dict(ad=str(ad), gid=int(gid), icid=int(icid), boyut=int(boyut),
                            taban=g.get("taban"), sebep=None,
                            adaylar=[(int(x[1]), int(x[2]), str(x[3])) for x in lodlar[bas:]]))
        else:
            out.append(dict(ad=str(g.get("taban") or "?"), gid=None, icid=None, boyut=None,
                            taban=g.get("taban"), adaylar=[],
                            sebep="LOD %d not available (%d LODs in index)" % (lod, len(lodlar))))
    return out


def _json_uygun(v):
    """numpy / bytes -> JSON'lanabilir (manifest)."""
    if isinstance(v, dict):
        return {str(k): _json_uygun(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_json_uygun(x) for x in v]
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    return v


def _goreli(yol, klasor):
    if not yol:
        return None
    try:
        return os.path.relpath(yol, klasor).replace("\\", "/")
    except ValueError:
        return yol


def _kopya_eklem_var(j, w):
    """Ayni vertexte ayni eklem iki yuvada (agirlik>0) mi? (Blender REPLACE tuzagi, glb_yaz notu)"""
    if j.shape[1] < 2:
        return False
    k = j.shape[1]
    jj = np.where(w > 0, j, -1 - np.arange(k)[None, :])       # agirliksiz yuva benzersiz negatif
    s = np.sort(jj, axis=1)
    return bool((s[:, 1:] == s[:, :-1]).any())


# ------------------------------------------------------------------ rig dugumleri
class _Rig:
    """326 rig dugumu + SkeletonRoot (matrix = Cinv) bir kez kurulur; her parcanin skin'i
    bunlari paylasir. `ibm_varsayilan[i]` = inv(Cinv.G_rig[i]) (palet disi rig dugumu icin)."""

    def __init__(self, W, rig):
        self.rig = rig
        self.G = ISK.global_matrisler(rig)                                     # (n,4,4) iskelet uzayi
        n = rig["n"]
        self.dugum = [W.add_node(rig["adlar"][i], translation=rig["yerel_pos"][i],
                                 rotation=rig["yerel_quat"][i]) for i in range(n)]
        kokler = []
        for i in range(n):
            e = rig["ebeveyn"][i]
            if e >= 0:
                W.cocuk_ekle(self.dugum[e], self.dugum[i])
            else:
                kokler.append(self.dugum[i])
        self.sk_root = W.add_node(SKELETON_ROOT_AD, matrix=ISK.Cinv, children=kokler)
        mesh_global = np.einsum("ab,nbc->nac", ISK.Cinv, self.G)              # dugum globali (mesh uzayi)
        self.ibm_varsayilan = np.linalg.inv(mesh_global)


def _skin_kur(W, RD, R, G, parca_ad):
    """Parca skin'i: joints = 326 rig dugumu + (addon | duz) palet dugumleri.
    Doner (skin_idx, palet2joint (kc,), uygunluk_sozlugu, hiyerarsik_mi, ek_dugum_sayisi)."""
    kc = R["kemik"]["sayi"]
    palet = np.asarray(G["matris"], np.float32)
    u = ISK.rig_uygunluk(RD.rig, R["kemik"]["crc32"], palet, tol=RIG_TOL)
    ibm_rm = ISK.ibm_satir_major(palet)                     # (kc,4,4) satir-major = ham^T
    duz_mt = ISK.duz_dugum_matrisleri(palet)                # Cm.inv(IBM): duz yaprak dugum matrisi
    hiyerarsik = bool(u["uygun"])
    n = RD.rig["n"]
    joints = list(RD.dugum)
    ibm = [RD.ibm_varsayilan[i] for i in range(n)]
    palet2joint = np.zeros(kc, np.int64)
    ek = 0
    crcs = R["kemik"]["crc32"]
    for pi in range(kc):
        a = u["eslesme"][pi] if hiyerarsik else None
        if a is not None:
            palet2joint[pi] = a
            # K-1a (2026-09-05, Blender kimlik turuyla olculdu): paletin IBM'i VERBATIM
            # yazilinca rig dugum hiyerarsisiyle tutarsiz kaliyordu (Diplomat Mannequin/Pants:
            # P_O_BV_Abs kemiginde W_rig x IBM_palet sapmasi 4,23 mm; RIG_TOL 5 mm bunu
            # "uygun" sayiyor). Blender 'Apply Modifiers' ile bu sapmayi bakiyor -> 299 vertex
            # 1,6 mm kayiyor, dokunulmamis parca yeniden yaziliyordu. IBM artik rig'in kendi
            # dunya matrisinden turetilir: W_rig x IBM = I, dinlenme pozu = bind konumu.
            # Paletin ham IBM'i oyuna geri yazilmaz (ithalat deriyi tasimaz), kayip yok.
            ibm[a] = RD.ibm_varsayilan[a]
        else:
            crc = int(crcs[pi], 16) if isinstance(crcs[pi], str) else int(crcs[pi])
            ad = ("addon_%08X" if hiyerarsik else "flat_%08X") % crc
            nd = W.add_node("%s@%s" % (ad, parca_ad), matrix=duz_mt[pi])
            W.cocuk_ekle(RD.sk_root, nd)
            palet2joint[pi] = len(joints)
            joints.append(nd)
            ibm.append(ibm_rm[pi])
            ek += 1
    skin = W.add_skin(joints, np.asarray(ibm, np.float32), skeleton=RD.sk_root, name=parca_ad + "_skin")
    return skin, palet2joint, u, hiyerarsik, ek


# ------------------------------------------------------------------ materyal / doku
class _Materyaller:
    """Materyal basina 1 GLB materyali; PNG yola gore 1 kez gomulur (paylasilan TextureSet)."""

    def __init__(self, W, tex_klasor, progress):
        self.W, self.tex_klasor, self.progress = W, tex_klasor, progress
        self.mat = {}          # mat_id(int) -> glb material idx
        self.rapor = {}        # "0x..." -> doku_png sonucu (manifest)
        self.goruntu = {}      # normcase(yol) -> texture idx
        self.gomulu_yollar = []  # gomulen PNG'lerin mutlak yollari (gevsek kopya temizligi icin)
        self.gomulu_bayt = 0

    def _doku(self, yol):
        if not yol or not os.path.isfile(yol):
            return None
        k = os.path.normcase(os.path.abspath(yol))
        if k in self.goruntu:
            return self.goruntu[k]
        with open(yol, "rb") as f:
            b = f.read()
        img = self.W.add_image_png(b, os.path.splitext(os.path.basename(yol))[0])
        t = self.W.add_texture(img, os.path.splitext(os.path.basename(yol))[0])
        self.goruntu[k] = t
        self.gomulu_yollar.append(os.path.abspath(yol))
        self.gomulu_bayt += len(b)
        return t

    def al(self, mat_id, yedek=None):
        """`yedek`: mesh'in kendi materyali forge'da yoksa denenecek materyal id'leri
        (silah hattinda silah_katalog.json'un materyalleri; olculdu: trinket mesh'lerinin
        MeshInstancingData materyali forge'da YOK, katalogunki VAR)."""
        key = mat_id if isinstance(mat_id, int) else int(str(mat_id), 16)
        if key in self.mat:
            return self.mat[key]
        r = DP.materyal_dokulari(key, self.tex_klasor, self.progress)
        if r.get("kaynak") is None and yedek:
            for y in yedek:
                yk = y if isinstance(y, int) else int(str(y), 16)
                if yk == key:
                    continue
                ry = DP.materyal_dokulari(yk, self.tex_klasor, self.progress)
                if ry.get("kaynak") is not None:
                    r = dict(ry, yerine_gecen="0x%X" % yk)   # gercekten kullanilan materyal
                    break
        base = self._doku(r.get("diffuse"))
        normal = self._doku(r.get("normal"))
        # kesim maskeli kartlar (sac/sakal/kirpik): diffuse yoksa beyaz+maske tabani kullan
        if base is None and r.get("kesim_taban"):
            base = self._doku(r["kesim_taban"])
        alfa = "MASK" if r.get("alfa_turu") == "cutout" else "OPAQUE"
        # SAC/SAKAL RENGI (doku_png.materyal_tonu): sacin diffuse dokusu YOKTUR, rengi
        # materyalin kendi ton parametresinde durur -> baseColorFactor. Ton parametresi
        # yalniz sac ailesinde var (olculdu: 122/122 sac materyali, 0/316 diger); yine de
        # diffuse'u OLAN bir materyalde dokuyu renklendirmemek icin kosul aciktir.
        ton = r.get("ton")
        bcf = ton["baseColorFactor"] if (ton and not r.get("diffuse")) else None
        mi = self.W.add_material("MAT_%X" % key, base, normal, alpha_mode=alfa, base_color=bcf)
        self.mat[key] = mi
        self.rapor["0x%X" % key] = r
        return mi


def _prim_materyalleri(R, mesh_mat_listesi):
    """primitive i -> materyal id ('0x...' | None). Once MeshInstancingData (590/590 mesh'te
    sayisi prim sayisina esit, olculdu), tutmazsa indeksin mesh_mat listesi, o da yoksa
    CBA materyal listesi (sira ayni, onizleme3d veri zinciri 4)."""
    prims = R["MeshData"]["prims"]
    mids = R["MeshData"].get("MeshInstancingData") or []
    n = len(prims)
    if len(mids) == n:
        return [m["material"] for m in mids], "MeshInstancingData"
    if mesh_mat_listesi and len(mesh_mat_listesi) == n:
        return list(mesh_mat_listesi), "index mesh_mat"
    cba = R["MeshData"].get("CBA43E05", {}).get("material_listesi") or []
    if len(cba) == n:
        return list(cba), "material list"
    out = [None] * n
    for i in range(min(n, len(mids))):
        out[i] = mids[i]["material"]
    return out, "partial"


# ------------------------------------------------------------------ ana hat

def _zincirli(fn):
    """YAMA ZINCIRI (2026-10-12, Nexus LordOfThe9): EXPORT 3D mesh'i oyunun gordugu zincirden okur
    (CF.okuma_gorunumu: boot_patch_01 > boot). Eskiden tek forge okunuyordu: Connor/Altair gibi
    Patch_01'de guncellenen kiyafetlerde boot'un ESKI mesh'i cikiyordu. Manifest her parcanin
    hangi arsivden okundugunu `arsiv` alaninda soyler (olculebilir)."""
    @functools.wraps(fn)
    def sar(*a, **k):
        with CF.okuma_gorunumu(C, getattr(C, "FORGE", None)):
            return fn(*a, **k)
    return sar


def _kimin(lf, gid):
    """Parcanin okundugu arsivin adi (cok-forge gorunumunde sahibi; tek forge'da dosyanin kendisi)."""
    k = getattr(lf, "kimin", None)
    if k is not None and gid is not None:
        try:
            return k(int(gid))
        except Exception:                                  # noqa: BLE001
            pass
    return os.path.basename(getattr(lf, "path", "") or "")


@_zincirli
def kur(anahtar, out_dir=None, lod=0, progress=None, gevsek_kopya=None, silah=False):
    """Bir indeks anahtarini (kiyafet / CHR_* grubu / SILAH) GLB'ye yazar.

    silah=False (VARSAYILAN): kiyafet-karakter hatti -- DEGISMEDI. Kaynak onizleme3d
    indeksi, her parca skinli okunur, 326 dugumlu Edward rigi daima kurulur.
    silah=True: kaynak `silah_indeks.json`. Silahlarin bir kismi RIGID'dir (CMD fmt 3/4,
    skinsiz: pistol / musket / mizrak / blunderbuss); onlar ARMATURSUZ, duz mesh dugumu
    olarak yazilir (JOINTS/WEIGHTS yok). Kalani (kilic / trinket / gizli bicak / kilif)
    skinlidir ve ESKI yolla, rig kurularak yazilir. Rig YALNIZ skinli parca varsa
    olusturulur, yani rigid-only bir silah GLB'sinde armature hic yoktur.

    gevsek_kopya: None -> ortam degiskeni EXPORT3D_GEVSEK_KOPYA varsa o ("1"/"0"), yoksa
    GEVSEK_GOMULU_KOPYA sabiti; False -> GLB'ye gomulen diffuse/normal PNG'nin textures\\
    altindaki kopyasi GLB yazildiktan sonra silinir (modul docstring). Ortam degiskeni sadece
    testler icin (kaynak kod cagrisi acikca True/False verirse ona uyulur, ortam devreye girmez).
    Doner: {ok, klasor, glb, parca_sayisi, cikan, atlanan:[{ad, gid, icid, sebep}],
            rig:{hiyerarsik, duz}, sure, ...olcumler}
    Oyun dosyasi yalniz okunur; sonunda outfit_core.release_forge(onbellek=False)."""
    t0 = time.time()
    if gevsek_kopya is None:
        _env = os.environ.get("EXPORT3D_GEVSEK_KOPYA")
        gevsek_kopya = (_env not in (None, "", "0")) if _env is not None else GEVSEK_GOMULU_KOPYA
    kok = out_dir or os.environ.get("OW_EXPORT3D_KOK") or VARSAYILAN_KOK
    os.makedirs(kok, exist_ok=True)
    klasor = serbest_ad(kok, str(anahtar))
    tex_klasor = os.path.join(klasor, TEXTURES_KLASOR)
    if silah:
        idx, idx_yol = silah_indeks_yukle()
        if anahtar not in idx:
            raise KeyError("'%s' not in weapon 3D index" % anahtar)
        kayit = idx[anahtar]
        mesh_mat = {}
        yedek_mat = list(kayit.get("katalog_materyal") or [])
        liste = silah_parcalar(anahtar, lod)
    else:
        idx, idx_yol = indeks_yukle()
        kayit = kayit_bul(anahtar)                    # indeks ya da parca_envanteri
        if kayit.get("kaynak") == "envanter":
            _e, idx_yol = envanter_yukle()
        mesh_mat = kayit.get("mesh_mat") or {}
        yedek_mat = []
        liste = parcalar(anahtar, lod)
    os.makedirs(tex_klasor, exist_ok=True)
    DP.onbellek_temizle()

    W = GY.GlbWriter()
    rig = ISK.rig_yukle(RIG_AD)
    # Silah hattinda rig LAZY kurulur (ilk skinli parcada); rigid-only GLB'de armature yok.
    RD = None if silah else _Rig(W, rig)
    MAT = _Materyaller(W, tex_klasor, progress)
    mesh_dugumleri = []
    manifest_parcalar = []
    atlanan = []
    say = {"hiyerarsik": 0, "duz": 0}
    toplam_nv = toplam_nt = 0
    kopya_toplam = 0
    yinelenen_toplam = 0
    kayip_maks = 0.0                 # 8 yuvaya sigmayan agirligin en buyuk orani (tum parcalar)
    kayipli_parca = 0
    n_parca = len(liste)
    try:
        lf = C._forge()
        for i, p in enumerate(liste):
            C._log(progress, "part %d / %d: %s" % (i + 1, n_parca, p["ad"]))
            m = {"ad": p["ad"], "taban": p["taban"], "gid": ("0x%012X" % p["gid"]) if p["gid"] is not None else None,
                 "icid": ("0x%012X" % p["icid"]) if p["icid"] is not None else None, "lod": lod,
                 "durum": "atlandi", "sebep": None, "arsiv": _kimin(lf, p["gid"])}
            manifest_parcalar.append(m)

            def atla(sebep):
                m["sebep"] = sebep
                atlanan.append({"ad": p["ad"], "gid": m["gid"], "icid": m["icid"], "sebep": sebep})
                C._log(progress, "  skipped: %s" % sebep)

            if p["sebep"]:
                atla(p["sebep"]); continue
            # --- ic dosya (+ yapisal okuma). Silah hattinda LOD zinciri denenir: LOD0
            #     canli TOC'ta olmayabilir ya da MPH varyanti cikabilir (olculdu: 5 aile).
            adaylar = p.get("adaylar") or [(p["gid"], p["icid"], p["ad"])]
            data = R = G = None
            sebep = None
            for _li, (_gid, _icid, _ad) in enumerate(adaylar):
                try:
                    _data = FG.ic_dosya(lf, _gid, _icid)
                except KeyError as e:
                    sebep = sebep or "not in live TOC (%s)" % e
                    continue
                except (ValueError, AssertionError) as e:
                    sebep = sebep or "container error: %s" % str(e)[:120]
                    continue
                try:
                    R, G = MY.oku(_data, rigid=bool(silah))
                except MY.DesteklenmiyorHatasi as e:
                    if sebep is None:
                        sebep = e.sebep
                        m["ayrinti"] = None if e.ayrinti is None else str(e.ayrinti)[:160]
                    R = G = None
                    continue
                data = _data
                if _li:                       # istenen LOD tutmadi, alt LOD'a duruldu
                    m["lod"] = lod + _li
                    m["lod_geri_dusme"] = {"istenen": lod, "kullanilan": lod + _li, "sebep": sebep}
                    m["ad"] = p["ad"] = _ad
                    m["gid"] = "0x%012X" % _gid
                    m["icid"] = "0x%012X" % _icid
                    C._log(progress, "  LOD %d unusable (%s) -> using LOD %d" % (lod, sebep, lod + _li))
                break
            if data is None:
                atla(sebep or "no readable LOD"); continue
            m["ic_bayt"] = len(data)
            m["sha256"] = hashlib.sha256(data).hexdigest()
            rigid = bool(G.get("rigid"))
            m.update(NV=int(G["NV"]), NT=int(G["NT"]), fmt=int(R["CMD"]["fmt"]),
                     stride=dict(R["CMD"]["stride"]), kemik=int(R["kemik"]["sayi"]),
                     kemik_per_vertex=int(G["nb"]), prim=len(G["prims"]), rigid=rigid)
            # --- bayt kapisi (fail-closed)
            bk = MY.bayt_kapisi(R, G, data)
            m["bayt_kapisi"] = bk
            if not bk["hepsi"]:
                dusen = [k for k in MY.TAMPONLAR if not bk[k]]
                atla("byte gate failed: %s" % ", ".join(dusen)); continue
            # --- skin (rigid parcada YOK: armature'suz duz mesh)
            if rigid:
                skin = palet2joint = None
                m["rig_uygunluk"] = None
            else:
                if RD is None:                                  # lazy rig (yalniz silah hatti)
                    RD = _Rig(W, rig)
                skin, palet2joint, u, hiyerarsik, ek = _skin_kur(W, RD, R, G, p["ad"])
                m["rig_uygunluk"] = {"eslesen": u["eslesen"], "addon": u["addon"], "hata_maks": u["hata_maks"],
                                     "hata_medyan": u["hata_medyan"], "uygun": u["uygun"], "tol": u["tol"],
                                     "hiyerarsik": hiyerarsik, "ek_dugum": ek, "addon_crc": u["addon_crc"]}
                say["hiyerarsik" if hiyerarsik else "duz"] += 1
            # --- vertex verisi (mesh uzayi, Z-up; kok dugum Y-up'a cevirir)
            pos = G["pos"].astype(np.float32)
            uv0 = G["uv0"].astype(np.float32)
            if rigid:
                # rigid akista normal ZATEN cozulmus (u8x3, v/127-1) -- oktahedral kod yok
                nrm = np.ascontiguousarray(G["normal"], np.float32)
                jj = w8s = None
                m["kopya_eklem"] = 0
                m["agirlik_kaybi"] = None
                m["agirlik_toplam"] = None
                m["bayt_per_kemik"] = 0
            else:
                nrm = MY.okt_coz(G["nokt"], (G["bayrak"] & 1).astype(bool)).astype(np.float32)
                idx_h = G["kemik_idx"].astype(np.int64)
                w_h = G["agirlik"].astype(np.float64)
                order = np.argsort(-w_h, axis=1, kind="stable")     # ilk 4 = en buyuk 4 -> JOINTS_0
                j_s = np.take_along_axis(idx_h, order, 1)
                w_s = np.take_along_axis(w_h, order, 1)
                # glTF'te 8 yuva var (JOINTS_0+JOINTS_1); mesh 12/16 etki tasiyorsa en buyuk 8'i alinir
                # ve toplam 1.0'a YENIDEN NORMALLENIR. Dusen agirlik manifest'e yazilir (sessiz kayip yok).
                tut = min(w_s.shape[1], MY.GLTF_MAKS_ETKI)
                j8 = j_s[:, :tut]
                w_tut = w_s[:, :tut]
                _bol = w_tut.sum(1, keepdims=True)
                w8s = np.divide(w_tut, _bol, out=np.zeros_like(w_tut), where=_bol > 0).astype(np.float32)
                m["agirlik_kaybi"] = G.get("agirlik_kaybi") or R.get("agirlik_kaybi")
                m["agirlik_toplam"] = R.get("agirlik_toplam")
                m["bayt_per_kemik"] = int(G.get("bayt_per_kemik", 2))
                jj = palet2joint[j8]
                kopya = 0
                if _kopya_eklem_var(jj, w8s):
                    jj, w8s, kopya = GY.agirlik_tekillestir(jj, w8s)
                    kopya_toplam += kopya
                m["kopya_eklem"] = int(kopya)
            # --- primitive'ler (MeshPrimitive.base/firstIdx; IB prim-yerel)
            mat_ids, mat_kaynak = _prim_materyalleri(R, mesh_mat.get("%d:%d" % (p["gid"], p["icid"])))
            m["materyal_kaynagi"] = mat_kaynak
            prims = []
            m_mats = []
            yinelenen = 0
            _cpi = R["CMD"].get("CPI") or []
            _t0_rigid = 0
            for pi_, pr in enumerate(G["prims"]):
                if rigid:
                    # RIGID: IndexBuffer kume-dolgulu, MeshPrimitive.firstIdx dolgusuz akisa
                    # bakar -> gercek konum CPI[j].IndexStart, vertex tabani CPI[j].VertexStart.
                    # mesh_yapisal._geo_rigid G["ib"]yi prim sirasiyla ardisik dizdi (dolgu atilmis),
                    # bu yuzden ucgen dilimi kumulatif NT ile alinir.
                    b0 = int(_cpi[pi_]["VertexStart"]) if pi_ < len(_cpi) else int(pr["base"])
                    b1 = b0 + pr["NV"]
                    t0i, t1i = _t0_rigid, _t0_rigid + pr["NT"]
                    _t0_rigid = t1i
                else:
                    b0, b1 = pr["base"], pr["base"] + pr["NV"]
                    t0i = pr["firstIdx"] // 3
                    t1i = t0i + pr["NT"]
                tri = G["ib"][t0i:t1i].astype(np.uint32)
                # primitive ICI yinelenen ucgen (ayni 3 vertex, sira farki olabilir): Blender importeri
                # bunlari dusurur (olculdu: Yasuke Armorplate 1 -> polys = NT-1; primitive'ler arasi
                # yinelenenleri DUSURMEZ). Manifest'e yazilir; kapi (c) polys + yinelenen == NT.
                if len(tri):
                    _u, _c = np.unique(np.sort(tri.reshape(-1, 3), axis=1), axis=0, return_counts=True)
                    yinelenen += int((_c - 1).sum())
                mid = mat_ids[pi_]
                gm = None
                if mid:
                    gm = MAT.al(mid, yedek=yedek_mat)
                elif yedek_mat:                       # mesh materyal soylemiyorsa katalogunki
                    mid = yedek_mat[min(pi_, len(yedek_mat) - 1)]
                    gm = MAT.al(mid)
                m_mats.append(mid)
                prims.append(W.make_primitive(pos[b0:b1], nrm[b0:b1], uv0[b0:b1], tri, gm,
                                              joints8=None if jj is None else jj[b0:b1],
                                              weights8=None if w8s is None else w8s[b0:b1]))
            m["materyaller"] = m_mats
            m["yinelenen_ucgen"] = yinelenen
            yinelenen_toplam += yinelenen
            mesh = W.add_mesh(p["ad"], prims)
            nd = W.add_node(p["ad"], mesh=mesh, skin=skin)
            mesh_dugumleri.append(nd)
            _ak = m.get("agirlik_kaybi") or {}
            if float(_ak.get("maks") or 0.0) > 0:
                kayipli_parca += 1
                kayip_maks = max(kayip_maks, float(_ak["maks"]))
            m["durum"] = "cikan"
            m["bbox_min"] = [float(x) for x in pos.min(0)]
            m["bbox_max"] = [float(x) for x in pos.max(0)]
            toplam_nv += int(G["NV"]); toplam_nt += int(G["NT"])
        cikan = len(mesh_dugumleri)
        glb_yol = None
        glb_bayt = 0
        if cikan:
            root = W.kok_zup_yup(mesh_dugumleri + ([] if RD is None else [RD.sk_root]))
            glb_yol = os.path.join(klasor, "%s.glb" % anahtar)
            glb_bayt = W.write(glb_yol, [root])
            C._log(progress, "GLB written: %s (%.1f MB)" % (os.path.basename(glb_yol), glb_bayt / 1e6))
    finally:
        C.release_forge(onbellek=False)
        # doku_png'nin materyal/TextureSet onbellegi PNG YOLLARI tasir ve hemen asagida gomulen
        # PNG'ler silinebilir (gevsek_kopya=False). Ayni oturumda ayni TextureSet'i paylasan bir
        # SONRAKI export olmayan dosyayi gostermesin: onbellek export bitince de bosaltilir
        # (olculdu 2026-09-12, kamara proplari; _onbellekten de artik her yolu yokluyor).
        DP.onbellek_temizle()
    # --- gevsek kopya temizligi: gomulen PNG'ler (yalniz bu export'un textures\ klasorundekiler)
    silinen_gevsek = 0
    silinen_gevsek_bayt = 0
    if glb_yol and not gevsek_kopya:
        tex_nc = os.path.normcase(os.path.abspath(tex_klasor)) + os.sep
        for yol in MAT.gomulu_yollar:
            if os.path.normcase(yol).startswith(tex_nc) and os.path.isfile(yol):
                silinen_gevsek_bayt += os.path.getsize(yol)
                os.remove(yol)
                silinen_gevsek += 1
        if silinen_gevsek:
            C._log(progress, "loose copies of %d embedded textures removed (%.1f MB; they are inside the GLB)"
                   % (silinen_gevsek, silinen_gevsek_bayt / 1e6))
    sure = round(time.time() - t0, 3)
    # --- gevsek PNG toplami
    png_bayt = 0
    png_sayisi = 0
    if os.path.isdir(tex_klasor):
        for f in os.listdir(tex_klasor):
            if f.lower().endswith(".png"):
                png_bayt += os.path.getsize(os.path.join(tex_klasor, f)); png_sayisi += 1

    def _gevsek(yol):
        # manifest'te yalniz diskte DURAN dosya yol olarak yazilir (gomulup silinen -> None)
        return _goreli(yol, klasor) if yol and os.path.isfile(yol) else None
    # --- manifest
    materyaller = {}
    for mid, r in MAT.rapor.items():
        materyaller[mid] = {
            "kaynak": r.get("kaynak"), "ts_id": r.get("ts_id"),
            "diffuse": _gevsek(r.get("diffuse")), "normal": _gevsek(r.get("normal")),
            "gloss": _gevsek(r.get("gloss")), "emissive": _gevsek(r.get("emissive")),
            "mask": _gevsek(r.get("mask")), "diger": [_gevsek(x) for x in r.get("diger", [])],
            "atlanan": r.get("atlanan", []), "slotlar": r.get("slotlar", []), "sure": r.get("sure"),
            # baseColor'i bos kalan materyalin GEREKCESI (doku_png._diffuse_yok_sebep):
            # sac/sakal setlerinin diffuse dokusu YOKTUR -- eksik dosya degil, eksik varlik.
            "diffuse_yok_sebep": r.get("diffuse_yok_sebep"),
            # sac/sakal renk tonu (doku_png.materyal_tonu): iki renk + glTF'e yazilan deger
            "ton": r.get("ton"),
            "gomulu": {"diffuse": bool(r.get("diffuse")), "normal": bool(r.get("normal"))},
            "gomulu_goruntu": {"diffuse": os.path.splitext(os.path.basename(r["diffuse"]))[0] if r.get("diffuse") else None,
                               "normal": os.path.splitext(os.path.basename(r["normal"]))[0] if r.get("normal") else None}}
    manifest = {
        "surum": SURUM, "uretici": GY.URETICI, "tarih": time.strftime("%Y-%m-%d %H:%M:%S"),
        "anahtar": anahtar, "gorunen_ad": kayit.get("gorunen_ad"), "lod": lod, "indeks": idx_yol,
        "kategori": "weapon" if silah else "outfit",
        "silah": None if not silah else {
            "tur": kayit.get("tur"), "kaynak": kayit.get("kaynak"), "katalog": kayit.get("katalog"),
            "eslesme": kayit.get("eslesme"), "katalog_materyal": kayit.get("katalog_materyal"),
            "rigid_parca": sum(1 for x in manifest_parcalar if x.get("rigid")),
            "skinli_parca": sum(1 for x in manifest_parcalar if x.get("rigid") is False),
            "armature": RD is not None},
        "forge": getattr(C, "FORGE", None), "klasor": klasor,
        "glb": os.path.basename(glb_yol) if glb_yol else None, "glb_bayt": glb_bayt,
        "gomulu_doku_bayt": MAT.gomulu_bayt, "gomulu_goruntu_sayisi": len(MAT.goruntu),
        "gevsek_kopya": bool(gevsek_kopya), "silinen_gevsek": silinen_gevsek,
        "silinen_gevsek_bayt": silinen_gevsek_bayt,
        "gevsek_png": png_sayisi, "gevsek_png_bayt": png_bayt,
        "eksen": "GLB is Y-up (Root_Zup_to_Yup rotation on the game's Z-up mesh space); units are metres",
        "uv": "unchanged (DirectX/glTF convention: v down, origin top-left); textures are NOT flipped",
        "normal_g": NORMAL_G_NOTU % DP.NORMAL_G_TERS,
        "rig": {"ad": rig["ad"], "dugum": rig["n"], "iskelet": rig.get("iskelet"), "tol_m": RIG_TOL,
                "hiyerarsik": say["hiyerarsik"], "duz": say["duz"],
                # 2026-09-05 (K-1a): metin de duzeltildi -- eslesen kemigin IBM'i ARTIK verbatim
                # degil, rig dugumunun dunya matrisinden turetiliyor (W_rig x IBM = I).
                "Cm": ISK.Cm.tolist(), "kural": "matched palette bones take the rig node's own IBM "
                                                "(W_rig x IBM = I); unmatched palette bones are leaf "
                                                "nodes under SkeletonRoot with matrix = Cm.inv(IBM)",
                "ibm": "rig_turetilmis"},
        "parca_sayisi": n_parca, "cikan": cikan, "atlanan": atlanan,
        "toplam_NV": toplam_nv, "toplam_NT": toplam_nt, "kopya_eklem_toplam": kopya_toplam,
        "yinelenen_ucgen_toplam": yinelenen_toplam,
        "agirlik_kaybi_ozet": {"gltf_yuva": MY.GLTF_MAKS_ETKI, "kayipli_parca": kayipli_parca,
                               "maks_oran": round(kayip_maks, 6),
                               "aciklama": "fraction of skin weight dropped when a mesh has more than "
                                           "%d influences per vertex (per-part detail: parcalar[].agirlik_kaybi)"
                                           % MY.GLTF_MAKS_ETKI},
        "parcalar": manifest_parcalar, "materyaller": materyaller, "sure": sure,
        "sinirlar": SILAH_SINIRLARI if silah else SINIRLAR,
    }
    with open(os.path.join(klasor, MANIFEST_AD), "w", encoding="utf-8") as f:
        json.dump(_json_uygun(manifest), f, ensure_ascii=False, indent=1)
    _readme_yaz(os.path.join(klasor, README_AD), manifest)
    sonuc = {"ok": bool(cikan), "klasor": klasor, "glb": glb_yol, "parca_sayisi": n_parca, "cikan": cikan,
             "atlanan": atlanan, "rig": {"hiyerarsik": say["hiyerarsik"], "duz": say["duz"]}, "sure": sure,
             "glb_bayt": glb_bayt, "gevsek_png_bayt": png_bayt, "gevsek_png": png_sayisi,
             "gomulu_doku_bayt": MAT.gomulu_bayt, "gomulu_goruntu_sayisi": len(MAT.goruntu),
             "gevsek_kopya": bool(gevsek_kopya), "silinen_gevsek": silinen_gevsek,
             "manifest": os.path.join(klasor, MANIFEST_AD), "readme": os.path.join(klasor, README_AD),
             "toplam_NV": toplam_nv, "toplam_NT": toplam_nt, "materyal": len(MAT.mat),
             "kopya_eklem_toplam": kopya_toplam, "yinelenen_ucgen_toplam": yinelenen_toplam,
             "agirlik_kayipli_parca": kayipli_parca, "agirlik_kaybi_maks": round(kayip_maks, 6),
             "kategori": "weapon" if silah else "outfit",
             "rigid_parca": sum(1 for x in manifest_parcalar if x.get("rigid")),
             "armature": RD is not None}
    return sonuc


# ------------------------------------------------------------------ README (Ingilizce, plan §7)
SINIRLAR = [
    "No animation: only the bind pose and skin weights are exported (animation channels are unresolved).",
    "No cloth simulation: cloth parts come as static meshes; cloth bones are plain leaf bones.",
    "Rigid (skinless) parts that sit inside an outfit group - ship hulls and some props - are still skipped by the "
    "outfit export and listed under 'atlanan' in manifest.json. Weapons have their own EXPORT 3D button in the "
    "Weapons tab, and that path does read rigid meshes.",
    "NPC head/face rigs: head bones bind through their palette matrices only (no facial hierarchy).",
    "No morph targets / blend shapes.",
    "Import back is TEXTURES + MESH, not everything: IMPORT 3D reads repainted PNGs from textures\\ and "
    "an edited .glb, but skeleton, animation, cloth setup, material parameters and part list stay as the "
    "game has them.",
    "Only LOD0 (highest detail); no shadow or collision meshes.",
    "Roughness/metallic mapping is unverified: the gloss PNG (normal-map alpha) is written loose but not wired into the material.",
    "Hair, beard, brows and lashes have NO colour texture in the game files - only a normal map and masks. "
    "Their colour is a tint stored in the material itself, and this export reads it and writes it as the "
    "material's baseColorFactor (manifest.json > materyaller > 'ton'). What is unverified is the colour space: "
    "the game stores an 8-bit value and this export feeds it to glTF as a linear factor. If the hair looks too "
    "light or too dark for your taste, change the Base Color of that material in Blender - the RGB the game "
    "stores is printed in manifest.json under 'ton' > 'srgb8'.",
    "Unsupported mesh sub-variants and unusual skin strides are skipped with a reason in manifest.json.",
    "glTF stores at most 8 bone influences per vertex. A few game meshes carry 12 or 16; for those the "
    "8 strongest influences are kept and renormalised, and the dropped fraction is reported per part under "
    "'agirlik_kaybi' in manifest.json (summary under 'agirlik_kaybi_ozet').",
    "Small embedded-mip textures may be skipped (listed under 'atlanan' per material).",
    "Textures whose level-0 data fails the validity gate (random BC7 block modes / noise after decoding, e.g. the hidden blades) are skipped with the reason under 'atlanan'; that material stays untextured instead of getting a wrong image.",
    "Textures are read from the base game archive, not from patch files.",
    "UV orientation is consistent with the in-game preview but has not been confirmed on every material - check emblem direction in Blender.",
    "Normal-map green channel convention (DirectX Y-down vs glTF/OpenGL Y-up) was measured 2026-09-04: "
    "the game's G channel is DirectX-style and is now inverted (255-G) to match glTF/OpenGL, so bumps "
    "should read correctly in Blender out of the box.",
]
# Silah hattinin kendi sinir listesi (kur(..., silah=True) manifest'ine ve README'sine yazilir)
SILAH_SINIRLARI = [
    "No animation and no attachment point: the weapon comes in its own local space, exactly as the game "
    "stores it. It is NOT placed in a hand or on a hip - parent it yourself in Blender.",
    "Pistols, muskets, spears and the blunderbuss are RIGID meshes: they carry no skin, so the GLB has no "
    "armature at all (this is correct, not a missing rig).",
    "Swords, trinkets, hidden blades and holsters ARE skinned in the game files; for those the Edward "
    "skeleton is exported with the mesh, and unmatched palette bones become flat leaf bones.",
    "A weapon whose catalogue entry names several parts (dual swords, left/right pistols) exports every part "
    "into the same GLB, each in its own local space - they may sit on top of each other.",
    "'(holstered)' entries are the small copies the game shows in a belt holster, not a second weapon.",
    "LOD0 (highest detail) is used. If LOD0 is missing from the live archive or uses an unsupported mesh "
    "sub-variant, the next LOD is used instead and manifest.json records the fall-back under 'lod_geri_dusme'.",
    "Materials come from the mesh itself; if the mesh names a material the archive does not have, the "
    "material from the Workshop's own weapon catalogue is used and noted as 'yerine_gecen' in manifest.json.",
    "Roughness/metallic mapping is unverified: the gloss PNG (normal-map alpha) is written loose but not "
    "wired into the material.",
    "Textures are read from the base game archive, not from patch files.",
    "Import back is TEXTURES + MESH, not everything: IMPORT 3D reads repainted PNGs from textures\\ and "
    "an edited .glb, but skeleton, animation, cloth setup, material parameters and part list stay as the "
    "game has them.",
    "Normal-map green channel convention (DirectX Y-down vs glTF/OpenGL Y-up) was measured 2026-09-04: the "
    "game's G channel is DirectX-style and is now inverted (255-G) to match glTF/OpenGL.",
]
# normal haritasi G kanali: manifest'e yazilan durum (doku_png.NORMAL_G_TERS; 09-04 olcumu -- bkz. doku_png.py)
NORMAL_G_NOTU = ("measured 2026-09-04 (geometric-normal vs decoded-texel correlation over 9.27M triangle "
                 "corners across all 25 outfits, r flips sign and stays consistent across a random 50/50 "
                 "split): DirectX Y-down confirmed, G channel is inverted (255-G) to match glTF/OpenGL Y-up; "
                 "doku_png.NORMAL_G_TERS=%s")


def _readme_yaz(yol, m):
    atl = m.get("atlanan") or []
    _s = m.get("silah") or {}
    _silah = m.get("kategori") == "weapon"
    if _silah:
        _rig_satir = ("Rig      : rigid mesh, no armature (correct for this weapon)"
                      if not _s.get("armature") else
                      "Rig      : %d parts bound to the Edward skeleton hierarchy, %d parts with a flat bone palette"
                      % (m["rig"]["hiyerarsik"], m["rig"]["duz"]))
    else:
        _rig_satir = ("Rig      : %d parts bound to the Edward skeleton hierarchy, %d parts with a flat bone palette"
                      % (m["rig"]["hiyerarsik"], m["rig"]["duz"]))
    satirlar = [
        "OUTFIT WORKSHOP - 3D EXPORT (GLB)",
        "=" * 34,
        "",
        ("Weapon   : %s (%s)" if _silah else "Outfit   : %s (%s)")
        % (m.get("gorunen_ad") or m["anahtar"], m["anahtar"]),
    ]
    if _silah:
        satirlar.append("Type     : %s%s" % (_s.get("tur") or "Weapon",
                                             "" if _s.get("katalog") else "  (mesh family not listed in the weapon catalogue)"))
        satirlar.append("Meshes   : %d rigid, %d skinned" % (_s.get("rigid_parca") or 0, _s.get("skinli_parca") or 0))
    satirlar += [
        "File     : %s" % (m.get("glb") or "(no GLB - no part could be exported)"),
        "Parts    : %d exported, %d skipped (details in manifest.json)" % (m["cikan"], len(atl)),
        _rig_satir,
        "Textures : %d diffuse/normal images embedded in the GLB (%.1f MB); %d loose reference PNG files in textures\\ (%.1f MB)%s"
        % (m.get("gomulu_goruntu_sayisi", 0), m.get("gomulu_doku_bayt", 0) / 1e6,
           m.get("gevsek_png", 0), m.get("gevsek_png_bayt", 0) / 1e6,
           " - the embedded images are ALSO kept loose" if m.get("gevsek_kopya") else ""),
        "Export   : %.1f s, GLB %.1f MB" % (m.get("sure", 0), m.get("glb_bayt", 0) / 1e6),
    ]
    _ak = m.get("agirlik_kaybi_ozet") or {}
    if _ak.get("kayipli_parca"):
        satirlar.append(
            "Weights  : %d part(s) carry more than %d influences per vertex; the %d strongest are kept and "
            "renormalised (worst vertex loses %.2f%% of its weight - see 'agirlik_kaybi' in manifest.json)"
            % (_ak["kayipli_parca"], _ak.get("gltf_yuva", 8), _ak.get("gltf_yuva", 8),
               100.0 * float(_ak.get("maks_oran") or 0.0)))
    # sac/sakal tonu ozeti: hangi materyal hangi renge boyandi (README'de gorunur olsun)
    tonlu = [(mid, mm["ton"]) for mid, mm in sorted((m.get("materyaller") or {}).items())
             if (mm.get("ton") or {}).get("baseColorFactor")
             and not (mm.get("gomulu") or {}).get("diffuse")]
    if tonlu:
        satirlar.append(
            "Hair     : %d hair/beard material(s) have no colour texture; each is tinted from the colour "
            "stored in the material itself -> %s"
            % (len(tonlu), ", ".join("%s rgb(%d,%d,%d)" % (mid, *t["srgb8"][t["secilen"]][:3])
                                     for mid, t in tonlu[:6])
               + (" ..." if len(tonlu) > 6 else "")))
    satirlar += [
        "",
        "IMPORT IN BLENDER",
        "-----------------",
        "1. File > Import > glTF 2.0 (.glb/.gltf) and pick the .glb file.",
        "2. Every part arrives as a mesh with an Armature modifier; vertex groups carry the bone names.",
        "3. Textures are embedded: diffuse and normal maps are already wired into each material.",
        ("   The loose copies in textures\\ are the same images (plus gloss/emissive/mask references)."
         if m.get("gevsek_kopya") else
         "   textures\\ holds only the references that are not embedded (gloss / emissive / mask / extra maps)."),
        ("   To get the embedded diffuse/normal PNGs as files: Blender > File > External Data > Unpack Resources."
         if not m.get("gevsek_kopya") else "   (embedded images are also kept loose in textures\\)"),
        "   A material whose texture is listed under 'atlanan' in manifest.json stays untextured (grey) on purpose:",
        "   its level-0 data could not be decoded and is NOT sold as a texture.",
        "",
        "AXES AND UNITS",
        "--------------",
        "- Units are metres (Edward is about 1.8 m tall).",
        "- The file is Y-up as glTF requires; Blender converts it to Z-up on import automatically.",
        "- UVs are written unchanged (origin top-left, v down); the textures are NOT flipped.",
        "",
        "REPAINTING THE TEXTURES (textures\\ is the editing surface)",
        "----------------------------------------------------------",
        "Every PNG in textures\\ may be repainted and brought back into the game with IMPORT 3D.",
        "The file name is the address, so do NOT rename or move the files:",
        "",
        "    TEX_<id>_s<n>_<role>.png    the texture sits in the material itself",
        "    TEX_<id>_ts<n>_<role>.png   the texture sits in a shared TextureSet",
        "    <role> is diffuse / normal / gloss / emissive / mask - it says what the image means.",
        "",
        "RULES YOU MUST KEEP (IMPORT refuses the file otherwise, and says why):",
        "- Keep the pixel size exactly as exported. 2048x2048 must come back 2048x2048.",
        "  The archive reserves a fixed number of bytes per texture; a different size does not fit.",
        "- Keep the file a PNG with the same name. Save over the file, do not 'Save As' a new name.",
        "- A normal map and its _gloss partner are two halves of ONE game texture. Edit either one",
        "  and IMPORT rebuilds the pair; if you delete one of them the slot is refused.",
        "- Textures you do not touch are skipped: IMPORT compares each file against the checksum",
        "  recorded in manifest.json at export time, so an untouched slot is never rewritten.",
        "- A TextureSet (ts) image can be shared by several outfits or characters. Repainting it",
        "  changes all of them. IMPORT names the sharing before it writes anything.",
        "",
        "A repaint is written through the same single writer as the Workshop's APPLY button, and it",
        "lands in the same undo record - 'Revert all' puts every repainted texture back.",
        "",
        "WHAT THIS EXPORT DOES NOT DO (honest limits)",
        "-------------------------------------------",
    ]
    for s in m.get("sinirlar") or SINIRLAR:
        satirlar.append("- " + s)
    if atl:
        satirlar += ["", "SKIPPED PARTS", "-------------"]
        for a in atl:
            satirlar.append("- %s: %s" % (a["ad"], a["sebep"]))
    satirlar += ["", "manifest.json lists every part with its byte gate result, bone count, rig fit and materials.",
                 "Generated by %s on %s." % (m.get("uretici"), m.get("tarih")), ""]
    with open(yol, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(satirlar))
