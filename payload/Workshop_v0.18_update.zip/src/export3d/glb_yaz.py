# -*- coding: utf-8 -*-
"""GLB (glTF 2.0 ikili) yazicisi + geri okuyucu -- saf Python (stdlib + numpy).

Plan: tasarim/3D_DISA_AKTARMA_PLANI.md §5 Adim 4. Kaynak: kesif3d/glb_writer.py:34-175
(Blender 5.2 basssiz importta FINISHED olcuulmus yazici) + su eklemeler:
  * JOINTS_0/WEIGHTS_0 (ilk 4 etki) + JOINTS_1/WEIGHTS_1 (sonraki 4) -- 8 etki/vertex ZORUNLU
    (P0 olcumu: 8->4 indirgeme kayipli, maks 68/255).
  * joints bileseni u8 (en buyuk indeks < 256) / u16; indeks u16 (NV <= 65535) / u32.
  * TEXCOORD_1 (uv1), COLOR_0 (renk), alpha_mode; sampler REPEAT 10497 (Tunic prim1 iki U
    karosuna yayiliyor -- olculdu), doku CEVRILMEZ (AC4 = DirectX = glTF: v asagi).
  * PNG gomulu (bufferView); 4 bayt hizalama her yerde (bufferView, JSON chunk, BIN chunk).
  * Kok dugum yardimcisi: Z-up -> Y-up rotation quaternion (-0.7071068, 0, 0, 0.7071068).
  * glb_geri_oku(path): planin (b) kapisi -- dosyayi bagimsiz olarak geri okur ve olcer.

Kullanim:
    w = GlbWriter()
    img = w.add_image_png(png_bytes, "TEX_x_s0_diffuse")   -> image index
    tex = w.add_texture(img)                               -> texture index (sampler REPEAT)
    mat = w.add_material("MAT_x", tex, tex_normal)         -> material index
    prim = w.make_primitive(pos, nrm, uv0, indices, mat, joints8=j8, weights8=w8)
    mesh = w.add_mesh("Tunic_LOD0", [prim, ...])
    j = [w.add_node(ad, translation=..., rotation=...), ...]; w.cocuk_ekle(j[0], j[1])
    skin = w.add_skin(j, ibm_satir_major, skeleton=j[0])
    body = w.add_node("Tunic_LOD0", mesh=mesh, skin=skin)
    root = w.kok_zup_yup([body, j[0]])
    w.write(path, [root])
Oyun dosyasina dokunmaz; yalnizca verilen yola yazar.
"""
import hashlib
import io
import json
import struct
import zlib

import numpy as np

SURUM = "1.0"

# --- glTF sabitleri
FLOAT, UBYTE, USHORT, UINT = 5126, 5121, 5123, 5125
ARRAY_BUFFER, ELEMENT_ARRAY_BUFFER = 34962, 34963
TYPE_N = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
BILESEN_BOYUT = {UBYTE: 1, USHORT: 2, UINT: 4, FLOAT: 4}
BILESEN_DTYPE = {UBYTE: np.uint8, USHORT: np.uint16, UINT: np.uint32, FLOAT: np.float32}
SAMPLER_REPEAT = 10497
FILTER_LINEAR, FILTER_LINEAR_MIPMAP_LINEAR = 9729, 9987
CHUNK_JSON, CHUNK_BIN = 0x4E4F534A, 0x004E4942
ALPHA_MODLARI = ("OPAQUE", "MASK", "BLEND")
# Z-up (oyun/mesh uzayi) -> Y-up (glTF): X ekseni etrafinda -90 derece, (x, y, z, w)
KOK_ZUP_YUP_ROTATION = (-0.7071068, 0.0, 0.0, 0.7071068)
KOK_ZUP_YUP_AD = "Root_Zup_to_Yup"
URETICI = "OutfitWorkshop export3d glb_yaz %s" % SURUM
HIZA = 4


def png_rgba(w, h, rgba_bytes):
    """Kucuk RGBA8 PNG kodlayici (yalniz stdlib) -- testler ve dolgu dokular icin.
    Gercek dokular icin png_kodla (PIL) kullanilir."""
    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    raw = b"".join(b"\x00" + rgba_bytes[y * w * 4:(y + 1) * w * 4] for y in range(h))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def png_kodla(arr, compress_level=6):
    """numpy (H,W,3|4) u8 -> PNG baytlari (PIL). PIL yoksa RGBA icin png_rgba'ya duser."""
    arr = np.ascontiguousarray(arr, dtype=np.uint8)
    try:
        from PIL import Image
    except ImportError:                                   # paket python'da PIL var; guvence
        if arr.ndim == 3 and arr.shape[2] == 4:
            return png_rgba(arr.shape[1], arr.shape[0], arr.tobytes())
        raise
    mod = "RGBA" if (arr.ndim == 3 and arr.shape[2] == 4) else ("RGB" if arr.ndim == 3 else "L")
    buf = io.BytesIO()
    Image.fromarray(arr, mod).save(buf, "PNG", compress_level=compress_level)
    return buf.getvalue()


def png_boyut(png_bytes):
    """PNG IHDR'dan (genislik, yukseklik); PNG degilse None."""
    if len(png_bytes) < 24 or png_bytes[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return struct.unpack(">II", png_bytes[16:24])


def agirlik_tekillestir(joints8, weights8):
    """Ayni vertexte ayni eklem birden fazla yuvada (agirlik>0) gecerse agirliklari TEK yuvada toplar.
    Blender importeri kopya eklem girislerini toplamaz, REPLACE eder (olculdu: sentetik kopyali veride
    Σw sapmasi 0,22) -- sahne katmani oyun verisinde kopya gorurse bunu cagirir. Doner (j, w, kopya_sayisi)."""
    j = np.array(joints8, dtype=np.int64)
    w = np.array(weights8, dtype=np.float32)
    kopya = 0
    if j.ndim != 2:
        return j, w, 0
    for r in range(len(j)):
        gor = {}
        for s in range(j.shape[1]):
            if w[r, s] <= 0:
                continue
            k = int(j[r, s])
            if k in gor:
                w[r, gor[k]] += w[r, s]
                w[r, s] = 0.0
                j[r, s] = 0
                kopya += 1
            else:
                gor[k] = s
    return j, w, kopya


class GlbWriter:
    """Tek tamponlu GLB kurucusu. Tum bufferView'lar 4 bayta hizali, accessor byteOffset 0."""

    def __init__(self, uretici=URETICI):
        self.bin = bytearray()
        self.j = {"asset": {"version": "2.0", "generator": uretici},
                  "buffers": [], "bufferViews": [], "accessors": [], "meshes": [],
                  "materials": [], "textures": [], "images": [], "samplers": [],
                  "nodes": [], "skins": [], "scenes": [], "scene": 0}
        self.son_boyut = None

    # ---------------------------------------------------------------- tamponlar
    def _pad(self, n=HIZA):
        while len(self.bin) % n:
            self.bin.append(0)

    def add_buffer_view(self, data, target=None):
        self._pad()
        off = len(self.bin)
        self.bin += data
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(data)}
        if target is not None:
            bv["target"] = target
        self.j["bufferViews"].append(bv)
        return len(self.j["bufferViews"]) - 1

    def add_accessor(self, arr, ctype, atype, target=None, minmax=False, normalized=False):
        arr = np.ascontiguousarray(arr)
        n = TYPE_N[atype]
        count = arr.size // n
        bv = self.add_buffer_view(arr.tobytes(), target)
        acc = {"bufferView": bv, "byteOffset": 0, "componentType": ctype,
               "count": int(count), "type": atype}
        if normalized:
            acc["normalized"] = True
        if minmax:
            a2 = arr.reshape(count, n)
            acc["min"] = [float(x) for x in a2.min(axis=0)]
            acc["max"] = [float(x) for x in a2.max(axis=0)]
        self.j["accessors"].append(acc)
        return len(self.j["accessors"]) - 1

    # ---------------------------------------------------------------- doku / materyal
    def add_image_png(self, png_bytes, name=None):
        """PNG baytlarini BIN tampona gomer (bufferView + mimeType image/png)."""
        if png_boyut(png_bytes) is None:
            raise ValueError("add_image_png: PNG imzasi yok (%r)" % (name,))
        bv = self.add_buffer_view(bytes(png_bytes))
        im = {"bufferView": bv, "mimeType": "image/png"}
        if name:
            im["name"] = name
        self.j["images"].append(im)
        return len(self.j["images"]) - 1

    def _sampler_repeat(self):
        # tek sampler: LINEAR / LINEAR_MIPMAP_LINEAR, wrap S/T = REPEAT (10497)
        if not self.j["samplers"]:
            self.j["samplers"].append({"magFilter": FILTER_LINEAR, "minFilter": FILTER_LINEAR_MIPMAP_LINEAR,
                                       "wrapS": SAMPLER_REPEAT, "wrapT": SAMPLER_REPEAT})
        return 0

    def add_texture(self, image_idx, name=None):
        t = {"source": int(image_idx), "sampler": self._sampler_repeat()}
        if name:
            t["name"] = name
        self.j["textures"].append(t)
        return len(self.j["textures"]) - 1

    def add_material(self, name, base_tex=None, normal_tex=None, double_sided=True, alpha_mode="OPAQUE",
                     emissive_tex=None, alpha_cutoff=0.5, base_color=None):
        """metallicRoughness bagi BOS birakilir (gloss/roughness esleme 3. asama, plan §7/9).

        base_color: [r,g,b,a] 0..1 -> `baseColorFactor`. glTF'te bu LINEER bir carpandir ve
        varsa baseColorTexture ile CARPILIR. Sac/sakal materyallerinde doku beyaz + kesim
        alfali oldugu icin gorunen renk dogrudan budur (doku_png.materyal_tonu). Verilmezse
        alan hic yazilmaz -> glTF varsayilani [1,1,1,1] (beyaz), eski davranis."""
        if alpha_mode not in ALPHA_MODLARI:
            raise ValueError("alpha_mode %r not in %r" % (alpha_mode, ALPHA_MODLARI))
        m = {"name": name, "pbrMetallicRoughness": {"metallicFactor": 0.0, "roughnessFactor": 0.8},
             "doubleSided": bool(double_sided), "alphaMode": alpha_mode}
        if base_color is not None:
            bc = [float(x) for x in base_color]
            if len(bc) == 3:
                bc.append(1.0)
            if len(bc) != 4 or not all(0.0 <= x <= 1.0 for x in bc):
                raise ValueError("base_color %r must be 3 or 4 floats in 0..1" % (base_color,))
            m["pbrMetallicRoughness"]["baseColorFactor"] = bc
        if alpha_mode == "MASK":
            m["alphaCutoff"] = float(alpha_cutoff)
        if base_tex is not None:
            m["pbrMetallicRoughness"]["baseColorTexture"] = {"index": int(base_tex), "texCoord": 0}
        if normal_tex is not None:
            m["normalTexture"] = {"index": int(normal_tex), "texCoord": 0, "scale": 1.0}
        if emissive_tex is not None:
            m["emissiveTexture"] = {"index": int(emissive_tex), "texCoord": 0}
            m["emissiveFactor"] = [1.0, 1.0, 1.0]
        self.j["materials"].append(m)
        return len(self.j["materials"]) - 1

    # ---------------------------------------------------------------- geometri
    def make_primitive(self, pos, nrm, uv0, indices, material, uv1=None, renk=None,
                       joints8=None, weights8=None):
        """pos (n,3) f32 · nrm (n,3) f32|None · uv0 (n,2) f32|None (glTF: v ASAGI, sol-ust; cevirme yok)
        indices (m,) ya da (t,3) -> u16 (NV<=65535) / u32 · material index|None
        uv1 (n,2) -> TEXCOORD_1 · renk (n,3|4) u8 -> COLOR_0 normalized (f32 verilirse FLOAT)
        joints8/weights8 (n,k) k<=8: ilk 4 -> JOINTS_0/WEIGHTS_0, sonraki 4 -> JOINTS_1/WEIGHTS_1
        (k>4 ise iki set; k<=4 ise tek set). joints u8 (maks indeks<256) / u16; weights f32.
        Agirlik toplami cagiranin sorumlulugu (u8/255, Σ=1) -- glb_geri_oku olcer."""
        pos = np.ascontiguousarray(pos, dtype=np.float32).reshape(-1, 3)
        nv = len(pos)
        attrs = {"POSITION": self.add_accessor(pos, FLOAT, "VEC3", ARRAY_BUFFER, minmax=True)}
        if nrm is not None:
            nrm = np.ascontiguousarray(nrm, dtype=np.float32).reshape(-1, 3)
            self._n_kontrol("NORMAL", nrm, nv)
            attrs["NORMAL"] = self.add_accessor(nrm, FLOAT, "VEC3", ARRAY_BUFFER)
        if uv0 is not None:
            uv0 = np.ascontiguousarray(uv0, dtype=np.float32).reshape(-1, 2)
            self._n_kontrol("TEXCOORD_0", uv0, nv)
            attrs["TEXCOORD_0"] = self.add_accessor(uv0, FLOAT, "VEC2", ARRAY_BUFFER)
        if uv1 is not None:
            uv1 = np.ascontiguousarray(uv1, dtype=np.float32).reshape(-1, 2)
            self._n_kontrol("TEXCOORD_1", uv1, nv)
            attrs["TEXCOORD_1"] = self.add_accessor(uv1, FLOAT, "VEC2", ARRAY_BUFFER)
        if renk is not None:
            renk = np.asarray(renk)
            if renk.ndim != 2 or renk.shape[1] not in (3, 4):
                raise ValueError("COLOR_0 shape %r (expected (n,3) or (n,4))" % (renk.shape,))
            self._n_kontrol("COLOR_0", renk, nv)
            atype = "VEC3" if renk.shape[1] == 3 else "VEC4"
            if renk.dtype == np.uint8:
                attrs["COLOR_0"] = self.add_accessor(renk, UBYTE, atype, ARRAY_BUFFER, normalized=True)
            else:
                attrs["COLOR_0"] = self.add_accessor(renk.astype(np.float32), FLOAT, atype, ARRAY_BUFFER)
        if joints8 is not None:
            if weights8 is None:
                raise ValueError("joints8 given without weights8")
            jn = np.asarray(joints8)
            wn = np.asarray(weights8, dtype=np.float32)
            if jn.ndim != 2 or jn.shape[1] < 1 or jn.shape[1] > 8:
                raise ValueError("joints8 shape %r (expected (n,1..8))" % (jn.shape,))
            if wn.shape != jn.shape:
                raise ValueError("weights8 shape %r != joints8 shape %r" % (wn.shape, jn.shape))
            self._n_kontrol("JOINTS", jn, nv)
            if jn.size and jn.min() < 0:
                raise ValueError("negative joint index")
            k = jn.shape[1]
            set_sayisi = 2 if k > 4 else 1
            # sete sigmayan sutunlar sifirla doldurulur (joint 0, agirlik 0)
            jd = np.zeros((nv, 4 * set_sayisi), dtype=np.int64)
            wd = np.zeros((nv, 4 * set_sayisi), dtype=np.float32)
            jd[:, :k] = jn
            wd[:, :k] = wn
            jd[wd == 0] = 0                                 # agirliksiz yuva -> joint 0 (importer temizligi)
            jtip, jdtype = ((UBYTE, np.uint8) if (jd.size == 0 or jd.max() < 256) else (USHORT, np.uint16))
            for s in range(set_sayisi):
                sl = slice(4 * s, 4 * s + 4)
                attrs["JOINTS_%d" % s] = self.add_accessor(jd[:, sl].astype(jdtype), jtip, "VEC4", ARRAY_BUFFER)
                attrs["WEIGHTS_%d" % s] = self.add_accessor(np.ascontiguousarray(wd[:, sl]), FLOAT, "VEC4", ARRAY_BUFFER)
        elif weights8 is not None:
            raise ValueError("weights8 given without joints8")
        prim = {"attributes": attrs, "mode": 4}
        if indices is not None:
            idx = np.asarray(indices).ravel()
            if idx.size % 3:
                raise ValueError("index count %d not a multiple of 3" % idx.size)
            if idx.size and (idx.min() < 0 or idx.max() >= nv):
                raise ValueError("index out of range (NV=%d, max=%d)" % (nv, int(idx.max())))
            if nv <= 65535:
                prim["indices"] = self.add_accessor(idx.astype(np.uint16), USHORT, "SCALAR", ELEMENT_ARRAY_BUFFER)
            else:
                prim["indices"] = self.add_accessor(idx.astype(np.uint32), UINT, "SCALAR", ELEMENT_ARRAY_BUFFER)
        if material is not None:
            prim["material"] = int(material)
        return prim

    @staticmethod
    def _n_kontrol(ad, arr, nv):
        if len(arr) != nv:
            raise ValueError("%s count %d != POSITION count %d" % (ad, len(arr), nv))

    def add_mesh(self, name, primitives):
        self.j["meshes"].append({"name": name, "primitives": list(primitives)})
        return len(self.j["meshes"]) - 1

    # ---------------------------------------------------------------- dugum / skin
    def add_node(self, name, translation=None, rotation=None, scale=None, matrix=None,
                 children=None, mesh=None, skin=None):
        """matrix: (4,4) SATIR-major numpy -> glTF sutun-major 16 float. TRS ile matrix birlikte verilmez."""
        if matrix is not None and (translation is not None or rotation is not None or scale is not None):
            raise ValueError("node %r: matrix and TRS are mutually exclusive" % name)
        n = {"name": name}
        if translation is not None:
            n["translation"] = [float(x) for x in translation]
        if rotation is not None:
            n["rotation"] = [float(x) for x in rotation]
        if scale is not None:
            n["scale"] = [float(x) for x in scale]
        if matrix is not None:
            n["matrix"] = [float(x) for x in np.asarray(matrix, np.float32).T.ravel()]
        if children:
            n["children"] = [int(c) for c in children]
        if mesh is not None:
            n["mesh"] = int(mesh)
        if skin is not None:
            n["skin"] = int(skin)
        self.j["nodes"].append(n)
        return len(self.j["nodes"]) - 1

    def cocuk_ekle(self, ebeveyn, cocuk):
        """Var olan dugume cocuk baglar (rig agacini sonradan kurmak icin)."""
        self.j["nodes"][ebeveyn].setdefault("children", []).append(int(cocuk))

    def kok_zup_yup(self, children, name=KOK_ZUP_YUP_AD):
        """Sahne koku: Z-up mesh uzayini glTF Y-up'a ceviren rotation quaternion."""
        return self.add_node(name, rotation=KOK_ZUP_YUP_ROTATION, children=children)

    def add_skin(self, joint_nodes, inverse_bind_matrices, skeleton=None, name="skin"):
        """inverse_bind_matrices: (J,4,4) SATIR-major numpy -> sutun-major saklanir (glTF).
        Palet ham 16 float'i sutun-major'in kendisidir: IBM_rm = transpose(ham) verilirse
        dosyaya ham baytlar VERBATIM iner (kapi: IBM baytlari == palet 16 float)."""
        ibm = np.asarray(inverse_bind_matrices, np.float32)
        if ibm.shape != (len(joint_nodes), 4, 4):
            raise ValueError("IBM shape %r != (%d,4,4)" % (ibm.shape, len(joint_nodes)))
        col = np.ascontiguousarray(np.transpose(ibm, (0, 2, 1)))   # sutun-major, matris basina
        acc = self.add_accessor(col.reshape(-1, 16), FLOAT, "MAT4")
        s = {"name": name, "joints": [int(j) for j in joint_nodes], "inverseBindMatrices": acc}
        if skeleton is not None:
            s["skeleton"] = int(skeleton)
        self.j["skins"].append(s)
        return len(self.j["skins"]) - 1

    # ---------------------------------------------------------------- yazim
    def write(self, path, scene_nodes):
        """GLB'yi diske yazar; toplam bayt doner. JSON chunk bosluk (0x20), BIN chunk 0 ile 4'e hizalanir."""
        self._pad()
        self.j["buffers"] = [{"byteLength": len(self.bin)}]
        self.j["scenes"] = [{"nodes": [int(n) for n in scene_nodes]}]
        j = dict(self.j)
        for k in ("samplers", "skins", "textures", "images", "materials"):
            if not j[k]:
                del j[k]
        js = json.dumps(j, separators=(",", ":")).encode("utf-8")
        while len(js) % HIZA:
            js += b" "
        total = 12 + 8 + len(js) + 8 + len(self.bin)
        with open(path, "wb") as f:
            f.write(struct.pack("<4sII", b"glTF", 2, total))
            f.write(struct.pack("<II", len(js), CHUNK_JSON) + js)
            f.write(struct.pack("<II", len(self.bin), CHUNK_BIN) + bytes(self.bin))
        self.son_boyut = total
        return total


# ==================================================================== geri okuma (kapi b)
def _acc_oku(js, binb, idx, hata, etiket):
    """Accessor -> numpy (count, n). Hiza + sinir kontrolleri hata listesine yazilir."""
    a = js["accessors"][idx]
    n = TYPE_N[a["type"]]
    ct = a["componentType"]
    dt = BILESEN_DTYPE[ct]
    bs = BILESEN_BOYUT[ct]
    bv = js["bufferViews"][a["bufferView"]]
    ao = a.get("byteOffset", 0)
    off = bv.get("byteOffset", 0) + ao
    ln = a["count"] * n * bs
    if bv.get("byteOffset", 0) % HIZA:
        hata.append("%s: bufferView byteOffset %d not 4-aligned" % (etiket, bv.get("byteOffset", 0)))
    if off % bs:
        hata.append("%s: accessor offset %d not aligned to component size %d" % (etiket, off, bs))
    if "byteStride" in bv:
        hata.append("%s: interleaved bufferView (byteStride) not expected" % etiket)
    if ln > bv["byteLength"] - ao:
        hata.append("%s: accessor bytes %d exceed bufferView %d" % (etiket, ln, bv["byteLength"] - ao))
    if bv.get("byteOffset", 0) + bv["byteLength"] > len(binb):
        hata.append("%s: bufferView exceeds BIN chunk" % etiket)
    arr = np.frombuffer(binb, dtype=dt, count=a["count"] * n, offset=off).reshape(a["count"], n)
    return arr, a


def _png_ihdr(binb, js, im):
    bv = js["bufferViews"][im["bufferView"]]
    off = bv.get("byteOffset", 0)
    return png_boyut(bytes(binb[off:off + 24]))


def glb_geri_oku(path):
    """GLB'yi bagimsiz olarak geri okur; planin (b) kapisi.
    Doner: {ok, hatalar[], baslik, chunklar, sayim, meshler[{ad, primler[{NV,NT,material,...}]}],
            prim_materyal_sirasi, skinler[{ad, eklem_sayisi, ibm_ham (J,16) f32 verbatim, ibm_sha256}],
            goruntuler[{ad, mime, bayt, boyut}], sampler_repeat, sampler_sapan[(i,wrapS,wrapT)],
            kok_dugumler, kok_rotation, ...}
    Hicbir kontrol istisna atmaz; hepsi `hatalar`a yazilir, `ok = not hatalar`."""
    with open(path, "rb") as f:
        d = f.read()
    hata = []
    out = {"dosya": path, "boyut": len(d), "hatalar": hata, "ok": False}
    if len(d) < 20:
        hata.append("file too short (%d B)" % len(d))
        return out
    magic, ver, ln = struct.unpack_from("<4sII", d, 0)
    out["baslik"] = {"magic": magic.decode("latin-1"), "version": ver, "length": ln}
    if magic != b"glTF":
        hata.append("magic %r" % magic)
    if ver != 2:
        hata.append("version %d != 2" % ver)
    if ln != len(d):
        hata.append("header length %d != file size %d" % (ln, len(d)))
    if len(d) % HIZA:
        hata.append("file size %d not 4-aligned" % len(d))
    # --- chunklar
    chunks = []
    off = 12
    while off + 8 <= len(d):
        cl, ct = struct.unpack_from("<II", d, off)
        if cl % HIZA:
            hata.append("chunk 0x%08X length %d not 4-aligned" % (ct, cl))
        if off + 8 + cl > len(d):
            hata.append("chunk 0x%08X overruns file" % ct)
            break
        chunks.append({"tip": "JSON" if ct == CHUNK_JSON else ("BIN" if ct == CHUNK_BIN else "0x%08X" % ct),
                       "offset": off + 8, "uzunluk": cl})
        off += 8 + cl
    if off != len(d):
        hata.append("chunk sum %d != file size %d" % (off, len(d)))
    out["chunklar"] = chunks
    if not chunks or chunks[0]["tip"] != "JSON":
        hata.append("first chunk is not JSON")
        return out
    c0 = chunks[0]
    jsraw = d[c0["offset"]:c0["offset"] + c0["uzunluk"]]
    kuyruk = jsraw[jsraw.rfind(b"}") + 1:]                 # son '}' sonrasi yalniz 0x20 olmali
    if kuyruk.strip(b" "):
        hata.append("JSON chunk padding is not spaces")
    try:
        js = json.loads(jsraw.decode("utf-8"))
    except Exception as e:                                # noqa: BLE001 -- olcum, kapi dusurulur
        hata.append("JSON parse error: %s" % e)
        return out
    out["json_bayt"] = c0["uzunluk"]
    binb = b""
    if len(chunks) > 1:
        if chunks[1]["tip"] != "BIN":
            hata.append("second chunk is not BIN")
        c1 = chunks[1]
        binb = d[c1["offset"]:c1["offset"] + c1["uzunluk"]]
    out["bin_bayt"] = len(binb)
    if len(chunks) > 2:
        hata.append("unexpected extra chunks: %d" % (len(chunks) - 2))
    bl_json = js.get("buffers", [{}])[0].get("byteLength", -1) if js.get("buffers") else -1
    if not (0 <= len(binb) - bl_json < HIZA):
        hata.append("buffers[0].byteLength %d vs BIN chunk %d" % (bl_json, len(binb)))
    if js.get("asset", {}).get("version") != "2.0":
        hata.append("asset.version %r" % js.get("asset", {}).get("version"))
    out["uretici"] = js.get("asset", {}).get("generator")
    # --- sayim
    say = {k: len(js.get(k, [])) for k in ("accessors", "bufferViews", "meshes", "materials", "textures",
                                           "images", "samplers", "skins", "nodes", "scenes")}
    say["primitives"] = sum(len(m.get("primitives", [])) for m in js.get("meshes", []))
    out["sayim"] = say
    # --- bufferView hiza + sinir (hepsi)
    for i, bv in enumerate(js.get("bufferViews", [])):
        if bv.get("byteOffset", 0) % HIZA:
            hata.append("bufferView %d byteOffset %d not 4-aligned" % (i, bv.get("byteOffset", 0)))
        if bv.get("byteOffset", 0) + bv["byteLength"] > len(binb):
            hata.append("bufferView %d exceeds BIN" % i)
    # --- sampler
    # glTF 2.0: wrapS/wrapT OPSIYONEL, varsayilani 10497 REPEAT -> alanin YOKLUGU = REPEAT.
    # (Blender glTF ihracatcisi REPEAT iken iki alani da yazmaz; yalniz magFilter/minFilter
    #  kalir -- 2026-10-05 LOWER_DECK_PROPS_V2_SHARE kategorilerinde olculdu.)
    # Acikca REPEAT olmayan deger (33071 CLAMP_TO_EDGE / 33648 MIRRORED_REPEAT) yine kapiyi dusurur:
    # yazicinin REPEAT sozlesmesi yuk tasiyor (bkz. modul docstring, Tunic prim1 iki U karosu).
    samplers = js.get("samplers", [])
    sapan = [(i, s.get("wrapS", SAMPLER_REPEAT), s.get("wrapT", SAMPLER_REPEAT)) for i, s in enumerate(samplers)]
    sapan = [x for x in sapan if x[1] != SAMPLER_REPEAT or x[2] != SAMPLER_REPEAT]
    out["sampler_repeat"] = bool(samplers) and not sapan
    out["sampler_sapan"] = sapan
    if sapan:
        hata.append("sampler wrap is not REPEAT: %d/%d sampler, ilk %d (wrapS %s, wrapT %s)"
                    % (len(sapan), len(samplers), sapan[0][0], sapan[0][1], sapan[0][2]))
    for i, t in enumerate(js.get("textures", [])):
        if "sampler" not in t:
            hata.append("texture %d has no sampler" % i)
    # --- goruntuler
    gor = []
    for i, im in enumerate(js.get("images", [])):
        g = {"ad": im.get("name"), "mime": im.get("mimeType"), "bayt": None, "boyut": None}
        if "bufferView" in im:
            g["bayt"] = js["bufferViews"][im["bufferView"]]["byteLength"]
            g["boyut"] = _png_ihdr(binb, js, im)
            if g["boyut"] is None:
                hata.append("image %d: no PNG signature" % i)
        else:
            hata.append("image %d not embedded (uri)" % i)
        gor.append(g)
    out["goruntuler"] = gor
    # --- dugum -> mesh/skin haritasi
    mesh_skin = {}
    for nd in js.get("nodes", []):
        if "mesh" in nd:
            mesh_skin.setdefault(nd["mesh"], nd.get("skin"))
    # --- skinler
    skinler = []
    for si, sk in enumerate(js.get("skins", [])):
        e = {"ad": sk.get("name"), "eklem_sayisi": len(sk["joints"]), "skeleton": sk.get("skeleton"),
             "ibm_ham": None, "ibm_sha256": None, "ibm_satir": None}
        if "inverseBindMatrices" in sk:
            arr, a = _acc_oku(js, binb, sk["inverseBindMatrices"], hata, "skin %d IBM" % si)
            if a["type"] != "MAT4" or a["componentType"] != FLOAT:
                hata.append("skin %d IBM type %s/%d" % (si, a["type"], a["componentType"]))
            if a["count"] != len(sk["joints"]):
                hata.append("skin %d IBM count %d != joints %d" % (si, a["count"], len(sk["joints"])))
            ham = np.array(arr, dtype=np.float32)                       # (J,16) sutun-major verbatim
            e["ibm_ham"] = ham
            e["ibm_sha256"] = hashlib.sha256(ham.tobytes()).hexdigest()
            e["ibm_satir"] = np.transpose(ham.reshape(-1, 4, 4), (0, 2, 1))
        for jn in sk["joints"]:
            if not (0 <= jn < say["nodes"]):
                hata.append("skin %d joint node %d out of range" % (si, jn))
        skinler.append(e)
    out["skinler"] = skinler
    # --- meshler / primitifler
    meshler = []
    prim_mat = {}
    toplam_nv = toplam_nt = 0
    for mi, m in enumerate(js.get("meshes", [])):
        me = {"ad": m.get("name"), "primler": []}
        sira = []
        skin_idx = mesh_skin.get(mi)
        eklem = len(js["skins"][skin_idx]["joints"]) if skin_idx is not None else None
        for pi, p in enumerate(m.get("primitives", [])):
            et = "mesh %d prim %d" % (mi, pi)
            at = p["attributes"]
            pr = {"attr": sorted(at), "material": p.get("material"), "skin": skin_idx, "eklem_sayisi": eklem,
                  "mode": p.get("mode", 4)}
            pr["material_ad"] = (js["materials"][p["material"]].get("name")
                                 if p.get("material") is not None and p["material"] < say["materials"] else None)
            if p.get("material") is not None and p["material"] >= say["materials"]:
                hata.append("%s: material index out of range" % et)
            sira.append(p.get("material"))
            if "POSITION" not in at:
                hata.append("%s: no POSITION" % et)
                me["primler"].append(pr)
                continue
            pos, a = _acc_oku(js, binb, at["POSITION"], hata, et + " POSITION")
            nv = a["count"]
            pr["NV"] = nv
            toplam_nv += nv
            if a["type"] != "VEC3" or a["componentType"] != FLOAT:
                hata.append("%s: POSITION type" % et)
            if "min" not in a or "max" not in a:
                hata.append("%s: POSITION min/max missing" % et)
                pr["minmax_sapma"] = None
            else:
                mn, mx = pos.min(axis=0).astype(np.float64), pos.max(axis=0).astype(np.float64)
                sap = float(max(np.abs(mn - np.array(a["min"])).max(), np.abs(mx - np.array(a["max"])).max()))
                pr["minmax_sapma"] = sap
                pr["bbox_min"], pr["bbox_max"] = [float(x) for x in mn], [float(x) for x in mx]
                if sap > 1e-6:
                    hata.append("%s: POSITION min/max deviates %g" % (et, sap))
            # diger nitelikler: sayim POSITION ile ayni
            for ad in at:
                if ad == "POSITION":
                    continue
                arr, aa = _acc_oku(js, binb, at[ad], hata, et + " " + ad)
                if aa["count"] != nv:
                    hata.append("%s: %s count %d != NV %d" % (et, ad, aa["count"], nv))
                if ad == "NORMAL":
                    ln_ = np.linalg.norm(arr.astype(np.float64), axis=1)
                    pr["normal_uzunluk_sapma_maks"] = float(np.abs(ln_ - 1).max()) if nv else 0.0
            # indeksler
            if "indices" in p:
                idx, ia = _acc_oku(js, binb, p["indices"], hata, et + " indices")
                pr["NT"] = ia["count"] // 3
                toplam_nt += pr["NT"]
                pr["indeks_tip"] = {USHORT: "u16", UINT: "u32", UBYTE: "u8"}.get(ia["componentType"])
                if ia["count"] % 3:
                    hata.append("%s: index count %d not multiple of 3" % (et, ia["count"]))
                if nv <= 65535 and ia["componentType"] != USHORT:
                    hata.append("%s: NV %d <= 65535 but indices are not u16" % (et, nv))
                if nv > 65535 and ia["componentType"] != UINT:
                    hata.append("%s: NV %d > 65535 but indices are not u32" % (et, nv))
                pr["indeks_maks"] = int(idx.max()) if idx.size else -1
                if idx.size and idx.max() >= nv:
                    hata.append("%s: index max %d >= NV %d" % (et, int(idx.max()), nv))
            else:
                pr["NT"] = nv // 3
                pr["indeks_tip"] = None
            # skin nitelikleri
            setler = sorted(int(k[-1]) for k in at if k.startswith("JOINTS_"))
            pr["set_sayisi"] = len(setler)
            pr["uv1"] = "TEXCOORD_1" in at
            pr["color0"] = "COLOR_0" in at
            if setler:
                wsum = np.zeros(nv, np.float64)
                jmax = -1
                jtip = None
                for s in setler:
                    if "WEIGHTS_%d" % s not in at:
                        hata.append("%s: JOINTS_%d without WEIGHTS_%d" % (et, s, s))
                        continue
                    jarr, ja = _acc_oku(js, binb, at["JOINTS_%d" % s], hata, et + " JOINTS_%d" % s)
                    warr, wa = _acc_oku(js, binb, at["WEIGHTS_%d" % s], hata, et + " WEIGHTS_%d" % s)
                    if ja["type"] != "VEC4" or wa["type"] != "VEC4":
                        hata.append("%s: JOINTS/WEIGHTS_%d not VEC4" % (et, s))
                    if ja["componentType"] not in (UBYTE, USHORT):
                        hata.append("%s: JOINTS_%d component %d" % (et, s, ja["componentType"]))
                    t = {UBYTE: "u8", USHORT: "u16"}.get(ja["componentType"])
                    if jtip is not None and t != jtip:
                        hata.append("%s: JOINTS sets differ in component type" % et)
                    jtip = t
                    if jarr.size:
                        jmax = max(jmax, int(jarr.max()))
                    if wa["componentType"] == FLOAT:
                        wsum += warr.astype(np.float64).sum(axis=1)
                    else:
                        hata.append("%s: WEIGHTS_%d not float" % (et, s))
                    if warr.size and (warr.min() < 0 or warr.max() > 1 + 1e-6):
                        hata.append("%s: WEIGHTS_%d out of [0,1]" % (et, s))
                pr["joints_tip"] = jtip
                pr["joints_maks"] = jmax
                pr["agirlik_toplam_sapma_maks"] = float(np.abs(wsum - 1).max()) if nv else 0.0
                if pr["agirlik_toplam_sapma_maks"] > 1e-6:
                    hata.append("%s: weight sum deviates %g" % (et, pr["agirlik_toplam_sapma_maks"]))
                if eklem is None:
                    hata.append("%s: skinned primitive but node has no skin" % et)
                elif jmax >= eklem:
                    hata.append("%s: JOINTS max %d >= skin joints %d" % (et, jmax, eklem))
                if jtip == "u8" and jmax >= 256:
                    hata.append("%s: u8 joints with index %d" % (et, jmax))
            me["primler"].append(pr)
        prim_mat[me["ad"] if me["ad"] is not None else mi] = sira
        meshler.append(me)
    out["meshler"] = meshler
    out["prim_materyal_sirasi"] = prim_mat
    out["toplam_NV"], out["toplam_NT"] = toplam_nv, toplam_nt
    # --- sahne / kok
    sc = js.get("scenes", [])
    kok = sc[js.get("scene", 0)]["nodes"] if sc else []
    out["kok_dugumler"] = [js["nodes"][i].get("name") for i in kok]
    out["kok_rotation"] = [js["nodes"][i].get("rotation") for i in kok]
    out["kok_zup_yup"] = any(js["nodes"][i].get("name") == KOK_ZUP_YUP_AD
                             and tuple(round(x, 6) for x in js["nodes"][i].get("rotation", []))
                             == tuple(round(x, 6) for x in KOK_ZUP_YUP_ROTATION) for i in kok)
    # dugum indeksleri
    for i, nd in enumerate(js.get("nodes", [])):
        for c in nd.get("children", []):
            if not (0 <= c < say["nodes"]):
                hata.append("node %d child %d out of range" % (i, c))
        if "mesh" in nd and nd["mesh"] >= say["meshes"]:
            hata.append("node %d mesh out of range" % i)
        if "skin" in nd and nd["skin"] >= say["skins"]:
            hata.append("node %d skin out of range" % i)
    for i, m in enumerate(js.get("materials", [])):
        for anahtar in ("baseColorTexture", "normalTexture", "emissiveTexture"):
            t = m.get("pbrMetallicRoughness", {}).get(anahtar) if anahtar == "baseColorTexture" else m.get(anahtar)
            if t is not None and t["index"] >= say["textures"]:
                hata.append("material %d %s index out of range" % (i, anahtar))
        if m.get("alphaMode", "OPAQUE") not in ALPHA_MODLARI:
            hata.append("material %d alphaMode %r" % (i, m.get("alphaMode")))
        bcf = m.get("pbrMetallicRoughness", {}).get("baseColorFactor")
        if bcf is not None and (len(bcf) != 4 or not all(0.0 <= float(x) <= 1.0 for x in bcf)):
            hata.append("material %d baseColorFactor %r" % (i, bcf))
    out["materyaller"] = [{"ad": m.get("name"), "alphaMode": m.get("alphaMode", "OPAQUE"),
                           "doubleSided": m.get("doubleSided", False),
                           "base": m.get("pbrMetallicRoughness", {}).get("baseColorTexture", {}).get("index"),
                           "baseColorFactor": m.get("pbrMetallicRoughness", {}).get("baseColorFactor"),
                           "normal": (m.get("normalTexture") or {}).get("index")} for m in js.get("materials", [])]
    out["ok"] = not hata
    return out


def glb_goruntuler(path):
    """GLB'deki gomulu goruntuleri {ad: png_baytlari} olarak dondurur (test/kapi yardimcisi;
    sahne gevsek kopyalari sildigi icin gomulu PNG'ye buradan ulasilir). Dosya bir kez okunur."""
    with open(path, "rb") as f:
        d = f.read()
    off = 12
    js = None
    binb = b""
    while off + 8 <= len(d):
        cl, ct = struct.unpack_from("<II", d, off)
        body = d[off + 8: off + 8 + cl]
        if ct == CHUNK_JSON and js is None:
            js = json.loads(body.decode("utf-8"))
        elif ct == CHUNK_BIN and not binb:
            binb = body
        off += 8 + cl
    out = {}
    if not js:
        return out
    bvs = js.get("bufferViews", [])
    for i, im in enumerate(js.get("images", [])):
        if "bufferView" not in im:
            continue
        bv = bvs[im["bufferView"]]
        o = bv.get("byteOffset", 0)
        out[im.get("name") or "image_%d" % i] = bytes(binb[o: o + bv["byteLength"]])
    return out


def geri_oku_ozet(r):
    """glb_geri_oku sonucunu JSON'a yazilabilir hale getirir (numpy diziler dusurulur)."""
    o = {}
    for k, v in r.items():
        if k == "skinler":
            o[k] = [{kk: vv for kk, vv in s.items() if kk not in ("ibm_ham", "ibm_satir")} for s in v]
        elif isinstance(v, np.ndarray):
            o[k] = v.tolist()
        else:
            o[k] = v
    return o
