# -*- coding: utf-8 -*-
"""mesh_yapisal — Vanilla AC4 Resynced Mesh (0x415D9568) YAPISAL okuyucu, clustered
varyant (fmt 0/1, skinned CMD). Plan §5 Adim 2.

`kesif3d\\mesh_oku.py:28-191` birebir tasindi; iki fark: (1) assert'ler
`DesteklenmiyorHatasi(sebep)`e cevrildi, (2) TAG kuyruk bayti (`data[q2+4]==0` assert'i)
artik kapi degil, `R["prim_tag_listesi"]["kuyruk_bayt_dagilim"]`e sayilir — Hood_* mesh'lerinde
1 (13 benzersiz mesh, 7/7 bayt-birebir; 0 zorunlu olsaydi 25 kiyafetin hepsinde kapusonu dusururdu).
Sebep dizeleri plandaki 4 sinif:
  * "MPH variant"                                     gate_CMD != 0 (akis sayfali gemi govdesi)
  * "rigid fmt%d (position encoding unresolved)"      fmt not in {0,1}
  * "skin stride %d unsupported"                      stride/NbBonesPerVert bayt/kemik 2 ya da 3 degil
  * "unknown mesh sub-variant"                        nesne basligi / kapi / uzunluk tutmuyor
    (ayrinti `.ayrinti` alaninda; mesaj sabit kalir ki manifest sayimi tek anahtarla yapilsin)
Tum ofsetler capayla degil alan alan yuruyerek bulunur; her adimda nesne basligi dogrulanir.

`bayt_kapisi(R, G, data)`: 7 CMD tamponu COZULEN alanlardan yeniden kurulur ve ham
dilimle sha256 kiyaslanir -> "yorum dogru" iddiasi mesh basina KANITA doner. `hepsi=False`
olan parca GLB'ye GIRMEZ (fail-closed; karar cagiranindir).

2026-09-04 EKI — KUME-SIZ (cluster-free) VARYANT: CompiledMesh govdesindeki gate_CMD
bayti 3 ise ClusteredMeshData nesnesi YOKTUR ve geometri MeshData'nin kendi 5 tamponunda
yasar (bkz. GATE_YOK / MD_TAMPONLAR notlari). `oku` bu bicimi de cozer, `R["kumesiz"]`
True gelir ve `R["CMD"]` MeshData'dan SENTEZLENIR (ClusterCount 0, CPI bos, kutu = baslik
bbox'i). Ayni geometri sozlesmesi (G) doner, `bayt_kapisi` calisir. Yazici tarafi
`mesh_yaz.yaz_serbest`tir: SERBEST TOPOLOJI (vertex/ucgen sayisi degisebilir) ancak bu
bicimde mumkundur.
"""
import struct
import hashlib
import collections as _c
import numpy as np

__all__ = ["oku", "desteklenen_mi", "bayt_kapisi", "okt_coz", "okt_kodla", "skin_yerlesim",
           "DesteklenmiyorHatasi", "SEBEP_MPH", "SEBEP_RIGID", "SEBEP_STRIDE", "SEBEP_BILINMEYEN",
           "TAMPONLAR", "GLTF_MAKS_ETKI", "RIGID_FMT", "RIGID_STRIDE", "RIGID_KUME_INDEKS"]

# --- nesne sinif crc'leri (MeshPrimitive 0xA57387EF; 0xA576D7EF YANLIS)
H_MESH, H_CM, H_CMD, H_CPI, H_MD, H_PRIM, H_MID = (0x415D9568, 0xFC9E1595, 0xC351EE43,
                                                   0x07B19A87, 0x0645ABB5, 0xA57387EF, 0x0B1D34C1)
H_BONE, H_TAGLIST, H_TAG, H_CBA, H_8A4 = 0x9EF0E7A1, 0x285A56EA, 0x86BF209D, 0xCBA43E05, 0x8A44FE7A
u8 = lambda b, o: b[o]
u16 = lambda b, o: struct.unpack_from("<H", b, o)[0]
u32 = lambda b, o: struct.unpack_from("<I", b, o)[0]
i32 = lambda b, o: struct.unpack_from("<i", b, o)[0]
u64 = lambda b, o: struct.unpack_from("<Q", b, o)[0]
f32 = lambda b, o, n=1: struct.unpack_from("<%df" % n, b, o)

TAMPONLAR = ("VBstatic", "VBdynamic", "VBidxWeight", "VBprecompute", "IndexBuffer", "ClusterDesc", "ClusterBitMask")
# MeshData'nin KENDI tampon zinciri (kume-siz mesh'te geometri BURADA yasar; kumeli mesh'te
# 5 uzunlugun HEPSI 0'dir -- 330/330 olculdu).
MD_TAMPONLAR = TAMPONLAR[:5]
NESNE_MARK = (b"\xf8\xfb", b"\x00\x00")     # bkz. nesne_basi

# --- KUME-SIZ (cluster-free) varyant. 2026-09-04'te cozuldu.
# CompiledMesh govdesi: [4B alan][u8 gate_CMD]. gate_CMD == 0 -> ClusteredMeshData nesnesi
# GELIR (kumeli, vanilla kiyafet/silah). gate_CMD == 3 -> NULL: ClusteredMeshData YOKTUR;
# hemen ardindan gate_MPH ve MeshData nesnesi gelir, geometri MeshData'nin 5 tamponundadir:
#     nv*stride[0] (VBstatic) · nv*stride[1] (VBdynamic) · nv*stride[2] (VBidxWeight)
#     · nv*stride[3] (VBprecompute) · nt*6 (IndexBuffer, IsIdx32=0)
# KANIT: karakter derleyicisi (cw_derle.py) mesh_kur bu bicimi uretiyor ve ciktisi (karakter
# animasyon modu, v30_0081786E922F.bin) KAPTANIN OYUNUNDA KURULU VE CALISIYOR; 0xC351EE43 imzasi o dosyada
# SIFIR kez geciyor. Kumeli bicimde zorunlu olan CMD center/halfext, CPI kutulari,
# SurfaceArea ve SphereBV bu bicimde HIC YOKTUR -> tek turetilmis tablo baslik bbox'idir.
GATE_VAR, GATE_YOK = 0, 3

SEBEP_MPH = "MPH variant"
SEBEP_RIGID = "rigid fmt%d (skinless; pass rigid=True)"
SEBEP_STRIDE = "skin stride %d unsupported"
SEBEP_BILINMEYEN = "unknown mesh sub-variant"
DESTEKLI_FMT = (0, 1)

# --- RIGID (skinsiz) varyant. 2026-09-04'te 846 mesh uzerinde COZULDU.
# Ayri VBstatic/VBdynamic/VBidxWeight yerine TEK serpistirilmis akis (VBstatic) kullanilir;
# VBdynamic / VBidxWeight / VBprecompute tamponlari BOSTUR (846/846 olculdu).
# Alan haritasi (kolon-kolon entropi + kenar-duzgunlugu + kutu oracle'i ile turetildi):
#     bayt  0.. 1  s16 px          bayt  8..10  u8x3 normal   (v/127 - 1)
#     bayt  2.. 3  s16 py          bayt 11      u8   normal.w / bayrak (ham)
#     bayt  4.. 5  s16 pz          bayt 12..14  u8x3 tangent  (v/127 - 1)
#     bayt  6.. 7  s16 w           bayt 15      u8   tangent.w / el (ham)
#   fmt 3 (stride 20): bayt 16..19 = UV0 s16 x2 / 2048
#   fmt 4 (stride 28): bayt 16..19 = RGBA u8x4 | 20..23 = UV0 | 24..27 = UV1  (s16 x2 / 2048)
# KONUM: pos = (px, py, pz) * w / 32768.   w PER-VERTEX'tir; |w| mesh basina SABIT (846/846,
# tek buyukluk), isareti vertexten vertexe degisir ve konumu birebir ters cevirir.
#   Kanit: |w|/32768 olcegi, ham araligin tam +-32767'yi kapladigi her prim/eksende bbox'tan
#   turetilen olcege 1.0000 oraniyla oturuyor; isaret alinmazsa (yalniz +|w| ya da -|w|)
#   846 mesh'in ancak %1,3 / %26,2'si kutu kapisini geciyor, isaret alinirsa %100'u.
#   Bolen 32767 DEGIL 32768 (749/846 mesh'te daha kucuk hata).
# INDEKS: IndexBuffer KUME-DOLGULUdur -> uzunluk = ClusterCount * 192 indeks (846/846).
#   MeshPrimitive.firstIdx dolgusuz mantiksal akisa bakar; GERCEK konum CPI[j].IndexStart'tir.
#   Indeksler prim-YEREL (< prim.NV) ve taban CPI[j].VertexStart'tir -- MeshPrimitive.base
#   DEGIL (10 gemi decal mesh'inde ikisi ayrisiyor; base kullanildiginda prim kutusu 15 m
#   kaciyor, vstart ile 3e-4 m'ye oturuyor).
RIGID_FMT = (3, 4)
RIGID_STRIDE = {3: 20, 4: 28}
RIGID_KUME_INDEKS = 192               # kume basina SABIT indeks sayisi (dolgulu)
RIGID_UV_OFS = {20: 16, 28: 20}       # UV0'in stride icindeki ofseti
# VBidxWeight yerlesimi OLCULDU (2026-09-03, 25 kiyafet + 52 CHR_* grubu, 622 okunabilir parca):
# stride SABIT nb=stride/2 DEGIL. Belirleyici alan MeshData.NbBonesPerVert; bayt/kemik = stride/nb.
#   stride  8 / nb  4 = 2 B/kemik   98 parca   kemik sayisi   1..119
#   stride 12 / nb  4 = 3 B/kemik    1 parca   kemik sayisi 603
#   stride 16 / nb  8 = 2 B/kemik  492 parca   kemik sayisi   5..253
#   stride 24 / nb  8 = 3 B/kemik   30 parca   kemik sayisi 310..665
#   stride 32 / nb 16 = 2 B/kemik    1 parca   kemik sayisi  58
# 2 B/kemik -> [nb x u8 indeks][nb x u8 agirlik];  3 B/kemik -> [nb x u16 indeks][nb x u8 agirlik].
# Kanit: "nb = stride/2 + blok u8" varsayimi stride 24'te vertexlerin yalniz %30,65'inde agirlik
# toplami 255 verirken (maks 735 = ~3x255), u16 indeksli okuma 30/30 parcada 622/622 vertexte 255
# veriyor; ayrica 3 B/kemik olan 31 parcanin HEPSININ kemik sayisi > 255 (u8 indekse SIGMIYOR),
# 2 B/kemik olan 591 parcanin hepsininki <= 255 (maks 253). Serpistirilmis (idx,w) adaylari
# stride 24'te %0,15'e dusuyor -> blok yerlesimi. MeshData.stride[2] == CMD.idxWeight: 622/622.
BAYT_PER_KEMIK = (2, 3)
GLTF_MAKS_ETKI = 8            # glTF JOINTS_0+JOINTS_1 = 8 yuva (glb_yaz.make_primitive kapisi)


def skin_yerlesim(stride, nb_bones_per_vert):
    """VBidxWeight yerlesimi -> (nb, bayt_per_kemik) ya da None (desteklenmiyor).
    nb = MeshData.NbBonesPerVert; bayt/kemik = stride/nb (2 = u8 indeks, 3 = u16 indeks)."""
    nb = int(nb_bones_per_vert or 0)
    st = int(stride or 0)
    if nb <= 0 or st <= 0 or st % nb:
        return None
    bpb = st // nb
    if bpb not in BAYT_PER_KEMIK:
        return None
    return nb, bpb


class DesteklenmiyorHatasi(Exception):
    """Mesh bu okuyucunun kapsaminda degil. str() = plandaki sebep dizesi (manifest anahtari);
    `ayrinti` = insan icin ek bilgi (ofset / beklenen-bulunan)."""

    def __init__(self, sebep, ayrinti=None):
        Exception.__init__(self, sebep)
        self.sebep = sebep
        self.ayrinti = ayrinti

    def __str__(self):
        return self.sebep


def _gerek(kosul, ayrinti):
    """assert yerine: tutmazsa 'unknown mesh sub-variant' (ayrinti ile)."""
    if not kosul:
        raise DesteklenmiyorHatasi(SEBEP_BILINMEYEN, ayrinti)


def _agirlik_toplam_olc(agirlik):
    """u8 agirlik toplamlari (vertex basina) -> olcum sozlugu. Oyunda 255 olculdu; kapi DEGIL,
    kayittir (bozuk bir mesh'i sessizce dogru gostermemek icin manifest'e yazilir)."""
    if agirlik.size == 0:
        return dict(min=0, maks=0, tam_255_orani=1.0)
    t = agirlik.astype(np.int64).sum(1)
    return dict(min=int(t.min()), maks=int(t.max()), tam_255_orani=round(float((t == 255).mean()), 6))


def _agirlik_kaybi_olc(agirlik, tut):
    """glTF'e yalnizca en buyuk `tut` etki yazilabilir; DUSEN agirligin oranini olcer.
    kayip_v = (toplam - en buyuk `tut` toplami) / toplam. nb <= tut ise her sey sifirdir."""
    nb = int(agirlik.shape[1])
    if agirlik.size == 0 or nb <= tut:
        return dict(nb=nb, tutulan=min(nb, tut), dusen_yuva=max(nb - tut, 0),
                    maks=0.0, ortalama=0.0, etkilenen_vertex=0, vertex=int(agirlik.shape[0]))
    w = np.sort(agirlik.astype(np.float64), axis=1)[:, ::-1]      # buyukten kucuge
    top = w.sum(1)
    dusen = w[:, tut:].sum(1)
    oran = np.where(top > 0, dusen / np.maximum(top, 1e-12), 0.0)
    return dict(nb=nb, tutulan=tut, dusen_yuva=nb - tut,
                maks=round(float(oran.max()), 6), ortalama=round(float(oran.mean()), 6),
                etkilenen_vertex=int((dusen > 0).sum()), vertex=int(agirlik.shape[0]))


def nesne_basi(b, o, beklenen=None):
    """[u16 idx][u16 mark][u32 0][u32 hash] -> (idx, hash, govde_off)

    `mark` vanilla dosyalarda DAIMA F8 FB'dir (330/330 olculdu) ama KUME-SIZ mesh'lerde
    00 00'dir (CJ sablonu + karakter anim modu v30: 4/4 dosyada tum nesne basliklarinda 00 00).
    Bu yuzden mark bir KAPI degil, `NESNE_MARK` uyeligiyle sinirli bir alandir; yapisal
    kapi olarak b[o+4:o+8] == 0 korunur (mark'i tek basina serbest birakmak Mesh olmayan
    ic dosyalarda cop okumaya kapi acardi)."""
    idx = u16(b, o)
    _gerek(b[o + 2:o + 4] in NESNE_MARK and b[o + 4:o + 8] == b"\x00\x00\x00\x00",
           ("nesne basligi yok @%d: %s" % (o, b[o:o + 12].hex())))
    h = u32(b, o + 8)
    if beklenen is not None:
        _gerek(h == beklenen, ("beklenen 0x%08X, bulunan 0x%08X @%d" % (beklenen, h, o)))
    return idx, h, o + 12


def _sarmalayici(data):
    """Sarmalayici alanlari (oku ve desteklenen_mi ortak)."""
    _gerek(len(data) >= 12, "wrapper shorter than 12 B")
    tip, boyut, adLen = struct.unpack_from("<III", data, 0)
    _gerek(tip == H_MESH, "wrapper type 0x%08X is not Mesh" % tip)
    p = 12 + adLen
    _gerek(len(data) >= p + 13, "wrapper truncated")
    flag = data[p]; p += 1
    nid = u64(data, p); p += 8
    _gerek(u32(data, p) == H_MESH, "wrapper second type != Mesh"); p += 4
    _gerek(boyut == len(data) - 13 - adLen, "wrapper size %d != %d" % (boyut, len(data) - 13 - adLen))
    return tip, boyut, adLen, flag, nid, p


def oku(data, rigid=False, poz_olcek=None):
    """Mesh ic dosyasi (sarmalayici dahil) -> (R: yapisal sozluk, G: geometri/numpy).
    Kapsam disi mesh'te DesteklenmiyorHatasi; mesh_oku.oku:28-191 ile ayni alan sirasi.

    `rigid=False` (VARSAYILAN): fmt 3/4 (skinsiz) mesh'ler eskisi gibi DUSER. Kiyafet disa
    aktarma hatti skin bekliyor (sahne.kur JOINTS/WEIGHTS kuruyor); rigid parcayi sessizce
    o hatta sokmak yayindaki davranisi bozardi -- karar cagirana birakilir.
    `rigid=True`: fmt 3/4 cozulur; G["rigid"] True, G["kemik_idx"]/G["agirlik"] BOS (NV x 0),
    G["nokt"]/G["tokt"]/G["bayrak"] None ve normal/tangent G["normal"]/G["tangent"]te hazir gelir."""
    try:
        return _oku(data, rigid=rigid, poz_olcek=poz_olcek)
    except DesteklenmiyorHatasi:
        raise
    except (struct.error, IndexError, ValueError) as e:      # kisa / bozuk govde
        raise DesteklenmiyorHatasi(SEBEP_BILINMEYEN, "%s: %s" % (type(e).__name__, e))


def _kafa_standart(data, p, R):
    """Kemik tablosundan sonraki STANDART yol; CMD nesne govdesinin ofsetini doner."""
    # --- primitive tag listeleri: [u32 nPrim] then nPrim x ( TAGLIST obj [u32 n] + n x (TAG obj [u32 crc][u8 0]) )
    nprim_tag = u32(data, p); p += 4
    taglar = []; tag_bayrak = _c.Counter()
    for i in range(nprim_tag):
        idx, h, q = nesne_basi(data, p, H_TAGLIST)
        n = u32(data, q); q += 4
        lst = []
        for j in range(n):
            idx2, h2, q2 = nesne_basi(data, q, H_TAG)
            # TAG kuyruk bayti: mesh_oku 0 varsayiyordu; Hood_* mesh'lerinde (13 benzersiz, olculdu)
            # 6/6 tag'da 1 ve mesh geri kalaniyla 7/7 bayt-birebir okunuyor -> bayrak, kapi degil.
            lst.append("0x%08X" % u32(data, q2)); tag_bayrak[int(data[q2 + 4])] += 1
            q = q2 + 5
        taglar.append(lst); p = q
    R["prim_tag_listesi"] = dict(nPrim=nprim_tag, off_son=p, taglar=taglar,
                                 kuyruk_bayt_dagilim={int(k): int(v) for k, v in tag_bayrak.items()})
    # --- [8B 0][f32 0.2][u32 0][u8 03][bbox min f32x4][bbox max f32x4][u8 gate CompiledMesh]
    R["u32_a_b"] = [u32(data, p), u32(data, p + 4)]
    R["f32_02"] = f32(data, p + 8)[0]; _gerek(u32(data, p + 12) == 0, ("u32@+12 != 0", p + 12))
    R["u8_03"] = data[p + 16]
    bmin = f32(data, p + 17, 4); bmax = f32(data, p + 33, 4)
    R["baslik_bbox"] = dict(off=p + 17, min=[round(x, 5) for x in bmin], max=[round(x, 5) for x in bmax])
    p += 49
    gate_cm = data[p]; p += 1
    R["gate_CompiledMesh"] = gate_cm
    _gerek(gate_cm == 0, ("gate CompiledMesh", gate_cm))
    # --- CompiledMesh: [4B][gate CMD][CMD obj][gate MPH]
    idx, h, q = nesne_basi(data, p, H_CM)
    R["CompiledMesh"] = dict(off=p, alan4=data[q:q + 4].hex(), gate_CMD=data[q + 4])
    q += 5
    if R["CompiledMesh"]["gate_CMD"] == GATE_YOK:      # kume-siz: CMD nesnesi YOK
        return ("KUMESIZ", q)
    if R["CompiledMesh"]["gate_CMD"] != GATE_VAR:
        raise DesteklenmiyorHatasi(SEBEP_MPH, "gate_CMD=%d" % R["CompiledMesh"]["gate_CMD"])
    idx, h, q = nesne_basi(data, q, H_CMD)
    return ("CMD", q)


def _kafa_isaretci(data, bas, R, pencere=8192):
    """YEDEK yol (sac/sakal/kas/kirpik alt-varyanti): basliktaki etiket/bbox alanlari
    farkli yerlesimde. onizleme3d.mesh_coz gibi ClusteredMeshData isaretcisi taranir;
    guvenligi cozulen-kutu kapisi + 7 tampon bayt kapisi saglar."""
    son = min(len(data), bas + pencere)
    k = -1
    for _m in NESNE_MARK:
        k = data.find(_m + b"\x00\x00\x00\x00" + struct.pack("<I", H_CMD), bas, son)
        if k >= bas + 2:
            break
    if k >= bas + 2:
        obj = k - 2
        R["CompiledMesh"] = dict(off=None, gate_CMD=0, yedek_yol=True)
        R["prim_tag_listesi"] = dict(nPrim=None, taglar=[], yedek_yol=True)
        R["kafa_atlanan"] = dict(bayt=obj - bas, hex=data[bas:obj][:80].hex(" "))
        return ("CMD", obj + 12)
    # KUME-SIZ alt-varyant: ClusteredMeshData imzasi YOKTUR (bu bicimin tanimi budur) ->
    # MeshData imzasi aranir; gate_CMD/gate_MPH nesnenin hemen onundeki 2 bayttir.
    k2 = -1
    for _m in NESNE_MARK:
        k2 = data.find(_m + b"\x00\x00\x00\x00" + struct.pack("<I", H_MD), bas, son)
        if k2 >= bas + 4:
            break
    _gerek(k2 >= bas + 4,
           ("ne ClusteredMeshData ne MeshData isaretcisi %d..%d araliginda var" % (bas, son)))
    obj = k2 - 2
    _gerek(data[obj - 2] == GATE_YOK, ("kume-siz alt-varyant gate_CMD", data[obj - 2]))
    R["CompiledMesh"] = dict(off=None, gate_CMD=GATE_YOK, yedek_yol=True)
    R["prim_tag_listesi"] = dict(nPrim=None, taglar=[], yedek_yol=True)
    R["kafa_atlanan"] = dict(bayt=obj - 2 - bas, hex=data[bas:obj - 2][:80].hex(" "))
    return ("KUMESIZ", obj - 1)


def _oku_meshdata(data, q):
    """MeshData nesnesi (baslik + prim dizisi + 5 tampon) -> (md, prims, mdbuf, q_son).
    `q` = MeshData NESNE BASLIGININ ofseti. mdbuf = [(off, len)] x 5 (kumeli mesh'te hepsi 0).
    Yeniden yazici bu ofsetlere dayanir, bu yuzden hepsi md'ye KAYDEDILIR."""
    idx, h, q = nesne_basi(data, q, H_MD)
    md = dict(off=q - 12, govde_off=q, IsIdx32=data[q], fmt=data[q + 1], stride=list(data[q + 2:q + 6]),
              NbBonesPerVert=data[q + 6], b7=data[q + 7], b8=data[q + 8], b9=data[q + 9],
              u32_10=u32(data, q + 10))
    q += 14
    md["prim_sayi_off"] = q
    n = i32(data, q); q += 4
    _gerek(0 <= n <= 65535, ("MeshData prim sayisi", n))
    md["prim_dizi_off"] = q
    prims = []
    for i in range(n):
        idx, h, q2 = nesne_basi(data, q, H_PRIM)
        v = struct.unpack_from("<6I", data, q2)
        prims.append(dict(base=v[0], z1=v[1], NV=v[2], firstIdx=v[3], NT=v[4], tip=v[5]))
        q = q2 + 24
    md["prims"] = prims
    md["prim_kayit_B"] = 36                       # 12 B nesne basligi + 24 B govde
    md["tampon_bas"] = q
    mdbuf = []
    for k in range(5):
        l = i32(data, q)
        _gerek(0 <= l and q + 4 + l <= len(data), ("MeshData tampon %d uzunlugu" % k, l))
        mdbuf.append((q + 4, l)); q += 4 + l
    md["md_tampon_len"] = [l for _o, l in mdbuf]
    md["md_tampon"] = {nm: dict(off=o, len=l) for nm, (o, l) in zip(MD_TAMPONLAR, mdbuf)}
    md["kuyruk_off"] = q
    return md, prims, mdbuf, q


def _oku_kuyruk(data, q, md):
    """MeshData tamponlarindan SONRAKI kuyruk: MeshInstancingData listesi + opak alanlar.
    Kume-siz dosyalarda 0xCBA43E05 nesnesi YOKTUR (karakter anim modu v30'da imza sifir kez geciyor);
    o yuzden CBA cozumu ZORUNLU DEGIL -- tutmazsa md["CBA43E05"] None kalir ve 8A44FE7A
    kuyruk nesnesi imzayla bulunur."""
    nmid = i32(data, q); q += 4
    _gerek(0 <= nmid <= 65535, ("MeshInstancingData sayisi", nmid))
    md["MID_sayi_off"] = q - 4
    md["MID_dizi_off"] = q
    mids = []
    for i in range(nmid):
        idx, h, q2 = nesne_basi(data, q, H_MID)
        mids.append(dict(off=q2, b0=data[q2], prim=u16(data, q2 + 1), x=u16(data, q2 + 3),
                         NV=u16(data, q2 + 5), mask="0x%04X" % u16(data, q2 + 7), ref01=data[q2 + 9],
                         material="0x%012X" % u64(data, q2 + 10)))
        q = q2 + 30 - 12
    md["MeshInstancingData"] = mids
    md["MID_kayit_B"] = 30
    md["kuyruk25_hex"] = data[q:q + 25].hex(" ")
    q25 = q + 25
    md["CBA43E05"] = None
    try:
        idx, h, q2 = nesne_basi(data, q25, H_CBA)
        cba = dict(off=q25, bas13=data[q2:q2 + 13].hex(" "))
        q2 += 13
        nm_ = u32(data, q2); q2 += 4
        mats = []
        for i in range(nm_):
            _gerek(data[q2] == 1, ("materyal listesi bayragi", q2))
            mats.append("0x%012X" % u64(data, q2 + 1)); q2 += 9
        nf = u32(data, q2); q2 += 4
        cba["material_listesi"] = mats
        cba["f32_listesi"] = [round(x, 5) for x in f32(data, q2, nf)]; q2 += 4 * nf
        j = data.find(struct.pack("<I", H_8A4), q2) - 8
        _gerek(j >= q2, "0x8A44FE7A tail object not found")
        cba["kalan_hex"] = data[q2:j].hex(" "); cba["kalan_B"] = j - q2
        md["CBA43E05"] = cba
        q2 = j
    except DesteklenmiyorHatasi:
        q2 = data.find(struct.pack("<I", H_8A4), q25) - 8
        _gerek(q2 >= q25, "0x8A44FE7A tail object not found")
    idx, h, q3 = nesne_basi(data, q2, H_8A4)
    md["8A44FE7A"] = dict(off=q2, govde_hex=data[q3:].hex(" "), govde_B=len(data) - q3)
    return q2


def _kumesiz_cmd(md, prims, data, kutu):
    """Kume-siz MeshData'dan KUMELI okuyucunun bekledigi `cmd` sozlugunu sentezler.
    ClusterCount 0, CPI bos, SphereBV sifir; kutu = baslik bbox'i (tek turetilmis tablo).
    Tampon ofsetleri MeshData'nin KENDI tamponlarina bakar; ClusterDesc/ClusterBitMask
    bu bicimde YOKTUR -> uzunluk 0 (bayt kapisi bunlari bos-bos kiyaslar)."""
    st = list(md["stride"])
    bmin, bmax = kutu
    c = (bmin + bmax) * 0.5
    h = (bmax - bmin) * 0.5
    tampon = {}
    for nm in MD_TAMPONLAR:
        tampon[nm] = dict(md["md_tampon"][nm])
    son = md["kuyruk_off"]
    tampon["ClusterDesc"] = dict(off=son, len=0)
    tampon["ClusterBitMask"] = dict(off=son, len=0)
    return dict(off=None, kumesiz=True, DataVersion=None, fmt=md["fmt"],
                stride=dict(static=st[0], dynamic=st[1], idxWeight=st[2], precompute=st[3]),
                ClusterCount=0, center=[round(float(x), 5) for x in c],
                halfext=[round(float(x), 5) for x in h], fixed=None, DrawPrims=len(prims),
                CPI=[], SphereBV=[0.0, 0.0, 0.0, 0.0], UserCategory=0, tampon=tampon)


def _oku_kumesiz(data, R, q, matris, kemik_crc, kc, rigid=False):
    """gate_CMD == 3 yolu: ClusteredMeshData YOK, geometri MeshData tamponlarinda."""
    gate_mph = data[q]; q += 1
    R["gate_MPH"] = gate_mph
    _gerek(gate_mph == 3, ("gate MPH (kume-siz)", gate_mph))
    md, prims, mdbuf, q2 = _oku_meshdata(data, q)
    _oku_kuyruk(data, q2, md)
    R["MeshData"] = md
    R["dosya_B"] = len(data)
    _rigid = md["fmt"] in RIGID_FMT
    if md["fmt"] not in DESTEKLI_FMT and not (_rigid and rigid):
        raise DesteklenmiyorHatasi(SEBEP_RIGID % md["fmt"], "MeshData fmt (kume-siz)")
    R["rigid"] = bool(_rigid)
    _gerek(md["IsIdx32"] == 0, ("kume-siz IsIdx32", md["IsIdx32"]))
    # ISARETCI ALT-VARYANTI + KUME-SIZ: kutu ofseti MeshData nesnesinden 51 B geride durur
    # (kutu 32 B · gate_CompiledMesh 1 · CompiledMesh nesnesi 12 · alan4 4 · gate_CMD 1 ·
    #  gate_MPH 1 = 51). Kumeli standart yolda ayni zincir cmd_off - 50 verir (89/89 olculdu).
    if R.get("baslik_bbox") is None:
        _o = md["off"] - 51
        if _o >= 0 and data[_o + 32] == 0 and data[_o + 49] == GATE_YOK and data[_o + 50] == gate_mph:
            R["baslik_bbox"] = dict(off=_o, kaynak="kumesiz_md-51",
                                    min=[round(float(x), 5) for x in f32(data, _o, 4)],
                                    max=[round(float(x), 5) for x in f32(data, _o + 16, 4)])
    bb = R.get("baslik_bbox")
    _gerek(bb is not None and bb.get("off") is not None,
           ("kume-siz mesh'te baslik bbox'i cozulemedi", 0))
    kutu = (np.array(bb["min"][:3], np.float64), np.array(bb["max"][:3], np.float64))
    cmd = _kumesiz_cmd(md, prims, data, kutu)
    R["CMD"] = cmd
    buf = {nm: (cmd["tampon"][nm]["off"], cmd["tampon"][nm]["len"]) for nm in TAMPONLAR}
    st = [cmd["stride"]["static"], cmd["stride"]["dynamic"],
          cmd["stride"]["idxWeight"], cmd["stride"]["precompute"]]
    if _rigid:
        return _geo_rigid(data, R, cmd, buf, st, prims, matris, kemik_crc)
    if st[2] <= 0:
        raise DesteklenmiyorHatasi(SEBEP_STRIDE % st[2], "idxWeight stride (kume-siz)")
    return _geo_skinned(data, R, cmd, buf, st, prims, md, matris, kemik_crc, kc)


def _oku(data, rigid=False, poz_olcek=None):
    R = {}
    if poz_olcek:
        R["_poz_olcek_zorla"] = float(poz_olcek)
    # --- sarmalayici
    tip, boyut, adLen, flag, nid, p = _sarmalayici(data)
    R["sarmalayici"] = dict(tipCrc="0x%08X" % tip, boyut=boyut, adLen=adLen, flag=flag,
                            nesne_id="0x%012X" % nid, govde_off=p, ad_sifreli=data[12:12 + adLen].hex())
    g = p
    # --- govde basi: [u8 01][15B 0][u32 kc]  (olculdu: govde+0 = 01, govde+16 = kc)
    R["govde_bas_hex"] = data[g:g + 20].hex(" ")
    kc = u32(data, g + 16)
    p = g + 20
    # Kemik tablosu uzunlugu DOSYAYA SIGMALI. Bu kapi `desteklenen_mi`de vardi, `_oku`da yoktu:
    # Mesh olmayan / bozuk bir ic dosyada kc cop okunup np.zeros((kc,4,4)) 115 GiB istiyor ve
    # MemoryError sozlesmeyi (yalniz DesteklenmiyorHatasi) delip disari kaciyordu (olculdu).
    _gerek(0 <= kc and p + kc * 81 <= len(data), ("bone table runs past end of file", kc, len(data)))
    kemik_crc = []; son_bayt = []; matris = np.zeros((kc, 4, 4), np.float32)
    for i in range(kc):
        idx, h, q = nesne_basi(data, p, H_BONE)
        # Nesne basligindaki u16 idx vanilla'da SIRALIDIR (0,1,2,...) ama kume-siz dosyalarda
        # 759/759 kemikte 0'dir (CJ sablonu; oyunda calisiyor) -> sirali VEYA sifir kabul edilir.
        _gerek(idx == i or idx == 0, ("kemik idx", idx, i))
        kemik_crc.append(u32(data, q))
        matris[i] = np.array(f32(data, q + 4, 16), np.float32).reshape(4, 4)
        son_bayt.append(int(data[q + 68]))
        p = q + 69
    R["kemik"] = dict(sayi=kc, kayit_B=81, ilk_kayit_off=g + 20, son_off=p, crc32=["0x%08X" % c for c in kemik_crc],
                      son_bayt_dagilim={int(k): int(v) for k, v in _c.Counter(son_bayt).items()})
    # --- kemik tablosundan sonrasi: STANDART yol, tutmazsa ISARETCI yedegi (alt-varyant)
    _kafa_bas = p
    try:
        yol, q = _kafa_standart(data, p, R)
        R["alt_varyant"] = False
    except DesteklenmiyorHatasi as _e:
        if str(_e) != SEBEP_BILINMEYEN:
            raise                              # MPH / rigid / stride sebepleri yedege dusmez
        yol, q = _kafa_isaretci(data, _kafa_bas, R)
        R["alt_varyant"] = True
    R["kumesiz"] = (yol == "KUMESIZ")
    if R["kumesiz"]:
        return _oku_kumesiz(data, R, q, matris, kemik_crc, kc, rigid=rigid)
    cmd = dict(off=q - 12)
    cmd["DataVersion"] = i32(data, q); q += 4
    cmd["fmt"] = data[q]; q += 1
    _rigid = cmd["fmt"] in RIGID_FMT
    if cmd["fmt"] not in DESTEKLI_FMT and not (_rigid and rigid):
        raise DesteklenmiyorHatasi(SEBEP_RIGID % cmd["fmt"], "CMD fmt")
    R["rigid"] = bool(_rigid)
    st = struct.unpack_from("<4i", data, q); q += 16
    cmd["stride"] = dict(static=st[0], dynamic=st[1], idxWeight=st[2], precompute=st[3])
    # idxWeight kapisi burada DEGIL: yerlesim MeshData.NbBonesPerVert'e bagli (asagida, MeshData
    # cozuldukten sonra `skin_yerlesim`). Burada yalniz olanaksiz stride elenir.
    # Rigid'de skin yoktur -> idxWeight stride 0 BEKLENIR (846/846 olculdu).
    if not _rigid and st[2] <= 0:
        raise DesteklenmiyorHatasi(SEBEP_STRIDE % st[2], "idxWeight stride")
    cmd["ClusterCount"] = i32(data, q); q += 4
    cmd["center"] = [round(x, 5) for x in f32(data, q, 3)]; q += 12
    cmd["halfext"] = [round(x, 5) for x in f32(data, q, 3)]; q += 12
    cmd["fixed"] = data[q]; q += 1
    cmd["DrawPrims"] = i32(data, q); q += 4
    cpis = []
    for i in range(cmd["DrawPrims"]):
        idx, h, q2 = nesne_basi(data, q, H_CPI)
        cc, istart, vstart = struct.unpack_from("<3i", data, q2)
        fl = f32(data, q2 + 12, 7)
        cpis.append(dict(ClusterCount=cc, IndexStart=istart, VertexStart=vstart, SurfaceArea=round(fl[0], 5),
                         center=[round(x, 5) for x in fl[1:4]], halfext=[round(x, 5) for x in fl[4:7]]))
        q = q2 + 40
    cmd["CPI"] = cpis
    cmd["SphereBV"] = [round(x, 5) for x in f32(data, q, 4)]; q += 16
    cmd["UserCategory"] = i32(data, q); q += 4
    buf = {}
    for nm in TAMPONLAR:
        l = i32(data, q); buf[nm] = (q + 4, l); q += 4 + l
    cmd["tampon"] = {k: dict(off=v[0], len=v[1]) for k, v in buf.items()}
    _gerek(q + 1 <= len(data), "buffer chain runs past end of file")
    gate_mph = data[q]; q += 1
    R["gate_MPH"] = gate_mph; _gerek(gate_mph == 3, ("gate MPH", gate_mph))
    R["CMD"] = cmd
    # --- ISARETCI ALT-VARYANTINDA BASLIK BBOX'I: standart yolda ofset DAIMA cmd_off - 50'dir
    # (89/89 olculdu). Alt-varyantta yurutme etiket listelerinde koptugu icin ofset bilinmiyordu;
    # ayni sabit denenir ve IKI kapiyla dogrulanir: (1) o+32'deki gate_CompiledMesh bayti 0
    # (241/241), (2) oradaki kutu CMD center+-halfext ile ortusuyor (241/241, en cok 0,2
    # nicemleme adimi). Bu ofset cozulmeden kume-siz cevrim yapilamaz: yeni kutuyu yazacak
    # yer yoktur -> 241 mesh (korpusun %73'u) serbest duzenlemeye kapali kalirdi.
    if R.get("alt_varyant") and R.get("baslik_bbox") is None:
        _o = cmd["off"] - 50
        if _o >= 0 and _o + 33 <= len(data) and data[_o + 32] == 0:
            _mn = np.array(f32(data, _o, 4)[:3], np.float64)
            _mx = np.array(f32(data, _o + 16, 4)[:3], np.float64)
            _c3 = np.array(cmd["center"], np.float64); _h3 = np.array(cmd["halfext"], np.float64)
            _e = float(max(np.abs(_mn - (_c3 - _h3)).max(), np.abs(_mx - (_c3 + _h3)).max()))
            if _e <= 1e-4 * max(1.0, float(np.abs(_h3).max())):
                R["baslik_bbox"] = dict(off=_o, kaynak="alt_varyant_cmd-50",
                                        min=[round(float(x), 5) for x in _mn] + [0.0],
                                        max=[round(float(x), 5) for x in _mx] + [0.0],
                                        cmd_sapma=round(_e, 8))
    # --- MeshData
    md, prims, _mdbuf, q = _oku_meshdata(data, q)
    _oku_kuyruk(data, q, md)
    R["MeshData"] = md
    R["dosya_B"] = len(data)

    # --- geometri cozumu
    # Vertex sayisi = max(base+NV), sum(NV) DEGIL: Hat_U_Edward_Morgan_LOD0'da prim1 (base 2587,
    # NV 1357) prim0'in (base 0, NV 4092) araliginin ICINDE -> tamponlar 4092 vertexlik, sum 5449
    # olurdu. Ortusmeyen ardisik prim'lerde iki formul aynidir; bayt kapisi tampon uzunlugunu kanitlar.
    if _rigid:
        return _geo_rigid(data, R, cmd, buf, st, prims, matris, kemik_crc)
    return _geo_skinned(data, R, cmd, buf, st, prims, md, matris, kemik_crc, kc)


def _geo_skinned(data, R, cmd, buf, st, prims, md, matris, kemik_crc, kc):
    """SKINNED (fmt 0/1) geometri cozumu -> (R, G). Kumeli ve kume-siz bicim AYNI
    yerlesimi paylasir (5 tampon, prim-yerel u16 indeks); tek fark tamponlarin
    ClusteredMeshData'da mi MeshData'da mi durdugudur -> `buf` cagirandan gelir."""
    NV = max((pr["base"] + pr["NV"] for pr in prims), default=0)
    NT = sum(pr["NT"] for pr in prims)
    R["NV_prim_toplam"] = sum(pr["NV"] for pr in prims)
    R["prim_ortusme"] = R["NV_prim_toplam"] != NV
    sS, sD, sW, sP = st
    o, l = buf["VBstatic"]; _gerek(l == NV * sS, ("VBstatic len", l, NV, sS))
    _gerek(sS >= 8, ("VBstatic stride", sS))
    vb1 = np.frombuffer(data[o:o + l], np.uint8).reshape(NV, sS)
    o, l = buf["VBdynamic"]; _gerek(l == NV * sD and sD == 12, ("VBdynamic len/stride", l, NV, sD))
    vb2 = np.frombuffer(data[o:o + l], np.uint8).reshape(NV, 12)
    # --- VBidxWeight: yerlesim MeshData.NbBonesPerVert'ten (bkz. skin_yerlesim ustundeki olcum)
    _yer = skin_yerlesim(sW, md["NbBonesPerVert"])
    if _yer is None:
        raise DesteklenmiyorHatasi(SEBEP_STRIDE % sW,
                                   "idxWeight stride %d / NbBonesPerVert %d" % (sW, md["NbBonesPerVert"]))
    nb, bayt_per_kemik = _yer
    o, l = buf["VBidxWeight"]; _gerek(l == NV * sW, ("VBidxWeight len", l, NV, sW))
    vb3 = np.frombuffer(data[o:o + l], np.uint8).reshape(NV, sW)
    if bayt_per_kemik == 2:
        kemik_idx = vb3[:, 0:nb]                                  # u8 indeks (kemik sayisi <= 255)
    else:
        kemik_idx = vb3[:, 0:2 * nb].copy().view("<u2").reshape(NV, nb)   # u16 indeks (> 255 kemik)
    agirlik = vb3[:, sW - nb:sW]                                  # daima son nb bayt, u8, toplam 255
    _gerek(kemik_idx.size == 0 or int(kemik_idx.max()) < kc,
           ("kemik indeksi palet disi", int(kemik_idx.max()) if kemik_idx.size else -1, kc))
    R["kemik_per_vertex"] = nb
    R["bayt_per_kemik"] = bayt_per_kemik
    R["agirlik_toplam"] = _agirlik_toplam_olc(agirlik)
    R["agirlik_kaybi"] = _agirlik_kaybi_olc(agirlik, GLTF_MAKS_ETKI)
    o, l = buf["VBprecompute"]
    if sP and l == NV * sP:
        vbp = np.frombuffer(data[o:o + l], np.uint8).reshape(NV, sP)
    else:
        vbp = None
    R["VBprecompute_per_vertex"] = bool(sP and l == NV * sP)
    R["VBprecompute_ham"] = dict(len=l, stride=sP, NV=NV, len_div_NV=round(l / NV, 4) if NV else None, len_div_2=l // 2)
    vbp_ham = np.frombuffer(data[o:o + l], np.uint8)
    o, l = buf["IndexBuffer"]; _gerek(l == NT * 6, ("IndexBuffer len", l, NT))
    ib = np.frombuffer(data[o:o + l], np.uint16).reshape(NT, 3)
    ibg = ib.astype(np.int64).copy()
    prim_of_tri = np.zeros(NT, np.int32)
    for i, pr in enumerate(prims):
        t0 = pr["firstIdx"] // 3; t1 = t0 + pr["NT"]
        _gerek(pr["firstIdx"] % 3 == 0, ("firstIdx % 3", i))
        _gerek(t1 <= NT, ("prim triangle range", i))
        _gerek(pr["NT"] == 0 or ib[t0:t1].max() < pr["NV"], ("IB prim-yerel sinir asimi", i))
        ibg[t0:t1] += pr["base"]; prim_of_tri[t0:t1] = i
    pos = vb1_uv = None
    # KONUM OLCEGI MESH BASINA: ham i16/32768 * us; us baslik sinir kutusundan
    # turetilir (onizleme3d.mesh_coz ile ayni yontem). Sabit 1/16384 (us=2)
    # varsaymak Boots (us=1) ve Hat (us=3) gibi parcalari yanlis boyutta veriyordu.
    _ham = vb2[:, 0:6].copy().view("<i2").reshape(NV, 3).astype(np.float64)
    _p0 = _ham / 32768.0
    _kutu = R.get("baslik_bbox")
    if _kutu is None:                    # yedek yol: baslik alanlari okunmadi, CMD kutusu esdeger
        _c3 = np.array(cmd["center"], np.float64); _h3 = np.array(cmd["halfext"], np.float64)
        _bmin, _bmax = _c3 - _h3, _c3 + _h3
        R["baslik_bbox"] = dict(off=None, kaynak="CMD",
                                min=[round(float(x), 5) for x in _bmin],
                                max=[round(float(x), 5) for x in _bmax])
    else:
        _bmin = np.array(_kutu["min"][:3], np.float64)
        _bmax = np.array(_kutu["max"][:3], np.float64)
    _zorla = R.get("_poz_olcek_zorla")
    _e0 = _p0.max(0) - _p0.min(0)
    _eb = _bmax - _bmin
    if _zorla:
        _us = float(_zorla)
        R["poz_olcek_kaynak"] = "cagiran"
    else:
        with np.errstate(divide="ignore", invalid="ignore"):
            _oran = np.where(_e0 > 1e-9, _eb / np.maximum(_e0, 1e-12), np.nan)
        _gerek(bool(np.isfinite(_oran).any()), ("konum olcegi turetilemedi", 0))
        _us = float(np.median(_oran[np.isfinite(_oran)]))
        if abs(_us - round(_us)) < 0.01:
            _us = float(round(_us))
        R["poz_olcek_kaynak"] = "kutu_orani"
    _gerek(_us > 0, ("konum olcegi <= 0", _us))
    pos = _p0 * _us
    # KAPI: cozulen kutu basliktakine oturmali (bayt kapisi olcek hatasina kordur)
    _hata = float(max(np.abs(pos.min(0) - _bmin).max(), np.abs(pos.max(0) - _bmax).max()))
    if _hata > 2e-3 and R.get("kumesiz") and not _zorla:
        # KUME-SIZ dosyalarda baslik kutusu TAM olmayabilir: cw_derle uretilen mesh'in kutusunu
        # min-[0.30,0.05,0.30] / max+[0.30,0.70,0.30] PAYIYLA yaziyor (olculdu; CJ sablonu ve
        # karakter anim modu v30'da kutu payli). Oran yontemi bu dosyalarda olcegi kaciriyor -> geometrinin
        # kutunun ICINE sigdigi EN BUYUK tamsayi olcek secilir. Bu yontem 290/290 vanilla skinned
        # mesh'te oran yontemiyle ayni sonucu veriyor ve CJ sablonunda 2 buluyor -- kemik-mesafesi
        # kahini (vertex -> baskin kemigin bind konumu) de 2'yi seciyor (medyan 0,094 m; us=1'de
        # 0,58 m, us=3'te 0,57 m).
        _en = None
        for _c in range(1, 17):
            _pc = _p0 * _c
            if (_pc.min(0) >= _bmin - 2e-3).all() and (_pc.max(0) <= _bmax + 2e-3).all():
                _en = _c
        _gerek(_en is not None, ("kume-siz konum olcegi kutuya sigmadi", 0))
        _us = float(_en)
        pos = _p0 * _us
        R["poz_olcek_kaynak"] = "kutuya_sigan_en_buyuk"
        _hata = float(max(np.abs(pos.min(0) - _bmin).max(), np.abs(pos.max(0) - _bmax).max()))
    elif _zorla:
        R["poz_kutu_pay"] = round(_hata, 6)
    else:
        _gerek(_hata <= 2e-3,
               ("konum olcegi sinir kutusuna oturmuyor us=%.4f hata=%.5f" % (_us, _hata), 0))
    R["poz_olcek"] = _us
    R["poz_kutu_hatasi"] = round(_hata, 6)
    uv0 = vb1[:, 4:8].copy().view("<i2").reshape(NV, 2).astype(np.float64) / 2048.0
    uv1 = vb1[:, 8:12].copy().view("<i2").reshape(NV, 2).astype(np.float64) / 2048.0 if sS >= 16 else None
    # ClusterDesc / ClusterBitMask ham dilimleri de G'ye konur (bayt kapisi bunlari HAMDAN kiyaslar;
    # anlamlari cozulmedi, GLB'ye girmezler) -- mesh_oku'ya gore tek ek.
    oc, lc = buf["ClusterDesc"]; ob, lb = buf["ClusterBitMask"]
    G = dict(NV=NV, NT=NT, vb1=vb1, vb2=vb2, vb3=vb3, vbp=vbp, vbp_ham=vbp_ham, ib=ib, ibg=ibg, prim_of_tri=prim_of_tri,
             pos=pos, poz_olcek=R["poz_olcek"], uv0=uv0, uv1=uv1, renk=vb1[:, 0:4], son4=vb1[:, 12:16] if sS >= 16 else None,
             bayrak=vb2[:, 6], b7=vb2[:, 7], nokt=vb2[:, 8:10], tokt=vb2[:, 10:12],
             kemik_idx=kemik_idx, agirlik=agirlik, nb=nb, bayt_per_kemik=bayt_per_kemik,
             agirlik_kaybi=R["agirlik_kaybi"], matris=matris, kemik_crc=kemik_crc, prims=prims,
             cluster_desc_ham=data[oc:oc + lc], cluster_bitmask_ham=data[ob:ob + lb])
    return R, G


def _geo_rigid(data, R, cmd, buf, st, prims, matris, kemik_crc):
    """RIGID (fmt 3/4) geometri cozumu -> (R, G). Alan haritasi icin RIGID_* sabitlerinin
    ustundeki olcum notuna bak. Skin yoktur; kemik_idx/agirlik NV x 0 doner."""
    sS, sD, sW, sP = st
    _gerek(sS == RIGID_STRIDE.get(cmd["fmt"]), ("rigid static stride", cmd["fmt"], sS))
    for _nm in ("VBdynamic", "VBidxWeight", "VBprecompute"):
        _gerek(buf[_nm][1] == 0, ("rigid'de %s bos olmali" % _nm, buf[_nm][1]))
    o, l = buf["VBstatic"]
    _gerek(l > 0 and l % sS == 0, ("VBstatic len", l, sS))
    NV = l // sS
    vb1 = np.frombuffer(data[o:o + l], np.uint8).reshape(NV, sS)
    # --- IndexBuffer: KUMELI bicimde kume-dolgulu (uzunluk = ClusterCount * 192 indeks) ve
    #     konumlar CPI[j].IndexStart/VertexStart'tan okunur. KUME-SIZ bicimde kume yoktur:
    #     tampon tam olarak NT*6 B'dir, dilimler MeshPrimitive.firstIdx/base ile adreslenir
    #     (skinned bicimle ayni kural) -- CPI listesi bostur.
    kumesiz = bool(cmd.get("kumesiz"))
    o2, l2 = buf["IndexBuffer"]
    NT = sum(pr["NT"] for pr in prims)
    if kumesiz:
        _gerek(l2 == NT * 6, ("kume-siz rigid IndexBuffer len", l2, NT))
    else:
        _gerek(l2 == cmd["ClusterCount"] * RIGID_KUME_INDEKS * 2,
               ("rigid IndexBuffer len", l2, cmd["ClusterCount"]))
        _gerek(len(cmd["CPI"]) == len(prims), ("CPI/prim sayisi", len(cmd["CPI"]), len(prims)))
    ib_ham = np.frombuffer(data[o2:o2 + l2], np.uint16)
    ib = np.zeros((NT, 3), np.int64)          # prim-YEREL (dolgu atilmis)
    ibg = np.zeros((NT, 3), np.int64)         # global (vstart eklenmis)
    prim_of_tri = np.zeros(NT, np.int32)
    t0 = 0
    for i, pr in enumerate(prims):
        if kumesiz:
            i0, vstart = pr["firstIdx"], pr["base"]
            _gerek(pr["firstIdx"] % 3 == 0, ("firstIdx % 3", i))
        else:
            cpi = cmd["CPI"][i]
            i0, vstart = cpi["IndexStart"], cpi["VertexStart"]
        _gerek(i0 >= 0 and i0 + pr["NT"] * 3 <= len(ib_ham), ("IndexStart araligi", i, i0, pr["NT"]))
        seg = ib_ham[i0:i0 + pr["NT"] * 3].astype(np.int64).reshape(-1, 3)
        if seg.size:
            _gerek(int(seg.max()) < pr["NV"], ("rigid IB prim-yerel sinir asimi", i))
            _gerek(vstart + int(seg.max()) < NV, ("rigid IB vstart tasmasi", i))
        ib[t0:t0 + pr["NT"]] = seg
        ibg[t0:t0 + pr["NT"]] = seg + vstart
        prim_of_tri[t0:t0 + pr["NT"]] = i
        t0 += pr["NT"]
    R["NV_prim_toplam"] = sum(pr["NV"] for pr in prims)
    R["prim_ortusme"] = R["NV_prim_toplam"] != NV
    R["rigid_dolgu_indeks"] = int(len(ib_ham) - NT * 3)
    # --- KONUM: pos = (px,py,pz) * w / 32768   (w = bayt 6..7, PER-VERTEX s16)
    _q = vb1[:, 0:8].copy().view("<i2").reshape(NV, 4).astype(np.float64)
    _w = _q[:, 3]
    _wm = np.unique(np.abs(_w))
    _gerek(_wm.size >= 1 and _wm.max() > 0, ("rigid w olcegi sifir", 0))
    pos = _q[:, :3] * (_w[:, None] / 32768.0)
    R["poz_olcek"] = float(_wm.max()) / 32768.0            # nicemleme adimi (m)
    R["rigid_w_buyukluk"] = [int(x) for x in _wm[:8]]
    # KAPI: cozulen kutu CMD kutusuna (ve varsa baslik kutusuna) BIR nicemleme adimi icinde
    # oturmali. 846/846 mesh'te olculdu (%99,05'i yarim adim icinde).
    _c3 = np.array(cmd["center"], np.float64); _h3 = np.array(cmd["halfext"], np.float64)
    _bmin, _bmax = _c3 - _h3, _c3 + _h3
    _hata = float(max(np.abs(pos.min(0) - _bmin).max(), np.abs(pos.max(0) - _bmax).max()))
    _gerek(_hata <= R["poz_olcek"] * 2.0 + 1e-6,
           ("rigid konum kutusu tutmuyor hata=%.6f adim=%.6f" % (_hata, R["poz_olcek"]), 0))
    R["poz_kutu_hatasi"] = round(_hata, 6)
    R["poz_kutu_hatasi_adim"] = round(_hata / R["poz_olcek"], 4)
    if R.get("baslik_bbox") is None:
        R["baslik_bbox"] = dict(off=None, kaynak="CMD",
                                min=[round(float(x), 5) for x in _bmin],
                                max=[round(float(x), 5) for x in _bmax])
    # --- normal / tangent: u8x3, v/127 - 1 (|v| medyani 0,9996 olculdu; 8..10 geometrik
    #     normalle cos 0,949, 12..14 ona dik -> |cos| 0,052)
    nham = vb1[:, 8:11].astype(np.float64) / 127.0 - 1.0
    tham = vb1[:, 12:15].astype(np.float64) / 127.0 - 1.0
    normal = nham / np.maximum(np.linalg.norm(nham, axis=1, keepdims=True), 1e-12)
    tangent = tham / np.maximum(np.linalg.norm(tham, axis=1, keepdims=True), 1e-12)
    # --- UV / renk
    _uo = RIGID_UV_OFS[sS]
    uv0 = vb1[:, _uo:_uo + 4].copy().view("<i2").reshape(NV, 2).astype(np.float64) / 2048.0
    uv1 = vb1[:, 24:28].copy().view("<i2").reshape(NV, 2).astype(np.float64) / 2048.0 if sS == 28 else None
    renk = vb1[:, 16:20] if sS == 28 else None
    bos = np.zeros((NV, 0), np.uint8)
    R["kemik_per_vertex"] = 0
    R["bayt_per_kemik"] = 0
    R["agirlik_toplam"] = _agirlik_toplam_olc(bos)
    R["agirlik_kaybi"] = _agirlik_kaybi_olc(bos, GLTF_MAKS_ETKI)
    R["VBprecompute_per_vertex"] = False
    R["VBprecompute_ham"] = dict(len=0, stride=sP, NV=NV, len_div_NV=0.0, len_div_2=0)
    oc, lc = buf["ClusterDesc"]; ob, lb = buf["ClusterBitMask"]
    G = dict(NV=NV, NT=NT, rigid=True, vb1=vb1, vb2=None, vb3=None, vbp=None,
             vbp_ham=np.zeros(0, np.uint8), ib=ib, ib_ham=ib_ham, ibg=ibg, prim_of_tri=prim_of_tri,
             pos=pos, poz_olcek=R["poz_olcek"], poz_w=_w.astype(np.int64),
             uv0=uv0, uv1=uv1, renk=renk, son4=None,
             normal=normal, tangent=tangent, normal_ham=nham, tangent_ham=tham,
             bayrak=None, b7=None, nokt=None, tokt=None,
             nw=vb1[:, 11], tw=vb1[:, 15],
             kemik_idx=bos, agirlik=bos, nb=0, bayt_per_kemik=0,
             agirlik_kaybi=R["agirlik_kaybi"], matris=matris, kemik_crc=kemik_crc, prims=prims,
             cluster_desc_ham=data[oc:oc + lc], cluster_bitmask_ham=data[ob:ob + lb])
    return R, G


def _nbpv_hizli(data, q):
    """CMD govdesinde stride'lardan SONRAKI ofsetten MeshData.NbBonesPerVert'e yuru (tampon
    icerigi okunmaz, yalnizca uzunluklar atlanir). Yapi beklenmedikse None -> karar `oku`ya kalir."""
    try:
        q += 4 + 12 + 12 + 1                              # ClusterCount, center, halfext, fixed
        ndraw = i32(data, q); q += 4
        if not 0 <= ndraw <= 4096:
            return None
        q += ndraw * 52                                   # CPI = 12 B nesne basligi + 40 B govde
        q += 16 + 4                                       # SphereBV, UserCategory
        for _ in range(len(TAMPONLAR)):
            l = i32(data, q)
            if l < 0:
                return None
            q += 4 + l
        if not q + 1 + 12 + 7 <= len(data):
            return None
        q += 1                                            # gate MPH
        _i, _h, b = nesne_basi(data, q, H_MD)
        return data[b + 6]
    except (DesteklenmiyorHatasi, struct.error, IndexError, ValueError):
        return None


def desteklenen_mi(data, rigid=False):
    """(bool, sebep) — yalniz basligi yurur (tamponlar atlanir; hizli tarama).
    `rigid=True` ise fmt 3/4 de "destekli" sayilir (bkz. oku(rigid=...)).
    True ise sebep ''. False'ta sebep plandaki 4 diziden biri. `oku` yine de daha derin
    bir kapida (tampon uzunlugu, MeshData) dusebilir; o zaman sebep 'unknown mesh sub-variant'."""
    try:
        tip, boyut, adLen, flag, nid, g = _sarmalayici(data)
        kc = u32(data, g + 16)
        p = g + 20
        _gerek(p + kc * 81 <= len(data), "bone table runs past end of file")
        if kc:
            nesne_basi(data, p, H_BONE)                      # ilk kemik basligi dogrulanir
        p += kc * 81
        nprim = u32(data, p); p += 4
        for i in range(nprim):
            idx, h, q = nesne_basi(data, p, H_TAGLIST)
            nn = u32(data, q); q += 4
            p = q + nn * 17                                   # TAG obj = 12 baslik + 4 crc + 1
        _gerek(u32(data, p + 12) == 0, ("u32@+12 != 0", p + 12))
        p += 49
        gate_cm = data[p]; p += 1
        _gerek(gate_cm == 0, ("gate CompiledMesh", gate_cm))
        idx, h, q = nesne_basi(data, p, H_CM)
        if data[q + 4] == GATE_YOK:                       # kume-siz: CMD yok, MeshData'ya bak
            idx, h, b = nesne_basi(data, q + 6, H_MD)
            fmt = data[b + 1]
            st = list(data[b + 2:b + 6])
            if fmt in RIGID_FMT:
                return (True, "") if rigid else (False, SEBEP_RIGID % fmt)
            if fmt not in DESTEKLI_FMT:
                return False, SEBEP_RIGID % fmt
            if st[2] <= 0 or skin_yerlesim(st[2], data[b + 6]) is None:
                return False, SEBEP_STRIDE % st[2]
            return True, ""
        if data[q + 4] != 0:
            return False, SEBEP_MPH
        idx, h, q = nesne_basi(data, q + 5, H_CMD)
        fmt = data[q + 4]
        st = struct.unpack_from("<4i", data, q + 5)
        if fmt in RIGID_FMT and rigid:
            if st[0] != RIGID_STRIDE[fmt]:
                return False, SEBEP_BILINMEYEN
            return True, ""
        if fmt not in DESTEKLI_FMT:
            return False, SEBEP_RIGID % fmt
        if st[2] <= 0:
            return False, SEBEP_STRIDE % st[2]
        nbpv = _nbpv_hizli(data, q + 21)
        if nbpv is not None and skin_yerlesim(st[2], nbpv) is None:
            return False, SEBEP_STRIDE % st[2]
        # nbpv okunamadiysa karar `oku`ya birakilir (bu tarayici derin kapilari denemez)
        return True, ""
    except DesteklenmiyorHatasi as e:
        return False, e.sebep
    except (struct.error, IndexError, ValueError):
        return False, SEBEP_BILINMEYEN


def okt_coz(B, z_neg):
    """45 derece donmus oktahedral + ayri z isaret biti (cw_derle.okt_coz ile ayni)."""
    q0 = B[:, 0].astype(np.float64) / 127.5 - 1.0
    q1 = B[:, 1].astype(np.float64) / 127.5 - 1.0
    px = (q0 + q1) / 2.0; py = (q0 - q1) / 2.0
    z = (1.0 - np.abs(px) - np.abs(py)) * np.where(z_neg, -1.0, 1.0)
    V = np.stack([px, py, z], 1)
    return V / np.maximum(np.linalg.norm(V, axis=1, keepdims=True), 1e-12)


def okt_kodla(V):
    """cw_derle.okt_kodla (|z| yarikuresi, z isareti ayri)."""
    uz = np.linalg.norm(V, axis=1, keepdims=True)
    V = V / np.maximum(uz, 1e-12)
    x, y, z = V[:, 0], V[:, 1], V[:, 2]
    s = np.maximum(np.abs(x) + np.abs(y) + np.abs(z), 1e-12)
    px, py = x / s, y / s
    b0 = np.clip(np.round((px + py) * 127.5 + 127.5), 0, 255).astype(np.uint8)
    b1 = np.clip(np.round((px - py) * 127.5 + 127.5), 0, 255).astype(np.uint8)
    return np.stack([b0, b1], 1), z < 0


def _s16(x, olcek):
    """float alan -> round(x*olcek) little-endian s16 bayt sutunlari (NV, 2*k)."""
    v = np.round(np.asarray(x, np.float64) * olcek)
    if v.size and (v.min() < -32768 or v.max() > 32767):
        return None
    return np.ascontiguousarray(v.astype("<i2")).view(np.uint8).reshape(v.shape[0], -1)


def _sha(b):
    return hashlib.sha256(bytes(b)).hexdigest()


def _bayt_kapisi_rigid(R, G, ham, kiyas, NV, NT, sS):
    """RIGID (fmt 3/4) bayt kapisi. Yeniden kurulan alanlar (yorumun KANITI):
      VBstatic  = round(pos*32768/w) s16 x3 | w s16 | round((normal_ham+1)*127) u8x3 | nw(ham)
                  | round((tangent_ham+1)*127) u8x3 | tw(ham)
                  | [renk(ham) fmt4] | round(uv0*2048) s16 x2 | [round(uv1*2048) s16 x2 fmt4]
                  -- normal/tangent NORMALLENMEMIS ham cozumden geri kodlanir (olcek 1/127,
                     kayma -1 boylece BIREBIR sinanir); birim vektor G["normal"]dedir.
      IndexBuffer = kume-dolgulu tampon; her prim'in NT*3'luk gercek dilimi (ibg - vstart)
                  yeniden yazilir, DOLGU baytlari hamdan kopyalanir (dolgunun anlami
                  cozulmedi -> durustce passthrough; kapi ucgen yorumunu sinar).
      VBdynamic / VBidxWeight / VBprecompute = rigid'de 0 uzunluk (bos ile bos kiyaslanir).
      ClusterDesc / ClusterBitMask = ham kopya (anlami cozulmedi)."""
    out = {}
    w = np.asarray(G["poz_w"], np.float64).reshape(NV, 1)
    guv = np.divide(np.asarray(G["pos"], np.float64) * 32768.0, w,
                    out=np.zeros((NV, 3)), where=w != 0)
    posb = _s16(guv, 1.0)
    wb = _s16(w.reshape(NV, 1), 1.0)
    nb_ = np.clip(np.round((np.asarray(G["normal_ham"]) + 1.0) * 127.0), 0, 255).astype(np.uint8)
    tb_ = np.clip(np.round((np.asarray(G["tangent_ham"]) + 1.0) * 127.0), 0, 255).astype(np.uint8)
    uvb = _s16(G["uv0"], 2048.0)
    par = [posb, wb, nb_, np.asarray(G["nw"]).reshape(NV, 1), tb_, np.asarray(G["tw"]).reshape(NV, 1)]
    if sS == 28:
        par.append(np.ascontiguousarray(G["renk"]))
    par.append(uvb)
    if sS == 28:
        par.append(_s16(G["uv1"], 2048.0))
    if any(p is None for p in par):
        out["VBstatic"] = False
    else:
        vb1r = np.concatenate(par, 1)
        out["VBstatic"] = vb1r.shape[1] == sS and kiyas("VBstatic", vb1r.tobytes())
    # --- IndexBuffer: dolgulu tamponu ham kopyadan baslat, gercek dilimleri yeniden yaz
    ibr = np.array(G["ib_ham"], dtype="<u2", copy=True)
    ib_ok = True
    t0 = 0
    for i, pr in enumerate(G["prims"]):
        # KUME-SIZ bicimde CPI yoktur: taban MeshPrimitive.base, konum firstIdx (bkz. _geo_rigid)
        if R["CMD"].get("kumesiz"):
            vstart, i0 = pr["base"], pr["firstIdx"]
        else:
            cpi = R["CMD"]["CPI"][i]
            vstart, i0 = cpi["VertexStart"], cpi["IndexStart"]
        yerel = G["ibg"][t0:t0 + pr["NT"]] - vstart
        t0 += pr["NT"]
        if yerel.size and (yerel.min() < 0 or yerel.max() > 65535):
            ib_ok = False
            break
        ibr[i0:i0 + pr["NT"] * 3] = yerel.reshape(-1).astype("<u2")
    out["IndexBuffer"] = ib_ok and kiyas("IndexBuffer", ibr.tobytes())
    out["VBdynamic"] = kiyas("VBdynamic", b"")
    out["VBidxWeight"] = kiyas("VBidxWeight", b"")
    out["VBprecompute"] = kiyas("VBprecompute", b"")
    out["ClusterDesc"] = kiyas("ClusterDesc", G["cluster_desc_ham"])
    out["ClusterBitMask"] = kiyas("ClusterBitMask", G["cluster_bitmask_ham"])
    out["hepsi"] = all(out[nm] for nm in TAMPONLAR)
    return out


def bayt_kapisi(R, G, data):
    """7 CMD tamponunu COZULEN alanlardan yeniden kur, ham dilimle sha256 kiyasla.
    -> {"VBstatic":bool, ..., "ClusterBitMask":bool, "hepsi":bool}
      VBstatic     = renk(ham) | round(uv0*2048) s16 x2 | [round(uv1*2048) s16 x2 | son4(ham)]
      VBdynamic    = round(pos/us*32768) s16 x3 (us mesh basina) | bayrak(ham) | b7(ham) | okt_kodla(N)[0] | okt_kodla(T)[0]
                     (z-isaret biti yeniden URETILMEZ, hamdan gelir: z~0 vertexlerde belirsiz, %99,76 olculdu)
      VBidxWeight  = kemik_idx | agirlik
      IndexBuffer  = prim basina (ibg - base) u16 (prim-yerel)
      VBprecompute / ClusterDesc / ClusterBitMask = G'deki ham kopya (anlam cozulmedi; GLB'ye girmez)"""
    T = R["CMD"]["tampon"]
    NV, NT = G["NV"], G["NT"]
    sS = R["CMD"]["stride"]["static"]

    def ham(nm):
        o, l = T[nm]["off"], T[nm]["len"]
        return data[o:o + l]

    def kiyas(nm, kurulan):
        if kurulan is None:
            return False
        h = ham(nm)
        return len(kurulan) == len(h) and _sha(kurulan) == _sha(h)

    out = {}
    if G.get("rigid"):
        return _bayt_kapisi_rigid(R, G, ham, kiyas, NV, NT, sS)
    # --- VBstatic
    par = [np.ascontiguousarray(G["renk"]), _s16(G["uv0"], 2048.0)]
    if G["uv1"] is not None:
        par += [_s16(G["uv1"], 2048.0), np.ascontiguousarray(G["son4"])]
    if any(p is None for p in par):
        out["VBstatic"] = False
    else:
        vb1r = np.concatenate(par, 1)
        out["VBstatic"] = vb1r.shape[1] == sS and kiyas("VBstatic", vb1r.tobytes())
    # --- VBdynamic
    posb = _s16(G["pos"], 32768.0 / G["poz_olcek"])      # mesh basina olcek
    if posb is None:
        out["VBdynamic"] = False
    else:
        bay = G["bayrak"]
        N = okt_coz(G["nokt"], (bay & 1).astype(bool))
        Tn = okt_coz(G["tokt"], ((bay >> 1) & 1).astype(bool))
        vb2r = np.concatenate([posb, bay.reshape(NV, 1), G["b7"].reshape(NV, 1),
                               okt_kodla(N)[0], okt_kodla(Tn)[0]], 1)
        out["VBdynamic"] = kiyas("VBdynamic", vb2r.tobytes())
    # --- VBidxWeight: ham u8 bloklar; 2 B/kemik -> [u8 idx][u8 w], 3 B/kemik -> [u16 idx LE][u8 w]
    bpk = int(G.get("bayt_per_kemik", 2))
    if bpk == 2:
        idxb = np.asarray(G["kemik_idx"]).astype(np.uint8)
    else:
        idxb = np.ascontiguousarray(np.asarray(G["kemik_idx"]).astype("<u2")).view(np.uint8).reshape(NV, -1)
    vb3r = np.concatenate([idxb, np.asarray(G["agirlik"]).astype(np.uint8)], 1)
    out["VBidxWeight"] = (vb3r.shape[1] == R["CMD"]["stride"]["idxWeight"]
                          and kiyas("VBidxWeight", np.ascontiguousarray(vb3r).tobytes()))
    # --- IndexBuffer (prim-yerel u16; kapsanmayan ucgen 0 kalir -> fail-closed)
    ibr = np.zeros((NT, 3), "<u2")
    ib_ok = True
    for pr in G["prims"]:
        t0 = pr["firstIdx"] // 3; t1 = t0 + pr["NT"]
        yerel = G["ibg"][t0:t1] - pr["base"]
        if yerel.size and (yerel.min() < 0 or yerel.max() > 65535):
            ib_ok = False
            break
        ibr[t0:t1] = yerel.astype("<u2")
    out["IndexBuffer"] = ib_ok and kiyas("IndexBuffer", ibr.tobytes())
    # --- ham kopyalar
    out["VBprecompute"] = kiyas("VBprecompute", np.ascontiguousarray(G["vbp_ham"]).tobytes())
    out["ClusterDesc"] = kiyas("ClusterDesc", G["cluster_desc_ham"])
    out["ClusterBitMask"] = kiyas("ClusterBitMask", G["cluster_bitmask_ham"])
    out["hepsi"] = all(out[nm] for nm in TAMPONLAR)
    return out
