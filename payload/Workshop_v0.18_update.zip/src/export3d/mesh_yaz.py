# -*- coding: utf-8 -*-
"""mesh_yaz — duzenlenmis geometriyi GECERLI bir oyun ic dosyasina geri yazar.

IKI MOD VARDIR:
  `yaz`         — MOD 1, AYNI TOPOLOJI. Kumeli bicimi korur, cikti uzunlugu girdiyle
                  birebir aynidir, kume tablolarina dokunulmaz. Asagidaki basliktaki
                  tum olcumler bu modu anlatir.
  `yaz_serbest` — MOD 2, SERBEST TOPOLOJI. Mesh'i KUME-SIZ bicime cevirir; vertex ve
                  ucgen sayisi serbestce degisebilir. Ayrintili olcum notu `SURUM`
                  sabitinin hemen altindadir.
Cagiran icin ek: `prim_geometri(R, G)` mevcut geometriyi `yaz_serbest`in bekledigi
primitif listesine cevirir (duzenlemenin baslangic noktasi ve kimlik kapisinin girdisi).

--- MOD 1 (yaz) ------------------------------------------------------------------------
Kapsam: **AYNI TOPOLOJI**. Vertex sayisi, ucgen sayisi, prim yerlesimi, stride'lar ve
kume tablolari degismez; degisen yalnizca vertex ALANLARIDIR (konum, normal, tanjant, UV).
Cikti bayt uzunlugu girdiyle BIREBIR aynidir -> sarmalayici boyutu, K1 kayit uzunlugu ve
forge TOC'u degismez (forge'a yazmak bu modulun isi DEGIL; cikti ic dosya baytlaridir).

Yontem: `mesh_yapisal.bayt_kapisi` zaten 7 CMD tamponunu COZULEN alanlardan yeniden kurup
sha256 kiyasliyordu -- yani kodlayici embriyo halinde vardi. Bu modul o kurucuyu ayirir,
yeni alanlarla besler ve TURETILMIS TABLOLARI yeniden hesaplar.

--- OLCULMUS TABLO FORMULLERI (330 mesh: fmt0 282 / fmt1 8 / fmt3 20 / fmt4 20) -------
Hepsi COZULEN konumlardan yeniden uretildi ve diskteki degerle kiyaslandi; hata birimi
nicemleme adimi (skinned us/32768 m, rigid |w|/32768 m):
  * baslik bbox   = tum vertexlerin min/max'i          maks 0,498 adim (89 mesh, 4. bilesen 0.0)
  * CMD center/halfext = ayni kutu (center=(min+max)/2) maks 0,720 adim (330/330)
  * CPI center/halfext = prim'in INDEKSLENEN vertexleri maks 0,627 adim (329/330)
        - vertex ARALIGI ([base, base+NV)) adayi 5855 adima kadar sapiyor -> indeksli dogru
  * CPI SurfaceArea    = ucgen alanlari toplami (0,5*|cross|)  medyan oran 1,0000
        (p05 0,9982 · p95 1,0027; 405 prim)
  * CMD SphereBV       = COZULMEDI. Merkez ne kutu merkezi ne agirlik merkezi (medyan 12,5 mm
        sapma); yaricap ise merkeze en uzak vertexe 1,0009 medyan oraniyla oturuyor. Bu yuzden
        kure YENIDEN URETILMEZ: merkez kutu merkeziyle birlikte otelenir, yaricap mesh'in
        KENDI paylari korunarak (r_yeni = maks_uzaklik_yeni * r_eski/maks_uzaklik_eski)
        olceklenir -> asla kucultmez.
Tek aykiri mesh: Hat_U_Edward_Morgan_LOD0 (prim araliklari CAKISIYOR; prim1'in kayitli
SurfaceArea'si hesaplananin 1/18'i, CPI kutusu 369 adim sapiyor). Bu yuzden tablo yazimi
once ORIJINAL geometriyle bir "formul oz-denetimi" kosar: kendi formulumuz diskteki degeri
uretemiyorsa mesh REDDEDILIR (fail-closed), sessizce yanlis tablo yazilmaz.

--- REDDETME (fail-closed) ------------------------------------------------------------
  * vertex/ucgen sayisi degisti
  * yeni konum nicemleme araligina sigmiyor (|pos*32768/olcek| > 32767) -> her mesh'in
    ne kadar bosluğu oldugu `olcek_bosluk()` ile raporlanir
  * yeniden kurulan bir tampon uzunlugu orijinalden farkli
  * tablo formulu oz-denetimden gecmedi (yukaridaki aykiri mesh sinifi)
Bu listenin DORDU (konum bandi, rigid olcek yukseltme, dejenere ucgen, bos primitif)
POLITIKA reddetmesidir: `src/uzman.py` anahtari acikken YAZILIR ve rapor
`uzman_uyarilari` listesinde en kotu senaryoyu soyler (bkz. __all__'un altindaki not).
Kapasite reddetmeleri (65535 vertex, s16 tavani, tampon uzunlugu, IsIdx32) anahtardan
ETKILENMEZ.

--- ONCEKI IS (okundu, tekrar edilmedi) -----------------------------------------------
`karakter derleyicisi (cw_derle.py): mesh_kur` oyunda calisan bir mesh yazicisidir ama BASKA
bir isi yapar: topolojiyi DEGISTIRIR (kume tablosu olmayan bir sablona nv/nt yazar,
sarmalayici boyutunu @4'ten duzeltir, kuyruktaki vertex sayisini @21'den gunceller) ve
bbox'i CÖMERT payla yazar (min-[0.30,0.05,0.30], max+[0.30,0.70,0.30]) -- yani oyun
BUYUK bir bbox'i kabul ediyor. Burada bbox TAM yazilir, cunku `mesh_yapisal.oku` konum
olcegini bbox/ham oranindan turetiyor: payli bir kutu kendi okuyucumuzu yaniltirdi.
cw_derle CMD center/halfext, CPI ve SurfaceArea'ya HIC dokunmaz (sablonunda DrawPrims yok);
kume tabanli vanilla mesh'lerde bu tablolar VARDIR ve guncellenmek zorundadir.
`karakter ekleme araci (arac\\coklu_paket.py)` ise kap/doku isidir; mesh govdesine girmez
(oradan alinan tek sey: sarmalayici boyutu = 12 + len(govde), uzunluk sabit kalirsa
dokunulmasi gerekmez).
"""
import os
import sys
import struct
import hashlib
import numpy as np

from . import mesh_yapisal as MY

try:                                        # UZMAN MODU: politika kapilarinin anahtari
    import uzman as UZ
except ImportError:                         # src/ sys.path'te degilse (dogrudan cagri)
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import uzman as UZ

__all__ = ["yaz", "dene", "yaz_serbest", "dene_serbest", "prim_geometri", "olcek_bosluk",
           "tablo_oz_denetim", "YazmaHatasi", "SURUM"]


# --- UZMAN MODU (bkz. src/uzman.py) ----------------------------------------------------
# Bu modulde DORT politika kapisi vardir; hepsi ayni desendedir:
#     if <kosul>:
#         if not UZ.kapi("<ad>"):   raise YazmaHatasi(<bugunku metin>)   # varsayilan
#         _uyar(uyarilar, "<ad>", ...)                                    # uzman: devam + uyari
#   olcek_bandi     skinned konum bandi asildi (olcek="serbest"in yaptigi is)
#   olcek_yukselt   rigid konum olcegi (w) buyutulecek
#   dejenere_ucgen  dejenere ucgen (dejenere="gecir"in yaptigi is)
#   bos_primitif    primitif bosaltilamaz -> GORUNMEZ primitife tamamlanir
# Uretilen uyarilar `yaz_serbest`in raporunda `uzman_uyarilari` listesinde doner.
# KAPASITE kapilari (65535 vertex tavani, s16 nicemleme tavani, IsIdx32, stride,
# primitif SAYISI, tampon uzunlugu, tablo oz-denetimi) anahtardan ETKILENMEZ.
def _uyar(uyarilar, ad, **kw):
    """Uzman uyarisini listeye ekle (liste verilmediyse sessizce dus -- cagiran
    `yaz_serbest` her zaman verir; dogrudan cagri icin savunma)."""
    if uyarilar is None:
        return
    uyarilar.append(UZ.uyari(ad, **kw))

SURUM = "2.0"

# =====================================================================================
# MOD 2 — SERBEST TOPOLOJI (yaz_serbest): KUME-SIZ (cluster-free) bicime cevirerek yazar
# =====================================================================================
# `yaz` AYNI TOPOLOJIYI korumak zorundadir cunku kumeli bicimde ClusterDesc/ClusterBitMask/
# CPI tablolarinin uretimi cozulmemistir. Blender ise duzenleme YAPILMASA BILE vertex sayisini
# degistirir (Sword_W_PersianScimitar_01A_LOD0: 10.047 -> 10.080; 33 vertex UV/normal dikisinde
# bolunuyor) -> `yaz` gercek duzenleme icin kullanilamaz.
#
# COZUM (olculdu): OYUN KUME TABLOLARINI ZORUNLU TUTMUYOR. CompiledMesh govdesindeki
# gate_CMD bayti 3 ise ClusteredMeshData nesnesi HIC YOKTUR ve geometri MeshData'nin kendi
# 5 tamponunda yasar. Kanit zinciri:
#   * karakter derleyicisi (cw_derle.py) mesh_kur bu bicimi uretir (ucgen siler, ucgen ekler,
#     PN alt bolme yapar -> keyfi topoloji) ve ciktisi KAPTANIN OYUNUNDA KURULU VE CALISIYOR.
#   * O dosyalarda (CJ sablonu 2 mesh + karakter anim modu v30 2 mesh) 0xC351EE43 imzasi SIFIR kez gecer.
#   * Bu modulun cozumu `mesh_yapisal` ile 4/4 dosyada okundu ve 7 TAMPONUN HEPSI bayt-birebir
#     yeniden kuruldu; ayrica dosyalar bayt-birebir yeniden uretildi (gate b).
#
# KUME-SIZ BICIMDE NE DEGISIR (330 kumeli + 4 kume-siz mesh'te olculdu):
#   gate_CMD            0 -> 3   (ClusteredMeshData nesnesi silinir; gate_MPH 3 kalir)
#   MeshData.stride[3]  sP -> 0  (VBprecompute DUSER: 229/330 mesh'te uzunlugu NV*sP DEGIL,
#                                 yani per-vertex veri degil -> yeni vertexler icin uretilemez;
#                                 66/330 vanilla mesh zaten sP=0 ile geliyor)
#   MeshData.b7/b8/b9   -> 0,0,0 (330/330: (b7,b8,b9)==(0,0,0) <=> sP==0. Kural olculdu,
#                                 kume-siz Jack sablonu da 0,0,0)
#   MeshData.u32_10     -> 0     (sP==0 olan 66/66 vanilla mesh'te 0; iki kume-siz dosyada da 0)
#   MeshData 5 tamponu  bos -> nv*s0 | nv*s1 | nv*s2 | 0 | nt*6
#   MeshPrimitive       base/NV/firstIdx/NT yeniden yazilir (cok primitifli mesh desteklenir)
#   MeshInstancingData  MID[j].NV = ilgili prim'in yeni NV'si (kuyruk+21 = ilk MID'in NV'si;
#                                 cw_derle'nin "u16 @ kuyruk+21" yamasi BUDUR)
#   baslik bbox         yeni geometrinin TAM kutusu
#   sarmalayici boyutu  @4 = len(cikti) - 13 - adLen
# DEGISMEYENLER: kemik tablosu, prim etiket listeleri, materyal baglantilari (MID.material),
# CBA43E05 materyal listesi, 0x8A44FE7A kuyrugu, nesne basliklari.
#
# RIGID (fmt 3/4) KUME-SIZ YERLESIMI — olculmus karar: AYNI SERPISTIRILMIS AKIS kullanilir
# (VBstatic stride 20/28; VBdynamic/VBidxWeight/VBprecompute BOS). Ayri-tampon (skinned)
# yerlesimi bicimsel olarak MUMKUN DEGILDIR: tampon uzunluklari MeshData.stride[i] ile
# tanimlidir ve 40/40 rigid mesh'te stride[1..3] == 0 ve NbBonesPerVert == 0'dir -- ayri
# tamponlarin uzunlugunu tanimlayacak alan YOKTUR. Skinned yerlesime gecmek fmt'yi 0/1
# yapmayi, yani var olmayan kemik indeksi/agirligi uydurmayi gerektirirdi.
#
# KONUM OLCEGI (us) — 2026-09-04 olcumu:
#   skinned: pos = ham_s16/32768 * us.  us dosyada HICBIR ALANDA saklanmiyor (baslik bbox /
#   CMD / MeshData capalarinin +-256 B penceresi ve dosyanin son 400 B'si u8/u16/u32/f32 olarak
#   tarandi: 0 aday). Vanilla'da us == ceil(max|bbox|) 290/290 tutuyor ve BAGIMSIZ bir kahin
#   (vertex -> baskin kemigin bind konumu medyan mesafesi) 290/290 ayni us'u seciyor.
#   AMA kume-siz CJ sablonunda bbox PAYLI yazilmis (ceil 3) oldugu halde dogru olcek 2'dir
#   (kahin: medyan 0,094 m; us=3'te 0,570 m) -> "us = ceil(max|bbox|)" oyunun KESIN kurali
#   OLDUGU KANITLANAMAZ. Bu yuzden yazici olcegi DEGISTIRMEZ: us daima orijinalinkidir ve
#   yeni kutu TAM yazilir; ceil(max|yeni bbox|) != us cikan duzenleme (yani kullanicinin
#   modeli bir olcek bandini asmasi) REDDEDILIR -- iki hipotez orada ayrisiyor, sessizce
#   birini secmek yerine sebep gosterilir (`olcek="serbest"` ile bilincli olarak asilabilir).
#   rigid: olcek vertexin KENDI w alanindadir -> belirsizlik yok.
KUMESIZ_GATE = 3          # gate_CMD = 3  -> ClusteredMeshData YOK
POZ_GRUP_BASAMAK = 5      # normal/tanjant yumusatmasinda konum gruplamasi (10 mikron)

# --- GOLGELEME (normal/tanjant) SEMANTIGI -------------------------------------------
# Blender 5.2 ile OLCULDU (6 GLB, 44 parca, skinned + rigid; yer gercegi Blender'in KENDI
# hesapladigi normaller -- ozel bolunmus normaller silinip iki kipte yeniden uretildi:
# hepsi-yumusak ve 30 derece auto-smooth). Bizim hesabimizin Blender'a acisal sapmasi:
#
#   kaynastirma / esik      medyan     p95      >5 derece
#   ESKI YAZICI (alan agirlikli, kosulsuz konum kaynastirmasi)
#                           9,659     49,807      %51,3
#   KONUM  + 30 derece      0,003 .. 4,978   4,8 .. 37,6   %4,8 .. %44,8   (dosyaya gore oynak)
#   INDEKS + 180 derece     0,0021..0,0023   0,0036..0,0039     %0,00      <- SECILEN
#
# KOK NEDEN: Blender ayni KONUMDAKI farkli vertexleri KAYNASTIRMAZ. glTF ithalatcisi her
# glTF vertexini ayri bir Blender vertexi yapar, dolayisiyla UV dikisindeki kopya
# TOPOLOJIK olarak ayridir ve Blender golgelemeyi oradan gecirmez. Eski yazici konuma gore
# kosulsuz kaynastiriyordu: cift tarafli kumasta on/arka yuz tek normalde eriyip 178 derece
# hata veriyordu. Ayrica Blender yuz normalini KOSE ACISI ile agirliklandirir, ALAN ile degil.
# Ikinci gozlem: Blender'dan cikan GLB'de keskin kenarlar ZATEN vertex bolunmesi olarak
# maddelesmistir -> ayrica aci esigi uygulamak GEREKSIZ ve zararlidir (asiri boler).
NORMAL_KAYNASTIRMA = "indeks"   # "indeks" = Blender semantigi (varsayilan) · "konum" = eski
NORMAL_ACI_ESIGI = 180.0        # 180 = aci esigine gore EK bolme yok (Blender zaten bolmus)

# Tablo oz-denetim esikleri (olcume dayali: kutu maks 0,72 adim · alan p95 sapmasi %0,3)
KAPI_KUTU_ADIM = 2.0          # turetilmis kutu diskteki degerden en cok bu kadar adim sapabilir
KAPI_ALAN_ORAN = 0.05         # SurfaceArea bagil sapmasi
S16_MAKS = 32767


class YazmaHatasi(Exception):
    """Yazici bu mesh'i / bu duzenlemeyi reddetti. str() = kullaniciya gosterilecek sebep."""

    def __init__(self, sebep, ayrinti=None):
        Exception.__init__(self, sebep)
        self.sebep = sebep
        self.ayrinti = ayrinti

    def __str__(self):
        return self.sebep


# ----------------------------------------------------------------- kucuk yardimcilar
def _sha(b):
    return hashlib.sha256(bytes(b)).hexdigest()


def _s16_bayt(x, olcek=1.0):
    """float -> round(x*olcek) little-endian s16 bayt sutunlari. Aralik disi ise None."""
    v = np.round(np.asarray(x, np.float64) * olcek)
    if v.size and (v.min() < -32768 or v.max() > S16_MAKS):
        return None
    return np.ascontiguousarray(v.astype("<i2")).view(np.uint8).reshape(v.shape[0], -1)


def _adim(R):
    """Nicemleme adimi (metre). skinned: us/32768 · rigid: poz_olcek ZATEN adimdir."""
    return float(R["poz_olcek"]) if R.get("rigid") else float(R["poz_olcek"]) / 32768.0


def _ucgen_alan(P, TRI):
    if len(TRI) == 0:
        return 0.0
    a, b, c = P[TRI[:, 0]], P[TRI[:, 1]], P[TRI[:, 2]]
    return float(0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1).sum())


def _prim_ucgenleri(R, G, i):
    """prim i'nin global (ibg) ucgenleri + tabani. skinned: firstIdx/base · rigid: CPI."""
    pr = G["prims"][i]
    if R.get("rigid"):
        t0 = sum(p["NT"] for p in G["prims"][:i])
        return G["ibg"][t0:t0 + pr["NT"]]
    t0 = pr["firstIdx"] // 3
    return G["ibg"][t0:t0 + pr["NT"]]


def _kutu(P):
    return P.min(0), P.max(0)


def _tablolari_hesapla(R, G, pos):
    """`pos` konumlarindan turetilmis tablolarin TAMAMI -> sozluk.
    (baslik bbox / CMD center-halfext / CPI center-halfext-SurfaceArea)"""
    mn, mx = _kutu(pos)
    t = dict(bbox_min=mn, bbox_max=mx,
             cmd_center=(mn + mx) * 0.5, cmd_halfext=(mx - mn) * 0.5, cpi=[])
    for i in range(len(G["prims"])):
        tri = _prim_ucgenleri(R, G, i)
        if len(tri):
            kul = np.unique(tri.reshape(-1))
            kmn, kmx = _kutu(pos[kul])
            alan = _ucgen_alan(pos, tri)
        else:                                    # ucgensiz prim: kutu ve alan sifir
            kmn = kmx = np.zeros(3)
            alan = 0.0
        t["cpi"].append(dict(center=(kmn + kmx) * 0.5, halfext=(kmx - kmn) * 0.5, alan=alan))
    return t


def tablo_oz_denetim(R, G, data):
    """FORMUL KAPISI: turetilmis tablolari ORIJINAL geometriden yeniden hesaplar ve
    diskteki degerlerle kiyaslar. Formulumuz bu mesh'te diskteki degeri uretemiyorsa
    yeni tablo yazmak SESSIZ BIR YALAN olurdu -> yazici reddeder.
    -> {gecti, kutu_sapma_adim, alan_sapma, ayrinti}"""
    adim = _adim(R)
    t = _tablolari_hesapla(R, G, G["pos"])
    cmd = R["CMD"]
    sap = 0.0
    ayr = {}
    bb = R.get("baslik_bbox") or {}
    if R.get("kumesiz"):
        # Kume-siz bicimde CMD kutusu / CPI / SurfaceArea YOKTUR -> tek turetilmis tablo
        # baslik bbox'idir. (CJ sablonu gibi PAYLI kutulu ucuncu-sahis dosyalarda bu kapi
        # duser; o dosyalarda ayni-topoloji yazimi zaten tablo yazmadan yapilabilir.)
        if bb.get("off") is not None:
            d = max(float(np.abs(np.array(bb["min"][:3]) - t["bbox_min"]).max()),
                    float(np.abs(np.array(bb["max"][:3]) - t["bbox_max"]).max()))
            ayr["bbox_adim"] = d / adim
            sap = d / adim
        return dict(gecti=bool(sap <= KAPI_KUTU_ADIM), kutu_sapma_adim=round(sap, 4),
                    alan_sapma=0.0, kumesiz=True,
                    ayrinti={k: round(v, 4) for k, v in ayr.items()})
    if bb.get("off") is not None:
        d = max(float(np.abs(np.array(bb["min"][:3]) - t["bbox_min"]).max()),
                float(np.abs(np.array(bb["max"][:3]) - t["bbox_max"]).max()))
        ayr["bbox_adim"] = d / adim
        sap = max(sap, d / adim)
    d = max(float(np.abs(np.array(cmd["center"]) - t["cmd_center"]).max()),
            float(np.abs(np.array(cmd["halfext"]) - t["cmd_halfext"]).max()))
    ayr["cmd_adim"] = d / adim
    sap = max(sap, d / adim)
    cpi_adim = 0.0
    alan_sapma = 0.0
    for i, cp in enumerate(cmd["CPI"]):
        h = t["cpi"][i]
        d = max(float(np.abs(np.array(cp["center"]) - h["center"]).max()),
                float(np.abs(np.array(cp["halfext"]) - h["halfext"]).max()))
        cpi_adim = max(cpi_adim, d / adim)
        a0 = float(cp["SurfaceArea"])
        if a0 > 1e-9:
            alan_sapma = max(alan_sapma, abs(h["alan"] - a0) / a0)
        elif h["alan"] > 1e-6:
            alan_sapma = max(alan_sapma, 1.0)
    ayr["cpi_adim"] = cpi_adim
    ayr["alan_oran_sapma"] = alan_sapma
    sap = max(sap, cpi_adim)
    gecti = sap <= KAPI_KUTU_ADIM and alan_sapma <= KAPI_ALAN_ORAN
    return dict(gecti=bool(gecti), kutu_sapma_adim=round(sap, 4),
                alan_sapma=round(alan_sapma, 6),
                ayrinti={k: round(v, 4) for k, v in ayr.items()})


# ----------------------------------------------------------------- nicemleme / bosluk
def _nicemle(R, G, pos):
    """Yeni konumlar -> (ham s16 dizi, geri-cozulmus konum, bosluk_bilgisi).
    skinned: ham = round(pos*32768/us) · rigid: ham = round(pos*32768/w) (w per-vertex, isaretli).
    Aralik disi ise YazmaHatasi."""
    NV = G["NV"]
    pos = np.asarray(pos, np.float64)
    if R.get("rigid"):
        w = np.asarray(G["poz_w"], np.float64).reshape(NV, 1)
        with np.errstate(divide="ignore", invalid="ignore"):
            q = np.divide(pos * 32768.0, w, out=np.zeros((NV, 3)), where=w != 0)
        sifir_w = (w.reshape(-1) == 0)
        if sifir_w.any() and float(np.abs(pos[sifir_w]).max()) > 0:
            raise YazmaHatasi("vertices with w=0 must stay at the origin (%d affected)"
                              % int(sifir_w.sum()))
        ham = np.round(q)
        geri = ham * (w / 32768.0)
    else:
        us = float(R["poz_olcek"])
        q = pos * (32768.0 / us)
        ham = np.round(q)
        geri = ham * (us / 32768.0)
    maks = float(np.abs(q).max()) if q.size else 0.0
    bosluk = dict(maks_ham=maks,
                  bosluk_kati=(S16_MAKS / maks) if maks > 0 else float("inf"),
                  adim_m=_adim(R))
    if maks > S16_MAKS:
        raise YazmaHatasi(
            "positions do not fit the mesh quantisation range: |value| %.1f > %d "
            "(scale down by at least %.4fx)" % (maks, S16_MAKS, maks / S16_MAKS), bosluk)
    return ham, geri, bosluk


def olcek_bosluk(R, G, pos=None):
    """Bu mesh'in geometrisi s16 tavanina carpmadan EN COK kac kat buyutulebilir?
    -> {maks_ham, bosluk_kati, adim_m}. `pos` verilmezse cozulmus konumlar kullanilir."""
    p = G["pos"] if pos is None else pos
    NV = G["NV"]
    p = np.asarray(p, np.float64)
    if R.get("rigid"):
        w = np.asarray(G["poz_w"], np.float64).reshape(NV, 1)
        with np.errstate(divide="ignore", invalid="ignore"):
            q = np.divide(p * 32768.0, w, out=np.zeros((NV, 3)), where=w != 0)
    else:
        q = p * (32768.0 / float(R["poz_olcek"]))
    maks = float(np.abs(q).max()) if q.size else 0.0
    return dict(maks_ham=round(maks, 2), bosluk_kati=(S16_MAKS / maks) if maks > 0 else float("inf"),
                adim_m=_adim(R))


# ----------------------------------------------------------------- tampon kurucular
def _tamponlar_skinned(R, G, ham_poz, alan):
    """fmt 0/1 -> {tampon_adi: bytes}. `alan` = yeni alanlar sozlugu (None = degismedi).
    Yerlesim `mesh_yapisal.bayt_kapisi` ile BIREBIR aynidir (o kapi bu kurucunun kanitidir)."""
    NV = G["NV"]
    sS = R["CMD"]["stride"]["static"]
    out = {}
    # --- VBstatic: renk | uv0 | [uv1 | son4]
    uv0 = G["uv0"] if alan.get("uv0") is None else alan["uv0"]
    par = [np.ascontiguousarray(G["renk"]), _s16_bayt(uv0, 2048.0)]
    if G["uv1"] is not None:
        uv1 = G["uv1"] if alan.get("uv1") is None else alan["uv1"]
        par += [_s16_bayt(uv1, 2048.0), np.ascontiguousarray(G["son4"])]
    if any(p is None for p in par):
        raise YazmaHatasi("UV values do not fit the s16/2048 texture-coordinate range")
    vb1 = np.concatenate(par, 1)
    if vb1.shape[1] != sS:
        raise YazmaHatasi("rebuilt VBstatic stride %d != %d" % (vb1.shape[1], sS))
    out["VBstatic"] = vb1.tobytes()
    # --- VBdynamic: pos s16x3 | bayrak | b7 | nokt | tokt
    bay = np.asarray(G["bayrak"]).astype(np.uint8).copy()
    if alan.get("normal") is None:
        N = MY.okt_coz(G["nokt"], (bay & 1).astype(bool))
        nk = MY.okt_kodla(N)[0]
    else:
        nk, nneg = MY.okt_kodla(np.asarray(alan["normal"], np.float64))
        bay = (bay & ~np.uint8(1)) | nneg.astype(np.uint8)
    if alan.get("tangent") is None:
        Tn = MY.okt_coz(G["tokt"], ((bay >> 1) & 1).astype(bool))
        tk = MY.okt_kodla(Tn)[0]
    else:
        tk, tneg = MY.okt_kodla(np.asarray(alan["tangent"], np.float64))
        bay = (bay & ~np.uint8(2)) | (tneg.astype(np.uint8) << 1)
    posb = np.ascontiguousarray(ham_poz.astype("<i2")).view(np.uint8).reshape(NV, 6)
    vb2 = np.concatenate([posb, bay.reshape(NV, 1),
                          np.asarray(G["b7"]).reshape(NV, 1), nk, tk], 1)
    out["VBdynamic"] = vb2.tobytes()
    # --- VBidxWeight (degismez; ham alanlardan yeniden kurulur)
    bpk = int(G.get("bayt_per_kemik", 2))
    if bpk == 2:
        idxb = np.asarray(G["kemik_idx"]).astype(np.uint8)
    else:
        idxb = np.ascontiguousarray(np.asarray(G["kemik_idx"]).astype("<u2")).view(np.uint8).reshape(NV, -1)
    vb3 = np.concatenate([idxb, np.asarray(G["agirlik"]).astype(np.uint8)], 1)
    if vb3.shape[1] != R["CMD"]["stride"]["idxWeight"]:
        raise YazmaHatasi("rebuilt VBidxWeight stride %d != %d"
                          % (vb3.shape[1], R["CMD"]["stride"]["idxWeight"]))
    out["VBidxWeight"] = np.ascontiguousarray(vb3).tobytes()
    # --- IndexBuffer: prim-yerel u16
    ibr = np.zeros((G["NT"], 3), "<u2")
    for pr in G["prims"]:
        t0 = pr["firstIdx"] // 3
        yerel = G["ibg"][t0:t0 + pr["NT"]] - pr["base"]
        if yerel.size and (yerel.min() < 0 or yerel.max() > 65535):
            raise YazmaHatasi("index buffer out of u16 range after rebuild")
        ibr[t0:t0 + pr["NT"]] = yerel.astype("<u2")
    out["IndexBuffer"] = ibr.tobytes()
    # --- anlami cozulmemis tamponlar: HAM kopya
    out["VBprecompute"] = np.ascontiguousarray(G["vbp_ham"]).tobytes()
    out["ClusterDesc"] = bytes(G["cluster_desc_ham"])
    out["ClusterBitMask"] = bytes(G["cluster_bitmask_ham"])
    return out


def _tamponlar_rigid(R, G, ham_poz, alan):
    """fmt 3/4 -> {tampon_adi: bytes}. Tek serpistirilmis akis; IndexBuffer kume-dolgulu."""
    NV = G["NV"]
    sS = R["CMD"]["stride"]["static"]
    w = np.asarray(G["poz_w"], np.float64).reshape(NV, 1)
    posb = np.ascontiguousarray(ham_poz.astype("<i2")).view(np.uint8).reshape(NV, 6)
    wb = _s16_bayt(w, 1.0)
    if alan.get("normal") is None:
        nb_ = np.clip(np.round((np.asarray(G["normal_ham"]) + 1.0) * 127.0), 0, 255).astype(np.uint8)
    else:
        nb_ = np.clip(np.round((np.asarray(alan["normal"], np.float64) + 1.0) * 127.0), 0, 255).astype(np.uint8)
    if alan.get("tangent") is None:
        tb_ = np.clip(np.round((np.asarray(G["tangent_ham"]) + 1.0) * 127.0), 0, 255).astype(np.uint8)
    else:
        tb_ = np.clip(np.round((np.asarray(alan["tangent"], np.float64) + 1.0) * 127.0), 0, 255).astype(np.uint8)
    uv0 = G["uv0"] if alan.get("uv0") is None else alan["uv0"]
    par = [posb, wb, nb_, np.asarray(G["nw"]).reshape(NV, 1), tb_, np.asarray(G["tw"]).reshape(NV, 1)]
    if sS == 28:
        par.append(np.ascontiguousarray(G["renk"]))
    par.append(_s16_bayt(uv0, 2048.0))
    if sS == 28:
        uv1 = G["uv1"] if alan.get("uv1") is None else alan["uv1"]
        par.append(_s16_bayt(uv1, 2048.0))
    if any(p is None for p in par):
        raise YazmaHatasi("UV values do not fit the s16/2048 texture-coordinate range")
    vb1 = np.concatenate(par, 1)
    if vb1.shape[1] != sS:
        raise YazmaHatasi("rebuilt VBstatic stride %d != %d" % (vb1.shape[1], sS))
    out = {"VBstatic": vb1.tobytes()}
    # --- IndexBuffer: dolgulu tamponu HAMDAN baslat, gercek dilimleri yeniden yaz
    ibr = np.array(G["ib_ham"], dtype="<u2", copy=True)
    t0 = 0
    for i, pr in enumerate(G["prims"]):
        cpi = R["CMD"]["CPI"][i]
        yerel = G["ibg"][t0:t0 + pr["NT"]] - cpi["VertexStart"]
        t0 += pr["NT"]
        if yerel.size and (yerel.min() < 0 or yerel.max() > 65535):
            raise YazmaHatasi("index buffer out of u16 range after rebuild")
        i0 = cpi["IndexStart"]
        ibr[i0:i0 + pr["NT"] * 3] = yerel.reshape(-1).astype("<u2")
    out["IndexBuffer"] = ibr.tobytes()
    out["VBdynamic"] = b""
    out["VBidxWeight"] = b""
    out["VBprecompute"] = b""
    out["ClusterDesc"] = bytes(G["cluster_desc_ham"])
    out["ClusterBitMask"] = bytes(G["cluster_bitmask_ham"])
    return out


# ----------------------------------------------------------------- tablo yazimi
def _tablolari_yaz(buf, R, G, pos_yeni, sphere=True):
    """Turetilmis tablolari `buf` (bytearray) icine yazar. Doner: yazilanlarin ozeti."""
    t = _tablolari_hesapla(R, G, pos_yeni)
    cmd = R["CMD"]
    if R.get("kumesiz"):                       # CMD yok -> yalniz baslik kutusu yazilir
        bb = R.get("baslik_bbox") or {}
        if bb.get("off") is not None:
            o = bb["off"]
            struct.pack_into("<3f", buf, o, *[float(x) for x in t["bbox_min"]])
            struct.pack_into("<3f", buf, o + 16, *[float(x) for x in t["bbox_max"]])
            return dict(baslik_bbox=True, cmd_kutu=False, cpi=0, sphere=None), t
        return dict(baslik_bbox=False, cmd_kutu=False, cpi=0, sphere=None), t
    B = cmd["off"] + 12
    yaz_ = {}
    # Kure isi icin ESKI degerler HAM baytlardan okunur: R["CMD"]["center"] okuyucu tarafindan
    # 5 haneye YUVARLANMIS durumda; o yuvarlamayi kure merkezine tasimak kucuk mesh'lerde
    # yaricapi 4e-5 bagil kadar eksik birakiyordu (olculdu, 5/329 mesh geometriyi disarida birakti).
    _so = B + 54 + 52 * len(cmd["CPI"])
    _sb_eski = struct.unpack_from("<4f", buf, _so)
    _c_eski_ham = np.array(struct.unpack_from("<3f", buf, B + 25), np.float64)
    bb = R.get("baslik_bbox") or {}
    if bb.get("off") is not None:
        o = bb["off"]
        struct.pack_into("<3f", buf, o, *[float(x) for x in t["bbox_min"]])
        struct.pack_into("<3f", buf, o + 16, *[float(x) for x in t["bbox_max"]])
        yaz_["baslik_bbox"] = True
    else:
        # alt-varyant (isaretci yolu): baslik kutusunun ofseti cozulmedi -> yazilmaz.
        # `mesh_yapisal.oku` bu mesh'lerde olcegi CMD kutusundan turetir, o guncellenir.
        yaz_["baslik_bbox"] = False
    struct.pack_into("<3f", buf, B + 25, *[float(x) for x in t["cmd_center"]])
    struct.pack_into("<3f", buf, B + 37, *[float(x) for x in t["cmd_halfext"]])
    yaz_["cmd_kutu"] = True
    for i, h in enumerate(t["cpi"]):
        q2 = B + 54 + 52 * i + 12
        struct.pack_into("<f", buf, q2 + 12, float(h["alan"]))
        struct.pack_into("<3f", buf, q2 + 16, *[float(x) for x in h["center"]])
        struct.pack_into("<3f", buf, q2 + 28, *[float(x) for x in h["halfext"]])
    yaz_["cpi"] = len(t["cpi"])
    # --- SphereBV: algoritmasi COZULMEDI -> otele + payi koruyarak olcekle (asla kucultme)
    if sphere:
        so = _so
        sb = _sb_eski
        c_eski = _c_eski_ham
        sc_eski = np.array(sb[:3], np.float64)
        r_eski = float(sb[3])
        d_eski = float(np.linalg.norm(G["pos"] - sc_eski, axis=1).max()) if G["NV"] else 0.0
        pay = (r_eski / d_eski) if d_eski > 1e-9 else 1.0
        sc_yeni = sc_eski + (np.array(t["cmd_center"], np.float64) - c_eski)
        # Merkez ONCE f32'ye yuvarlanip GERI OKUNUR, yaricap ondan sonra olculur: kucuk
        # yaricapli mesh'lerde merkezin f32 yuvarlamasi (mutlak ~3e-8 m) bagil olarak
        # yaricapin 3e-5'ine kadar cikip kureyi geometrinin ICINDE birakiyordu (olculdu).
        struct.pack_into("<3f", buf, so, float(sc_yeni[0]), float(sc_yeni[1]), float(sc_yeni[2]))
        sc_f32 = np.array(struct.unpack_from("<3f", buf, so), np.float64)
        d_yeni = float(np.linalg.norm(pos_yeni - sc_f32, axis=1).max()) if G["NV"] else 0.0
        # (1 + 1e-6): yaricap da f32 saklanir; tam sinirda asagi yuvarlanmasin diye kucuk pay.
        r_yeni = max(d_yeni * max(pay, 1.0), r_eski if d_yeni <= d_eski else 0.0, d_yeni) * (1.0 + 1e-6)
        struct.pack_into("<f", buf, so + 12, float(r_yeni))
        yaz_["sphere"] = dict(pay=round(pay, 5), r_eski=round(r_eski, 5), r_yeni=round(r_yeni, 5))
    return yaz_, t


# ----------------------------------------------------------------- ana giris
def yaz(data, R, G, yeni_pos=None, yeni_normal=None, yeni_tangent=None,
        yeni_uv0=None, yeni_uv1=None, tablolar="auto", sphere=True):
    """Duzenlenmis geometri -> YENI ic dosya baytlari (uzunluk girdiyle AYNI).

    data      : orijinal ic dosya baytlari (sarmalayici dahil)
    R, G      : `mesh_yapisal.oku(data[, rigid=True])` ciktisi (AYNI `data` icin)
    yeni_*    : (NV,3) konum / normal / tanjant, (NV,2) UV. None = alan degismedi.
                Normal ve tanjant BIRIM vektor beklenir (skinned oktahedral, rigid u8x3).
    tablolar  : "auto" (varsayilan; alanlar degistiyse turetilmis tablolar yeniden
                hesaplanir), "always", "never".
    sphere    : CMD SphereBV de guncellensin mi (bkz. modul basligi -- otelenir, kucultulmez).

    -> (yeni_data: bytes, rapor: dict)
    Reddedilirse `YazmaHatasi` (str() = kullaniciya gosterilecek Ingilizce sebep)."""
    if tablolar not in ("auto", "always", "never"):
        raise YazmaHatasi("unknown table mode %r (use auto/always/never)" % (tablolar,))
    NV, NT = G["NV"], G["NT"]

    def _kontrol(ad, dizi, sut):
        if dizi is None:
            return None
        a = np.asarray(dizi, np.float64)
        if a.ndim != 2 or a.shape[1] != sut:
            raise YazmaHatasi("%s must have shape (%d, %d), got %s" % (ad, NV, sut, tuple(a.shape)))
        if a.shape[0] != NV:
            raise YazmaHatasi("vertex count changed: mesh has %d vertices, %s has %d "
                              "(this writer only supports edits with the SAME topology)"
                              % (NV, ad, a.shape[0]))
        if not np.isfinite(a).all():
            raise YazmaHatasi("%s contains NaN or infinite values" % ad)
        return a

    pos = _kontrol("positions", yeni_pos, 3)
    nrm = _kontrol("normals", yeni_normal, 3)
    tan = _kontrol("tangents", yeni_tangent, 3)
    uv0 = _kontrol("uv0", yeni_uv0, 2)
    uv1 = _kontrol("uv1", yeni_uv1, 2)
    if uv1 is not None and G.get("uv1") is None:
        raise YazmaHatasi("this mesh has no second UV set (stride %d)" % R["CMD"]["stride"]["static"])
    if pos is None:
        pos = np.asarray(G["pos"], np.float64)
    alan = dict(normal=nrm, tangent=tan, uv0=uv0, uv1=uv1)

    ham, poz_geri, bosluk = _nicemle(R, G, pos)
    kur = _tamponlar_rigid if R.get("rigid") else _tamponlar_skinned
    yeni_buf = kur(R, G, ham, alan)

    # --- tamponlari yerine yerlestir (uzunluk DEGISEMEZ)
    out = bytearray(data)
    T = R["CMD"]["tampon"]
    degisen = []
    for nm in MY.TAMPONLAR:
        o, l = T[nm]["off"], T[nm]["len"]
        yb = yeni_buf[nm]
        if len(yb) != l:
            raise YazmaHatasi("rebuilt %s is %d B but the file reserves %d B "
                              "(topology change is not supported)" % (nm, len(yb), l))
        if bytes(data[o:o + l]) != yb:
            degisen.append(nm)
        out[o:o + l] = yb

    rapor = dict(NV=int(NV), NT=int(NT), fmt=int(R["CMD"]["fmt"]), rigid=bool(R.get("rigid")),
                 alt_varyant=bool(R.get("alt_varyant")), B=len(data),
                 degisen_tampon=degisen, bosluk=bosluk,
                 verilen_alanlar=[k for k, v in dict(pos=yeni_pos, **alan).items() if v is not None])

    guncelle = (tablolar == "always") or (tablolar == "auto" and bool(degisen))
    if guncelle:
        oz = tablo_oz_denetim(R, G, data)
        rapor["tablo_oz_denetim"] = oz
        if not oz["gecti"]:
            raise YazmaHatasi(
                "derived tables cannot be recomputed for this mesh: our formula reproduces "
                "the stored values only to %.1f quantisation steps / %.1f%% surface area "
                "(limits %.1f / %.1f%%). Refusing rather than writing tables we cannot prove."
                % (oz["kutu_sapma_adim"], oz["alan_sapma"] * 100.0,
                   KAPI_KUTU_ADIM, KAPI_ALAN_ORAN * 100.0), oz)
        yaz_, t = _tablolari_yaz(out, R, G, poz_geri, sphere=sphere)
        rapor["tablo_yazildi"] = yaz_
    else:
        rapor["tablo_yazildi"] = None
        rapor["tablo_oz_denetim"] = None

    if len(out) != len(data):
        raise YazmaHatasi("internal error: output length %d != input length %d" % (len(out), len(data)))
    rapor["ayni_bayt"] = (bytes(out) == bytes(data))
    rapor["sha_eski"] = _sha(data)[:16]
    rapor["sha_yeni"] = _sha(out)[:16]
    return bytes(out), rapor


def dene(data, R, G, **kw):
    """`yaz` ile ayni ama reddetmede firlatmaz -> (bytes|None, rapor).
    Reddedilmisse rapor["red"] = sebep (kullaniciya gosterilecek Ingilizce dize)."""
    try:
        return yaz(data, R, G, **kw)
    except YazmaHatasi as e:
        return None, dict(red=str(e), ayrinti=e.ayrinti)


# =====================================================================================
#  SERBEST TOPOLOJI YAZICISI  (modul basligindaki "MOD 2" notu tum olcumleri tasiyor)
# =====================================================================================
def _grupla(pos, basamak=POZ_GRUP_BASAMAK):
    """Konuma gore vertex gruplama: UV/normal dikisinde BOLUNMUS kopyalar ayni gruba duser.
    Normal/tanjant bu gruplar uzerinde toplanir -> dikis cizgisi golgelemede gorunmez
    (cw_derle.mesh_kur ayni gruplamayi kullanir)."""
    if len(pos) == 0:
        return np.zeros(0, np.int64), 0
    key = np.round(np.asarray(pos, np.float64), basamak) + 0.0        # -0.0 -> 0.0
    _u, grup = np.unique(key, axis=0, return_inverse=True)
    grup = np.asarray(grup).reshape(-1)
    return grup, int(grup.max()) + 1


def _kose_bilesenleri(kenar_a, kenar_b, n_kose):
    """(kenar_a[i], kenar_b[i]) kose ciftlerinden bagli bilesenler -> (nkose,) kume indeksi.
    scipy varsa csgraph, yoksa saf-python birlestir-bul (ikisi de AYNI sonucu verir)."""
    if n_kose == 0:
        return np.zeros(0, np.int64)
    if len(kenar_a) == 0:
        return np.arange(n_kose, dtype=np.int64)
    try:
        from scipy.sparse import coo_matrix
        from scipy.sparse.csgraph import connected_components
        v = np.ones(len(kenar_a), np.int8)
        g = coo_matrix((v, (kenar_a, kenar_b)), shape=(n_kose, n_kose))
        _n, etiket = connected_components(g, directed=False)
        return np.asarray(etiket, np.int64)
    except ImportError:
        ust = list(range(n_kose))

        def _bul(a):
            k = a
            while ust[k] != k:
                k = ust[k]
            while ust[a] != k:
                ust[a], a = k, ust[a]
            return k

        for a, b in zip(kenar_a.tolist(), kenar_b.tolist()):
            ra, rb = _bul(a), _bul(b)
            if ra != rb:
                ust[rb] = ra
        kok = np.fromiter((_bul(i) for i in range(n_kose)), np.int64, n_kose)
        _u, kume = np.unique(kok, return_inverse=True)
        return np.asarray(kume).reshape(-1)


def _normal_tanjant(pos, tri, uv, grup, esik_deg=None):
    """Blender golgeleme semantigiyle vertex normali + UV tanjanti -> (N, T, el, olcum).

    ESKI SURUM IKI SEYI YANLIS YAPIYORDU (olculdu, bkz. NORMAL_ACI_ESIGI notu):
      1) yuz normalini ALAN agirligiyla topluyordu (Blender KOSE ACISI kullanir),
      2) ayni konumdaki tum vertexleri KOSULSUZ kaynastiriyordu -- keskin kenar da,
         cift tarafli kumasin ters yuzu de tek normalde eriyordu (178 derece hata).

    Yeni yontem: ucgen KOSELERI, paylastiklari kenarin iki yuzu arasindaki aci esikten
    kucukse birlesecek sekilde kumelenir (Blender'in "yelpaze" = fan mantigi). Kenar
    kimligi `grup` dizisinden gelir:
      grup = arange(nv)   -> BLENDER semantigi (varsayilan): ayni konumdaki farkli
                             vertexler kaynasmaz, yalnizca AYNI indeksi paylasan ucgenler
                             birbirine baglanir. Blender'a sapma medyan 0,0022 derece.
      grup = _grupla(pos) -> ESKI semantik: UV dikisindeki kopyalar da kaynasir.
    Esik 180 iken aci nedeniyle EK bolme yapilmaz (Blender'dan gelen GLB'de keskin kenar
    zaten vertex bolunmesi olarak maddelesmistir; ustune esik uygulamak asiri boler).
    Ucgeni olmayan (yetim) vertexler +z'ye sabitlenir."""
    esik = float(NORMAL_ACI_ESIGI if esik_deg is None else esik_deg)
    nv = len(pos)
    kullanilan = np.zeros(nv, bool)
    if nv == 0 or len(tri) == 0:
        Nv = np.tile(np.array([0.0, 0.0, 1.0]), (nv, 1))
        Tv = np.tile(np.array([1.0, 0.0, 0.0]), (nv, 1))
        return Nv, Tv, np.ones(nv, bool), dict(yetim_vertex=nv, yetim_grup=0, TN_ort=0.0,
                                               kume=0, cok_kumeli_vertex=0, esik_deg=esik)
    nt = len(tri)
    kullanilan[tri.reshape(-1)] = True
    p0, p1, p2 = pos[tri[:, 0]], pos[tri[:, 1]], pos[tri[:, 2]]
    e1, e2 = p1 - p0, p2 - p0
    fn = np.cross(e1, e2)
    fl = np.linalg.norm(fn, axis=1, keepdims=True)
    fnn = np.divide(fn, fl, out=np.zeros_like(fn), where=fl > 1e-20)
    # --- KOSE ACILARI (Blender'in agirligi)
    kenar_vec = [(p1 - p0, p2 - p0), (p2 - p1, p0 - p1), (p0 - p2, p1 - p2)]
    aci = np.zeros((nt, 3))
    for k, (a, b) in enumerate(kenar_vec):
        na = np.linalg.norm(a, axis=1); nb_ = np.linalg.norm(b, axis=1)
        ok = (na > 1e-20) & (nb_ > 1e-20)
        c = np.zeros(nt)
        c[ok] = np.clip((a[ok] * b[ok]).sum(1) / (na[ok] * nb_[ok]), -1.0, 1.0)
        aci[:, k] = np.where(ok, np.arccos(c), 0.0)
    # --- UV tanjant/bitanjant (yuz basina, Lengyel)
    u0, u1, u2 = uv[tri[:, 0]], uv[tri[:, 1]], uv[tri[:, 2]]
    du1, du2 = u1 - u0, u2 - u0
    det = du1[:, 0] * du2[:, 1] - du2[:, 0] * du1[:, 1]
    det = np.where(np.abs(det) < 1e-12, 1e-12, det)
    r = 1.0 / det
    Tf = (e1 * du2[:, 1:2] - e2 * du1[:, 1:2]) * r[:, None]
    Bf = (e2 * du1[:, 0:1] - e1 * du2[:, 0:1]) * r[:, None]
    tl = np.linalg.norm(Tf, axis=1, keepdims=True)
    Tfn = np.divide(Tf, tl, out=np.zeros_like(Tf), where=tl > 1e-20)
    bl = np.linalg.norm(Bf, axis=1, keepdims=True)
    Bfn = np.divide(Bf, bl, out=np.zeros_like(Bf), where=bl > 1e-20)
    # --- KOSE KUMELERI: kenari paylasan ve acisi esigin ALTINDA olan yuzler birlesir
    g3 = grup[tri]                                          # (nt,3) konum gruplari
    ng = int(grup.max()) + 1
    kose_a, kose_b = [], []
    ka = np.arange(nt) * 3
    for k in range(3):
        ga = g3[:, k]; gb = g3[:, (k + 1) % 3]
        lo = np.minimum(ga, gb); hi = np.maximum(ga, gb)
        kose_a.append(np.stack([lo, hi, ka + k, ka + (k + 1) % 3, ga], 1))
    E = np.concatenate(kose_a, 0)                           # (3nt, 5)
    yuz = np.concatenate([np.arange(nt)] * 3)
    anah = E[:, 0].astype(np.int64) * ng + E[:, 1]
    sira = np.argsort(anah, kind="stable")
    E = E[sira]; yuz = yuz[sira]; anah = anah[sira]
    _u, bas, adet = np.unique(anah, return_index=True, return_counts=True)
    cs = np.cos(np.radians(esik))
    ba, bb = [], []
    ikili = bas[adet == 2]
    if len(ikili):
        i0, i1 = ikili, ikili + 1
        uy = (fnn[yuz[i0]] * fnn[yuz[i1]]).sum(1) >= cs
        i0 = i0[uy]; i1 = i1[uy]
        ayni = E[i0, 4] == E[i1, 4]                         # kenarin ayni ucu mu?
        ba.append(np.where(ayni, E[i1, 2], E[i1, 3])); bb.append(E[i0, 2])
        ba.append(np.where(ayni, E[i1, 3], E[i1, 2])); bb.append(E[i0, 3])
    for b_, n_ in zip(bas[adet > 2].tolist(), adet[adet > 2].tolist()):
        for x in range(b_, b_ + n_ - 1):
            if float(fnn[yuz[x]] @ fnn[yuz[x + 1]]) < cs:
                continue
            ayni = E[x, 4] == E[x + 1, 4]
            ba.append(np.array([E[x + 1, 2] if ayni else E[x + 1, 3],
                                E[x + 1, 3] if ayni else E[x + 1, 2]]))
            bb.append(np.array([E[x, 2], E[x, 3]]))
    kume = _kose_bilesenleri(np.concatenate(ba) if ba else np.zeros(0, np.int64),
                             np.concatenate(bb) if bb else np.zeros(0, np.int64), 3 * nt)
    nk = int(kume.max()) + 1
    # --- kume basina normal / tanjant / bitanjant (aci agirlikli)
    agir = aci.reshape(-1)                                  # kose sirasi: tri*3 + k
    yuz_kose = np.repeat(np.arange(nt), 3)
    Nk = np.zeros((nk, 3)); Tk = np.zeros((nk, 3)); Bk = np.zeros((nk, 3))
    np.add.at(Nk, kume, fnn[yuz_kose] * agir[:, None])
    np.add.at(Tk, kume, Tfn[yuz_kose] * agir[:, None])
    np.add.at(Bk, kume, Bfn[yuz_kose] * agir[:, None])
    nu = np.linalg.norm(Nk, axis=1, keepdims=True)
    yetim_k = int((nu.reshape(-1) < 1e-12).sum())
    Nk = np.where(nu > 1e-12, Nk / np.maximum(nu, 1e-12), np.array([0.0, 0.0, 1.0]))
    # --- vertex -> BASKIN kume (aci agirligi en buyuk olan). Girdi vertexleri keskin
    #     kenarda zaten bolunmus oldugu icin normalde vertex basina TEK kume duser.
    vidx = tri.reshape(-1)
    kilit = kume.astype(np.int64) * (nv + 1) + vidx
    _uk, ters = np.unique(kilit, return_inverse=True)
    top = np.zeros(len(_uk))
    np.add.at(top, ters, agir)
    v_of = (_uk % (nv + 1)).astype(np.int64)
    k_of = (_uk // (nv + 1)).astype(np.int64)
    en_iyi = np.full(nv, -1, np.int64); en_agir = np.full(nv, -1.0)
    sirala = np.argsort(top, kind="stable")
    en_iyi[v_of[sirala]] = k_of[sirala]
    en_agir[v_of[sirala]] = top[sirala]
    cok = int(len(_uk) - int((en_iyi >= 0).sum()))
    gecerli = en_iyi >= 0
    Nv = np.tile(np.array([0.0, 0.0, 1.0]), (nv, 1))
    Tv = np.tile(np.array([1.0, 0.0, 0.0]), (nv, 1))
    Bv = np.tile(np.array([0.0, 1.0, 0.0]), (nv, 1))
    Nv[gecerli] = Nk[en_iyi[gecerli]]
    Tv[gecerli] = Tk[en_iyi[gecerli]]
    Bv[gecerli] = Bk[en_iyi[gecerli]]
    Tv = Tv - Nv * (Tv * Nv).sum(1, keepdims=True)
    tu = np.linalg.norm(Tv, axis=1)
    sifir = tu < 1e-9
    if sifir.any():
        yedek = np.cross(Nv[sifir], np.array([0.0, 1.0, 0.0]))
        kotu = np.linalg.norm(yedek, axis=1) < 1e-6
        if kotu.any():
            yedek[kotu] = np.cross(Nv[sifir][kotu], np.array([1.0, 0.0, 0.0]))
        Tv[sifir] = yedek
        tu = np.linalg.norm(Tv, axis=1)
    Tv = Tv / np.maximum(tu[:, None], 1e-12)
    Bn = Bv / np.maximum(np.linalg.norm(Bv, axis=1, keepdims=True), 1e-12)
    el = (np.cross(Nv, Tv) * Bn).sum(1) > 0
    olcum = dict(yetim_vertex=int((~kullanilan).sum()), yetim_grup=yetim_k,
                 kume=nk, cok_kumeli_vertex=cok, esik_deg=esik,
                 TN_ort=float(np.abs((Nv * Tv).sum(1)[kullanilan]).mean()) if kullanilan.any() else 0.0)
    return Nv, Tv, el, olcum


def _en_yakin(kaynak, hedef):
    """hedef'teki her nokta icin kaynak'taki en yakin indeks. scipy varsa cKDTree,
    yoksa parcali kaba kuvvet (bellek sinirli)."""
    kaynak = np.asarray(kaynak, np.float64); hedef = np.asarray(hedef, np.float64)
    if len(kaynak) == 0:
        return np.zeros(len(hedef), np.int64)
    try:
        from scipy.spatial import cKDTree
        return np.asarray(cKDTree(kaynak).query(hedef)[1], np.int64)
    except ImportError:
        out = np.zeros(len(hedef), np.int64)
        adim = max(1, int(4e6 // max(len(kaynak), 1)))
        for i in range(0, len(hedef), adim):
            d = ((hedef[i:i + adim, None, :] - kaynak[None, :, :]) ** 2).sum(-1)
            out[i:i + adim] = d.argmin(1)
        return out


def _u8_agirlik(w):
    """(nv, nb) float ya da u8 agirlik -> u8, satir toplami TAM 255 (en buyuk yuvaya artik)."""
    w = np.asarray(w, np.float64)
    if w.size == 0:
        return w.astype(np.uint8)
    t = w.sum(1, keepdims=True)
    w = np.divide(w, t, out=np.zeros_like(w), where=t > 0)
    q = np.floor(w * 255.0).astype(np.int64)
    eksik = 255 - q.sum(1)
    q[np.arange(len(q)), np.argmax(w, axis=1)] += eksik
    return np.clip(q, 0, 255).astype(np.uint8)


def _mid_prim_esle(R, G):
    """Her MeshInstancingData kaydinin hangi MeshPrimitive'in NV'sini tasidigini
    ORIJINAL dosyada dogrulayarak bulur (405 kayitta olculdu: 398'i MID.prim, 3'u
    SIRA ile eslesiyor; 4'u -- Hat_U_Edward_Morgan ve 3 gemi decal'i -- HICBIRIYLE
    eslesmiyor). Eslesmeyen dosya REDDEDILIR: yanlis NV yazmak sessiz bir yalan olurdu.
    -> (esle: [prim_idx], hata: None | (j, NV))"""
    md = R["MeshData"]; prims = md["prims"]; mids = md["MeshInstancingData"]
    esle = []
    for j, m in enumerate(mids):
        aday = None
        if j < len(prims) and prims[j]["NV"] == m["NV"]:
            aday = j
        elif m["prim"] < len(prims) and prims[m["prim"]]["NV"] == m["NV"]:
            aday = m["prim"]
        elif len(prims) == 1 and m["NV"] == G["NV"]:
            aday = 0
        if aday is None:
            return None, (j, m["NV"])
        esle.append(aday)
    return esle, None


def _prim_dogrula(i, p, nb, sS, rigid, dejenere, kpos=None, uyarilar=None):
    """Tek primitif sozlugu -> dogrulanmis (pos, tri, uv0, uv1) + olcum. Fail-closed.

    kpos     : ORIJINAL primitifin vertexleri (bos primitifi doldururken agirlik
               merkezi buradan alinir; None verilebilir)
    uyarilar : uzman modu uyarilarinin toplandigi liste (bkz. `_uyar`)"""
    if not isinstance(p, dict):
        raise YazmaHatasi("primitive %d must be a dict with 'pos' and 'tri'" % i)
    if p.get("pos") is None or p.get("tri") is None:
        raise YazmaHatasi("primitive %d needs both 'pos' (N,3) and 'tri' (M,3)" % i)
    pos = np.asarray(p["pos"], np.float64)
    tri = np.asarray(p["tri"], np.int64)
    if pos.ndim != 2 or pos.shape[1] != 3:
        raise YazmaHatasi("primitive %d: 'pos' must have shape (N, 3), got %s" % (i, tuple(pos.shape)))
    if tri.ndim != 2 or tri.shape[1] != 3:
        raise YazmaHatasi("primitive %d: 'tri' must have shape (M, 3), got %s" % (i, tuple(tri.shape)))
    nv, nt = len(pos), len(tri)
    if nv < 3 or nt < 1:
        # C11 POLITIKA: bos primitif. Varsayilan REDDEDER; uzman modunda GORUNMEZ bir
        # primitife tamamlanir (3 vertex tek noktada + 1 sifir-alanli ucgen) -- bu, ayni
        # kod tabaninda `mesh_ithal._cokuk_prim`in capraz aktarimda zaten urettigi bicimdir.
        if not UZ.kapi("bos_primitif"):
            if nv < 3:
                raise YazmaHatasi("primitive %d has %d vertices; a primitive cannot be emptied "
                                  "(delete the object in Blender only if you also drop its material)"
                                  % (i, nv))
            raise YazmaHatasi("primitive %d has no triangles; a primitive cannot be emptied" % i)
        pos, tri, yer = _bos_primitif_doldur(pos, kpos)
        _uyar(uyarilar, "bos_primitif", grup=i, nv=nv, nt=nt, yer=yer)
        nv, nt = len(pos), len(tri)
    if not np.isfinite(pos).all():
        raise YazmaHatasi("primitive %d: 'pos' contains NaN or infinite values (%d vertices)"
                          % (i, int((~np.isfinite(pos)).any(1).sum())))
    if nv > 65535:
        raise YazmaHatasi(
            "primitive %d has %d vertices; the index buffer is 16-bit (MeshData.IsIdx32 = 0 in "
            "330/330 vanilla and 4/4 cluster-free meshes measured) and MeshInstancingData.NV is a "
            "u16, so a single primitive is capped at 65535 vertices. Switching IsIdx32 to 1 is NOT "
            "supported: no mesh with a 32-bit index buffer exists in the measured corpus, so its "
            "layout is unverified. Split the mesh across primitives instead." % (i, nv))
    if tri.size and (tri.min() < 0 or tri.max() >= nv):
        raise YazmaHatasi("primitive %d: triangle index out of range (min %d, max %d, NV %d)"
                          % (i, int(tri.min()), int(tri.max()), nv))
    dej = int(((tri[:, 0] == tri[:, 1]) | (tri[:, 1] == tri[:, 2]) | (tri[:, 0] == tri[:, 2])).sum())
    if dej and dejenere == "reddet":
        # C10 POLITIKA: dejenere ucgen. `dejenere="gecir"` modu ZATEN VAR; uzman modu
        # varsayilan cagriyi da o moda dusurur ve sebebini SOYLER.
        if not UZ.kapi("dejenere_ucgen"):
            # Bu mesaj artik KULLANICIYA gidiyor (IMPORT 3D dogrulama raporu): API
            # ipucu ('dejenere' parametresi) yerine Blender'da yapilacak isi soyler.
            raise YazmaHatasi("material group %d has %d degenerate triangles (two or more corners of "
                              "the triangle are the same point). Fix them in Blender with "
                              "Edit Mode > Mesh > Clean Up > Degenerate Dissolve, save the .glb again "
                              "and import once more." % (i, dej))
        _uyar(uyarilar, "dejenere_ucgen", grup=i, sayi=dej)
    return pos, tri, nv, nt, dej


def _bos_primitif_doldur(pos, kpos):
    """Bos/eksik primitifi GORUNMEZ bir primitife tamamlar: TEK NOKTADA 3 vertex ve
    1 sifir-alanli ucgen. Doner (pos, tri, yer_metni).

    Nokta secimi bilerek KAYNAKTAN: kalan vertexler varsa onlarin, yoksa orijinal
    primitifin agirlik merkezi. Boylece mesh'in sinir kutusu buyumez -- (0,0,0)
    kullanmak kutuyu karakterin koku kadar genisletip yanlis mesafede kirpilmasina
    yol acabilirdi. Kaynak da yoksa (0,0,0) kalir ve uyari bunu ACIKCA yazar."""
    p = np.asarray(pos, np.float64)
    if len(p):
        c = p.mean(0)
    elif kpos is not None and len(np.asarray(kpos)):
        c = np.asarray(kpos, np.float64).mean(0)
    else:
        c = np.zeros(3)
    return (np.repeat(c[None, :], 3, 0), np.array([[0, 1, 2]], np.int64),
            "(%.4f, %.4f, %.4f) m" % (float(c[0]), float(c[1]), float(c[2])))


def _kaynak_vertex_araligi(R, G, i):
    """prim i'nin ORIJINAL vertex araligi [v0, v1). Rigid KUMELI mesh'te taban
    MeshPrimitive.base DEGIL CPI[i].VertexStart'tir (10 gemi decal mesh'inde ayrisiyorlar --
    `mesh_yapisal` RIGID notunda olculdu)."""
    pr = R["MeshData"]["prims"][i]
    if R.get("rigid") and not R.get("kumesiz") and i < len(R["CMD"]["CPI"]):
        v0 = R["CMD"]["CPI"][i]["VertexStart"]
    else:
        v0 = pr["base"]
    return int(v0), int(v0 + pr["NV"])


def prim_geometri(R, G):
    """MEVCUT geometriyi `yaz_serbest`in bekledigi primitif listesine cevirir.
    Kimlik kapisinin (degistirilmemis mesh -> kume-siz bicim -> geri oku) girdisidir ve
    cagiran icin de duzenleme baslangicidir."""
    out = []
    t0 = 0
    for i, pr in enumerate(R["MeshData"]["prims"]):
        v0, v1 = _kaynak_vertex_araligi(R, G, i)
        if R.get("rigid"):
            tri = np.asarray(G["ibg"])[t0:t0 + pr["NT"]] - v0
        else:
            a = pr["firstIdx"] // 3
            tri = np.asarray(G["ibg"])[a:a + pr["NT"]] - v0
        t0 += pr["NT"]
        d = dict(pos=np.asarray(G["pos"], np.float64)[v0:v1], tri=np.asarray(tri, np.int64),
                 uv0=np.asarray(G["uv0"], np.float64)[v0:v1])
        if G.get("uv1") is not None:
            d["uv1"] = np.asarray(G["uv1"], np.float64)[v0:v1]
        if G.get("renk") is not None:
            d["renk"] = np.asarray(G["renk"])[v0:v1]
        if G.get("son4") is not None:
            d["son4"] = np.asarray(G["son4"])[v0:v1]
        if R.get("rigid"):
            d["normal"] = np.asarray(G["normal"])[v0:v1]
            d["tangent"] = np.asarray(G["tangent"])[v0:v1]
            d["nw"] = np.asarray(G["nw"])[v0:v1]
            d["tw"] = np.asarray(G["tw"])[v0:v1]
        else:
            d["b7"] = np.asarray(G["b7"])[v0:v1]
            d["normal"] = MY.okt_coz(np.asarray(G["nokt"])[v0:v1],
                                     (np.asarray(G["bayrak"])[v0:v1] & 1).astype(bool))
            d["tangent"] = MY.okt_coz(np.asarray(G["tokt"])[v0:v1],
                                      ((np.asarray(G["bayrak"])[v0:v1] >> 1) & 1).astype(bool))
            d["kemik_idx"] = np.asarray(G["kemik_idx"])[v0:v1]
            d["agirlik"] = np.asarray(G["agirlik"])[v0:v1]
            # el kurali biti (bayrak bit 2): UV parametrizasyonundan YENIDEN hesaplanabilir
            # ama diskteki degerle her zaman ortusmuyor (289 mesh'te medyan %0,000 fark,
            # p95 %5,68, maks %19,09) -> degismeyen vertexlerde DISKTEKI deger tasinir.
            d["el"] = ((np.asarray(G["bayrak"])[v0:v1] >> 2) & 1).astype(bool)
        out.append(d)
    return out


def yaz_serbest(data, R, G, primler, olcek="orijinal", dejenere="reddet",
                normal="auto", tangent="auto", deri="auto",
                golgeleme=NORMAL_KAYNASTIRMA):
    """SERBEST TOPOLOJI: yeni geometriyi KUME-SIZ bicime cevirerek yeni ic dosya uretir.

    data     : ORIJINAL ic dosya baytlari (kumeli ya da kume-siz)
    R, G     : `mesh_yapisal.oku(data[, rigid=True])` ciktisi (AYNI `data` icin)
    primler  : primitif basina sozluk listesi -- UZUNLUGU ORIJINAL PRIM SAYISINA ESIT
               olmalidir (her primitifin materyal baglantisi MeshInstancingData'da durur;
               primitif eklemek/silmek materyal listesini de degistirmek demektir ve bu
               yazicinin kapsaminda DEGILDIR). Sozluk alanlari:
                 pos   (nv,3) float  ZORUNLU        tri (nt,3) int  ZORUNLU
                 uv0   (nv,2) float  yoksa en yakin komsudan tasinir
                 uv1   (nv,2)        yalniz ikinci UV seti olan mesh'lerde
                 normal / tangent (nv,3)            yoksa yeni ucgenlerden hesaplanir
                 kemik_idx (nv,nb) / agirlik (nv,nb)  skinned; yoksa en yakin komsudan
                 renk (nv,4) u8 / son4 (nv,4) u8 / b7 (nv,) u8   yoksa en yakin komsudan
                 el    (nv,) bool  el kurali biti; yoksa UV parametrizasyonundan hesaplanir
    olcek    : "orijinal" (varsayilan; konum olcegi degismez, band asilirsa REDDEDILIR)
               ya da "serbest" (us = ceil(max|pos|) -- bkz. modul basligi, iki hipotez)
    dejenere : "reddet" (varsayilan) | "gecir"
    normal / tangent : "auto" (verilmediyse hesapla) | "hesapla" (verilse de hesapla)
    deri     : "auto" (verilmediyse en yakin komsudan tasi) | "zorunlu" (verilmemisse reddet)
    golgeleme: "indeks" (varsayilan, BLENDER semantigi: ayni konumdaki farkli vertexler
               KAYNASMAZ) | "konum" (eski davranis: konuma gore kaynastir). Yalnizca
               normal/tanjant HESAPLANDIGINDA etkilidir; Blender normal verdiyse aynen alinir.

    -> (yeni_data: bytes, rapor: dict).  Reddedilirse `YazmaHatasi`."""
    if olcek not in ("orijinal", "serbest"):
        raise YazmaHatasi("unknown scale mode %r (use 'orijinal' or 'serbest')" % (olcek,))
    if golgeleme not in ("indeks", "konum"):
        raise YazmaHatasi("unknown shading mode %r (use 'indeks' or 'konum')" % (golgeleme,))
    if dejenere not in ("reddet", "gecir"):
        raise YazmaHatasi("unknown degenerate mode %r (use 'reddet' or 'gecir')" % (dejenere,))
    md = R["MeshData"]
    cmd = R["CMD"]
    eski_prims = md["prims"]
    rigid = bool(R.get("rigid"))
    kumesiz_kaynak = bool(R.get("kumesiz"))
    bb = R.get("baslik_bbox") or {}
    if bb.get("off") is None:
        raise YazmaHatasi(
            "this mesh uses the pointer sub-variant: the header bounding box offset could not be "
            "resolved, so the box that the game needs after a topology change cannot be written. "
            "Free-topology editing is not supported for this mesh.")
    if md["IsIdx32"] != 0:
        raise YazmaHatasi("MeshData.IsIdx32 = %d (32-bit index buffer) is unverified; refusing"
                          % md["IsIdx32"])
    sS = cmd["stride"]["static"]
    sD = cmd["stride"]["dynamic"]
    sW = cmd["stride"]["idxWeight"]
    if rigid:
        if sS not in (20, 28):
            raise YazmaHatasi("rigid VBstatic stride %d is not one of the measured layouts (20, 28)" % sS)
    else:
        if sD != 12:
            raise YazmaHatasi("skinned VBdynamic stride %d != 12 (unsupported layout)" % sD)
        if sS not in (8, 16):
            raise YazmaHatasi("skinned VBstatic stride %d is not one of the measured layouts (8, 16)" % sS)
    if not isinstance(primler, (list, tuple)):
        raise YazmaHatasi("'primler' must be a list of per-primitive dicts")
    if len(primler) != len(eski_prims):
        raise YazmaHatasi(
            "this mesh has %d primitive(s) but %d were given. The writer keeps the primitive count "
            "fixed because each primitive is bound to one material through MeshInstancingData; "
            "adding or removing a primitive would change the material list too."
            % (len(eski_prims), len(primler)))
    mid_esle, mid_hata = _mid_prim_esle(R, G)
    if mid_esle is None:
        raise YazmaHatasi(
            "this mesh's MeshInstancingData record %d carries a vertex count (%d) that matches no "
            "primitive, so the writer cannot tell which primitive to update after a topology change. "
            "Refusing rather than writing a count it cannot prove." % mid_hata)

    nb = int(G.get("nb") or 0)
    bpk = int(G.get("bayt_per_kemik") or 0)
    # UZMAN MODU: acilan her politika kapisi buraya bir cumle birakir; rapor onu
    # `uzman_uyarilari` olarak dondurur (cagiran onay ekraninda gosterir).
    uzman_uyarilari = []
    olcumler = []
    P, T, UV0, UV1 = [], [], [], []
    NRM, TAN, REN, SON4, B7, KIDX, AGR, NW, TW = [], [], [], [], [], [], [], [], []
    taban = 0
    yeni_prims = []
    ilk_tri = 0
    for i, p in enumerate(primler):
        eski = eski_prims[i]
        # --- kaynak (orijinal) prim vertexleri: aktarilmayan alanlar buradan tasinir
        # (dogrulamadan ONCE hesaplanir: uzman modunda bos primitif bu vertexlerin
        #  agirlik merkezine cokertilir, bkz. `_bos_primitif_doldur`)
        k0, k1 = _kaynak_vertex_araligi(R, G, i)
        kpos = np.asarray(G["pos"], np.float64)[k0:k1]
        pos, tri, nv, nt, dej = _prim_dogrula(i, p, nb, sS, rigid, dejenere,
                                              kpos=kpos, uyarilar=uzman_uyarilari)
        ayni = (nv == eski["NV"])
        yakin = None

        def _al(ad, sut, kaynak_dizi, tam=None):
            """primler[i][ad] verildiyse onu dogrula; yoksa ayni NV'de HAM kopyala,
            degistiyse en yakin komsudan tasi."""
            v = p.get(ad)
            if v is not None:
                a = np.asarray(v)
                if a.ndim == 1:
                    a = a.reshape(-1, 1) if sut == 1 else a
                if (a.shape[0] != nv) or (sut and a.ndim == 2 and a.shape[1] != sut):
                    raise YazmaHatasi("primitive %d: '%s' must have shape (%d, %s), got %s"
                                      % (i, ad, nv, sut, tuple(a.shape)))
                return a, "verildi"
            if kaynak_dizi is None:
                return (np.zeros((nv, sut)) if tam is None else np.full((nv, sut), tam)), "sabit"
            ks = np.asarray(kaynak_dizi)[k0:k1]
            if ayni:
                return ks, "kopya"
            nonlocal yakin
            if yakin is None:
                yakin = _en_yakin(kpos, pos)
            return ks[yakin], "en_yakin"

        uv0, uv0_k = _al("uv0", 2, G.get("uv0"))
        uv0 = np.asarray(uv0, np.float64)
        uv1 = None; uv1_k = None
        ikinci_uv = (not rigid and sS >= 16) or (rigid and sS == 28)
        if ikinci_uv:
            uv1, uv1_k = _al("uv1", 2, G.get("uv1"))
            uv1 = np.asarray(uv1, np.float64)
        # --- turetilmis alanlar
        # golgeleme grubu: "indeks" (Blender semantigi, varsayilan) her vertexi ayri tutar;
        # kaynasma yalnizca PAYLASILAN UCGEN KENARI uzerinden olur. "konum" eski davranistir.
        if golgeleme == "konum":
            grup, _ng = _grupla(pos)
        else:
            grup = np.arange(nv, dtype=np.int64)
        N, Tn, el, gol = _normal_tanjant(pos, tri, uv0, grup)
        if normal == "auto" and p.get("normal") is not None:
            N = np.asarray(p["normal"], np.float64)
            if N.shape != (nv, 3):
                raise YazmaHatasi("primitive %d: 'normal' must have shape (%d, 3)" % (i, nv))
            nu = np.linalg.norm(N, axis=1, keepdims=True)
            N = np.divide(N, nu, out=np.tile(np.array([0.0, 0.0, 1.0]), (nv, 1)), where=nu > 1e-12)
            # Tanjant HESAPLANAN normale gore diklestirilmisti; verilen normal baska
            # bir yone bakiyorsa taban carpik kalirdi -> yeniden Gram-Schmidt + el.
            Tn = Tn - N * (Tn * N).sum(1, keepdims=True)
            _tu = np.linalg.norm(Tn, axis=1, keepdims=True)
            _yd = np.cross(N, np.array([0.0, 1.0, 0.0]))
            _ky = np.linalg.norm(_yd, axis=1) < 1e-6
            if _ky.any():
                _yd[_ky] = np.cross(N[_ky], np.array([1.0, 0.0, 0.0]))
            Tn = np.divide(Tn, _tu, out=_yd, where=_tu > 1e-9)
            Tn = Tn / np.maximum(np.linalg.norm(Tn, axis=1, keepdims=True), 1e-12)
        if tangent == "auto" and p.get("tangent") is not None:
            Tn = np.asarray(p["tangent"], np.float64)
            if Tn.shape != (nv, 3):
                raise YazmaHatasi("primitive %d: 'tangent' must have shape (%d, 3)" % (i, nv))
            Tn = Tn - N * (Tn * N).sum(1, keepdims=True)
            tu = np.linalg.norm(Tn, axis=1, keepdims=True)
            Tn = np.divide(Tn, tu, out=np.tile(np.array([1.0, 0.0, 0.0]), (nv, 1)), where=tu > 1e-12)
        if p.get("el") is not None and not rigid:
            _el = np.asarray(p["el"]).reshape(-1)
            if len(_el) != nv:
                raise YazmaHatasi("primitive %d: 'el' must have %d entries" % (i, nv))
            el = _el.astype(bool)
        # --- opak / deri alanlari
        if rigid:
            renk = None
            if sS == 28:
                renk, _ = _al("renk", 4, G.get("renk"), tam=255)
            nw, _ = _al("nw", 1, np.asarray(G["nw"]).reshape(-1, 1) if G.get("nw") is not None else None, tam=0)
            tw, _ = _al("tw", 1, np.asarray(G["tw"]).reshape(-1, 1) if G.get("tw") is not None else None, tam=0)
            NW.append(np.asarray(nw).reshape(nv)); TW.append(np.asarray(tw).reshape(nv))
            REN.append(renk); SON4.append(None); B7.append(None); KIDX.append(None); AGR.append(None)
        else:
            renk, _ = _al("renk", 4, G.get("renk"), tam=255)
            son4 = None
            if sS >= 16:
                son4, _ = _al("son4", 4, G.get("son4"), tam=255)
            b7v, _ = _al("b7", 1, np.asarray(G["b7"]).reshape(-1, 1) if G.get("b7") is not None else None, tam=0)
            if p.get("kemik_idx") is not None and p.get("agirlik") is not None:
                ki = np.asarray(p["kemik_idx"], np.int64)
                ag = np.asarray(p["agirlik"])
                if ki.shape[0] != nv or ag.shape[0] != nv:
                    raise YazmaHatasi("primitive %d: 'kemik_idx'/'agirlik' must have %d rows" % (i, nv))
                if ki.shape[1] > nb or ag.shape[1] > nb:
                    raise YazmaHatasi("primitive %d: this mesh stores %d bone influences per vertex; "
                                      "%d were given (drop the smallest weights first)"
                                      % (i, nb, max(ki.shape[1], ag.shape[1])))
                kif = np.zeros((nv, nb), np.int64); kif[:, :ki.shape[1]] = ki
                agf = np.zeros((nv, nb), np.float64); agf[:, :ag.shape[1]] = ag
                deri_k = "verildi"
            else:
                if deri == "zorunlu":
                    raise YazmaHatasi("primitive %d: skin data required (pass 'kemik_idx' and "
                                      "'agirlik'); deri='auto' would transfer it from the nearest "
                                      "original vertex instead" % i)
                kif, deri_k = _al("__kemik", nb, G.get("kemik_idx"))
                agf, _ = _al("__agirlik", nb, G.get("agirlik"))
                kif = np.asarray(kif, np.int64); agf = np.asarray(agf, np.float64)
            kmax = int(kif.max()) if kif.size else -1
            if kmax >= R["kemik"]["sayi"]:
                raise YazmaHatasi("primitive %d: bone index %d is outside this mesh's %d-bone palette"
                                  % (i, kmax, R["kemik"]["sayi"]))
            KIDX.append(kif); AGR.append(agf)
            REN.append(renk); SON4.append(son4); B7.append(np.asarray(b7v).reshape(nv))
            NW.append(None); TW.append(None)
        P.append(pos); T.append(tri); UV0.append(uv0); UV1.append(uv1)
        NRM.append(N); TAN.append(Tn)
        yeni_prims.append(dict(base=taban, z1=eski.get("z1", 0), NV=nv,
                               firstIdx=ilk_tri * 3, NT=nt, tip=eski.get("tip", 1),
                               el=el))
        olcumler.append(dict(i=i, NV_eski=eski["NV"], NT_eski=eski["NT"], NV=nv, NT=nt,
                             dejenere=dej, uv0=uv0_k, golgeleme=gol))
        taban += nv
        ilk_tri += nt
    NV = taban
    NT = ilk_tri
    pos_all = np.concatenate(P) if P else np.zeros((0, 3))

    # ------------------------------------------------------- konum olcegi + nicemleme
    if rigid:
        w_abs = float(np.abs(np.asarray(G["poz_w"], np.float64)).max()) if G["NV"] else 0.0
        if w_abs <= 0:
            raise YazmaHatasi("rigid position scale w is zero in the source mesh")
        # RIGID'DE OLCEK DOSYADADIR: konum = ham_s16 * w / 32768 ve w her vertexin KENDI
        # alanidir (VBstatic bayt 6..7, s16). Skinned us'un aksine burada tahmin yok --
        # w'yi buyutmek olcegi buyutur ve okuyucu ayni alandan geri okur (bayt kapisi
        # bunu 8/8 rigid silahta dogruluyor). Tavani: w <= 32767 -> erisim ~32,7 km.
        # Yine de OYUN ICI dogrulanmadigi icin buyutme yalniz olcek="serbest" ile yapilir.
        gerek_w = 0.0
        if NV:
            gerek_w = float(np.abs(pos_all).max()) * 32768.0 / float(S16_MAKS)
        if gerek_w > w_abs:
            # C2 POLITIKA: rigid olcek yukseltme.
            if olcek == "orijinal" and not UZ.kapi("olcek_yukselt"):
                raise YazmaHatasi(
                    "the edited geometry leaves this rigid mesh's position band: it is quantised "
                    "with w = %d (reach +/-%.4f m) and the new geometry reaches %.4f m. Unlike "
                    "skinned meshes, this scale IS stored in the file (a per-vertex s16 field), so "
                    "raising it is safe as far as our own reader/writer can prove - but it has not "
                    "been confirmed in game yet. Scale your edit back, or pass olcek='serbest' to "
                    "raise w to %d."
                    % (int(round(w_abs)), w_abs * S16_MAKS / 32768.0,
                       float(np.abs(pos_all).max()), int(np.ceil(gerek_w))))
            w_yeni = float(np.ceil(gerek_w))
            if w_yeni > S16_MAKS:
                # KAPASITE (uzman modu bunu ACMAZ): w bir s16 alandir, tavani yok edilemez.
                raise YazmaHatasi(
                    "positions do not fit even the largest rigid scale: w would have to be %d "
                    "(max %d, reach +/-%.1f m)"
                    % (int(w_yeni), S16_MAKS, S16_MAKS * S16_MAKS / 32768.0))
            if olcek == "orijinal":
                _uyar(uzman_uyarilari, "olcek_yukselt",
                      eski=int(round(w_abs)), yeni=int(w_yeni))
            w_abs = w_yeni
        q = pos_all * (32768.0 / w_abs)
        us = w_abs / 32768.0
        onerilen = None
    else:
        us = float(R["poz_olcek"])
        maks = float(np.abs(pos_all).max()) if NV else 0.0
        onerilen = max(1.0, float(np.ceil(maks - 1e-9)))
        if onerilen != us:
            # C1 POLITIKA: skinned konum bandi asimi.
            if olcek == "orijinal" and not UZ.kapi("olcek_bandi"):
                # us KANIT DURUMU (2026-09-04 yeniden olculdu):
                #  * 755 vanilla mesh'in TAMAMINDA us == ceil(maks|baslik kutusu|); kurali
                #    curutecek TEK bir mesh yok ve baslik kutusu gercek geometriyle
                #    0,00003 m icinde ortusuyor (yani kutu us'yi TASIYABILIR).
                #  * Kutunun 4. float bileseni (min[3]/max[3]) 755/755 mesh'te 0,0 -> olcek DEGIL.
                #  * "Oyun kutudan turetmiyor" diyen 3 m oyun-ici testi GECERSIZDIR: o test
                #    0x20AEBE2E.. Drake ailesine yazildi ve YARIM-BOY deneyi ayni ailede
                #    hicbir gorsel degisiklik uretmedi -- oyun o mesh'i hic okumuyor.
                #    Gecerli deney paketi hazir: scratchpad/yayin3d/kum/kilic_aile2_3m.
                # Kanitlanana kadar yazici olcegi KENDILIGINDEN degistirmez.
                raise YazmaHatasi(
                    "the edited geometry leaves this mesh's position band: the mesh is quantised at "
                    "scale %g m and the new geometry reaches %.4f m, which vanilla would store at "
                    "scale %g. Every one of 755 vanilla meshes follows 'scale = ceil(max header "
                    "box)', but no in-game test has confirmed yet that the engine derives it that "
                    "way, so changing it cannot be proven safe. Scale your edit back inside "
                    "+/-%g m, or pass olcek='serbest' to accept the risk."
                    % (us, maks, onerilen, us))
            if olcek == "orijinal":
                _uyar(uzman_uyarilari, "olcek_bandi", eski=us, yeni=onerilen)
            us = onerilen
        q = pos_all * (32768.0 / us)
    maks_ham = float(np.abs(q).max()) if NV else 0.0
    if maks_ham > S16_MAKS:
        raise YazmaHatasi(
            "positions do not fit the mesh quantisation range: |value| %.1f > %d "
            "(scale the model down by at least %.4fx, or headroom %.4fx is available)"
            % (maks_ham, S16_MAKS, maks_ham / S16_MAKS, S16_MAKS / maks_ham),
            dict(maks_ham=maks_ham, bosluk_kati=S16_MAKS / maks_ham if maks_ham else float("inf")))
    ham = np.round(q).astype("<i2")

    # ------------------------------------------------------- tamponlar
    posb = np.ascontiguousarray(ham).view(np.uint8).reshape(NV, 6)
    if rigid:
        # w PER-VERTEX'tir ama |w| mesh basina SABITTIR (846/846 olculdu); isareti yalnizca
        # konumu ters cevirir. Yeni vertexlerin isareti bilinmedigi icin TUMU +|w| yazilir ve
        # konumlar ona gore nicemlenir -- cozulen konum degismez (isaret ham s16'ya gecer).
        wi = int(round(w_abs))
        if not -32768 <= wi <= S16_MAKS:
            raise YazmaHatasi("rigid position scale w = %d does not fit s16" % wi)
        wb = np.full((NV, 1), wi, "<i2")
        wb = np.ascontiguousarray(wb).view(np.uint8).reshape(NV, 2)
        Nc = np.concatenate(NRM) if NRM else np.zeros((0, 3))
        Tc = np.concatenate(TAN) if TAN else np.zeros((0, 3))
        nb_ = np.clip(np.round((Nc + 1.0) * 127.0), 0, 255).astype(np.uint8)
        tb_ = np.clip(np.round((Tc + 1.0) * 127.0), 0, 255).astype(np.uint8)
        nwv = np.concatenate([x for x in NW]).astype(np.uint8).reshape(NV, 1)
        twv = np.concatenate([x for x in TW]).astype(np.uint8).reshape(NV, 1)
        par = [posb, wb, nb_, nwv, tb_, twv]
        if sS == 28:
            par.append(np.concatenate([np.asarray(x, np.uint8) for x in REN]).reshape(NV, 4))
        uvb = _s16_bayt(np.concatenate(UV0), 2048.0)
        if uvb is None:
            raise YazmaHatasi("UV values do not fit the s16/2048 texture-coordinate range")
        par.append(uvb)
        if sS == 28:
            uvb1 = _s16_bayt(np.concatenate(UV1), 2048.0)
            if uvb1 is None:
                raise YazmaHatasi("second UV set does not fit the s16/2048 range")
            par.append(uvb1)
        vb1 = np.concatenate(par, 1)
        if vb1.shape[1] != sS:
            raise YazmaHatasi("rebuilt rigid VBstatic stride %d != %d" % (vb1.shape[1], sS))
        tamponlar = [vb1.tobytes(), b"", b"", b""]
    else:
        renk = np.concatenate([np.asarray(x, np.uint8) for x in REN]).reshape(NV, 4)
        uvb = _s16_bayt(np.concatenate(UV0), 2048.0)
        if uvb is None:
            raise YazmaHatasi("UV values do not fit the s16/2048 texture-coordinate range")
        par = [renk, uvb]
        if sS >= 16:
            uvb1 = _s16_bayt(np.concatenate(UV1), 2048.0)
            if uvb1 is None:
                raise YazmaHatasi("second UV set does not fit the s16/2048 range")
            par += [uvb1, np.concatenate([np.asarray(x, np.uint8) for x in SON4]).reshape(NV, 4)]
        vb1 = np.concatenate(par, 1)
        if vb1.shape[1] != sS:
            raise YazmaHatasi("rebuilt VBstatic stride %d != %d" % (vb1.shape[1], sS))
        Nc = np.concatenate(NRM); Tc = np.concatenate(TAN)
        elc = np.concatenate([pr["el"] for pr in yeni_prims])
        nk, negN = MY.okt_kodla(Nc)
        tk, negT = MY.okt_kodla(Tc)
        bayrak = (negN.astype(np.uint8) | (negT.astype(np.uint8) << 1)
                  | (elc.astype(np.uint8) << 2))
        b7v = np.concatenate([np.asarray(x, np.uint8) for x in B7]).reshape(NV, 1)
        vb2 = np.concatenate([posb, bayrak.reshape(NV, 1), b7v, nk, tk], 1)
        if vb2.shape[1] != 12:
            raise YazmaHatasi("rebuilt VBdynamic stride %d != 12" % vb2.shape[1])
        kidx = np.concatenate(KIDX); agr = _u8_agirlik(np.concatenate(AGR))
        if bpk == 2:
            if kidx.size and int(kidx.max()) > 255:
                raise YazmaHatasi("bone index %d does not fit this mesh's 1-byte bone slots"
                                  % int(kidx.max()))
            idxb = kidx.astype(np.uint8)
        else:
            idxb = np.ascontiguousarray(kidx.astype("<u2")).view(np.uint8).reshape(NV, -1)
        vb3 = np.concatenate([idxb, agr], 1)
        if vb3.shape[1] != sW:
            raise YazmaHatasi("rebuilt VBidxWeight stride %d != %d" % (vb3.shape[1], sW))
        tamponlar = [vb1.tobytes(), vb2.tobytes(), np.ascontiguousarray(vb3).tobytes(), b""]
    # --- IndexBuffer: prim-YEREL u16, prim sirasiyla ardisik (kume dolgusu YOK)
    ib = np.zeros((NT, 3), "<u2")
    t0 = 0
    for tri in T:
        ib[t0:t0 + len(tri)] = tri.astype("<u2")
        t0 += len(tri)
    tamponlar.append(ib.tobytes())

    yeni = _kumesiz_kur(data, R, G, yeni_prims, tamponlar, pos_all, mid_esle)

    rapor = dict(
        mod="kumesiz", kaynak_kumesiz=kumesiz_kaynak, rigid=rigid, fmt=int(cmd["fmt"]),
        NV_eski=int(G["NV"]), NT_eski=int(G["NT"]), NV=int(NV), NT=int(NT),
        prim=len(yeni_prims), primler=[{k: v for k, v in o.items()} for o in olcumler],
        poz_olcek_eski=float(R["poz_olcek"]), poz_olcek=float(us if not rigid else R["poz_olcek"]),
        poz_olcek_onerilen=onerilen, olcek_modu=olcek,
        uzman_uyarilari=list(uzman_uyarilari),
        maks_ham=round(maks_ham, 1), bosluk_kati=(S16_MAKS / maks_ham) if maks_ham else float("inf"),
        bbox_min=[float(x) for x in pos_all.min(0)] if NV else None,
        bbox_max=[float(x) for x in pos_all.max(0)] if NV else None,
        B_eski=len(data), B=len(yeni), MID_prim_eslesme=mid_esle,
        dusen=dict(ClusteredMeshData=True, ClusterDesc=int(cmd["tampon"]["ClusterDesc"]["len"]),
                   ClusterBitMask=int(cmd["tampon"]["ClusterBitMask"]["len"]),
                   VBprecompute=int(cmd["tampon"]["VBprecompute"]["len"])),
        sha_eski=_sha(data)[:16], sha_yeni=_sha(yeni)[:16])
    return bytes(yeni), rapor


def _kumesiz_kur(data, R, G, yeni_prims, tamponlar, pos_all, mid_esle):
    """Yeni ic dosyayi diker: [gate_CMD'ye kadar orijinal] + gate 3 + gate_MPH +
    MeshData (yamali baslik + yeni prim dizisi) + 5 tampon + [orijinal kuyruk, MID.NV yamali].
    Baslik bbox'i ve sarmalayici boyutu da yamalanir."""
    md = R["MeshData"]
    cmd = R["CMD"]
    bb = R["baslik_bbox"]
    kumesiz = bool(R.get("kumesiz"))
    kes = (md["off"] - 2) if kumesiz else (cmd["off"] - 1)     # gate_CMD baytinin ofseti
    if kes <= 0 or kes >= len(data):
        raise YazmaHatasi("internal error: gate_CMD offset %d out of range" % kes)
    if not kumesiz and data[kes] != 0:
        raise YazmaHatasi("internal error: expected gate_CMD 0 at %d, found %d" % (kes, data[kes]))
    bas = bytearray(data[:kes])
    # --- baslik bbox: yeni geometrinin TAM kutusu (4. bilesen orijinalinde 0.0, oyle kalir)
    o = bb["off"]
    if len(pos_all):
        struct.pack_into("<3f", bas, o, *[float(x) for x in pos_all.min(0)])
        struct.pack_into("<3f", bas, o + 16, *[float(x) for x in pos_all.max(0)])
    bas += bytes([KUMESIZ_GATE])                                # gate_CMD = 3 -> CMD YOK
    bas += bytes([R.get("gate_MPH", 3)])                        # gate_MPH (3 = MPH yok)
    # --- MeshData nesne basligi + 14 baytlik baslik (yamali)
    mh = bytearray(data[md["off"]:md["prim_sayi_off"]])         # 12 + 14 B
    mh[12 + 5] = 0                                              # stride[3] = 0 (VBprecompute duser)
    mh[12 + 7] = 0; mh[12 + 8] = 0; mh[12 + 9] = 0              # b7/b8/b9 = 0  (330/330: <=> sP==0)
    struct.pack_into("<I", mh, 12 + 10, 0)                      # u32_10 = 0    (66/66 sP==0 mesh'te 0)
    gv = bytearray(mh)
    gv += struct.pack("<i", len(yeni_prims))
    for i, pr in enumerate(yeni_prims):
        gv += data[md["prim_dizi_off"] + 36 * i: md["prim_dizi_off"] + 36 * i + 12]   # nesne basligi
        gv += struct.pack("<6I", pr["base"], pr["z1"], pr["NV"], pr["firstIdx"], pr["NT"], pr["tip"])
    for b in tamponlar:
        gv += struct.pack("<I", len(b)) + b
    # --- kuyruk: MeshInstancingData'nin NV'leri disinda BIREBIR
    kuyruk = bytearray(data[md["kuyruk_off"]:])
    for j, m in enumerate(md["MeshInstancingData"]):
        struct.pack_into("<H", kuyruk, m["off"] - md["kuyruk_off"] + 5,
                         int(yeni_prims[mid_esle[j]]["NV"]))
    yeni = bytearray(bytes(bas) + bytes(gv) + bytes(kuyruk))
    adLen = int(R["sarmalayici"]["adLen"])
    struct.pack_into("<I", yeni, 4, len(yeni) - 13 - adLen)     # sarmalayici boyutu
    return bytes(yeni)


def kumesiz_yeniden_uret(data, R, G):
    """BICIM KAPISI: kume-siz bir ic dosyayi KENDI cozumumuzden yeniden dizer ve bayt-birebir
    olmalidir. Vertex tamponlari cozulup yeniden KODLANMAZ (o is `mesh_yapisal.bayt_kapisi`nin
    kapsamindadir ve 4/4 kume-siz dosyada 7/7 tamponu birebir kuruyor); burada olculen sey
    KAPTIR: gate_CMD/gate_MPH konumu, MeshData basligi, prim kaydi, 5 tamponun uzunluk
    onekli zinciri, kuyruk ve sarmalayici boyutu. Ikisi birlikte dosyanin TAMAMINI kapsar."""
    if not R.get("kumesiz"):
        raise YazmaHatasi("kumesiz_yeniden_uret expects a cluster-free mesh")
    md = R["MeshData"]
    tamponlar = [bytes(data[md["md_tampon"][nm]["off"]:
                            md["md_tampon"][nm]["off"] + md["md_tampon"][nm]["len"]])
                 for nm in MY.MD_TAMPONLAR]
    prims = [dict(base=p["base"], z1=p["z1"], NV=p["NV"], firstIdx=p["firstIdx"],
                  NT=p["NT"], tip=p["tip"]) for p in md["prims"]]
    esle, hata = _mid_prim_esle(R, G)
    if esle is None:
        esle = [min(j, len(prims) - 1) for j in range(len(md["MeshInstancingData"]))]
    yeni = _kumesiz_kur(data, R, G, prims, tamponlar, np.zeros((0, 3)), esle)
    return yeni


def dene_serbest(data, R, G, primler, **kw):
    """`yaz_serbest` ile ayni ama reddetmede firlatmaz -> (bytes|None, rapor)."""
    try:
        return yaz_serbest(data, R, G, primler, **kw)
    except YazmaHatasi as e:
        return None, dict(red=str(e), ayrinti=e.ayrinti)
