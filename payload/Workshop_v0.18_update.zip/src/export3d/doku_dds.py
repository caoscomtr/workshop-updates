# -*- coding: utf-8 -*-
"""export3d.doku_dds -- oyunun BC bloklarini OLDUGU GIBI .dds olarak okur/yazar.

Neden ayri modul: `doku_png` level-0'i COZER (BC -> RGBA) ve rol donusumleri uygular;
geri yol ise PNG -> TexEncode -> DDS'tir, yani her tur donusunde bir kez daha
sikistirma kaybi eklenir. Bu modul ARADAKI ADIMLARI HIC ATMAZ: forge'daki bloklar
ne ise .dds icine o baytlar yazilir, ayni dosya geri verilince yeniden kodlama
YAPILMAZ (dogrudan yol). Kayipsiz tur donusu = D3 kapisi.

Uc kaynak birlestirilir (hepsi olculmus, bkz. doku_png "LEVEL-0 KURTARMA YOLLARI"):
  * HARICI mip'ler: `doku_png.harici_mip_id` (onek 0x8) ile TOC girisleri, SIK (pitch yok)
  * GOMULU havuz : tanimin ic dosyasinin sonundaki `[u32 uzunluk][piksel]` blogu,
                   256 B satir hizasi + seviye basina 512 B yuvarlama (`doku_png._yerlesim`)
  * TANIM        : `doku_enjekte2.tanim_oku` (W/H/fmt/srgb/mipcount)

YAZICI YOK: bu modul forge'a TEK BAYT yazmaz. Yazma her zaman doku_enjekte2'dendir
(TEK YAZICI kurali). Burasi yalniz .dds uretir/ayristirir ve `uyumlu_mu` ile
"bu dosya dogrudan yazilabilir mi" sorusunu yanitlar.

DDS bicimi: DAIMA DX10 basligi (veri 148. bayttan baslar). Sebep: eski FourCC
(DXT1/DXT5) sRGB'yi TASIMAZ; DX10'un dxgi alani tasir ve `doku_enjekte2.dds_mipler`
her ikisini de okur. Okuma tarafi ikisini de kabul eder (topluluk dosyalari).
"""

import os
import struct

import outfit_core as C
import doku_enjekte2 as DE

try:
    from . import doku_png as DP
except ImportError:                                   # modul dosya yolundan yuklendiyse
    import doku_png as DP

__all__ = ["mip_zinciri", "dds_yaz", "dds_oku", "uyumlu_mu", "dds_rgba",
           "DESTEKLI_AILE", "SURUM"]

SURUM = "1.0"

# TexEncode + doku_enjekte2'nin birlikte yazabildigi aileler (doku_ithal.DESTEKLI_AILE)
DESTEKLI_AILE = ("BC1", "BC3", "BC7")

# aile + srgb -> dxgi (DE.DXGI'nin TERSI; yalnizca yazabildigimiz uc aile)
AILE_DXGI = {("BC1", 0): 71, ("BC1", 1): 72,
             ("BC3", 0): 77, ("BC3", 1): 78,
             ("BC7", 0): 98, ("BC7", 1): 99}
# aile -> imagecodecs bcn kodu (C._bc_decode_rgba fmt_enum bekliyor; ondan once cevir)
AILE_ENUM = {"BC1": 0x02, "BC3": 0x05, "BC7": 0x0A}

DDS_SIHIR = b"DDS "
DDS_VERI_DX10 = 148
DDS_VERI_ESKI = 128
# dwFlags: CAPS|HEIGHT|WIDTH|PIXELFORMAT|MIPMAPCOUNT|LINEARSIZE
DDSD_BAYRAK = 0x000A1007
DDSCAPS = 0x00401008                                  # TEXTURE|MIPMAP|COMPLEX
DDPF_FOURCC = 0x4
DDSCAPS2_CUBEMAP = 0x200
DDSCAPS2_VOLUME = 0x200000


# ------------------------------------------------------------------ yardimcilar
def _boyut(W, H, lvl):
    return max(1, W >> lvl), max(1, H >> lvl)


def _blok_bayt(w, h, blok):
    return max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * blok


def _seviye_sayisi(W, H):
    """1x1'e kadar tam zincirin seviye sayisi."""
    n, w, h = 1, max(1, W), max(1, H)
    while w > 1 or h > 1:
        w, h = max(1, w // 2), max(1, h // 2)
        n += 1
    return n


def _havuz_yerlesim(W, H, blok, ilk_lvl, uzunluk):
    """gomulu havuzun yerlesimi, seviye numaralari MUTLAK.

    `doku_png._yerlesim` her zaman level 0'dan baslar; havuz ise harici mip'lerden
    SONRAKI seviyeyle baslar (doku_enjekte2.yerlesim'in `ilk_lvl` parametresi).
    Gercek H ve 512 yuvarlamasi doku_png'nin olculmus kuralidir."""
    w, h = _boyut(W, H, ilk_lvl)
    return [(lvl + ilk_lvl, off, pitch, satir, rb)
            for (lvl, off, pitch, satir, rb) in DP._yerlesim(w, h, blok, uzunluk)]


def _de_pad(res, taban, pitch, satir, rb):
    """256 B hizali satirlardan SIK blok verisi (pitch kirpilir)."""
    out = bytearray()
    for r in range(satir):
        out += res[taban + r * pitch: taban + r * pitch + rb]
    return bytes(out)


# ------------------------------------------------------------------ MIP ZINCIRI
def mip_zinciri(kap, tm):
    """Bir slotun TUM mip seviyeleri (harici TOC girisleri + gomulu havuz).

    Doner:
      {kap, kap_tm, doku_id, W, H, aile, srgb, fmt_enum, mipcount, blok,
       seviyeler: [{lvl, w, h, veri, kaynak, rid, off, forge_len, pitch}],
       havuz: {piksel_bas, uzunluk, ilk_lvl, yer}|None,
       eksik: [{lvl, sebep}], hdr: int}
    `veri` DAIMA SIK'tir (bw*bh*blok) -- gomulu seviyelerin satir dolgusu kirpilir.
    Hicbir seviye UYDURULMAZ: bulunamayan seviye `eksik` listesine yazilir."""
    hdr, tex, tanim, res, tms = C._slot_tanim(kap, tm)
    DP.aile_coz(tanim)                 # olculmus ek enum (0x06 -> BC1); yazici bunu hala tanimaz
    W, H = int(tanim["W"]), int(tanim["H"])
    aile, blok = tanim["aile"], tanim["blok"]
    z = {"kap": "0x%X" % DP._mat_int(kap), "kap_tm": int(tm),
         "doku_id": "0x%X" % tex, "doku_id_sayi": tex,
         "W": W, "H": H, "aile": aile, "blok": blok,
         "srgb": int(bool(tanim.get("srgb"))), "fmt_enum": int(tanim["fmt_enum"]),
         "mipcount": int(tanim.get("mipcount") or 0), "hdr": int(hdr),
         "seviyeler": [], "havuz": None, "eksik": []}
    if aile is None or not blok:
        z["eksik"].append({"lvl": 0, "sebep": "unknown texture format enum 0x%02X"
                                              % tanim["fmt_enum"]})
        return z

    # --- 1) HARICI mip'ler: level 0'dan baslayarak KESINTISIZ oldugu surece
    lf = C._forge()
    tam = _seviye_sayisi(W, H)
    ust = max(1, min(z["mipcount"] or tam, tam))
    for lvl in range(ust):
        rid = DP.harici_mip_id(tex, lvl)
        if rid not in lf.by_id:
            break
        off, ln, _ext = lf.by_id[rid]
        w, h = _boyut(W, H, lvl)
        gerek = _blok_bayt(w, h, blok)
        if ln < gerek:
            z["eksik"].append({"lvl": lvl, "sebep":
                               "external mip %d holds %d bytes, %d are needed"
                               % (lvl, ln, gerek)})
            break
        lf.f.seek(off)
        z["seviyeler"].append({"lvl": lvl, "w": w, "h": h, "veri": lf.f.read(ln)[:gerek],
                               "kaynak": "external", "rid": rid, "off": int(off),
                               "forge_len": int(ln), "pitch": None})
    ilk_lvl = len(z["seviyeler"])

    # --- 2) GOMULU havuz (K1 sinirli cipa; doku_png._gomulu_mip0_k1 ile AYNI kural)
    son = None
    try:
        for _icid, b, s in DP._ic_sinirlar(DP._mat_int(kap)):
            if b <= hdr < s:
                son = s
                break
    except Exception:                                       # noqa: BLE001
        son = None
    cipa = None
    if son is not None:
        cipa = DP._cipa_bul(res, hdr, son)
    if cipa is None:
        # yedek: eski (yaklasik) sinir -- bir sonraki TM basligina kadar
        son2 = tms[tm + 1][0] if tm + 1 < len(tms) else len(res)
        cipa = DE.cipa_bul(res, hdr + 14, son2)
    if cipa:
        _q, piksel_bas, uzunluk = cipa
        yer = _havuz_yerlesim(W, H, blok, ilk_lvl, uzunluk)
        z["havuz"] = {"piksel_bas": int(piksel_bas), "uzunluk": int(uzunluk),
                      "ilk_lvl": ilk_lvl, "yer": yer}
        for (lvl, roff, pitch, satir, rb) in yer:
            w, h = _boyut(W, H, lvl)
            taban = piksel_bas + roff
            veri = _de_pad(res, taban, pitch, satir, rb)
            if len(veri) < _blok_bayt(w, h, blok):
                z["eksik"].append({"lvl": lvl, "sebep":
                                   "embedded level %d is cut short in the pool" % lvl})
                break
            z["seviyeler"].append({"lvl": lvl, "w": w, "h": h, "veri": veri,
                                   "kaynak": "embedded", "rid": None,
                                   "off": int(taban), "forge_len": None,
                                   "pitch": int(pitch)})

    # --- 3) eksik seviyeler ACIKCA soylenir (uydurulmaz)
    var = set(s["lvl"] for s in z["seviyeler"])
    for lvl in range(tam):
        if lvl not in var and not any(e["lvl"] == lvl for e in z["eksik"]):
            z["eksik"].append({"lvl": lvl, "sebep":
                               "level %d is in neither the archive's mip entries nor the "
                               "embedded pool" % lvl})
    z["eksik"].sort(key=lambda e: e["lvl"])
    return z


# ------------------------------------------------------------------ DDS YAZICI
def dds_yaz(yol, zincir):
    """Zincirdeki seviyeleri DX10 baslikli .dds olarak yazar. Doner: yol.

    Seviyeler level 0'dan KESINTISIZ olmak zorundadir (DDS bicimi baska turlusunu
    tasiyamaz); zincirde bosluk varsa ValueError. Baytlar OLDUGU GIBI yazilir."""
    sev = sorted([s for s in zincir["seviyeler"]], key=lambda s: s["lvl"])
    if not sev or sev[0]["lvl"] != 0:
        raise ValueError("level 0 is missing, so this texture cannot be written as a DDS file")
    for i, s in enumerate(sev):
        if s["lvl"] != i:
            raise ValueError("the mip chain has a gap at level %d, so it cannot be written "
                             "as a DDS file" % i)
    aile, srgb = zincir["aile"], int(bool(zincir["srgb"]))
    dxgi = AILE_DXGI.get((aile, srgb))
    if dxgi is None:
        raise ValueError("the game stores this texture as %s; DDS export writes BC1, BC3 "
                         "and BC7 only" % (aile or "an unknown format"))
    W, H = int(zincir["W"]), int(zincir["H"])
    basli = bytearray()
    basli += DDS_SIHIR
    basli += struct.pack("<7I", 124, DDSD_BAYRAK, H, W, len(sev[0]["veri"]), 0, len(sev))
    basli += b"\x00" * 44                                  # dwReserved1[11]
    basli += struct.pack("<2I", 32, DDPF_FOURCC) + b"DX10" + b"\x00" * 20
    basli += struct.pack("<5I", DDSCAPS, 0, 0, 0, 0)
    basli += struct.pack("<5I", dxgi, 3, 0, 1, 0)          # DX10: dim=TEXTURE2D, arraySize 1
    assert len(basli) == DDS_VERI_DX10, "DDS basligi %d bayt oldu" % len(basli)
    with open(yol, "wb") as f:
        f.write(bytes(basli))
        for s in sev:
            f.write(s["veri"])
    return yol


# ------------------------------------------------------------------ DDS OKUYUCU
def dds_oku(yol):
    """.dds -> {ok, sebep, W, H, dxgi, aile, srgb, blok, baslik, seviyeler:[{lvl,w,h,veri}]}

    Sebep DONDURULUR (exception degil): cagiran onu kullaniciya kelimesi kelimesine
    gosterir. Kupharita / hacim dokusu / BC2-BC4-BC5-BC6H / sikistirilmamis dosyalar
    ACIKCA reddedilir -- tahmin YOK."""
    r = {"ok": False, "sebep": None, "yol": yol, "seviyeler": [], "baslik": None,
         "W": 0, "H": 0, "dxgi": 0, "aile": None, "srgb": 0, "blok": 0}
    try:
        with open(yol, "rb") as f:
            d = f.read()
    except OSError as e:
        r["sebep"] = "the file could not be read (%s)" % e
        return r
    if len(d) < DDS_VERI_ESKI or d[:4] != DDS_SIHIR:
        r["sebep"] = "this is not a DDS file (the DDS marker is missing)"
        return r
    H = struct.unpack_from("<I", d, 12)[0]
    W = struct.unpack_from("<I", d, 16)[0]
    mip = struct.unpack_from("<I", d, 28)[0]
    caps2 = struct.unpack_from("<I", d, 112)[0]
    fc = d[84:88]
    if fc == b"DX10":
        if len(d) < DDS_VERI_DX10:
            r["sebep"] = "this DDS file stops before its DX10 header ends"
            return r
        dxgi = struct.unpack_from("<I", d, 128)[0]
        boyut = struct.unpack_from("<I", d, 132)[0]
        veri = DDS_VERI_DX10
        r["baslik"] = "dx10"
        if boyut == 4:
            r["sebep"] = "this is a 3D (volume) texture; the game stores flat textures only"
            return r
    else:
        dxgi = {b"DXT1": 71, b"DXT2": 74, b"DXT3": 74, b"DXT4": 77, b"DXT5": 77}.get(fc, 0)
        veri = DDS_VERI_ESKI
        r["baslik"] = "fourcc"
        if not dxgi:
            ad = fc.decode("latin1").strip("\x00") or "uncompressed"
            r["sebep"] = ("this DDS file is %s; the game stores BC1, BC3 and BC7 textures "
                          "only" % ad)
            return r
    if caps2 & DDSCAPS2_CUBEMAP:
        r["sebep"] = "this is a cube map; the game stores flat textures only"
        return r
    if caps2 & DDSCAPS2_VOLUME and r["baslik"] == "fourcc":
        r["sebep"] = "this is a 3D (volume) texture; the game stores flat textures only"
        return r
    if dxgi not in DE.DXGI:
        r["sebep"] = "this DDS file uses an unknown texture format (DXGI=%d)" % dxgi
        return r
    blok, srgb, aile = DE.DXGI[dxgi]
    r.update({"W": int(W), "H": int(H), "dxgi": int(dxgi), "aile": aile,
              "srgb": int(srgb), "blok": int(blok), "mipcount_baslik": int(mip)})
    if aile not in DESTEKLI_AILE:
        r["sebep"] = ("this DDS file is %s; the game stores BC1, BC3 and BC7 textures only"
                      % DE.DXGI_AD.get(dxgi, aile))
        return r
    if not W or not H:
        r["sebep"] = "this DDS file says its size is %dx%d" % (W, H)
        return r
    off, w, h, lvl = veri, int(W), int(H), 0
    while off < len(d):
        n = _blok_bayt(w, h, blok)
        if off + n > len(d):
            break
        r["seviyeler"].append({"lvl": lvl, "w": w, "h": h, "veri": d[off:off + n]})
        off += n
        if w == 1 and h == 1:
            break
        w, h, lvl = max(1, w // 2), max(1, h // 2), lvl + 1
    if not r["seviyeler"]:
        r["sebep"] = ("this DDS file holds no pixel data for a %dx%d %s texture"
                      % (W, H, aile))
        return r
    r["ok"] = True
    return r


def dds_rgba(dds, lvl=0):
    """DDS seviyesini RGBA diziye acar (yeniden kodlama yolu + onizleme icin)."""
    sev = next((s for s in dds["seviyeler"] if s["lvl"] == int(lvl)), None)
    if sev is None:
        raise ValueError("this DDS file has no level %d" % lvl)
    return C._bc_decode_rgba(sev["veri"], sev["w"], sev["h"], AILE_ENUM[dds["aile"]])


# ------------------------------------------------------------------ UYUMLULUK KAPISI
def uyumlu_mu(dds, tanim, zincir=None):
    """(rota, sebep) -- rota: 'dogrudan' | 'yeniden_kodla' | 'red'.

    'dogrudan' = yeniden kodlama YOK, dosyanin baytlari oldugu gibi yazilir. Kosullar
    doku_enjekte2.plan'in KAPILARIYLA ayni olmak zorunda (aksi halde kullaniciya
    "yazilacak" denip yazicinin 'size gate ... file=None' mesajina dusulur):
      KAPI 2 boyut, KAPI 3 aile + sRGB, KAPI 4 her HARICI mip'in uzunlugu.
    'red' yalniz slotun kendisi yazilamazsa (aile BC1/BC3/BC7 disi) verilir --
    boyut/bicim uyusmazligi red degil, yeniden kodlama sebebidir."""
    if not dds.get("ok"):
        return "red", dds.get("sebep") or "this DDS file could not be read"
    t_aile = tanim.get("aile")
    if t_aile not in DESTEKLI_AILE:
        return "red", ("the game stores this texture slot as %s; the Workshop writes BC1, "
                       "BC3 and BC7 only" % (t_aile or "an unknown format"))
    W, H = int(tanim["W"]), int(tanim["H"])
    t_srgb = int(bool(tanim.get("srgb")))
    if (dds["W"], dds["H"]) != (W, H):
        return "yeniden_kodla", ("the file is %dx%d but this slot is %dx%d, so it will be "
                                 "resized and re-encoded"
                                 % (dds["W"], dds["H"], W, H))
    if dds["aile"] != t_aile:
        return "yeniden_kodla", ("the file is %s but this slot is %s, so it will be "
                                 "re-encoded" % (dds["aile"], t_aile))
    if dds["srgb"] != t_srgb and dds["baslik"] == "dx10":
        return "yeniden_kodla", ("the file is %s but this slot is %s, so it will be "
                                 "re-encoded"
                                 % (DE.DXGI_AD.get(dds["dxgi"], dds["aile"]),
                                    t_aile + ("_sRGB" if t_srgb else " (linear)")))
    # eski FourCC baslikta sRGB YOKTUR (DXT1/DXT5 tasimaz) -> slotun bayragi gecerlidir.
    # DIKKAT: yazicinin KAPI 3'u dosyanin DXGI'sini okur ve FourCC'yi LINEAR sayar.
    # Bu yuzden 'dogrudan' rotasini alan cagiran (outfit_core._design_dds_uygula)
    # dosyayi OLDUGU GIBI kopyalayamaz: BLOKLARI aynen tutup basligi slotun
    # DXGI'siyle yeniden yazar (dds_yaz). Olculdu 2026-09-09: EDWARD_ROBES_EDIT'in
    # dort DXT1 dosyasi da "colour space mismatch" ile reddediliyordu.
    if zincir is None:
        return "dogrudan", "the file matches this slot exactly"
    dmap = dict((s["lvl"], s) for s in dds["seviyeler"])
    for s in zincir["seviyeler"]:
        if s["kaynak"] != "external":
            continue
        d = dmap.get(s["lvl"])
        if d is None:
            return "yeniden_kodla", ("the file has %d mip level(s) but this slot needs at "
                                     "least %d, so the whole chain will be rebuilt"
                                     % (len(dds["seviyeler"]), s["lvl"] + 1))
        if len(d["veri"]) != int(s["forge_len"]):
            return "yeniden_kodla", ("mip level %d is %d bytes in the file but the archive "
                                     "reserves %d, so the chain will be rebuilt"
                                     % (s["lvl"], len(d["veri"]), s["forge_len"]))
    return "dogrudan", "the file matches this slot exactly"


def yazilmayan_seviyeler(zincir, dds=None):
    """Dogrudan yolda YAZILMAYACAK seviyeler (kullaniciya NOTE olarak soylenir).

    IKI ayrisma olculdu ve ikisi de SESSIZ:
      (a) HARICI mip kimligi: yazici oneki 0xA (`plan` :588), okuyucu 0x8
          (`doku_png.MIP_ID_ONEK`). Bit 41'i BOS olan doku kimliklerinde (0x1F.. gibi)
          yazici girisi BULAMAZ, o seviyeyi atlar ve yine de "yazildi" der.
      (b) GOMULU yerlesim: yazici KARE varsayar ve 512 yuvarlamasi yapmaz
          (`yerlesim` :508-521); gercek kural `doku_png._yerlesim`tir. Ayrisan
          seviyeyi yazici ya yanlis yere koyar ya da (kare olmayan dokuda
          `len(src) < rb*satir` oldugu icin) HIC yazmaz.
    Bu fonksiyon ikisini de OLCER. Level 0 listede cikarsa cagiran REDDETMELIDIR."""
    out = []
    lf = C._forge()
    yz_base = (0xA0000000000 | int(zincir["doku_id_sayi"])) << 20
    for s in zincir["seviyeler"]:
        if s["kaynak"] != "external":
            continue
        if (yz_base | s["lvl"]) not in lf.by_id:
            out.append({"lvl": s["lvl"], "w": s["w"], "h": s["h"],
                        "sebep": "the writer looks for this mip level under a different "
                                 "id and does not find it"})
    h = zincir.get("havuz")
    if not h:
        return out
    W, H, blok = zincir["W"], zincir["H"], zincir["blok"]
    de_yer, _tot = DE.yerlesim(W, blok, h["ilk_lvl"], h["uzunluk"], H)
    de_map = dict((lvl, (roff, pitch, satir, rb)) for lvl, roff, pitch, satir, rb in de_yer)
    for (lvl, roff, pitch, satir, rb) in h["yer"]:
        d = de_map.get(lvl)
        w, hh = _boyut(W, H, lvl)
        if d is None:
            out.append({"lvl": lvl, "w": w, "h": hh,
                        "sebep": "the writer's layout has no room for this level"})
            continue
        if d != (roff, pitch, satir, rb):
            gerek = _blok_bayt(w, hh, blok)
            if gerek < d[3] * d[2]:
                out.append({"lvl": lvl, "w": w, "h": hh,
                            "sebep": "the writer expects more rows than this level has, so "
                                     "it is skipped"})
            else:
                out.append({"lvl": lvl, "w": w, "h": hh,
                            "sebep": "the writer places this level %d bytes away from where "
                                     "the game reads it" % abs(d[0] - roff)})
    return out
