# -*- coding: utf-8 -*-
"""materyal_yonlendir -- bir mesh'in MATERYAL referanslarini baska bir materyale cevirir.

NEDEN: capraz ice aktarmada (A silahinin sekli B silahinin yuvasina) yalniz geometri tasinirsa
B'nin dokusu A'nin UV'sine oturmaz, silah yamali gorunur. A'nin materyali (doku seti) zaten
arsivde; B'nin referanslarini A'ya cevirmek dokuyu bedavaya getirir.

OLCUM (2026-09-05, canli DataPC_boot.forge, 3 kilic + 1 tunik, salt okuma): materyal ID'si
UC yerde durur, baska yerde YOK (hizasiz taramayla dogrulandi):
  (a) LODSelector (0x51DC6B80) ic dosyasi, her dolu bandin B kaydi (0x38B0D64C):
      [u8 00][u64 mesh][u16][f32 mesafe][u32 N][N x ([u8 01][u64 MATERYAL])][kuyruk]
      N = mesh'in primitif sayisi (Tunic_X_Inner: 5, 168 B kayit; kilic: 1, 40 B).
  (b) Mesh ic dosyasi, MeshInstancingData[i] (0x0B1D34C1), primitif basina u64.
  (c) Mesh ic dosyasi, 0xCBA43E05 kuyruk nesnesi, [u32 n] + n x [u8 01][u64] (prim sirasi).
Kiyafet parcalarinin 8/9'unda LODSelector B kayitlari BOS (yalniz vekil kayitlari) -> motor
materyali en azindan kiyafetlerde mesh'in kendi MID'inden okuyor. Hangi yeri okudugu kesin
bilinmedigi icin UCU BIRDEN degistirilir.

Materyal govdelerinde iskelet/kemik referansi YOK (olculdu): skinning mesh'te kalir.
OYUNDA HENUZ DENENMEDI -- kanit bayt duzeyi + kendi okuyucularimiz.

HEDEF MATERYAL ID'SI UST DUZEY TOC GIRISI OLMALI (2026-09-05, mesh_ithal "CAPRAZ MATERYAL
KAPISI"): bu modul verilen id'yi sorgusuz yazar; dogrulama cagiranin isidir. Vanilla'da
LODSelector B kayitlarinin 2.959/2.959'u ve mesh MID/CBA'nin 384/464'u ust duzey giris, kalan
80'i mesh'in KENDI girisindeki ic materyal; baska girise gomulu materyale referans 0. Kaynak
girisine gomulu materyal (CHR_W_Sword 0x730D46174, trinket 0x22D695576ED) bu yuzden
mesh_ithal._materyal_dogrula'da (lf.by_id) durdurulur, buraya gelmez.
"""
import struct

try:
    from . import forge_giris as FG
    from . import mesh_yapisal as MY
except ImportError:                                   # modul dosya yolundan yuklendiyse
    import forge_giris as FG
    import mesh_yapisal as MY

__all__ = ["mesh_materyal_yerleri", "lodsel_materyal_yerleri", "mesh_ic_yonlendir",
           "lodsel_yonlendir", "prim_materyalleri"]

T_BANT_ANA = 0x38B0D64C
T_BANT_GOLGE = 0xA360319A


def _int(v):
    return v if isinstance(v, int) else int(str(v), 16)


def mesh_materyal_yerleri(data, rigid=True):
    """Mesh ic dosyasi -> [{yer, prim, materyal, ofset}] (MID + CBA43E05 listesi)."""
    R, _G = MY.oku(data, rigid=rigid)
    md = R["MeshData"]
    out = []
    for m in md.get("MeshInstancingData") or []:
        out.append({"yer": "MeshInstancingData", "prim": int(m["prim"]),
                    "materyal": _int(m["material"]), "ofset": int(m["off"]) + 10})
    cba = md.get("CBA43E05")
    if cba and cba.get("off") is not None:
        p = int(cba["off"]) + 12 + 13
        if p + 4 <= len(data):
            n = struct.unpack_from("<I", data, p)[0]
            p += 4
            for i in range(n):
                if p + 9 > len(data):
                    break
                out.append({"yer": "CBA43E05", "prim": i,
                            "materyal": struct.unpack_from("<Q", data, p + 1)[0], "ofset": p + 1})
                p += 9
    return out


def prim_materyalleri(data, rigid=True):
    """Mesh'in primitif basina materyali (MID'den; yoksa CBA'dan): {prim: materyal_int}."""
    out = {}
    for y in mesh_materyal_yerleri(data, rigid=rigid):
        if y["yer"] == "MeshInstancingData":
            out[y["prim"]] = y["materyal"]
    if not out:
        for y in mesh_materyal_yerleri(data, rigid=rigid):
            out.setdefault(y["prim"], y["materyal"])
    return out


def mesh_ic_yonlendir(data, prim2mat, rigid=True):
    """Mesh ic dosyasinda MID + CBA materyal u64'lerini `prim2mat` {prim: yeni_id} ile degistirir.
    Doner (yeni_bytes, degisiklikler[{yer, prim, eski, yeni, ofset}]). Uzunluk sabit."""
    b = bytearray(data)
    degisen = []
    for y in mesh_materyal_yerleri(data, rigid=rigid):
        yeni = prim2mat.get(y["prim"])
        if yeni is None or _int(yeni) == y["materyal"]:
            continue
        o = y["ofset"]
        if struct.unpack_from("<Q", b, o)[0] != y["materyal"]:
            raise ValueError("material id at offset %d does not match the reader (%s)" % (o, y["yer"]))
        struct.pack_into("<Q", b, o, _int(yeni))
        degisen.append({"yer": y["yer"], "prim": y["prim"], "eski": y["materyal"],
                        "yeni": _int(yeni), "ofset": o})
    yeni_b = bytes(b)
    # oz-denetim: ayni okuyucu yeni id'leri goruyor mu
    if degisen:
        gor = {(y["yer"], y["prim"]): y["materyal"] for y in mesh_materyal_yerleri(yeni_b, rigid=rigid)}
        for d in degisen:
            if gor.get((d["yer"], d["prim"])) != d["yeni"]:
                raise ValueError("self-check failed: %s prim %d" % (d["yer"], d["prim"]))
    return yeni_b, degisen


def lodsel_materyal_yerleri(gov):
    """LODSelector ic dosyasi -> [{bant, prim, mesh, materyal, ofset}] (DOLU B kayitlari)."""
    try:
        from . import cozum as CZ
    except ImportError:
        import cozum as CZ
    w = FG.sarmalayici_coz(gov)
    g0 = w["govde_off"]
    b = gov[g0:]
    ns = CZ._nesneler(b)
    out, bant = [], -1
    for k, (off, _idx, tip) in enumerate(ns):
        son = ns[k + 1][0] if k + 1 < len(ns) else len(b)
        pay = b[off + 12:son]
        if tip == T_BANT_GOLGE:
            bant += 1
        elif tip == T_BANT_ANA and len(pay) >= 40:
            mesh = struct.unpack_from("<Q", pay, 1)[0]
            n = struct.unpack_from("<I", pay, 15)[0]
            if not mesh or not (1 <= n <= 256) or 19 + 9 * n > len(pay):
                continue
            for i in range(n):
                p = 19 + 9 * i
                if pay[p] != 1:
                    continue
                mat = struct.unpack_from("<Q", pay, p + 1)[0]
                if mat:
                    out.append({"bant": bant, "prim": i, "mesh": mesh, "materyal": mat,
                                "ofset": g0 + off + 12 + p + 1})
    return out


def lodsel_yonlendir(gov, mesh_id, prim2mat):
    """LODSelector ic dosyasinda YALNIZ `mesh_id`li B kayitlarinin materyallerini degistirir.
    Capraz aktarimda yeniden yazilan HER ana bant mesh'i (bant 0 + bant 1; bkz. mesh_ithal
    basligi "LOD BANTLARI") icin ayri cagrilir, mesh_ithal._lodsel_isleri ayni LODSelector'a
    giden cagrilari tek ise toplar; dokunulmayan proxy bantlarin A kaydinda materyal yoktur.
    (2026-09-05'e kadar yalniz LOD0 cagriliyordu: B[band 1] hedefin dokusunda kaliyordu.)
    Doner (yeni_bytes, degisiklikler)."""
    b = bytearray(gov)
    degisen = []
    for y in lodsel_materyal_yerleri(gov):
        if y["mesh"] != _int(mesh_id):
            continue
        yeni = prim2mat.get(y["prim"])
        if yeni is None or _int(yeni) == y["materyal"]:
            continue
        struct.pack_into("<Q", b, y["ofset"], _int(yeni))
        degisen.append({"yer": "LODSelector.B[band %d]" % y["bant"], "prim": y["prim"],
                        "eski": y["materyal"], "yeni": _int(yeni), "ofset": y["ofset"]})
    yeni_b = bytes(b)
    if degisen:
        gor = {(y["bant"], y["prim"]): y["materyal"] for y in lodsel_materyal_yerleri(yeni_b)
               if y["mesh"] == _int(mesh_id)}
        for d in degisen:
            bant = int(d["yer"].split("band ")[1].rstrip("]"))
            if gor.get((bant, d["prim"])) != d["yeni"]:
                raise ValueError("self-check failed: band %d prim %d" % (bant, d["prim"]))
    return yeni_b, degisen
