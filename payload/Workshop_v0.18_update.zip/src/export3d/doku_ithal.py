# -*- coding: utf-8 -*-
"""doku_ithal — 3D export klasorunde BOYANMIS PNG'leri oyuna geri yazar (ITHALAT, doku tarafi).

Bu modul YENI BIR YAZICI DEGILDIR. Kiyafet APPLY hattinin AYNI son iki adimini kullanir:
    PNG -> (alfa politikasi) -> tools\\TexEncode.exe -> DDS -> doku_enjekte2.uygula
`doku_enjekte2` tek yazicidir; boyut/format/sRGB/ayrilmis-uzunluk kapilari, catisma
korumalari ve GERI ALMA KAYDI (KAYIT -> `gerial` / "Revert all") orada zaten vardir.
Buraya yazilan her slot o kayda girer, yani Revert All calismaya devam eder.

--- ADRES: DOSYA ADI NEYI GOSTERIR ---------------------------------------------------
Export'un yazdigi ad `TEX_<id>_s<n>_<rol>.png` (materyalin kendi TextureMap'i) ya da
`TEX_<id>_ts<n>_<rol>.png` (paylasilan TextureSet). BURADAKI `<n>` ADLANDIRMA
NUMARASIDIR, yazma hedefi DEGILDIR: TextureSet yuvasi 0/1/4/7 diye gider ama tanimin
durdugu kaptaki TextureMap blok INDEKSI 0/1/2/3'tur. Bu yuzden yazma hedefi
(`kap`, `kap_tm`) manifest.json'a export aninda YAZILIR (doku_png._slot_yaz) ve ithalat
adi degil MANIFESTI okur. Manifest'i olmayan / eski bir export reddedilir.

--- ROL TERSLERI (export ne yaptiysa tam tersi) ---------------------------------------
  diffuse   : export `arr[...,:3]` yazdi (alfa DUSTU) -> ithalatta RGB kullanicidan,
              alfa `alfa_politika` ile VANILLA'dan geri konur (kullanici bilincli alfa
              koyduysa onunki korunur -- politikanin kendi karari).
  normal    : export `normal_z_kur` ile (R, 255-G, kurulan Z) RGB + AYRI `_gloss` L
              yazdi. Ithalat bunu geri cevirir: R=R, G=255-G, A=gloss, B ise
              VANILLA'DAN geri konur. B'yi 0 yazmak ilk denemede olculdu: ayni
              Weapon_Sword_31 s3 slotunda ortalama 28,2 / maksimum 255 fark --
              kullanicinin DOKUNMADIGI bir kanali bozmak. Vanilla'dan geri konunca
              dokunulmamis bir export/ithalat turu 18/18 slotta BAYT-BIREBIR oluyor.
              normal ile gloss TEK slotun iki yarisidir: biri degistiyse ikisi de okunur.
  gloss     : normal'in alfa bandi. Tek basina degismisse yine normal slotu yazilir.
  emissive /
  mask / ...: export RGBA'yi (vanilla alfasiyla) oldugu gibi yazdi -> dosya HALA RGBA ise
              aynen geri okunur. Kullanici dosyayi RGB kaydettiyse (alfa yok) ya da
              editor duz 255 alfa bastiysa bu bir alfa kanali DEGIL, kanalin
              YOKLUGUDUR: PIL convert("RGBA") 255 uydurur. Olculdu (U_Edward_Fire,
              tur2 senaryo 06/06b, 2026-09-05): RGB fark 0/0/0 iken alfa fark ort
              105,6 (emissive, vanilla ort 149) ve 247,9 (mask, vanilla %89,5 sifir =
              BOLGE MASKESI) -- 4,19 M piksel, kullanicinin dokunmadigi kanal sessizce
              siliniyordu. Duzeltme: diffuse'teki alfa politikasinin AYNISI (alfa yok /
              duz 255 -> vanilla geri konur; gercek alfa -> kullanicininki). Vanilla
              cekilemezse slot REDDEDILIR (255 basmak yerine), tara() bunu NOTE/red
              olarak onay ekraninda gosterir. Duzeltme sonrasi alfa fark 0/0.

--- 16-BIT GRI PNG (I;16) -------------------------------------------------------------
Pillow 16-bit RGB/RGBA/LA PNG'yi acilista 8-bit'e indirir (senaryo 15 fark 0) ama 16-bit
GRI PNG'yi ham "I;16" birakir; convert("L")/convert("RGBA") 255'ten buyuk her degeri 255'e
KIRPAR. Olculdu (U_Edward_Fire, tur2 15b/15c, 2026-09-05): x257 kaydedilmis gloss'ta cikti
alfa ort 255,0 (vanilla 188,31; fark ort 66,7, maks 239, 4.156.847 px = tum kiyafet "hep
islak"), x257 gri diffuse'ta RGB ort 254,98 (bembeyaz, fark ort 185/198/198) -- beyaz liste
I;16'yi bilerek geciriyor, hicbir kapi (tara / NOTE / DE.plan / TexEncode) yakalamiyordu.
Duzeltme: her PNG acisi (_png_oku, _gri_oku ve diffuse yolundaki alfa_politika.
dogru_alfali_rgba) once alfa_politika.gri16_8bit'ten gecer: 16-bit gri >>8 ile 8-bit L
(Pillow'un renkli icin yaptiginin aynisi; x257 kaynakla bayt-birebir), 32-bit gri (I/F)
ise acik red. Duzeltme sonrasi 15b vanilla fark 0/0/0/0, 15c RGB = 8-bit L birebir.

--- DEGISMEYEN DOSYA YAZILMAZ (IKI KADEMELI KAPI) -------------------------------------
1. kademe (BAYT, G3): export aninda her PNG'nin sha256'si manifest'e yazilir; esitse dosya
   HIC acilmaz, slot HIC kodlanmaz. "Kullanici tek dosyayi boyadi" durumunda 30 slotluk bir
   kiyafette 30 kez BC7 kodlamasini (~yarim saat) onler.
2. kademe (PIKSEL, G3b): sha FARKLIYSA dosya zaten G6'da cozuluyor; rol tersleri uygulanmis
   hedef dizi (`_hedef_rgba`, yani kodlayiciya gidecek olan) CANLI slotun cozulmus mip0'iyla
   (`vanilla_rgba`) np.array_equal ile karsilastirilir. Birebirse slot 'degismeyen' sayilir,
   onay ekranina SKIP satiri + NOTE duser ve HIC kodlanmaz. Neden gerekli (olculdu,
   U_Edward_Fire diffuse 2048 BC3, tur2 07/15/20/20b + 'GIMP degistirmeden kaydet' = yalniz
   tIME/tEXt chunk eklendi, 2026-09-05): Photoshop/GIMP'in her kaydi, Adam7 interlace, zlib
   seviyesi, RGB->RGBA duz 255, 16-bit RGB -- hepsi bayt sha'sini degistirir ama pikseli
   degistirmez. 2. kademe yokken bes senaryo da '1 written' idi ve DDS uretiliyordu:
   TexEncode'un piksel-birebir PNG'den urettigi BC3, canli slotla 262.144 bloktan 261.638'inde
   bayt-farkli; cozulunce 4.194.304 pikselin 3.128.066'si (%74,6) farkli (kanal ort
   1,53/0,85/1,43, maks 33). Yani DOKUNULMAMIS dosya oyuna %74,6 pikseli oynamis bir doku
   yaziyor, 4 harici mip + 1 gomulu giris (+40 KB) Revert kaydini sisiriyordu. Kapi sonrasi
   ayni bes senaryo: 0 written / 15 unchanged, DDS uretilmez. 1 piksel boyanmis (02),
   gloss/normal boyanmis (10/11), alfa gradyani (07b) ise yine yazilir.
   FAIL-CLOSED: kapi yalniz KANITLA atlar; vanilla cozulemez / boyut uymaz / istisna ->
   yazilir (eski davranis). CANLI slotla karsilastirildigi icin (slot_mip0_bc canli arsivi
   okur, yazici harici mip'i yerinde yazar) onceki ithalatla modlanmis slotu geri boyayan
   dosya canli (modlu) slottan FARKLI cikar ve yazilir -> yanlis atlama yok.
   BC1 slotta yalniz alfa boyanmissa (07c) renk canliyla birebirdir; o alfa bandi zaten
   yazilmayacagi icin (asagi, BC1 ALFASI) SKIP satiri bunu ACIKCA soyler (eskiden ayni
   RGB sessizce yeniden kodlaniyordu). Emissive/mask RGB kaydi (06/06b) da ayni kapiya
   duser: renk birebir, alfa zaten vanilla'dan geri konacakti -> SKIP (eskiden kayipli
   yeniden kodlama). Maliyet (olculdu, taze surec, 2048 BC3 diffuse): re-saved slot basina
   ~0,1-0,2 s (_hedef_rgba 0,095 s = PNG'nin ikinci cozumu + BC cozumu 0,011 s +
   array_equal 0,004 s; tara toplam 0,14 -> 0,31 s), yerine BC3 ~0,6-2 s / BC7 ~60-170 s
   kodlama + 5 Revert girisi + 5,5 MB RAW yedek odeniyordu. Kapi testi:
   testler\\tur2_doku_sha_kapi.py (kum havuzu, 15 kapi) + test_doku_ithal.py K2b.

--- BC1 ALFASI: YAZILMAYAN BANDI ONAYDAN ONCE SOYLE (G8b) -----------------------------
Workshop BC1 slotlari OPAK yazar (`alfa_politika` karari 'bc1_opak', geriye uyum):
`_hedef_rgba` BC1'de `out[..., :3]` dondurur, yani dosyanin alfa bandi -- emissive/mask/ref
rolunde PNG'nin A kanali, `normal` rolunde AYRI GLOSS DOSYASI -- kodlayiciya HIC gitmez.
"Yazamiyor" degil "yazmiyor": BC1 blogu 1-bit punch-through TASIYABILIR (TexEncode'a alfasi
0 olan PNG dogrudan verilince 65.536 blogun hepsini c0<=c1 punch-through uretti, RGB de
siyaha dustu -- bandi dusurmek KASITLI ve KORUYUCU). Kusur bandi dusurmek degil, BUNU
SOYLEMEMEKTI: gerekce yalniz `hazirla`nin logunda, yani ONAYDAN SONRA goruluyordu
(GUI iki asamali: asama 1 = tara + rapor_metni, asama 2 = uygula -> hazirla).
Olculdu (U_Edward_Fire, s2_mask 0x24C1103081C tm2, BC1 1024, kum havuzu forge KOPYASI,
2026-09-05): vanilla alfa duz 255 (benzersiz 1), 65.536/65.536 blok duz renk.
  * 07c (YALNIZ alfa boyandi, RGB dokunulmadi): duzeltmeden ONCE "1 repainted" + 699.192 B
    DDS + plan kabul 1 iken RGB fark 0/0/0 idi -- gorsel etkisi SIFIR bir yazim, 512 KB blok
    verisi ve bir geri-alma kaydi. G3b piksel kapisi bunu kapatti: 0 written, SKIP satiri.
  * 07d (alfa TERS + 1 RGB pikseli boyandi): G3b devreye GIRMEZ (renk gercekten degisti) ->
    "1 repainted", WRITE satiri, onay ekraninda alfadan TEK SATIR YOK; alfa sessizce dustu.
Duzeltme (G8b): `_bc1_dusen_alfa` bandi CANLI slotun alfasiyla karsilastirir (vanilla
cekilemezse 'duz 255 degil'e duser, suphede False -- uyari sadece sorun varsa); dusen band
varsa WRITE satirina "colour only - painted alpha not written" eklenir ve NOTE basilir.
Ayni olcut G3b'nin SKIP satirini da besler, ikisi ayrisamaz. Kapi: testler\\tur2_bc1_alfa.py.

--- REDDETME (fail-closed; hepsi kullaniciya SEBEBIYLE gosterilir) --------------------
  * manifest yok / eski surum (kap-kap_tm-sha256 alanlari yok)
  * PNG boyutu slotun boyutundan farkli (arsivde ayrilmis yer sabittir)
  * slotun ailesi BC1/BC3/BC7 disinda (TexEncode bu ucunu yazar)
  * canli arsivdeki doku kimligi export anindakinden farkli (arsiv degismis)
  * kap canli arsivde yok / o TM indeksi yok
  * normal'in gloss esi eksik
  * PNG acilamiyor ya da 3 kanaldan az (rol RGB istiyorsa)
  * 32-bit gri (PIL modu I/F, PNG disi kaynak): deger araligi bilinemez, kirpilmaz
  * emissive/mask/ref dosyasinda alfa yok (ya da duz 255) VE slotun vanilla alfasi
    forge'dan cekilemiyor (aksi halde vanilla geri konur ve NOTE gosterilir)
Reddedilen dosya yazilmaz; kabul edilenler yazilir (kismi is), rapor ikisini de sayar.

Forge'a bu modul KENDISI yazmaz: `uygula()` doku_enjekte2.uygula'yi cagirir.
`tara()` ve `plan_ozeti()` forge'u yalniz 'rb' acar -- onay ekrani bunlarla kurulur.
"""
import glob
import hashlib
import json
import os
import shutil
import tempfile
import time

import numpy as np
from PIL import Image

import outfit_core as C
import doku_enjekte2 as DE
import alfa_politika as AP                 # alfa politikasi + 16-bit gri (I;16) kapisi

try:
    from . import doku_png as DP
except ImportError:                                   # modul dosya yolundan yuklendiyse
    import doku_png as DP
try:
    from . import doku_dds as DD
except ImportError:                                   # modul dosya yolundan yuklendiyse
    import doku_dds as DD

__all__ = ["tara", "hazirla", "uygula", "rapor_metni", "SURUM"]

SURUM = "1.0"
MANIFEST_AD = "manifest.json"
TEX_KLASOR = "textures"
# TexEncode'un yazabildigi aileler (outfit_core._FMT_BCN ile AYNI kume)
DESTEKLI_AILE = ("BC1", "BC3", "BC7")
# Duzenlenmis GLB adayi: export'un kendi GLB'si DISINDAKI .glb dosyalari
DUZENLI_GLB_ONEK = "_edit"
Image.MAX_IMAGE_PIXELS = None


# ------------------------------------------------------------------ yardimcilar
def _log(progress, s):
    C._log(progress, s)


def manifest_oku(klasor):
    """(manifest_dict, yol). Dosya yoksa FileNotFoundError."""
    yol = os.path.join(klasor, MANIFEST_AD)
    if not os.path.isfile(yol):
        raise FileNotFoundError(
            "This is not a 3D export folder: %s is missing. Pick the folder that "
            "EXPORT 3D created (it holds the .glb, manifest.json and textures\\)." % MANIFEST_AD)
    with open(yol, encoding="utf-8") as f:
        return json.load(f), yol


def _slot_kayitlari(man):
    """manifest -> [(mat_hex, slot_kaydi)] duzlestirilmis liste (paylasilan kap TEK KEZ).

    Ayni TextureSet birden cok materyal tarafindan kullanildigi icin manifest'te ayni
    slot kaydi tekrar tekrar gecer; yazma hedefi (kap, kap_tm) ayni oldugundan bir kez
    islenir ama `paylasan` alaninda o kabi kullanan TUM materyaller sayilir."""
    hedefler = {}                       # (kap, kap_tm) -> kayit
    for mat_hex, mm in sorted((man.get("materyaller") or {}).items()):
        for s in (mm.get("slotlar") or []):
            if not s.get("dosya_ad"):
                continue                # atlanan slot (hata alani dolu) -> ithalat adayi degil
            # kap yoksa (ITHALATTAN ONCEKI export) her dosya AYRI kayit sayilir --
            # aksi halde hepsi ("", None) altinda toplanip "1 of 1" gibi yaniltici
            # bir sayi uretiyordu (olculdu).
            anahtar = ((str(s.get("kap")).upper(), s.get("kap_tm")) if s.get("kap")
                       else ("?", s["dosya_ad"]))
            h = hedefler.get(anahtar)
            if h is None:
                h = dict(s)
                h["paylasan"] = []
                hedefler[anahtar] = h
            if mat_hex not in h["paylasan"]:
                h["paylasan"].append(mat_hex)
    return list(hedefler.values())


def _png_oku(yol, en_az_kanal=3):
    """PNG -> (H,W,4) uint8 + (W,H) boyut. Kanal yetersizse ValueError.
    16-bit gri (I;16) ONCE AP.gri16_8bit ile olcekli 8-bit L'ye iner: eskiden beyaz
    listeden gecip dogrudan convert("RGBA") ile KIRPILIYORDU (modul basligi, 16-BIT GRI).
    32-bit gri (I/F) orada ValueError -> tara() 'could not be read' olarak reddeder."""
    with Image.open(yol) as im:
        w, h = im.size
        im8 = AP.gri16_8bit(im)
        bant = im8.getbands()
        if en_az_kanal >= 3 and len(bant) < 3 and im8.mode not in ("P", "L", "LA"):
            raise ValueError("the file has %d channel(s) (%s); this slot needs a colour image"
                             % (len(bant), "".join(bant)))
        arr = np.asarray(im8.convert("RGBA")).copy()
    return arr, (w, h)


def _gri_oku(yol):
    """Gloss PNG -> (H,W) uint8 L. 16-bit gri olcekli iner (_png_oku ile ayni kapi)."""
    with Image.open(yol) as im:
        w, h = im.size
        arr = np.asarray(AP.gri16_8bit(im).convert("L")).copy()
    return arr, (w, h)


def _alfa_var_mi(yol):
    """PNG'de GERCEK alfa bilgisi var mi (A bandi ya da tRNS)? Dosyayi COZMEZ.
    alfa_politika.dogru_alfali_rgba ile AYNI olcut: RGB/L/P dosyada convert('RGBA')nin
    urettigi duz 255, kullanicinin alfasi DEGILDIR."""
    with Image.open(yol) as im:
        return ("A" in im.getbands()) or ("transparency" in im.info)


# emissive / mask / ref rollerinde alfa kaynagi kararlari (alfa_politika.alfa_karari'nin
# donusleri): bunlar kullanicininkini korur, 'vanilla' forge'dan geri koyar.
_ALFA_KULLANICI = ("kullanici", "kullanici_sabit")


def _ref_alfa_karari(yol, arr, aile):
    """emissive / mask / ref (diffuse ve normal DISI) rolleri icin alfa karari.
    Kural diffuse ile BIREBIR AYNI (alfa_politika.alfa_karari): alfa yok ya da duz 255
    -> 'vanilla'; gercek varyasyon ya da 255-disi sabit -> kullanicininki.
    Doner (karar, gerekce_tr)."""
    import alfa_politika as AP
    user = arr[..., 3] if _alfa_var_mi(yol) else None
    return AP.alfa_karari(user, aile)


def _ref_alfa_red_sebebi(rol):
    """Vanilla alfa cekilemedigi icin reddetme metni (tara() ve _hedef_rgba AYNI metni verir)."""
    return ("the file has no alpha channel (or a flat 255 one) and the game's own alpha for "
            "this %s slot could not be read, so the alpha band cannot be restored. Save the "
            "file as RGBA (keep the exported alpha) and import again." % rol)


_VANILLA_RGBA = {}


def vanilla_rgba(kap, tm, tanim=None):
    """Slotun VANILLA mip0'i (H,W,4) uint8 ya da None. SALT OKUNUR ('rb'), onbellekli.

    Neden gerekli: export normal haritasini (R, 255-G, KURULAN Z) olarak yaziyor, yani
    oyunun B kanali GERI GELMIYOR. Olculdu (Weapon_Sword_31 s3, BC7): B'yi 0 yazmak
    ortalama 28,2 / maksimum 255 fark uretiyor -- kullanicinin DOKUNMADIGI bir kanali
    bozmak demek. `alfa_politika`nin alfa icin yaptigi seyin aynisi yapilir: dokunulmamis
    kanal forge'daki vanilla degerden geri konur."""
    anahtar = ("%s" % kap).upper(), int(tm)
    if anahtar in _VANILLA_RGBA:
        return _VANILLA_RGBA[anahtar]
    out = None
    try:
        if tanim is None:
            _h, _t, tanim, _r, _m = C._slot_tanim(kap, int(tm))
        W, H, aile = tanim["W"], tanim["H"], tanim["aile"]
        data, _t2 = C.slot_mip0_bc(kap, int(tm))
        if data is not None and aile:
            gerek = ((W + 3) // 4) * ((H + 3) // 4) * DE.AILE_BLOK[aile]
            if len(data) >= gerek:
                out = C._bc_decode_rgba(data[:gerek], W, H, tanim["fmt_enum"])
    except Exception:                                           # noqa: BLE001
        out = None
    _VANILLA_RGBA[anahtar] = out
    return out


def _bc1_dusen_alfa(j, arr, gloss=None, tanim=None):
    """G8b -- BC1 slotta YAZILAMAYACAK bir alfa duzenlemesi var mi? (modul basligi, BC1 ALFASI)

    BC1 blogu 3 kanal saklar; 1-bit punch-through URETILEBILIR ama Workshop bu slotlari
    OPAK yazar (alfa_politika 'bc1_opak', geriye uyum) -- yani `_hedef_rgba` BC1'de
    `out[..., :3]` dondurur ve dosyanin alfa bandi kodlayiciya HIC gitmez. Kullanicinin
    o banda koydugu emek COPE gider, bu yuzden ONAY EKRANINDA soylenmelidir.

    Alfa bandi nerede: emissive/mask/ref rolunde PNG'nin kendi A bandi, `normal` rolunde
    ise AYRI GLOSS dosyasi (`_hedef_rgba` onu `out[..., 3]`e koyar, sonra BC1'de atar).

    Olcut CANLI slotun alfasi (BC1 cozumu: 255, punch-through'da 0). Band ondan FARKLIYSA
    duzenleme kullanicinindir. Vanilla cekilemezse 'duz 255 degil'e duser. Doner True
    yalniz KANITLA -- suphede False (gereksiz uyari basma: uyari sadece sorun varsa)."""
    if j.get("aile") != "BC1":
        return False
    try:
        if j.get("rol") == "normal":
            band = gloss                    # normal'in alfasi gloss dosyasindan gelir
        elif arr is not None and arr.ndim == 3 and arr.shape[2] == 4 and _alfa_var_mi(j["dosya"]):
            band = arr[..., 3]
        else:
            band = None                     # dosyada gercek alfa yok -> dusen bir sey de yok
        if band is None or band.ndim != 2:
            return False
        van = vanilla_rgba(j["kap"], j["kap_tm"], tanim)
        if van is not None and van.shape[:2] == band.shape[:2]:
            return not bool(np.array_equal(band, van[..., 3]))
        return bool(int(band.min()) != 255)
    except Exception:                                           # noqa: BLE001
        return False


def _bc1_alfa_notu(j):
    """G8b NOTE metni (rol'e gore; SKIP satiriyla AYNI ifadeyi kullanir)."""
    if j.get("rol") == "normal":
        return ("%s is the gloss half of %s, but the game stores that slot as BC1 and the "
                "Workshop writes BC1 slots with no alpha band, so your gloss edits are "
                "discarded - only the normal map's colour is written."
                % (j.get("gloss_dosya_ad") or "the gloss file", j["dosya_ad"]))
    return ("%s carries a painted alpha channel, but the game stores this slot as BC1 and the "
            "Workshop writes BC1 slots with no alpha band, so that alpha is discarded - only the "
            "colour is written. Paint the colour channels instead." % j["dosya_ad"])


def _piksel_ayni_mi(j, tanim, arr, gloss=None):
    """G3b -- ikinci kademe degisim kapisi (modul basligi, DEGISMEYEN DOSYA YAZILMAZ).

    Dosya sha'si manifestten FARKLI; oyuna yazilacak dizi (`_hedef_rgba`: rol tersleri
    uygulanmis, kodlayiciya gidecek olan) CANLI slotun cozulmus mip0'iyla (`vanilla_rgba`)
    birebir mi? Ayni yardimci kullanildigi icin kapi, `hazirla`nin yazacagi seyin TA
    KENDISINI karsilastirir (rol tersi degisirse kapi da onunla degisir).

    Doner (ayni, alfa_yoksayildi):
      ayni            : True yalniz KANITLANIRSA (np.array_equal). Vanilla cozulemedi /
                        boyut uymadi / istisna -> False = yazilir (fail-closed: suphe varsa
                        atlanmaz, eski davranis).
      alfa_yoksayildi : `_bc1_dusen_alfa` -- BC1 slotta dosyanin (ya da gloss esinin) alfa
                        bandi canli slotunkinden farkli; Workshop BC1'i opak yazdigi icin o
                        band zaten yazilamaz. rapor_metni SKIP satirinda "pixel-identical"
                        yerine bunu ACIKCA soyler (07c).
    Neden CANLI slot: `slot_mip0_bc` canli arsivi okur, yazici da harici mip'i yerinde yazar;
    onceki ithalatla modlanmis slot da 'canli'dir -> onu geri boyayan dosya farkli cikar,
    yazilir (yanlis atlama yok)."""
    try:
        van = vanilla_rgba(j["kap"], j["kap_tm"], tanim)
        if van is None or van.shape[:2] != (j["H"], j["W"]):
            return False, False
        hedef, _karar = _hedef_rgba(j)
        if hedef.shape[:2] != van.shape[:2] or hedef.shape[2] > 4:
            return False, False
        ayni = bool(np.array_equal(hedef, van[..., :hedef.shape[2]]))
        # BC1'in dusen alfasi TEK yerden olculur (`_bc1_dusen_alfa`) -- SKIP satiri ile
        # yazilan slotun NOTE'u ayni olcutu paylasir, ikisi ayrisamaz.
        alfa_yok = bool(ayni and _bc1_dusen_alfa(j, arr, gloss, tanim))
        return ayni, alfa_yok
    except Exception:                                           # noqa: BLE001
        return False, False


def _temiz_png_yaz(arr, etiket):
    """Profil tasimayan gecici PNG (fromarray -> renk profili yok), _tex_encode girdisi."""
    d = os.path.join(tempfile.gettempdir(), "OutfitWorkshop_3dimport_%d" % os.getpid())
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "%s.png" % etiket)
    Image.fromarray(arr).save(p)
    return p


# ------------------------------------------------------------------ TARAMA (salt okunur)
def tara(klasor, progress=None, glb=True, gizle_eksik=False, hedef=None, hedef_silah=None,
         capraz_esleme=None):
    """Export klasorunu tarar; forge'a TEK BAYT YAZMAZ.

    Doner:
      {ok, klasor, manifest, anahtar, kategori, kaynak_glb,
       yazilacak:[...], degismeyen:int, red:[{dosya,sebep}], uyari:[...],
       yeniden_kaydedilen:[{dosya_ad, degisen, aile, alfa_yoksayildi}],
       mesh: None | {durum, ozet, parcalar, sebep}}
    `yazilacak` kaydi: {dosya, dosya_ad, rol, kap, kap_tm, W, H, aile, srgb,
                        doku_id, paylasan, gloss_dosya, degisen}
    `yeniden_kaydedilen`: sha'si degismis ama PIKSELI canli slotla birebir dosyalar
                        (G3b); `degismeyen` sayisina DAHILDIR, kodlanmaz.
    """
    klasor = os.path.abspath(klasor)
    man, man_yol = manifest_oku(klasor)
    tex_dir = os.path.join(klasor, TEX_KLASOR)
    rapor = {"ok": False, "klasor": klasor, "manifest": man_yol,
             "anahtar": man.get("anahtar"), "kategori": man.get("kategori") or "outfit",
             "gorunen_ad": man.get("gorunen_ad"), "kaynak_glb": man.get("glb"),
             "yazilacak": [], "degismeyen": 0, "red": [], "uyari": [], "mesh": None,
             "yeniden_kaydedilen": [], "toplam_dosya": 0, "surum": SURUM}

    # CAPRAZ mod: secili oge export'un kendi ogesi degil -> yalniz MESH tasinir. Dokular
    # baska bir ogenin yuvalarina (farkli boyut/rol) yazilamaz; hedef kendi dokusunu tutar.
    # PARCA TAKASI (2026-09-05, Discord istegi): hedef ogenin KENDISI olsa bile kullanici
    # elle bir esleme verdiyse ("sag kilici sol yuvaya koy") bu da CAPRAZ yoldur -- mesh
    # tasinir, PNG'ler yazilmaz. mesh_ithal.plan ayni karari ayni kosulla verir; ikisi
    # ayrisirsa kullanici eslemeyi secer ama tarama onu unutur (olculmus hata sinifi).
    rapor["takas"] = bool(hedef) and bool(capraz_esleme) \
        and str(hedef) == str(man.get("anahtar") or "")
    rapor["capraz"] = bool(hedef) and (str(hedef) != str(man.get("anahtar") or "")
                                       or bool(capraz_esleme))
    if rapor["capraz"]:
        if glb:
            rapor["mesh"] = mesh_farki(klasor, man, progress, doku_kaplari=set(),
                                       gizle_eksik=gizle_eksik, hedef=hedef,
                                       hedef_silah=hedef_silah,
                                       capraz_esleme=capraz_esleme)
        m = rapor["mesh"] or {}
        # NOT metni mesh planina BAKARAK soylenir: materyal yonlendirmesi kapiya takilan
        # parcada (mesh_ithal `_capraz_materyal`, dogrulanamayan materyal) hedef kendi
        # dokusunu tutar; 2026-09-05'e kadar bu satir kosulsuz "textures follow the shape"
        # diyordu (CHR_W_Sword -> Weapon_Sword_02, kum forge'da olculdu).
        # KATLAMA: cok materyalli kaynak parcasi daha az yuvali hedefe katlaninca yalniz ilk
        # grubun materyali tasinir (mesh_ithal `materyal_dusen`, WARNING satiri); bu NOTE da
        # ayni parcalarda "textures follow the shape" diye onaylamaz, kac parcada oldugunu
        # soyler (Edward_Assassin -> U_Edward_Fire: 3 parca, Torso'da ucgenlerin %98,9'u;
        # 2026-09-05'e kadar kosulsuz onayliyordu, kum forge'da olculdu).
        yazilan = [p for p in (m.get("parcalar") or [])
                   if p.get("capraz") and p.get("_is") and p.get("rota") not in ("red", "atla")]
        izleyen = [p for p in yazilan if p.get("materyal")]
        katlanan = [p for p in izleyen if p.get("materyal_dusen")]
        ek = ("" if not katlanan else
              " On %d part(s) the game mesh has fewer material slots than the source, so part "
              "of that shape is drawn with a neighbouring group's material (see the WARNING "
              "lines above)." % len(katlanan))
        # PARCA TAKASI: kaynak ile hedef AYNI oge oldugu icin "cross-import" demek yanlis
        # olurdu (kullanici baska bir kiyafeti ithal ettigini sanir). Ayni bilgi -- PNG'ler
        # yazilmaz, tasinan sekil kendi materyalini goturur -- takas diliyle soylenir.
        if rapor.get("takas"):
            rapor["uyari"].append(
                "part swap: the PNG files in this folder are not written; only the mesh (and "
                "the material it points at) is moved into the slot you picked. Everything else "
                "in this item stays as it is.")
        elif yazilan and not izleyen:
            rapor["uyari"].append("cross-import: the PNG files in this folder are not written, and "
                                  "the target keeps its own textures (see the MESH lines above "
                                  "for why the source material could not be used).")
        elif yazilan and len(izleyen) < len(yazilan):
            rapor["uyari"].append("cross-import: the PNG files in this folder are not written; "
                                  "%d of %d written part(s) point at the source item's own "
                                  "material, the rest keep the target's textures (see the MESH "
                                  "lines above).%s" % (len(izleyen), len(yazilan), ek))
        else:
            rapor["uyari"].append("cross-import: the PNG files in this folder are not written; the "
                                  "target is pointed at the source item's own material instead, so "
                                  "its textures follow the shape.%s" % ek)
        rapor["mesh_yazilacak"] = int(m.get("yazilacak") or 0) if m.get("yazilabilir") else 0
        rapor["imza"] = klasor_imzasi(klasor) if "klasor_imzasi" in globals() else None
        rapor["ok"] = bool(rapor["mesh_yazilacak"])
        return rapor
    kayitlar = _slot_kayitlari(man)
    if not kayitlar:
        rapor["red"].append(
            {"dosya": MANIFEST_AD,
             "sebep": "this export was written before IMPORT 3D existed, so it does not record "
                      "where each PNG belongs. Run EXPORT 3D once more and paint that folder."})
        return rapor
    eski = [k for k in kayitlar if not k.get("kap") or k.get("kap_tm") is None or not k.get("sha256")]
    if eski:
        rapor["red"].append(
            {"dosya": MANIFEST_AD,
             "sebep": "this export is older than IMPORT 3D: %d of %d textures have no recorded "
                      "target or checksum. Run EXPORT 3D once more and paint the new folder."
                      % (len(eski), len(kayitlar))})
        return rapor

    for k in kayitlar:
        rapor["toplam_dosya"] += 1
        ad = k["dosya_ad"]
        yol = os.path.join(tex_dir, ad)
        rol = k.get("rol") or "ref"
        gloss_ad = k.get("gloss_dosya_ad")
        gloss_yol = os.path.join(tex_dir, gloss_ad) if gloss_ad else None
        _g = None                       # gloss dizisi (yalniz normal rolunde dolar)
        # --- DDS: 'Textures (.dds)' exportu ayni slot icin ikinci bir dosya birakir.
        # Hangisinin duzenlendigini SHA soyler; ikisi birden duzenlendiyse SECMEYIZ.
        dds_ad = k.get("dds_dosya_ad")
        dds_yol = os.path.join(tex_dir, dds_ad) if dds_ad else None
        dds_degisen = bool(dds_ad and k.get("dds_sha256") and os.path.isfile(dds_yol)
                           and C._sha256_file(dds_yol) != k["dds_sha256"])
        png_var = os.path.isfile(yol)
        # --- G2 dosya duruyor mu (DDS duzenlendiyse PNG'nin yoklugu engel degil)
        if not png_var and not dds_degisen:
            rapor["red"].append({"dosya": ad, "sebep":
                                 "the file is not in textures\\ any more. Put it back, or export again."})
            continue
        if png_var and rol == "normal" and gloss_ad and not os.path.isfile(gloss_yol) \
                and not dds_degisen:
            rapor["red"].append({"dosya": ad, "sebep":
                                 "its partner %s is missing. A normal map and its gloss file are two "
                                 "halves of one game texture; both must be present." % gloss_ad})
            continue
        # --- G3 degisti mi (sha) -- degismeyen HIC islenmez
        degisen = []
        if png_var and C._sha256_file(yol) != k["sha256"]:
            degisen.append(ad)
        if png_var and rol == "normal" and gloss_ad and k.get("gloss_sha256") \
                and os.path.isfile(gloss_yol):
            if C._sha256_file(gloss_yol) != k["gloss_sha256"]:
                degisen.append(gloss_ad)
        if not degisen and not dds_degisen:
            rapor["degismeyen"] += 1
            continue
        # --- G4 kap canli arsivde ve o TM indeksi var mi
        try:
            _hdr, tex, tanim, _res, _tms = C._slot_tanim(k["kap"], int(k["kap_tm"]))
        except Exception as e:                                  # noqa: BLE001
            rapor["red"].append({"dosya": ad, "sebep":
                                 "the game archive no longer holds this texture slot (%s). Export "
                                 "this outfit again so the addresses match." % e})
            continue
        # --- G5 hedef doku kimligi export anindakiyle ayni mi
        beklenen = k.get("doku_id")
        if beklenen and int(str(beklenen), 16) != tex:
            rapor["red"].append({"dosya": ad, "sebep":
                                 "the game archive changed since this export (slot now holds texture "
                                 "0x%X, the export recorded %s). Export again before importing." % (tex, beklenen)})
            continue
        W, H, aile = tanim["W"], tanim["H"], tanim["aile"]
        # --- G7 aileyi yazabiliyor muyuz
        if aile not in DESTEKLI_AILE:
            # Enum 0x06 gibi yalniz OKUMA tarafinin (doku_png.ENUM_AILE_EK, olculmus) tanidigi
            # bicimler burada ACIKCA reddedilir: yazici tablosu (doku_enjekte2.ENUM_AILE) onlari
            # bilmez ve oyunda geri yazmanin dogru oldugu kanitlanmadi -- fail-closed.
            rapor["red"].append({"dosya": ad, "sebep":
                                 "the game stores this texture as %s; the Workshop's encoder writes "
                                 "BC1, BC3 and BC7 only." % (
                                     aile or "an unknown format (enum 0x%02X; export-only)"
                                     % int(tanim.get("fmt_enum") or 0))})
            continue
        # --- GD DDS YOLU ------------------------------------------------------------
        # DDS oyunun KENDI bloklarini tasir: bicim/boyut uyuyorsa hicbir kod cozme ya da
        # yeniden kodlama YAPILMAZ (kayipsiz tur donusu). Uymuyorsa acilir ve slotun
        # bicimine yeniden kodlanir; bu bir RED degildir ama SOYLENIR.
        if dds_degisen:
            if degisen:
                rapor["red"].append({"dosya": dds_ad, "sebep":
                                     "both %s and %s were edited and they are two copies of the "
                                     "same texture, so the tool cannot tell which one you meant. "
                                     "Keep one and export again." % (ad, dds_ad)})
                continue
            dds = DD.dds_oku(dds_yol)
            zincir = None
            if dds.get("ok"):
                try:
                    zincir = DD.mip_zinciri(k["kap"], int(k["kap_tm"]))
                except Exception:                               # noqa: BLE001
                    zincir = None
            rota, sebep = DD.uyumlu_mu(dds, tanim, zincir)
            if rota == "red":
                rapor["red"].append({"dosya": dds_ad, "sebep": sebep + "."})
                continue
            j = {
                "dosya": dds_yol, "dosya_ad": dds_ad, "rol": rol, "kap": k["kap"],
                "kap_tm": int(k["kap_tm"]), "W": W, "H": H, "aile": aile,
                "srgb": int(bool(tanim.get("srgb"))), "doku_id": "0x%X" % tex,
                "paylasan": k.get("paylasan") or [], "gloss_dosya": None,
                "gloss_dosya_ad": None, "degisen": [dds_ad], "kaynak": "dds",
                "dds_rota": rota, "dds_sebep": sebep}
            # PIKSEL KIMLIGI (G3b'nin DDS karsiligi): dosya yeniden kaydedilmis ama
            # level 0 canli slotla BIREBIR ise yazacak bir sey yok.
            if rota == "dogrudan" and zincir is not None:
                s0 = next((s for s in zincir["seviyeler"] if s["lvl"] == 0), None)
                d0 = next((s for s in dds["seviyeler"] if s["lvl"] == 0), None)
                if s0 and d0 and s0["veri"] == d0["veri"]:
                    rapor["degismeyen"] += 1
                    rapor["yeniden_kaydedilen"].append(
                        {"dosya_ad": dds_ad, "degisen": [dds_ad], "aile": aile,
                         "alfa_yoksayildi": False})
                    continue
            if rota == "yeniden_kodla":
                rapor["uyari"].append("%s %s. The game's own blocks are not reused for this "
                                      "file, so some compression loss is added."
                                      % (dds_ad, sebep))
            elif zincir is not None:
                yz = DD.yazilmayan_seviyeler(zincir)
                if any(x["lvl"] == 0 for x in yz):
                    # Level 0 yazilamiyorsa "yazdim" demek YALAN olurdu: oyun tam
                    # cozunurluklu dokuyu vanilla'dan okumaya devam ederdi.
                    rapor["red"].append({"dosya": dds_ad, "sebep":
                                         "this version cannot write the full-resolution level "
                                         "of this texture back (%s), so nothing would change "
                                         "in the game."
                                         % [x for x in yz if x["lvl"] == 0][0]["sebep"]})
                    continue
                if yz:
                    rapor["uyari"].append(
                        "%s is written block for block, but its smallest mip level(s) (%s) are "
                        "not: the texture writer places them differently from where the game "
                        "reads them, so the game keeps its own."
                        % (dds_ad, ", ".join(str(x["lvl"]) for x in yz)))
            rapor["yazilacak"].append(j)
            continue
        # --- G6 boyut
        try:
            _arr, (pw, ph) = _png_oku(yol)
        except Exception as e:                                  # noqa: BLE001
            rapor["red"].append({"dosya": ad, "sebep": "the image could not be read (%s)." % e})
            continue
        if (pw, ph) != (W, H):
            rapor["red"].append({"dosya": ad, "sebep":
                                 "the image is %dx%d but this slot must stay %dx%d. The archive "
                                 "reserves a fixed number of bytes per texture, so a different size "
                                 "does not fit. Resize it back and import again." % (pw, ph, W, H)})
            continue
        if rol == "normal" and gloss_ad:
            try:
                _g, (gw, gh) = _gri_oku(gloss_yol)
            except Exception as e:                              # noqa: BLE001
                rapor["red"].append({"dosya": gloss_ad, "sebep": "the image could not be read (%s)." % e})
                continue
            if (gw, gh) != (W, H):
                rapor["red"].append({"dosya": gloss_ad, "sebep":
                                     "the gloss image is %dx%d but it must stay %dx%d, the same size "
                                     "as its normal map." % (gw, gh, W, H)})
                continue
        j = {
            "dosya": yol, "dosya_ad": ad, "rol": rol, "kap": k["kap"], "kap_tm": int(k["kap_tm"]),
            "W": W, "H": H, "aile": aile, "srgb": int(bool(tanim.get("srgb"))),
            "doku_id": "0x%X" % tex, "paylasan": k.get("paylasan") or [],
            "gloss_dosya": gloss_yol if (rol == "normal" and gloss_ad) else None,
            "gloss_dosya_ad": gloss_ad if rol == "normal" else None,
            "degisen": degisen}
        # --- G3b PIKSEL KIMLIGI: sha degisti ama kodlayiciya gidecek dizi canli slotla
        # BIREBIR mi? (editor 'degistirmeden kaydet', interlace, zlib seviyesi, RGB->RGBA duz
        # 255, 16-bit RGB...) Birebirse yeniden kodlamak yalniz kayip ekler (%74,6 piksel
        # oynuyor; modul basligi) -> 'degismeyen' sayilir, SKIP + NOTE, HIC kodlanmaz.
        # Yalniz KANITLA atlar; karsilastirilamazsa yazilir (fail-closed). G8'den ONCE
        # durur ki atlanan dosya icin alfa NOTE'u da basilmasin.
        ayni, alfa_yok = _piksel_ayni_mi(j, tanim, _arr, _g)
        if ayni:
            rapor["degismeyen"] += 1
            rapor["yeniden_kaydedilen"].append({"dosya_ad": ad, "degisen": degisen,
                                                "aile": aile, "alfa_yoksayildi": alfa_yok})
            continue
        # --- G8 diffuse/normal DISI RGBA rolleri (emissive / mask / ref): alfa kanali
        # dosyada YOK ya da duz 255 ise bu kanalin yoklugudur, kullanicinin alfasi degil.
        # Slotun alfasi oyun verisidir (mask'ta BOLGE MASKESI; olculdu, modul basligi):
        # vanilla geri konur ve kullaniciya NOTE gosterilir; vanilla cekilemiyorsa
        # 255 basmak yerine slot REDDEDILIR (fail-closed). _hedef_rgba ayni karari verir.
        if rol not in ("diffuse", "normal") and aile != "BC1":
            alfa_karar, _ = _ref_alfa_karari(yol, _arr, aile)
            if alfa_karar == "vanilla":
                van = vanilla_rgba(k["kap"], int(k["kap_tm"]), tanim)
                if van is None or van.shape[:2] != (H, W):
                    rapor["red"].append({"dosya": ad, "sebep": _ref_alfa_red_sebebi(rol)})
                    continue
                rapor["uyari"].append(
                    "%s has no alpha channel (it was saved as RGB, or with a flat 255 alpha). "
                    "This %s slot's alpha band is game data%s, so the game's own alpha is kept "
                    "and only the colour is written. Save the file as RGBA if you mean to paint "
                    "the alpha." % (ad, rol, " (a region mask)" if rol.startswith("mask") else ""))
        # --- G8b BC1'in DUSEN ALFASI (modul basligi, BC1 ALFASI). Workshop BC1 slotlari opak
        # yazar; dosyanin alfa bandi (normal'de gloss dosyasi) kodlayiciya HIC gitmez.
        # Yalniz-alfa halini (07c) G3b'nin SKIP satiri soyluyordu, ama RGB de degistiyse slot
        # YAZILIR ve alfa SESSIZCE duserdi: olculdu 2026-09-05 (U_Edward_Fire s2_mask BC1 1024,
        # senaryo 07d = alfa ters + 1 RGB pikseli) -> "1 repainted", onay ekraninda alfadan tek
        # satir yok, gerekce ("BC1 slot has no alpha band.") yalniz ONAYDAN SONRAKI hazirla
        # logunda goruluyordu. Simdi WRITE satiri + NOTE onay ekraninda soyler.
        if _bc1_dusen_alfa(j, _arr, _g, tanim):
            j["bc1_alfa_dusuyor"] = True
            rapor["uyari"].append(_bc1_alfa_notu(j))
        rapor["yazilacak"].append(j)

    # yeniden kaydedilmis ama piksel-birebir dosyalar: TEK toplu NOTE (dosya basina SKIP
    # satirini rapor_metni basar; uyari listesi onay ekraninda 4 satirla sinirli)
    yk = rapor["yeniden_kaydedilen"]
    # BC1'in dusen alfasi yuzunden atlanan dosyalar AYRI NOTE alir: onlar icin "every pixel
    # is identical" DOGRU DEGIL (renk birebir, alfa farkli) ve kullanicinin kaybettigi sey
    # tam olarak o farktir -- ayni cumleye katlanirsa duzenlemesinin coptegi hic anlasilmaz.
    yk_duz = [x for x in yk if not x.get("alfa_yoksayildi")]
    yk_alfa = [x for x in yk if x.get("alfa_yoksayildi")]

    def _adlar(liste):
        s = ", ".join(x["dosya_ad"] for x in liste[:4])
        return s + (" and %d more" % (len(liste) - 4) if len(liste) > 4 else "")
    if yk_duz:
        rapor["uyari"].append(
            "%d file(s) were re-saved (their bytes changed) but every pixel is identical to the "
            "texture the game already holds, so they are skipped and not re-encoded: %s. "
            "Re-encoding an unchanged image would only add compression loss."
            % (len(yk_duz), _adlar(yk_duz)))
    if yk_alfa:
        rapor["uyari"].append(
            "%d file(s) match the game's texture in colour and differ only in the alpha channel, "
            "but the Workshop writes these BC1 slots with no alpha band, so nothing is written "
            "and the alpha you painted is discarded: %s. Paint the colour channels instead."
            % (len(yk_alfa), _adlar(yk_alfa)))

    # paylasim uyarisi: bir kap birden cok materyale bagliysa boyama hepsini etkiler
    for j in rapor["yazilacak"]:
        if len(j["paylasan"]) > 1:
            rapor["uyari"].append(
                "%s is shared by %d materials in this export (%s), so repainting it changes all of "
                "them. A TextureSet can also be shared with outfits and characters outside this "
                "export." % (j["dosya_ad"], len(j["paylasan"]), ", ".join(j["paylasan"][:4])))

    if glb:
        # Doku yazilacak KAPLARI mesh tarafina bildir: ayni arsiv girisine iki
        # yazici birden dokunamaz (bkz. mesh_ithal cakisma notu).
        kaplar = set()
        for j in rapor["yazilacak"]:
            try:
                kaplar.add(int(str(j["kap"]), 16))
            except (TypeError, ValueError):
                pass
        rapor["mesh"] = mesh_farki(klasor, man, progress, doku_kaplari=kaplar,
                                   gizle_eksik=gizle_eksik)
    m = rapor["mesh"] or {}
    rapor["mesh_yazilacak"] = int(m.get("yazilacak") or 0) if m.get("yazilabilir") else 0
    rapor["imza"] = klasor_imzasi(klasor)
    # ok = YAZILACAK BIR SEY VAR MI (doku ya da mesh). Eskiden yalniz dokuya bakiyordu;
    # mesh acildiktan sonra "sadece modeli duzenledim" durumu "nothing to import" olurdu.
    rapor["ok"] = bool(rapor["yazilacak"] or rapor["mesh_yazilacak"])
    return rapor


def klasor_imzasi(klasor):
    """Klasorun PARMAK IZI: onaydan sonra dosyalar degistiyse APPLY bunu gorur.
    Yalnizca stat (ad + boyut + mtime_ns) -- 30 PNG'yi yeniden sha'lamak icin degil,
    'onayladigin sey hala bu mu?' sorusuna cevap vermek icin."""
    h = hashlib.sha256()
    kok = os.path.abspath(klasor)
    for taban, _dizin, dosyalar in os.walk(kok):
        for ad in sorted(dosyalar):
            if not ad.lower().endswith((".png", ".glb", ".json")):
                continue
            y = os.path.join(taban, ad)
            try:
                st = os.stat(y)
            except OSError:
                continue
            h.update(("%s|%d|%d\n" % (os.path.relpath(y, kok).replace("\\", "/"),
                                      st.st_size, st.st_mtime_ns)).encode("utf-8"))
    return h.hexdigest()[:16]


# ------------------------------------------------------------------ MESH tarafi (KOPRU)
# Mesh geri yazimi ACIK. Kopru `mesh_ithal`: glb_oku.eslestir -> mesh_yaz.yaz (ayni
# topoloji) / mesh_yaz.yaz_serbest (topoloji degistiyse) -> kur_mesh.kur. Blender'in
# UV/normal dikislerinde vertex sayisini degistirmesi artik engel DEGIL: serbest
# topoloji yazicisi (kume-siz MeshData) herhangi bir vertex/ucgen sayisini kabul eder.
MESH_YAZIM = True


def _MI():
    try:
        from . import mesh_ithal as MI
    except ImportError:                                   # modul dosya yolundan yuklendiyse
        import mesh_ithal as MI
    return MI


def duzenli_glb_bul(klasor, man):
    """Kullanicinin Blender'dan kaydettigi GLB (bkz. mesh_ithal.duzenli_glb_bul)."""
    return _MI().duzenli_glb_bul(klasor, man)


def mesh_farki(klasor, man, progress=None, doku_kaplari=None, gizle_eksik=False,
               hedef=None, hedef_silah=None, capraz_esleme=None):
    """Duzenlenmis GLB varsa kaynakla karsilastirir ve parca basina ROTA karari verir.
    SALT OKUNUR: forge yalniz 'rb' acilir. MESH_YAZIM kapaliysa rapor uretilir ama
    'yazilabilir' False doner (eski davranis, tek bayrakla geri alinabilir).
    `capraz_esleme` = {kaynak_parca: hedef_parca} (arayuzun SWAP PARTS penceresi);
    otomatik eslemeyi EZER ve yalniz eslenen parcalar yazilir."""
    p = _MI().plan(klasor, man, progress=progress, doku_kaplari=doku_kaplari,
                   eksikleri_gizle=bool(gizle_eksik), hedef=hedef, hedef_silah=hedef_silah,
                   capraz_esleme=capraz_esleme)
    if not MESH_YAZIM:
        p["yazilabilir"] = False
        p["kapali"] = True
        for k in p.get("parcalar") or []:
            k["_is"] = None
        p["sebep"] = ("mesh write-back is switched off in this build. The comparison above is "
                      "reported, not written.")
    return p


# ------------------------------------------------------------------ HAZIRLIK (encode)
def _hedef_rgba(j, progress=None):
    """Bir is kaydini oyunun bekledigi diziye cevirir (rol tersleri; modul basligi)."""
    rol, aile, W, H = j["rol"], j["aile"], j["W"], j["H"]
    if rol == "normal":
        arr, _ = _png_oku(j["dosya"])
        g = arr[..., 1]
        if DP.NORMAL_G_TERS:
            g = (255 - g).astype(np.uint8)
        out = np.zeros((H, W, 4), np.uint8)
        out[..., 0] = arr[..., 0]
        out[..., 1] = g
        # B: export bu kanali ATTI (Z, R/G'den kuruluyor) -> kullanicinin dokunmadigi
        # kanal vanilla'dan geri konur. 0 yazmak olculdu: ortalama 28,2 fark.
        van = vanilla_rgba(j["kap"], j["kap_tm"])
        b_kaynak = "vanilla"
        if van is not None and van.shape[:2] == (H, W):
            out[..., 2] = van[..., 2]
        else:
            out[..., 2] = 0
            b_kaynak = "zero (vanilla could not be read)"
        if j.get("gloss_dosya"):
            gl, _ = _gri_oku(j["gloss_dosya"])
            out[..., 3] = gl
        elif van is not None and van.shape[:2] == (H, W):
            out[..., 3] = van[..., 3]
        else:
            out[..., 3] = 255
        if aile == "BC1":
            return out[..., :3], {"karar": "normal_bc1",
                                     "gerekce": "the Workshop writes this BC1 slot with no "
                                                "alpha band, so the gloss band is not encoded."}
        return out, {"karar": "normal_yeniden_kuruldu",
                     "gerekce": "R kept, G re-inverted to the game's DirectX convention, blue band "
                                "restored from %s, alpha taken from the gloss file." % b_kaynak}
    if rol == "diffuse":
        # export alfayi DUSURDU -> alfa_politika vanilla'yi geri koyar (ya da kullanicininki)
        import alfa_politika as AP
        arr, karar = AP.dogru_alfali_rgba(j["dosya"], j["kap"], j["kap_tm"], W, H, aile,
                                          progress=progress, aile_olculdu=aile)
        return arr, karar
    # emissive / mask / ref: export RGBA'yi (vanilla alfasiyla) oldugu gibi yazdi. Dosya
    # hala RGBA ise aynen geri okunur; RGB kaydedildiyse / duz 255 alfa bastiysa alfa
    # kanali YOKTUR (PIL 255 uydurur) -> diffuse'teki politikanin aynisi: vanilla geri
    # konur. Olculdu (tur2 06/06b): eski yol alfa fark ort 105,6 / 247,9 (mask = bolge
    # maskesi siliniyordu); simdi 0. Vanilla cekilemezse REDDEDILIR (tara() ayni kapiyi
    # onay ekraninda gosterir; buraya dusmesi beklenmez, dusse de 255 basilmaz).
    arr, _ = _png_oku(j["dosya"])
    if aile == "BC1":
        return arr[..., :3], {"karar": "rgba_aynen",
                                    "gerekce": "the Workshop writes this BC1 slot with no "
                                               "alpha band, so the file's alpha is not encoded."}
    alfa_karar, _ = _ref_alfa_karari(j["dosya"], arr, aile)
    if alfa_karar in _ALFA_KULLANICI:
        return arr, {"karar": "rgba_aynen",
                     "gerekce": "the file carries its own alpha channel, so the RGBA image is "
                                "used as it is."}
    van = vanilla_rgba(j["kap"], j["kap_tm"])
    if van is None or van.shape[:2] != (H, W):
        raise ValueError("%s: %s" % (j["dosya_ad"], _ref_alfa_red_sebebi(rol)))
    arr[..., 3] = van[..., 3]
    return arr, {"karar": "rgba_vanilla_alfa",
                 "gerekce": "the file has no alpha channel (or a flat 255 one); this %s slot's "
                            "alpha band is game data, so it is restored from the game's own "
                            "texture and only the colour is written." % rol}


def _dds_hedef_rgba(j, progress=None):
    """Uyumsuz DDS -> slotun bicimine gidecek RGBA dizi (+ karar metni).

    ROL TERSI UYGULANMAZ: bir DDS zaten OYUN duzeninde kanallar tasir (normal'in G'si,
    gloss'un alfada olmasi dahil). PNG yolundaki `_hedef_rgba` donusumlerini burada
    tekrarlamak kullanicinin dosyasini BOZARDI."""
    dds = DD.dds_oku(j["dosya"])
    if not dds.get("ok"):
        raise ValueError(dds.get("sebep") or "this DDS file could not be read")
    arr = DD.dds_rgba(dds, 0)
    gerekce = ["the DDS is used as the picture source, channels as they are"]
    if (dds["W"], dds["H"]) != (j["W"], j["H"]):
        arr = np.asarray(Image.fromarray(arr, "RGBA").resize((j["W"], j["H"]),
                                                             Image.LANCZOS))
        gerekce.append("resized from %dx%d to %dx%d" % (dds["W"], dds["H"], j["W"], j["H"]))
    arr = np.ascontiguousarray(arr)
    if j["aile"] == "BC1":
        arr = arr.copy()
        arr[..., 3] = 255
        gerekce.append("this BC1 slot is written with no alpha band")
    return arr, {"karar": "dds", "gerekce": "; ".join(gerekce)}


def hazirla(rapor, progress=None):
    """Kabul edilen islerin DDS'lerini uretir -> (dds_dir, uretilen_listesi).
    Dosya adlari doku_enjekte2'nin (A) bicimidir: IC_<kap>_tm<kap>_<tm>_<WxH>_<WxH>_<AILE>.dds
    -- yani `plan()` bunlari kap ve TM indeksi olarak COZER."""
    # Klasor ADI degil TAM YOLU anahtar: iki farkli surucudeki "U_Edward_Fire"
    # ayni gecici klasoru paylasip birbirinin DDS'ini yazardi (_encode_design_dir
    # ayni kalibi kullaniyor).
    dds_dir = os.path.join(tempfile.gettempdir(), "OutfitWorkshop_3ddds_%s"
                           % hashlib.md5(rapor["klasor"].encode("utf-8")).hexdigest()[:10])
    if os.path.isdir(dds_dir):
        shutil.rmtree(dds_dir, ignore_errors=True)
    os.makedirs(dds_dir, exist_ok=True)
    uretilen = []
    n = len(rapor["yazilacak"])
    for i, j in enumerate(rapor["yazilacak"], 1):
        # --- DDS DOGRUDAN: kodlayici HIC calismaz, dosya yazicinin (A) adiyla kopyalanir.
        # Bloklar oyunun kendi bloklaridir; yeniden kodlamak yalniz kayip eklerdi.
        if j.get("kaynak") == "dds" and j.get("dds_rota") == "dogrudan":
            dds = os.path.join(dds_dir, C._slot_filename(j["kap"], j["kap_tm"], j["W"],
                                                         j["H"], j["aile"], ext="dds"))
            shutil.copyfile(j["dosya"], dds)
            j["dds"] = dds
            uretilen.append(dds)
            _log(progress, "  %s used as is - no re-encoding (%dx%d %s%s)  -- texture %d of %d"
                 % (j["dosya_ad"], j["W"], j["H"], j["aile"],
                    " sRGB" if j["srgb"] else "", i, n))
            continue
        est = C._encode_estimate_sec(j["aile"], j["W"], j["H"])
        _log(progress, "  encoding %s (%dx%d %s%s%s)  -- texture %d of %d"
             % (j["dosya_ad"], j["W"], j["H"], j["aile"], " sRGB" if j["srgb"] else "",
                (", ~%ds" % est) if est else "", i, n))
        arr, karar = (_dds_hedef_rgba(j, progress) if j.get("kaynak") == "dds"
                      else _hedef_rgba(j, progress))
        j["alfa_karari"] = karar.get("karar")
        _log(progress, "    alpha: %s" % karar.get("gerekce"))
        temiz = _temiz_png_yaz(arr, "%s_tm%d" % (str(j["kap"]).replace("0x", ""), j["kap_tm"]))
        dds = os.path.join(dds_dir, C._slot_filename(j["kap"], j["kap_tm"], j["W"], j["H"],
                                                     j["aile"], ext="dds"))
        _son = [-99]

        def _ilerle(f, _i=i, _n=n, _son=_son):
            genel = int(((_i - 1) + max(0.0, min(1.0, f))) * 100.0 / _n)
            if genel - _son[0] >= 2:
                _son[0] = genel
                _log(progress, "    encoding... %d/100" % genel)

        C._tex_encode(temiz, dds, j["srgb"], C._FMT_BCN[j["aile"]], progress, on_frac=_ilerle)
        j["dds"] = dds
        uretilen.append(dds)
    return dds_dir, uretilen


def plan_ozeti(dds_dir):
    """doku_enjekte2.durum ile ayni kapilar ama EKRANA BASMAZ: (isler, red).
    Forge yalniz 'rb' acilir."""
    _lf, isler, red, _mat = DE.plan(dds_dir)
    return isler, red


# ------------------------------------------------------------------ UYGULA (TEK YAZICI)
def uygula(klasor, progress=None, rapor=None, mesh=True):
    """tara -> (doku) hazirla + doku_enjekte2.uygula -> (mesh) mesh_ithal.uygula.

    SIRA ONEMLI: once DOKU, sonra MESH. Ikisi de yeni girisi arsivin SONUNA ekler ve
    her iki geri-alma deposu da kuyrugu ancak KENDI bloklari dosyanin tam sonunda
    dururken kirpabilir. Mesh en son eklendigi icin 'Revert all' once mesh'i (kuyruk
    kirpilir), sonra dokuyu (yeni kuyruk kirpilir) geri alir -> arsiv BAYT-BIREBIR
    eski haline doner. Ters sirada yazilsaydi doku bloklari mesh bloklarinin altinda
    kalir ve arsiv kalici olarak buyurdu (olculdu).

    Doner rapor + {yazilan_giris, dds_dir, mesh_sonuc}."""
    r = rapor or tara(klasor, progress)
    m_plan = r.get("mesh") or {}
    mesh_var = bool(mesh and m_plan.get("yazilabilir") and m_plan.get("yazilacak"))
    out = dict(r, yazilan_giris=0, dds_dir=None, mesh_sonuc=None)
    if not r["yazilacak"] and not mesh_var:
        return out
    if r["yazilacak"]:
        dds_dir, _uretilen = hazirla(r, progress)
        out["dds_dir"] = dds_dir
        isler, red = plan_ozeti(dds_dir)
        if red:
            for ad, sebep in red:
                r["red"].append({"dosya": ad, "sebep": sebep})
            _log(progress, "REFUSED by the writer's own gates: %d file(s)." % len(red))
        out["yazici_red"] = red
        if isler:
            _log(progress, "- writing textures via the single writer (doku_enjekte2) ...")
            w = DE.uygula(dds_dir) or {}
            if w.get("red_sebep"):
                raise RuntimeError("The writer refused: %s" % w["red_sebep"])
            yazilan = w.get("harici", 0) + w.get("gomulu", 0)
            if yazilan == 0 and not mesh_var:
                raise RuntimeError("Nothing was written to the game archive.")
            out["yazilan_giris"] = yazilan
            out["yazici"] = w
            C._invalidate_cache()
    if mesh_var:
        _log(progress, "- writing the edited model (%d part(s)) ..." % m_plan["yazilacak"])
        ms = _MI().uygula(m_plan, progress=progress,
                          etiket="IMPORT 3D %s" % (r.get("anahtar") or ""))
        out["mesh_sonuc"] = ms
        for x in ms.get("red") or []:
            if x not in (r.get("red") or []):
                r["red"].append({"dosya": x.get("ad") or x.get("dosya"), "sebep": x["sebep"]})
        C._invalidate_cache()
    return out


# ------------------------------------------------------------------ ONAY METNI
# LOD BANTLARI ve PAYLASIM: iki alan da mesh planindan (mesh_ithal.plan) gelir ve
# ONAYDAN ONCE basilir. Ikisi de ISTEGE BAGLI okunur -- plan bu alanlari uretmiyorsa
# (eski surum, ya da bant/paylasim olcumu yapilamayan bir hedef) hicbir satir basilmaz
# ve rapor eskisi gibi kurulur. Sozlesme:
#   p["bant_ozeti"]       = {"grup": N, "yazilacak_bant": M, "atlanan_bant": K}
#   p["paylasim_uyarisi"] = [{"ad": parca adi, "paylasan": N}]   (N >= 2 olanlar)
def _bant_satirlari(p):
    """Silahin kac MESAFE BANDINA cizildigi ve kacina yazildigi.

    Neden gerekli: bir silahin tek mesh'i yoktur (Weapon_Sword_19 = 2 grup x 4 LOD
    bandi). Bantlarin cogunda desen [1.0, 1.0, 4.0, 32.0] m'dir; yalniz birincil banda
    yazilirsa duzenlenmis sekil 1 metreden oteye cizilmez ve kullanici "yama tutmadi"
    sanir. Tek bantli hedefte (33 grup tek proxy) cumle GURULTUDUR -> basilmaz."""
    oz = p.get("bant_ozeti")
    if not isinstance(oz, dict):
        return []
    try:
        yaz = int(oz.get("yazilacak_bant") or 0)
        atla = int(oz.get("atlanan_bant") or 0)
        grup = int(oz.get("grup") or 0)
    except (TypeError, ValueError):
        return []
    top = yaz + atla
    # yaz <= 0: yazilan bant yok -> "written to 0 of them" demek yerine SUS (hukum
    # cumlesi zaten "Nothing" tarafini anlatiyor). top < 2: tek proxy'li hedef, gurultu.
    if top < 2 or yaz <= 0:
        return []
    nerede = (" across %d group(s)" % grup) if grup > 0 else ""
    # KIYAFET BANTLARI (2026-09-08): kiyafet plani `oge: "item"` tasir (mesh_ithal.plan);
    # silah sozlesmesi alan eklemez ve eski cumle birebir kalir.
    ne = "item" if oz.get("oge") == "item" else "weapon"
    if not atla:
        return ["  BANDS  This %s is drawn at %d distance bands%s; the same shape is written "
                "to all of them, so it looks the same up close and far away." % (ne, top, nerede)]
    return ["  BANDS  This %s is drawn at %d distance bands%s; the same shape is written to "
            "%d of them. The other %d keep the game's original shape, so the %s changes back "
            "to it when the camera moves away." % (ne, top, nerede, yaz, atla, ne)]


def _paylasim_satirlari(p):
    """Yazilacak parcayi baska ogeler de ciziyorsa SOYLE (gizleme yolundaki SHARED ile
    ayni sozcukler: "N other item(s) draw this same mesh")."""
    u = p.get("paylasim_uyarisi")
    if not isinstance(u, (list, tuple)) or not u:
        return []
    L = []
    for x in list(u)[:6]:
        if not isinstance(x, dict):
            continue
        try:
            n = int(x.get("paylasan") or 0)
        except (TypeError, ValueError):
            continue
        if n < 2 or not x.get("ad"):
            continue
        L.append("  SHARED %s - %d other item(s) draw this same mesh, so editing it changes them "
                 "too." % (x["ad"], n))
    if len(u) > 6 and L:
        L.append("  ... and %d more shared part(s)" % (len(u) - 6))
    return L


def rapor_metni(r):
    """Onaydan ONCE gosterilecek duz Ingilizce satirlar (arayuz confirm penceresi)."""
    L = []
    ad = r.get("gorunen_ad") or r.get("anahtar") or "this item"
    L.append("IMPORT 3D - %s" % ad)
    L.append("Folder: %s" % r["klasor"])
    L.append("")
    m = r.get("mesh") or {}
    L.extend(_MI().rapor_satirlari(m))
    L.extend(_bant_satirlari(m))
    L.extend(_paylasim_satirlari(m))
    if m.get("kapali") and m.get("sebep"):
        L.append("  NOT WRITTEN - " + m["sebep"])
    L.append("")
    L.append("TEXTURES")
    yk = r.get("yeniden_kaydedilen") or []
    # ozet parantezi: piksel-birebir yeniden kayitlar ile BC1'in dusen alfasi yuzunden
    # atlananlar AYRI sayilir -- ikincisinde "pixel-identical" dogru degil (renk birebir,
    # alfa farkli) ve atlamanin sebebi de baskadir.
    _ayrinti = []
    _n_duz = sum(1 for x in yk if not x.get("alfa_yoksayildi"))
    _n_alfa = len(yk) - _n_duz
    if _n_duz:
        _ayrinti.append("%d of them re-saved but pixel-identical" % _n_duz)
    if _n_alfa:
        _ayrinti.append("%d with only an alpha change, which is not written to a BC1 slot" % _n_alfa)
    L.append("  %d repainted, %d untouched (skipped%s), %d refused."
             % (len(r["yazilacak"]), r.get("degismeyen", 0),
                (", " + ", ".join(_ayrinti)) if _ayrinti else "", len(r["red"])))
    for j in r["yazilacak"][:12]:
        # BC1'in dusen alfasi (G8b) WRITE satirinda da durur: NOTE listesi 4 satirla sinirli,
        # boylece cok uyarili bir raporda bile kullanici hangi dosyada oldugunu gorur.
        L.append("  WRITE  %s  (%dx%d %s%s%s)"
                 % (j["dosya_ad"], j["W"], j["H"], j["aile"], " sRGB" if j["srgb"] else "",
                    ", colour only - painted alpha not written" if j.get("bc1_alfa_dusuyor") else ""))
    if len(r["yazilacak"]) > 12:
        L.append("  ... and %d more" % (len(r["yazilacak"]) - 12))
    # sha'si degismis ama pikseli canli slotla birebir dosyalar (G3b): arayuz SKIP
    # onekini 'atla' sinifiyla boyar (arayuz.html i3dSatirSinifi)
    for x in yk[:12]:
        if x.get("alfa_yoksayildi"):
            # "cannot be stored" DEME: BC1 blogu 1-bit punch-through tasiyabilir, yazmayan
            # Workshop'un kendi politikasi (alfa_politika 'bc1_opak'). Dogru ifade bu.
            L.append("  SKIP   %s  (colour identical to the game's texture; the Workshop writes "
                     "this BC1 slot with no alpha band, so the alpha you painted is discarded)"
                     % x["dosya_ad"])
        else:
            L.append("  SKIP   %s  (re-saved but pixel-identical to the game's texture, "
                     "not re-encoded)" % x["dosya_ad"])
    if len(yk) > 12:
        L.append("  ... and %d more skipped" % (len(yk) - 12))
    for x in r["red"][:8]:
        L.append("  REFUSED %s" % x["dosya"])
        L.append("          %s" % x["sebep"])
    if len(r["red"]) > 8:
        L.append("  ... and %d more refused" % (len(r["red"]) - 8))
    for u in r.get("uyari", [])[:4]:
        L.append("  NOTE   %s" % u)
    L.append("")
    L.append("WHAT WILL BE WRITTEN")
    nm = int((r.get("mesh") or {}).get("yazilacak") or 0) if (r.get("mesh") or {}).get("yazilabilir") else 0
    # EKSIK PARCA + ISARETSIZ KUTUCUK: bu hukum 2026-09-06'ya kadar kosulsuz "Nothing."
    # diyordu. Kullanicinin Blender'da SILDIGI parcalar varken bu cumle DOGRU ama EKSIK:
    # yazacak bir sey gercekten yok, ama tek bir kutucuk isaretlenince olusur. Dort kisi
    # (loe, Maxx, cOnstnt ve bir kisi daha) raporu okuyup vazgecti. Cumle artik kutucugu
    # ADIYLA anar, sayiyi ve parca adlarini yazar. Rapor satirlari sozluge GIRMEZ
    # (arayuz.html i3dSatirSinifi aciklamasi) -> yeni ceviri maliyeti yok.
    _mp = r.get("mesh") or {}
    _kalan = [e for e in (_mp.get("eksik") or []) if not e.get("gizle")]
    if not r["yazilacak"] and not nm and _kalan:
        _adlar_ = ", ".join(str(e.get("ad")) for e in _kalan[:6]) \
            + (" ..." if len(_kalan) > 6 else "")
        if _mp.get("capraz"):
            # capraz: parcalar kullanicinin dosyasindan SILINMEDI, kaynak ogede hic yoktu
            L.append("  Nothing yet - %d part(s) of the target have no part in the source item: "
                     "%s. Tick \"Hide parts missing from my file\" below and they are removed "
                     "from the game in one write." % (len(_kalan), _adlar_))
        else:
            L.append("  Nothing yet - %d part(s) are missing from your file: %s. Tick \"Hide "
                     "parts missing from my file\" below and they are removed from the game in "
                     "one write." % (len(_kalan), _adlar_))
        _nred = len(r["red"]) + len(_mp.get("red") or [])
        if _nred:
            L.append("  Nothing else can be written: %d change(s) were refused (see REFUSED "
                     "above) and every other file is unchanged." % _nred)
        else:
            L.append("  Nothing else changed, so nothing else will be written.")
        L.append("  Until you tick that box the game archive is not touched, and Revert puts "
                 "every hidden part back.")
    elif not r["yazilacak"] and not nm:
        L.append("  Nothing. Every file is either unchanged or refused; the game archive is not "
                 "touched.")
    else:
        L.append("  %d texture slot(s) and %d mesh part(s) go into DataPC_boot.forge."
                 % (len(r["yazilacak"]), nm))
        L.append("  Nothing else is touched. Every write is recorded, and Revert puts the archive "
                 "back to how it is right now.")
    return L
