# -*- coding: utf-8 -*-
"""iskelet.py -- pisirilmis rig tablosu (rigler/*.json) + rig/palet uygunluk kapisi.

Plan: tasarim/3D_DISA_AKTARMA_PLANI.md §3.1 / §5 Adim 3.

Kanit tabani (kesif3d/iskelet_kanit_v3.py, iskelet_kanit4.py, p0_walpole_glb.py):
  * Skeleton 0x02242390EC10 = 326 kemik, ad crc32-dogrulamali 326/326, tek kok (Reference).
  * Ebeveyn = J alanindan DFS (J = torun sayisi; her yeni kemik yigindaki TUM
    atalarin sayacini dusurur). Yerelden kurulan global vs model_pos 1,6e-6.
  * Palet 4x4 = glTF inverseBindMatrices VERBATIM (sutun-major; satir-major goruntusu
    ham 4x4'un transpozu). Agac-vs-IBM sapmasi 3,8e-6 (Walpole 45 kemik, el 106 kemik).
  * Iskelet uzayi -> mesh uzayi:  p_sk = C . p_mesh + o
        C = [[0,-1,0],[1,0,0],[0,0,1]]   o = (0, 0, -0.964)
    (konvansiyon A: perm [1,0,2], isaret [-1,1,1], oteleme z = -0,96399999; medyan 3,1e-7)
    glTF'te SkeletonRoot dugumu matrix = Cinv, altinda 326 rig dugumu.

Bu modul oyun dosyasina DOKUNMAZ: yalniz rigler/<ad>.json okur.
Bagimlilik: numpy + stdlib.
"""
import json
import os

import numpy as np

SURUM = 1
BURA = os.path.dirname(os.path.abspath(__file__))
RIGLER = os.path.join(BURA, "rigler")

# --- iskelet uzayi <-> mesh uzayi sabitleri (olculdu: kesif3d/iskelet_kanit3.json C_kok_dugum_donusumu)
C = np.array([[0.0, -1.0, 0.0],
              [1.0, 0.0, 0.0],
              [0.0, 0.0, 1.0]])
O = np.array([0.0, 0.0, -0.964])
Cm = np.eye(4)
Cm[:3, :3] = C
Cm[:3, 3] = O
Cinv = np.linalg.inv(Cm)          # SkeletonRoot dugumunun matrisi (glTF)

_ONBELLEK = {}


# ------------------------------------------------------------------ matematik
def qmat(q):
    """Birim quaternion (x,y,z,w) -> 3x3 donme matrisi (sutun-vektor)."""
    x, y, z, w = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def mat4(p, q):
    """Oteleme p + quaternion q -> 4x4 (sutun-vektor, oteleme [:3,3])."""
    m = np.eye(4)
    m[:3, :3] = qmat(q)
    m[:3, 3] = p
    return m


# ------------------------------------------------------------------ hiyerarsi
def ebeveyn_j_dfs(J):
    """J alanindan ebeveyn listesi (p0_walpole_glb.py:49-54 algoritmasi birebir).

    J[i] = i'nin torun sayisi. Serilestirme sirasi DFS oldugu icin: yiginin
    tepesindeki sayaci 0 olan atalar dusurulur, kalan tepe = ebeveyn, sonra
    yigindaki TUM atalarin sayaci 1 azaltilir ve i yigina itilir."""
    n = len(J)
    eb = [-1] * n
    stack = []
    for i in range(n):
        while stack and stack[-1][1] == 0:
            stack.pop()
        if stack:
            eb[i] = stack[-1][0]
        for s in stack:
            s[1] -= 1
        stack.append([i, int(J[i])])
    return eb


# ------------------------------------------------------------------ rig yukleme
def rig_yukle(ad="edward_326"):
    """rigler/<ad>.json -> rig sozlugu (onbellekli).

    Donen alanlar: ad, iskelet, forge, sha16, n, adlar[list], idler[np.uint32],
    ebeveyn[list], J[list], yerel_pos(n,3), yerel_quat(n,4), model_pos(n,3),
    model_quat(n,4), id2i{id:i}, kok(int), kemikler (ham JSON kayitlari)."""
    if ad in _ONBELLEK:
        return _ONBELLEK[ad]
    yol = os.path.join(RIGLER, ad + ".json")
    with open(yol, "r", encoding="utf-8") as f:
        T = json.load(f)
    kem = T["kemikler"]
    n = len(kem)
    ebeveyn = [int(k["ebeveyn"]) for k in kem]
    kokler = [i for i, e in enumerate(ebeveyn) if e < 0]
    rig = dict(
        ad=ad, iskelet=T.get("iskelet"), forge=T.get("forge"), sha16=T.get("sha16"),
        n=n, kemikler=kem,
        adlar=[k["ad"] for k in kem],
        idler=np.array([int(k["id"]) for k in kem], dtype=np.uint32),
        ebeveyn=ebeveyn,
        J=[int(k["J"]) for k in kem],
        yerel_pos=np.array([k["yerel_pos"] for k in kem], dtype=np.float64),
        yerel_quat=np.array([k["yerel_quat"] for k in kem], dtype=np.float64),
        model_pos=np.array([k["model_pos"] for k in kem], dtype=np.float64),
        model_quat=np.array([k["model_quat"] for k in kem], dtype=np.float64),
        id2i={int(k["id"]): i for i, k in enumerate(kem)},
        kok=kokler[0] if len(kokler) == 1 else None,
        kok_sayisi=len(kokler),
    )
    _ONBELLEK[ad] = rig
    return rig


def global_matrisler(rig):
    """Yerel pos/quat + ebeveyn zinciri -> (n,4,4) ISKELET uzayi globalleri.

    global_i = global_ebeveyn @ yerel_i  (kok icin yerel = global).
    Mesh uzayi dugum globali = Cinv @ global_i (glTF SkeletonRoot matrix=Cinv)."""
    n = rig["n"]
    eb = rig["ebeveyn"]
    G = np.zeros((n, 4, 4), dtype=np.float64)
    for i in range(n):
        Gl = mat4(rig["yerel_pos"][i], rig["yerel_quat"][i])
        G[i] = (G[eb[i]] @ Gl) if eb[i] >= 0 else Gl
    return G


# ------------------------------------------------------------------ palet yardimcilari
def ibm_satir_major(palet_mt):
    """Ham palet 16 float (kc,4,4) -> glTF IBM'in satir-major goruntusu (kc,4,4).

    Palet floatlari glTF'e VERBATIM sutun-major yazilir; numpy'da satir-major
    matris olarak kullanmak icin transpoz alinir (p0_walpole_glb.py:69)."""
    mt = np.asarray(palet_mt, dtype=np.float64)
    return np.transpose(mt, (0, 2, 1))


def palet_inv_ibm(palet_mt):
    """inv(IBM) = palet kemiginin MESH uzayindaki globali (kc,4,4)."""
    return np.linalg.inv(ibm_satir_major(palet_mt))


def duz_dugum_matrisleri(palet_mt):
    """Duz (hiyerarsisiz) palet dugumu icin SkeletonRoot altina yazilacak matris:
    Cm @ inv(IBM)  -> dugum globali (Cinv @ bu) = inv(IBM) olur (plan §3.2 / §5 Adim 3)."""
    return np.einsum("ab,kbc->kac", Cm, palet_inv_ibm(palet_mt))


# ------------------------------------------------------------------ uygunluk kapisi
def rig_uygunluk(rig, palet_crc, palet_mt, tol=5e-3):
    """Mesh paletinin rig hiyerarsisine BAGLANABILIR olup olmadigini olcer.

    palet_crc : kc adet kemik crc32 (int ya da '0x%08X' str)
    palet_mt  : (kc,4,4) ham palet floatlari (mesh_yapisal.oku -> G['matris'])
    Eslesen her kemik icin  |Cinv . G_rig[i]  -  inv(IBM_palet)|  maks (metre).
    tol altinda -> hiyerarsik (uygun=True); degilse parca DUZ palet-armature'a
    duser (her palet kemigi SkeletonRoot altinda matrix = Cm . inv(IBM)).

    Donus: {eslesen, addon, hata_maks, uygun, hata_medyan, eslesme[list: rig i | None],
            hata[list], addon_crc[list], tol}"""
    crcs = [int(c, 16) if isinstance(c, str) else int(c) for c in palet_crc]
    mt = np.asarray(palet_mt, dtype=np.float64)
    if mt.shape != (len(crcs), 4, 4):
        raise ValueError("palet_mt shape %r != (%d,4,4)" % (mt.shape, len(crcs)))
    id2i = rig["id2i"]
    eslesme = [id2i.get(c) for c in crcs]
    G = global_matrisler(rig)
    invIBM = palet_inv_ibm(mt)
    hata = []
    for pi, a in enumerate(eslesme):
        if a is None:
            continue
        hata.append(float(np.abs(Cinv @ G[a] - invIBM[pi]).max()))
    eslesen = sum(1 for a in eslesme if a is not None)
    addon = len(eslesme) - eslesen
    hata_maks = max(hata) if hata else None
    uygun = bool(eslesen > 0 and hata_maks is not None and hata_maks <= tol)
    return dict(eslesen=eslesen, addon=addon, hata_maks=hata_maks, uygun=uygun,
                hata_medyan=float(np.median(hata)) if hata else None,
                eslesme=eslesme, hata=hata,
                addon_crc=["0x%08X" % c for c, a in zip(crcs, eslesme) if a is None],
                tol=float(tol))
