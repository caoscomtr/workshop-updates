# -*- coding: utf-8 -*-
"""export3d.doku_png -- materyal dokularini glTF icin PNG'ye cozer (Plan §5 Adim 5).

Tek giris: ``materyal_dokulari(mat_id, klasor, progress)``.

  * Okuma yolu: ``_slot_tanim`` (slot tanimi) -> ``mip0_oku`` (level-0 BC bloklari,
    DORT yol; asagidaki "LEVEL-0 KURTARMA YOLLARI" blogu) -> ``bc_decode_rgba``
    (imagecodecs, yoksa texture2ddecoder YEDEGI; FLIP YOK). ``mip0_oku`` eskiden ``outfit_core.slot_mip0_bc`` ile
    BIREBIR ayniydi; 09-03 olcumu o yolun iki kusurunu gosterdi (harici mip kimliginde
    yanlis onek, gomulu havuzda yaklasik ic-dosya siniri) ve bu modul ikisini de
    YEDEK YOL olarak duzeltir -- `outfit_core`a DOKUNULMADI (yazma yolu paylasiyor).
    Forge tanitiscisi paylasilan ``outfit_core._forge()``; burada ikinci tanitici
    ACILMAZ, ``release_forge`` de CAGRILMAZ (kapatma sahne.py'nin ``finally``sindedir).
  * diffuse  -> sRGB PNG (RGB)                        TEX_<id>_s<slot>_diffuse.png
  * normal   -> ``normal_z_kur``: Z yeniden kurulmus RGB  TEX_<id>_s<slot>_normal.png
                + alfa (gloss bandi) L PNG                  TEX_<id>_s<slot>_gloss.png
  * emissive / mask -> referans RGBA PNG          TEX_<id>_s<slot>_emissive|mask.png
  * ``mip0_oku`` dort yolun dordunde de None (ya da kisa mip) -> slot ATLANIR,
    ``atlanan``a sebebiyle yazilir; materyal o dokusuz kalir. (Eskiden "gomulu-mip
    kucuk doku, olc: 32x64 BC1" bu kovaya dusuyordu; 09-03'ten beri ``embedded_k1``
    yolu onlari okuyor -- 25 kiyafet + 52 CHR_* kapsaminda 0 slot kaldi.)
  * GECERLILIK KAPISI (``gecerlilik``; 09-03): level-0 BC7 blok mod histogrami rastgele
    (mod0+1 > %50 / gecersiz > %0,5) ya da GOMULU level-0 cozulunce gurultu (komsu-fark
    ortalamasi > 25) -> slot ATLANIR ("... level-0 not decodable (...)"), dosya yazilmaz.
    Kalibrasyon 77 anahtar / 1.819 slot. ``mip0_oku`` level-0'in kaynagini (hangi yol)
    da soyler. ⚠️ Kapinin ILK sebebi (Edward_Assassin HiddenBladeL/R 5 slot) 09-03'te
    COZULDU: o slotlar bozuk oyun varligi degildi, ESKI gomulu cipa kuralinin urettigi
    kaymis okumaydi; ``embedded_k1`` yolu ayni slotlarda temiz piksel veriyor
    (komsu-fark 33,6->9,3 · 29,2->1,9 · 36,0->6,9 · 33,5->10,2 · 36,2->6,9) ve artik
    kapidan GECIYORLAR. Kapi yine de durur: son care ``embedded`` yolu icin gecerli.
  * BC COZUCU YEDEGI (09-12): secim ``outfit_core._bcn_cozucu`` (once imagecodecs, ImportError/
    OSError'da texture2ddecoder); ``bc_decode_rgba`` EXPORT tarafinin sarmalayicisidir: kullanilan
    cozucuyu olcer (slot kaydinda ``cozucu``) ve texture2ddecoder secildiyse olculmus iki spec
    sapmasini duzeltir (BC3 c0<=c1 renk blogu, BC1 3-renk indeks 3 alfasi; asagidaki "BC COZUCU"
    blogu). OLCULDU (bu makine): imagecodecs'in imzasiz ``_bcn.pyd``si Smart App Control tarafindan
    BLOKLU; ``from imagecodecs import bcn_decode`` HATA VERMEZ (stub), hata ilk CAGRIDA
    ``DelayedImportError`` (ImportError alt sinifi) -- secim bu yuzden import'a degil CAGRIYA bakar.
    7 gercek dokuda (BC1 x2, BC3 x2, BC7 x3) Pillow DDS cozucusuyle RGB bayt-birebir
    (testler/test_bcn_cozucu.py). Iki cozucu de yoksa ImportError (SESSIZ DEGIL).
  * Materyal basina 1 kez (modul onbellegi); PNG dogrudan diske
    (2048^2 RGBA ~ 16 MB/slot bellek).

Dosya adi oneki ``TEX_`` BILINCLI: ``outfit_core._SLOT_RE`` bu adi TANIMAZ, yani
bu klasor APPLY akisinda yanlislikla secilse bile aday uretmez (kapi d:
``_design_adaylari(klasor) == []``).

SLOT ROLU (plandan sapma, olculdu 2026-09-03): plan s0/s3 sabitini yazar; olcum rolun slot
indeksine gore SABIT OLMADIGINI gosterdi. Rol artik TAHMIN EDILMIYOR, VARLIK ADINDAN OKUNUYOR
(``rol_karar``; ayrinti icin asagidaki "ROL KAYNAGI" bolumu):
   1. ``doku_adi`` -- ic dosya sarmalayicisindaki karistirilmis ad, K1 ad sifresi cozulerek
      (``ad_coz``). 25 kiyafet + 52 CHR_*'in 1.347 tekil dokusunun 1.347'sinde okundu.
   2. ad okunamazsa ``imza_rolu`` -- sRGB bayragi + piksel istatistigi (%98,44).
   3. o da yoksa baglama yuvasi (TS'te %100, material'de %97,03).
Karari veren olcumler her slot kaydinda: ``imza`` (ort/std/luminans/gri/alfa/srgb/aile) ve
``rol_ayrinti`` (okunan ad, imza rolu + sebebi, yuva rolu, varsa ``catisma``). Dosya adi
KESIN role gore verilir. ``rol_kaynagi``: 'asset name' | 'pixel signature' | yuva kaynagi.
ESKI DAVRANISLA FARK (474 materyal / 1.347 slot): 1.328 slot AYNI rol · 19 slot degisti --
1.198 TextureSet slotunun HEPSI ayni (yuva tablosu dogruymus), 648 kiyafet material slotunun
643'u ayni; degisen 5'i Edward_Assassin'in 3 yuvali HiddenBlade L/R + Mannequin materyalleri
(Emissive yuvasi olmadigi icin sabit tablo kayiyordu; normal haritasi 'mask' diye yaziliyor,
GLB'ye normal HIC girmiyordu). Kalan 14 degisiklik CHR materyallerinde.

TEXTURESET YEDEGI (plandan sapma, olculdu): indeksin 487 tekil materyalinin
169'unda (25 kiyafette 13, Fire'in 4 materyalinin 2'si) govdede HIC TextureMap
blogu yok; materyal dokularini bir **TextureSet** (0xD70E6670) kaynagina u64
referansla tasiyor. 168/169'unda referans bulundu. TextureSet govdesi
``[01] + 14 x [tag u8][id u64] + u32`` (ansiklopedi DOKU_ENVANTERI.md §1/§5;
110/110 sette dokular.db `setler` ile birebir). Slot rolleri olculmus:
0 Diffuse · 1 Normal · 3 Height · 4 Emissive · 5 Transmission · 6 Occlusion ·
7 Mask1 · 8 Mask2 · 12 Mask0 · 13 DiffuseAlpha. Her slotun tanimi ya
TextureSet kaynagindaki gomulu TextureMap blogudur (326 slot) ya da dokunun
kendi TextureMap (0xA2B7E917) girisi (50 slot); ikisi de ``slot_mip0_bc`` ile
okunur. TextureSet 58 materyalde paylasiliyor -> PNG'ler SET kimligiyle
adlandirilir (``TEX_<tsid>_ts<slot>_<rol>.png``) ve set basina 1 kez cozulur.
"""
import os
import struct
import time

import numpy as np
from PIL import Image
from PIL.PngImagePlugin import PngInfo

import outfit_core as C
import doku_enjekte2 as DE            # AILE_BLOK (blok bayt sayisi), tm_bloklari

SURUM = 1
ONEK = "TEX_"

TIP_TEXTURESET = 0xD70E6670           # ansiklopedi: TextureSet (Material -> 14 doku yuvasi)
TIP_TEXTUREMAP = 0xA2B7E917           # ansiklopedi: TextureMap (tek doku tanimi + gomulu mip)
TS_IMZA = struct.pack("<I", TIP_TEXTURESET)
TS_SLOT_SAYISI = 14

# katalog rol metni -> anahtar
ROL_ANAHTAR = {
    "Colour (diffuse)":     "diffuse",
    "Surface (normal)":     "normal",
    "Glow map (LOCKED)":    "emissive",
    "Region mask (LOCKED)": "mask",
}
# katalog disi materyal icin plandaki slot sabiti
VARSAYILAN_ROL = {0: "diffuse", 1: "emissive", 2: "mask", 3: "normal"}
# TextureSet yuva rolleri (DOKU_ENVANTERI.md §5, adin son ekiyle %99,8-100 olculmus)
TS_SLOT_ROL = {0: "diffuse", 1: "normal", 2: "orbis", 3: "height", 4: "emissive",
               5: "transmission", 6: "occlusion", 7: "mask", 8: "mask2",
               12: "mask0", 13: "diffusealpha"}
# sonuc sozlugunde tekil anahtari olan roller; digerleri `diger` listesine gider
ANA_ROLLER = ("diffuse", "normal", "emissive", "mask")

# ================================================== ROL KAYNAGI: VARLIK ADI (olculdu 2026-09-03)
#
# Rol artik TAHMIN EDILMIYOR, OKUNUYOR. Her ic dosya sarmalayicisi
# `[tipCrc u32][boyut u32][adLen u32][AD adLen B][flag u8][id u64][tipCrc u32]` bir AD tasir;
# ad duz ASCII degil, 8 baytlik ECB blok sifresiyle karistirilmistir. Sifre ANSIKLOPEDIDE
# KIRILMIS (ansiklopedi projesi, formatlar\k1_isimler\cozucu.py; 9171/9171 blok bayt-dogrulanmis):
#     X = rotr64(sifre, 19);  duz = ((X - K) mod 2^64) XOR MASK
# Kuyruk (adLen mod 8) 3/5/6/7 ise SON 1-3 BAYT cozulemez ve '?' olur; rol kelimesi adin
# SONUNDAN once geldigi icin ("..._NormalMap" -> "..._NormalMa?") ROL HER ZAMAN OKUNUR.
#
# OLCUM (25 kiyafet + 52 CHR_*, 474 materyal, 1.347 TEKIL doku, hepsi cozuldu):
#   * 1.347/1.347 dokunun adi canli forge'dan okundu (dis veri tabani GEREKMEZ).
#     704'u ansiklopedi `dokular.db`nin "kanitli" adiyla BIREBIR; kalan 643'un tek farki
#     ansiklopedinin ngram ile TAMAMLADIGI 1-3 baytlik kuyruk ('...DiffuseMa?' vs '...DiffuseMap').
#   * 1.347/1.347'sinde rol kelimesi tam okundu (Diffuse/Normal/Emissive/Mask0/Mask1/Mask2;
#     1 ad yalin "MaskMap"). Dagilim: normal 340 · diffuse 334 · mask1 332 · emissive 330 ·
#     mask2 6 · mask0 4 · yalin mask 1.
#   * BAGIMSIZ DOGRULAMA -- TextureMap tanimindaki sRGB BAYRAGI: adi Diffuse olan 334 dokunun
#     334'unde srgb=1, adi Diffuse OLMAYAN 1.013 dokunun 0'inda srgb=1. Iki olcum (ad + bayrak)
#     1.347/1.347 uyusuyor; catisma yok. Bu yuzden srgb bayragi adsiz durumda yedek imza.
#
# BAGLAMA YUVASI HALA ISE YARIYOR AMA TEK BASINA YETMIYOR (ayni korpus):
#   * TextureSet yolu: 1.198/1.198 slotta yuva no ile ad AYNI rolu veriyor (yuva 0 diffuse ·
#     1 normal · 4 emissive · 7 mask1 · 8 mask2). Yuva tablosu TS yolunda %100.
#   * Material yolu: 1.307/1.347 (%97,03). Yanlislar yapisal: (a) 3 yuvali materyaller
#     (HiddenBlade, Mannequin) -- Emissive yuvasi YOK, sonraki roller kayiyor; (b) 8 yuvali
#     materyaller (Armor_YasukeIconic) -- ikinci dortlu 4..7'de tekrar ediyor; (c) permutasyon
#     (CHR_Shared_Cloth_A: s0 Normal · s1 Diffuse · s2 Emissive · s3 Mask1).
# PIKSEL ISTATISTIGI TEK BASINA DAHA KOTU: srgb + (R,G ~128) + (BC1/parlak) kurali 1.326/1.347
# (%98,44) -- yuva kuralindan iyi, addan kotu. Bu yuzden sira: AD -> srgb -> piksel -> yuva.
#
# SACIN DIFFUSE'U YOKTUR (olculdu, "sac dokusu yanlis rolde" savinin cevabi): 34 tekil
# TextureSet'in 28'i {0,1,4,7} (diffuse+normal+emissive+mask1), 6'si {1,7,8} -- ve bu 6'nin
# hepsi Hair_S_Short/Long/Braid/Curly, Beard_S_Long, Hair_S_LashesBrows. Sacin yuva 1 dokusu
# GERCEKTEN normal haritasidir: srgb=0 · R ortalamasi 128,5 (std 56,8) · G 129,7 (std 10,7) ·
# B SABIT 128 (std 1,44 -- kullanilmayan kanal; kumas normalinde ayni yerde sabit 0) ·
# alfa = sac kartlarinin kesim maskesi. Kanal kanal bakildiginda R telin eninde x turevi,
# G boyunda y, B duz. Yuva 7/8 ise maske: yuva 7'de B SABIT 255 (std 0.0) -- normal haritasi
# olamaz; yuva 8 birim vektor (0,1,0) yani tel yonu (anizotropi). Sacin rengi dokudan degil
# materyal tonundan gelir; export'ta baseColor'in doku ile DOLMAMASI ROL HATASI DEGIL, sacin
# diffuse dokusunun OLMAMASIDIR (`sonuc["diffuse_yok_sebep"]`).
# ⤷ 2026-09-04: bu ton BULUNDU ve artik `baseColorFactor` olarak yaziliyor -- asagidaki
#   "MATERYAL TONU" blogu. Sac kartlari artik BEYAZ CIKMIYOR.
#
# ad -> rol (ilk eslesen kazanir; Mask1 -> "mask" BILINCLI: eski dosya adlari korunsun)
ROL_ADI = (("diffusealpha", "diffusealpha"), ("diffuse", "diffuse"), ("normal", "normal"),
           ("emissive", "emissive"), ("mask0", "mask0"), ("mask1", "mask"), ("mask2", "mask2"),
           ("height", "height"), ("occlusion", "occlusion"), ("transmission", "transmission"),
           ("orbis", "orbis"), ("specular", "specular"), ("mask", "mask"))
_AD_MASK = 0x2F4C6E1332104572
_AD_K = 0xFF0CCB0A1F6F1A0B
_AD_MB = _AD_MASK.to_bytes(8, "little")
_AD_KB = _AD_K.to_bytes(8, "little")
# ARTIK (kuyruk) ALT-BLOK SABITLERI -- 2026-09-07'de olculdu, K1 ad sifresinin
# son 1-3 bayti COZULDU. Kuyruk (r = adLen % 8) 4/2/1 baytlik alt-bloklara ayrilir;
# alt-blok (genislik W bayt, kuyruk ici bayt ofseti q) icin
#     duz = ((rotr(sifreli, 19 mod 8W, 8W) - KK) & m) ^ MM
#   KK = K'nin DUSUK W bayti (konumdan BAGIMSIZ)
#   MM = MASK'in q. bayttan baslayan W bayti (KONUMSAL)
#   tek istisna (W=1, q=2): MM'nin 7. biti ters -> 0x10 degil 0x90 (olculdu; bu
#   deger (KK=0x8B, MM=0x10) ciftine ozdestir, cikti ASCII kalsin diye sart).
# Kanit: 3.887/3.887 ad ICINDEKI kimlik tekrariyla birebir; 199.827 kuyrukta %100
# yazdirilabilir ASCII; MotionCloth capalarinda r=3/6/7 icin 274/274.
_AD_ALT = {
    # (W, q): (rot, KK, MM)
    (8, 0): (19, _AD_K, _AD_MASK),
    (4, 0): (19, 0x1F6F1A0B, 0x32104572),
    (2, 0): (3, 0x1A0B, 0x4572),
    (1, 0): (3, 0x0B, 0x72),
    (2, 4): (3, 0x1A0B, 0x6E13),
    (1, 2): (3, 0x0B, 0x90),
    (1, 4): (3, 0x0B, 0x13),
    (1, 6): (3, 0x0B, 0x4C),
}
_AD_TAM_R = (0, 1, 2, 3, 4, 5, 6, 7)  # ARTIK HEPSI tam cozulebilir (eskiden 0,1,2,4)
_AD_ONBELLEK = {}                     # giris_id -> {ic_id: ad} | None (okunamadi)
# piksel imzasi esikleri (yukaridaki kalibrasyon; yalniz AD OKUNAMAZSA kullanilir)
IMZA_MERKEZ = 10.0                    # |ort(R)-128| ve |ort(G)-128| ust siniri -> normal
IMZA_PARLAK = 200.0                   # luminans ust siniri -> mask (BC1 ile birlikte)

# ---- level-0 GECERLILIK KAPISI (olculdu 2026-09-03, Edward_Assassin HiddenBladeL/R materyalleri
# 0x212D977BC90 / 0x212D97196C3): harici mip girisi olmayan 2048^2 BC7 / 1024^2 BC1-BC7 slotlarda
# `_embedded_mip0`un materyal govdesinden aldigi 4 MB gercek BC7 degil -- blok mod histogrami
# rastgele bayt dagilimi (mod0 .47, mod1 .28, gecersiz .018-.041; gercek BC7 referans 0x23709626AC7:
# mod4 .24, mod5 .25, mod6 .51, mod0-3 0.0) ve cozulmus goruntu gurultu (komsu-fark ort. 33-36;
# 232 temiz PNG'de medyan 1.1, maks 14.8). Bu slotlar eskiden 'basarili' PNG olarak satiliyordu.
# Kapi: BC7 icin mod0+mod1 > %50 ya da gecersiz (ilk bayt 0) > %0,5 -> RED (her kaynakta; format
# duzeyinde); GOMULU level-0'da cozulmus L kanali komsu-fark ortalamasi > GURULTU_ESIK -> RED.
# Gurultu kapisi yalniz gomulu yolda: kalibrasyon (77 anahtar, 486 materyal, 1.819 slot, 09-03)
# gomulu temiz maks 8,9 / bozuk min 29,2; harici temiz maks 22,7 (CHR_LaurensPrins normal) 25'e
# fazla yakin ve harici mip'te bozuk hic gorulmedi -> harici yolda yalniz olculur, reddedilmez.
# Reddedilen slot `atlanan`a sebebiyle yazilir, dosya YAZILMAZ (plan: "her parca ya dogru ya
# manifest'te gerekceli").
GURULTU_ESIK = 25.0
BC7_MOD01_ESIK = 0.50
BC7_GECERSIZ_ESIK = 0.005
# ---- NORMAL HARITASI YESIL KANAL YONU (09-04 OLCULDU, artik DOGRULANDI): AC4 G kanali DirectX
# tabanliydi (Y asagi), glTF/Blender "Y yukari" (OpenGL) bekliyordu -> G TERS CEVRILMELIYDI.
# Olcum yontemi: bayt/gAMA/imza gibi statik ipucu DEGIL -- her mesh kosesinde gercek geometriden
# (pozisyon+UV, Blender'in glTF importer'inin da kullandigi standart Lengyel tanjant uretimi)
# kurulan T/B/N tabaninda o ucgenin DUZ yuz normali izdusuruluyor (Fx,Fy) ve ayni kosenin UV'sinden
# orneklenen doku (R,G) ile Pearson korelasyonu hesaplaniyor: dogru uzlasim (+) korelasyon verir,
# ters uzlasim (-) verir. 25 kiyafet / tum parcalar / 9.265.963 ucgen-kosesi (normal_g_olcum.py,
# scratchpad): kontrol X (R kanali/tanjant, ters cevirme soz konusu degil) r=+0,0139 (beklenen isaret,
# yontemin kendini dogrulamasi); test Y HAM (mevcut, TERS=False) r=-0,0320 (YANLIS yonlu); Y TERS
# (255-G) r=+0,0320 (DOGRU yonlu, X ile ayni isaret). Rastgele iki yariya bolununce (n=4.632.981 /
# 4.632.982) isaretler ve buyukluk DEGISMEDI (r_y_ham -0,0323/-0,0317, r_y_ters +0,0323/+0,0317) --
# n bu buyuklukte r=0,03 ~97-sigma, tesadufi degil. Karar: NORMAL_G_TERS = True (G = 255 - G; z
# yeniden kurulumu y'nin isaretinden bagimsiz, degismez).
NORMAL_G_TERS = True
# BC7 blok modu = ilk baytin en dusuk set biti (mod 0..7); ilk bayt 0 = gecersiz blok (-1)
_BC7_MOD = np.array([((b & -b).bit_length() - 1) if b else -1 for b in range(256)], np.int8)

# onbellekler: materyal id -> sonuc ; TextureSet id -> sonuc
_ONBELLEK = {}
_TS_ONBELLEK = {}

# ================================================== OLCULMUS EK FORMAT ENUM'LARI (EXPORT TARAFI)
# Yazicinin tablosu (doku_enjekte2.ENUM_AILE: 0x02/0x03 BC1, 0x05 BC3, 0x0A BC7) 19 slotta
# olculmustu ve ona DOKUNULMADI. Burasi yalniz OKUMA/PNG tarafinin ek tablosudur.
#
# 0x06 -> BC1 : SPEC'TEN DEGIL, OLCUMDEN (2026-09-12, OBD_FX_KenwayFleet_NavigationLine_01_Set,
#   256x512, srgb=1). Level-0 havuzu 65.536 B = (256/4)*(512/4) blok x 8 B -- BC1'in blok boyutu;
#   16 B'lik BC3/BC7 olsaydi havuz yarim kalirdi. BC1 olarak cozulunce tutarli goruntu (ok ucu +
#   kesik cizgi, 149 benzersiz renk; gozle dogrulandi). 44 kamara mesh'i yalniz bu enum yuzunden
#   dokusuz kaliyordu. YAZMA TARAFI BU ENUM'U HALA TANIMAZ (fail-closed): bir 0x06 dokuyu geri
#   yazmak doku_enjekte2'de "unknown texture format in the archive" ile reddedilir -- oyun icinde
#   BC1 yazmanin dogru oldugu KANITLANMADI, yalnizca okuma tutarli.
ENUM_AILE_EK = {0x06: "BC1"}


def aile_coz(tanim):
    """tanim['aile'] bos ise OLCULMUS ek tablodan `aile` + `blok` doldurur (YERINDE) ve kaynagi
    `tanim['aile_kaynagi']`ne yazar (ikinci cagri ayni kaynagi soyler).
    Doner (aile, kaynak): kaynak 'enum' (yazicinin tablosu) | 'measured' (ENUM_AILE_EK) | None."""
    aile = tanim.get("aile")
    if aile:
        return aile, tanim.get("aile_kaynagi") or "enum"
    try:
        ek = ENUM_AILE_EK.get(int(tanim.get("fmt_enum")))
    except (TypeError, ValueError):
        ek = None
    if ek:
        tanim["aile"] = ek
        tanim["blok"] = DE.AILE_BLOK[ek]
        tanim["aile_kaynagi"] = "measured"
        return ek, "measured"
    return None, None


# ================================================== level-0 KURTARMA YOLLARI (olculdu 2026-09-03)
#
# (1) HARICI MIP KIMLIGI — `outfit_core._external_mip0` girisi
#     `((0xA0000000000 | doku_id) << 20) | seviye` diye kuruyor. Dogru onek 0xA DEGIL 0x8:
#     `0xA0000000000` bit 41'i de set ediyor. Doku kimliklerinin cogunda bit 41 ZATEN set
#     (0x2.. / 0x3.. ile baslayanlar) oldugu icin iki formul ayni sonucu veriyor ve hata
#     yillardir gorunmuyordu; bit 41'i BOS olan kimliklerde (0x1F1.. gibi) yanlis giris
#     araniyor ve mip "yok" saniliyordu.
#     KANIT: ansiklopedi `katalog.db/mipler` -> Beard_S_Long_TEX_NormalMap (0x1F176AF59CC)
#     seviye 0 girisi 0x9F176AF59CC00000 (= (0x8..|id)<<20), 4.194.304 B; eski formulun
#     urettigi 0xBF176AF59CC00000 canli TOC'ta YOK. Ayni kural `ship/hkm_ortak.mip_fid`de de
#     boyle yazili. OLCUM (25 kiyafet + 52 CHR_*, 1.207 tekil slot): eski formul 1.153 slotta
#     mip buluyor, yeni formul 1.161; yeni formulun bulup eskinin bulamadigi 8 slot,
#     eskinin bulup yeninin bulamadigi 0 slot -> yeni kural eskinin UST KUMESI.
#
# (2) GOMULU LEVEL-0'IN IC DOSYA SINIRI — `_embedded_mip0` piksel havuzunun cipasini
#     "bir sonraki TextureMap basligina kadar, 64 bayt toleransla, >10.000 B" kuraliyla
#     ariyor. Ucu de olculmus sekilde yanlis:
#       * SINIR: giris govdesi (K2) ic dosyalarin ARDISIK birlesimidir ve sinirlar K1
#         tablosunda TAM yazilidir (forge_giris.k1_coz). "Bir sonraki TM basligi" bu siniri
#         YAKLASIK veriyor.
#       * TOLERANS 64: havuz ic dosyanin sonunda TAM biter (`off+4+uzunluk == ic_len`);
#         64 baytlik tolerans BC blok hizasini kaydiran ERKEN bir cipa secebiliyor ve doku
#         SAF GURULTU olarak cozuluyor (Ship Workshop 2026-07-29 olcumu, ayni kok neden).
#       * ALT SINIR 10.000: sihirli sayi; 16x16..64x64 dokular tamamen disarida kaliyor.
#         Yapisal alt sinir 512'dir (her mipin toplami 512'ye yuvarlanir).
#     Bu modulun kurtarma yolu ucunu birlikte duzeltir (+ satir sayisi icin KARE varsayimi
#     yerine gercek H). OLCUM (ayni 1.207 slot, bayt karsilastirmasi): 1.195 slot BIREBIR
#     AYNI · 7 slot yalniz yeni yolda okunuyor (eskiden cipa None) · 0 slot yalniz eskide ·
#     5 slot FARKLI ve hepsinde eski veri gurultu, yeni veri temiz (Edward_Assassin
#     HiddenBladeL/R: komsu-fark 33,6->9,3 · 29,2->1,9 · 36,0->6,9 · 33,5->10,2 · 36,2->6,9;
#     gozle dogrulandi: silah atlasi + eslesen normal haritasi).
#
# (3) BASKA FORGE / PATCH FORGE ARANDI, YOK: 157 forge'un TOC'u tarandi (forge_tara.py);
#     hicbir yerde okunamayan dokulara ait harici mip girisi bulunamadi. Piksel yalnizca
#     bu iki yolda yasiyor.
MIP_ID_ONEK = 0x80000000000           # harici RawAsset mip kimligi: ((ONEK | doku_id) << 20) | seviye
CIPA_ALT_SINIR = 512                  # yapisal: gecerli havuz uzunlugu >= 512 ve 512'nin kati
CIPA_HIZA = 512
CIPA_TARAMA = 4096                    # cipa, TM basligindan sonraki ilk 4 KB icinde aranir
_IC_SINIR_ONBELLEK = {}               # giris_id -> [(ic_id, bas, son)]  (K2 icinde MUTLAK)


def harici_mip_id(doku_id, seviye=0):
    """dokunun harici RawAsset mip girisinin TOC kimligi (olculdu, bkz. yukarida (1))."""
    return ((MIP_ID_ONEK | doku_id) << 20) | seviye


def _harici_mip0_yedek(doku_id):
    """(1) duzeltilmis kimlikle level-0 RawAsset baytlari, ya da None."""
    rid = harici_mip_id(doku_id, 0)
    lf = C._forge()
    if rid not in lf.by_id:
        return None
    off, ln, _ext = lf.by_id[rid]
    lf.f.seek(off)
    return lf.f.read(ln)


def _ic_sinirlar(giris_id):
    """giris govdesindeki (K2) ic dosya araliklari [(ic_id, bas, son)] -- K1 tablosundan TAM."""
    if giris_id in _IC_SINIR_ONBELLEK:
        return _IC_SINIR_ONBELLEK[giris_id]
    from yalin_forge import read_block
    try:
        from . import forge_giris as FG
    except ImportError:                                     # modul dosya yolundan yuklendiyse
        import forge_giris as FG
    lf = C._forge()
    k1, _n1 = read_block(lf.read_raw(giris_id), 0)
    out = []
    p = 0
    for ic_id, ln in FG.k1_coz(k1):
        out.append((ic_id, p, p + ln))
        p += ln
    _IC_SINIR_ONBELLEK[giris_id] = out
    return out


def _cipa_bul(ic, bas, son):
    """piksel havuzunun u32 uzunluk cipasi -> (cipa_off, veri_off, uzunluk) ya da None.

    Kural (bkz. yukarida (2)): havuz ic dosyanin sonunda TAM biter (tolerans 0), uzunluk
    >= 512, 512'nin kati olan adaylar TERCIH edilir; hic yoksa kat olmayanlarin en buyugu."""
    ic_len = son - bas
    en_iyi = yedek = None
    for q in range(bas, max(bas, min(bas + CIPA_TARAMA, son - 4))):
        v = struct.unpack_from("<I", ic, q)[0]
        if not (CIPA_ALT_SINIR <= v < ic_len):
            continue
        if q + 4 + v != son:                                # TAM bitis (tolerans YOK)
            continue
        if v % CIPA_HIZA == 0:
            if en_iyi is None or v > en_iyi[2]:
                en_iyi = (q, q + 4, v)
        elif yedek is None or v > yedek[2]:
            yedek = (q, q + 4, v)
    return en_iyi if en_iyi is not None else yedek


def _yerlesim(W, H, blok, uzunluk):
    """gomulu mip yerlesimi [(lvl, goreli_off, pitch, satir, rowbytes)] -- satir sayisi
    KARE varsayimiyla degil gercek H'den (bh), her mipin toplami 512'ye yuvarlanir."""
    out = []
    off = 0
    w, h, lvl = max(1, W), max(1, H), 0
    while w >= 1 and h >= 1:
        bw = max(1, (w + 3) // 4)
        bh = max(1, (h + 3) // 4)
        rowbytes = bw * blok
        pitch = DE.align(rowbytes, 256)
        n = DE.align(pitch * bh, 512)
        if off + n > uzunluk:
            break
        out.append((lvl, off, pitch, bh, rowbytes))
        off += n
        if w == 1 and h == 1:
            break
        w = max(1, w // 2)
        h = max(1, h // 2)
        lvl += 1
    return out


def _gomulu_mip0_k1(kaynak_id, hdr, tanim, res):
    """(2) K1 sinirli + tam-bitisli cipa ile gomulu level-0 baytlari, ya da None."""
    try:
        sinirlar = _ic_sinirlar(kaynak_id)
    except Exception:                                       # noqa: BLE001 -- eski yola dusulur
        return None
    bas = son = None
    for _ic_id, b, s in sinirlar:
        if b <= hdr < s:
            bas, son = b, s
            break
    if bas is None:
        return None
    cipa = _cipa_bul(res, hdr, son)
    if not cipa:
        return None
    _q, piksel_bas, uzunluk = cipa
    yer = _yerlesim(tanim["W"], tanim["H"], tanim["blok"], uzunluk)
    if not yer:
        return None
    _lvl, roff, pitch, satir, rb = yer[0]
    taban = piksel_bas + roff
    out = bytearray()
    for r in range(satir):
        out += res[taban + r * pitch: taban + r * pitch + rb]
    return bytes(out)


def mip0_oku(kaynak_id, kaynak_slot):
    """slotun level-0 BC baytlarini SIRAYLA dort yoldan dener; hangisi verdiyse onu soyler.

    Doner: (data|None, tanim, kaynak) — kaynak:
      'external'         `outfit_core._external_mip0` (mevcut yol, degismedi)
      'external_mip_id'  duzeltilmis harici mip kimligi (yukarida (1))   -> +8 slot
      'embedded_k1'      K1 sinirli + tam-bitisli cipa (yukarida (2))    -> +7 slot, 5 slot gurultuden temize
      'embedded'         `outfit_core._embedded_mip0` (eski gomulu yol, son care)
    Sira KANITLI: 1.207 slotluk olcumde yeni yollar eskinin bulduklarini ya BIREBIR
    tekrar uretiyor ya da (5 slotta) gurultu yerine temiz piksel veriyor; eskinin bulup
    yeninin bulamadigi slot YOK."""
    hdr, tex, tanim, res, tms = C._slot_tanim(kaynak_id, kaynak_slot)
    aile_coz(tanim)                    # olculmus ek enum (0x06): gomulu yollar blok boyutunu ister
    data = C._external_mip0(tex)
    if data is not None:
        return data, tanim, "external"
    data = _harici_mip0_yedek(tex)
    if data is not None:
        return data, tanim, "external_mip_id"
    data = _gomulu_mip0_k1(kaynak_id, hdr, tanim, res)
    if data is not None:
        return data, tanim, "embedded_k1"
    return C._embedded_mip0(res, tanim, hdr, tms, kaynak_slot), tanim, "embedded"


def bc7_mod_histogrami(data):
    """BC7 blok mod dagilimi (16 B'lik blogun ilk bayti). Doner {mod01, gecersiz, hist}."""
    m = _BC7_MOD[np.frombuffer(data, np.uint8)[::16]]
    n = max(1, len(m))
    say = np.bincount((m + 1).astype(np.int64), minlength=9)      # 0 = gecersiz, 1..8 = mod 0..7
    return {"mod01": round(float((say[1] + say[2]) / n), 4), "gecersiz": round(float(say[0] / n), 4),
            "hist": {str(i - 1): round(float(say[i] / n), 4) for i in range(9) if say[i]}}


def gurultu_olc(arr):
    """cozulmus RGBA'nin L kanalinda komsu-fark ortalamasi (yatay+dikey /2)."""
    a = np.asarray(arr)
    L = (0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2]).astype(np.float32)
    return round(float(0.5 * (np.abs(np.diff(L, axis=1)).mean() + np.abs(np.diff(L, axis=0)).mean())), 3)


def gecerlilik(data, arr, aile, kaynak="embedded"):
    """level-0 gecerlilik kapisi. kaynak: `mip0_oku`un dondurdugu yol adi; gurultu kapisi
    yalniz GOMULU yollarda ('embedded', 'embedded_k1') olculur, harici yollarda yalniz raporlanir.
    Doner (ok, sebep|None, olcum)."""
    olcum = {}
    sebep = None
    if aile == "BC7":
        h = bc7_mod_histogrami(data)
        olcum["bc7_mod01"], olcum["bc7_gecersiz"] = h["mod01"], h["gecersiz"]
        if h["gecersiz"] > BC7_GECERSIZ_ESIK or h["mod01"] > BC7_MOD01_ESIK:
            sebep = ("BC7 block mode histogram is random: mode0+1 %.2f > %.2f or invalid %.3f > %.3f"
                     % (h["mod01"], BC7_MOD01_ESIK, h["gecersiz"], BC7_GECERSIZ_ESIK))
    g = gurultu_olc(arr)
    olcum["gurultu"] = g
    if sebep is None and str(kaynak).startswith("embedded") and g > GURULTU_ESIK:
        sebep = "decoded image is noise: mean neighbour difference %.1f > %.0f" % (g, GURULTU_ESIK)
    return sebep is None, sebep, olcum


# ============================================ BC COZUCU: SPEC DUZELTMELI YEDEK + OLCUM (09-12)
#
# SECIM outfit_core'da: `_bcn_cozucu()` once imagecodecs.bcn_decode'u GERCEKTEN cagirarak dener,
# dusunce texture2ddecoder'a gecer, ikisi de yoksa ImportError. OLCULDU (2026-09-12, bu makine):
# Windows Smart App Control (HKLM\...\CI\Policy VerifiedAndReputablePolicyState = 1) imagecodecs'in
# imzasiz `_bcn.pyd`sini yuklemiyor (CodeIntegrity 3077 "An Application Control policy has blocked
# this file"); imagecodecs bunu STUB ile gizler: `from imagecodecs import bcn_decode` basarili doner,
# `imagecodecs.BCN.available` False'tur, stub ilk CAGRIDA `DelayedImportError` (ImportError alt
# sinifi) firlatir. Makinedeki 9 `_bcn.pyd` kopyasi ayni hash (hepsi bloklu) -> imagecodecs yolu
# burada kosturulamaz, yalniz "varsa" olculur (test B5).
#
# BURASI export tarafinin sarmalayicisi (`bc_decode_rgba`):
#   1. hangi cozucunun kullanildigini olcer ve slot kaydina yazar (`cozucu`; `cozucu_bilgi()`),
#   2. texture2ddecoder secildiyse OLCULMUS iki spec sapmasini duzeltir:
#      * BC3 renk blogunda c0 <= c1 ise t2d BC1'in 3-renk kuralini uyguluyor (spec: BC3 HER ZAMAN
#        4-renk). Olcum: 0x22D6CCFC162 s0 (2048^2) 39 blokta siyah piksel; Pillow ve spec referansi
#        hemfikir. `_t2d_bc3_onhazirlik` COZMEDEN ONCE: c0==c1 -> indeksler 0 (palet tekduze),
#        c0<c1 -> uclar takas + indeks LSB ters (palet sirasi tam tersine doner; tamsayi-birebir).
#        Sonra 3 gercek BC3 dokuda Pillow ile RGBA bayt-birebir.
#      * BC1 3-renk modunda (c0 <= c1) indeks 3 = SAYDAM siyah (spec, bcdec, Pillow); t2d alfa 255
#        veriyor. `_t2d_bc1_sonislem` COZDUKTEN SONRA o pikselleri (0,0,0,0) yapar.
#      * BC7 gecersiz (mod 8, 16 bayti sifir) blok: t2d (0,0,0,0) = spec; sapan PILLOW'dur (alfa
#        255) -- test bunu bilerek olcer. imagecodecs (bcdec) uc kuralda da spec'tedir.
#   3. `oz_sinama()`: yuvarlama gerektirmeyen uclarla (255/0; 510/3 ve 255/3 tam bolunur) uc aile
#      icin spec-kesin beklenen piksellerle sentetik bloklar; `kur.py` 5e bunu PAKETTEKI python'da
#      kosturur, testler/test_bcn_cozucu.py ayni olcumu gercek dokularla Pillow'a karsi yapar.
_COZUCU_LOGLANDI = [False]


def cozucu_bilgi():
    """{'ad': 'imagecodecs' | 'texture2ddecoder', 'sebep': birincilin dusme sebebi | None}.
    Secim ilk cagrida yapilir; iki cozucu de yoksa ImportError."""
    ad = C.bcn_cozucu_adi()
    return {"ad": ad, "sebep": C._BCN.get("hata")}


def cozucu_zorla(ad=None):
    """Cozucu secimini sifirlar (ad=None: bir sonraki cagri dogal secimi yeniden yapar) ya da ZORLAR:
    'texture2ddecoder' -> imagecodecs import edilemez kilinip secim yeniden yapilir;
    'imagecodecs' -> texture2ddecoder gizlenir (imagecodecs yoksa ImportError). Test / kur.py 5e icin.
    Doner: secilen ad (None ile None)."""
    import sys as _s
    C._BCN.clear()
    _COZUCU_LOGLANDI[0] = False
    if ad is None:
        return None
    gizle = {"texture2ddecoder": "imagecodecs", "imagecodecs": "texture2ddecoder"}.get(ad)
    if gizle is None:
        raise ValueError("unknown decoder %r" % ad)
    yoktu = object()
    eski = _s.modules.get(gizle, yoktu)
    _s.modules[gizle] = None                        # `import gizle` artik ImportError firlatir
    try:
        secim = C.bcn_cozucu_adi()
    finally:
        if eski is yoktu:
            _s.modules.pop(gizle, None)
        else:
            _s.modules[gizle] = eski
    if secim != ad:
        C._BCN.clear()
        raise ImportError("could not force %s (selected %s)" % (ad, secim))
    return secim


def _t2d_bc3_onhazirlik(ham):
    """BC3 blok baytlarini t2d icin spec-esdeger hale getirir (her renk blogunda c0 > c1 ya da
    indekssiz tekduze palet). Doner: yeni bytes (girdi degismez)."""
    blk = np.frombuffer(ham, np.uint8).reshape(-1, 16).copy()
    c0 = blk[:, 8].astype(np.uint16) | (blk[:, 9].astype(np.uint16) << 8)
    c1 = blk[:, 10].astype(np.uint16) | (blk[:, 11].astype(np.uint16) << 8)
    esit = c0 == c1
    if esit.any():
        blk[esit, 12:16] = 0                       # 4-renk palet tekduze: her indeks c0 -> indeks 0
    kucuk = c0 < c1
    if kucuk.any():
        sw = blk[kucuk]
        sw[:, 8:12] = np.concatenate([sw[:, 10:12], sw[:, 8:10]], axis=1)   # uclar takas
        sw[:, 12:16] ^= 0x55                                                  # 0<->1, 2<->3
        blk[kucuk] = sw
    return blk.tobytes()


def _t2d_bc1_sonislem(ham, arr, W, H):
    """BC1 3-renk (c0 <= c1) bloklarinda indeks 3 -> (0,0,0,0). `arr` (H, W, 4) YERINDE.
    Doner: duzeltilen piksel sayisi."""
    BW, BH = (W + 3) // 4, (H + 3) // 4
    blk = np.frombuffer(ham, np.uint8)[:BW * BH * 8].reshape(-1, 8)
    c0 = blk[:, 0].astype(np.uint16) | (blk[:, 1].astype(np.uint16) << 8)
    c1 = blk[:, 2].astype(np.uint16) | (blk[:, 3].astype(np.uint16) << 8)
    uc = c0 <= c1
    if not uc.any():
        return 0
    idx = (blk[:, 4].astype(np.uint32) | (blk[:, 5].astype(np.uint32) << 8)
           | (blk[:, 6].astype(np.uint32) << 16) | (blk[:, 7].astype(np.uint32) << 24))
    pik = ((idx[:, None] >> (2 * np.arange(16, dtype=np.uint32))) & 3) == 3      # (blok, 16)
    pik &= uc[:, None]
    maske = pik.reshape(BH, BW, 4, 4).transpose(0, 2, 1, 3).reshape(BH * 4, BW * 4)[:H, :W]
    arr[maske] = 0
    return int(maske.sum())


def bc_decode_rgba(data, W, H, fmt_enum, report=None, aile=None):
    """BC bloklari -> RGBA (H, W, 4) uint8. Secim `outfit_core._bcn_cozucu` (imagecodecs, ImportError/
    OSError'da texture2ddecoder); texture2ddecoder'da spec duzeltmeleri (BC3 onhazirlik, BC1 sonislem).
    Kullanilan cozucu `cozucu_bilgi()`; iki cozucu de yoksa ImportError -- sessiz degil."""
    aile = aile or DE.ENUM_AILE.get(fmt_enum) or ENUM_AILE_EK.get(fmt_enum)
    if aile not in ("BC1", "BC3", "BC7"):
        raise ValueError("unknown texture format enum 0x%02X" % fmt_enum)
    BW, BH = (W + 3) // 4, (H + 3) // 4
    gerek = BW * BH * DE.AILE_BLOK[aile]
    ham = bytes(data[:gerek])
    if len(ham) < gerek:                            # t2d'nin C kodu sinir denetimi yapmaz: once biz
        raise ValueError("BC data short: %d < %d bytes (%s %dx%d)" % (len(ham), gerek, aile, W, H))
    ad = C.bcn_cozucu_adi()                         # ImportError: iki cozucu de yok
    if ad == "texture2ddecoder" and aile == "BC3":
        ham = _t2d_bc3_onhazirlik(ham)
    arr = C._bc_decode_rgba(ham, W, H, fmt_enum, report, aile=aile)
    if ad == "texture2ddecoder" and aile == "BC1":
        _t2d_bc1_sonislem(ham, arr, W, H)
    return arr


def _oz_sinama_bloklari():
    """Sentetik bloklar + spec-kesin beklenen RGBA (yuvarlama gerektirmeyen uclar).
    Doner: [(aile, fmt_enum, bloklar, W, H, beklenen), ...]"""
    RED, GRN = 0xF800, 0x07E0                       # 565 (255,0,0) / (0,255,0): her genisletmede tam
    idx01 = 0x44444444                              # piksel i -> indeks (i & 1)
    # BC1 8x4: [c0>c1, indeks 0/1] + [c0<c1 3-renk, indeks 3 = saydam siyah]
    bc1 = struct.pack("<HHI", RED, GRN, idx01) + struct.pack("<HHI", GRN, RED, 0xFFFFFFFF)
    b1 = np.zeros((4, 8, 4), np.uint8)
    for i in range(16):
        b1[i // 4, i % 4] = (255, 0, 0, 255) if (i & 1) == 0 else (0, 255, 0, 255)
    # BC3 12x4: alfa blogu a0=255 > a1=0, indeks (i&1) -> 255/0; renk bloklari:
    #   [c0>c1 idx 0/1] + [c0==c1 idx 3 -> c0 (4-renk)] + [c0<c1 idx 3 -> (c0+2c1+1)//3 = (170,85,0)]
    aidx = 0
    for i in range(16):
        aidx |= (i & 1) << (3 * i)
    ablk = struct.pack("<BB", 255, 0) + aidx.to_bytes(6, "little")
    bc3 = (ablk + struct.pack("<HHI", RED, GRN, idx01) + ablk + struct.pack("<HHI", RED, RED, 0xFFFFFFFF)
           + ablk + struct.pack("<HHI", GRN, RED, 0xFFFFFFFF))
    b3 = np.zeros((4, 12, 4), np.uint8)
    for i in range(16):
        a = 255 if (i & 1) == 0 else 0
        b3[i // 4, i % 4] = (255, 0, 0, a) if (i & 1) == 0 else (0, 255, 0, a)
        b3[i // 4, 4 + i % 4] = (255, 0, 0, a)
        b3[i // 4, 8 + i % 4] = (170, 85, 0, a)
    # BC7 8x4: mod 6, e0=(0,0,0,0) p0=0, e1=(127,..)+p1=1 -> (255,255,255,255), indeks 0/15
    #   (agirlik 0/64: tam) + hepsi-sifir blok (mod 8 GECERSIZ -> spec (0,0,0,0))
    idx7 = [0] + [15 if (i & 1) else 0 for i in range(1, 16)]
    bits, pos = 0, 0
    for v, n in ([(0b1000000, 7)] + [(x, 7) for ch in range(4) for x in (0, 127)]
                 + [(0, 1), (1, 1), (idx7[0], 3)] + [(idx7[i], 4) for i in range(1, 16)]):
        bits |= (v & ((1 << n) - 1)) << pos
        pos += n
    bc7 = bits.to_bytes(16, "little") + bytes(16)
    b7 = np.zeros((4, 8, 4), np.uint8)
    for i in range(16):
        b7[i // 4, i % 4] = (255, 255, 255, 255) if idx7[i] == 15 else (0, 0, 0, 0)
    return [("BC1", 0x02, bc1, 8, 4, b1), ("BC3", 0x05, bc3, 12, 4, b3), ("BC7", 0x0A, bc7, 8, 4, b7)]


def oz_sinama(zorla=None):
    """Cozucu oz-sinamasi: sentetik BC1/BC3/BC7 bloklari `bc_decode_rgba` ile cozulur ve spec-kesin
    beklenenle piksel piksel karsilastirilir. zorla: None (dogal secim) | 'texture2ddecoder' |
    'imagecodecs'. Doner {'cozucu', 'sebep', 'BC1', 'BC3', 'BC7', 'fark'}; secim sonunda dogala doner."""
    son = {"cozucu": None, "sebep": None, "BC1": False, "BC3": False, "BC7": False, "fark": {}}
    try:
        cozucu_zorla(zorla)
        for aile, fe, blok, W, H, bekle in _oz_sinama_bloklari():
            try:
                arr = bc_decode_rgba(blok, W, H, fe)
                ok = arr.shape == bekle.shape and bool((arr == bekle).all())
                son[aile] = ok
                if not ok:
                    son["fark"][aile] = ("%d px" % int((arr != bekle).any(axis=2).sum())
                                         if arr.shape == bekle.shape else "shape %r" % (arr.shape,))
            except Exception as e:                                  # noqa: BLE001
                son["fark"][aile] = "%s: %s" % (type(e).__name__, str(e)[:160])
        b = cozucu_bilgi()
        son["cozucu"], son["sebep"] = b["ad"], b["sebep"]
    except ImportError as e:                                        # zorlama tutmadi / cozucu yok
        son["sebep"] = "%s: %s" % (type(e).__name__, str(e)[:200])
    finally:
        if zorla is not None:
            cozucu_zorla(None)
    return son


def _mat_int(mat_id):
    return mat_id if isinstance(mat_id, int) else int(str(mat_id), 16)


def _mat_hex(mat_id):
    """dosya adinda kullanilan kimlik: buyuk harf hex, '0x' YOK (IC_ kalibiyla ayni)."""
    return "%X" % _mat_int(mat_id)


def _ad_rotr(x, s, w):
    s %= w
    return ((x >> s) | (x << (w - s))) & ((1 << w) - 1)


def _ad_rotl(x, s, w):
    s %= w
    return ((x << s) | (x >> (w - s))) & ((1 << w) - 1)


def _ad_bolunme(r):
    """kuyruk uzunlugu r (1..7) -> [(q, W)] alt-blok listesi; kod 4,2,1 sirasiyla iler."""
    out = []
    q = 0
    for W in (4, 2, 1):
        if r - q >= W:
            out.append((q, W))
            q += W
    return out


def _ad_blok(blok, q=0):
    """tek alt-blok (1/2/4/8 B; q = kuyruk ici bayt ofseti) -> duz bayt."""
    W = len(blok)
    w = W * 8
    m = (1 << w) - 1
    rot, kk, mm = _AD_ALT[(W, q)]
    x = _ad_rotr(int.from_bytes(blok, "little"), rot, w)
    return (((x - kk) & m) ^ mm).to_bytes(W, "little")


def _ad_blok_kodla(blok, q=0):
    """_ad_blok'un TERSI (gecerli ad alani YAZMAK icin)."""
    W = len(blok)
    w = W * 8
    m = (1 << w) - 1
    rot, kk, mm = _AD_ALT[(W, q)]
    x = ((int.from_bytes(blok, "little") ^ mm) + kk) & m
    return _ad_rotl(x, rot, w).to_bytes(W, "little")


def ad_coz(sifreli, bilinmeyen=b"?"):
    """Karistirilmis ad alani -> duz ad (bytes). TUM uzunluklar tam cozulur;
    `bilinmeyen` geriye donuk uyumluluk icin durur, artik kullanilmaz."""
    out = bytearray()
    n = len(sifreli)
    tam = (n // 8) * 8
    for i in range(0, tam, 8):
        out += _ad_blok(sifreli[i:i + 8])
    r = n - tam
    if r:
        kuyruk = sifreli[tam:]
        for q, W in _ad_bolunme(r):
            out += _ad_blok(kuyruk[q:q + W], q)
    return bytes(out)


def ad_kodla(duz):
    """Duz ad -> karistirilmis ad alani. ad_coz'un tam TERSI, her uzunlukta bayt-birebir."""
    out = bytearray()
    n = len(duz)
    tam = (n // 8) * 8
    for i in range(0, tam, 8):
        out += _ad_blok_kodla(duz[i:i + 8])
    r = n - tam
    if r:
        kuyruk = duz[tam:]
        for q, W in _ad_bolunme(r):
            out += _ad_blok_kodla(kuyruk[q:q + W], q)
    return bytes(out)


def _giris_ic_adlari(gid):
    """TOC girisinin ic dosya adlari {ic_id: ad}. Okunamazsa {} (rol yedek imzalara duser)."""
    if gid in _AD_ONBELLEK:
        return _AD_ONBELLEK[gid]
    try:
        try:
            from . import forge_giris as FG
        except ImportError:                                 # modul dosya yolundan yuklendiyse
            import forge_giris as FG
        out = {}
        for icid, govde in FG.ic_dosyalar(C._forge(), gid):
            adLen = struct.unpack_from("<I", govde, 8)[0]
            if 0 < adLen <= len(govde) - 12:
                out[icid] = ad_coz(govde[12:12 + adLen]).decode("latin1")
    except Exception:                                       # noqa: BLE001 -- ad zorunlu degil
        out = {}
    _AD_ONBELLEK[gid] = out
    return out


def doku_adi(doku_id, *kaplar):
    """dokunun VARLIK ADI (K1 ad sifresi cozulmus) ya da None. `kaplar`: aranacak TOC girisleri."""
    for gid in kaplar:
        if not gid:
            continue
        ad = _giris_ic_adlari(_mat_int(gid)).get(_mat_int(doku_id))
        if ad:
            return ad
    return None


def ad_rolu(ad):
    """varlik adi -> rol anahtari (ROL_ADI ilk eslesme) ya da None."""
    n = (ad or "").lower()
    for anahtar, rol in ROL_ADI:
        if anahtar in n:
            return rol
    return None


def piksel_imzasi(arr, tanim):
    """cozulmus RGBA -> rolu ayirt eden olcumler (kayit + adsiz yedek kural icin).

    Orneklem: 512x512'den buyuk dokular adimlanarak taranir (olcum degeri degismez,
    sure 2048^2'de ~40 ms). Doner: ort/std/medyan (RGBA) + luminans + gri_oran + alfa."""
    a = np.asarray(arr)
    if a.shape[0] * a.shape[1] > 512 * 512:
        a = a[::max(1, a.shape[0] // 512), ::max(1, a.shape[1] // 512)]
    f = a.astype(np.float32)
    mx = f[..., :3].max(2)
    mn = f[..., :3].min(2)
    ort = [round(float(f[..., i].mean()), 2) for i in range(4)]
    return {"ort": ort, "std": [round(float(f[..., i].std()), 2) for i in range(4)],
            "lum": round(0.299 * ort[0] + 0.587 * ort[1] + 0.114 * ort[2], 2),
            "gri_oran": round(float(((mx - mn) < 12).mean()), 4),
            "a_opak": round(float((f[..., 3] > 250).mean()), 4),
            "a_sifir": round(float((f[..., 3] < 8).mean()), 4),
            "srgb": int(bool(tanim.get("srgb"))), "aile": tanim.get("aile")}


def imza_rolu(imza):
    """AD OKUNAMAZSA rol: srgb bayragi -> piksel imzasi. Doner (rol, sebep).
    Olculdu (1.347 doku, yer gercegi = varlik adi): 1.326 dogru (%98,44) --
    diffuse 334/334 · normal 335/340 · mask 338/343 · emissive 319/326."""
    if imza.get("srgb"):
        return "diffuse", "sRGB flag set"
    o = imza["ort"]
    if abs(o[0] - 128) <= IMZA_MERKEZ and abs(o[1] - 128) <= IMZA_MERKEZ:
        return "normal", "R,G means centred on 128 (tangent-space X/Y)"
    if imza.get("aile") == "BC1" or imza["lum"] > IMZA_PARLAK:
        return "mask", "BC1 or bright (mean luminance %.0f)" % imza["lum"]
    return "emissive", "remainder"


def rol_karar(doku_id, kaplar, imza, onsel, onsel_kaynak):
    """Bir slotun ROLU. Sira olculdu (bkz. ROL KAYNAGI bolumu):
        1. varlik adi (K1 ad sifresi)  -> tam okuma, 1.347/1.347
        2. ad yoksa: sRGB bayragi + piksel imzasi (`imza_rolu`), %98,44
        3. o da yoksa: baglama yuvasi (`onsel`), TS'te %100 / material'de %97,03
    Doner: (rol, kaynak, ayrinti) -- ayrinti kayda yazilir (ad, imza sebebi, catisma)."""
    ayrinti = {}
    ad = None
    try:
        ad = doku_adi(doku_id, *kaplar)
    except Exception:                                       # noqa: BLE001
        ad = None
    ayrinti["doku_adi"] = ad
    imza_rol, imza_sebep = imza_rolu(imza)
    ayrinti["imza_rol"], ayrinti["imza_sebep"] = imza_rol, imza_sebep
    ayrinti["yuva_rol"] = onsel
    rol_ad = ad_rolu(ad)
    if rol_ad:
        # catisma kapisi: ad "diffuse" derken sRGB bayragi bos (ya da tersi) -> kayda yazilir.
        # Olculdu: 1.347 dokuda 0 catisma. Cikan olursa ad yine kazanir ama manifest'te gorunur.
        srgb = bool(imza.get("srgb"))
        if (rol_ad == "diffuse") != srgb:
            ayrinti["catisma"] = ("asset name says %s but sRGB flag is %d"
                                  % (rol_ad, int(srgb)))
        return rol_ad, "asset name", ayrinti
    if imza_rol:
        return imza_rol, "pixel signature", ayrinti
    return onsel, onsel_kaynak, ayrinti


def slot_rolu(mat_id, slot):
    """materyal TextureMap slotu -> (rol_anahtari, kaynak). kaynak: 'katalog' | 'varsayilan' | 'yok'."""
    cs = None
    try:
        cs = C._catalog_slot("0x%X" % _mat_int(mat_id), slot)
    except Exception:                                           # noqa: BLE001
        cs = None
    if cs is not None and cs.get("rol") in ROL_ANAHTAR:
        return ROL_ANAHTAR[cs["rol"]], "katalog"
    if slot in VARSAYILAN_ROL:
        return VARSAYILAN_ROL[slot], "varsayilan"
    return "ref", "yok"


def dosya_adi(mat_id, slot, rol, ts=False):
    """TEX_<id>_s<slot>_<rol>.png (TextureSet yuvasi: _ts<slot>_) -- _SLOT_RE ile ESLESMEZ."""
    return "%s%s_%s%d_%s.png" % (ONEK, _mat_hex(mat_id), "ts" if ts else "s", slot, rol)


def normal_z_kur(rgba):
    """2 kanalli AC4 normal haritasindan (R=x, G=y, B~0, A=gloss) glTF normalini kurar.

    x = R/127.5-1, y = G/127.5-1, z = sqrt(max(0, 1-x^2-y^2)) -> RGB u8 (z de
    ayni olcekle: z*127.5+127.5). Ham B kanali ATILIR (olculdu: %66-99 sifir,
    dolu oldugu yerde Z ile iliskisiz -- corr < 0.1). Alfa bandi aynen gloss (L).
    G kanalinin yonu (DirectX Y-asagi / OpenGL Y-yukari) 09-04'te OLCULDU (bkz. NORMAL_G_TERS
    yorumu): `NORMAL_G_TERS` True (varsayilan) iken G = 255-G yazilir, False iken G oldugu gibi
    kopyalanir (z degismez).
    Doner: (rgb uint8 HxWx3, gloss uint8 HxW)."""
    a = np.asarray(rgba)
    g = (255 - a[..., 1]) if NORMAL_G_TERS else a[..., 1]
    x = a[..., 0].astype(np.float32) / 127.5 - 1.0
    y = g.astype(np.float32) / 127.5 - 1.0
    z = np.sqrt(np.maximum(0.0, 1.0 - x * x - y * y))
    rgb = np.empty(a.shape[:2] + (3,), dtype=np.uint8)
    rgb[..., 0] = a[..., 0]
    rgb[..., 1] = g
    rgb[..., 2] = np.clip(np.rint(z * 127.5 + 127.5), 0, 255).astype(np.uint8)
    gloss = np.ascontiguousarray(a[..., 3]) if a.shape[-1] > 3 else np.full(a.shape[:2], 255, np.uint8)
    return rgb, gloss


def _srgb_png(arr_rgb, path):
    """sRGB PNG: `sRGB` yiginigi (rendering intent 0) + gAMA 1/2.2 ile yazilir."""
    info = PngInfo()
    info.add(b"sRGB", b"\x00")
    info.add(b"gAMA", (45455).to_bytes(4, "big"))
    Image.fromarray(arr_rgb, "RGB").save(path, pnginfo=info)


# ============================================ MATERYAL TONU (sac/sakal rengi) -- olculdu 2026-09-04
#
# SAC/SAKAL RENGI MATERYALDE, DOKUDA DEGIL. Yukaridaki "SACIN DIFFUSE'U YOKTUR" olcumu neyin
# EKSIK oldugunu soyluyordu; bu blok neyin YERINE GECTIGINI soyluyor: renk materyal govdesindeki
# parametre tablosunda iki float4 olarak duruyor.
#
# GOVDE YAPISI (bayt-dogrulandi, 122 sac/sakal materyali):
#     ... [RGBA8 A (4B)][RGBA8 B (4B)][8 B][u32 N][N x 16 B kayit][float yuku]
#     kayit = [tag u32][deger u32][u16 0][tip u8][5 B 0]
#     tip 0x0A -> 1 float · 0x0D -> 4 float (RGBA) · 0x13 -> doku basvurusu (float tuketmez)
# Float yuku kayit SIRASINA gore tuketilir; kayit sirasi materyalden materyale DEGISIR
# (Edward'da renkler sonda, BlackBeard'da basta) -- bu yuzden ofset EZBERLENMEZ, tablo cozulur.
# Ilk 8 baytlik RGBA8 cifti ayni iki rengin 8-bit kopyasidir ve sirasi SABIT (A sonra B);
# 122/122 materyalde float4 == RGBA8/255 (bayt-birebir). Yani renkler 8-bitlik bir renk
# secicide yazilmis, float'a acilmis.
#
# TAGLER (CRC32(ad); ad cozulemedi -- 197.802 aday isim denendi, 0 eslesme. Anlam OLCUMLE
# belirlendi, isimle degil):
#     0x8E9AB4EF  renk A      0x2AEEDB50  renk B
#     0xC95AA0DB · 0x5A662E5A · 0x7003E4D2 · 0x69D737E6 · 0x2F89F81F · 0xB680A9A5  skaler
#
# BUNUN SAC RENGI OLDUGUNUN KANITI (uc bagimsiz olcum):
#  1. KAPSAM: 52 CHR_* + 25 kiyafetin 438 tekil materyali tarandi. Iki renk parametresi
#     122/122 sac-ailesi materyalinde (Hair_/Beard_/Brow_/Lash_) VAR, 316/316 sac disi
#     materyalde (govde, pantolon, bot, silah, mankenler) YOK. Tek istisna yok.
#  2. AYIRT EDICILIK (kaptanin istedigi kahin): renk, sac rengi degisen karakterlerde
#     sac renginin degistigi YONDE degisiyor --
#       Hair_M_Wig_A / Hair_M_Wig_A_UnderHat (pudrali peruk, British/Spanish/RichSpanish)
#                                        = (227,206,178) / (232,213,180)  -> krem beyaz
#       Hair_U_GovernorTorres (yasli, kir sacli) = (114,114,114) / (121,121,121) -> gri
#       Hair_U_TheButler = (114, 96, 81) · Hair_U_PeterChamberlain = (115,104,87) -> kirlasmis
#       Hair_U_Edward_SimpleSailor       = ( 42, 26, 14) / ( 42, 26, 14)  -> koyu kumral
#       Hair_U_BlackBeard                = (  6,  6,  6) / ( 17, 17, 17)  -> siyah
#       Hair_U_MaryRead                  = (  6,  6,  6) / (  8,  8,  8)  -> siyah
#       Hair_U_AnneBonny                 = ( 12,  1,  0) / ( 51, 13,  6)  -> KIZIL (tek kirmizi ton)
#       Hair_U_CarolineScott             = (117, 36,  6) / ( 56, 25,  9)  -> kizil
#       Hair_U_RhonaDunsmore             = ( 20,  6,  1) / ( 93, 51, 26)  -> kizil kumral
#       Hair_F_Bun_A (PoorFemale)        = (  0,  0,  0) -> saf siyah
#     Yani hem hue (kizil/notr) hem parlaklik (peruk 227 .. siyah 6) karakterin bilinen sac
#     rengiyle ayni yonde gidiyor. Rastgele bir alan bunu yapmaz.
#  3. A MI B MI (tek baseColorFactor'a hangisi girecek): KAS hakemligi. Kas materyallerinin
#     iki rengi cogunlukla AYNI (tek renk) -- bu yuzden "sacin rengi kasin rengine ne kadar
#     yakin?" olculebilir. Iki rengi ayni olan 24 kasta: B kazanan 18, A kazanan 6;
#     ortalama RGB uzakligi B 21,0 · A 31,7 · ortalama(A,B) 22,3. -> B (0x2AEEDB50) secilir,
#     A manifest'e ayrica yazilir. (Fark kucuk: cogu karakterde A ile B birkac ton uzakta.)
#
# RENK UZAYI (durustce: OLCUMLE DEGIL, MUHAKEMEYLE secildi -- oyun ici ekran goruntusu yok):
# deger 8-bitlik bir secicide yazilmis; glTF `baseColorFactor` LINEER ister. Iki okuma da
# savunulabilir. `TON_SRGB=False` (varsayilan) degeri LINEER kabul eder ve /255 ile dogrudan
# yazar; bu, gercek sac albedolariyla daha tutarli cikti veriyor (Torres'in kir saci 0,45 ·
# peruk 0,89 · siyah sac 0,02-0,07 · koyu kumral 0,16/0,10/0,05 -- hepsi gercek olculere yakin).
# `TON_SRGB=True` yapilirsa deger sRGB kabul edilip lineere cevrilir; o zaman ayni renkler
# Blender'da 8-bit degerin KENDISI gibi gorunur ama kir sac 0,17'ye duser (fazla koyu).
# Manifest her iki sayiyi da tasir; README bunun dogrulanmadigini SOYLER.
TON_TAG = {0x8E9AB4EF: "a", 0x2AEEDB50: "b"}
TON_SECILEN = "b"                  # kas hakemligi (yukarida 3): 18/24
TON_SRGB = False                   # True -> saklanan deger sRGB kabul edilip lineere cevrilir
PAR_KAYIT = 16                     # parametre kaydi bayt sayisi
PAR_GENISLIK = {0x0A: 1, 0x0D: 4}  # tip -> tukettigi float sayisi
PAR_MAKS = 64                      # bir tabloda en fazla kayit (kalibrasyon: olculen maks 13)


def _par_kayit(res, o):
    """[tag u32][deger u32][u16 0][tip u8][5 B 0] -> (tag, deger, tip) ya da None."""
    if o + PAR_KAYIT > len(res):
        return None
    tag = struct.unpack_from("<I", res, o)[0]
    if tag == 0 or res[o + 8:o + 10] != b"\0\0" or res[o + 11:o + 16] != b"\0" * 5:
        return None
    return tag, struct.unpack_from("<I", res, o + 4)[0], res[o + 10]


def parametre_tablosu(res):
    """Materyalin float tasiyan parametre tablosu -> ({tag: float|[f,f,f,f]}, tablo_ofseti).

    Govdede birden cok [u32 N][N x 16 B] tablosu var (biri doku bildirimleri, tipi 0x13,
    float tuketmez). EN COK float tuketen tablo secilir -- olculen 122 sac materyalinde
    bu daima 8 kayitlik (2 x 0x0D + 6 x 0x0A = 14 float) sabit tablodur."""
    en = None
    for p in range(0, max(0, len(res) - 4 - PAR_KAYIT)):
        n = struct.unpack_from("<I", res, p)[0]
        if not (2 <= n <= PAR_MAKS) or p + 4 + n * PAR_KAYIT > len(res):
            continue
        kk = []
        for i in range(n):
            r = _par_kayit(res, p + 4 + i * PAR_KAYIT)
            if r is None:
                kk = None
                break
            kk.append(r)
        if not kk:
            continue
        gen = sum(PAR_GENISLIK.get(t, 0) for _tg, _d, t in kk)
        fo = p + 4 + n * PAR_KAYIT
        if gen == 0 or fo + gen * 4 > len(res):
            continue
        if en is None or gen > en[0]:
            en = (gen, p, kk, fo)
    if en is None:
        return {}, None
    _gen, p, kk, o = en
    out = {}
    for tag, _deger, tip in kk:
        w = PAR_GENISLIK.get(tip, 0)
        if w == 1:
            out[tag] = float(struct.unpack_from("<f", res, o)[0])
        elif w > 1:
            out[tag] = [float(x) for x in struct.unpack_from("<%df" % w, res, o)]
        o += w * 4
    return out, p


def _srgb_lineer(c):
    """sRGB (0..1) -> lineer (glTF baseColorFactor'in uzayi)."""
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def materyal_tonu(res):
    """Materyalin sac/sakal renk tonu, ya da None (sac disi materyalde parametre yok).

    Doner: {"a": [r,g,b,a], "b": [...], "srgb8": {"a": [0..255]*4, "b": [...]},
            "secilen": "b", "uzay": "linear"|"srgb->linear",
            "baseColorFactor": [r,g,b,a]}   -- glTF'e giren deger."""
    par, _off = parametre_tablosu(res)
    renk = {ad: par[tag] for tag, ad in TON_TAG.items()
            if isinstance(par.get(tag), list) and len(par[tag]) == 4}
    if len(renk) != len(TON_TAG):
        return None
    sec = renk[TON_SECILEN]
    if TON_SRGB:
        bcf = [_srgb_lineer(c) for c in sec[:3]] + [sec[3]]
    else:
        bcf = list(sec)
    return {"a": [round(c, 6) for c in renk["a"]], "b": [round(c, 6) for c in renk["b"]],
            "srgb8": {ad: [int(round(c * 255)) for c in v] for ad, v in renk.items()},
            "secilen": TON_SECILEN, "uzay": "srgb->linear" if TON_SRGB else "linear",
            "baseColorFactor": [round(min(1.0, max(0.0, c)), 6) for c in bcf]}


# ------------------------------------------------------------- TextureSet yedegi
def texture_set_bul(res):
    """materyal govdesinde TextureSet (0xD70E6670) tipli bir TOC girisine u64 referans arar.
    Doner: (ofset, ts_id) ya da None. (olculdu: ofset 59-79, materyal ~5 KB)"""
    lf = C._forge()
    for o in range(0, len(res) - 8):
        v = struct.unpack_from("<Q", res, o)[0]
        if v in lf.by_id and lf.by_id[v][2] == TIP_TEXTURESET:
            return o, v
    return None


def texture_set_coz(tres):
    """TextureSet govdesi: 2. imzadan sonra ``[01] + 14 x [tag][u64 id] + u32``.
    tag=01 dolu, 03 bos. Doner: {yuva: doku_id} ya da None (govde bulunamadi)."""
    o = tres.find(TS_IMZA, 4)
    if o < 0 or o + 5 + TS_SLOT_SAYISI * 9 > len(tres) or tres[o + 4] != 1:
        return None
    p = o + 5
    yuvalar = {}
    for s in range(TS_SLOT_SAYISI):
        tag = tres[p]
        idv = struct.unpack_from("<Q", tres, p + 1)[0]
        if tag == 1 and idv:
            yuvalar[s] = idv
        elif not (tag == 3 and idv == 0):
            return None
        p += 9
    return yuvalar or None


def _ts_slot_kaynagi(ts_id, tres, doku_id):
    """yuvadaki dokunun tanimi nerede? -> (kaynak_id, tm_indeksi, 'gomulu'|'textmap') ya da None."""
    for i, (_hdr, tex) in enumerate(DE.tm_bloklari(tres)):
        if tex == doku_id:
            return ts_id, i, "gomulu"
    lf = C._forge()
    if doku_id in lf.by_id and lf.by_id[doku_id][2] == TIP_TEXTUREMAP:
        return doku_id, 0, "textmap"
    return None


# ------------------------------------------------------------- ortak yazici
def _slot_yaz(sonuc, klasor, ad_id, slot, rol, kaynak_id, kaynak_slot, ts, kayit, progress,
              doku_id=None):
    """tek slotu coz + PNG yaz; sonuc/kayit doldurulur. Hata -> atlanan.

    `rol` artik ONSEL'dir (baglama yuvasindan): piksel cozuldukten sonra `rol_karar`
    varlik adi / sRGB bayragi / piksel imzasi ile KESIN rolu belirler, dosya adi da
    KESIN role gore verilir. Karari veren olcumler `kayit["imza"]` + `kayit["rol_ayrinti"]`
    icinde durur."""
    data, tanim, mip0_kaynagi = mip0_oku(kaynak_id, kaynak_slot)
    aile, aile_kaynagi = aile_coz(tanim)
    W, H = tanim["W"], tanim["H"]
    kayit.update({"W": W, "H": H, "aile": aile, "srgb": int(bool(tanim.get("srgb"))),
                  "mip0_kaynagi": mip0_kaynagi, "fmt_enum": int(tanim["fmt_enum"]),
                  "aile_kaynagi": aile_kaynagi})
    if aile is None:
        raise ValueError("unknown texture format enum 0x%02X" % tanim["fmt_enum"])
    if data is None:
        raise ValueError("mip0 not found (no external + embedded level-0)")
    gerek = ((W + 3) // 4) * ((H + 3) // 4) * DE.AILE_BLOK[aile]
    if len(data) < gerek:
        raise ValueError("mip0 too short (%d < %d bytes)" % (len(data), gerek))
    kayit["bayt"] = gerek
    arr = bc_decode_rgba(data[:gerek], W, H, tanim["fmt_enum"], aile=aile)
    kayit["cozucu"] = C._BCN.get("ad")
    if kayit["cozucu"] == "texture2ddecoder" and not _COZUCU_LOGLANDI[0]:
        _COZUCU_LOGLANDI[0] = True
        C._log(progress, "  texture decoder: texture2ddecoder (imagecodecs unavailable: %s)"
               % C._BCN.get("hata"))
    # --- gecerlilik kapisi: bozuk level-0 (olc: HiddenBlade gomulu 4 MB) dosya OLMAZ, atlanan olur
    ok, sebep, olcum = gecerlilik(data[:gerek], arr, aile, mip0_kaynagi)
    kayit.update(olcum)
    if not ok:
        raise ValueError("%s level-0 not decodable (%s)" % (mip0_kaynagi, sebep))
    # --- ROL: onsel (yuva) yerine olculmus karar; dosya adi KESIN role gore
    imza = piksel_imzasi(arr, tanim)
    kayit["imza"] = imza
    rol, rol_kaynagi, rol_ayrinti = rol_karar(doku_id if doku_id is not None else kaynak_id,
                                              (kaynak_id, ad_id, doku_id), imza,
                                              rol, kayit.get("rol_kaynagi") or "binding slot")
    kayit["rol"], kayit["rol_kaynagi"], kayit["rol_ayrinti"] = rol, rol_kaynagi, rol_ayrinti
    yol = os.path.join(klasor, dosya_adi(ad_id, slot, rol, ts))
    if rol == "normal":
        kayit["b_dolu_yuzde"] = round(float((arr[..., 2] > 8).mean() * 100), 2)
        # ALFA BANDI NE? (olculdu, 340 normal haritasi): 333'unde saydam piksel orani ~0 ->
        # bant GLOSS'tur. 7'sinde %26-82 tam saydam -> bant KESIM MASKESIDIR (6 sac/sakal seti +
        # Hat_S_Rich_British_Male_A). Ayrim keskin: gloss tarafinin p90'i 0.000, maksimumu
        # kesim tarafina ait. Kesim maskeli parcalar glTF'te alphaMode=MASK ister -- bunu
        # `alfa_turu` olarak kayda yaziyoruz (materyali kuran sahne.py karar verir).
        kayit["alfa_turu"] = "cutout" if imza["a_sifir"] > 0.05 else "gloss"
        rgb, gloss = normal_z_kur(arr)
        Image.fromarray(rgb, "RGB").save(yol)
        gyol = os.path.join(klasor, dosya_adi(ad_id, slot, "gloss", ts))
        Image.fromarray(gloss, "L").save(gyol)
        kayit["gloss_dosya"] = gyol
        if sonuc["normal"] is None:
            sonuc["normal"], sonuc["gloss"] = yol, gyol
        else:
            sonuc["diger"].extend([yol, gyol])
    elif rol == "diffuse":
        _srgb_png(np.ascontiguousarray(arr[..., :3]), yol)
        if sonuc["diffuse"] is None:
            sonuc["diffuse"] = yol
        else:
            sonuc["diger"].append(yol)
    else:                                           # emissive / mask / diger: referans RGBA
        Image.fromarray(arr, "RGBA").save(yol)
        if rol in ANA_ROLLER and sonuc[rol] is None:
            sonuc[rol] = yol
        else:
            sonuc["diger"].append(yol)
    kayit["dosya"] = yol
    # --- ITHALAT KOPRUSU (doku_ithal.py): PNG -> (kap, TM indeksi) yolu + degisim damgasi.
    # `slot` ADLANDIRMA numarasidir (TextureSet yuvasi 0/1/4/7 gibi); yazma hedefi ise
    # tanimin DURDUGU kabin TM blok INDEKSIDIR (kaynak_id, kaynak_slot). Ikisi TS
    # hattinda BIRBIRINDEN FARKLI -- bu yuzden manifest'e ayri ayri yazilir.
    kayit["dosya_ad"] = os.path.basename(yol)
    kayit["kap"] = "0x%X" % _mat_int(kaynak_id)
    kayit["kap_tm"] = int(kaynak_slot)
    # Kabin DURDUGU arsiv: cok-forge gorunumunde (mesh shared_00'da, kap boot'ta) ithalatcinin
    # "bu doku baska arsivde" diyebilmesi icin; tek forge'da None (manifest'in `forge`u yeter).
    kayit["kap_forge"] = _kap_sahibi(kaynak_id)
    kayit["sha256"] = C._sha256_file(yol)
    if kayit.get("gloss_dosya"):
        kayit["gloss_dosya_ad"] = os.path.basename(kayit["gloss_dosya"])
        kayit["gloss_sha256"] = C._sha256_file(kayit["gloss_dosya"])
    C._log(progress, "  texture 0x%X %s%d %s %dx%d %s -> %s"
           % (_mat_int(ad_id), "ts" if ts else "s", slot, rol, W, H, aile, os.path.basename(yol)))


def _kesim_alfa_kaydi(sonuc):
    """alfa_turu == "cutout" olan ilk slot kaydi (sac/sakal kartlari) ya da None."""
    for k in sonuc.get("slotlar") or []:
        if k.get("alfa_turu") == "cutout" and not k.get("hata"):
            return k
    return None


def _kesim_taban_yaz(sonuc, klasor):
    """Diffuse'u olmayan kesim-maskeli materyal icin beyaz RGB + maske alfali taban doku.

    glTF'te saydamlik baseColorTexture'in alfasindan gelir; maske normal dokusunun
    alfasinda oldugu icin (doku_png onu L kanalli PNG olarak yaziyor) tabani biz kuruyoruz.
    Renk verilmez -- beyaz birakilir, kullanici materyal tonunu kendi secer."""
    kayit = _kesim_alfa_kaydi(sonuc)
    if kayit is None:
        return
    sonuc["alfa_turu"] = "cutout"
    if sonuc.get("diffuse"):
        return                                    # diffuse varsa alfasi zaten kendi icinde
    kaynak = sonuc.get("gloss") or kayit.get("alfa_yolu") or kayit.get("yol")
    if not kaynak:
        return
    if not os.path.isabs(kaynak):
        kaynak = os.path.join(klasor, os.path.basename(kaynak))
    if not os.path.isfile(kaynak):
        return
    try:
        from PIL import Image
        a = Image.open(kaynak).convert("L")
        taban = Image.merge("RGBA", (Image.new("L", a.size, 255), Image.new("L", a.size, 255),
                                     Image.new("L", a.size, 255), a))
        yol = os.path.join(klasor, os.path.splitext(os.path.basename(kaynak))[0] + "_cutoutbase.png")
        taban.save(yol)
        sonuc["kesim_taban"] = yol
    except Exception as e:                                        # noqa: BLE001
        sonuc["atlanan"].append({"slot": None, "sebep": "cutout base not built: %s" % e})


def _diffuse_yok_sebep(sonuc):
    """diffuse PNG'si yoksa NEDEN yok? (glTF baseColor'i bos kalan materyalin gerekcesi)

    Olculdu: 34 tekil TextureSet'in 6'sinda (Hair_S_Short/Long/Braid/Curly, Beard_S_Long,
    Hair_S_LashesBrows) yuva 0 HIC YOK -- sacin diffuse dokusu YOKTUR, rengi materyal
    tonundan gelir. Bu bir rol hatasi degil, varligin kendi eksigidir."""
    if sonuc["diffuse"] or not sonuc["slotlar"]:
        return None
    roller = sorted({k.get("rol") for k in sonuc["slotlar"] if k.get("rol")})
    atlanan = [a for a in sonuc["atlanan"] if a.get("slot") is not None]
    if atlanan:
        return ("no diffuse texture: %d slot(s) skipped (%s); present roles: %s"
                % (len(atlanan), atlanan[0]["sebep"], ", ".join(roller) or "none"))
    return ("no diffuse texture in this material/TextureSet at all (present roles: %s) -- "
            "hair/beard sets carry only normal + masks; the base colour comes from the material "
            "tint instead and is written to baseColorFactor (see 'ton')"
            % (", ".join(roller) or "none"))


def _bos_sonuc(mat_id, klasor):
    return {"mat_id": "0x%X" % _mat_int(mat_id), "klasor": klasor, "kaynak": None, "ts_id": None,
            "diffuse": None, "normal": None, "gloss": None, "emissive": None, "mask": None,
            "diger": [], "atlanan": [], "slotlar": [], "ton": None, "sure": 0.0, "onbellek": False}


def _kap_sahibi(kap_id):
    """kabin durdugu arsivin dosya adi -- yalniz cok-forge gorunumunde bilinir (cok_forge.CokForge
    .kimin); tek forge'da None."""
    kimin = getattr(C._forge(), "kimin", None)
    return kimin(_mat_int(kap_id)) if kimin else None


def _sonuc_dosyalari(s):
    """sonucun disa verdigi HER dosya yolu: ana roller + diger + kesim tabani + slot kayitlari."""
    yollar = [s.get(k) for k in ("diffuse", "normal", "gloss", "emissive", "mask", "kesim_taban")
              if s.get(k)]
    yollar += [p for p in (s.get("diger") or []) if p]
    for k in (s.get("slotlar") or []):
        for a in ("dosya", "gloss_dosya"):
            if k.get(a):
                yollar.append(k[a])
    return yollar


def _onbellekten(depo, key, klasor):
    """Onbellekten YALNIZ diskte hala duran, en az bir dosya yazmis bir sonuc doner.

    OLCULDU (2026-09-12, kamara proplari / MapMarker ailesi): sahne.kur gomdugu PNG'leri export
    sonunda SILER (gevsek_kopya=False); onbellek PNG YOLLARINI tuttugu icin ayni TextureSet'i
    paylasan bir sonraki mesh olmayan dosyayi gosteriyor ve sessizce dokusuz cikiyordu. Kural:
    (1) sonucun verdigi HER yol (slot kayitlari, gloss ve kesim tabani dahil) diskte olmali; biri
        yoksa kayit ATILIR ve yeniden cozulur (eski kural yalniz ana rolleri yokluyordu);
    (2) hic dosya yazmamis (olumsuz) sonuc onbellekten verilmez: "material not in forge" gibi
        kararlar arsiv/zincir degisince bayatlar, yeniden hesabi ucuzdur."""
    onceki = depo.get(key)
    if onceki is None or os.path.normcase(onceki["klasor"]) != os.path.normcase(klasor):
        return None
    yollar = _sonuc_dosyalari(onceki)
    if not yollar or not all(os.path.isfile(p) for p in yollar):
        depo.pop(key, None)
        return None
    geri = dict(onceki)
    geri["onbellek"] = True
    return geri


def texture_set_dokulari(ts_id, klasor, progress=None):
    """TextureSet'in dolu yuvalarini PNG'ye cozer (set basina 1 kez, set kimligiyle adlandirilir)."""
    ts_id = _mat_int(ts_id)
    klasor = os.path.abspath(klasor)
    geri = _onbellekten(_TS_ONBELLEK, ts_id, klasor)
    if geri is not None:
        return geri
    t0 = time.time()
    sonuc = _bos_sonuc(ts_id, klasor)
    sonuc["kaynak"], sonuc["ts_id"] = "textureset", "0x%X" % ts_id
    tres = C._material_res(ts_id)
    yuvalar = texture_set_coz(tres)
    if not yuvalar:
        sonuc["atlanan"].append({"slot": None, "sebep": "TextureSet 0x%X body not parsed" % ts_id})
    else:
        os.makedirs(klasor, exist_ok=True)
    for slot in sorted(yuvalar or {}):
        ts0 = time.time()
        doku_id = yuvalar[slot]
        rol = TS_SLOT_ROL.get(slot, "ts%d" % slot)
        kayit = {"slot": slot, "rol": rol, "rol_kaynagi": "textureset", "doku_id": "0x%X" % doku_id}
        try:
            kk = _ts_slot_kaynagi(ts_id, tres, doku_id)
            if kk is None:
                raise ValueError("texture 0x%X descriptor not found (no embedded TextureMap, not in live TOC)" % doku_id)
            kayit["tanim_kaynagi"] = kk[2]
            _slot_yaz(sonuc, klasor, ts_id, slot, rol, kk[0], kk[1], True, kayit, progress,
                      doku_id=doku_id)
        except Exception as e:                                  # noqa: BLE001
            kayit["hata"] = str(e)
            sonuc["atlanan"].append({"slot": slot, "sebep": str(e)})
            C._log(progress, "  texture 0x%X ts%d SKIPPED: %s" % (ts_id, slot, e))
        kayit["sure"] = round(time.time() - ts0, 3)
        sonuc["slotlar"].append(kayit)
    sonuc["diffuse_yok_sebep"] = _diffuse_yok_sebep(sonuc)
    _kesim_taban_yaz(sonuc, klasor)
    sonuc["sure"] = round(time.time() - t0, 3)
    _TS_ONBELLEK[ts_id] = sonuc
    return sonuc


def materyal_dokulari(mat_id, klasor, progress=None):
    """Materyalin dokularini `klasor` icine PNG olarak cozer.

    Doner: {diffuse, normal, gloss, emissive, mask: yol|None,
            diger: [yol...], atlanan: [{slot, sebep}], slotlar: [olcum...],
            mat_id, klasor, kaynak: 'material'|'textureset'|None, ts_id, sure, onbellek}
    Ayni materyal ayni klasor icin ikinci cagri onbellekten doner (dosyalar
    diskte duruyorsa); klasor degismisse yeniden yazilir."""
    key = _mat_int(mat_id)
    klasor = os.path.abspath(klasor)
    geri = _onbellekten(_ONBELLEK, key, klasor)
    if geri is not None:
        return geri
    t0 = time.time()
    sonuc = _bos_sonuc(key, klasor)
    try:
        res = C._material_res(key)
    except KeyError as e:
        sonuc["atlanan"].append({"slot": None, "sebep": "material not in forge (%s)" % e})
        # Ilerleme gunlugune de yaz: slot olmayinca hicbir "texture ... SKIPPED" satiri cikmaz ve
        # kullanici dokusuz GLB'nin sebebini goremezdi (olculdu 2026-09-12; sebep cok-forge'du).
        C._log(progress, "  material 0x%X SKIPPED: not in %s (%s)"
               % (key, os.path.basename(getattr(C, "FORGE", "") or "the archive"), e))
        sonuc["sure"] = round(time.time() - t0, 3)
        _ONBELLEK[key] = sonuc
        return sonuc
    # RENK TONU MATERYALDE, TextureSet'te DEGIL (olculdu): 6 sac TextureSet'i 34 materyal
    # tarafindan PAYLASILIYOR ama her karakterin sac rengi baska. Bu yuzden ton, paylasilan
    # TS sonucundan ONCE ve materyalin KENDI govdesinden okunur.
    sonuc["ton"] = materyal_tonu(res)
    slot_sayisi = len(DE.tm_bloklari(res))
    if slot_sayisi == 0:
        # ---- TextureSet yedegi
        ts = texture_set_bul(res)
        if ts is None:
            sonuc["atlanan"].append({"slot": None, "sebep": "no TextureMap block and no TextureSet reference in material"})
        else:
            tsr = texture_set_dokulari(ts[1], klasor, progress)
            for k in ("kaynak", "ts_id", "diffuse", "normal", "gloss", "emissive", "mask",
                      "slotlar", "diffuse_yok_sebep", "kesim_taban", "alfa_turu"):
                sonuc[k] = tsr.get(k)          # kesim alanlari TS sonucundan tasinir
            sonuc["diger"] = list(tsr["diger"])
            sonuc["atlanan"] = list(tsr["atlanan"])
            sonuc["ts_onbellek"] = tsr["onbellek"]
        sonuc["sure"] = round(time.time() - t0, 3)
        _ONBELLEK[key] = sonuc
        return sonuc
    sonuc["kaynak"] = "material"
    os.makedirs(klasor, exist_ok=True)
    tms = DE.tm_bloklari(res)
    for slot in range(slot_sayisi):
        ts0 = time.time()
        rol, kaynak = slot_rolu(key, slot)
        doku_id = tms[slot][1]
        kayit = {"slot": slot, "rol": rol, "rol_kaynagi": kaynak, "doku_id": "0x%X" % doku_id}
        try:
            _slot_yaz(sonuc, klasor, key, slot, rol, key, slot, False, kayit, progress,
                      doku_id=doku_id)
        except Exception as e:                                  # noqa: BLE001
            kayit["hata"] = str(e)
            sonuc["atlanan"].append({"slot": slot, "sebep": str(e)})
            C._log(progress, "  texture 0x%X s%d SKIPPED: %s" % (key, slot, e))
        kayit["sure"] = round(time.time() - ts0, 3)
        sonuc["slotlar"].append(kayit)
    sonuc["diffuse_yok_sebep"] = _diffuse_yok_sebep(sonuc)
    _kesim_taban_yaz(sonuc, klasor)
    sonuc["sure"] = round(time.time() - t0, 3)
    _ONBELLEK[key] = sonuc
    return sonuc


def onbellek_temizle():
    """materyal + TextureSet + varlik adi + K2 ic sinir onbelleklerini bosaltir
    (yeni export klasoru / forge ya da forge zinciri degisimi / export sonu -- PNG'ler silinmis
    olabilir, bkz. _onbellekten)."""
    _ONBELLEK.clear()
    _TS_ONBELLEK.clear()
    _AD_ONBELLEK.clear()
    _IC_SINIR_ONBELLEK.clear()
