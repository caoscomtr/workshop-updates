# -*- coding: utf-8 -*-
"""mesh_ithal — duzenlenmis GLB'nin MESH tarafini oyuna geri yazan KOPRU.

Bu modul YENI BIR YAZICI DEGILDIR. Zaten olculmus dort halkayi birbirine baglar:

    glb_oku.eslestir      duzenlenmis GLB <-> export GLB (iskelet hizalamasi, parca/prim
                          eslesmesi, vertex permutasyonu, IDENTICAL/CHANGED karari)
    mesh_yaz.yaz          AYNI TOPOLOJI: uzunluk sabit, turetilmis tablolar yeniden
                          hesaplanir (330/330 degistirilmemis mesh bayt-birebir)
    mesh_yaz.yaz_serbest  TOPOLOJI DEGISTIYSE: kume-siz MeshData bicimi (gate_CMD 3);
                          herhangi bir vertex/ucgen sayisi (identity 328/330)
    kur_mesh.kur          WAL kaydi + yedek + yazma sonrasi DOGRULAMA + geri_al

--- ROTA SECIMI (parca basina) --------------------------------------------------------
  atla     : topoloji IDENTICAL ve en buyuk vertex oynamasi TASIMA_ESIK_M altinda.
             Arsive DOKUNULMAZ. (Blender bir seyi yeniden kaydetse bile kilobaytlarca
             ayni baytin yeniden yazilmasini onler.) Blender'in iki NORMALIZASYONU --
             dikis vertexi bolmesi (NV +2) ve kaynaktaki kopya ucgenleri dusurmesi
             (NT -206) -- IDENTICAL sayilir (glb_oku basligi); parca yine atlanir, onay
             metnine "SKIP <parca> - Blender re-split ... / dropped ..." notu duser.
             (2026-09-05'e kadar ikisi de CHANGED sayilip dokunulmamis rijit tabanca
             kume-siz bicimde, Weapon_Pistol_01'de 206 vanilla ucgen EKSIK yeniden
             kuruluyordu; Blender 5.2 kimlik turu, 17/17 senaryoda olculdu.)
  ayni     : topoloji IDENTICAL ama vertexler oynamis -> `mesh_yaz.yaz`. Ic dosya
             UZUNLUGU degismez; arsiv buyumez, kume yapisi korunur.
  serbest  : topoloji CHANGED (vertex/ucgen eklendi/silindi ya da ucgen kumesi degisti)
             -> `mesh_yaz.yaz_serbest`. Ic dosya buyur/kucultur, giris arsivin SONUNA
             eklenir (kur_mesh "ek" yontemi; orijinal baytlar yerinde durur).
             Onay satirinin ALTINA geometrik olcum duser (`_sekil_olcumu`): esleme varsa
             "vertices moved up to X mm", yoksa glb_oku._kaba_donusum'un butun-parca tahmini
             ("centre moved ~50.0 mm" / "scaled ~2.00x" / "rotated ~90 deg" / "local edit");
             olculemeyen "moved (not measured)" -- hicbir zaman 0,0. (2026-09-05'e kadar bu
             satir yalniz NV/NT/bayt tasiyordu: Weapon_Pistol_11'de 5 cm tasima, 2x, 0,5x,
             90 derece ve tek-vertex senaryolari kimlik turuyle karakter karakter AYNI
             satiri veriyor, `tasima_mm` olculmemisken 0.0 basiliyordu; 7 senaryoyla olculdu.)
  red      : asagidaki kapilardan biri dustu; parca YAZILMAZ, sebebi kullaniciya gider.

--- BAYAT EXPORT KAPISI (export'un kendi IBM kusuru "duzenleme" sayiliyordu) -----------
2026-09-05'te sahne.py K-1a kapandi: o tarihten ONCEKI export'larda palet IBM'i verbatim
yazildigi icin skinin `globalJoint_j @ IBM_j`'si eklemler arasi tutarsizdi. Blender ice
aktarirken tutarsizligi bakiyor, bu yuzden DOKUNULMAMIS bir tur-donusunde bile vertexler
kayiyordu -- ve rota `ayni` olup kaymis konumlar oyuna yaziliyordu. Olculdu (U_Edward_Diplomat,
02:03 export'u + Blender 5.2 kimlik turu): 01_kimlik senaryosu 12/12 parca IDENTICAL derken
"WRITE HumanBody_Mannequin 1,61 mm (539.266 B)" + "WRITE Pants 0,49 mm (207.875 B)" = 747.141 B
yaziyordu; kullanici Blender'da hicbir sey yapmamisti. Kaynak export'un olculen ust siniri
(glb_oku `ibm_kayma_m`, baslik "(1d)") 1,6115 mm / 0,4868 mm -- gozlenen kaymayla ucuncu
haneye kadar AYNI. Simdi `_bayat_ibm_mm`: IDENTICAL bir parcada oynama
TASIMA_ESIK_M + ibm_kayma_m'i ASMIYORSA rota `atla` (tek bayt yazilmaz) ve SKIP satiri
"movement is not yours ... export the item again" der; asiyorsa parca yazilir ama WRITE
satirinin altina kusurun payi (mm) DUSER. Saglam export'ta olcum hic kosmaz (ibm_kayma_m None
-> kapi 0), yani yeni export'larin davranisi bit-bit degismez: 14 senaryoluk Blender matrisi
(yeni export'tan uretilmis GLB'ler) degisiklikten ONCE ve SONRA 20 alanda 0 fark verdi.
Kapi GERCEK duzenlemeyi YUTMUYOR -- ayni bayat dosyada kusurlu parcayi bilerek otelemek
(olculdu): 0,2 mm -> tasima 1,59 mm, rota atla (fail-closed, "export again" denir);
1,0 mm -> 1,76 mm YAZILIR; 5,0 mm -> 5,02 mm YAZILIR. Bu makinedeki 18 export'un 9'u kusurlu
(CHR_AhTabai 2,571e-03 -> 0,74/1,09 mm; JulienDuCasse / Edward_Assassin / Asian x3 / Diplomat /
FirstCiv / Yasuke 4,228e-03 -> 0,05..1,61 mm); silahlar (rijit, skin yok) ve 02:53 sonrasi
export'lar temiz.

--- SAHNE YERLESIMI (butun model tasindi/donduruldu) -----------------------------------
glb_oku.hizala BUTUN modelin kati donusumunu geri alir (rijitte mesh fiti, skinlide kemik
fiti); butun modeli 5 cm tasimak ya da 90 derece dondurmek oyuna YAZILMAZ -- oyun ogeyi
kendisi yerlestirir, mesh'ler birbirine/kemiklere gore degismemistir. 2026-09-05'e kadar bu
SESSIZDI: Blender senaryo 16/17 (Pistol_02, Pistol_11, Sword_10) "2 part(s) matched,
2 unchanged in shape" verip not yazmiyordu; ayni silahta TEK parcayi 5 cm tasimak
"WRITE ... moved up to 50.00 mm" yazdigi icin kullanici tutarsizligi goremiyordu.
Simdi `glb_oku.sahne_yerlesimi` (rijit: E = A; kemikli: E = M_kok @ A) YERLESIM_* esigini
asarsa NOTE satiri duser (yazma karari degismez). Esiklerin altindaki olculen taban:
rijit kimlik 1,9e-5 derece / ~1e-16 m; skinli kimlik (kilic 327 kemik, BlackBeard) 1e-5
derece / 0,001 mm. Armature'u SILINMIS skinli dosya bu nota girmez: onun kendi notu var
(iskelet kapisi) ve tabani farklidir (Blender kemik matrisini katlamaz, A = [90 derece | 0]).

--- JOIN KAPISI (Blender Ctrl+J: "hepsini birlestirdim") ------------------------------
Export'ta olup kullanicinin dosyasinda OLMAYAN parcalar 2026-09-05'e kadar yalniz "silinmis"
sayiliyordu; buyuyen eslesmis parcayla CAPRAZ KONTROL yoktu. Oysa Ctrl+J'nin imzasi tam
budur: N eksik parca + tam onlarin geometrisi kadar buyumus TEK parca. Olculdu
(CHR_BlackBeard, senaryo 07_hepsi_join, 6 mesh Tunic'te birlestirildi): onay ekrani
"WRITE Tunic +12574 vertices (16259 -> 28833), 915315 B -> 1582381 B" + "MISSING 5 part(s)
... They stay in the game as they are" diyor, join'e dair TEK uyari yoktu; HIDE ile 5 parca
gizlenip ayni Tunic yaziliyordu. Uretilen bayt cozuldu: Boots/HeadAcc/Pants Tunic'in prim
0'ina (kaynak_i=0, CHANGED -- notsuz), Brow (MASK sac karti) ve Holster K-3 ile prim 1'e
(OPAK kumas materyali) girdi; deri GLB'den tasinmadigi icin en yakin Tunic vertexinden
geldi (Boots'un agirlik kutlesinin %0'i kendi kemiklerinde, cizmeler ELE bagli). Oyunda
sonuc: HIDE'siz cift geometri, HIDE'li yanlis materyal + yanlis deri; Workshop bunu geri
AYIRAMAZ. Simdi `_join_teshisi`: buyuyen (NV_y > NV_k) her eslesmis parcanin YENI
vertexleri (kaynak parcaya JOIN_TOL_M'den uzak olanlar) arasinda eksik parcanin
vertexlerinin JOIN_PAY'i bulunuyorsa o parca YUTULMUS -> yutan parca ROTA_RED (bayt
uretilmez), yutulanlar MISSING/HIDE listesine GIRMEZ (gizlemek oyundan cizmeyi silerdi).
scipy yoksa ya da konumlar oynamissa yedek imza: dNV == eksik NV toplami VE dNT == eksik
NT toplami. Olcum (07): 5 parcanin 12574/12574 vertexi Tunic'in 12574 yeni vertexi arasinda
maks 0,000 mm; dikis kontrolu (ayni vertexlerin ORIJINAL Tunic'e yakinligi) %0;
dNV=dNT=toplam. 03_sac_sil/05_kup_join/06_subdivide/08_secili_nesne kapiya hic girmez
(buyuyen parca + eksik parca birlikte yok); 05'in kubu K-3 notuyla yazilmaya devam eder.

--- AD TAKASI (kullanici iki nesnenin adini takas etti) --------------------------------
Ad = kullanicinin acik talimatidir (glb_oku K-2: adla eslesen parca 2-opt'a girmez), bu
yuzden adi takas edilmis parca DIGER parcanin arsiv girisine yazilir ve materyal girise bagli
kalir. 2026-09-05'e kadar bu SESSIZDI; Blender 5.2 senaryo 10c (CHR_BlackBeard, Brow<->HeadAcc
nesne+mesh adi takasi) ile olculdu: onay ekrani "WRITE Brow ... -1752 vertices (3282 -> 1530)"
+ "WRITE HeadAcc ... +1752 vertices (1530 -> 3282)" diyor, 0 red, 0 NOTE; uretilen bayt
cozuldu: Brow girisine (MASK sac karti materyali) HeadAcc'in opak mesh'i, HeadAcc girisine
(opak materyal) sac kartlari; deri de girisin orijinal vertexlerinden en yakin komsuyla
geldigi icin yanlis parcanin derisi. 10a/10b'nin (Boots<->Pants) reddi konum bandindan gelen
TESADUFTU: poz_olcek Boots 1,0, diger 5 parca 2,0 -> 15 ciftin yalniz Boots'lu 5'i yakalanir,
10'u 10c gibi gecer (10d Pants<->Holster olculdu: 2 WRITE, 0 red, 0 NOTE).
Simdi glb_oku.eslestir iki ucuz sinyali OLCUP kayda yazar, `_ad_takas_notlari` NOTE yapar
(yazma karari degismez, ad = talimat korunur):
  (i)  `ad_celiskisi` : nesne adi ile mesh adi iki FARKLI export parcasina cozuluyor
                        (10a: outliner'dan yalniz nesne adi degisti, mesh_ad eski adi tasir;
                        kaynak export'ta 6/6 parcada mesh_ad == ad, Blender tur-donusu koruyor);
  (ii) `takas_imzasi` : adla eslesmis CHANGED iki parcada NV ve NT CAPRAZ birebir
                        (10a/10b 4832/2304; 10c 3282/1530 + 2188/2840; kimlik/subdivide/join'de
                        sifir). Iki parcanin karsilikli TAM esitligi gerektigi icin yanlis alarm
                        pratikte sifir; bilincli takas yapan kullaniciyi engellemez.
Rota RED istenirse karar kaptanin: sinyaller parca kaydinda (`ad_celiskisi`, `takas_imzasi`).

--- KAPILAR (hepsi fail-closed, hepsi kullaniciya SEBEBIYLE gosterilir) ---------------
  * Blender'da JOIN edilmis parca: eksik parcalarin vertexleri buyuyen parcanin yeni
    vertexleri arasinda (ya da NV+NT artisi eksiklerin toplamina tam esit) -> yutan parca
    YAZILMAZ, yutulanlar gizlenmez (bkz. "JOIN KAPISI")
  * parca export manifest'inde yok (gid/icid kaydi olmadan nereye yazilacagi bilinmez)
  * canli arsivdeki ic dosyanin sha256'si export anindakinden farkli (arsiv degismis)
  * mesh cozulemiyor (mesh_yapisal desteklemiyor)
  * GLB primitif sayisi oyundaki primitif sayisiyla ayni degil
  * bazi primitifler eslesmedi (Blender'da primitif silinmis/eklenmis olabilir)
  * vertex eslesmesi kurulamadi (topoloji BILINMIYOR)
  * yazicinin kendi kapilari (dejenere ucgen, 65535 vertex tavani, konum bandi,
    turetilmis tablo oz-denetimi) -> mesaj dogrudan mesh_yaz'dan gelir

--- "ayni" ROTASININ ON KOSULU -------------------------------------------------------
`mesh_yaz.yaz` OYUNUN vertex sirasini bekler. Export (sahne.kur) her primitifi
`pos[b0:b1]` diliminden yazdigi icin GLB primitif i = oyun primitif i ve vertex sirasi
BIREBIRDIR. Bu varsayim EZBERLENMEZ, her parcada OLCULUR: kaynak GLB'nin primitif
konumlari oyundan okunan konumlarla karsilastirilir (float32 toleransi). Tutmazsa parca
sessizce "ayni" rotasindan DUSER ve serbest rotasina gecer -- yanlis sirayla yazmaktansa
buyuk ama dogru bir dosya yazmak yeglenir.

--- CAPRAZ ESLEME (A -> B: ad belirteci ONCE, boyut SON CARE) -------------------------
Capraz aktarimda A'nin parcalari B'nin parcalarina `_aile_anahtari` ile (Musket, Torso_X_Sash,
HumanBody_Head ...) eslenir; ayni ailede birden fazla parca varsa ic-dosya BOYUTUNA gore
siralanip zip'lenir. 2026-09-05'e kadar aile anahtari tabancanin ELDEKI modelini ve kilifta
duran `_Small` kopyasini AYIRMIYORDU (dordu de "Musket"); boyut ise 18 Small'li tabancanin
3'unde (Pistol_01/11/19) kilif kopyasinda ana modelden BUYUK. Olculdu (Weapon_Pistol_11 ->
Weapon_Pistol_03, kum forge'da kuru kosu, tek bayt yazilmadi): GoldenPistol_01A (el, 364.600 B)
WheellockPistol_Small yuvasina, GoldenPistol_Small (371.606 B) WheellockPistol_01A yuvasina
gidiyordu; geri okunan mesh'in z-boyu kilif yuvasinda 0,4850 m (yuvanin orijinali 0,3282 m),
el yuvasinda 0,3467 m (orijinali 0,5165 m) ve rapor iki satiri da "WRITE ... textures follow
the shape" diye uyarisiz onayliyordu. Katalog (silah_indeks, forge acilmadan): 306 sirali
tabanca ciftinin 90'inda (%29) kilif<->el capraz baglaniyordu, iki yonde de.
Simdi `_belirtec` (`_Small` ad belirteci; tools/silah_indeks_kur.py'nin "holstered" kuraliyla
AYNI) aile anahtarina katilir (Musket -> Musket_Small): kilif kopyasi yalniz kilif yuvasina,
eldeki model yalniz eldeki yuvaya; karsi tarafta o turden parca yoksa NO PLACE / TARGET ONLY
(yazilmaz, fail-closed). K1 ad cozumunun '?' bozulmasi tabanda belirtecin kendisine gelebildigi
icin (`Smal?`, `Sm???` katalogda var) belirtec ONCE LOD'lu `ad`dan okunur: 755 LOD kaydinda
119 Small, ad yolu 119/119, yalniz-taban yolu 119/119, yanlis pozitif 0. Duzeltme sonrasi:
el 0,4850 m -> el yuvasi (0,5165), kilif 0,3467 m -> kilif yuvasi (0,3282); 306/306 ciftte
capraz 0 (testler/tur2_capraz_esleme_kapi.py, belirtec kapatilinca 90'a doner = kapi ayirt
edici); 15-cift matrisinin diger 14 ciftinde esleme/yersiz/hedef_yalniz/red birebir ayni
(rijit->skinli'de yalniz NO PLACE metni "(Musket holster copy)" oldu). Her capraz WRITE
satirinin altina eslemenin DAYANAGI duser (`esleme_sebebi`: "holster copy -> holster copy ...",
"paired by part family 'X' (... ordered by file size - check the names)"). Adda belirteci
OLMAYAN cok-parcali aileler boyut sirasinda KALIR ve olculdu: Pistol_02 RightUp/RightDown_
Holster (z-boyu 0,35/0,39 m, Small sinifi degil, el modeli yok), Pistol_10 Hip/Chest 01A/01B,
Sword_14 R/L ve Sword_15 Right/Left (iki kilicta da R > L, boyut sirasi dogru yone dusuyor).

--- CAPRAZ HEDEFIN BICIMI (rijit/skinli karari HEDEF baytlarindan) ------------------------
Capraz modda gid/icid hedeften gelir ama `m` KAYNAGIN manifestidir; 2026-09-05'e kadar hedef
mesh `MY.oku(data, rigid=m["rigid"])` ile, yani KAYNAGIN bayragiyla okunuyordu. Skinli kaynak
(fmt 1, rigid=False) -> rijit hedef (fmt 3) bu yuzden okuyucunun "rigid fmt3 (skinless; pass
rigid=True)" ic-dil hatasina dusup REFUSED oluyordu (ters yon calisiyordu: rigid=True fmt 1'i
de cozer). Olculdu (kum forge, kuru kosu, tek bayt yazilmadi): Weapon_Sword_02 -> CHR_W_Sword
(1:1) ve OBD_SHP_Harpoon_WhaleBoat_L3 -> CIN_HiddenBladeChest_Lock_01A (9,4 m -> 5 cm) ikisi de
"the Workshop cannot decode this mesh (rigid fmt3 (skinless; pass rigid=True))" ile red; buyuk
-> kucuk senaryosu konum bandi kapisina hic gelmiyordu; parca kaydinda rigid=False (kaynagin).
Simdi capraz modda hedef `rigid=True` ile okunur ve bicimi G["rigid"] soyler (yazici zaten
R["rigid"]'den alir); o ana kadar parca kaydinda rigid=None (kaynagin bayragi tasinmaz). rigid=True
skinli (fmt 0/1) mesh'i DEGISTIRMEDEN okur (3 skinli mesh, R/G'de farkli anahtar 0/0). Sonuc:
Sword_02 -> CHR_W_Sword WRITE 508 -> 11405 vertex, 14.667 B -> 333.699 B, geri okuma fmt 3 /
rigid / NV-NT birebir, bayt kapisi 7/7, z-boyu 0,8336 m (w = 1 bandinda); 9,4 m -> 5 cm artik
GERCEK rijit konum bandi kapisina duser ("... reaches 4.7783 m"). Ters yon, skinli->skinli ve
rijit->rijit ciftleri bayt bayt ayni kaldi. Okuyucunun SEBEP_RIGID metni `_kullanici_dili`nden
gecer (kendi export'unda manifest `rigid` alani mesh'le celisirse: taze export ister); "pass
rigid=True" kullaniciya sizmaz. Kapi: testler/tur2_capraz_rigid_hedef_kapi.py (eski okuma
zorlanınca ayni olcum REFUSED'a doner = ayirt edici).

--- CAPRAZ MATERYAL KAPISI (A'nin materyali canli TOC'ta UST DUZEY giris olmali) ----------
Capraz yazimda hedef mesh'in MID+CBA'si ve hedefin LODSelector B kaydi A'nin materyaline
cevrilir (`_capraz_materyal` + `_lodsel_isleri`). 2026-09-05'e kadar id KAYNAK MANIFESTINDEN
(`parcalar[].materyaller`) alinip dogrulanmadan yaziliyordu. Olculdu (kum forge, kuru kosu,
tek bayt yazilmadi; CHR_W_Sword -> Weapon_Sword_02): rapor "textures follow the shape:
material 0x2096FAAA8BE -> 0x730D46174" + "WRITE ... (LODSelector) - 1 material reference(s)
point at the source material, so the game picks the source textures" diyordu; oysa
0x730D46174 canli TOC'ta YOK (`lf.by_id` False; kum ve gercek oyunda ayni) -- 0x73D421434
girisinin ICINE gomulu 609 B'lik materyal (tip 0x85C817C3), dokulari da o girise gomulu.
Export'un kendisi bu materyali "material not in forge" diye atlamisti (manifest
`materyaller[id].atlanan`, 0 doku slotu): aracin kendi okuyucusu (`outfit_core._material_res`
= `lf.by_id`) goremiyordu. Vanilla emsal: 3.889 LODSelector'un 2.959 dolu bant referansi
2.959/2.959 ust duzey; 241 silahin 185 LOD0 mesh'inde MID/CBA 384 ust duzey + 80 AYNI girisin
ic dosyasi + BASKA girise gomulu 0 -> aracin yazacagi desen (baska girise gomulu materyal,
ustune LODSelector'de ic-dosya referansi) 3.423 referansta SIFIR emsalli. Matristeki
trinket->kilic cifti de ayni kusuru tasiyordu (0x22D695576ED, 0x22D69557708 icine gomulu);
15 ciftin 39 manifest materyalinden yalniz bu 2'si by_id False.
Simdi `_materyal_dogrula` (olcut `lf.by_id`, okuyucuyla AYNI): dogrulanamayan materyal varsa
parca YONLENDIRILMEZ (`_materyal_prim2mat` kurulmaz -> LODSelector isi de uretilmez), mesh
MID/CBA hedefin kendi materyalinde kalir, satir "textures could not follow the shape: the
source material 0x... could not be verified in the archive ...; the target keeps its own
textures" olur, doku_ithal'in capraz NOTE'u da buna gore soylenir. Diger 13 cift birebir ayni
kaldi. Kapi: testler/tur2_capraz_materyal_kapi.py (`--sabotaj` kapiyi kapatir, kusur geri
gelir = ayirt edici). Oyun-ici sonuc (gomulu materyal cozulur mu) hala OLCULMEDI; kapi bu
yuzden fail-closed.

--- CAPRAZ MATERYAL KATLAMASI (cok materyalli kaynak -> daha az yuvali hedef) --------------
Hedef mesh yuva (primitif) KAZANAMAZ (mesh_yaz.yaz_serbest: len(primler) != len(eski_prims)
-> YazmaHatasi); `_capraz_primler` A'nin fazla gruplarini B'nin SON grubuna katlar ve
"merged into the target's last group" notunu yazar. Materyalde `_capraz_materyal` o gruba
yalniz ILK gelen kaynak grubunun materyalini yazar (`if j not in prim2mat`); 2026-09-05'e
kadar digerleri SESSIZCE dusuyor ve hemen altindaki satir "textures follow the shape: material
X -> Y on 1 group(s)" (len(k["materyal"]) = degisen HEDEF prim sayisi) kaybi yapisal olarak
soyleyemiyordu. Olculdu (Edward_Assassin -> U_Edward_Fire, kum forge, kuru kosu, tek bayt
yazilmadi): Torso 4 kaynak grubu -> 1 yuva, yazilan 0x22D90B0AB73 (grup 0, 360/33.669 ucgen),
dusen grup 1/2/3 = 0x22D90B0AC7A/ACAC/ABE4, 14.650+8.570+10.089 = 33.309 ucgen = %98,9 (dort
materyal dort FARKLI diffuse dokuya gider); ChestBelt 2 -> 1, dusen 0x22D90B0AB73 %75,4;
Sash 2 -> 1, dusen %44,0. Onay ekrani ucunde de "textures follow the shape" diye onayliyordu.
Simdi `_materyal_dusenler` katlanan her grubu OLCER (materyali hedef grubuna yazilan
materyalden FARKLI olan kaynak gruplari, GLB ucgen sayisiyla) -> parca kaydi `materyal_dusen`
[{grup, hedef_grup, materyal, kullanilan, NT}], `materyal_dusen_ucgen_pay`,
`materyal_tasinan_grup`, `materyal_yuva`; rapor satiri "textures follow the shape for source
group 0 only: ..." olur ve altina "WARNING: 3 of 4 source material group(s) cannot be carried -
... source groups 1, 2, 3 (98.9% of this part's triangles ...) will be drawn with material
0x22D90B0AB73 instead of their own" duser; doku_ithal'in capraz NOTE'u da kac parcada oldugunu
soyler (3). Materyal SECIMI degistirilmedi: uretilen 7 isin (6 mesh + LODSelector) baytlari
sha256-birebir, yalniz rapor degisti; ayni materyalli katlanan grup dusen SAYILMAZ, tek
materyalli parcalarda (Boots/Pants/ShoulderPad) satir eski haliyle (yanlis alarm 0). Reddetmek
bilerek secilmedi: kiyafet torsolarinin cogu cok materyalli, uyari kullanicinin karari. Kapi:
testler/tur2_capraz_materyal_dusen_kapi.py (K1-K7; `--sabotaj` olcumu kapatir, K1-K4/K6 duser
= ayirt edici). Oyun-ici gorunum (yanlis dokuyla cizim) bu ciftte OLCULMEDI; uyari GLB'deki
ucgen payina dayanir.

--- LOD BANTLARI (capraz SILAH: hedef grubun TUM ANA bant mesh'leri yazilir) ----------------
Silah gruplarinin LODSelector zinciri 5 bant tasir; her bantta bir ANA (B kaydi, materyalli,
cizilen) ve bir PROXY (A kaydi, golge/uzak vekili) mesh olabilir (cozum.py, bayt-dogrulandi).
Indeks (silah_indeks.json, 141 oyuncu grubu, 2026-09-05 sayildi): 108 grupta 2 ana bant
(bant 0 + bant 1; 216/216 ust duzey giris, gid == icid) + 2 proxy (247/249'u LODSelector
girisinin ICINDE), 33 grup yalniz-proxy tek mesh. Bant desenleri: 97 grup mesafe [1,1,4,32] m
(oyun_bandi 1: oyun ucuncu-sahis kamera mesafesinde bant 1'i cizer), 8 grup [10,10,20,80],
3 grup [4,4,16,32], 33 grup [20]/[10]. 2026-09-05'e kadar capraz yazici YALNIZ lodlar[0]'i
(bant 0, 1,0 m'ye kadar) ve LODSelector'da yalniz onun B kaydini yaziyordu (hakem K4, kum
forge, kuru kosu: Sword_10 -> Sword_29 plan 1 mesh + LODSelector B[band 0]; cozum.coz(hedef)
.yazilacak 4 mesh; oyun_lod0 0x2458930C4FF planda YOK; rapor "The shape and its textures move"
diyordu, LOD siniri hicbir yerde yoktu). Oyun ici emsal cozum.py basliginda: Drake kiliclarinda
(ayni [1,4,...] bant duzeni) yalniz bant-0 yazilinca HICBIR SEY DEGISMEDI, bant-1 yazilinca
gorundu.
Simdi `_hedef_parcalari` silahta her kayda indeksten `bantlar` ekler (`_silah_bant_tablosu`:
lodlar ile zincir.rol/bant/mesafe hizali degilse None = bilgi yok, sessiz varsayim yok);
`_capraz_bant_kararlari` birincilden sonra diger ANA bantlar icin AYNI kaynak parcayla
`_parca_karari` cagirir (kayit `bant_ek`/`bant`/`bant_mesafe`/`ad_taban`, `ad` "... [LOD band
N]"; birincil listede ONCE kalir), `_lodsel_isleri` iki mesh'in B kaydini ayni LODSelector
isinde cevirir. Proxy bantlara DOKUNULMAZ (LODSelector girisinin ic dosyasi; ayni gid'e ust
uste yazma olculmedi) ve rapor "LOD bands:" satiriyla bunu mesafeleriyle SOYLER
(`_lod_kapsam_metni`: "...beyond 4.0 m the target's original outline shows"). TUM-YA-DA-HIC:
bir ana bant dusurse birincil de RED (sebep bandi ve mesafeyi soyler). HIDE ayni kurali izler
(`_eksik_bant_girdileri`: hedef-yalniz silah parcasi birincil + diger ana bantlariyla gizlenir;
`eksik` listesi parca basina TEK kayit kalir, arayuz sayaci bozulmaz).
Olculdu (kum forge, testler/tur2_lod_bant_kapi.py 21/21, --sabotaj ayirt edici 3/3):
Sword_10 -> Sword_29 plan 3 is (bant 0 472.674 -> 271.486 B, bant 1 0x2458930C4FF 170.244 ->
224.798 B, LODSelector B[band 0] + B[band 1] -> 0x22CC4062B9C); bant-1 baytlari geri okundu:
NV/NT 5836/9430 birincille ayni, bbox A ile 0,0 mm, bayt kapisi 7/7. Pistol_11 -> Pistol_03
6 is (4 mesh + 2 LODSelector, ikisinde de iki bant). Trinket -> Sword_02 2 mesh (materyal
kapisi kapali, LODSelector isi yok). Uctan uca (kum kopyasi): 3 giris kuruldu, arsivden geri
okundu (NV/bayt/materyal niyetle ayni), geri alindi -> 25.641.569.500 B, 3 girisin ic baytlari
sha256-birebir, aktif yama 0. 15-cift matrisi: kiyafet ciftleri birebir (4/7/2 is), buyuk->
kucuk redleri ayni (birincil RED -> bantlara gidilmez). Bant-1 yaziminin oyun ici
gorunurlugu Drake olcumune dayanir; bu ciftler icin oyunda henuz gorulmedi (kaptanin tek testi).

2026-09-07 -- AYNI OGE (IMPORT 3D, capraz DEGIL) de artik butun ANA bantlara yazar.
Kusur: kullanicinin OLAGAN akisi grup basina yalniz lodlar[0]'i yaziyordu; `silah` bayragi
`if capraz:` blogunda hapisti ve bant tablosu hic kurulmuyordu. Olculdu (silah_indeks.json,
268 grup / 755 mesh girisi): 159 grupta IKI ana bant var, bant bilgisi olan 244 grubun
116'sinda `oyun_bandi` = 1 -- ucuncu-sahis kamera mesafesinde oyun BANT 1'i cizer, yani o
gruplarda yazilan tek mesh hic gorunmuyordu (Drake kiliclarinda oyun ici olculmustu: yalniz
bant-0 yazilinca HICBIR SEY DEGISMEDI). Weapon_Sword_19 = 2 grup x 4 bant = 8 mesh girisi;
plan ONCE 2, SIMDI 4 giris yaziyor (testler/test_lod_bant.py K1b). Alti silahlik olcumde
(Sword_19/10/29/14, Pistol_11/03) kapsam 10/40'tan 20/40'a cikti ve eksik ANA bant 0 oldu.
Yol AYNI kod: `_capraz_bant_kararlari(..., ayni_oge=True)` bant mesh'ini `_parca_karari
(capraz=True)` ile yazar (bant mesh'i AYRI bir arsiv girisidir, kendi topolojisi vardir,
birincilin sha'si ona uymaz); fark yalniz raporda -- satir "A -> B" demez. Birincilin rotasi
`ayni` (topoloji degismemis) olabilecegi icin bant kapisi artik `serbest` VE `ayni` rotalarini
gecirir; `atla`/`red`de bantlara gidilmez. GIZLE yolundaki ayni bosluk da kapandi: ayni-oge
`eksik` kaydina `bantlar` konur ve `_eksik_bant_girdileri` ek kayitlarda `sha256`i BOSALTIR
(manifest yalniz birincilin ozetini tasir; kopyalanan ozet her bant-1 gizlemesini "the game
archive changed since this export" diye reddediyordu -- yanlis teshis, olculdu).

PROXY KARARI (2026-09-07 yeniden olculdu, karar DEGISMEDI: proxy'ler vanilla kalir):
  (1) 318/318 ANA mesh ust duzey arsiv girisidir (gid == icid) -> her bant bagimsiz yazilir.
      413 PROXY'nin 366'si (%88,6) grubun LODSelector GIRISININ gid'inde durur ve 145 grupta
      IKI proxy AYNI gid'i paylasir; proxy yazmak tek arsiv girisine bir ithalatta 2-3 ust
      uste yazma demektir (LODSelector materyal isi de ayni girise gider) -- olculmemis.
  (2) Proxy ucgen butcesi ana mesh'in %11,4'u (medyan, 325 cift; ana medyan 8.146, proxy 1.237
      ucgen): tam ayrintili sekli 32 m'lik vekile ve golge mesh'ine yazmak gorunmeyen bir seye
      ~9 kat poligon odemektir.
  Karar SESSIZ degil: `_lod_kapsam_metni` hangi bantlarin yazildigini ve hangi mesafeden
  sonra ogenin kendi orijinal seklinin gorunecegini soyler, ozet `bant_ozeti` ile doku_ithal'e
  gider ("drawn at 8 distance bands ...; the same shape is written to 4 of them").

--- KIYAFET BANTLARI (2026-09-08: kiyafet/karakter parcalari da BUTUN bantlariyla yazilir) ---
Topluluk raporu (Maxx, Discord 2026-09-08): Edward Kenway's Robes'ta Swap parts ile etek
(Torso_Edward_Assassin_X_Dress) yuvasina baska parca koydu; "onizlemede goruyor, oyunda hicbir
sey degismedi". Olculdu (kum havuzu, plan): kiyafet yolunda bant tablosu HIC kurulmuyordu
(`if silah` kapisi), Swap parts Dress'in 5 LOD girisinden (indeks + cozum zinciri ayni sayiyi
verir: 0x23020FC0115, 0x24566E02EC7/ECE/ED5/EDC) yalniz 1'ine (LOD0) yaziyordu; "eksik parcayi
gizle" yolu da 1/5. Onizleme (onizleme3d.Oturum.sahne lod=0) tam o LOD0 girisini okur -> orada
gorunur; oyun 4 m'lik ilk bant sinirinin otesinde (mesafe [4,16,24,32,48]) vanilla LOD1..4'u
cizer. Ayni aile: v0.13 silah yarim-yama dersi.
Kiyafet indeksi (onizleme3d_indeks.json, 760 grup): 708 grupta birden cok LOD girisi; rol
desenleri [main,proxy,main,proxy,proxy] 299 grup, [proxy x5] 285 grup (A kaydi var, B YOK --
oyun o A mesh'lerini cizer, "ana bant" kavrami yok). 1.981/3.311 giris LODSelector girisinin
gid'inde ALT DOSYA (251 grupta 3, 211 grupta 5 LOD ayni gid'de) -> bir ithalatta ayni gid'e
ust uste yazma OLAGAN durumdur (kur_mesh zincir kaydi: `ustune`, geri alma en yeniden eskiye).
Simdi `_kiyafet_bant_tablosu` her grubun HER (gid, icid) ciftini anahtarlar (bayat export'ta
da bulunur) ve her banda `yazilir=True` koyar; `_bant_yazilir` silahta eski kurali (yalniz
'main') korur. plan(): tablo ve `_capraz_bant_kararlari` artik `silah` kosulsuz; HIDE
(`_eksik_bant_girdileri`) ayni kural; rapor "LOD bands: all N meshes of this part are
rewritten"; `bant_ozeti` kiyafette `oge: "item"` tasir. Silah davranisi ve sozlesmesi
DEGISMEDI (test_lod_bant K1/K2/K8 ayni). Kapi: testler/test_swap_parts_bantlar.py.

--- PAYLASIM (yazma yolu, 2026-09-07) --------------------------------------------------
Gizleme yolu 2026-09-05'ten beri "SHARED: N other item(s) draw this same mesh and lose it
too" diyordu; YAZMA yolunda parca kaydinin `paylasan` alani None kaliyordu, yani 24 kiyafette
ortak olan HumanBody'yi yeniden yazan kullanici bunu hicbir yerde gormuyordu (olculdu:
U_Edward_Asian plani 14 WRITE / 0 SHARED). Simdi yazilacak her parca icin
`_paylasan_oge_sayisi(gid, haric=<oge>, silah_dahil=True)` olculur (forge acilmaz, gid basina
tek kez), `paylasim_uyarisi` sozlesme alanina N>=2 olanlar girer ve satiri doku_ithal basar
(U_Edward_Diplomat: 24 / 23 / 6). `silah_dahil` YENI ve varsayilani False: gizleme yolunun
davranisi bit-bit korunsun diye. Olculdu, gerekiyor: silah indeksinde 81 gid'i 2-3 SILAH
ogesi paylasiyor (Trinket_Golden_Earrings ile CHR_TRK_Gold_Earring ayni girisi cizer) ve
yalniz kiyafet indeksi + envanter taranirsa bunlarin hepsine 0 denir.

--- TUMU-YA-DA-HIC: UYGULA (2026-09-07) ------------------------------------------------
Plan asamasindaki tum-ya-da-hic 2026-09-05'te kurulmustu; YAZMA asamasinda yoktu: `uygula`
isleri duz dongude kuruyor, biri reddedilince `continue` deyip digerlerini birakiyordu --
yarim yazilmis bir parca (yalniz bant 0) kullaniciya "SUCCESS" olarak gorunuyordu ve oyunda
hicbir sey degismiyordu. Simdi `plan` birincil + bantlarina ayni `grup_id`yi verir
(gizleme kayitlari da), `uygula` gruplari bir birim olarak kurar ve bir uyesi dusunce o
grubun YAZILANLARINI `kur_mesh.geri_al` ile EN YENIDEN ESKIYE geri alir (arsivin sonuna
eklenen blok ancak en ustteyken kirpilabilir), grubu "ok": False isaretler ve mesaji durust
kurar. LODSelector isi KENDI grubudur: birden cok parcaya hizmet eder ve dusmesi mesh'leri
gecersiz kilmaz (yalniz dokular hedefin kendi materyalinde kalir).

--- GOVDE KAPISI (capraz HIDE: karakterin kendi derisi asla gizleme adayi olmaz) ----------
Capraz modda "Hide parts missing from my file" hedef-yalniz parcalarin HEPSINI gizliyordu; aile
suzgeci yoktu. Olculdu (U_Edward_Fire -> U_Edward_Templar, gizle_eksik=True, kum forge, kuru
kosu, tek bayt yazilmadi): Fire export'unda govde grubu yok (14 parca: Boots/Bracer/Cape/Hat/
Pants/Torso*), Templar'da HumanBody_Mannequin (539.266 B) + HumanBody_Head_Mannequin (71.105 B)
var -> ikisi hedef-yalniz -> 8 HIDE icinde "HIDE HumanBody_Mannequin_LOD0 - not in your file"
(geri-oku gizli_mi=True, 23.956 bayt degisti). Kullanici tunigi kaldirmak isterken Edward'in
govdesi ve kafasi gorunmez olurdu; "not in your file" metni de yaniltici: kaynak bu parcayi hic
iceremezdi, kullanici silmedi. Kapsam (indeks + envanter, 446 oge, forge acilmadan sayildi):
HumanBody gid 0x02361965BBBA 24 kiyafette, HumanBody_Head 0x02361965BBAC 25 ogede AYNI arsiv
girisi; NPC yuz mesh'i HumanBody_Head_Crowd (aile 'Head', taban 'Head_X#1') 0x024EDEDCAF6D
80 NPC karakterinde ortak. Gizleme IndexBuffer'a yazildigi icin tek tik 24 (ya da 80) ogede
birden govde/yuzu silerdi. Govdesiz 53 kaynak (Fire + 52 CHR_*) x 24 govdeli hedef = 1.272
capraz ciftte ayni otomatik HIDE tetikleniyordu.
Simdi hedef-yalniz kayit `_govde_mi` ise (aile / taban / ad koku GOVDE_KOKLERI: HumanBody,
Head; HeadAcc/FaceAcc DEGIL) `eksik` listesine GIRMEZ (arayuz kutusunun sayaci onu saymaz,
gizlenmez), `govde` listesine girer (ad/gid/aile + ayni girisi tasiyan DIGER oge sayisi
`_paylasan_oge_sayisi` ile indeksten OLCULUR) ve rapor "BODY ... A cross-import never hides
them ... shared by up to N other item(s)" der. HIDE satiri hedef-yalniz parcada "the source
item has no part of this kind" der ("not in your file" degil); ozet satiri capraz modda
"have no source part" der. Kendi export'unda (capraz degil) Blender'da silinen govde ESKISI
GIBI gizlenir: o kullanicinin acik secimidir. Olculdu (duzeltme sonrasi, ayni cift): 6 HIDE
(Glove + 5 Tunic), govde 2 (paylasan 23 / 24), yazilacak 12 -> 10; kontrol cifti
Edward_Assassin -> Templar (govde eslesir) birebir ayni kaldi (6 HIDE, govde 0). Kapi:
testler/tur2_capraz_govde_kapi.py (`--sabotaj` GOVDE_KOKLERI'ni bosaltir, 8 HIDE geri gelir =
ayirt edici). Oyun-ici gorunum olculmedi; kanit bayt duzeyinde (gizle.gizli_mi).
"""
import os
import time

import numpy as np

import functools

import outfit_core as C
import uzman as UZ                                    # UZMAN MODU (bkz. src/uzman.py)

try:
    from . import cok_forge as CF
    from . import forge_giris as FG
    from . import glb_oku as GO
    from . import kur_mesh as KM
    from . import mesh_yapisal as MY
    from . import mesh_yaz as MZ
except ImportError:                                   # modul dosya yolundan yuklendiyse
    import cok_forge as CF
    import forge_giris as FG
    import glb_oku as GO
    import kur_mesh as KM
    import mesh_yapisal as MY
    import mesh_yaz as MZ

__all__ = ["plan", "uygula", "duzenli_glb_bul", "rapor_satirlari", "SURUM",
           "ROTA_ATLA", "ROTA_AYNI", "ROTA_SERBEST", "ROTA_RED", "ROTA_GIZLE", "ROTA_MATERYAL"]

SURUM = "1.1"


def _zincirli(fn):
    """YAMA ZINCIRI (2026-10-12): plan/uygula orijinal mesh'i oyunun gordugu zincirden okur
    (CF.okuma_gorunumu: boot_patch_01 > boot) ve kur_mesh.kur ayni halkaya yazar (etkin_arsiv).
    Connor/Altair gibi Patch_01'de guncellenen parcalarda eski tek-forge okuma boot'un ESKI
    mesh'ini temel aliyor, yazma boot'a gidiyor, oyun patch'i gostermeye devam ediyordu."""
    @functools.wraps(fn)
    def sar(*a, **k):
        with CF.okuma_gorunumu(C, getattr(C, "FORGE", None)):
            return fn(*a, **k)
    return sar
DUZENLI_GLB_ONEK = "_edit"


# ------------------------------------------------------------------ UZMAN MODU
# Bu modulde YEDI politika kapisi vardir (C3, C4, C6, C7, C8, C9, C13). Hepsi ayni
# desendedir ve KAPI ADI `uzman.KAPILAR`dan gelir:
#     if <kosul>:
#         if not UZ.kapi("<ad>"):
#             k["sebep"] = <bugunku metin>;  return k          # varsayilan: REDDET
#         _uzman_uyar(k, "<ad>", ...)                          # uzman: devam + UYARI
# Uyari KAYBOLMAZ: parca kaydinda `uzman_uyarilari`, plan sozlugunde de ayni adli
# liste tutulur ve `plan()` bunlari `notlar`a da dusurur -- yani A ajani arayuzu
# baglamadan once bile onay ekraninda gorunurler.
#
# GUVENLIK kapilari uzman modunda da REDDEDER ve buradaki desene HIC girmezler:
# oyun acikken yazma, ayni arsiv girisine iki yazici (`doku_kaplari` / `KM._catisma`),
# `kur_mesh`in yazma sonrasi dogrulamasi, geri-alma deposu, YAZMA_KILIDI.
def _uzman_uyar(k, ad, **kw):
    """Parca kaydina bir uzman uyarisi ekler ve metnini doner."""
    m = UZ.uyari(ad, **kw)
    k.setdefault("uzman_uyarilari", []).append(m)
    return m


def _uzman_topla(out):
    """Parca kayitlarindaki uzman uyarilarini PLAN sozlugune tasir ([{ad, uyari}]).
    Ayni uyari iki kez yazilmaz (LOD bant kayitlari birincilin adini tasiyabilir).
    Onay ekranina `rapor_satirlari` "EXPERT" satirlari olarak basar."""
    var = {(e.get("ad"), e.get("uyari")) for e in (out.get("uzman_uyarilari") or [])}
    for k in out.get("parcalar") or []:
        for u in k.get("uzman_uyarilari") or []:
            imza = (k.get("ad"), u)
            if imza in var:
                continue
            var.add(imza)
            out.setdefault("uzman_uyarilari", []).append({"ad": k.get("ad"), "uyari": u})

ROTA_ATLA = "atla"
ROTA_AYNI = "ayni"
ROTA_SERBEST = "serbest"
ROTA_RED = "red"
# Parca export'ta var ama kullanicinin dosyasinda YOK (Blender'da silinmis) ve
# kullanici "eksik parcalari oyundan kaldir" dedi: parca oyunda GORUNMEZ yapilir
# (bkz. gizle.py: DEJENERE INDEKS -- her ucgen (a,b,c) -> (a,a,a); oyunun kendi dolgu
# bicimi, 2977/2977 vanilla dolgu ucgeni boyle. Konum/UV/deri/normal'e dokunulmaz,
# ic dosya uzunlugu sabit, degisen baytlarin hepsi IndexBuffer icinde; 330/330 mesh kapisi).
ROTA_GIZLE = "gizle"
# Capraz aktarimda hedefin LODSelector girisi: B kayitlarindaki materyal referansi A'nin
# materyaline cevrilir (dokular sekli izlesin). Mesh'in kendi MID+CBA'si ayni iste yazilir.
ROTA_MATERYAL = "materyal"

# Bu esigin ALTINDAKI oynama "degismedi" sayilir. 10 mikron: konum tamponu s16
# ile nicemlendigi icin gercek adim tipik bir parcada 60 mikron civarindadir
# (poz_olcek 2 m / 32768), yani bu esigin altindaki her oynama zaten AYNI
# baytlari uretir. Ustu ise Blender'in float32 + iskelet hizalamasi gurultusu
# (dokunulmamis bir tam turda maks 2,3e-6 m olculdu). Esik yalniz bir HIZ
# kisayolu: altina duseni yazsak bile mesh_yaz ayni baytlari verir ve
# "identical after rebuild" dalina duser.
TASIMA_ESIK_M = 1e-5
# Sahne yerlesimi NOT esikleri (bkz. baslik "SAHNE YERLESIMI"): butun modelin hizalamayla
# geri alinan tasinmasi/donmesi bunu asarsa kullaniciya soylenir. Olculen taban gurultusu
# (kimlik turu) rijitte 1,9e-5 derece / ~1e-16 m, skinlide 1e-5 derece / 1e-6 m; bir
# kullanicinin bilerek yaptigi en kucuk hareket (Blender'da 1 mm / 1 derece) bunun uzerinde.
YERLESIM_ACI_ESIK_DERECE = 0.1
YERLESIM_OTELEME_ESIK_M = 5e-4
# UV bu kadar oynamadiysa UV tamponu YAZILMAZ (dokunulmamis kanali yeniden
# nicemlemekten kacinmak; doku tarafindaki "degismeyen dosya yazilmaz" kurali).
UV_ESIK = 1e-6
# "ayni" rotasinin on kosul toleransi: GLB float32, oyun s16 -> 0,1 mm bol bol yeter
GLB_SIRA_TOL_M = 1e-4
# JOIN KAPISI (bkz. baslik): eksik parcanin vertexi, buyuyen parcanin YENI vertexine bu kadar
# yakinsa "icinde" sayilir. Olculen taban: join'de 0,000 mm (ayni float32 baytlar), kimlik
# turunda hizalama gurultusu 2,3e-6 m; dikis vertexleri bile kaynak parcaya yakinlik
# kontrolunde %0 verdi. 0,5 mm ikisinin de cok ustunde, bilincli bir duzenlemenin altinda.
JOIN_TOL_M = 5e-4
# Eksik parcanin vertexlerinin bu PAYI buyuyen parcanin icindeyse parca yutulmus sayilir.
# %100 degil: join'den sonra birkac vertex oynatan kullanici da join yapmistir (fail-closed).
JOIN_PAY = 0.9
# GOVDE KAPISI (bkz. baslik): karakterin kendi DERISI olan parca aileleri. Capraz modda
# hedef-yalniz kalan bu parcalar gizleme adayi OLMAZ. Olculdu (indeks + envanter, 446 oge):
# HumanBody / HumanBody_Head oyuncu kiyafetlerinde 24 / 25 ogede AYNI arsiv girisi; NPC yuzu
# HumanBody_Head_Crowd (aile 'Head') 80 karakterde ortak. HeadAcc / FaceAcc (sapka, maske) DEGIL:
# kok belirteci tam esitlikle karsilastirilir.
GOVDE_KOKLERI = ("HumanBody", "Head")


def _govde_mi(h):
    """Hedef parca kaydi ({ad, taban, aile}) karakterin kendi govdesi/yuzu mu? Aile anahtarinin,
    tabanin ya da adin ILK belirteci GOVDE_KOKLERI'nden biriyse True. 'Head_Adewale#1' tabanli
    'HumanBody_Head_Crowd_LOD0' iki yoldan da yakalanir; 'HeadAcc_*' / 'FaceAcc_*' yakalanmaz."""
    for s in (h.get("aile"), h.get("taban"), h.get("ad")):
        if str(s or "").split("_")[0] in GOVDE_KOKLERI:
            return True
    return False


def _paylasan_oge_sayisi(gid_hex, haric=None, silah_dahil=False):
    """Bu arsiv girisini (gid) herhangi bir LOD parcasi olarak tasiyan indeks + envanter
    ogelerinin sayisi, `haric` (hedefin kendisi) disinda. Forge ACILMAZ (iki JSON taranir);
    olculemezse None -- rapor o zaman sayi basmaz, tahmin yazmaz.

    silah_dahil=True ise SILAH indeksi de taranir. Varsayilan False cunku gizleme yolu
    (2026-09-05'ten beri kurulu, "SHARED: N other item(s) ... lose it too") bu sayiyi iki
    kaynaktan olcuyor ve davranisi degistirilmedi. Yazma yolu (2026-09-07) True verir:
    olculdu, silah indeksinde 81 gid'i 2-3 SILAH ogesi paylasiyor (orn. Trinket_Golden_Earrings
    ile CHR_TRK_Gold_Earring ayni girisi cizer) ve iki JSON'luk tarama bunlarin hepsine 0 der."""
    try:
        from . import sahne as S3
    except ImportError:
        import sahne as S3
    try:
        gid = int(str(gid_hex), 16)
        idx, _y = S3.indeks_yukle()
        env, _y2 = S3.envanter_yukle()
        sil = {}
        if silah_dahil:
            try:
                sil, _y3 = S3.silah_indeks_yukle()
            except Exception:                                   # noqa: BLE001
                sil = {}                                        # indeks yoksa iki kaynakla yetin
        ogeler = set()
        for ad, v in list(idx.items()) + list(env.items()) + list(sil.items()):
            if ad == haric or not isinstance(v, dict):
                continue
            for g in (v.get("gruplar") or v.get("parcalar") or []):
                for l in (g.get("lodlar") or []):
                    try:
                        if l and l[1] is not None and int(l[1]) == gid:
                            ogeler.add(ad)
                    except (TypeError, ValueError, IndexError):
                        pass
        return len(ogeler)
    except Exception:                                           # noqa: BLE001
        return None


def _log(progress, s):
    C._log(progress, s)


def _ad_takas_notlari(rap):
    """glb_oku.eslestir'in olctugu iki AD sinyalini onay ekrani NOTE satirlarina cevirir
    (bkz. baslik "AD TAKASI"). Yazma karari DEGISMEZ (ad = kullanicinin talimati, K-2);
    yalniz soyler. Doner [str] (Ingilizce)."""
    L = []
    kayitlar = rap.get("parcalar") or []
    # (i) nesne adi ile mesh adi iki FARKLI export parcasini gosteriyor (10a: 2 parca)
    celiski = [r for r in kayitlar if r.get("ad_celiskisi")]
    if celiski:
        L.append("object and mesh names disagree: %s. The OBJECT name decides which archive "
                 "entry a part is written into, so each of these goes where its object name "
                 "says. If you renamed objects in Blender by accident, rename them back before "
                 "importing."
                 % "; ".join("object '%s' holds the mesh of '%s'"
                             % (r["ad"], r["ad_celiskisi"].get("mesh_ad_kaynak")) for r in celiski))
    # (ii) adla eslesmis CHANGED ciftte NV/NT capraz birebir (10a/10b/10c: tek cift)
    gorulen = set()
    for r in kayitlar:
        d = r.get("takas_imzasi")
        if not d or (d, r["ad"]) in gorulen:
            continue
        gorulen.add((r["ad"], d))
        L.append("%s and %s carry each other's original vertex and triangle counts - did you "
                 "swap their names? Names decide where a part is written: each shape would go "
                 "into the OTHER part's archive entry and take that entry's material. Rename "
                 "them back in Blender if that is not what you meant." % (r["ad"], d))
    return L


def _yerlesim_notu(hiz, skinli):
    """Butun modelin hizalamayla geri alinan tasinmasi/donmesi esigi asiyorsa kullaniciya
    giden NOT metni; yoksa None. Yazma kararina dokunmaz (bkz. baslik "SAHNE YERLESIMI")."""
    yer = (hiz or {}).get("yerlesim") or {}
    aci = float(yer.get("aci_derece") or 0.0)
    mm = 1000.0 * float(yer.get("oteleme_buyuklugu_m") or 0.0)
    if aci <= YERLESIM_ACI_ESIK_DERECE and mm <= 1000.0 * YERLESIM_OTELEME_ESIK_M:
        return None
    if skinli:
        return ("the whole model (armature and meshes together) sits %.1f mm away and %.1f deg "
                "turned from where the export put it. The meshes did not move relative to the "
                "bones, so that counts as scene placement, not a shape edit: nothing is written "
                "for it and the game keeps placing the item itself." % (mm, aci))
    return ("the whole model sits %.1f mm away and %.1f deg turned from where the export put it - "
            "every part moved together in Blender, or the file was exported with another up axis. "
            "That counts as scene placement, not a shape edit: nothing is written for it and the "
            "game keeps placing the item itself. Edits to the shape (moving some vertices, or one "
            "part relative to the others) are still picked up." % (mm, aci))


def _sha(b):
    import hashlib
    return hashlib.sha256(b).hexdigest()


def duzenli_glb_bul(klasor, man):
    """Kullanicinin Blender'dan kaydettigi GLB: export'un kendi GLB'si DISINDAKI .glb.
    Birden cok varsa `<anahtar>_edit.glb` tercih edilir, yoksa en yeni tarihli."""
    import glob
    kendi = os.path.normcase(man.get("glb") or "")
    adaylar = [p for p in glob.glob(os.path.join(klasor, "*.glb"))
               if os.path.normcase(os.path.basename(p)) != kendi]
    if not adaylar:
        return None
    tercih = os.path.normcase("%s%s.glb" % (man.get("anahtar"), DUZENLI_GLB_ONEK))
    for p in adaylar:
        if os.path.normcase(os.path.basename(p)) == tercih:
            return p
    return max(adaylar, key=os.path.getmtime)


# ------------------------------------------------------------------ yardimcilar
def _prim_esleme(parca, y_parca):
    """eslestir raporundan {oyun_prim_indeksi: (glb_prim, prim_kaydi)}.
    `q["kaynak_i"]` KAYNAK GLB'nin primitif indeksidir; export her primitifi oyun
    sirasiyla yazdigi icin bu ayni zamanda OYUN primitif indeksidir."""
    esle = {}
    for q, yp in zip(parca["primler"], y_parca["primler"]):
        if q.get("kaynak_i") is not None:
            esle[int(q["kaynak_i"])] = (yp, q)
    return esle


def _fazla_primler(parca, y_parca):
    """Kaynakta karsiligi OLMAYAN GLB primitifleri (Blender'da join edilen yeni geometri).
    Doner [(glb_prim, prim_kaydi)]."""
    out = []
    for q, yp in zip(parca.get("primler", []), y_parca.get("primler", [])):
        if q.get("kaynak_i") is None and int(yp.get("NV") or 0) > 0:
            out.append((yp, q))
    return out


def _prim_birlestir(a, b):
    """Iki serbest-rota primitif sozlugunu tek primitifte birlestirir (indeksler kaydirilir)."""
    n = len(a["pos"])
    out = {"pos": np.concatenate([np.asarray(a["pos"], np.float64), np.asarray(b["pos"], np.float64)]),
           "tri": np.concatenate([np.asarray(a["tri"], np.int64).reshape(-1, 3),
                                  np.asarray(b["tri"], np.int64).reshape(-1, 3) + n])}
    for k in ("uv0", "uv1", "normal"):
        if a.get(k) is not None and b.get(k) is not None:
            out[k] = np.concatenate([np.asarray(a[k], np.float64), np.asarray(b[k], np.float64)])
    return out


def _oyun_sirasi_mi(R, G, k_parca, n_prim):
    """`ayni` rotasinin on kosulu: kaynak GLB primitif vertexleri oyunun sirasinda mi?
    Doner (True, None) ya da (False, olculen_maks_fark_metre)."""
    if len(k_parca["primler"]) != n_prim:
        return False, None
    oyun_pos = np.asarray(G["pos"], np.float64)
    maks = 0.0
    for i in range(n_prim):
        kp = k_parca["primler"][i]
        v0, v1 = MZ._kaynak_vertex_araligi(R, G, i)
        if (v1 - v0) != kp["NV"]:
            return False, None
        d = np.abs(np.asarray(kp["pos"], np.float64) - oyun_pos[v0:v1])
        maks = max(maks, float(d.max()) if d.size else 0.0)
        if maks > GLB_SIRA_TOL_M:
            return False, maks
    return True, maks


def _ayni_diziler(R, G, parca, y_parca, k_parca, esle, n_prim):
    """`mesh_yaz.yaz` icin TAM MESH dizileri (oyun vertex sirasinda).
    Doner (pos, normal|None, uv0|None, olcum) ya da (None, None, None, sebep_metni)."""
    nv_all = int(G["NV"])
    pos = np.asarray(G["pos"], np.float64).copy()
    nrm = None
    uv0 = None
    uv_oynadi = False
    for i in range(n_prim):
        yp, q = esle[i]
        kp = k_parca["primler"][i]
        perm, _y = GO.vertex_perm(yp, kp)
        if perm is None:
            return None, None, None, ("primitive %d could not be matched vertex-for-vertex" % i)
        v0, v1 = MZ._kaynak_vertex_araligi(R, G, i)
        nv = v1 - v0
        # perm bir SURJEKSIYON olabilir (GLB'de dikis kopyalari fazla): uzunlugu GLB NV'si,
        # degerleri oyun indeksleri; her oyun vertexi en az bir kez kapsanmali.
        ikiz = kp.get("_ikiz_kanonik") if nv != len(perm) else None
        if nv != len(perm) and not (len(perm) > nv and int(perm.max()) < nv and ikiz is not None):
            return None, None, None, ("primitive %d has %d vertices in the game but %d in the "
                                      "export" % (i, nv, len(perm)))
        gecici = np.empty((nv, 3), np.float64)
        gecici[perm] = np.asarray(yp["pos"], np.float64)
        if ikiz is not None:                              # kapsanmayan kopya ikizinden dolar
            kaps = np.zeros(nv, bool); kaps[perm] = True
            for j in np.where(~kaps)[0]:
                gecici[j] = gecici[ikiz[j]]
        pos[v0:v1] = gecici
        if yp.get("nrm") is not None:
            if nrm is None:
                nrm = np.asarray(_mesh_normal(R, G), np.float64).copy()
            g2 = np.empty((nv, 3), np.float64)
            g2[perm] = np.asarray(yp["nrm"], np.float64)
            if ikiz is not None:
                for j in np.where(~kaps)[0]:
                    g2[j] = g2[ikiz[j]]
            nrm[v0:v1] = g2
        if yp.get("uv0") is not None and kp.get("uv0") is not None:
            fark = float(np.abs(np.asarray(yp["uv0"]) - np.asarray(kp["uv0"])[perm]).max())
            if fark > UV_ESIK:
                uv_oynadi = True
            if uv0 is None:
                uv0 = np.asarray(G["uv0"], np.float64).copy()
            g3 = np.empty((nv, 2), np.float64)
            g3[perm] = np.asarray(yp["uv0"], np.float64)
            if ikiz is not None:
                for j in np.where(~kaps)[0]:
                    g3[j] = g3[ikiz[j]]
            uv0[v0:v1] = g3
    if not uv_oynadi:
        uv0 = None                       # dokunulmamis UV tamponunu yeniden nicemleme
    if nrm is not None:
        u = np.linalg.norm(nrm, axis=1, keepdims=True)
        nrm = np.divide(nrm, u, out=np.zeros_like(nrm), where=u > 1e-12)
    if nv_all != len(pos):
        return None, None, None, "internal: vertex count mismatch"
    return pos, nrm, uv0, None


def _mesh_normal(R, G):
    """Oyundaki normaller (skinned oktahedral kod cozulur)."""
    if R.get("rigid"):
        return np.asarray(G["normal"], np.float64)
    return MY.okt_coz(np.asarray(G["nokt"]), (np.asarray(G["bayrak"]) & 1).astype(bool))


def _serbest_primler(R, G, esle, n_prim, fazla=None):
    """`mesh_yaz.yaz_serbest` icin primitif listesi. Degismeyen primitifler ORIJINAL
    alanlariyla (kemik, agirlik, renk, el biti) aynen tasinir; degisenler GLB'den gelir.
    fazla: kaynakta karsiligi olmayan GLB primitifleri [(yp, q)] -- materyal adi tutan gruba,
    yoksa SON gruba katilir (K-3). Doner (primler, degisen, katilan_notlari)."""
    primler = MZ.prim_geometri(R, G)
    uv1_var = (G.get("uv1") is not None)
    degisen = []
    notlar = []

    def _d(yp):
        d = {"pos": np.asarray(yp["pos"], np.float64),
             "tri": np.asarray(yp["tri"], np.int64)}
        if yp.get("uv0") is not None:
            d["uv0"] = np.asarray(yp["uv0"], np.float64)
        if uv1_var and yp.get("uv1") is not None:
            d["uv1"] = np.asarray(yp["uv1"], np.float64)
        if yp.get("nrm") is not None:
            d["normal"] = np.asarray(yp["nrm"], np.float64)
        return d

    for i in range(n_prim):
        if i not in esle:
            continue
        yp, q = esle[i]
        oynama = float(q.get("poz_fark_maks_m") or 0.0)
        if q.get("topoloji") == GO.IDENTICAL and oynama <= TASIMA_ESIK_M:
            continue                                     # orijinal dilim aynen kalir
        primler[i] = _d(yp)
        degisen.append(i)
        # Cok gruplu parcada grubun KENDI yuvasinda buyumesi de soylenir: K-3 notu yalniz
        # fazla primleri anlatiyordu, ayni materyalli yabanci geometri sessiz kaliyordu
        # (07_hepsi_join: Boots/HeadAcc/Pants Tunic'in prim 0'ina notsuz girdi).
        b_nv = int(yp.get("NV") or 0) - int(q.get("kaynak_NV") or 0)
        b_nt = int(yp.get("NT") or 0) - int(q.get("kaynak_NT") or 0)
        if n_prim > 1 and b_nv > 0:
            notlar.append("material group %d grew by %d vertices and %d triangles inside its own "
                          "slot (that geometry takes this group's material; on a skinned part its "
                          "bone weights come from the nearest original vertices)" % (i, b_nv, b_nt))
    for yp, q in (fazla or []):
        # hedef grup: ayni materyal adini tasiyan eslesmis grup, yoksa son grup
        j = None
        for i in range(n_prim):
            if i in esle and esle[i][1].get("material_ad") and \
                    esle[i][1].get("material_ad") == q.get("material_ad"):
                j = i
                break
        if j is None:
            j = n_prim - 1
        taban = primler[j] if j in degisen else (_d(esle[j][0]) if j in esle else
                                                  {k_: primler[j][k_] for k_ in ("pos", "tri", "uv0", "uv1", "normal")
                                                   if primler[j].get(k_) is not None})
        primler[j] = _prim_birlestir(taban, _d(yp))
        if j not in degisen:
            degisen.append(j)
        notlar.append("new geometry (%d vertices, %d triangles) was merged into material group %d - "
                      "a game mesh cannot gain material slots, so it takes that group's material"
                      % (int(yp["NV"]), int(yp["NT"]), j))
    return primler, degisen, notlar


# ------------------------------------------------------------------ JOIN KAPISI
def _join_teshisi(rap, y_sahne, k_sahne, eksik_adlar):
    """Blender Ctrl+J imzasi (bkz. baslik "JOIN KAPISI"). Export'ta olup dosyada OLMAYAN
    parcalarin vertexleri, BUYUYEN eslesmis bir parcanin YENI vertexleri (kaynak parcaya
    JOIN_TOL_M'den uzak olanlar) arasinda JOIN_PAY oraninda bulunuyorsa o parca yutulmus
    sayilir. scipy yoksa ya da konumlar oynamissa yedek imza: dNV == eksik NV toplami VE
    dNT == eksik NT toplami. Salt olcum; forge acilmaz.

    Doner {yutan_parca_ad: {"parcalar": [{ad, NV, NT, bulunan|None}], "dNV", "dNT",
                            "tam_sayim": bool}} -- bos sozluk = join imzasi yok."""
    k_ad = {p["ad"]: p for p in k_sahne.get("parcalar") or []}
    eksik = [k_ad[a] for a in (eksik_adlar or []) if a in k_ad and int(k_ad[a].get("NV") or 0) > 0]
    if not eksik:
        return {}
    top_nv = sum(int(p["NV"]) for p in eksik)
    top_nt = sum(int(p.get("NT") or 0) for p in eksik)
    try:
        from scipy.spatial import cKDTree
    except ImportError:                                         # yedek imza yeter
        cKDTree = None
    out = {}
    for pr, yp in zip(rap.get("parcalar") or [], y_sahne.get("parcalar") or []):
        kad = pr.get("kaynak_ad")
        if kad is None or kad not in k_ad:
            continue
        d_nv = int(pr.get("NV") or 0) - int(pr.get("kaynak_NV") or 0)
        d_nt = int(pr.get("NT") or 0) - int(pr.get("kaynak_NT") or 0)
        if d_nv <= 0:
            continue                       # buyumeyen parca hicbir seyi yutmus olamaz
        tam_sayim = (d_nv == top_nv and d_nt == top_nt)
        yutulan = []
        if cKDTree is not None:
            ypos = np.asarray(yp.get("pos"), np.float64).reshape(-1, 3)
            spos = np.asarray(k_ad[kad].get("pos"), np.float64).reshape(-1, 3)
            if len(ypos) and len(spos):
                d_src, _ = cKDTree(spos).query(ypos)
                yeni = ypos[d_src > JOIN_TOL_M]
                if len(yeni):
                    kd = cKDTree(yeni)
                    for p in eksik:
                        epos = np.asarray(p.get("pos"), np.float64).reshape(-1, 3)
                        if not len(epos):
                            continue
                        d, _ = kd.query(epos)
                        bulunan = int((d <= JOIN_TOL_M).sum())
                        if bulunan >= JOIN_PAY * len(epos):
                            yutulan.append({"ad": p["ad"], "NV": int(p["NV"]),
                                            "NT": int(p.get("NT") or 0), "bulunan": bulunan})
        if tam_sayim:
            # sayim tam tutuyorsa konumu oynamis (ya da scipy'siz) kalanlar da yutulmustur
            var = {q["ad"] for q in yutulan}
            for p in eksik:
                if p["ad"] not in var:
                    yutulan.append({"ad": p["ad"], "NV": int(p["NV"]),
                                    "NT": int(p.get("NT") or 0), "bulunan": None})
        if yutulan:
            out[pr["ad"]] = {"parcalar": yutulan, "dNV": d_nv, "dNT": d_nt, "tam_sayim": tam_sayim}
    return out


def _join_sebebi(parca, yutan):
    """JOIN KAPISI red sebebi (kullanici dili). Kanit cumlesi olculen degerden kurulur."""
    ps = yutan["parcalar"]
    n = len(ps)
    adlar = ", ".join(q["ad"] for q in ps[:6]) + (" ..." if n > 6 else "")
    top = sum(int(q["NV"]) for q in ps)
    nv_k, nv_y = int(parca.get("kaynak_NV") or 0), int(parca.get("NV") or 0)
    if all(q.get("bulunan") is not None for q in ps):
        kanit = "%d of their %d vertices sit inside it" % (sum(int(q["bulunan"]) for q in ps), top)
    else:
        kanit = "their vertex and triangle counts add up to its growth"
    if yutan.get("tam_sayim"):
        buyume = "it grew by exactly their vertex count (+%d, %d -> %d)" % (nv_y - nv_k, nv_k, nv_y)
    else:
        buyume = "it grew by %d vertices (%d -> %d)" % (nv_y - nv_k, nv_k, nv_y)
    return ("it looks like you joined %d part%s into this object in Blender (%s): %s, and %s. "
            "The game keeps every part as its own mesh and the Workshop cannot split them apart "
            "again, so nothing is written for this object - and the joined parts are neither "
            "hidden nor written, the game keeps them all as they are. Undo the join in Blender "
            "(or export the item again), leave the parts as separate objects, and export again."
            % (n, "" if n == 1 else "s", adlar, kanit, buyume))


# ------------------------------------------------------------------ PLAN (salt okunur)
@_zincirli
def plan(klasor, man, progress=None, glb_yol=None, doku_kaplari=None,
         eksikleri_gizle=False, hedef=None, hedef_silah=None, capraz_esleme=None):
    """Duzenlenmis GLB'yi kaynakla karsilastirir ve parca basina ROTA karari verir.
    Arsive TEK BAYT YAZMAZ (forge yalniz 'rb' acilir).

    Doner:
      {durum: "yok"|"hata"|"var", dosya, sebep, yazilabilir,
       ozet{...}, parcalar:[{ad, kaynak_ad, gid, icid, rota, sebep, NV, kaynak_NV,
                             NT, kaynak_NT, tasima_mm, degisen_prim, mevcut_yama,
                             grup_id, bant, bant_ek, bant_mesafe, lod_kapsam, paylasan,
                             _is{...}}],
       yazilacak, atlanan, red:[{ad, sebep}], tasinan:[(ad, mm)], degisen:[ad],
       bant_ozeti{grup, yazilacak_bant, atlanan_bant}    (yalniz SILAH ithalatinda),
       paylasim_uyarisi:[{ad, paylasan}]                 (paylasan >= 2 olanlar)}
    `_is` alani APPLY'in kullandigi bellek-ici is kaydidir (numpy tasir, JSON'a girmez).
    `grup_id`: birincil + LOD bantlari AYNI degeri tasir -- `uygula` tumu-ya-da-hic grubu.
    `bant_ozeti` / `paylasim_uyarisi` RAPOR METNI ICERMEZ, yalniz olcumdur; cumleyi
    doku_ithal._bant_satirlari / _paylasim_satirlari kurar."""
    kaynak = os.path.join(klasor, man.get("glb") or "")
    yeni_yol = glb_yol or duzenli_glb_bul(klasor, man)
    if yeni_yol is None and hedef and os.path.isfile(kaynak) \
            and (str(hedef) != str(man.get("anahtar") or "") or capraz_esleme):
        # CAPRAZ: duzenlenmis dosya yoksa export'un kendisi kaynaktir ("A'yi oldugu gibi B'ye koy")
        yeni_yol = kaynak
    if yeni_yol is None:
        return {"durum": "yok", "yazilabilir": False, "parcalar": [], "red": [],
                "sebep": "no edited .glb in this folder - only the textures will be imported. To "
                         "bring mesh edits back, save your Blender model as %s%s.glb next to the "
                         "original." % (man.get("anahtar"), DUZENLI_GLB_ONEK)}
    if not os.path.isfile(kaynak):
        return {"durum": "hata", "dosya": yeni_yol, "yazilabilir": False, "parcalar": [], "red": [],
                "sebep": "the original %s is gone, so there is nothing to compare the edited model "
                         "against. Export this item again." % (man.get("glb") or "GLB")}
    t0 = time.time()
    _log(progress, "- reading the edited model and comparing it with the export ...")
    try:
        y_sahne = GO.oku(yeni_yol)
        k_sahne = GO.oku(kaynak)
        rap = GO.eslestir(y_sahne, k_sahne)
        GO.manifest_bagla(rap, os.path.join(klasor, "manifest.json"))
    except Exception as e:                                      # noqa: BLE001
        return {"durum": "hata", "dosya": yeni_yol, "yazilabilir": False, "parcalar": [], "red": [],
                "sebep": "the edited model could not be read (%s)." % e}

    out = {"durum": "var", "dosya": yeni_yol, "yazilabilir": True, "sure": None,
           "ozet": rap["ozet"], "hizalama": rap.get("hizalama"), "parcalar": [], "red": [],
           "yazilacak": 0, "atlanan": 0, "tasinan": [], "degisen": [], "surum": SURUM,
           "notlar": [], "eksik": [], "gizlenecek": 0, "yutulan": [], "govde": [],
           # UZMAN MODU: acilan her politika kapisinin uyarisi burada toplanir
           # ([{ad, uyari}]). Bos liste = hicbir kapi acilmadi. `_uzman_topla` doldurur.
           "uzman": bool(UZ.acik()), "uzman_uyarilari": []}

    # --- ISKELET KAPISI. Kullanicilar Blender'da armature'u siliyor ("yuvarlak garip
    # seyler"); o zaman GLB'de skin kalmaz ve mesh'ler kaynak uzayindan KATI bir
    # donusumle kayar (Diplomat: X ekseninde 4,78 derece, olculdu). glb_oku bunu
    # mesh'lerden geri kazanir ("mesh (kemik yok)"). Kazanamazsa YAZILMAZ: kaymis
    # modeli yazmak karakteri oyunda kiymik bulutuna cevirir (2026-09-05 oyun ici
    # goruldu, geri alindi).
    hiz = rap.get("hizalama") or {}
    k_skinli = any(p.get("skinli") for p in k_sahne["parcalar"])
    y_skinli = any(p.get("skinli") for p in y_sahne["parcalar"])
    yontem = str(hiz.get("yontem") or "")
    if k_skinli and not y_skinli:
        if yontem.startswith("yok"):
            return {"durum": "hata", "dosya": yeni_yol, "yazilabilir": False, "parcalar": [],
                    "red": [], "eksik": [], "notlar": [],
                    "sebep": ("your file has no skeleton (the armature was deleted or not exported) "
                              "and the Workshop could not line the model up with the export (%s). "
                              "Nothing is written: a mis-aligned model tears the character apart in "
                              "the game. Export the item again, redo the edit on the fresh file, and "
                              "leave the armature in place (or at least do not move the meshes)."
                              % yontem)}
        n_y, n_k = len(y_sahne["parcalar"]), len(k_sahne["parcalar"])
        if n_y * 2 < n_k:
            # Senaryo 13 (olculdu): tek nesne + iskelet yok = Blender'in "Selected Objects"
            # kutusu. Armature silinmis demek yanlis olur; ne yapacagini soyle.
            out["notlar"].append(
                "your file holds only %d of the %d parts and no skeleton. If you ticked "
                "\"Selected Objects\" in Blender's export dialog, untick it and export again so "
                "every part comes through; the parts that are here were lined up automatically "
                "(residual %.2f mm)." % (n_y, n_k, 1000.0 * float(hiz.get("artik_rms_m") or 0.0)))
        else:
            out["notlar"].append(
                "your file has no skeleton (the armature was deleted in Blender). That is fine: the "
                "model was rotated %.2f deg and moved %.1f mm relative to the export, and it was lined "
                "up again automatically (residual %.2f mm on %d vertices)."
                % (float(hiz.get("aci_derece") or 0.0),
                   1000.0 * float(np.linalg.norm(np.asarray(hiz.get("oteleme_m") or [0, 0, 0]))),
                   1000.0 * float(hiz.get("artik_rms_m") or 0.0), int(hiz.get("nokta") or 0)))
    else:
        # --- SAHNE YERLESIMI NOTU (rijit dosya ya da kemigi duran skinli dosya; baslik
        # "SAHNE YERLESIMI"). Blender'in olagan Y-up/iskelet-koku donusumu (90 derece +
        # 0,964 m) her kemikli dosyada gorulur ve kullanicinin eylemi degildir; glb_oku
        # .sahne_yerlesimi bu tabani dusup yalniz KULLANICININ tasima/dondurmesini verir
        # (senaryo 1 kimlik: 1e-5 derece / 0,001 mm -> not yok; 16: 50,0 mm; 17: 90,0 derece).
        n_ = _yerlesim_notu(hiz, k_skinli)
        if n_:
            out["notlar"].append(n_)
    # --- AD TAKASI NOTU (bkz. baslik "AD TAKASI"): ad = talimat kalir, yazma karari
    # degismez; glb_oku'nun olctugu iki ucuz sinyal (nesne/mesh adi celiskisi, NV/NT capraz
    # imzasi) kullaniciya SOYLENIR. 2026-09-05'e kadar 10c'de iki WRITE, sifir uyari vardi.
    out["notlar"].extend(_ad_takas_notlari(rap))

    # --- EKSIK PARCALAR: export'ta var, kullanicinin dosyasinda yok = Blender'da
    # silinmis. Eski davranis sessizce yok saymakti; kullanici "paltoyu sildim, oyunda
    # duruyor" diye sasiriyordu. Simdi listelenir; `eksikleri_gizle` ile oyundan
    # kaldirilir (gorunmez yazilir).
    # --- CAPRAZ: secili oge (hedef) export'un kendi ogesi degilse A'nin sekli B'ye yazilir.
    # AYNI OGE ICINDE parca tasima da capraz sayilir: "cift kilicin iki eli de ayni model
    # olsun" (Discord istegi 2026-09-05). Hedef=kaynak ama ELLE esleme verilmisse capraz acilir;
    # esleme yoksa eski davranis (kendi kendine ithalat) korunur.
    capraz = bool(hedef) and (str(hedef) != str(man.get("anahtar") or "") or bool(capraz_esleme))
    esleme = {}
    # SILAH BAYRAGI capraz blogunun DISINDA hesaplanir (2026-09-07): ayni-oge ithalatinda da
    # LOD bant tablosu kurulabilsin diye. Capraz yolda deger DEGISMEDI (hedef_silah hedefin
    # bicimini soyler); capraz olmayan yolda hedef == kaynak oldugu icin kaynagin kendi
    # manifest bayragi kullanilir -- cagiran hedef_silah'i hic vermese de dogru kalir.
    silah = (bool(man.get("silah")) if (hedef_silah is None or not capraz)
             else bool(hedef_silah))
    # Bant tablosunun okundugu oge: capraz'da hedef, ayni-ogede kaynagin kendisi.
    silah_anahtari = str(hedef or man.get("anahtar") or "")
    if capraz:
        try:
            h_liste = _hedef_parcalari(hedef, silah)
        except Exception as e:                                  # noqa: BLE001
            return {"durum": "hata", "dosya": yeni_yol, "yazilabilir": False, "parcalar": [],
                    "red": [], "eksik": [], "notlar": [],
                    "sebep": "the selected target '%s' is not in the 3D index (%s)." % (hedef, e)}
        # aile anahtari `taban` + `ad`dan: belirtec (kilif kopyasi) adin LOD'lu halinden okunur,
        # cunku K1 '?' bozulmasi tabanda belirtecin kendisine gelebilir (bkz. `_belirtec`)
        k_liste = [{"ad": p.get("ad"), "taban": p.get("taban"), "boyut": p.get("ic_bayt") or 0,
                    "aile": _aile_anahtari(p.get("taban") or p.get("ad"), p.get("ad"))}
                   for p in (man.get("parcalar") or []) if p.get("durum") == "cikan"]
        esleme, yersiz, hedef_yalniz = _capraz_esle(
            k_liste, h_liste, uyarilar=out.setdefault("uzman_uyarilari", []))
        # ELLE ESLEME: kullanici "su parcayi su yuvaya" dediyse otomatik kurali EZER; yalniz
        # eslenenler yazilir (tek parca tasimak isterken butun kiyafetin degismesi surpriz olurdu).
        yasak = _elle_esleme_uygula(esleme, capraz_esleme, k_liste, h_liste, out)
        if capraz_esleme:
            _istenen = {_ad_coz(x, [k["ad"] for k in k_liste]) for x in capraz_esleme}
            for a in list(esleme):
                if a not in _istenen:
                    esleme.pop(a)
                    yasak.add(a)
            _kullanilan = {h["ad"] for h in esleme.values()}
            # KAYNAK PARCA KORUMASI: ayni oge icinde tasima yapiliyorsa (cift kilicin sag elini
            # sol ele kopyalamak gibi) KAYNAK parca "hedefte karsiligi yok" sayilmamali -- yoksa
            # "eksik parcalari gizle" kutusu kullanicinin sag kilicini yok eder (olculdu).
            _kullanilan |= set(_istenen)
            hedef_yalniz = [h for h in h_liste if h["ad"] not in _kullanilan]
            yersiz = [k["ad"] for k in k_liste if k["ad"] not in esleme and k["ad"] not in yasak]
        # GOVDE KAPISI (bkz. baslik): karakterin kendi derisi (HumanBody*, NPC yuzu) hedef-yalniz
        # kalsa da gizleme adayi DEGILDIR -- kaynak onu hic iceremezdi, kullanici silmedi; ayni
        # giris 24-80 ogede ortak. `eksik`e girmez (kutu saymaz), `govde`ye girer, rapor BODY der.
        govde = [h for h in hedef_yalniz if _govde_mi(h)]
        out["capraz"] = {"kaynak": man.get("anahtar"), "hedef": hedef, "silah": silah,
                         "elle": bool(capraz_esleme),
                         "eslesen": {a: h["ad"] for a, h in esleme.items()},
                         "esleme_sebebi": {a: h.get("esleme_sebebi") for a, h in esleme.items()},
                         "yersiz": yersiz, "hedef_yalniz": [h["ad"] for h in hedef_yalniz],
                         "govde": [h["ad"] for h in govde]}
        out["govde"] = [{"ad": h["ad"], "gid": h["gid"], "icid": h["icid"], "aile": h.get("aile"),
                         "paylasan": _paylasan_oge_sayisi(h["gid"], haric=hedef)} for h in govde]
        # hedefte karsiligi olmayan B parcalari "eksik" listesine girer: kullanici isterse gizler.
        # `bantlar` (silah): gizleme karari birincille birlikte DIGER ana bantlari da kapsar
        # (bkz. baslik "LOD BANTLARI"); liste parca basina TEK kayit kalir (arayuz sayaci).
        for h in hedef_yalniz:
            if _govde_mi(h):
                continue                                        # GOVDE KAPISI: aday degil
            out["eksik"].append({"ad": h["ad"], "gid": h["gid"], "icid": h["icid"],
                                 "rigid": bool(silah), "sha256": None,
                                 "gizle": bool(eksikleri_gizle), "rota": None, "sebep": None,
                                 "hedef_yalniz": True, "bantlar": h.get("bantlar")})
    # --- AYNI-OGE SILAH: LOD BANT TABLOSU (bkz. baslik "LOD BANTLARI"). Capraz yolda tablo
    # `_hedef_parcalari` icinde kuruluyordu; ayni-oge (IMPORT 3D) yolunda HIC kurulmuyordu ve
    # yalniz lodlar[0] yaziliyordu. Tablo indeksten okunur (forge acilmaz); anahtar kaynak
    # manifestindeki (gid, icid) ciftidir -- indeksin lodlar[0]'i export'un yazdigi mesh'tir.
    ayni_bant_tablo = {}
    if not capraz:
        try:
            # KIYAFET BANTLARI (2026-09-08): kiyafet/karakter ithalatinda da tablo kurulur
            # (bkz. baslik "KIYAFET BANTLARI"); 2026-09-08'e kadar yalniz silahta kuruluyordu
            # ve kiyafet parcasi 5 LOD girisinden yalniz 1'ine yaziliyordu (olculdu).
            ayni_bant_tablo = (_silah_bant_tablosu(silah_anahtari) if silah
                               else _kiyafet_bant_tablosu(silah_anahtari))
        except Exception:                                       # noqa: BLE001
            # Indeks yoksa/bozuksa SESSIZ VARSAYIM YOK: tablo bos kalir, her parca
            # `bilgi_yok` kapsamina duser ve rapor "no LOD layout" der.
            ayni_bant_tablo = {}
    man_kayit = {p.get("ad"): p for p in (man.get("parcalar") or [])}
    for ad in ([] if capraz else list((rap.get("ozet") or {}).get("eslesmemis_kaynak") or [])):
        m = man_kayit.get(ad) or {}
        out["eksik"].append({"ad": ad, "gid": m.get("gid"), "icid": m.get("icid"),
                             "rigid": bool(m.get("rigid")), "sha256": m.get("sha256"),
                             "gizle": bool(eksikleri_gizle and m.get("gid") and m.get("icid")),
                             "rota": None, "sebep": None,
                             # GIZLE de bantli olmali: birincili gizleyip bant-1'i birakmak
                             # silinen parcayi 1 m'nin otesinde geri getirirdi (capraz yolda
                             # zaten boyle; ayni-oge yolunda 2026-09-07'ye kadar eksikti).
                             "bantlar": _bant_kaydi(ayni_bant_tablo, m)})
    # --- JOIN KAPISI (bkz. baslik): eksik parcalar buyuyen bir parcanin ICINDEYSE silinmis
    # degil, join edilmistir. Yutan parca asagida ROTA_RED olur; yutulanlar eksik listesinden
    # CIKAR (MISSING satirina girmez, HIDE ile gizlenmez -- gizlemek cizmeyi oyundan silerdi).
    yutan = {}
    if not capraz and out["eksik"]:
        yutan = _join_teshisi(rap, y_sahne, k_sahne, [e["ad"] for e in out["eksik"]])
        if yutan:
            yutulan_adlar = {q["ad"] for v in yutan.values() for q in v["parcalar"]}
            out["eksik"] = [e for e in out["eksik"] if e["ad"] not in yutulan_adlar]
            out["yutulan"] = [{"ad": q["ad"], "icine": ad, "NV": q["NV"], "bulunan": q["bulunan"]}
                              for ad, v in yutan.items() for q in v["parcalar"]]

    try:
        yamalar = {y["gid"].upper(): y["id"] for y in (KM.durum(C.FORGE).get("yamalar") or [])}
    except Exception:                                           # noqa: BLE001
        yamalar = {}

    lf = C._forge()
    try:
        for parca, y_parca in zip(rap["parcalar"], y_sahne["parcalar"]):
            hk = esleme.get(parca.get("kaynak_ad")) if capraz else None
            k = _parca_karari(lf, parca, y_parca, k_sahne, yamalar,
                              doku_kaplari or set(),
                              hedef_kaydi=hk, capraz=capraz, yutan=yutan.get(parca.get("ad")),
                              elle=bool(capraz_esleme))
            # K-4 sinyalleri parca kaydinda da tasinir (arayuz/test okuyabilsin; metin NOTE'ta)
            k["ad_celiskisi"] = parca.get("ad_celiskisi")
            k["takas_imzasi"] = parca.get("takas_imzasi")
            # LOD BANTLARI: birincil karardan sonra AYNI grubun diger ANA bant mesh'leri;
            # birincil kayit listede ONCE kalir (arayuz/testler parcalar[0]'i okur).
            # capraz: yuva hedef ogenin grubudur (hk). ayni-oge: yuva kaynagin KENDI grubudur
            # ve kayit manifestten kurulur (2026-09-07; bkz. `_ayni_oge_bant_kaydi`).
            # KIYAFET BANTLARI (2026-09-08): kosul artik `silah` degil -- kiyafet/karakter
            # gruplari da 1-5 LOD girisi tasir (708/760 grup) ve hepsi yazilir.
            if capraz and hk:
                ek = _capraz_bant_kararlari(lf, parca, y_parca, k_sahne, yamalar,
                                            doku_kaplari or set(), hk, k)
            elif not capraz:
                ek = _capraz_bant_kararlari(
                    lf, parca, y_parca, k_sahne, yamalar, doku_kaplari or set(),
                    _ayni_oge_bant_kaydi(ayni_bant_tablo, parca.get("manifest")), k,
                    ayni_oge=True)
            else:
                ek = []
            grup_id = "g%d" % len(out["parcalar"])
            for kk in [k] + ek:
                # TUMU-YA-DA-HIC (uygula): birincil + bantlari TEK GRUPTUR; biri yazilamazsa
                # digerlerinin yazilanlari geri alinir (bkz. `uygula`).
                kk["grup_id"] = grup_id
                out["parcalar"].append(kk)
                if kk["rota"] == ROTA_RED:
                    out["red"].append({"ad": kk["ad"], "sebep": kk["sebep"]})
                elif kk["rota"] == ROTA_ATLA:
                    out["atlanan"] += 1
                else:
                    out["yazilacak"] += 1
                    if kk["rota"] == ROTA_SERBEST:
                        out["degisen"].append(kk["ad"])
                    else:
                        out["tasinan"].append((kk["ad"], kk["tasima_mm"]))
        # LODSelector isi YALNIZ materyal yonlendirmesi kurulan parcalar icin gerekir. Capraz
        # yolda bu hemen her zaman olur; ayni-oge yolunda materyal zaten ogenin kendisininkidir
        # (159 cok-bantli gruptan 157'sinde ana bantlarin materyali BIREBIR ayni -- olculdu
        # 2026-09-07), yani `_capraz_materyal` "already uses the same material" der ve is
        # kurulmaz. Kalan 2 grupta (prim SIRASI farkli) is gerekir; o yuzden kosul
        # `capraz` degil, "yonlendirme kuruldu mu" olmali.
        if capraz or any(p.get("_materyal_prim2mat") for p in out["parcalar"]):
            _lodsel_isleri(lf, out, hedef or man.get("anahtar"), silah, yamalar)
        for e in out["eksik"]:
            if not e["gizle"]:
                continue
            # LOD BANTLARI: gizlenen silah parcasi birincil + diger ana bantlariyla gizlenir
            gizle_grup = "h%d" % len(out["parcalar"])
            for j, ee in enumerate(_eksik_bant_girdileri(e)):
                k = _gizle_karari(lf, ee, yamalar, doku_kaplari or set())
                k["grup_id"] = gizle_grup
                if j == 0:
                    e["rota"], e["sebep"] = k["rota"], k["sebep"]
                else:
                    k["bant_ek"], k["bant"], k["bant_mesafe"] = True, ee["bant"], ee["bant_mesafe"]
                out["parcalar"].append(k)
                if k["rota"] == ROTA_RED:
                    out["red"].append({"ad": k["ad"], "sebep": k["sebep"]})
                elif k["rota"] == ROTA_GIZLE:
                    out["yazilacak"] += 1
                    out["gizlenecek"] += 1
        # --- PAYLASIM (yazma yolu). Gizleme yolunda bu sayi 2026-09-05'ten beri olculuyor
        # ("SHARED: N other item(s) ... lose it too") ama YAZMA yolunda parca kaydinin
        # `paylasan` alani None kaliyordu: kullanici 24 kiyafette ortak olan HumanBody'yi
        # yeniden yazarken bunu HICBIR YERDE gormuyordu (olculdu: U_Edward_Asian plani
        # 14 WRITE / 0 SHARED). Sayi indeksten okunur, forge acilmaz; olculemezse None kalir.
        _pay_onbellek = {}
        for k in out["parcalar"]:
            if k.get("rota") not in (ROTA_AYNI, ROTA_SERBEST) or not k.get("gid"):
                continue
            g = str(k["gid"]).upper()
            if g not in _pay_onbellek:
                _pay_onbellek[g] = _paylasan_oge_sayisi(
                    k["gid"], haric=(hedef or man.get("anahtar")), silah_dahil=True)
            k["paylasan"] = _pay_onbellek[g]
    finally:
        C.release_forge(onbellek=False)
    out["notlar"].extend(_kayip_geometri_notlari(out))
    # UZMAN MODU: parca kayitlarindaki uyarilari plana ve `notlar`a tasi (bkz. `_uzman_topla`).
    _uzman_topla(out)
    # --- SOZLESME ALANLARI (rapor metnini doku_ithal yazar; burasi yalniz OLCUMU verir)
    if silah:
        out["bant_ozeti"] = _bant_ozeti(out)
    elif any(isinstance(k.get("lod_kapsam"), dict) for k in out["parcalar"]):
        # KIYAFET BANTLARI (2026-09-08): kiyafette de olcum verilir; `oge: "item"` alani
        # yalniz kiyafette konur (silah sozlesmesi -- uc alanli sozluk -- DEGISMEDI), rapor
        # cumlesi "This weapon" yerine "This item" der (doku_ithal._bant_satirlari).
        out["bant_ozeti"] = dict(_bant_ozeti(out), oge="item")
    out["paylasim_uyarisi"] = [{"ad": k["ad"], "paylasan": int(k["paylasan"])}
                               for k in out["parcalar"]
                               if isinstance(k.get("paylasan"), int) and k["paylasan"] >= 2
                               and k.get("rota") in (ROTA_AYNI, ROTA_SERBEST)]
    out["sure"] = round(time.time() - t0, 2)
    out["yazilabilir"] = bool(out["yazilacak"])
    if not out["yazilacak"] and not out["red"]:
        out["sebep"] = "the edited model comes out of the game unchanged - no mesh change to import."
    return out


def _sha_uyusmazlik_sebebi(mevcut_yama, gid_hex):
    """Ic dosyanin sha'si export'takiyle tutmuyor -> SEBEP metni.

    Iki ayri dunya: (1) oyun guncellendi, (2) girise ZATEN bizim bir yamamiz kurulu.
    (2) cok daha sik, cunku paylasilan girisler (Boots 7 kiyafette ortak) baska bir
    kiyafete kurulan yamayla degisiyor. Tek metin yazmak kullaniciya "oyun guncellendi"
    dedirtiyordu -- yanlis teshis, Discord 2026-09-05."""
    if not mevcut_yama:
        return ("the game archive changed since this export (this mesh is not the one that was "
                "exported). Export the item again, redo your edit on the new file, and import "
                "that.")
    pay = _paylasan_oge_sayisi(gid_hex, haric=None)
    ortak = ("" if not pay or pay < 2 else
             " This part is shared by %d items, so the patch may have been installed from a "
             "different outfit." % pay)
    return ("this part already carries a Workshop patch (%s), so it no longer matches your "
            "export.%s Revert that patch (Revert this / Revert all), then export this item "
            "again and redo your edit on the fresh file." % (mevcut_yama, ortak))


KAYIP_ORAN = 0.01        # %1'den az kayip = temizlik, uyarma
KAYIP_UCGEN = 100        # ...ve en az 100 ucgen gitmis olsun (kucuk rotuslar susar)


def _kayip_geometri_notlari(out):
    """YAZILACAK parcalarda ucgen KAYBI varsa kullaniciyi uyar.

    Neden: kullanicilar bir esyayi (kolye, kemer, sapka) kaldirmak icin parcanin ICINDE
    duzenleme kipinde yuz siliyor (Discord'da dolasan tarif: tab -> L -> Delete). Bu, o
    parcanin govdesinde DELIK acar; esya cogu zaman AYRI BIR OBJE oldugu icin de yerinde
    kalir. Olculdu (Edward Assassin, 2026-09-05): Torso 33.669 -> 30.901 ucgen, tek not yok.
    Arac bunu reddetmez -- yuz silmek mesru bir islem -- ama SUSMAZ."""
    kayip = []
    for k in out.get("parcalar") or []:
        if k.get("rota") not in (ROTA_SERBEST, ROTA_AYNI):
            continue
        if k.get("bant_ek"):
            # LOD BANTLARI: ek bant kaydinin `kaynak_NT`si o bandin KENDI (daha seyrek) mesh'idir,
            # kullanicinin duzenledigi parca degil; birincil satir kaybi zaten soyler. Kiyafette
            # 5 bant bu notu bes kez uretiyordu (olculdu 2026-09-08: "3 part(s) come back with
            # faces deleted ... [LOD band 1] ... [LOD band 2]").
            continue
        nt, knt = k.get("NT"), k.get("kaynak_NT")
        if not nt or not knt or nt >= knt:
            continue
        d = knt - nt
        if d < KAYIP_UCGEN or d < KAYIP_ORAN * knt:
            continue
        kayip.append((d / float(knt), k.get("ad") or "?", d, knt))
    if not kayip:
        return []
    kayip.sort(reverse=True)
    liste = ", ".join("%s (%s of %s faces, %.0f%%)"
                      % (ad, "{:,}".format(d), "{:,}".format(knt), 100.0 * o)
                      for o, ad, d, knt in kayip[:6])
    if len(kayip) > 6:
        liste += " and %d more" % (len(kayip) - 6)
    return ["%d part(s) come back with faces deleted: %s. That is written as a hole in those "
            "parts. If you meant to remove a separate item (a necklace, a belt, a hat), delete "
            "the whole OBJECT in Blender's Outliner instead and tick \"Hide parts missing from "
            "my file\" - deleting faces inside a part cuts into the body itself."
            % (len(kayip), liste)]


def _gizle_karari(lf, e, yamalar, doku_kaplari=()):
    """Kullanicinin dosyasinda OLMAYAN bir export parcasini oyunda gorunmez yapma karari.
    Forge yalniz okunur; baytlar bellekte uretilir (gizle.gizle_bayt), kurulumu `uygula`."""
    ad = e["ad"]
    k = {"ad": ad, "kaynak_ad": ad, "rota": ROTA_RED, "sebep": None,
         "NV": 0, "kaynak_NV": None, "NT": 0, "kaynak_NT": None,
         "topoloji": "MISSING", "topoloji_sebep": "not in the edited file",
         "tasima_mm": 0.0, "gid": e.get("gid"), "icid": e.get("icid"), "rigid": e.get("rigid"),
         "degisen_prim": [], "mevcut_yama": None, "_is": None,
         # capraz hedef-yalniz parca: HIDE satiri "not in your file" DEMEZ (kaynak onu iceremezdi)
         "hedef_yalniz": bool(e.get("hedef_yalniz"))}
    try:
        try:
            from . import gizle as GZ
        except ImportError:
            import gizle as GZ
    except Exception as ex:                                     # noqa: BLE001
        k["sebep"] = "hiding parts is not available in this build (%s)." % ex
        return k
    if not e.get("gid") or not e.get("icid"):
        k["sebep"] = ("the export manifest does not record where this part lives in the game "
                      "archive. Run EXPORT 3D once more.")
        return k
    gid, icid = int(e["gid"], 16), int(e["icid"], 16)
    k["mevcut_yama"] = yamalar.get(str(e["gid"]).upper())
    if gid in doku_kaplari:
        k["sebep"] = ("this part's model and a repainted texture share one archive entry; import "
                      "the textures first, then hide the part in a second import.")
        return k
    cakisma = KM._catisma(C.FORGE, gid)
    if cakisma:
        k["sebep"] = ("the texture tool already holds this archive entry; revert the painted "
                      "textures first. (%s)" % cakisma)
        return k
    try:
        data = FG.ic_dosya(lf, gid, icid)
    except Exception as ex:                                     # noqa: BLE001
        k["sebep"] = "the game archive no longer holds this mesh (%s). Export again." % ex
        return k
    # ZATEN GIZLI MI? (K1) Bu soru sha kapisindan ONCE sorulur: gizleme IndexBuffer'i degistirdigi
    # icin ikinci ice aktarmada sha ZORUNLU OLARAK tutmaz ve kullanici "arsiv degisti, bastan yap"
    # gibi YANLIS bir sebep gorurdu (2026-09-05 GUI dogrulamasinda olculdu). Baska bir mesh gelmisse
    # gizle(data) != data olacagi icin asagidaki sha kapisi aynen isler -- kapi gevsemiyor.
    try:
        yeni_ic, wr = GZ.gizle(data)          # (bytes, rapor); uzunluk sabit, yalniz IndexBuffer
    except Exception as ex:                                     # noqa: BLE001
        yeni_ic, wr = None, None
        _gizle_hatasi = str(ex)
    else:
        _gizle_hatasi = None
    if yeni_ic is not None and bytes(yeni_ic) == bytes(data):
        k["rota"] = ROTA_ATLA
        k["sebep"] = ("already hidden by an earlier import - nothing to do%s (Revert brings it back)"
                      % ((" (%s)" % k["mevcut_yama"]) if k.get("mevcut_yama") else ""))
        return k
    if e.get("sha256") and _sha(data) != e["sha256"]:
        k["sebep"] = ("the game archive changed since this export. Export the item again, redo "
                      "the edit, and import that.")
        return k
    if yeni_ic is None:
        k["sebep"] = "this part cannot be hidden (%s)." % _gizle_hatasi
        return k
    # ("zaten gizli" karari yukari, sha kapisinin ONUNE alindi -- bkz. K1)
    # PAYLASIM: ayni arsiv girisini baska ogeler de kullaniyorsa gizleme ONLARI DA etkiler
    # (olculdu 2026-09-05: Diplomat'ta gizlenen Boots girisi Edward_Assassin'in da botu).
    try:
        k["paylasan"] = _paylasan_oge_sayisi(e.get("gid"), haric=None)
    except Exception:                                           # noqa: BLE001
        k["paylasan"] = None
    k["rota"] = ROTA_GIZLE
    k["kaynak_NV"] = (wr or {}).get("NV")
    k["kaynak_NT"] = (wr or {}).get("NT")
    k["eski_bayt"] = len(data)
    k["yeni_bayt"] = len(yeni_ic)
    k["_is"] = {"mod": ROTA_GIZLE, "gid": gid, "icid": icid, "yeni_ic": yeni_ic,
                "eski_bayt": len(data), "rapor": wr}
    return k


def _parca_karari(lf, parca, y_parca, k_sahne, yamalar, doku_kaplari=(),
                  hedef_kaydi=None, capraz=False, yutan=None, elle=False):
    """Tek parca icin rota karari. Forge yalniz okunur.
    capraz=True: gid/icid HEDEF ogeden (hedef_kaydi) gelir, sha kapisi yoktur (hedefin export'u
    yok), rota daima serbest (baska mesh'e yaziliyor), primitif sayisi farki birlestirilir.
    yutan: plan()'in JOIN KAPISI bulgusu (bu nesne export'un baska parcalarini yutmus) ->
    bayt uretilmeden ROTA_RED."""
    ad = parca.get("ad")
    k = {"ad": ad, "kaynak_ad": parca.get("kaynak_ad"), "rota": ROTA_RED, "sebep": None,
         "NV": parca.get("NV"), "kaynak_NV": parca.get("kaynak_NV"),
         "NT": parca.get("NT"), "kaynak_NT": parca.get("kaynak_NT"),
         "topoloji": parca.get("topoloji"), "topoloji_sebep": parca.get("topoloji_sebep"),
         # OLCULMEMIS oynama None kalir, 0.0 DEGIL: esleme kurulamayan parcada glb_oku
         # poz_fark_maks_m=None doner; eski `or 0.0` bunu "0 mm" diye onay ekranina tasiyordu.
         "tasima_mm": (None if parca.get("poz_fark_maks_m") is None
                       else round(float(parca["poz_fark_maks_m"]) * 1000.0, 3)),
         "donusum": parca.get("donusum_tahmini"), "kaba": parca.get("kaba_donusum"),
         "gid": None, "icid": None, "rigid": None, "degisen_prim": [], "mevcut_yama": None,
         "_is": None}
    m = parca.get("manifest")
    if parca.get("kaynak_ad") is None:
        k["sebep"] = ("this object is not in the export - the Workshop only writes back parts that "
                      "came out of EXPORT 3D. New objects you modelled yourself cannot be added to "
                      "the game this way.")
        return k
    if yutan:
        # JOIN KAPISI (bkz. baslik): bu nesne export'un baska parcalarini yutmus. Bayt
        # uretilmeden reddedilir; yutulanlar plan()'da eksik listesinden cikarildi.
        # C4 POLITIKA: uzman modunda yazilir -- yutulan geometri bu parcanin materyali ve
        # kemik agirliklariyla cizilir, yutulan parcalar oyunda YERINDE KALIR (iki kopya).
        k["yutulan"] = [q["ad"] for q in yutan["parcalar"]]
        if not UZ.kapi("join"):
            k["sebep"] = _join_sebebi(parca, yutan)
            return k
        _ps = yutan["parcalar"]
        _uzman_uyar(k, "join", n=len(_ps),
                    adlar=", ".join(q["ad"] for q in _ps[:6]) + (" ..." if len(_ps) > 6 else ""))
    if capraz:
        if hedef_kaydi is None:
            if elle:
                k["rota"] = ROTA_ATLA
                k["sebep"] = "not part of your mapping"
                return k
            k["sebep"] = ("the target item has no part of this kind (%s), so there is nowhere "
                          "to put it. It is not written."
                          % _aile_gorunen(_aile_anahtari(parca.get("kaynak_ad"))))
            return k
        k["capraz"] = True
        k["hedef_ad"] = hedef_kaydi["ad"]
        k["esleme_sebebi"] = hedef_kaydi.get("esleme_sebebi")   # onay satirinin altina duser
        m = dict(m or {}, gid=hedef_kaydi["gid"], icid=hedef_kaydi["icid"], sha256=None)
    if not m or not m.get("gid") or not m.get("icid"):
        k["sebep"] = ("the export manifest does not record where this part lives in the game "
                      "archive, so there is nowhere to write it. Run EXPORT 3D once more.")
        return k
    k["gid"], k["icid"] = m["gid"], m["icid"]
    # CAPRAZ: `m` kaynagin manifesti, `rigid` KAYNAGIN bicimidir; hedefin bicimini ancak hedef
    # baytlari (asagida G) soyler. O ana kadar None -- kaynagin bayragi hedefe tasinmaz
    # (bkz. baslik "CAPRAZ HEDEFIN BICIMI").
    k["rigid"] = None if capraz else bool(m.get("rigid"))
    k["mevcut_yama"] = yamalar.get(str(m["gid"]).upper())
    gid, icid = int(m["gid"], 16), int(m["icid"], 16)
    # --- CAKISMA: ayni arsiv girisine hem doku hem mesh yazilamaz.
    # Bir EntityGroup girisi hem mesh'i hem materyali tasiyabilir. Iki yazicinin
    # geri-alma kayitlari birbirinin blogunu "vanilla" sanir; kur_mesh bunu zaten
    # reddeder (`_catisma`) ama o red YAZMA aninda gelir -- kullanici dokulari
    # yazilmis, modeli yazilmamis bir yarim ise duser. Bu yuzden karar
    # DOGRULAMADA verilir ve sebebi ne yapacagini SOYLER.
    if gid in doku_kaplari:
        k["sebep"] = ("this part's model and one of the textures you repainted live in the SAME "
                      "archive entry, and the two writers cannot share it. The textures are "
                      "imported now; import the model on its own afterwards (Revert all first if "
                      "you want both), or repaint a texture that belongs to another part.")
        return k
    cakisma = KM._catisma(C.FORGE, gid)
    if cakisma:
        k["sebep"] = ("this part cannot be written because the texture tool already holds the same "
                      "archive entry. Revert the painted textures first, then import the model. "
                      "(%s)" % cakisma)
        return k
    try:
        data = FG.ic_dosya(lf, gid, icid)
    except Exception as e:                                      # noqa: BLE001
        k["sebep"] = ("the game archive no longer holds this mesh (%s). Export this item again so "
                      "the addresses match." % e)
        return k
    if m.get("sha256") and _sha(data) != m["sha256"]:
        # K-B: sha tutmuyorsa sebep IKI TURLU olabilir. (1) oyun guncellendi, (2) bu girise
        # ZATEN bizim bir yamamiz kurulu. (2) cok daha sik: paylasilan girisler (Boots 7
        # kiyafette ortak) baska bir kiyafete kurulan yamayla degisiyor. Ayni metni yazmak
        # kullaniciya "oyunun guncellendi" dedirtiyordu -- yanlis teshis.
        # C13 POLITIKA — YALNIZ IKINCI DAL. `mevcut_yama` VARSA baytlarin ne oldugunu
        # biliyoruz (bizim yamamiz) ve uzerine yazmak politika sorusudur; geri alma zinciri
        # (once bizimki, sonra vanilla) calismaya devam eder. `mevcut_yama` YOKSA baytlarin
        # ne oldugu BILINMIYOR (oyun guncellenmis olabilir) -> uzman modunda da REDDEDILIR.
        _mv = k.get("mevcut_yama")
        if not _mv or not UZ.kapi("sha_yama"):
            k["sebep"] = _sha_uyusmazlik_sebebi(_mv, m.get("gid"))
            return k
        try:
            _pay = _paylasan_oge_sayisi(m.get("gid"), haric=None)
        except Exception:                                       # noqa: BLE001
            _pay = None
        _uzman_uyar(k, "sha_yama", yama=_mv,
                    ortak=("" if not _pay or _pay < 2 else
                           " (this archive entry is shared by %d items, so the patch may have "
                           "been installed from a different one)" % _pay))
    try:
        # Capraz modda HEDEFIN kendi bicimi cozer: rigid=True fmt 3/4'u (skinsiz) acar ve fmt
        # 0/1'i (skinli) degistirmeden okur (R/G birebir, olculdu); yazici bicimi R["rigid"]'den
        # alir. Kaynagin bayragiyla okumak rijit hedefi DesteklenmiyorHatasi'na dusuruyordu.
        R, G = MY.oku(data, rigid=True if capraz else bool(m.get("rigid")))
    except Exception as e:                                      # noqa: BLE001
        k["sebep"] = _kullanici_dili(
            "the Workshop cannot decode this mesh (%s), so it cannot write it either." % e)
        return k
    if capraz:
        k["rigid"] = bool(G.get("rigid"))
    n_prim = len(R["MeshData"]["prims"])
    k_parca = None
    for p in k_sahne["parcalar"]:
        if p["ad"] == parca.get("kaynak_ad"):
            k_parca = p
            break
    if k_parca is None:
        k["sebep"] = "the original object could not be found in the export model."
        return k
    if capraz:
        nA = len(k_parca["primler"])
        esle = _prim_esleme(parca, y_parca)
        if len(esle) != nA:
            k["sebep"] = ("%d of %d material group(s) in the edited model could not be matched "
                          "to the source export." % (nA - len(esle), nA))
            return k
        primler, notlar = _capraz_primler(R, G, esle, n_prim, nA)
        k["degisen_prim"] = list(range(n_prim))
        k["NV"] = int(sum(len(p["pos"]) for p in primler))
        k["NT"] = int(sum(len(p["tri"]) for p in primler))
        k["kaynak_NV"] = int(G["NV"])
        k["kaynak_NT"] = int(sum(int(p.get("NT") or 0) for p in R["MeshData"]["prims"]) or 0)
        if notlar:
            k["not"] = "; ".join(notlar)
        dej = "gecir" if any(len(p["pos"]) == 3 and len(p["tri"]) == 1 for p in primler) else "reddet"
        k = _uret(k, ROTA_SERBEST, data, R, G, gid, icid, {"primler": primler, "dejenere": dej})
        if k.get("_is"):
            _capraz_materyal(lf, k, m, esle, n_prim, nA, icid)
        return k
    if len(k_parca["primler"]) != n_prim:
        # C7 POLITIKA: uzman modunda eslesebilen gruplar yazilir, eslesemeyenler oyundaki
        # sekillerini KORUR (`_serbest_primler` eslenmeyen dilimi aynen tasir).
        if not UZ.kapi("materyal_sayisi"):
            k["sebep"] = ("the export holds %d material group(s) for this part but the game mesh has "
                          "%d. Export this item again." % (len(k_parca["primler"]), n_prim))
            return k
        _uzman_uyar(k, "materyal_sayisi", export=len(k_parca["primler"]), oyun=n_prim)
    esle = _prim_esleme(parca, y_parca)
    if len(esle) != n_prim:
        eksik = sorted(set(range(n_prim)) - set(esle))
        # C6 POLITIKA: ayni gerekce -- eslesmeyen gruplar orijinal sekliyle kalir.
        if not UZ.kapi("materyal_eslesme"):
            k["sebep"] = ("%d of %d material group(s) in the edited model could not be matched to the "
                          "original (missing: %s). Every material slot must survive the edit - do not "
                          "delete or merge material slots in Blender."
                          % (n_prim - len(esle), n_prim, ", ".join(str(x) for x in eksik[:6])))
            return k
        _uzman_uyar(k, "materyal_eslesme", eksik=len(eksik), toplam=n_prim,
                    liste=(", ".join(str(x) for x in eksik[:6]) + (" ..." if len(eksik) > 6 else ""))
                          if eksik else "none - the edited model matched more groups than the game "
                                        "mesh has slots")
    if parca.get("topoloji") == GO.BILINMIYOR:
        # C3 POLITIKA: uzman modunda mesh KOMPLE yeniden kurulur (serbest rota). Vertexler
        # gercekten yeniden siralanmissa deri/renk alanlari EN YAKIN komsudan gelir.
        if not UZ.kapi("topoloji_hizalama"):
            k["sebep"] = ("the edited model has the same vertex count but the Workshop could not line "
                          "its vertices up with the original one-for-one (%s). Re-export, edit again "
                          "without re-ordering or duplicating vertices, and import that."
                          % (parca.get("topoloji_sebep") or "no matching key"))
            return k
        _uzman_uyar(k, "topoloji_hizalama",
                    sebep=(parca.get("topoloji_sebep") or "no matching key"))

    # ---- K-3: Blender'da join edilen YENI materyal grubu -> serbest rota, gruba katilir
    fazla = _fazla_primler(parca, y_parca)
    if fazla:
        primler, degisen, notlar = _serbest_primler(R, G, esle, n_prim, fazla=fazla)
        k["degisen_prim"] = degisen
        k["not"] = "; ".join(notlar)
        k = _uret(k, ROTA_SERBEST, data, R, G, gid, icid, {"primler": primler})
        return _kumesiz_rijit_notu(k)
    # ---- ROTA
    normalizasyon = _normalizasyon_notu(parca)
    # BAYAT EXPORT KAPISI (bkz. baslik): kaynak export'un IBM tutarsizligi bu parcanin
    # vertexlerini en fazla `bayat_mm` kadar kaydirabilir; o kadarlik oynama KULLANICININ
    # DEGIL, export'un kusurudur ve yazilmaz.
    bayat_mm = _bayat_ibm_mm(parca)
    if bayat_mm:
        k["bayat_ibm_mm"] = round(bayat_mm, 3)
    if parca.get("topoloji") == GO.IDENTICAL and k["tasima_mm"] is not None \
            and k["tasima_mm"] <= TASIMA_ESIK_M * 1000.0 + bayat_mm:
        k["rota"] = ROTA_ATLA
        k["sebep"] = "unchanged"
        par = []
        if normalizasyon:
            # Blender'in dikis bolmesi / kopya ucgen dususu DUZENLEME DEGILDIR: NV/NT
            # farkina ragmen yazilmaz, ama kullanici sayilarin nereden geldigini gorsun.
            par.append(normalizasyon)
        if bayat_mm and k["tasima_mm"] > TASIMA_ESIK_M * 1000.0:
            k["sebep"] = "unchanged (the movement is the stale export's own bind-matrix error)"
            par.append(_bayat_ibm_metni(k["tasima_mm"], bayat_mm, yazildi=False))
        elif normalizasyon:
            par.append("the shape is unchanged, nothing to write")
        if par:
            k["not"] = "; ".join(par)
        return k
    if normalizasyon:
        k["not"] = normalizasyon
    if bayat_mm:
        # Parca GERCEKTEN duzenlenmis (oynama bayat IBM'in aciklayabileceginden buyuk) ->
        # yazilir, ama yazilan sekle o kusurun da karistigi SOYLENIR.
        k["not"] = ((k["not"] + "; ") if k.get("not") else "") \
            + _bayat_ibm_metni(k["tasima_mm"], bayat_mm, yazildi=True)
    if parca.get("topoloji") == GO.IDENTICAL:
        sirali, olcum = _oyun_sirasi_mi(R, G, k_parca, n_prim)
        if sirali:
            pos, nrm, uv0, hata = _ayni_diziler(R, G, parca, y_parca, k_parca, esle, n_prim)
            if hata is None:
                return _uret(k, ROTA_AYNI, data, R, G, gid, icid,
                             dict(yeni_pos=pos, yeni_normal=nrm, yeni_uv0=uv0))
            k["not"] = "same-topology route unavailable (%s); rebuilding the whole mesh instead" % hata
        else:
            k["not"] = ("same-topology route unavailable (the export's vertex order no longer "
                        "matches the game's%s); rebuilding the whole mesh instead"
                        % ("" if olcum is None else ", off by %.4f m" % olcum))
    # CHANGED (ya da `ayni` on kosulu dusenler) -> serbest topoloji
    primler, degisen, notlar = _serbest_primler(R, G, esle, n_prim)
    k["degisen_prim"] = degisen
    if notlar:                                       # cok gruplu parcada grup buyumesi notu
        k["not"] = ((k["not"] + "; ") if k.get("not") else "") + "; ".join(notlar)
    k = _uret(k, ROTA_SERBEST, data, R, G, gid, icid, {"primler": primler})
    _kumesiz_rijit_notu(k)
    return k


def _bayat_ibm_mm(parca):
    """KAYNAK export'un bu parcadaki IBM tutarsizliginin vertexleri kaydirabilecegi maks
    mesafe (mm); saglam export'ta 0.0 (glb_oku olcumu hic kosmaz, deger None gelir).
    TASIMA_ESIK_M'in ALTINDAKI deger de 0 sayilir: o kadarlik bir kayma zaten `atla`
    dalina duser, kapiyi degistiremez -- ve "off by up to 0.00 mm" diye anlamsiz bir uyari
    yazdirirdi (saglam Tunic'te 0,0008 mm olculdu). Bkz. glb_oku basligi "(1d)"."""
    v = parca.get("kaynak_ibm_kayma_m")
    mm = 0.0 if not v else float(v) * 1000.0
    return 0.0 if mm <= TASIMA_ESIK_M * 1000.0 else mm


def _bayat_ibm_metni(tasima_mm, bayat_mm, yazildi):
    """Bayat export kapisinin kullanici metni (Ingilizce)."""
    if not yazildi:
        return ("the vertices moved %.2f mm, but that movement is the export's own: this item was "
                "exported by an older Workshop build whose bind matrices shift this part by up to "
                "%.2f mm when Blender sends it back. Nothing is written - if you did edit this "
                "part, export the item again and redo the edit on the fresh file"
                % (tasima_mm or 0.0, bayat_mm))
    return ("this item was exported by an older Workshop build whose bind matrices shift this part "
            "by up to %.2f mm when Blender sends it back, so that much of the movement is not "
            "yours; export the item again for a clean result" % bayat_mm)


def _normalizasyon_notu(parca):
    """glb_oku'nun olctugu Blender normalizasyonunu (bolunmus dikis vertexi, dusen kaynak
    kopya ucgeni) kullanici diline cevirir; yoksa None. Bu sayilar DUZENLEME degildir:
    IDENTICAL parcada yazim tetiklemez, CHANGED parcada NV/NT farkinin aciklamasidir."""
    b = int(parca.get("ikiz_bolunme") or 0)
    d = int(parca.get("kopya_ucgen_dustu") or 0)
    if not b and not d:
        return None
    par = []
    if b:
        par.append("Blender re-split %d seam %s" % (b, "vertex" if b == 1 else "vertices"))
    if d:
        par.append("Blender dropped %d duplicate triangle%s the game mesh carries"
                   % (d, "" if d == 1 else "s"))
    return " and ".join(par)


def _sekil_olcumu(k):
    """Serbest rotadaki parcanin onay satiri icin GEOMETRIK OLCUM (Ingilizce). Uc kaynak,
    guvenilirlik sirasiyla: (1) vertex eslemesi kurulduysa olculmus oynama (tasima_mm) +
    glb_oku._donusum_tahmini; (2) esleme yoksa glb_oku._kaba_donusum'un butun-parca tahmini
    (agirlik merkezi, RMS yaricap, ana eksenler; tahmin oldugu soylenir); (3) ikisi de yoksa
    "moved (not measured)". Olculmemis deger ASLA 0 diye basilmaz. Esikler: 0,5 mm oteleme,
    %0,5 olcek, 1 derece donme, eksen basina %2 sinir kutusu sapmasi -- altinda kalan
    duzenleme "local edit" (Weapon_Pistol_11 tek vertex 3 mm: merkez 0,4 mm olculdu)."""
    if k.get("tasima_mm") is not None:
        s = ("vertices moved up to %.2f mm" % k["tasima_mm"]
             if k["tasima_mm"] > TASIMA_ESIK_M * 1000.0
             else "vertices stay in place (only the triangles changed)")
        d = k.get("donusum") or {}
        ek = []
        if d.get("olcek") is not None and abs(float(d["olcek"]) - 1.0) > 0.005:
            ek.append("scaled ~%.2fx" % float(d["olcek"]))
        if float(d.get("oteleme_buyuklugu_m") or 0.0) * 1000.0 > 0.5:
            ek.append("shifted ~%.1f mm" % (float(d["oteleme_buyuklugu_m"]) * 1000.0))
        return s + ((" (" + ", ".join(ek) + ")") if ek else "")
    kb = k.get("kaba")
    if not kb:
        return "moved (not measured - its vertices could not be matched to the original)"
    par = []
    ot = float(kb.get("oteleme_buyuklugu_m") or 0.0) * 1000.0
    olcek = kb.get("olcek")
    aci = kb.get("aci_derece")
    if ot > 0.5:
        par.append("centre moved ~%.1f mm" % ot)
    if olcek is not None and abs(float(olcek) - 1.0) > 0.005:
        par.append("scaled ~%.2fx" % float(olcek))
    if aci is not None and float(aci) >= 1.0:
        par.append("rotated ~%.0f deg" % float(aci))
    elif olcek:
        bo = kb.get("bbox_boy_orani") or []
        if len(bo) == 3 and all(b is not None for b in bo) \
                and any(abs(float(b) / float(olcek) - 1.0) > 0.02 for b in bo):
            par.append("size x%.2f / x%.2f / x%.2f along X / Y / Z" % tuple(float(b) for b in bo))
    if not par:
        par.append("no whole-part move, scale or rotation - a local edit")
    return ("shape changed: " + ", ".join(par)
            + " (estimated from the whole part - its vertices could not be matched one-for-one)")


def _kumesiz_rijit_notu(k):
    """RIJIT parca kume-siz (gate_CMD 3) bicimde yeniden kurulduysa bunu SOYLE: vanilla
    korpusta bu bilesim yok (gizle.py, 330 mesh) ve Hide o dosyayi reddeder -- kullanici
    geri donus yolunun Revert oldugunu bilsin. Sessiz varsayim yerine olculmus not."""
    w = k.get("_is") or {}
    wr = w.get("rapor") or {}
    if k.get("rota") == ROTA_SERBEST and k.get("rigid") and wr.get("mod") == "kumesiz" \
            and not wr.get("kaynak_kumesiz"):
        n = ("rebuilt as a cluster-free rigid mesh - a layout the game's own files never use "
             "and Hide cannot undo (Revert can)")
        k["not"] = (k["not"] + "; " + n) if k.get("not") else n
    return k



# ------------------------------------------------------------------ CAPRAZ (A -> B)
BELIRTEC_KILIF = "Small"          # oyunun kilif kopyasi adi: Musket_W_P_X_Small_01A (bkz. baslik)
_BELIRTEC_RE = None


def _belirtec(ad, taban=None):
    """Parcanin AD BELIRTECI: kilifta duran kucuk kopya icin 'Small', yoksa ''.
    Kural tools/silah_indeks_kur.py ile AYNI: `(^|_)Small(_|$)`, ad 'Small_' ile baslamiyorsa.
    Once `ad` (LOD adi) okunur: K1 ad cozumunun '?' bozulmasi adin KUYRUGUNDA olur ve LOD
    ekini yer (`_Small_01A_LO??`), belirtece dokunmaz (18/18 Small'li tabancada olculdu).
    `taban` LOD eksiz oldugundan kuyruk bozulmasi belirtecin kendisine gelir (katalogda
    `Smal?`, `Sm???` var); yalniz o zaman hosgorulu kuyruk kurali: son token 'Sm' ile baslar,
    kalan harfler 'Small'in harfi ya da '?' ve '?'ler yalniz kuyrukta."""
    import re
    global _BELIRTEC_RE
    if _BELIRTEC_RE is None:
        _BELIRTEC_RE = re.compile(r"(^|_)%s(_|$)" % BELIRTEC_KILIF)
    for s in (ad, taban):
        s = str(s or "")
        if _BELIRTEC_RE.search(s) and not s.startswith(BELIRTEC_KILIF + "_"):
            return BELIRTEC_KILIF
    t = str(taban or "")
    son = t.split("_")[-1] if t else ""
    if son.endswith("?") and len(son) == len(BELIRTEC_KILIF) and son.startswith("Sm") \
            and "_" in t:
        govde = son.rstrip("?")
        if BELIRTEC_KILIF.startswith(govde):
            return BELIRTEC_KILIF
    return ""


def _aile_anahtari(taban, ad=None):
    """Parca AILESI: 'Tunic_U_Edward_Diplomat_X_Dress' -> 'Tunic_X_Dress',
    'HumanBody_Head_Mannequin' -> 'HumanBody_Head', 'Boots_Edward_Assassin' -> 'Boots',
    kilif kopyasi 'Musket_W_P_GoldenPistol_Small_01A' -> 'Musket_Small' (bkz. `_belirtec`).
    Olculdu: 760 grupta ayni kiyafet icinde yalniz 19 cakisma; tabancalarda ise 18/18 ogede
    el modeli + kilif kopyasi AYNI aileye dusuyordu (2026-09-05'e kadar ikisi de 'Musket'),
    belirtec ayirdi. `ad` verilmezse belirtec `taban`in kendisinden okunur (kaynak_ad ile
    cagrilan hata metni)."""
    import re
    s = str(taban or ad or "")
    tok = s.split("_")
    k = tok[0] if tok else ""
    if len(tok) > 1 and tok[1] in ("Head", "Hands", "Face", "Hair", "Neck"):
        k += "_" + tok[1]
    m = re.search(r"_X_([A-Za-z0-9]+)", s)
    if m:
        k += "_X_" + m.group(1)
    b = _belirtec(ad if ad is not None else s, taban)
    if b:
        k += "_" + b
    return k


def _aile_gorunen(aile):
    """Kullaniciya gosterilen aile adi: 'Musket_Small' -> 'Musket holster copy'."""
    a = str(aile or "")
    if a.endswith("_" + BELIRTEC_KILIF):
        return a[:-len(BELIRTEC_KILIF) - 1] + " holster copy"
    return a


def _hedef_parcalari(hedef, silah):
    """Hedef ogenin (indeksten) yazilabilir parcalari: [{ad, taban, gid, icid, boyut, aile
    [, bantlar]}]. Birincil kayit lodlar[0] (degismedi). Silahta her kayda `bantlar` eklenir:
    grubun LODSelector sirasindaki TUM bant mesh'leri (bkz. baslik "LOD BANTLARI"); indekste
    bant bilgisi yoksa None (yalniz birincil yazilir, rapor bunu soyler)."""
    try:
        from . import sahne as S3
    except ImportError:
        import sahne as S3
    liste = S3.silah_parcalar(hedef, 0) if silah else S3.parcalar(hedef, 0)
    # KIYAFET BANTLARI (2026-09-08): kiyafet/karakter hedefinde de her kayda `bantlar` konur;
    # tablo kurulamazsa (indeks kaydi zincirsiz) bos kalir = bilgi yok, yalniz birincil yazilir.
    try:
        bant_tablo = _silah_bant_tablosu(hedef) if silah else _kiyafet_bant_tablosu(hedef)
    except Exception:                                           # noqa: BLE001
        bant_tablo = {}
    out = []
    for p in liste:
        if p.get("gid") is None or p.get("icid") is None:
            continue
        kayit = {"ad": str(p["ad"]), "taban": p.get("taban"),
                 "gid": "0x%012X" % int(p["gid"]), "icid": "0x%012X" % int(p["icid"]),
                 "boyut": int(p.get("boyut") or 0),
                 "aile": _aile_anahtari(p.get("taban"), str(p["ad"]))}
        kayit["bantlar"] = bant_tablo.get((int(p["gid"]), int(p["icid"])))
        out.append(kayit)
    return out


def _silah_bant_tablosu(hedef):
    """Silah indeksinden (forge acilmadan) hedefin her grubu icin LODSelector SIRASINDAKI tum
    bant mesh'leri (bkz. baslik "LOD BANTLARI"). Anahtar: grubun birincil mesh'i lodlar[0]
    (gid, icid). Deger: [{ad, gid, icid, boyut, bant, rol, mesafe, birincil}] ya da None =
    indekste zincir kaydi yok / rol-bant-mesafe listeleri lodlar ile hizali degil (o zaman
    yalniz birincil yazilir ve rapor bunu SOYLER -- sessiz varsayim yok)."""
    try:
        from . import sahne as S3
    except ImportError:
        import sahne as S3
    idx, _yol = S3.silah_indeks_yukle()
    out = {}
    for g in (idx.get(hedef) or {}).get("gruplar") or []:
        lodlar = g.get("lodlar") or []
        if not lodlar:
            continue
        try:
            anahtar = (int(lodlar[0][1]), int(lodlar[0][2]))
        except (TypeError, ValueError, IndexError):
            continue
        z = g.get("zincir") or {}
        rol, bant, mes = z.get("rol") or [], z.get("bant") or [], z.get("mesafe") or []
        if not (len(rol) == len(bant) == len(mes) == len(lodlar)):
            out[anahtar] = None
            continue
        try:
            # `yazilir`: SILAHTA yalniz ANA (rol 'main') bantlar yazilir -- proxy karari
            # olculdu ve degismedi (bkz. baslik "PROXY KARARI"). Kiyafet tablosu bu alani
            # her bantta True kurar (bkz. `_kiyafet_bant_tablosu`).
            out[anahtar] = [
                {"ad": str(ad), "gid": "0x%012X" % int(gid), "icid": "0x%012X" % int(icid),
                 "boyut": int(boyut or 0), "bant": int(b), "rol": str(r),
                 "mesafe": (None if m is None else float(m)), "birincil": (i == 0),
                 "yazilir": (str(r) == "main")}
                for i, ((boyut, gid, icid, ad), r, b, m) in enumerate(zip(lodlar, rol, bant, mes))]
        except (TypeError, ValueError):
            out[anahtar] = None
    return out


def _kiyafet_bant_tablosu(hedef):
    """KIYAFET / KARAKTER indeksinden (forge acilmadan) hedefin her grubu icin LODSelector
    SIRASINDAKI tum bant mesh'leri (bkz. baslik "KIYAFET BANTLARI", 2026-09-08). Deger bicimi
    `_silah_bant_tablosu` ile AYNI ([{ad, gid, icid, boyut, bant, rol, mesafe, birincil,
    yazilir}] ya da None = indekste zincir kaydi yok / diziler lodlar ile hizali degil; o zaman
    yalniz birincil yazilir ve rapor bunu SOYLER). Silah tablosundan iki farki var:
      (1) ANAHTAR grubun HER (gid, icid) ciftidir, yalniz lodlar[0] degil: 2026-09-04'ten once
          alinmis export'larin birincili bugunku lodlar[0] olmayabilir (indeks o gun LODSelector
          zincir sirasina gecti); `birincil` bakilan anahtara gore isaretlenir, boylece bayat
          export'ta da grubun DIGER bantlari bulunur.
      (2) `yazilir` HER bantta True. Olculdu (onizleme3d_indeks.json, 760 grup, 2026-09-08):
          708 grubun birden cok LOD girisi var; Edward_Assassin'in 29 grubundan Dress/Torso/
          Boots/Sash gibi 12'sinde 5 bandin 5'i de 'proxy' (A kaydi), 'main' HIC YOK -- oyun o
          A mesh'lerini cizer. Silahin "yalniz ana bant" kurali burada TEK mesh yazar ve parca
          ilk bant sinirinin (4 m) otesinde vanilla'ya doner. cozum.py basligindaki kural:
          "YAZICI TUM BANTLARI YAMALAMALIDIR"."""
    try:
        from . import sahne as S3
    except ImportError:
        import sahne as S3
    kayit = S3.kayit_bul(hedef)
    out = {}
    for g in kayit.get("gruplar") or []:
        lodlar = g.get("lodlar") or []
        if not lodlar:
            continue
        try:
            anahtarlar = [(int(l[1]), int(l[2])) for l in lodlar]
        except (TypeError, ValueError, IndexError):
            continue
        z = g.get("zincir") or {}
        rol, bant, mes = z.get("rol") or [], z.get("bant") or [], z.get("mesafe") or []
        if not z or not (len(rol) == len(bant) == len(mes) == len(lodlar)):
            for a in anahtarlar:
                out[a] = None
            continue
        try:
            kayitlar = [
                {"ad": str(ad), "gid": "0x%012X" % int(gid), "icid": "0x%012X" % int(icid),
                 "boyut": int(boyut or 0), "bant": int(b), "rol": str(r),
                 "mesafe": (None if m is None else float(m)), "birincil": False, "yazilir": True}
                for (boyut, gid, icid, ad), r, b, m in zip(lodlar, rol, bant, mes)]
        except (TypeError, ValueError):
            for a in anahtarlar:
                out[a] = None
            continue
        for i, a in enumerate(anahtarlar):
            out[a] = [dict(k, birincil=(j == i)) for j, k in enumerate(kayitlar)]
    return out


def _bant_yazilir(b):
    """Bu bant mesh'i yazilir mi? Tablo `yazilir` alanini tasir; tasimayan eski kayitlarda
    (2026-09-08 oncesi cagiran) silah kurali: yalniz rol 'main'."""
    y = b.get("yazilir")
    return (str(b.get("rol")) == "main") if y is None else bool(y)


def _bant_kaydi(tablo, m):
    """`_silah_bant_tablosu` ciktisindan bir manifest parcasinin ({gid, icid} onaltilik) bant
    listesi; tablo bos / parca tabloda yok / adres okunamiyor -> None (= bilgi yok, sessiz
    varsayim yok)."""
    if not tablo or not m or not m.get("gid") or not m.get("icid"):
        return None
    try:
        return tablo.get((int(str(m["gid"]), 16), int(str(m["icid"]), 16)))
    except (TypeError, ValueError):
        return None


def _ayni_oge_bant_kaydi(tablo, m):
    """AYNI-OGE (capraz olmayan) silah ithalatinda `_capraz_bant_kararlari`ye verilen "hedef
    kaydi": hedef, kaynagin KENDI grubudur. Manifest parcasindan kurulur; bant listesi yoksa
    kayit yine doner (kapsam `bilgi_yok` olur ve rapor bunu soyler)."""
    if not m or not m.get("gid") or not m.get("icid"):
        return None
    return {"ad": m.get("ad"), "gid": m.get("gid"), "icid": m.get("icid"),
            "boyut": int(m.get("ic_bayt") or 0), "esleme_sebebi": None,
            "bantlar": _bant_kaydi(tablo, m)}


def _bant_ozeti(out):
    """Sozlesme alani `bant_ozeti` = {grup, yazilacak_bant, atlanan_bant}: silahin kac bant
    mesh'i var ve kacina yaziliyor (rapor metnini doku_ithal yazar). Bant listesi OLCULEMEYEN
    parcalar sayima GIRMEZ -- onlarin kendi "no LOD layout" satiri var, tahmin uretilmez.
    YAZILMAYAN parcalar da girmez: hicbir seyin yazilmadigi bir ithalatta "written to 0 of
    them" cumlesi kullaniciya yanlis bir kayip duygusu verir; o durumda satir hic kurulmaz."""
    grup = yaz = top = 0
    for k in out.get("parcalar") or []:
        kp = k.get("lod_kapsam")
        if not isinstance(kp, dict) or kp.get("bilgi_yok") or not kp.get("bant_sayisi"):
            continue
        if k.get("rota") not in (ROTA_AYNI, ROTA_SERBEST):
            continue
        grup += 1
        top += int(kp["bant_sayisi"])
        yaz += len(kp.get("yazilan") or [])
    return {"grup": grup, "yazilacak_bant": yaz, "atlanan_bant": max(top - yaz, 0)}


def _m_metni(m):
    """Bant ust siniri (metre) kullanici metni; olculmemis -> '? m' (asla 0 basilmaz)."""
    return ("%.1f m" % float(m)) if isinstance(m, (int, float)) else "? m"


def _lod_kapsam_metni(kp):
    """Capraz silah WRITE satirinin altina dusen LOD KAPSAMI (Ingilizce; bkz. baslik
    "LOD BANTLARI"): hangi bantlarin yazildigi ve hangi mesafeden itibaren hedefin orijinal
    seklinin gorunecegi, indeksteki OLCULEN bant sinirlariyla."""
    # "it" = capraz'da hedef oge, ayni-ogede ithal edilen ogenin kendisi.
    sahip = "the item's" if kp.get("ayni_oge") else "the target's"
    if kp.get("bilgi_yok"):
        return ("LOD bands: the weapon index holds no LOD layout for this part, so only this one "
                "mesh is rewritten; if it has other LOD bands they keep %s original shape "
                "from farther away." % sahip)
    yaz = kp.get("yazilan") or []
    if kp.get("tek") and yaz:
        return ("LOD bands: this is the part's only mesh (drawn to %s), so the new shape shows at "
                "every distance." % _m_metni(yaz[0][1]))
    px = kp.get("proxy") or []
    uzak = [m for _b, m in yaz if isinstance(m, (int, float))]
    en_uzak = _m_metni(max(uzak)) if uzak else "? m"
    if not px and kp.get("hepsi"):
        # KIYAFET: grubun BUTUN mesh'leri yazilir (proxy ayrimi yok) -- sekil her mesafede ayni
        return ("LOD bands: all %d meshes of this part are rewritten - %s - so the new shape "
                "shows at every distance (to %s)."
                % (len(yaz), ", ".join("band %d (to %s)" % (b, _m_metni(m)) for b, m in yaz),
                   en_uzak))
    s = ("LOD bands: the main meshes of %s are rewritten - the shapes the game draws this part "
         "with up to %s."
         % (" and ".join("band %d (to %s)" % (b, _m_metni(m)) for b, m in yaz), en_uzak))
    if px:
        s += (" The %d proxy mesh%s (lower-detail stand-ins used for shadows and for the far "
              "distance: %s) %s not rewritten, so beyond %s %s original outline shows."
              % (len(px), "" if len(px) == 1 else "es",
                 ", ".join("to %s" % _m_metni(m) for _b, m in px),
                 "is" if len(px) == 1 else "are", en_uzak, sahip))
    return s


def _capraz_bant_kararlari(lf, parca, y_parca, k_sahne, yamalar, doku_kaplari, hk, k,
                           ayni_oge=False):
    """SILAH: birincil (lodlar[0]) karari `k` verildikten sonra grubun DIGER ANA (rol 'main')
    bant mesh'leri icin AYNI kaynak parcayla ek kararlar (bkz. baslik "LOD BANTLARI").
    Proxy (golge/uzak) bantlara dokunulmaz; kapsam `k["lod_kapsam"]`a yazilir, rapor onu soyler.
    Doner ek kayit listesi (birincilden SONRA eklenir; arayuz/testler parcalar[0]'i birincil okur).

    ayni_oge=True (IMPORT 3D, capraz DEGIL): yuva kaynagin KENDI grubudur. Kayitlar yine
    "capraz" yoluyla uretilir -- bant mesh'i ayri bir arsiv girisidir, kendi topolojisi vardir
    ve sha kapisi ona uymaz; `_parca_karari(capraz=True)` tam bu isi yapar (olculdu: capraz
    yolda 21/21 kapi). Fark yalniz raporda: satir "A -> B" demez, kendi adini tasir.

    TUM-YA-DA-HIC: bir ana bant yazilamiyorsa birincil de dusurulur -- yalniz yakin bant
    yazilsa oyun ilk bant sinirinin (1 m) otesinde vanilla sekli cizer, kullanici
    "hicbir sey degismedi" gorur (Drake kiliclarinda oyun ici olculdu, bkz. cozum.py basligi)."""
    bantlar = hk.get("bantlar") if hk else None
    kp = {"bilgi_yok": bantlar is None, "tek": False, "yazilan": [], "proxy": [], "red": None,
          "bant_sayisi": (0 if bantlar is None else len(bantlar)), "ayni_oge": bool(ayni_oge),
          # KIYAFET BANTLARI (2026-09-08): tablo her bandi `yazilir` isaretlediyse (kiyafet)
          # proxy ayrimi yoktur, rapor "all N meshes" der; silahta eski metin aynen kalir.
          "hepsi": bool(bantlar) and all(_bant_yazilir(b) for b in bantlar)}
    k["lod_kapsam"] = kp
    # Birincil YAZILMIYORSA (atla/red) bantlara da gidilmez. `ayni` rotasi da gecerlidir:
    # ayni-oge ithalatinda birincil cogu zaman `ayni` olur (topoloji degismemistir) ama diger
    # bant mesh'leri BASKA topolojidedir ve serbest yolla yazilir.
    if bantlar is None or k["rota"] not in (ROTA_SERBEST, ROTA_AYNI):
        return []
    birincil = next((b for b in bantlar if b.get("birincil")), None)
    kp["proxy"] = [(b["bant"], b["mesafe"]) for b in bantlar if not _bant_yazilir(b)]
    if birincil is not None:
        kp["yazilan"].append((birincil["bant"], birincil["mesafe"]))
    if len(bantlar) == 1:
        kp["tek"] = True
        return []
    ek = []
    for b in bantlar:
        if not _bant_yazilir(b) or b.get("birincil"):
            continue
        hk2 = dict(hk, ad=b["ad"], gid=b["gid"], icid=b["icid"], boyut=b["boyut"],
                   esleme_sebebi=None, bantlar=None)
        k2 = _parca_karari(lf, parca, y_parca, k_sahne, yamalar, doku_kaplari,
                           hedef_kaydi=hk2, capraz=True)
        k2["ad_taban"] = k["ad"]
        k2["ad"] = "%s [LOD band %d]" % (k["ad"], b["bant"])
        k2["bant_ek"], k2["bant"], k2["bant_mesafe"] = True, b["bant"], b["mesafe"]
        k2["ad_celiskisi"], k2["takas_imzasi"] = k.get("ad_celiskisi"), k.get("takas_imzasi")
        # AYNI-OGE: kayit teknik olarak capraz yolla uretildi ama kullanici acisindan CAPRAZ
        # AKTARIM DEGIL (ayni ogenin baska bir LOD yuvasi). Rapor satiri "A -> B" demesin.
        k2["ayni_oge_bant"] = bool(ayni_oge)
        if ayni_oge:
            k2["capraz"] = False
            # "the target already uses the same material" ayni-ogede BEKLENEN durumdur
            # (157/159 cok-bantli grupta ana bantlarin materyali birebir ayni -- olculdu);
            # satiri basmak kullaniciya soylenecek bir sey eklemez. Diger materyal notlari
            # (yonlendirme yapilamadi vb.) AYNEN kalir.
            if k2.get("materyal_not") == "the target already uses the same material":
                k2.pop("materyal_not", None)
        if k2["rota"] == ROTA_RED:
            # C8 POLITIKA: TUMU-YA-DA-HIC. Uzman modunda yazilabilen bantlar YAZILIR ve
            # uyari, o mesafeden hangi seklin gorunecegini soyler. Yazilamayan bandin
            # KENDI sebebi (guvenlik ya da kapasite olabilir) burada YUTULMAZ, uyariya girer.
            if UZ.kapi("lod_bandi"):
                kp["red"] = (b["bant"], b["mesafe"], k2.get("sebep"))
                _uzman_uyar(k, "lod_bandi", bant=b["bant"], mesafe=_m_metni(b["mesafe"]),
                            sebep=(k2.get("sebep") or "no reason was recorded"))
                continue
            kp["red"] = (b["bant"], b["mesafe"], k2.get("sebep"))
            kp["yazilan"] = []
            k["rota"], k["_is"] = ROTA_RED, None
            for a in ("materyal", "_materyal_prim2mat", "_materyal_mesh_icid", "yeni_bayt"):
                k.pop(a, None)
            k["sebep"] = ("its LOD band %d mesh (drawn to %s) could not be rewritten: %s A part "
                          "is written into every LOD band the game draws it from, or not at all - "
                          "writing only the close-up band would leave the original shape "
                          "on screen from %s away - so nothing is written for it."
                          % (b["bant"], _m_metni(b["mesafe"]), k2.get("sebep"),
                             _m_metni(birincil["mesafe"] if birincil else None)))
            return []
        kp["yazilan"].append((b["bant"], b["mesafe"]))
        if k2["rota"] == ROTA_ATLA:
            continue        # hedef bant zaten ayni baytlara kuruluyor (pratikte olmaz): kapsamda
        ek.append(k2)
    return ek


def _eksik_bant_girdileri(e):
    """Gizlenecek hedef-yalniz SILAH parcasi icin gizlenecek mesh'ler: birincil + diger ANA
    bantlar (bkz. baslik "LOD BANTLARI"); bant bilgisi yoksa yalniz birincil. Proxy bantlara
    dokunulmaz. `eksik` listesinin kendisi parca basina TEK kayit kalir (arayuz sayaci)."""
    out = [e]
    for b in e.get("bantlar") or []:
        # silah: yalniz ANA bantlar; kiyafet: HER bant (`yazilir`, bkz. `_kiyafet_bant_tablosu`)
        if not _bant_yazilir(b) or b.get("birincil"):
            continue
        # sha256 = None: manifest YALNIZ birincil mesh'in ozetini tasir. Kaydi oldugu gibi
        # kopyalamak birincilin ozetini bant mesh'ine dayatir ve `_gizle_karari` her zaman
        # "the game archive changed since this export" der -- yanlis teshis (2026-09-07
        # olculdu: ayni-oge gizlemede bant 1 boyle reddediliyordu). Capraz yolda kayit zaten
        # sha256=None geliyordu. Kapi GEVSEMIYOR: bant mesh'i icin karsilastirilacak bir
        # ozet HIC yok; mesh yine cozulur (gizle.gizle), "zaten gizli" kapisi calisir ve
        # kur_mesh yazdiktan sonra diskten geri okuyup dogrular.
        out.append(dict(e, ad="%s [LOD band %d]" % (e["ad"], b["bant"]), gid=b["gid"],
                        icid=b["icid"], bant_ek=True, bant=b["bant"], bant_mesafe=b["mesafe"],
                        bantlar=None, sha256=None))
    return out


def _ad_coz(ad, adaylar):
    """Kullanicinin verdigi adi listedeki gercek ada baglar: birebir -> kucuk harf ->
    `?` kirpilmis on ek (ansiklopedi adlari kirpik olabiliyor: 'Hat_U_Edward_Fire_LO??').
    Doner gercek ad ya da None."""
    if ad is None:
        return None
    s = str(ad)
    if s in adaylar:
        return s
    kh = {a.lower(): a for a in adaylar}
    if s.lower() in kh:
        return kh[s.lower()]
    kok = s.split("?")[0].lower()
    if len(kok) >= 4:
        tut = [a for a in adaylar if a.lower().startswith(kok)]
        if len(tut) == 1:
            return tut[0]
    return None


def _elle_esleme_uygula(esleme, kullanici, kaynak, hedef, out):
    """Kullanicinin verdigi {kaynak_parca: hedef_parca} haritasini otomatik eslemenin USTUNE yazar.
    Cozulemeyen ad varsa rapora ACIK not dusulur (sessiz yok sayma yok). Doner yasakli kaynak
    adlari kumesi (deger None verilenler: 'bu parcayi yazma')."""
    k_adlar = [k["ad"] for k in kaynak]
    h_adlar = {h["ad"]: h for h in hedef}
    yasak = set()
    for ham_k, ham_h in (kullanici or {}).items():
        k_ad = _ad_coz(ham_k, k_adlar)
        if k_ad is None:
            out.setdefault("notlar", []).append(
                "the source part %r is not in this export, so that mapping was ignored" % ham_k)
            continue
        if ham_h is None:
            esleme.pop(k_ad, None)
            yasak.add(k_ad)
            continue
        h_ad = _ad_coz(ham_h, list(h_adlar))
        if h_ad is None:
            out.setdefault("notlar", []).append(
                "the target has no part called %r, so %s was not written" % (ham_h, k_ad))
            esleme.pop(k_ad, None)
            yasak.add(k_ad)
            continue
        esleme[k_ad] = h_adlar[h_ad]
        out.setdefault("notlar", []).append("you mapped %s onto %s" % (k_ad, h_ad))
    return yasak


def _capraz_esle(kaynak, hedef, uyarilar=None):
    """A parcalari -> B parcalari. Doner (esleme{A_ad: B_kaydi}, yersiz[A_ad], hedef_yalniz[B]).
    Kural: iki tarafta da TEK parca -> dogrudan; yoksa aile anahtari (ad belirteci DAHIL:
    kilif kopyasi yalniz kilif kopyasina), ayni ailede birden fazla parca varsa boyut sirasi
    SON CARE. 2026-09-05'e kadar belirtec yoktu: Pistol_11'de kilif kopyasi ana modelden buyuk
    oldugu icin zip Small<->el capraz bagliyordu (bkz. baslik "CAPRAZ ESLEME").
    Her B kaydina `esleme_sebebi` (kullaniciya giden Ingilizce dayanak) eklenir."""
    esleme, kullanilan = {}, set()
    if len(kaynak) == 1 and len(hedef) == 1:
        esleme[kaynak[0]["ad"]] = dict(hedef[0], esleme_sebebi="the only part on each side")
        return esleme, [], []
    h_aile = {}
    for h in hedef:
        h_aile.setdefault(h["aile"], []).append(h)
    for grp in h_aile.values():
        grp.sort(key=lambda x: -x["boyut"])
    k_aile = {}
    for k in kaynak:
        k_aile.setdefault(k["aile"], []).append(k)
    for aile, ks in k_aile.items():
        ks.sort(key=lambda x: -(x.get("boyut") or 0))
        hs = h_aile.get(aile, [])
        if str(aile).endswith("_" + BELIRTEC_KILIF):
            sebep = ("holster copy -> holster copy (paired by the '_%s' name marker; the belt-holster "
                     "copy never goes into the hand-held slot)" % BELIRTEC_KILIF)
        elif len(ks) == 1 and len(hs) == 1:
            sebep = "paired by part family '%s' (the only part of this kind on each side)" % _aile_gorunen(aile)
        else:
            sebep = ("paired by part family '%s' (%d source / %d target parts of this kind, ordered by "
                     "file size - check the names)" % (_aile_gorunen(aile), len(ks), len(hs)))
        for k, h in zip(ks, hs):
            esleme[k["ad"]] = dict(h, esleme_sebebi=sebep)
            kullanilan.add(h["ad"])
    yersiz = [k["ad"] for k in kaynak if k["ad"] not in esleme]
    hedef_yalniz = [h for h in hedef if h["ad"] not in kullanilan]
    # C9 POLITIKA: "hedefte bu turden parca yok". Varsayilanda o kaynak parcasi YAZILMAZ
    # (`_parca_karari` hedef_kaydi=None ile reddeder). Uzman modunda aile kurali BIR KEZ
    # gevsetilir: yersiz kalan kaynak parcalari, KULLANILMAMIS hedef parcalariyla dosya
    # boyutu sirasina gore eslenir. Bu bir TAHMINDIR; uyari bunu acikca soyler ve hangi
    # yuvaya dustugunu yazar. Hedef kalmadiysa eslenmeyen parca yine reddedilir.
    if yersiz and hedef_yalniz and UZ.kapi("hedef_yok"):
        k_boyut = {k["ad"]: (k.get("boyut") or 0) for k in kaynak}
        art = sorted(yersiz, key=lambda a: -k_boyut.get(a, 0))
        kalan = sorted(hedef_yalniz, key=lambda x: -(x.get("boyut") or 0))
        for a, h in zip(art, kalan):
            esleme[a] = dict(h, esleme_sebebi=(
                "EXPERT MODE: the target has no part of this kind - paired with the largest "
                "unused target part by file size, which is a guess, not a match"))
            kullanilan.add(h["ad"])
            if uyarilar is not None:
                uyarilar.append({"ad": a,
                                 "uyari": UZ.uyari("hedef_yok", kaynak=a, hedef=h["ad"])})
        yersiz = [k["ad"] for k in kaynak if k["ad"] not in esleme]
        hedef_yalniz = [h for h in hedef if h["ad"] not in kullanilan]
    return esleme, yersiz, hedef_yalniz


def _cokuk_prim(pos_ref):
    """Gorunmez primitif: 3 vertex tek noktada, 1 sifir-alanli ucgen (dejenere='gecir')."""
    c = np.asarray(pos_ref, np.float64).mean(0) if len(pos_ref) else np.zeros(3)
    return {"pos": np.repeat(c[None, :], 3, 0), "tri": np.array([[0, 1, 2]], np.int64),
            "uv0": np.zeros((3, 2), np.float64)}


def _capraz_primler(R, G, esle, n_prim, nA):
    """B mesh'i (R,G) icin primitif listesi: A'nin GLB primitifleri sirayla B'nin
    primitiflerine; A'nin fazlasi B'nin SON primitifine katilir; B'nin fazlasi cokertilir.
    Doner (primler, notlar[])."""
    primler = MZ.prim_geometri(R, G)
    uv1_var = (G.get("uv1") is not None)
    notlar = []

    def _d(yp):
        d = {"pos": np.asarray(yp["pos"], np.float64), "tri": np.asarray(yp["tri"], np.int64)}
        if yp.get("uv0") is not None:
            d["uv0"] = np.asarray(yp["uv0"], np.float64)
        if uv1_var and yp.get("uv1") is not None:
            d["uv1"] = np.asarray(yp["uv1"], np.float64)
        if yp.get("nrm") is not None:
            d["normal"] = np.asarray(yp["nrm"], np.float64)
        return d

    def _birlestir(a, b):
        n = len(a["pos"])
        out = {"pos": np.concatenate([a["pos"], b["pos"]]),
               "tri": np.concatenate([a["tri"], b["tri"] + n])}
        for k in ("uv0", "uv1", "normal"):
            if k in a and k in b:
                out[k] = np.concatenate([a[k], b[k]])
        return out

    hedef_pos = np.asarray(G["pos"], np.float64)
    dolu = {}
    for i in range(nA):
        if i not in esle:
            continue
        yp, _q = esle[i]
        j = min(i, n_prim - 1)
        dolu[j] = _birlestir(dolu[j], _d(yp)) if j in dolu else _d(yp)
        if j != i:
            notlar.append("source material group %d was merged into the target's last group %d"
                          % (i, j))
    cokuk = 0
    for j in range(n_prim):
        if j in dolu:
            primler[j] = dolu[j]
        else:
            primler[j] = _cokuk_prim(hedef_pos)
            cokuk += 1
    if cokuk:
        notlar.append("%d target material group(s) had no source and are hidden" % cokuk)
    return primler, notlar


def _kullanici_dili(msg):
    """Yazicinin ic dilindeki red sebebini son kullanicinin diline cevirir (K-5).
    Yalnizca bilinen kaliplar; taninmayan mesaj aynen gecer (bilgi kaybi yok)."""
    import re
    m = re.search(r"scale down by at least ([0-9.]+)x", msg)
    if "quantisation range" in msg and m:
        return ("this part is too big for its slot: the game stores each mesh's positions in a "
                "fixed range, and this model reaches %.2fx past it. Scale the whole object down "
                "by at least %.2fx in Blender (or move it back towards the body) and export "
                "again. Shrinking and reshaping are always fine; growing past the original "
                "size is the one thing the archive does not allow yet."
                % (float(m.group(1)), float(m.group(1))))
    if "65535" in msg and "vert" in msg:
        return ("this part has more than 65,535 vertices after the edit; the game's index "
                "format cannot address more. Reduce the vertex count (Decimate, or undo a "
                "Subdivision) and export again.")
    if "skinless; pass rigid=True" in msg:
        # mesh_yapisal.SEBEP_RIGID: okuyucu skinli bekledi, mesh skinsiz (rijit). Capraz modda
        # artik olusmaz (hedef rigid=True ile okunur); kendi export'unda yalniz manifest'in
        # `rigid` alani mesh'le celisiyorsa gelir -> taze export ister. Ic dil sizdirilmaz.
        return ("this game mesh has no skeleton (a rigid model), but the export recorded it as a "
                "skinned one, so the Workshop does not know which layout to write. Run EXPORT 3D "
                "on this item again and import from the fresh folder.")
    return msg


def _materyal_dogrula(lf, a_mats):
    """CAPRAZ MATERYAL KAPISI (bkz. baslik): A'nin manifestteki materyal id'lerinden canli
    TOC'ta UST DUZEY giris OLMAYANLARI dondurur (hex metin listesi; bos liste = hepsi dogrulandi).
    Olcut aracin kendi doku okuyucusuyla AYNI (`outfit_core._material_res`: `lf.by_id`);
    baska bir girisin icine gomulu materyal id'si buradan gecmez (vanilla emsali 0/3.423)."""
    gecersiz = []
    for x in a_mats:
        try:
            mid = int(str(x), 16)
        except (TypeError, ValueError):
            gecersiz.append(str(x))
            continue
        if mid not in lf.by_id:
            gecersiz.append("0x%X" % mid)
    return gecersiz


def _materyal_dusenler(esle, a_mats, prim2mat, n_prim, nA):
    """CAPRAZ MATERYAL KATLAMASI (bkz. baslik): hedef gruba katlanan kaynak gruplarindan
    materyali o gruba YAZILAN materyalden FARKLI olanlar. Doner [{grup, hedef_grup, materyal,
    kullanilan, NT}] (kaynak grup sirasiyla); bos liste = her kaynak grubunun materyali tasindi.
    Ayni materyalli katlanan grup kayip DEGILDIR (yanlis alarm yok). NT = grubun GLB'deki
    ucgen sayisi (rapordaki pay icin OLCULUR, varsayilmaz). Secimi degistirmez, yalniz olcer."""
    out = []
    for i in range(nA):
        if i not in esle:
            continue
        j = min(i, n_prim - 1)
        mid = int(str(a_mats[min(i, len(a_mats) - 1)]), 16)
        kul = prim2mat.get(j)
        if kul is None or mid == kul:
            continue
        yp = esle[i][0]
        try:
            nt = int(len(np.asarray(yp["tri"], np.int64).reshape(-1, 3)))
        except Exception:                                   # noqa: BLE001  (ucgen dizisi yoksa)
            nt = int((yp.get("NT") if isinstance(yp, dict) else 0) or 0)
        out.append({"grup": i, "hedef_grup": j, "materyal": "0x%X" % mid,
                    "kullanilan": "0x%X" % kul, "NT": nt})
    return out


def _capraz_materyal(lf, k, m, esle, n_prim, nA, icid):
    """Capraz yazimda A'nin materyalini B'nin yeni mesh'ine isler (MID + CBA) ve hedefin
    LODSelector'u icin ikinci bir is hazirlar. Basarisizlik parcayi DUSURMEZ: sekil yine
    yazilir, raporda "textures could not follow" denir.
    KAPI: A'nin materyali canli TOC'ta ust duzey giris degilse (`_materyal_dogrula`) hicbir
    referans cevrilmez; `_materyal_prim2mat` kurulmadigi icin `_lodsel_isleri` de bu parca
    icin is uretmez (mesh MID/CBA + LODSelector B kaydi hedefin kendi materyalinde kalir).
    KATLAMA: hedef mesh yuva kazanamadigi icin A'nin fazla gruplari B'nin son grubuna katlanir
    ve o gruba yalniz ILK gelenin materyali yazilir; digerleri `_materyal_dusenler` ile OLCULUP
    parca kaydina (`materyal_dusen`, `materyal_dusen_ucgen_pay`, `materyal_tasinan_grup`,
    `materyal_yuva`) yazilir, rapor bunu WARNING olarak soyler (bkz. baslik)."""
    try:
        try:
            from . import materyal_yonlendir as MTY
        except ImportError:
            import materyal_yonlendir as MTY
        a_mats = [x for x in (m.get("materyaller") or []) if x]
        if not a_mats:
            k["materyal_not"] = "the source export records no material for this part; the target keeps its own textures"
            return
        # --- KAPI (fail-closed): manifestteki id, arsivin canli TOC'unda ust duzey giris olmali.
        # 2026-09-05'e kadar kontrol yoktu: CHR_W_Sword -> Weapon_Sword_02'de mesh MID+CBA ve
        # LODSelector B kaydi, kaynak girisin (0x73D421434) ICINE gomulu 0x730D46174'e
        # cevriliyordu -- export'un kendisi bu materyali "material not in forge" diye atlamisti
        # (0 doku slotu) ama rapor "textures follow the shape" diyordu. Boyle bir referansin
        # (baska girise gomulu materyal) vanilla'da emsali 0. Dogrulanamayan materyal varsa
        # parca YONLENDIRILMEZ, hedef kendi materyalinde kalir ve sebebi kullaniciya gider.
        dogrulanamayan = _materyal_dogrula(lf, a_mats)
        if dogrulanamayan:
            k["materyal_dogrulanamayan"] = dogrulanamayan
            k["materyal_not"] = (
                "textures could not follow the shape: the source material %s could not be verified "
                "in the archive (it is not a top-level entry, so neither the Workshop nor the game "
                "can be trusted to find it from another item); the target keeps its own textures"
                % ", ".join(dogrulanamayan))
            return
        prim2mat = {}
        for i in range(nA):
            if i not in esle:
                continue
            j = min(i, n_prim - 1)
            if j not in prim2mat:
                prim2mat[j] = int(str(a_mats[min(i, len(a_mats) - 1)]), 16)
        # --- KATLAMA OLCUMU (bkz. baslik "CAPRAZ MATERYAL KATLAMASI"): ayni hedef gruba dusen
        # kaynak gruplarindan yalniz ilkinin materyali yazilir (yukaridaki `if j not in
        # prim2mat`; secim DEGISMEDI, uretilen baytlar birebir), digerleri 2026-09-05'e kadar
        # SESSIZCE dusuyordu (Torso_Edward_Assassin -> Torso_U_Edward_Fire: 4 grup -> 1 yuva,
        # ucgenlerin %98,9'u baska materyalle cizilecekken rapor "textures follow the shape"
        # diyordu). Simdi olculur ve yonlendirme sonucundan BAGIMSIZ kaydedilir (kayip, hedef
        # zaten ayni materyali kullansa da vardir); rapor_satirlari WARNING olarak basar.
        dusen = _materyal_dusenler(esle, a_mats, prim2mat, n_prim, nA)
        k["materyal_yuva"] = int(n_prim)
        k["materyal_tasinan_grup"] = [i for i in range(nA) if i in esle
                                      and i not in {d["grup"] for d in dusen}]
        if dusen:
            k["materyal_dusen"] = dusen
            top = int(k.get("NT") or 0)
            k["materyal_dusen_ucgen_pay"] = (float(sum(d["NT"] for d in dusen)) / top) if top else None
        yeni_ic, degisen = MTY.mesh_ic_yonlendir(k["_is"]["yeni_ic"], prim2mat, rigid=bool(k.get("rigid")))
        if not degisen:
            k["materyal_not"] = "the target already uses the same material"
            return
        k["_is"]["yeni_ic"] = yeni_ic
        k["yeni_bayt"] = len(yeni_ic)
        k["materyal"] = [{"prim": d["prim"], "eski": "0x%X" % d["eski"], "yeni": "0x%X" % d["yeni"]}
                         for d in degisen if d["yer"] == "MeshInstancingData"] or \
                        [{"prim": d["prim"], "eski": "0x%X" % d["eski"], "yeni": "0x%X" % d["yeni"]}
                         for d in degisen]
        k["_materyal_prim2mat"] = prim2mat
        k["_materyal_mesh_icid"] = icid
    except Exception as e:                                      # noqa: BLE001
        k["materyal_not"] = "textures could not follow the shape (%s); the target keeps its own" % e


def _lodsel_isleri(lf, out, hedef, silah, yamalar):
    """Capraz parcalarin hedef LODSelector girisleri: B kayitlarinda yeniden yazilan mesh'i
    gosteren materyal referanslari A'ya cevrilir. Her LODSelector girisi icin TEK is."""
    parcalar = [p for p in out.get("parcalar") or [] if p.get("_materyal_prim2mat")]
    if not parcalar:
        return
    try:
        try:
            from . import cozum as CZ
            from . import materyal_yonlendir as MTY
        except ImportError:
            import cozum as CZ
            import materyal_yonlendir as MTY
        r = CZ.coz(hedef)
    except Exception as e:                                      # noqa: BLE001
        for p in parcalar:
            p["materyal_not"] = "LODSelector of the target could not be resolved (%s); only the mesh carries the new material" % e
        return
    # mesh icid -> lodsel (gid, icid)
    icid2lodsel = {}
    for cp in r.get("parcalar") or []:
        ls = cp.get("lodsel") or {}
        if not ls.get("gid") or not ls.get("icid"):
            continue
        for l in cp.get("lodlar") or []:
            try:
                icid2lodsel[int(str(l["icid"]), 16)] = (int(str(ls["gid"]), 16), int(str(ls["icid"]), 16))
            except (KeyError, TypeError, ValueError):
                pass
    isler = {}
    for p in parcalar:
        key = icid2lodsel.get(int(p["_materyal_mesh_icid"]))
        if key is None:
            p["materyal_not"] = "no LODSelector band points at this mesh; only the mesh carries the new material"
            continue
        isler.setdefault(key, []).append(p)
    for (lg, li), ps in isler.items():
        try:
            gov = FG.ic_dosya(lf, lg, li)
            yeni = gov
            toplam = []
            for p in ps:
                yeni, d = MTY.lodsel_yonlendir(yeni, p["_materyal_mesh_icid"], p["_materyal_prim2mat"])
                toplam.extend(d)
            if not toplam:
                for p in ps:
                    p["materyal_not"] = "the LODSelector has no material record for this mesh (outfit style); the mesh carries the new material"
                continue
            if KM._catisma(C.FORGE, lg):
                for p in ps:
                    p["materyal_not"] = "the target's LODSelector entry is held by the texture tool; only the mesh carries the new material"
                continue
            out["parcalar"].append({
                # KENDI GRUBU: bu is birden cok parcaya hizmet eder ve DUSMESI mesh'leri
                # gecersiz kilmaz (yalnizca dokular hedefin kendi materyalinde kalir), o
                # yuzden mesh gruplariyla ayni tumu-ya-da-hic zincirine BAGLANMAZ.
                "grup_id": "ls%X_%X" % (lg, li),
                "ad": "%s (LODSelector)" % ps[0].get("hedef_ad", ps[0]["ad"]), "kaynak_ad": None,
                "rota": ROTA_MATERYAL, "sebep": None, "NV": 0, "kaynak_NV": None, "NT": 0,
                "kaynak_NT": None, "topoloji": "MATERIAL", "topoloji_sebep": None, "tasima_mm": 0.0,
                "gid": "0x%012X" % lg, "icid": "0x%012X" % li, "rigid": None, "degisen_prim": [],
                "mevcut_yama": yamalar.get(("0x%012X" % lg).upper()),
                "eski_bayt": len(gov), "yeni_bayt": len(yeni), "materyal": [
                    {"prim": d["prim"], "eski": "0x%X" % d["eski"], "yeni": "0x%X" % d["yeni"], "yer": d["yer"]}
                    for d in toplam],
                "_is": {"mod": ROTA_MATERYAL, "gid": lg, "icid": li, "yeni_ic": yeni,
                        "eski_bayt": len(gov), "rapor": {"degisen": len(toplam)}}})
            out["yazilacak"] += 1
        except Exception as e:                                  # noqa: BLE001
            for p in ps:
                p["materyal_not"] = "LODSelector could not be prepared (%s); only the mesh carries the new material" % e


def _uret(k, rota, data, R, G, gid, icid, kw):
    """Yeni ic dosyayi DOGRULAMA asamasinda uretir -- yazicinin KENDI kapilari
    (dejenere ucgen, 65535 vertex tavani, konum bandi, turetilmis tablo oz-denetimi)
    boylece kullaniciya ONAY EKRANINDA gorunur, yazarken degil. Arsive tek bayt
    yazilmaz: uretilen baytlar bellekte durur, kurulumu `uygula` yapar."""
    try:
        if rota == ROTA_AYNI:
            yeni_ic, wr = MZ.yaz(data, R, G, **kw)
        else:
            yeni_ic, wr = MZ.yaz_serbest(data, R, G, kw["primler"],
                                         dejenere=kw.get("dejenere", "reddet"))
    except MZ.YazmaHatasi as e:
        k["rota"] = ROTA_RED
        k["sebep"] = _kullanici_dili(str(e))
        return k
    except Exception as e:                                      # noqa: BLE001
        k["rota"] = ROTA_RED
        k["sebep"] = "the Workshop could not rebuild this part (%s)." % e
        return k
    # UZMAN MODU: yazicinin KENDI actigi kapilarin uyarilari (olcek bandi, olcek yukseltme,
    # dejenere ucgen, bos primitif) parca kaydina tasinir -- rapor sozlugunde kalmasin.
    for _u in (wr or {}).get("uzman_uyarilari") or []:
        k.setdefault("uzman_uyarilari", []).append(_u)
    if bytes(yeni_ic) == bytes(data):
        # Nicemleme adiminin altinda kalan bir oynama AYNI baytlari uretir: yazacak
        # bir sey yok demektir (arsivi bosuna buyutme).
        k["rota"] = ROTA_ATLA
        k["sebep"] = "rebuilt to the same bytes"
        return k
    k["rota"] = rota
    k["eski_bayt"] = len(data)
    k["yeni_bayt"] = len(yeni_ic)
    k["_is"] = {"mod": rota, "gid": gid, "icid": icid, "yeni_ic": yeni_ic,
                "eski_bayt": len(data), "rapor": wr}
    return k


# ------------------------------------------------------------------ UYGULA (yazar)
def _is_grubu(k):
    """Bir isin ait oldugu TUMU-YA-DA-HIC grubu. `plan` birincil + LOD bantlarina ayni
    `grup_id`yi verir; eski planlarda (alan yoksa) her is kendi basina bir gruptur."""
    return str(k.get("grup_id") or ("tek:%s" % k.get("ad")))


def _grup_gerial(kayitlar, progress):
    """Bir grubun YAZILAN isleri geri alinir -- EN YENIDEN ESKIYE (arsivin sonuna eklenen
    blok ancak en ustteyken kirpilabilir; `kur_mesh.geri_al_hepsi` de bu sirayi izler).
    Doner (geri_alinan_sayi, basarisiz_mesajlari)."""
    n, hata = 0, []
    for kid in reversed(kayitlar):
        try:
            g = KM.geri_al(kid)
        except Exception as e:                                  # noqa: BLE001
            g = {"ok": False, "mesaj": str(e)}
        if g.get("ok"):
            n += 1
            _log(progress, "    rolled back: %s" % kid)
        else:
            hata.append("%s (%s)" % (kid, g.get("mesaj") or "no reason given"))
            _log(progress, "    ROLLBACK FAILED: %s - %s" % (kid, g.get("mesaj")))
    return n, hata


@_zincirli
def uygula(p, progress=None, etiket=""):
    """`plan`in URETTIGI baytlari oyuna kurar. Her parca kur_mesh.kur ile kurulur:
    WAL kaydi ILK BAYTTAN ONCE yazilir, yazimdan sonra DISKTEN geri okunup dogrulanir,
    dogrulama dusrse kur_mesh kendi geri almasini yapar.

    TUMU-YA-DA-HIC (2026-09-07): bir parcanin LOD bantlari TEK GRUPTUR. Bir bandi
    yazilamazsa o grubun YAZILAN bantlari `kur_mesh.geri_al` ile geri alinir ve grup
    basarisiz sayilir. Yoksa yalniz yakin bant yazilmis olur, oyun ilk bant sinirinin
    otesinde vanilla sekli cizer ve kullanici "SUCCESS" gorurken hicbir sey degismez
    (Drake kiliclarinda oyun ici olculdu; bkz. baslik "LOD BANTLARI").

    Doner (sozlesme + geriye donuk alanlar):
      {ok, yazilan:[...], yazilan_sayi, geri_alinan, mesaj, gruplar:[{ad, bant, ok, sebep}],
       red:[...], kayit:[id], buyume, atlanan}
    `yazilan` LISTE olarak kalir (sunucu.py ve uc test onu boyle okuyor); sozlesmenin
    saydigi N `yazilan_sayi`dir ve len(yazilan) ile ayni deger."""
    sonuc = {"ok": True, "yazilan": [], "yazilan_sayi": 0, "geri_alinan": 0, "mesaj": "",
             "gruplar": [], "red": list(p.get("red") or []), "kayit": [], "buyume": 0,
             "atlanan": p.get("atlanan", 0),
             # UZMAN MODU: plandaki uyarilar SONUCA da tasinir -- kullanici "yazildi"
             # ekranindayken hangi kapinin acildigini hala gorebilsin.
             "uzman": bool(p.get("uzman")),
             "uzman_uyarilari": list(p.get("uzman_uyarilari") or [])}
    gorulen_gid = set()
    isler = [k for k in p.get("parcalar") or [] if k.get("_is")]
    n = len(isler)
    # Gruplari plan sirasiyla kur (birincil once, bantlari hemen ardindan).
    sira, gruplar = [], {}
    for k in isler:
        gk = _is_grubu(k)
        if gk not in gruplar:
            gruplar[gk] = []
            sira.append(gk)
        gruplar[gk].append(k)
    i = 0
    for gk in sira:
        uyeler = gruplar[gk]
        g_kayit, g_yazilan, g_gid = [], [], set()
        sebep = None
        for k in uyeler:
            i += 1
            w = k["_is"]
            yeni_ic, wr = w["yeni_ic"], w["rapor"]
            _log(progress, "  mesh %d of %d: %s (%s)"
                 % (i, n, k["ad"], "moved vertices, same shape" if w["mod"] == ROTA_AYNI
                    else "hidden - not in your file" if w["mod"] == ROTA_GIZLE
                    else "material reference -> source material" if w["mod"] == ROTA_MATERYAL
                    else "rebuilt (topology changed)"))
            # Ayni arsiv girisinde (gid) ikinci bir mesh varsa kur_mesh "zaten yamali"
            # der; bu bilincli bir ust uste yazmadir (zincir kaydi tutulur, geri alma
            # en yeniden eskiye yurur).
            ustune = (w["gid"] in gorulen_gid) or (w["gid"] in g_gid) or bool(k.get("mevcut_yama"))
            kr = KM.kur(C.FORGE, w["gid"], w["icid"], yeni_ic,
                        etiket=("%s %s" % (etiket, k["ad"])).strip(), ustune=ustune)
            if not kr.get("ok"):
                sebep = kr.get("mesaj") or "the install refused."
                sonuc["red"].append({"ad": k["ad"], "sebep": sebep})
                _log(progress, "    REFUSED: %s" % sebep)
                break
            g_gid.add(w["gid"])
            g_kayit.append(kr.get("kayit_id"))
            g_yazilan.append({
                "ad": k["ad"], "gid": k["gid"], "icid": k["icid"], "rota": w["mod"],
                "eski_bayt": w["eski_bayt"], "yeni_bayt": len(yeni_ic),
                "NV": int(wr.get("NV") or 0), "NT": int(wr.get("NT") or 0),
                "kayit_id": kr.get("kayit_id"), "buyume": int(kr.get("buyume") or 0)})
            _log(progress, "    written: %d B -> %d B (%s)"
                 % (w["eski_bayt"], len(yeni_ic), kr.get("kayit_id")))
        gad = uyeler[0].get("ad_taban") or uyeler[0].get("ad")
        if sebep is None:
            gorulen_gid |= g_gid
            sonuc["kayit"].extend(g_kayit)
            sonuc["yazilan"].extend(g_yazilan)
            sonuc["buyume"] += sum(int(w.get("buyume") or 0) for w in g_yazilan)
            sonuc["gruplar"].append({"ad": gad, "bant": list(g_kayit), "ok": True, "sebep": None,
                                     "parcalar": [w["ad"] for w in g_yazilan], "geri_alinan": 0})
            continue
        # YARIM GRUP BIRAKILMAZ: yazilanlari geri al (en yeniden eskiye).
        sonuc["ok"] = False
        n_geri, hata = (0, [])
        if g_kayit:
            _log(progress, "    rolling back %d already-written band(s) of %s ..."
                 % (len(g_kayit), gad))
            n_geri, hata = _grup_gerial(g_kayit, progress)
        sonuc["geri_alinan"] += n_geri
        if hata:
            # Geri alma da dustuyse SUSMA: kullanici arsivin karisik oldugunu bilmeli.
            sonuc["red"].append({"ad": gad, "sebep":
                                 "%d band(s) of this part could not be rolled back after the "
                                 "failed write (%s). Use Revert to put the archive back."
                                 % (len(hata), "; ".join(hata))})
        sonuc["gruplar"].append({"ad": gad, "bant": [], "ok": False, "sebep": sebep,
                                 "parcalar": [w["ad"] for w in g_yazilan],
                                 "geri_alinan": n_geri, "gerial_hatasi": hata})
    sonuc["yazilan_sayi"] = len(sonuc["yazilan"])
    ok_g = sum(1 for g in sonuc["gruplar"] if g["ok"])
    dusen = [g for g in sonuc["gruplar"] if not g["ok"]]
    if not dusen:
        sonuc["mesaj"] = "%d of %d part(s) written." % (ok_g, len(sonuc["gruplar"]))
    else:
        ilk = dusen[0].get("sebep") or "a write refused."
        sonuc["mesaj"] = (
            "%d of %d part(s) written; %d %s rolled back so that no part is left with only "
            "some of its LOD bands written%s (%s)"
            % (ok_g, len(sonuc["gruplar"]), len(dusen),
               "was" if len(dusen) == 1 else "were",
               "" if len(dusen) == 1 else " (first reason)", ilk))
    return sonuc


# ------------------------------------------------------------------ ONAY METNI
def _materyal_dusen_metni(k):
    """CAPRAZ MATERYAL KATLAMASI WARNING satiri (Ingilizce, bkz. baslik): kac kaynak materyal
    grubu tasinamadi, hangileri, parcanin ucgenlerinin yuzde kaci ve hangi materyalle
    cizilecekleri. Pay olculmemisse '?' basilir, asla 0 degil."""
    dus = k.get("materyal_dusen") or []
    n_kaynak = len(dus) + len(k.get("materyal_tasinan_grup") or [])
    pay = k.get("materyal_dusen_ucgen_pay")
    gruplar = ", ".join(str(d["grup"]) for d in dus)
    mats = ", ".join(sorted({d["materyal"] for d in dus}))
    kul = ", ".join(sorted({d["kullanilan"] for d in dus}))
    yuva = k.get("materyal_yuva")
    return ("%d of %d source material group(s) cannot be carried - the game mesh has %s material "
            "slot(s) for %d source group(s) - so source group%s %s (%s of this part's triangles; "
            "material%s %s) will be drawn with material %s instead of %s own"
            % (len(dus), n_kaynak, ("%d" % yuva) if isinstance(yuva, int) else "?", n_kaynak,
               "" if len(dus) == 1 else "s", gruplar,
               ("%.1f%%" % (100.0 * pay)) if isinstance(pay, float) else "an unmeasured share",
               "" if len(set(d["materyal"] for d in dus)) == 1 else "s", mats, kul,
               "its" if len(dus) == 1 else "their"))


def rapor_satirlari(p):
    """Onay ekranina giden duz Ingilizce MESH satirlari."""
    L = []
    if not p or p.get("durum") == "yok":
        L.append("MESH: " + ((p or {}).get("sebep") or "nothing to import."))
        return L
    if p.get("durum") == "hata":
        L.append("MESH: " + (p.get("sebep") or "could not be read."))
        return L
    oz = p.get("ozet") or {}
    cz = p.get("capraz")
    if cz:
        L.append("CROSS-IMPORT  %s  ->  %s%s" % (cz.get("kaynak"), cz.get("hedef"),
                                                 "   (parts you chose)" if cz.get("elle") else ""))
        L.append("  The shape and its textures move; the target keeps its own stats, sounds and "
                 "animations. %d part(s) matched." % len(cz.get("eslesen") or {}))
        for a in cz.get("yersiz") or []:
            L.append("  NO PLACE  %s - the target has no part of this kind; not written" % a)
    L.append("MESH (%s)" % os.path.basename(p.get("dosya") or ""))
    eksik = p.get("eksik") or []
    yutulan = p.get("yutulan") or []
    L.append("  %d part(s) matched, %d unchanged in shape, %d changed%s%s."
             % (oz.get("eslesen", 0), oz.get("identical", 0), oz.get("changed", 0),
                # capraz: bu parcalar kullanicinin dosyasindan eksik DEGIL, hedefe ozgu
                ((", %d target part(s) with no source part" if cz else ", %d missing from your file")
                 % len(eksik)) if eksik else "",
                (", %d joined into another part" % len(yutulan)) if yutulan else ""))
    for n_ in p.get("notlar") or []:
        L.append("  NOTE   %s" % n_)
    # UZMAN MODU: acilan her politika kapisi burada GORUNUR. Satirlar NOTE'un ustunde
    # degil altinda durur ama kendi etiketleriyle ayrisir; sessiz gecen kapi yoktur.
    for e in p.get("uzman_uyarilari") or []:
        L.append("  EXPERT %s%s" % (("%s - " % e["ad"]) if e.get("ad") else "", e.get("uyari")))
    for k in p.get("parcalar") or []:
        if k["rota"] == ROTA_GIZLE:
            _pay = k.get("paylasan") or 0
            L.append("  HIDE   %s - %s; it will be hidden in the game (%d B, "
                     "same size, Revert brings it back)%s"
                     % (k["ad"],
                        "the source item has no part of this kind" if k.get("hedef_yalniz")
                        else "not in your file", k.get("yeni_bayt") or 0,
                        ("  --  SHARED: %d other item(s) draw this same mesh and lose it too"
                         % _pay) if _pay else ""))
        elif k["rota"] == ROTA_AYNI:
            L.append("  WRITE  %s - same shape, vertices moved %s; the file keeps its "
                     "size (%d B), so the archive does not grow"
                     % (k["ad"], ("up to %.2f mm" % k["tasima_mm"]) if k.get("tasima_mm") is not None
                        else "(not measured)", k.get("yeni_bayt") or 0))
            if k.get("not"):
                # 2026-09-05'e kadar `ayni` rotasinin notu HIC BASILMIYORDU (serbest rotada
                # basiliyor): Blender normalizasyonu ve bayat-export uyarisi kullaniciya
                # ulasmiyordu.
                L.append("         %s" % k["not"])
            if k.get("lod_kapsam") is not None and not k.get("bant_ek"):
                # AYNI-OGE silah ithalatinda birincil cogu zaman `ayni` rotasindadir; LOD
                # kapsami satiri 2026-09-07'ye kadar yalniz `serbest` dalinda basiliyordu,
                # yani tam da bu yolda gorunmuyordu.
                L.append("         %s" % _lod_kapsam_metni(k["lod_kapsam"]))
        elif k["rota"] == ROTA_SERBEST:
            dv = (k["NV"] or 0) - (k["kaynak_NV"] or 0)
            dt = (k["NT"] or 0) - (k["kaynak_NT"] or 0)
            if k.get("bant_ek") and k.get("ayni_oge_bant"):
                # AYNI-OGE ek bandi: kaynak da hedef de ayni ogenin ayni parcasi, "A -> B" yaniltir
                bas = "%s [LOD band %d, drawn to %s]" % (
                    k.get("ad_taban") or k["ad"], k["bant"], _m_metni(k.get("bant_mesafe")))
            elif k.get("bant_ek"):
                # LOD BANTLARI: birincilin altindaki ek ana bant (ayni kaynak sekli, baska yuva)
                bas = "%s  ->  %s [LOD band %d, drawn to %s]" % (
                    k.get("ad_taban") or k["ad"], k["hedef_ad"], k["bant"], _m_metni(k.get("bant_mesafe")))
            else:
                bas = (k["ad"] + "  ->  " + k["hedef_ad"]) if k.get("capraz") else k["ad"]
            L.append("  WRITE  %s - %s vertices (%d -> %d), %s triangles (%d -> %d), %d B -> %d B"
                     % (bas,
                        ("+%d" % dv) if dv > 0 else ("%d" % dv) if dv < 0 else "same",
                        k["kaynak_NV"] or 0, k["NV"] or 0,
                        ("+%d" % dt) if dt > 0 else ("%d" % dt) if dt < 0 else "same",
                        k["kaynak_NT"] or 0, k["NT"] or 0,
                        k.get("eski_bayt") or 0, k.get("yeni_bayt") or 0))
            if not k.get("capraz"):
                # Sayilar (NV/NT/bayt) duzenlemeyi SOYLEMEZ: 5 cm tasima ile 2x buyutme ayni
                # sayilari verir. Olculen/tahmin edilen hareket-olcek-donme buraya duser.
                L.append("         %s" % _sekil_olcumu(k))
            elif k.get("esleme_sebebi"):
                # Capraz: adlar tek basina eslemenin NEDEN boyle kuruldugunu soylemez (Pistol_11
                # -> Pistol_03'te kilif<->el takasi iki "WRITE ... textures follow the shape"
                # satiriyla onaylaniyordu, 2026-09-05). Dayanak buraya duser.
                L.append("         %s" % k["esleme_sebebi"])
            if k.get("not"):
                L.append("         %s" % k["not"])
            dus = k.get("materyal_dusen") or []
            if k.get("materyal") and dus:
                # CAPRAZ MATERYAL KATLAMASI: onay YALNIZ materyali tasinan kaynak gruplari icin
                # verilir; 2026-09-05'e kadar bu satir katlanan parcada da kosulsuz "textures
                # follow the shape ... on 1 group(s)" diyordu (len = degisen HEDEF prim sayisi).
                tas = k.get("materyal_tasinan_grup") or []
                L.append("         textures follow the shape for source group%s %s only: material "
                         "%s -> %s on %d target group(s)"
                         % ("" if len(tas) == 1 else "s",
                            ", ".join(str(i) for i in tas) if tas else "?",
                            k["materyal"][0]["eski"], k["materyal"][0]["yeni"], len(k["materyal"])))
            elif k.get("materyal"):
                L.append("         textures follow the shape: material %s -> %s on %d group(s)"
                         % (k["materyal"][0]["eski"], k["materyal"][0]["yeni"], len(k["materyal"])))
            elif k.get("materyal_not"):
                L.append("         %s" % k["materyal_not"])
            if dus:
                L.append("         WARNING: %s" % _materyal_dusen_metni(k))
            if k.get("lod_kapsam") is not None and not k.get("bant_ek"):
                # LOD BANTLARI: hangi bantlar yaziliyor, orijinal sekil hangi mesafeden gorunur
                L.append("         %s" % _lod_kapsam_metni(k["lod_kapsam"]))
        elif k["rota"] == ROTA_MATERYAL:
            L.append("  WRITE  %s - %d material reference(s) point at the source material, so the "
                     "game picks the source textures for this shape (%d B -> %d B)"
                     % (k["ad"], len(k.get("materyal") or []), k.get("eski_bayt") or 0,
                        k.get("yeni_bayt") or 0))
        elif k["rota"] == ROTA_ATLA:
            if k.get("not"):
                # Blender normalizasyonu: sayilar degisti ama sekil degil -- soyle, yazma
                L.append("  SKIP   %s - %s" % (k["ad"], k["not"]))
            continue
    # "zaten gizli" parcalari ACIKCA say: kullanici kutuyu isaretleyip "Nothing" gorunce
    # neden bir sey olmadigini bilsin (K1'in ikinci yarisi).
    _gizli = [k for k in (p.get("parcalar") or [])
              if k.get("rota") == ROTA_ATLA and str(k.get("sebep") or "").startswith("already hidden")]
    if _gizli:
        L.append("  HIDDEN %d part(s) are already hidden from an earlier import, so there is "
                 "nothing to do for them: %s. Revert brings them back."
                 % (len(_gizli), ", ".join(k["ad"] for k in _gizli[:6])
                    + (" ..." if len(_gizli) > 6 else "")))
    if p.get("atlanan"):
        L.append("  SKIP   %d part(s) come out of the game unchanged - they are not written."
                 % p["atlanan"])
    kalan = [e for e in eksik if not e.get("gizle")]
    if kalan and cz:
        L.append("  TARGET ONLY %d part(s) of the target have no source part: %s. They stay as "
                 "they are. Tick \"Hide parts missing from my file\" to remove them."
                 % (len(kalan), ", ".join(e["ad"] for e in kalan[:6])
                    + (" ..." if len(kalan) > 6 else "")))
    elif kalan:
        L.append("  MISSING %d part(s) are in the export but not in your file: %s. They stay "
                 "in the game as they are. Tick \"Hide parts missing from my file\" to remove "
                 "them from the game."
                 % (len(kalan), ", ".join(e["ad"] for e in kalan[:6])
                    + (" ..." if len(kalan) > 6 else "")))
    gov = p.get("govde") or []
    if gov and cz:
        # GOVDE KAPISI (bkz. baslik): karakterin derisi capraz modda ASLA gizlenmez; paylasim
        # sayisi indeksten olculmustur (None ise cumle kurulmaz, tahmin basilmaz).
        pay = [g.get("paylasan") for g in gov if isinstance(g.get("paylasan"), int)]
        L.append("  BODY   %d part(s) of the target are the character's own skin (body, face), not "
                 "clothing: %s. A cross-import never hides them, even with the box ticked: the "
                 "source item has no skin part of its own, so nothing is missing here%s. They stay "
                 "as they are."
                 % (len(gov), ", ".join(g["ad"] for g in gov[:6]) + (" ..." if len(gov) > 6 else ""),
                    (", and the same mesh%s drawn by up to %d other item(s) in the game, which "
                     "would go blank too" % (" is" if len(gov) == 1 else "es are", max(pay)))
                    if pay and max(pay) > 0 else ""))
    for x in p.get("red") or []:
        L.append("  REFUSED %s" % x["ad"])
        L.append("          %s" % x["sebep"])
    yama = [k for k in (p.get("parcalar") or []) if k.get("mevcut_yama") and k["rota"] in
            (ROTA_AYNI, ROTA_SERBEST)]
    if yama:
        L.append("  NOTE   %d part(s) already carry a mesh patch; it will be replaced (the old "
                 "one stays in the undo history)." % len(yama))
    return L
