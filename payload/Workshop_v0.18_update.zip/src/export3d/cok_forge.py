# -*- coding: utf-8 -*-
"""cok_forge -- COK-FORGE OKUMA GORUNUMU (salt okuma; hicbir dosya 'wb'/'r+b' acilmaz).

NEDEN: bir mesh `DataPC_shared_00.forge`'da dururken materyali / TextureSet'i / TextureMap'i
`DataPC_boot.forge`'da (ya da bir *_patch_01 golgesinde) olabilir. `outfit_core._forge()` TEK
forge dondurdugu icin doku zinciri "material not in forge" ile kopuyor ve GLB dokusuz cikiyordu.
OLCULDU (2026-09-12, 71 kamara propu): tek forge -> 58 dokusuz; bu gorunumle -> 0 dokusuz.

NE: LeanForge ile AYNI arayuzu (by_id / read_raw / f / entries / count / path / close) veren,
oncelik sirali bir birlesik gorunum. Her kimlik SAHIBINE yonlendirilir; `by_id[k]` ile bakilan
son kimligin sahibi `f.seek/read` icin hatirlanir (mevcut okuyucular `by_id[k]` -> `f.seek(off)`
kalibini kullanir; ofset yalniz sahibin dosyasinda anlamlidir).

GOLGE KURALI (oyunun yama zinciri): ayni kimlik hem `X.forge` hem `X_patch_01.forge`'da varsa
oyun UST halkayi (patch) okur. Bu yuzden zincir 'yuksek yama once' kurulur ve `by_id` en yuksek
halkanin kaydini verir. TEK ISTISNA `sabit`: cagiranin ACIKCA sectigi giris (Explorer'da
kullanicinin tikladigi kopya) kendi arsivine bagli kalir -- `tani` onu zaten "golgede" diye uyardi.

Zincir (`zincir_kur`): secilen arsivin kendi yama grubu (patch_NN > ... > taban) ->
DataPC_boot grubu -> DataPC_shared_00 grubu (-> `ek` gruplar). Yalniz diskte VAR OLAN dosyalar;
`_dx12` / `_floor` / `_nav` / `_sound` / `_gi` arsivleri AYRI gruptur ve zincire GIRMEZ.

YAZICILAR BU GORUNUMU HIC GORMEZ: doku_enjekte2 ve kur_mesh kendi taniticilarini acar.
(kur_mesh 2026-10-12'den beri AYNI zincir kuraliyla yazma hedefini de yonlendirir:
`kur_mesh.etkin_arsiv`; okuma ve yazma boylece ayni halkaya bakar.)

`okuma_gorunumu(C, forge)`: outfit_core'un (`C`) okuma gorunumunu GECICI olarak `forge`un
kendi yama grubuna cevirir (patch kazanir -- oyunun gordugu kopya). Hide Parts ve Explorer
geri koyma bununla orijinali OKUR, kur_mesh ayni halkaya YAZAR.
"""
import contextlib
import os

try:
    from yalin_forge import LeanForge
except ImportError:                                             # paket duzeni: src/ altinda
    import sys as _sys
    _p = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _p not in _sys.path:
        _sys.path.insert(0, _p)
    from yalin_forge import LeanForge                           # noqa: E402

__all__ = ["CokForge", "zincir_kur", "zincir_grubu", "okuma_gorunumu", "ORTAK_GRUPLAR", "SURUM"]

SURUM = "1.0"

# Her dunyanin bastigi ortak arsivler: materyal/doku/TextureSet cogunlukla boot'ta, prop mesh'leri
# shared_00'da (olculdu: 71 kamara propunun 63'u shared_00, 9'u boot/boot_patch_01).
ORTAK_GRUPLAR = ("DataPC_boot", "DataPC_shared_00")


def zincir_grubu(ad):
    """'DataPC_boot_patch_01.forge' -> ('datapc_boot', 1) · 'DataPC_boot.forge' -> ('datapc_boot', 0).
    (explorer_core._zincir_grubu ile AYNI kural; burada kopyasi var ki bu modul explorer_core'a
    bagimli olmasin -- explorer_core zaten export3d'yi iceri alir.)"""
    t = ad[:-6] if ad.lower().endswith(".forge") else ad
    n = 0
    while True:
        i = t.lower().rfind("_patch_")
        if i < 0:
            break
        kuyruk = t[i + 7:]
        if not kuyruk.isdigit():
            break
        n = max(n, int(kuyruk))
        t = t[:i]
    return t.lower(), n


def zincir_kur(birincil, ortak=ORTAK_GRUPLAR, ek=()):
    """Birincil arsiv yolu -> oncelik sirali TAM yol listesi (ilk eleman = birincil arsivin grubu,
    en yuksek yama once). Yalniz `birincil`in klasorundeki, diskte VAR OLAN dosyalar.

    Sira: birincilin grubu (patch_NN ... taban) -> `ortak` gruplari -> `ek` gruplari.
    Birincil bir yama halkasi degilse ve grubunda yama varsa, yama ONDE gelir (golge kurali);
    birincil girisin kendisini korumak `CokForge(..., sabit=...)`in isidir."""
    birincil = os.path.abspath(birincil)
    kok = os.path.dirname(birincil)
    try:
        adlar = [a for a in os.listdir(kok) if a.lower().endswith(".forge")]
    except OSError:
        adlar = []
    gruplar = {}
    for a in adlar:
        t, n = zincir_grubu(a)
        gruplar.setdefault(t, []).append((n, a))
    taban_b, _n = zincir_grubu(os.path.basename(birincil))
    sira, gorulen = [], set()
    for taban in [taban_b] + [zincir_grubu(x)[0] for x in ortak] + [zincir_grubu(x)[0] for x in ek]:
        for _n, a in sorted(gruplar.get(taban, []), reverse=True):     # yuksek yama once
            p = os.path.join(kok, a)
            nc = os.path.normcase(p)
            if nc in gorulen or not os.path.isfile(p):
                continue
            gorulen.add(nc)
            sira.append(p)
    nc_b = os.path.normcase(birincil)
    if nc_b not in gorulen:                                     # klasor listelenemediyse bile
        sira.insert(0, birincil)
    return sira


@contextlib.contextmanager
def okuma_gorunumu(C, forge=None, ortak=(), sabit=None):
    """outfit_core (`C`) okuma gorunumunu GECICI olarak `forge`un yama zincirine cevirir.

    Zincir = yalniz `forge`un kendi grubu (ortak=() -> DataPC_boot icin [boot_patch_01, boot]);
    `ortak` verilirse zincir_kur'un ortak gruplari da eklenir. UST halka kazanir -- oyunun
    okudugu kopya. DOKUNMAZ: zincir tek halkaysa, `forge` yoksa ya da baska bir zincir zaten
    etkinse (ic ice cagri; mesh_glb'nin kendi baglami gibi) -> None verir. Cikista tek forge'a
    donulur ve onbellek bosaltilir (forge_zinciri_ayarla(None)). YALNIZ OKUMA."""
    forge = os.path.abspath(forge or getattr(C, "FORGE", None) or "")
    if not forge or not os.path.isfile(forge):
        yield None
        return
    if getattr(C, "forge_zinciri", lambda: None)() is not None:
        yield None
        return
    yollar = zincir_kur(forge, ortak=ortak)
    if len(yollar) <= 1:
        yield None
        return
    C.forge_zinciri_ayarla(yollar, sabit=sabit, birincil=forge)
    try:
        yield yollar
    finally:
        C.forge_zinciri_ayarla(None)


class _ByIdGorunumu(dict):
    """LeanForge.by_id gibi bir dict; `[k]` ve `get(k)` son bakilan kimligin SAHIBINI isaretler
    (f.seek/read yonlendirmesi icin). `in` / `items()` / `keys()` sahibi degistirmez."""
    __slots__ = ("_cf",)

    def __init__(self, cf):
        dict.__init__(self)
        self._cf = cf

    def __getitem__(self, k):
        v = dict.__getitem__(self, k)
        self._cf._son = self._cf.sahip[k]
        return v

    def get(self, k, varsayilan=None):
        if dict.__contains__(self, k):
            return self[k]
        return varsayilan


class _TaniticiMux(object):
    """`lf.f` yerine gecer: son bakilan kimligin sahibinin dosyasina yonlendirir."""
    __slots__ = ("_cf",)

    def __init__(self, cf):
        self._cf = cf

    def _hedef(self):
        lf = self._cf._son or self._cf.lfs[0]
        return lf

    def seek(self, off, whence=0):
        return self._hedef().f.seek(off, whence)

    def read(self, n=-1):
        lf = self._hedef()
        b = lf.f.read(n)
        self._cf._say(lf, len(b))
        return b

    def tell(self):
        return self._hedef().f.tell()

    @property
    def closed(self):
        return all(getattr(lf.f, "closed", True) for lf in self._cf.lfs)

    @property
    def name(self):
        return self._hedef().f.name


class CokForge(object):
    """Oncelik sirali birlesik okuma gorunumu (LeanForge arayuzu).

    yollar     : tam yollar, ILK ELEMAN EN YUKSEK ONCELIK (ayni kimlikte o kazanir)
    sabit      : {gid: yol} -- bu kimlikler golge kuralina bakilmaksizin verilen arsive baglanir
                 (yol zincirde olmali ve kimligi tasimali; degilse sessizce yoksayilmaz, `sabit_yok`a yazilir)
    istatistik : dict -- verilirse okuma sayaclari BURAYA yazilir (kapatildiktan sonra da okunabilsin)
    birincil   : kullanicinin sectigi arsiv (`path` bunu gosterir; zincirde yamasi ondan ONCE
                 gelebilir). Verilmezse yollar[0].
    `birincil` acilamazsa (ya da hic halka acilamazsa) istisna yukselir; oteki halkalar acilamazsa
    atlanir (`atlanan`). OLCULDU 2026-10-12: kum havuzunda DataPC_boot_patch_01.forge 55 baytlik YER
    TUTUCUDUR ve zincirin ILK halkasidir; eski kural ("ilk halka acilamazsa yukselir") Hide Parts'i
    "scimitar degil" ile dusuruyordu (test_parca_gizle K1c)."""

    def __init__(self, yollar, sabit=None, istatistik=None, birincil=None):
        self.yollar = [os.path.abspath(p) for p in yollar]
        if not self.yollar:
            raise ValueError("CokForge needs at least one archive")
        self.birincil = os.path.abspath(birincil or self.yollar[0])
        self.lfs = []
        self.atlanan = []                      # [(yol, hata)] acilamayan ikincil halkalar
        self.sahip = {}                        # fid -> LeanForge
        self.by_id = _ByIdGorunumu(self)
        self._son = None
        self.f = _TaniticiMux(self)
        self.istatistik = istatistik if istatistik is not None else {}
        self.istatistik.setdefault("okuma", {})
        self.istatistik["halkalar"] = []
        acilan = []
        nc_birincil = os.path.normcase(self.birincil)
        for p in self.yollar:
            try:
                lf = LeanForge(p)                               # 'rb'
            except Exception as e:                              # noqa: BLE001
                if os.path.normcase(p) == nc_birincil:
                    for q in acilan:
                        q.close()
                    raise
                self.atlanan.append((p, str(e)))
                continue
            acilan.append(lf)
        if not acilan:
            raise ValueError("none of the archives in the chain could be opened: %s"
                             % ", ".join(os.path.basename(p) for p in self.yollar))
        self.lfs = acilan
        # dusuk oncelikliden yukseke: yuksek oncelikli USTUNE yazar (golge kurali)
        for lf in reversed(self.lfs):
            for k, v in lf.by_id.items():
                dict.__setitem__(self.by_id, k, v)
                self.sahip[k] = lf
        self.sabit_yok = []
        for gid, yol in (sabit or {}).items():
            nc = os.path.normcase(os.path.abspath(yol))
            lf = next((x for x in self.lfs if os.path.normcase(x.path) == nc), None)
            if lf is None or gid not in lf.by_id:
                self.sabit_yok.append(gid)
                continue
            dict.__setitem__(self.by_id, gid, lf.by_id[gid])
            self.sahip[gid] = lf
        nc_b = os.path.normcase(self.birincil)
        self.path = next((x.path for x in self.lfs if os.path.normcase(x.path) == nc_b), self.lfs[0].path)
        self.count = len(self.by_id)
        self._entries = None
        self.istatistik["halkalar"] = [os.path.basename(x.path) for x in self.lfs]
        self.istatistik["atlanan_halka"] = [os.path.basename(p) for p, _e in self.atlanan]

    # ---- LeanForge arayuzu
    def read_raw(self, fid):
        lf = self.sahip[fid]                                    # KeyError: LeanForge ile ayni
        self._son = lf
        b = lf.read_raw(fid)
        self._say(lf, len(b), giris=True)
        return b

    @property
    def entries(self):
        """(off, id, len, ext) -- kimlik basina SAHIBININ satiri (golge kurali uygulanmis)."""
        if self._entries is None:
            self._entries = [(v[0], k, v[1], v[2]) for k, v in self.by_id.items()]
        return self._entries

    def textures(self):
        return [(fid, off, ln) for off, fid, ln, ext in self.entries if ext == 0xA2B7E917]

    def close(self):
        for lf in self.lfs:
            try:
                lf.close()
            except Exception:                                   # noqa: BLE001
                pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
        return False

    # ---- ek bilgi
    def kimin(self, fid):
        """kimligin sahibi (dosya adi) ya da None."""
        lf = self.sahip.get(fid)
        return os.path.basename(lf.path) if lf is not None else None

    def halkalar(self):
        return [os.path.basename(x.path) for x in self.lfs]

    def _say(self, lf, n, giris=False):
        ad = os.path.basename(lf.path)
        s = self.istatistik["okuma"].setdefault(ad, {"giris": 0, "bayt": 0})
        if giris:
            s["giris"] += 1
        s["bayt"] += int(n)
