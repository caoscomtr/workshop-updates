# -*- coding: utf-8 -*-
"""cozum — VARLIK COZUMLEME: "bu seyin mesh'i hangisi?" sorusunu OYUNUN KENDI
baglama zinciriyle yanitlar; ad benzerligi / "en buyuk govde = LOD0" tahminiyle DEGIL.

NEDEN VAR
---------
Eski indeksler (silah_indeks.json, onizleme3d_indeks.json) LOD sirasini
"ansiklopedideki en buyuk ic dosya = LOD0" kuraliyla kuruyordu. Bu kural
OLCULEREK CURUTULDU: Captain Drake's Swords'te en buyuk govdeler
(0x20AEBE2ED86 / 0x20AEBE2EC47) yamalandiginda OYUNDA HICBIR SEY DEGISMEDI;
gorunen degisiklik ancak 0x2308049FC2B / 0x2330AD5F489 yamalanunca geldi.
Sebep bu modulle olculdu: bu ikisi zincirin LOD0'i DEGIL, LOD1'idir ve oyun
ucuncu-sahis kamera mesafesinde LOD0'i hic cizmez.

ZINCIR (bayt-dogrulandi, bkz. §OLCUM)
-------------------------------------
    BuildTable  --[00][u64]-->  LODSelector  -->  5 BANT  -->  Mesh (+Material)
    EntityGroup --------------> LODSelector

LODSelector govdesi (0x51DC6B80): 12 B'lik nesne basliklariyla ([u16 idx]
[u16 F8FB][u32 0][u32 tipHash]) dizilmis 10 nesne = 5 BANT x 2 kayit:

  A kaydi  tipHash 0xA360319A  35 B govde   -- BANDIN VEKIL/GOLGE mesh'i
      [u8 bayrak][u64 mesh][f32 mesafe][f32 -1][f32 0][f32 1][u32 0][u16][u32]
      bayrak 1 = ref var, 3 = bos bant.
  B kaydi  tipHash 0x38B0D64C  >=40 B govde -- BANDIN ANA (cizilen) mesh'i
      [u8 bayrak][u64 mesh][u16][f32 mesafe][u32 1][u8 1][u64 MATERYAL]
      [u32 1][f32 yaricap][u32 0]
      27 B'lik kisa kayit = BOS bant (mesh yok).

`mesafe` bandin UST sinirini verir ve bantlar artan sirada gelir; bant 0 = en
yakin = zincirin LOD0'i. Kalibrasyon (adi ansiklopedide _LOD0.._LOD4 olarak
TAM cozulmus 2 hedefte, birebir tutuyor):

    Boots_U_Edward_Drake   A: LOD2 LOD2 LOD2 LOD3 LOD4   B: LOD0 LOD1 - - -
    Glove_U_Edward_Drake   A: LOD2 LOD2 LOD2 LOD3 LOD4   B: LOD0 LOD1 - - -
    Musket_..._Flintlock   A: LOD2 LOD2 LOD2 LOD3  -     B: LOD0 LOD1 - - -

OYUN BANDI
----------
Hangi bandin ekranda oldugunu belirleyen tek OLCUM'umuz Drake kiliclaridir:
bantlar 1/4/8/32/64 m ve oyun bant 1'i cizdi. Buradan tek parametreli bir
model: oyun_bandi = mesafesi KAMERA_M'den (2,5 m) buyuk-esit ILK dolu bant.
Boots (4/16/24/32/48) icin bant 0, Drake kilici (1/4/8/32/64) icin bant 1
verir -- ikisi de gozlemle uyumlu. TEK olcumden turetilmis MODELDIR; bir
hedefin gorunur bandini garanti ETMEZ. Guvenli kural degismez:

    !! YAZICI TUM BANTLARI YAMALAMALIDIR, yoksa model mesafede vanilla'ya doner.

OLCUM (hepsi 'rb', oyuna tek bayt yazilmaz)
-------------------------------------------
  * LODSelector semasi: 3.157 boot LODSelector'unun tamami cozuldu.
  * Silah giris noktasi: OBD_Weapons_BuildTable (0x208126FA475) agaci
    ozyinelemeli yuruldu -> 139 BuildTable, [00][u64] slotundan 99 LODSelector.
  * Kiyafet giris noktasi: onizleme3d indeksindeki EG_id (hideout gardirop
    EntityGroup'u) -> govdesindeki LODSelector referanslari.

API
---
    coz(anahtar)            -> tek hedefin cozumu (asagidaki sozluk)
    coz_hepsi(tur=None)     -> {anahtar: cozum}
    lod_indeks()            -> LodIndeks (onbellekli, forge imzasiyla gecersizlenir)
    lodsel_coz(govde)       -> ham bant listesi

`coz` ciktisi:
    {anahtar, tur, giris_noktasi, parcalar[], cozulmeyen[], ozet{}}
    parcalar[i] = {
      ad, kaynak,                # kaynak = LODSelector'e HANGI yoldan varildi
      lodsel {gid,icid,ad},
      bantlar [{seviye, mesafe, ana{gid,icid,ad,boyut}|None, materyal, golge{...}|None}],
      lodlar  [{seviye, rol, gid, icid, ad, materyal}],   # LODSelector SIRASI korunur
      yazilacak [{gid,icid}],    # yazicinin yamalamasi GEREKEN tum mesh'ler
      lod_sayisi, oyun_bandi, oyun_lod0 {gid,icid}|None, materyaller[]
    }
"""
from __future__ import annotations

import collections
import json
import os
import re
import struct
import sys
import time

BURA = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(BURA)
KOK = os.path.dirname(SRC)

# --- tip hash'leri (crc32(sinif adi); ansiklopedi `siniflar` tablosuyla uyumlu)
T_LODSEL = 0x51DC6B80
T_MESH = 0x415D9568
T_BUILDTABLE = 0x22ECBE63
T_ENTITYGROUP = 0x3F742D26
T_MATERIAL = 0x85C817C3

# --- LODSelector ic nesne tipleri (bu modulde olculdu)
T_BANT_GOLGE = 0xA360319A      # A: bandin vekil/golge mesh'i
T_BANT_ANA = 0x38B0D64C        # B: bandin ana mesh'i + materyali

BANT_SAYISI = 5
SILAH_BT_KOK = 0x208126FA475   # OBD_Weapons_BuildTable
KAMERA_M = 2.5                 # oyun bandi modeli (bkz. modul basligi)

def _db_yolu():
    """Ansiklopedi ad veritabani: GELISTIRME kaynagi, PAKETE GIRMEZ.

    Sira: ACBFR_VARLIKLAR_DB ortam degiskeni -> gelistirme agacindaki goreli konum
    -> bos. Bos oldugunda cozucu adsiz calisir; adlar yalnizca raporu susler,
    zincirin kendisi (LODSelector -> mesh) adlara BAGLI DEGILDIR.

    Goreli arama proje kokunun KARDES klasorlerinde `isimler\\varliklar.db` arar; klasor
    adi kodda YAZILI DEGILDIR (yayinlanan pakette anlamsiz olurdu ve gelistirme agacinin
    adini kullaniciya tasirdi). Tarama tek os.listdir, yalniz okuma, ilk eslesme kazanir.
    """
    ov = os.environ.get("ACBFR_VARLIKLAR_DB")
    if ov and os.path.isfile(ov):
        return ov
    kok = os.path.dirname(os.path.dirname(os.path.dirname(BURA)))
    try:
        for ad in sorted(os.listdir(kok))[:400]:
            aday = os.path.join(kok, ad, "isimler", "varliklar.db")
            if os.path.isfile(aday):
                return aday
    except OSError:                                   # kok okunamiyor = aday yok
        pass
    return ""


DB_YOL = _db_yolu()

def _onbellek_yolu():
    """LODSelector onbellegi KULLANICI verisidir, paketin parcasi DEGIL: kur_mesh'in WAL
    kaydiyla ayni kokte (%LOCALAPPDATA%\\ACBFR_Modding) durur. src\\export3d icine yazmak
    3,9 MB'lik uretilmis dosyayi pakete sokardi (build/kur.py beklenmeyen-dosya kapisi)."""
    kok = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    d = os.path.join(kok, "ACBFR_Modding", "export3d")
    try:
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "lod_indeks.json")
    except OSError:
        return os.path.join(BURA, "lod_indeks.json")


ONBELLEK_YOL = _onbellek_yolu()
SURUM = "1.0"


# =====================================================================================
#  0) yardimcilar
# =====================================================================================
def _hx(v):
    return None if v is None else "0x%X" % v


def _int(v):
    if v is None:
        return None
    return v if isinstance(v, int) else int(str(v), 16)


def _mod(ad):
    """export3d modullerini hem paket hem duz betik olarak import edebil."""
    if __package__:
        return __import__("%s.%s" % (__package__, ad), fromlist=[ad])
    for p in (SRC, BURA):
        if p not in sys.path:
            sys.path.insert(0, p)
    return __import__(ad)


def _forge():
    if SRC not in sys.path:
        sys.path.insert(0, SRC)
    import outfit_core as C
    return C


# =====================================================================================
#  1) LODSelector govde cozucusu
# =====================================================================================
def _nesneler(b):
    """[u16 idx][u16 F8FB][u32 0][u32 tip] baslikli nesneleri SIRAYLA dondur."""
    out = []
    i = 0
    n = len(b)
    while i + 12 <= n:
        if b[i + 2:i + 4] == b"\xf8\xfb" and b[i + 4:i + 8] == b"\x00\x00\x00\x00":
            out.append((i, struct.unpack_from("<H", b, i)[0],
                        struct.unpack_from("<I", b, i + 8)[0]))
            i += 12
            continue
        i += 1
    # ardisik nesne baslamalari: govde uzunluklari komsu ofsetlerden turetilir
    return out


def lodsel_coz(govde):
    """LODSelector govdesi -> {"bantlar":[...], "bilinmeyen":[tipHash...], "nesne":n}.

    Bant = (A kaydi, onu izleyen B kaydi). A yoksa B tek basina da bant acar
    (vanilla'da gorulmedi, ama fail-open degil: yapisi rapora yazilir)."""
    ns = _nesneler(govde)
    bantlar = []
    bilinmeyen = []
    acik = None
    for k, (off, _idx, tip) in enumerate(ns):
        son = ns[k + 1][0] if k + 1 < len(ns) else len(govde)
        pay = govde[off + 12:son]
        if tip == T_BANT_GOLGE:
            if acik is not None:
                bantlar.append(acik)
            acik = {"seviye": len(bantlar), "mesafe": None, "ana": None, "materyal": None,
                    "golge": None, "yaricap": None}
            if len(pay) >= 13:
                bayrak = pay[0]
                ref = struct.unpack_from("<Q", pay, 1)[0]
                acik["mesafe"] = round(struct.unpack_from("<f", pay, 9)[0], 4)
                acik["golge_bayrak"] = bayrak
                if bayrak == 1 and ref:
                    acik["golge"] = ref
        elif tip == T_BANT_ANA:
            if acik is None:
                acik = {"seviye": len(bantlar), "mesafe": None, "ana": None, "materyal": None,
                        "golge": None, "yaricap": None}
            if len(pay) >= 40:
                ref = struct.unpack_from("<Q", pay, 1)[0]
                d = round(struct.unpack_from("<f", pay, 11)[0], 4)
                mat = struct.unpack_from("<Q", pay, 20)[0]
                if ref:
                    acik["ana"] = ref
                    acik["materyal"] = mat or None
                    acik["yaricap"] = round(struct.unpack_from("<f", pay, 32)[0], 4)
                    if acik["mesafe"] is None:
                        acik["mesafe"] = d
                    acik["ana_mesafe"] = d
            bantlar.append(acik)
            acik = None
        else:
            bilinmeyen.append(tip)
    if acik is not None:
        bantlar.append(acik)
    for i, bn in enumerate(bantlar):
        bn["seviye"] = i
    return {"bantlar": bantlar, "bilinmeyen": bilinmeyen, "nesne": len(ns)}


def _u64_refler(b, bas=1):
    """govdedeki (onceki bayt, u64) ciftleri -- cagiran filtreler."""
    for q in range(bas, len(b) - 8):
        yield q, b[q - 1], struct.unpack_from("<Q", b, q)[0]


# =====================================================================================
#  2) LODSelector indeksi (canli forge taramasi + onbellek)
# =====================================================================================
class LodIndeks(object):
    """Canli boot.forge'daki TUM LODSelector'lerin cozumu + ters haritalar.

    Kapsam: (a) TOC ext'i LODSelector olan girisler (canli TOC'tan, DB'siz),
            (b) ansiklopedinin "bu giriste gomulu LODSelector var" dedigi girisler.
    Yalniz SALT OKUMA; is bitince cagiran release_forge cagirir."""

    def __init__(self, kayitlar, imza, adlar=None):
        self.kayit = kayitlar                      # icid -> kayit
        self.imza = imza
        self.ad = adlar or {}
        self.ad2 = collections.defaultdict(list)   # normalize(ad) -> [icid]
        self.mat2 = collections.defaultdict(list)  # material -> [icid]
        self.mesh2 = collections.defaultdict(list) # mesh icid -> [icid]
        for icid, k in self.kayit.items():
            if k.get("ad"):
                self.ad2[nrm(k["ad"])].append(icid)
            for bn in k["bantlar"]:
                # onbellekten gelen id'ler HEX DIZE'dir; ters haritalar DAIMA int anahtarli
                if bn.get("materyal"):
                    self.mat2[_int(bn["materyal"])].append(icid)
                for r in ("ana", "golge"):
                    m = bn.get(r)
                    if m:
                        self.mesh2[_int(m["icid"] if isinstance(m, dict) else m)].append(icid)
        for d in (self.ad2, self.mat2, self.mesh2):
            for k2 in d:
                d[k2] = sorted(set(d[k2]))

    def __len__(self):
        return len(self.kayit)


def nrm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


_DB_ONBELLEK = {}
# Ad/tip sozlugunun okunacagi arsivler, ILK KAZANIR (yama zinciri sirasi). None = OTOMATIK:
# C.FORGE'un klasorundeki yama grubu (DataPC_boot_patch_01 > DataPC_boot) -- oyunun gordugu adlar;
# Patch_01'de eklenen LODSelector/mesh'ler (Altair Skirt, SkirtFlapsMid; Edward Bracers) boylece ad
# ve tip bulur ve calisma zamanindaki cozum, zincirle kurulan indeksle AYNI sonucu verir (2026-10-12:
# eski sabit boot sozlugu Privateer BracerL/R'yi eski LODSelector'e dusuruyordu). FORGE'un adi
# DataPC_boot.forge degilse (gecici kopya, WhiteRoom) eski davranis: yalniz boot sozlugu.
# tools/parca_indeks_zincir.py --zincir acikca ("DataPC_boot_patch_01.forge", "DataPC_boot.forge") verir.
AD_FORGELERI = None
_AD_FORGE_ONBELLEK = {}


def _ad_forgeleri():
    """Sozluk arsivlerinin ad dizisi (ILK kazanir). Acik AD_FORGELERI varsa o, yoksa otomatik zincir."""
    if AD_FORGELERI:
        return tuple(AD_FORGELERI)
    C = _forge()
    forge = getattr(C, "FORGE", None) or ""
    if os.path.basename(forge).lower() != "datapc_boot.forge":
        return ("DataPC_boot.forge",)
    kok = os.path.normcase(os.path.dirname(os.path.abspath(forge)))
    hit = _AD_FORGE_ONBELLEK.get(kok)
    if hit is not None:
        return hit
    try:
        CF = _mod("cok_forge")
        adlar = tuple(os.path.basename(p) for p in CF.zincir_kur(forge, ortak=()))
    except Exception:                                      # noqa: BLE001
        adlar = ()
    if "DataPC_boot.forge" not in adlar:
        adlar = ("DataPC_boot.forge",)
    _AD_FORGE_ONBELLEK[kok] = adlar
    return adlar


def _db_adlar(db_yol=DB_YOL, forge=None):
    import sqlite3    # tembel: paket kapisi sqlite3 import edilmesin diyor
    """ansiklopediden {ic_id: (ad, tip)} + {ic_id: giris_id} (yalniz AD icin).
    `forge`: tek ad, ad dizisi ya da None (-> AD_FORGELERI); birden fazlaysa ILK kazanir.
    ONBELLEKLI: bt_lodsel/eg_lodsel parca basina cagriliyor; her cagrida 1,9M satirlik
    tabloyu yeniden taramak cozumu dakikalara cikariyordu (olculdu)."""
    if forge is None:
        forgeler = _ad_forgeleri()
    elif isinstance(forge, (tuple, list)):
        forgeler = tuple(forge)
    else:
        forgeler = (forge,)
    k = (db_yol, forgeler)
    if k in _DB_ONBELLEK:
        return _DB_ONBELLEK[k]
    ad, gir = {}, {}
    if not os.path.exists(db_yol):
        _DB_ONBELLEK[k] = (ad, gir)
        return ad, gir
    c = sqlite3.connect(db_yol)
    try:
        for f in forgeler:
            for gid, icid, a, tip in c.execute(
                    "select giris_id, ic_id, ad, tip from ic_dosyalar where forge=?", (f,)):
                icid = int(icid)
                if icid in ad:
                    continue
                ad[icid] = (a, int(tip) & 0xFFFFFFFF)
                gir[icid] = int(gid)
    finally:
        c.close()
    _DB_ONBELLEK[k] = (ad, gir)
    return ad, gir


def _forge_imza(lf):
    st = os.stat(lf.path)
    return {"yol": lf.path, "boyut": st.st_size, "mtime": int(st.st_mtime),
            "toc": len(lf.entries), "surum": SURUM}


_INDEKS = None


def lod_indeks(yenile=False, ilerleme=None):
    """Onbellekli LodIndeks. Forge imzasi degistiyse onbellek atilir."""
    global _INDEKS
    if _INDEKS is not None and not yenile:
        return _INDEKS
    C = _forge()
    lf = C._forge()
    imza = _forge_imza(lf)
    if not yenile and os.path.exists(ONBELLEK_YOL):
        try:
            with open(ONBELLEK_YOL, encoding="utf-8") as f:
                d = json.load(f)
            if d.get("imza") == imza:
                _INDEKS = LodIndeks(_onbellek_coz(d["kayit"]), imza)
                return _INDEKS
        except Exception:                                  # noqa: BLE001 -- bozuk onbellek yeniden kurulur
            pass
    _INDEKS = _indeks_kur(lf, imza, ilerleme)
    try:
        with open(ONBELLEK_YOL, "w", encoding="utf-8") as f:
            json.dump({"imza": imza, "uretim": time.strftime("%Y-%m-%d %H:%M:%S"),
                       "kayit": _onbellek_yaz(_INDEKS.kayit)}, f, ensure_ascii=False)
    except OSError:
        pass
    return _INDEKS


def _onbellek_yaz(kayit):
    return {"0x%X" % k: v for k, v in kayit.items()}


def _onbellek_coz(d):
    return {int(k, 16): v for k, v in d.items()}


def _indeks_kur(lf, imza, ilerleme=None):
    FG = _mod("forge_giris")
    ad, _gir = _db_adlar()
    # kapsam: canli TOC ext'i + ansiklopedinin bildirdigi gomulu LODSelector girisleri
    hedef = {e[1] for e in lf.entries if e[3] == T_LODSEL}
    if os.path.exists(DB_YOL):
        import sqlite3
        c = sqlite3.connect(DB_YOL)
        try:
            for f in _ad_forgeleri():
                for (g,) in c.execute("select distinct giris_id from ic_dosyalar "
                                      "where forge=? and tip=?", (f, T_LODSEL)):
                    if int(g) in lf.by_id:
                        hedef.add(int(g))
        finally:
            c.close()
    kayit = {}
    n = 0
    for gid in sorted(hedef):
        n += 1
        if ilerleme and n % 500 == 0:
            ilerleme("LODSelector scan %d/%d" % (n, len(hedef)))
        try:
            icler = FG.ic_dosyalar(lf, gid)
        except Exception:                                  # noqa: BLE001
            continue
        ic_kume = {cid for cid, _ in icler}
        for icid, gov in icler:
            try:
                w = FG.sarmalayici_coz(gov)
            except Exception:                              # noqa: BLE001
                continue
            if w["tip"] != T_LODSEL:
                continue
            try:
                c = lodsel_coz(gov[w["govde_off"]:])
            except Exception as e:                         # noqa: BLE001
                kayit[icid] = {"gid": gid, "icid": icid, "ad": ad.get(icid, ("", 0))[0],
                               "bantlar": [], "hata": "%s: %s" % (type(e).__name__, e)}
                continue
            bantlar = []
            for bn in c["bantlar"]:
                y = {"seviye": bn["seviye"], "mesafe": bn["mesafe"], "ana": None,
                     "materyal": _hx(bn["materyal"]), "golge": None, "yaricap": bn.get("yaricap")}
                for rol in ("ana", "golge"):
                    m = bn.get(rol)
                    if m:
                        y[rol] = _mesh_yer(lf, m, gid, ic_kume, ad)
                bantlar.append(y)
            kayit[icid] = {"gid": gid, "icid": icid, "ad": ad.get(icid, ("", 0))[0],
                           "bantlar": bantlar, "bilinmeyen": c["bilinmeyen"]}
    return LodIndeks(kayit, imza, ad)


_MESH_GIR = None


def _mesh_gir():
    """{mesh ic_id: giris_id} (ansiklopedi, yalniz boot) -- gomulu mesh'leri yerlestirmek icin."""
    global _MESH_GIR
    if _MESH_GIR is None:
        _MESH_GIR = {}
        if os.path.exists(DB_YOL):
            import sqlite3
            c = sqlite3.connect(DB_YOL)
            try:
                for gid, icid in c.execute("select giris_id, ic_id from ic_dosyalar "
                                           "where forge='DataPC_boot.forge' and tip=?", (T_MESH,)):
                    _MESH_GIR.setdefault(int(icid), int(gid))
            finally:
                c.close()
    return _MESH_GIR


def _mesh_yer(lf, icid, lodsel_gid, ic_kume, ad):
    """mesh ic_id -> {gid, icid, ad, yer}. Sira: LODSelector'un KENDI girisi ->
    kendi TOC girisi -> ansiklopedi. Hicbiri tutmazsa yer='?'."""
    nm = ad.get(icid, ("", 0))[0]
    if icid in ic_kume:
        return {"gid": _hx(lodsel_gid), "icid": _hx(icid), "ad": nm, "yer": "lodsel"}
    if icid in lf.by_id:
        return {"gid": _hx(icid), "icid": _hx(icid), "ad": nm, "yer": "toc"}
    g = _mesh_gir().get(icid)
    if g and g in lf.by_id:
        return {"gid": _hx(g), "icid": _hx(icid), "ad": nm, "yer": "db"}
    return {"gid": None, "icid": _hx(icid), "ad": nm, "yer": "?"}


# =====================================================================================
#  3) giris noktalari
# =====================================================================================
def _bt_slotlari(govde):
    """BuildTable govdesindeki [00][u64] GraphicObject slotlari + [01][u64] alt tablolari."""
    slot, alt = [], []
    for q, pre, v in _u64_refler(govde):
        if v <= 0xFFFFFFFF:
            continue
        (slot if pre == 0 else alt).append(v)
    return slot, alt


_SILAH_AGAC = None


def silah_bt_agaci(kok=SILAH_BT_KOK):
    """OBD_Weapons_BuildTable agacini ozyinelemeli yurur.
    -> {lodsel_icid: [BuildTable yolu (ad listesi)]}"""
    global _SILAH_AGAC
    if _SILAH_AGAC is not None:
        return _SILAH_AGAC
    C = _forge()
    FG = _mod("forge_giris")
    lf = C._forge()
    ad, gir = _db_adlar()
    onbellek = {}

    def govde(icid):
        if icid in onbellek:
            return onbellek[icid]
        gid = gir.get(icid, icid)
        onbellek[icid] = None
        try:
            for cid, g in FG.ic_dosyalar(lf, gid):
                w = FG.sarmalayici_coz(g)
                onbellek[cid] = (w["tip"], g[w["govde_off"]:])
        except Exception:                                  # noqa: BLE001
            pass
        return onbellek.get(icid)

    gorulen, sonuc = set(), {}
    yigit = [(kok, ())]
    while yigit:
        cur, yol = yigit.pop()
        if cur in gorulen:
            continue
        gorulen.add(cur)
        r = govde(cur)
        if not r or r[0] != T_BUILDTABLE:
            continue
        yeni_yol = yol + (ad.get(cur, ("0x%X" % cur, 0))[0],)
        slot, alt = _bt_slotlari(r[1])
        for v in alt:
            if ad.get(v, ("", 0))[1] == T_BUILDTABLE:
                yigit.append((v, yeni_yol))
        for v in slot:
            if ad.get(v, ("", 0))[1] == T_LODSEL:
                sonuc.setdefault(v, []).append(list(yeni_yol))
    _SILAH_AGAC = sonuc
    return sonuc


_BT_AD = None
_BT_SLOT = {}


def _bt_ad_indeksi():
    """{nrm(kirpilmamis BuildTable adi): [ic_id]} -- bt_lodsel'in tarama maliyetini kaldirir."""
    global _BT_AD
    if _BT_AD is None:
        ad, _gir = _db_adlar()
        _BT_AD = collections.defaultdict(list)
        for i, (a, t) in ad.items():
            if t == T_BUILDTABLE and a:
                _BT_AD[nrm(a.rstrip("?"))].append(i)
    return _BT_AD


def bt_lodsel(parca_adi):
    """Parca adiyla BIREBIR eslesen BuildTable'in [00][u64] slotu -> LODSelector icid.

    Ansiklopedi adlari kirpik olabilir ('OBD_Weapons_BuildTab??'); '?' kuyrugu
    ONEK olarak kabul edilir. Birden fazla aday varsa None (belirsizlik = red)."""
    if parca_adi in _BT_SLOT:
        return _BT_SLOT[parca_adi]
    _BT_SLOT[parca_adi] = None
    C = _forge()
    FG = _mod("forge_giris")
    lf = C._forge()
    ad, gir = _db_adlar()
    p = nrm(parca_adi)
    bti = _bt_ad_indeksi()
    adaylar = list(bti.get(p, []))
    if not adaylar:                       # kirpik ad: ONEK olarak dene (en uzun onek kazanir)
        onekler = [k for k in bti if k and len(k) >= 8 and p.startswith(k)]
        if onekler:
            adaylar = bti[max(onekler, key=len)]
    tam = [i for i in adaylar if nrm(ad[i][0]) == p]
    adaylar = tam or adaylar
    if len(adaylar) != 1:
        return None
    icid = adaylar[0]
    gid = gir.get(icid, icid)
    try:
        for cid, g in FG.ic_dosyalar(lf, gid):
            if cid != icid:
                continue
            w = FG.sarmalayici_coz(g)
            slot, _alt = _bt_slotlari(g[w["govde_off"]:])
            for v in slot:
                if ad.get(v, ("", 0))[1] == T_LODSEL:
                    return v
    except Exception:                                      # noqa: BLE001
        return None
    return None


_GIRIS_ICI = {}


def giris_ici(gid):
    """TOC girisi -> ({LODSelector ic id'leri}, {Material ic id'leri}).

    Katalogun `mat_id`'si her zaman Material DEGILDIR: bazi hedeflerde TextureSet
    girisidir (Musket_OBD_W_STORE_*_Set) ya da dogrudan LODSelector girisidir
    (trinket'ler). Kap icini okumak, ad tahminine dusmeden bir sonraki halkayi verir."""
    gid = _int(gid)
    if gid in _GIRIS_ICI:
        return _GIRIS_ICI[gid]
    C = _forge()
    FG = _mod("forge_giris")
    lf = C._forge()
    ls, mt = [], []
    try:
        for cid, g in FG.ic_dosyalar(lf, gid):
            w = FG.sarmalayici_coz(g)
            if w["tip"] == T_LODSEL:
                ls.append(cid)
            elif w["tip"] == T_MATERIAL:
                mt.append(cid)
    except Exception:                                      # noqa: BLE001
        pass
    _GIRIS_ICI[gid] = (ls, mt)
    return _GIRIS_ICI[gid]


_MAT_REF = None


def mat_ref_indeksi(idx):
    """{materyal govdesinde gecen id: [LODSelector]} -- LODSelector -> Material -> TextureSet.

    Bazi katalog kayitlarinda `mat_id` Material degil, Material'in KULLANDIGI TextureSet'tir
    (Musket/Sword_OBD_W_STORE_*_Set, 10 hedef). Bant materyallerinin govdesini bir kez
    okuyup icindeki tum bilinen id'leri LODSelector'e baglamak bu halkayi kapatir.
    TEMBEL: ancak daha ucuz yollar tukendiginde kurulur (~2 sn)."""
    global _MAT_REF
    if _MAT_REF is not None:
        return _MAT_REF
    C = _forge()
    FG = _mod("forge_giris")
    lf = C._forge()
    ad, gir = _db_adlar()
    _MAT_REF = collections.defaultdict(list)
    mat2ls = collections.defaultdict(list)
    for icid, k in idx.kayit.items():
        for bn in k["bantlar"]:
            if bn.get("materyal"):
                mat2ls[_int(bn["materyal"])].append(icid)
    onbellek = {}
    for mid, lslist in mat2ls.items():
        g = gir.get(mid, mid)
        if g not in onbellek:
            onbellek[g] = {}
            try:
                for cid, gv in FG.ic_dosyalar(lf, g):
                    onbellek[g][cid] = gv
            except Exception:                              # noqa: BLE001
                pass
        gv = onbellek[g].get(mid)
        if not gv:
            continue
        try:
            w = FG.sarmalayici_coz(gv)
            b = gv[w["govde_off"]:]
        except Exception:                                  # noqa: BLE001
            continue
        gor = set()
        for _q, _pre, v in _u64_refler(b):
            if v > 0xFFFFFFFF and v in ad and v not in gor:
                gor.add(v)
        for v in gor:
            _MAT_REF[v].extend(lslist)
    for v in _MAT_REF:
        _MAT_REF[v] = sorted(set(_MAT_REF[v]))
    return _MAT_REF


def eg_lodsel(eg_id):
    """EntityGroup govdesindeki LODSelector referanslari (gorulme sirasinda)."""
    C = _forge()
    FG = _mod("forge_giris")
    lf = C._forge()
    ad, gir = _db_adlar()
    eg_id = _int(eg_id)
    out = []
    gid = gir.get(eg_id, eg_id)
    try:
        icler = FG.ic_dosyalar(lf, gid)
    except Exception:                                      # noqa: BLE001
        return out
    for cid, g in icler:
        try:
            w = FG.sarmalayici_coz(g)
        except Exception:                                  # noqa: BLE001
            continue
        if w["tip"] != T_ENTITYGROUP:
            continue
        for _q, _pre, v in _u64_refler(g[w["govde_off"]:]):
            if v > 0xFFFFFFFF and ad.get(v, ("", 0))[1] == T_LODSEL and v not in out:
                out.append(v)
    return out


# =====================================================================================
#  4) parca cozumu
# =====================================================================================
def _ad_adaylari(idx, parca_adi):
    """SON CARE: ad eslesmesi. Ansiklopedi adlari kirpik oldugu icin (CHR_TRK_Narwhals_Hor?)
    tam eslesme tutmazsa ONEK denenir. Bu yol raporda `name` olarak SAYILIR -- zincir DEGIL."""
    n = nrm(parca_adi)
    if idx.ad2.get(n):
        return list(idx.ad2[n])
    onek = [k for k in idx.ad2 if k and len(k) >= 10 and n.startswith(k)]
    if onek:
        return list(idx.ad2[max(onek, key=len)])
    # oyunun kendi ad ikilikleri (CHR_TRK_Bloody_SpanishMedal <-> CHR_TRK_Spanish_Meda):
    # eski kurucunun bulanik esigi (0,82) korunur, ama sonuc `name` olarak isaretlenir.
    import difflib
    en_iyi, skor = None, 0.0
    for k in idx.ad2:
        if not k or abs(len(k) - len(n)) > 12:
            continue
        s = difflib.SequenceMatcher(None, n, k).ratio()
        if s > skor:
            en_iyi, skor = k, s
    return list(idx.ad2[en_iyi]) if en_iyi and skor >= 0.82 else []


def _parca(idx, lodsel_icid, ad_ipucu=None, kaynak="?"):
    k = idx.kayit.get(lodsel_icid)
    if not k:
        return None
    bantlar = k["bantlar"]
    lodlar, gorulen, yazilacak = [], set(), []
    for bn in bantlar:
        for rol in ("ana", "golge"):
            m = bn.get(rol)
            if not m or not m.get("gid"):
                continue
            anahtar = (m["gid"], m["icid"])
            if anahtar in gorulen:
                continue
            gorulen.add(anahtar)
            lodlar.append({"seviye": bn["seviye"], "rol": "main" if rol == "ana" else "proxy",
                           "gid": m["gid"], "icid": m["icid"], "ad": m.get("ad"),
                           "mesafe": bn["mesafe"],
                           "materyal": bn["materyal"] if rol == "ana" else None})
            yazilacak.append({"gid": m["gid"], "icid": m["icid"]})
    dolu = [bn for bn in bantlar if bn.get("ana") or bn.get("golge")]
    oyun = None
    for bn in dolu:
        if bn["mesafe"] is not None and bn["mesafe"] >= KAMERA_M:
            oyun = bn
            break
    if oyun is None and dolu:
        oyun = dolu[-1]
    oyun_lod0 = None
    if oyun:
        m = oyun.get("ana") or oyun.get("golge")
        if m and m.get("gid"):
            oyun_lod0 = {"gid": m["gid"], "icid": m["icid"], "ad": m.get("ad")}
    mats = []
    for bn in bantlar:
        if bn.get("materyal") and bn["materyal"] not in mats:
            mats.append(bn["materyal"])
    return {"ad": k.get("ad") or ad_ipucu, "kaynak": kaynak,
            "lodsel": {"gid": _hx(k["gid"]), "icid": _hx(k["icid"]), "ad": k.get("ad")},
            "bantlar": bantlar, "lodlar": lodlar, "yazilacak": yazilacak,
            "lod_sayisi": len(dolu), "mesh_sayisi": len(lodlar),
            "oyun_bandi": oyun["seviye"] if oyun else None, "oyun_lod0": oyun_lod0,
            "materyaller": mats}


# =====================================================================================
#  5) hedef cozumleri
# =====================================================================================
def _silah_katalog():
    with open(os.path.join(SRC, "silah_katalog.json"), encoding="utf-8") as f:
        return json.load(f)["silahlar"]


def _onizleme_indeks():
    for y in (os.path.join(SRC, "onizleme3d_indeks.json"),
              os.path.join(KOK, "onizleme3d", "onizleme3d_indeks.json")):
        if os.path.exists(y):
            with open(y, encoding="utf-8") as f:
                return json.load(f)["kiyafetler"], y
    raise FileNotFoundError("onizleme3d_indeks.json")


def coz_silah(anahtar, idx=None):
    """Silah: OBD_Weapons_BuildTable agaci (kapsam) + katalog materyali (kimlik)."""
    idx = idx or lod_indeks()
    kat = {w["ad"]: w for w in _silah_katalog()}
    w = kat.get(anahtar)
    if not w:
        raise KeyError("weapon %r is not in silah_katalog.json" % anahtar)
    agac = silah_bt_agaci()
    parcalar, eksik = [], []
    for m in w["materyaller"]:
        mat = _int(m["mat_id"])
        # Trinket'lerde katalogun `mat_id`'si aslinda GIRIS kimligidir ve o girisin birincil
        # ic dosyasi LODSelector'un ta kendisidir (32 trinket'te olculdu) -- once buna bak.
        if mat in idx.kayit:
            p = _parca(idx, mat, m["parca_adi"], "lodselector-id")
            if p:
                p["katalog_parca"] = m["parca_adi"]
                p["bt_yolu"] = agac.get(mat, [None])[0]
                if not any(q["lodsel"]["icid"] == p["lodsel"]["icid"] for q in parcalar):
                    parcalar.append(p)
                continue
        adaylar = idx.mat2.get(mat, [])
        zincir = [a for a in adaylar if a in agac]
        kaynak = "buildtable" if zincir else ("material" if adaylar else None)
        sec = zincir or adaylar
        if not sec:
            # katalogun id'si TextureSet/Material girisi olabilir: kabin icine bak
            g_ls, g_mt = giris_ici(mat)
            g_ls = [x for x in g_ls if x in idx.kayit]
            if g_ls:
                sec, kaynak = g_ls, "entry-lodselector"
            else:
                for mm in g_mt:
                    if idx.mat2.get(mm):
                        sec, kaynak = idx.mat2[mm], "entry-material"
                        break
        if not sec:
            mr = mat_ref_indeksi(idx).get(mat)
            if mr:
                zincir2 = [a for a in mr if a in agac]
                sec, kaynak = (zincir2 or mr), "material-textureset"
        if not sec:
            ls = bt_lodsel(m["parca_adi"])
            if ls is not None and ls in idx.kayit:
                sec, kaynak = [ls], "buildtable-name"
        if not sec:
            sec = _ad_adaylari(idx, m["parca_adi"])
            kaynak = "name" if sec else None
        if not sec:
            eksik.append({"parca_adi": m["parca_adi"], "mat_id": m["mat_id"],
                          "sebep": "no LODSelector reaches this material"})
            continue
        for ls in sec:
            p = _parca(idx, ls, m["parca_adi"], kaynak)
            if p and not any(q["lodsel"]["icid"] == p["lodsel"]["icid"] for q in parcalar):
                p["katalog_parca"] = m["parca_adi"]
                p["bt_yolu"] = agac.get(ls, [None])[0]
                parcalar.append(p)
    return _paketle(anahtar, "weapon", {"tur": "BuildTable", "id": _hx(SILAH_BT_KOK),
                                        "ad": "OBD_Weapons_BuildTable"}, parcalar, eksik,
                    gorunen_ad=w.get("gorunen_ad"))


def coz_kiyafet(anahtar, idx=None, yeni_parcalar=False):
    """Kiyafet/karakter: EG_id (varsa) -> LODSelector; yoksa parca adi -> BuildTable -> slot.
    yeni_parcalar=True: EntityGroup'un referans verdigi ama indekste HIC parcasi olmayan
    LODSelector'ler de `indeks_parca=None, yeni=True` ile eklenir (Patch_01'in ekledigi parcalar;
    tools/parca_indeks_zincir.py bunlari yeni grup olarak yazar). Varsayilan eski davranis."""
    idx = idx or lod_indeks()
    kiy, _yol = _onizleme_indeks()
    v = kiy.get(anahtar)
    if not v:
        raise KeyError("%r is not in onizleme3d_indeks.json" % anahtar)
    tur = "character" if anahtar.startswith("CHR") else "outfit"
    eg = v.get("EG_id")
    eg_set = set(eg_lodsel(eg)) if eg else set()
    giris = ({"tur": "EntityGroup", "id": eg, "ad": None} if eg
             else {"tur": "BuildTable", "id": None, "ad": "per-part BuildTable [00] slot"})
    parcalar, eksik = [], []
    for g in v["gruplar"]:
        taban = g["taban"]
        mesh_idler = {_int(l[2]) for l in g["lodlar"]}          # indeks kaydi: [boyut, gid, icid, ad]
        ls, kaynak = None, None
        # 1) EG kapsamindaki LODSelector'lerden bu parcanin mesh'ine dokunani sec
        aday = [a for a in (idx.mesh2.get(m, []) for m in mesh_idler) for a in a]
        say = collections.Counter(aday)
        eg_ic = [a for a in say if a in eg_set]
        if len(eg_ic) == 1:
            ls, kaynak = eg_ic[0], "entitygroup"
        elif len(eg_ic) > 1:
            ls, kaynak = max(eg_ic, key=lambda a: (say[a], a)), "entitygroup"
        if ls is None:
            b = bt_lodsel(taban)
            if b is not None and b in idx.kayit:
                ls, kaynak = b, "buildtable"
        if ls is None and say:
            ls, kaynak = max(say, key=lambda a: (say[a], a)), "mesh"
        if ls is None:
            n = _ad_adaylari(idx, taban)
            if len(n) == 1:
                ls, kaynak = n[0], "name"
        if ls is None:
            eksik.append({"parca_adi": taban, "sebep": "no LODSelector references these meshes"})
            continue
        p = _parca(idx, ls, taban, kaynak)
        if p is None:
            eksik.append({"parca_adi": taban, "sebep": "LODSelector 0x%X not decodable" % ls})
            continue
        p["indeks_parca"] = taban
        parcalar.append(p)
    if yeni_parcalar and eg_set:
        kullanilan = {_int(p["lodsel"]["icid"]) for p in parcalar}
        for ls in eg_lodsel(eg):
            if ls in kullanilan or ls not in idx.kayit:
                continue
            p = _parca(idx, ls, None, "entitygroup_yeni")
            if p is None or not p["lodlar"]:
                continue
            p["indeks_parca"] = None
            p["yeni"] = True
            parcalar.append(p)
    return _paketle(anahtar, tur, giris, parcalar, eksik, gorunen_ad=v.get("gorunen_ad"))


def _paketle(anahtar, tur, giris, parcalar, eksik, gorunen_ad=None):
    lodlar = [p["lod_sayisi"] for p in parcalar]
    return {"anahtar": anahtar, "gorunen_ad": gorunen_ad, "tur": tur,
            "giris_noktasi": giris, "parcalar": parcalar, "cozulmeyen": eksik,
            "ozet": {"parca": len(parcalar), "cozulmeyen": len(eksik),
                     "mesh": sum(p["mesh_sayisi"] for p in parcalar),
                     "lod_min": min(lodlar) if lodlar else 0,
                     "lod_max": max(lodlar) if lodlar else 0,
                     "kaynak": dict(collections.Counter(p["kaynak"] for p in parcalar))}}


def coz(anahtar, idx=None):
    """Anahtar turunu kendi bulur: silah katalogunda mi, onizleme indeksinde mi."""
    try:
        kat = {w["ad"] for w in _silah_katalog()}
    except Exception:                                      # noqa: BLE001
        kat = set()
    if anahtar in kat:
        return coz_silah(anahtar, idx)
    return coz_kiyafet(anahtar, idx)


def coz_hepsi(tur=None, ilerleme=None):
    """tur: None | 'weapon' | 'outfit' | 'character' -> {anahtar: cozum}"""
    idx = lod_indeks(ilerleme=ilerleme)
    out = {}
    if tur in (None, "weapon"):
        for w in _silah_katalog():
            try:
                out[w["ad"]] = coz_silah(w["ad"], idx)
            except Exception as e:                         # noqa: BLE001
                out[w["ad"]] = {"anahtar": w["ad"], "tur": "weapon", "hata": str(e),
                                "parcalar": [], "cozulmeyen": [], "ozet": {}}
    if tur in (None, "outfit", "character"):
        kiy, _y = _onizleme_indeks()
        for k in kiy:
            t = "character" if k.startswith("CHR") else "outfit"
            if tur in (None, t):
                try:
                    out[k] = coz_kiyafet(k, idx)
                except Exception as e:                     # noqa: BLE001
                    out[k] = {"anahtar": k, "tur": t, "hata": str(e),
                              "parcalar": [], "cozulmeyen": [], "ozet": {}}
    return out


# =====================================================================================
#  6) CLI
# =====================================================================================
def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="Resolve a target's meshes through the game's own "
                                             "BuildTable/EntityGroup -> LODSelector chain.")
    ap.add_argument("anahtar", nargs="?", help="catalog/index key (weapon, outfit or character)")
    ap.add_argument("--hepsi", action="store_true", help="resolve every catalog target")
    ap.add_argument("--tur", choices=["weapon", "outfit", "character"])
    ap.add_argument("--yenile", action="store_true", help="rebuild the LODSelector cache")
    ap.add_argument("--json", dest="js", help="write the result to this JSON file")
    a = ap.parse_args(argv)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    C = _forge()
    try:
        if a.yenile:
            lod_indeks(yenile=True, ilerleme=lambda s: print("  " + s))
        if a.hepsi or a.tur:
            r = coz_hepsi(a.tur, ilerleme=lambda s: print("  " + s))
            print("resolved %d targets" % len(r))
        elif a.anahtar:
            r = coz(a.anahtar)
            print(json.dumps(r["ozet"], ensure_ascii=False))
            for p in r["parcalar"]:
                print("%-42s via %-16s LODSelector %s  LODs=%d  game band=%s" % (
                    p["ad"], p["kaynak"], p["lodsel"]["icid"], p["lod_sayisi"], p["oyun_bandi"]))
                for l in p["lodlar"]:
                    print("    band %d %-5s gid=%-14s icid=%-14s d=%-6s %s" % (
                        l["seviye"], l["rol"], l["gid"], l["icid"], l["mesafe"], l["ad"] or ""))
        else:
            ap.error("give a key or --hepsi")
        if a.js:
            with open(a.js, "w", encoding="utf-8") as f:
                json.dump(r, f, ensure_ascii=False, indent=1)
            print("written:", a.js)
    finally:
        C.release_forge(onbellek=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
