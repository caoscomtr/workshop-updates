# -*- coding: utf-8 -*-
"""toc_ekle -- arsive YENI bir TOC girisi ekler (var olan bir girisin kopyasi olarak).

BUGUNE KADAR butun yazicilar VAR OLAN bir satiri yonlendiriyordu (kur_mesh.kur,
doku_enjekte2, ship_yerinde). Bu modul ilk kez YENI bir satir ekler: kaynak girisin
baytlari yeni bir kimlik ve yeni bir adla arsivin sonuna yazilir, TOC'a bir satir
eklenir, baslik sayaci bir artar. Kaynak girise TEK BAYT dokunulmaz.

TEK YAZICI KURALI: dosyaya yazan tek yer `kur_mesh.giris_ekle`dir. Burada yalniz
YENI GIRISIN BAYTLARI kurulur ve dogrulanir; yazma, kayit (WAL) ve geri alma o
modulun kapilarindan gecer.

DURUSTLUK -- BU YETMEZ: yeni giris arsivde durur ve okunur, ama OYUN ONU KULLANMAZ.
Kullanmasi icin ona isaret eden bir veri kaydi gerekir (kiyafet tablosu, Item /
UICosmeticDefinition kayitlari vb.). Bu modul o kayitlari yazmaz ve arayuz de
kullaniciya bunu acikca soyler.

OLCUM (2026-09-09, salt okuma, kum havuzu kopyalari + topluluk yamalari)
  * TOC bicimi: `scimitar\\0` @0, u32 surum=50 @9, i64 baslik_ofseti @13; baslik =
    [u32 giris_sayisi][u64 toc_konumu][8 bayt FF]. TOC = giris basina 24 bayt:
    [u64 ofset][u64 kimlik][u32 uzunluk][u32 sinif_crc]. AD TABLOSU YOK; adlar
    yalniz ic dosya sarmalayicisinda durur (bu yuzden ad tablosu guncellemesi de yok).
  * TOC'un ARDINDA bos (sifir) yer var: DataPC_boot 227.352 B = 9.473 satir,
    DataPC_WhiteRoom 27.969 B = 1.165 satir, topluluk patch_02 arsivleri 2.771-27.810 B.
    Yani satir YERINDE eklenir; TOC TASINMAZ (TR yamasi tasiyordu) ve baska araclarin
    kaydettigi satir konumlari gecerli kalir.
  * Topluluk patch_02 yamalari (JackSparrow v30, BlackBeard, Elizabeth) YENI SATIR
    EKLEMIYOR: 6-9 satirlarinin varlik kimlikleri vanilla DataPC_boot'ta AYNEN var
    (yalniz 0xC1/0xFF8/0xFFA sistem girisleri yamaya ozel). Yani "golgeleme"
    yapiyorlar; yeni kimlik icin ornek alinacak bir dizilim BIRAKMAMISLAR.

SINIR (v1): yalniz TEK ic dosyali ve kendi kimligine ATIF YAPMAYAN girisler
cogaltilir. Cok ic dosyali giriste her ic dosya yeni bir kimlik almali ve govdedeki
capraz atiflar yeniden eslenmelidir; govdesinde kendi kimligini tasiyan giriste ise
govde yeniden anahtarlanmalidir. Ikisi de olculmeden yapilmaz -> REDDEDILIR.
"""
import os
import struct
import sys

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)

from export3d import forge_giris as FG                         # noqa: E402
from export3d import doku_png as DP                            # noqa: E402
from export3d import kur_mesh as KM                            # noqa: E402

try:                                                           # kur_mesh ile AYNI yol
    from yalin_forge import LeanForge, read_block              # noqa: E402
except ImportError:                                            # gelistirme agacinda
    import outfit_core                                         # noqa: F401,E402
    from yalin_forge import LeanForge, read_block              # noqa: E402

__all__ = ["cogalt", "cogalt_plani", "yeni_kimlik", "ad_gecerli", "giris_kopyala",
           "AD_KURALI", "YENI_ALAN"]

# --- yeni kimlik alani -------------------------------------------------------------
# Vanilla DataPC_boot'ta olculen en buyuk kimlik 0x25C34A67523 (126.249 satir). Yeni
# kimlikler ONUN USTUNDEKI bir alandan verilir ki oyunun ileride verecegi kimliklerle
# carpismasin. Ust sinir da onemli: turetilmis nesne kimligi (nesne.kimlik) kimligi
# 20 bit sola kaydiriyor, yani kimlik 2**43'un altinda kalmali.
YENI_ALAN = 0x02F000000000                     # 0x2F << 36
KIMLIK_MASKE = 0xFFFFFFFFF                     # 36 bit
KIMLIK_UST = 1 << 43

_FNV_BASLA = 0xCBF29CE484222325
_FNV_ASAL = 0x100000001B3

AD_KURALI = "letters, digits, dot, dash or underscore; 1-200 characters, ASCII only"

# Ad alani ASCII disina cikamaz: ad sifresi bayt uzerinde calisir ve oyunun varlik
# adlari ASCII'dir. Bosluk da yok -- adlar dosya adi gibi kullaniliyor.
_AD_IZIN = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-")


def _fnv1a64(b):
    h = _FNV_BASLA
    for x in bytearray(b):
        h = ((h ^ x) * _FNV_ASAL) & 0xFFFFFFFFFFFFFFFF
    return h


def ad_gecerli(ad):
    """Ad kabul edilir mi? Doner None (tamam) ya da sebep metni."""
    if not ad:
        return "Type a name for the new entry (%s)." % AD_KURALI
    if len(ad) > 200:
        return "That name is too long (%s)." % AD_KURALI
    for ch in ad:
        if ch not in _AD_IZIN:
            return ("The name may only use %s - %r is not allowed." % (AD_KURALI, ch))
    return None


def _forge_kimlikleri(forge):
    """Bu arsivin ve YANINDAKI butun .forge dosyalarinin kimlikleri (CANLI TOC)."""
    kok = os.path.dirname(os.path.abspath(forge))
    hepsi = set()
    try:
        adlar = sorted(os.listdir(kok))
    except OSError:
        adlar = [os.path.basename(forge)]
    for ad in adlar:
        if not ad.lower().endswith(".forge"):
            continue
        p = os.path.join(kok, ad)
        try:
            with LeanForge(p) as lf:
                hepsi.update(int(e[1]) for e in lf.entries)
        except Exception:                                       # noqa: BLE001
            continue                                            # yer tutucu / bozuk dosya
    return hepsi


def _giris_adi(forge, gid):
    """Bu girisin ILK ic dosyasinin adi (bytes) ya da None."""
    try:
        with LeanForge(forge) as lf:
            if gid not in lf.by_id:
                return None
            icler = FG.ic_dosyalar(lf, gid)
        if not icler:
            return None
        govde = icler[0][1]
        w = FG.sarmalayici_coz(govde)
        return DP.ad_coz(govde[12:12 + w["adLen"]])
    except Exception:                                           # noqa: BLE001
        return None


def yeni_kimlik(ad, forge, kullanilan=()):
    """Addan TURETILMIS, CAKISMAYAN yeni giris kimligi.

    Ayni ad ayni kimligi verir (mod paketleri yeniden kurulunca kimlik kaymasin).
    Cakisma kontrolu EZBERE degil, arsiv klasorundeki her .forge'un CANLI TOC'una
    ve cagiranin verdigi `kullanilan` kumesine bakar.

    AYNI AD IKINCI KEZ: kimlik addan turedigi icin cakisma once BU ADIN kendi
    kimligine duser. O giris GERCEKTEN ayni adi tasiyorsa yeni kimlik URETILMEZ,
    ValueError atilir -- yoksa arac ayni adi tasiyan iki giris uretir ve kullanici
    hangisinin hangisi oldugunu ayirt edemez (olculdu: kapi E6).
    """
    var = _forge_kimlikleri(forge) | set(int(x) for x in kullanilan)
    ad_b = ad.encode("ascii")
    taban = _fnv1a64(ad.lower().encode("utf-8")) & KIMLIK_MASKE
    for i in range(4096):
        aday = YENI_ALAN | ((taban + i) & KIMLIK_MASKE)
        if aday >= KIMLIK_UST:
            continue
        if aday not in var:
            return aday
        if _giris_adi(forge, aday) == ad_b:
            raise ValueError(
                "This archive already has an entry named %r (0x%012X). Pick another "
                "name, or revert the one you added earlier." % (ad, aday))
    raise RuntimeError("no free id could be derived for %r" % ad)


def _sarmalayici_yaz(govde, yeni_icid, yeni_ad):
    """Ic dosyanin sarmalayicisini YENI kimlik ve YENI adla yeniden yaz.

    Sarmalayici: [u32 tip][u32 boyut][u32 adLen][ad][u8 bayrak][u64 nid][u32 tip].
    `boyut` ADI ICERMEZ (olculdu: boyut == len - 13 - adLen - kuyruk), bu yuzden ad
    uzunlugu degisince boyut alani DEGISMEZ -- ama yine de yeniden cozup dogrulanir
    (sarmalayici boyut dersi: uzunluk degistiren yazmada kabin kendi boyut alani).
    """
    w = FG.sarmalayici_coz(govde)
    ad_bayt = DP.ad_kodla(yeni_ad.encode("ascii"))
    if DP.ad_coz(ad_bayt) != yeni_ad.encode("ascii"):
        raise ValueError("the name cannot be encoded for this archive: %r" % yeni_ad)
    yeni = (struct.pack("<III", w["tip"], w["boyut"], len(ad_bayt)) + ad_bayt +
            bytes([w["flag"]]) + struct.pack("<Q", yeni_icid) +
            struct.pack("<I", w["tip"]) + govde[w["govde_off"]:])
    k = FG.sarmalayici_coz(yeni)                    # KURAL 2: kendi okuyucumuzla coz
    if k["nid"] != yeni_icid or k["tip"] != w["tip"] or k["boyut"] != w["boyut"] \
            or k["kuyruk"] != w["kuyruk"]:
        raise RuntimeError("the rebuilt inner file does not decode back to what we packed")
    if yeni[k["govde_off"]:] != govde[w["govde_off"]:]:
        raise RuntimeError("the rebuilt inner file changed its payload bytes")
    return yeni, w


def _oz_atiflar(yuk, icid):
    """Govde KENDI kimligine kac kez atif yapiyor? (dogrudan u64 + turetilmis onek)"""
    dogrudan = yuk.count(struct.pack("<Q", icid))
    onek = struct.pack("<Q", (0x8000000000000000 | (icid << 20)) & 0xFFFFFFFFFFFFFFFF)[2:]
    return dogrudan + yuk.count(onek)


def giris_kopyala(raw, eski_icid, yeni_icid, yeni_ad):
    """Giris ham baytlari -> YENI kimlikli/adli giris baytlari. Doner (bayt, bilgi).

    Yalniz TEK ic dosyali giriste calisir; K1 kaydinin ekstra alanlari BAYT BAZINDA
    korunur, yalniz kimlik (+0) ve uzunluk (+8) alanlari yazilir.
    """
    s1 = KM.blok_coz(raw, 0)
    k1, n1 = read_block(raw, 0)
    if k1 is None:
        raise ValueError("This archive entry is not a BMS container (raw asset?).")
    s2 = KM.blok_coz(raw, n1)
    k2, _n2 = read_block(raw, n1)
    if k2 is None:
        raise ValueError("This archive entry has no body container.")
    kayitlar = FG.k1_coz(k1, len(k2))
    if len(kayitlar) != 1:
        raise ValueError(
            "This entry holds %d inner files. Duplicating it would have to give every "
            "inner file a new id and remap the references between them, which has not "
            "been measured yet - refused." % len(kayitlar))
    if kayitlar[0][0] != eski_icid:
        raise ValueError("This entry's inner file is 0x%X, not 0x%X."
                         % (kayitlar[0][0], eski_icid))
    if kayitlar[0][1] != len(k2):
        raise ValueError("The entry's file table does not match its body.")
    yeni_ic, w = _sarmalayici_yaz(k2, yeni_icid, yeni_ad)
    yuk = k2[w["govde_off"]:]
    oz = _oz_atiflar(yuk, eski_icid)
    if oz:
        raise ValueError(
            "This entry's body carries its own id %d time(s), so the copy would still "
            "point at the original. Re-keying a body has not been measured yet - refused."
            % oz)
    k1_yeni = bytearray(k1)
    struct.pack_into("<Q", k1_yeni, 2, yeni_icid)
    struct.pack_into("<I", k1_yeni, 10, len(yeni_ic))
    yeni = (KM.blok_kur(bytes(k1_yeni), s1, KM._parca_boy_sec(s1, len(k1_yeni))) +
            KM.blok_kur(yeni_ic, s2, KM._parca_boy_sec(s2, len(yeni_ic))))

    # --- KURAL 2: yazmadan once KENDI okuyucumuzla coz ve karsilastir
    d1, m1 = read_block(yeni, 0)
    d2, _m2 = read_block(yeni, m1)
    if d1 != bytes(k1_yeni) or d2 != yeni_ic:
        raise RuntimeError("The rebuilt entry does not decode back to what we packed - "
                           "nothing was written.")
    kontrol = FG.k1_coz(d1, len(d2))
    if kontrol != [(yeni_icid, len(yeni_ic))]:
        raise RuntimeError("The rebuilt entry has an inconsistent file table - nothing "
                           "was written.")
    if len(yeni) > 0xFFFFFFFF:
        raise RuntimeError("The rebuilt entry is too large for this archive format.")
    bilgi = {"eski_icid": "0x%012X" % eski_icid, "yeni_icid": "0x%012X" % yeni_icid,
             "eski_ad_bayt": w["adLen"], "yeni_ad_bayt": len(yeni_ad),
             "ic_bayt_eski": len(k2), "ic_bayt_yeni": len(yeni_ic),
             "giris_bayt_eski": len(raw), "giris_bayt_yeni": len(yeni),
             "yuk_bayt": len(yuk), "oz_atif": oz}
    return yeni, bilgi


def _kaynak_oku(forge, kaynak_gid):
    with LeanForge(forge) as lf:
        if kaynak_gid not in lf.by_id:
            raise KeyError("Entry 0x%X is not in %s." % (kaynak_gid,
                                                         os.path.basename(forge)))
        _off, _ln, ext = lf.by_id[kaynak_gid]
        return lf.read_raw(kaynak_gid), int(ext)


def cogalt_plani(forge, kaynak_gid, yeni_ad):
    """SALT OKUMA: cogaltma mumkun mu, hangi kimlikle? Arsive tek bayt yazmaz."""
    r = {"ok": False, "forge": os.path.abspath(forge),
         "kaynak_gid": "0x%012X" % kaynak_gid, "yeni_ad": yeni_ad}
    sebep = ad_gecerli(yeni_ad)
    if sebep:
        r["mesaj"] = sebep
        return r
    try:
        raw, ext = _kaynak_oku(forge, kaynak_gid)
    except (KeyError, OSError, AssertionError) as e:
        r["mesaj"] = str(e)
        return r
    try:
        yeni_gid = yeni_kimlik(yeni_ad, forge)
        giris, bilgi = giris_kopyala(raw, kaynak_gid, yeni_gid, yeni_ad)
    except (ValueError, RuntimeError, KeyError) as e:
        r["mesaj"] = str(e)
        return r
    plan = KM.giris_ekle_plani(forge, yeni_gid, giris)
    r.update(plan)
    r.update(yeni_gid="0x%012X" % yeni_gid, yeni_gid_sayi=yeni_gid, ext="0x%08X" % ext,
             kaynak_gid="0x%012X" % kaynak_gid, yeni_ad=yeni_ad, bilgi=bilgi)
    return r


def cogalt(forge, kaynak_gid, yeni_ad, etiket=""):
    """Kaynak girisi YENI bir ad ve YENI bir kimlikle arsive EKLE (kopya olarak).

    Kaynak girise dokunulmaz. Geri alma (kur_mesh.geri_al) satiri kaldirir, sayaci
    eski degerine dondurur ve eklenen baytlari kirpar -> arsiv vanilla sha'ya doner.
    """
    r = {"ok": False}
    sebep = ad_gecerli(yeni_ad)
    if sebep:
        r["mesaj"] = sebep
        return r
    try:
        raw, ext = _kaynak_oku(forge, kaynak_gid)
        yeni_gid = yeni_kimlik(yeni_ad, forge)
        giris, bilgi = giris_kopyala(raw, kaynak_gid, yeni_gid, yeni_ad)
    except (KeyError, OSError, ValueError, RuntimeError, AssertionError) as e:
        r["mesaj"] = str(e)
        return r
    s = KM.giris_ekle(forge, yeni_gid, ext, giris, etiket=etiket,
                      kaynak_gid=kaynak_gid, icid=yeni_gid)
    s.setdefault("ok", False)
    s.update(yeni_gid="0x%012X" % yeni_gid, yeni_gid_sayi=yeni_gid,
             kaynak_gid="0x%012X" % kaynak_gid, yeni_ad=yeni_ad, bilgi=bilgi,
             ext="0x%08X" % ext)
    return s
