# -*- coding: utf-8 -*-
"""mod_kayit — KURULU MODLARIN DEFTERI: "ne kurdum, catisiyor mu, tek tikla kaldir".

Bugune kadar bir mod kurmak UC ayri yerde yapiliyordu (Outfits'in PNG eslestirmesi,
Ships'in klasor taramasi, Explorer'in geri koymasi) ve hicbiri "hangi modu kurdum"
sorusunu yanitlamiyordu. Kaldirma da mod basina degildi: `ship_mod_kaldir` YAMALI
BUTUN gemi hedeflerini geri aliyordu -- iki mod kuran kullanici birini kaldirinca
otekini de kaybediyordu. Bu modul o defteri tutar.

  NE YAPMAZ: forge'a TEK BAYT yazmaz. Yazmayi yapan, projedeki MEVCUT yazicilardir:
      mesh / ham  -> export3d.kur_mesh.kur / geri_al      (yedek + WAL + TOC + dogrulama)
      kiyafet     -> outfit_core.apply_outfit -> doku_enjekte2 (TEK YAZICI)
                     kaldirma: doku_enjekte2.gerial_secmeli (yalniz bu modun materyalleri)
      gemi        -> ship_core.uygula / geri_al
  Bu modul yalnizca SIRALAR, KAYDEDER, CATISMAYI ONCEDEN SOYLER ve GERI SARAR.
  Yazicilarin kapilarindan hicbiri kopyalanmaz, hicbiri gevsetilmez.

DEGISMEZ KURALLAR
  1. Oyun acikken kurma/kaldirma REDDEDILIR (yazicilar da reddeder; burada da
     reddedilir ki kullanici yarim is baslatmasin).
  2. `YAZMA_KILIDI` varsa yazma reddedilir (kur_mesh'in kilidiyle AYNI dosya).
  3. HEPSI YA DA HIC: bir oge patlarsa o ana kadar yazilan ogeler GERI ALINIR --
     BASARISIZ OGENIN KISMEN YAZDIGI DA. Yazma DENEMESI, tutamak gelmeden once
     kayda gecer (`_yazici_izi_al`), boylece hicbir tutamak dondurmeden bayt
     yazan bir yazici da geri sarilabilir. Geri sarmanin temiz oldugu
     SOYLENMEDEN once arsivin BOYUTU olculur (`_bayt_olc`); olcum tutmuyorsa
     "geri alindi" DENMEZ, ne kaldigi ve ne yapilacagi yazilir.
  4. CATISMA ONCEDEN: kurulacak plan, KURULU bir modun dokundugu girise dokunuyorsa
     kurulum ONCE reddedilir ve hangi modun dokundugu SOYLENIR. Catisma anahtari
     KALDIRMANIN taneciginde durur (kiyafette: materyal, slot DEGIL) -- daha ince
     bir anahtar "catisma yok" der, sonra bir modu kaldirmak otekini yok ederdi.
  5. KALDIRMA GERCEK OLSUN: kaldirmadan sonra arsivin BOYUTU olculur ve raporlanir
     (v0.13 dersi: "geri alindi" denip dosyanin buyumeye devam etmesi). Ayni
     yazmayla BIRLIKTE geri alinan baska modlar varsa defter onlari da
     "kaldirildi" yapar ve kullaniciya SOYLENIR.
  6. Kayit dosyasi kullanicinin Documents klasorunde, JSON, insan okuyabilir.
     Bozuksa uygulama COKMEZ: bozuk dosya kenara cekilir, defter bostan baslar.

AYRI FONKSIYON OLAN KAPILAR (`_yazma_kapisi`, `_catisma_kapisi`, `_geri_sar`,
`_yarim_temizle`, `_bayt_olc`)
  Kasten ayri: testler bunlari etkisiz hale getirip kapinin GERCEKTEN ayirt edici
  oldugunu olcer. (Ayni gerekce: kur_mesh._kayit_arsivle_tutuyor_mu.)

BIRLESIK HAZIR YAMA -- "forge_birlesik" (2026-09-08, Discord "Sparrow + QAR ayni anda")
  Oyun tek DataPC_boot_patch_02.forge tutar; iki hazir yama bugune kadar birbirini
  eziyordu. Yeni oge turu "forge_birlesik" N yamayi mod_birlestir (ACMB motoru)
  ile gecici bir klasorde TEK yamada birlestirir ve o dosyayi MEVCUT patch_02
  yazicisina (ADAPTORLER["forge"], yani sunucu._forge_kur_dosya) verir. Yeni
  yazici YOK: yedek adiyla alinir, kaldirma onceki yamayi geri koyar, defter
  kaynak yamalarin adlarini AYRI AYRI tutar (`kaynaklar`).
    catisma(): kurulu bir hazir yama varken yeni bir hazir yama gelirse tur
               "birlestirilebilir" -> "A ready-made patch is already installed
               (X). This one can be merged with it, or replace it."
    birlesik_plan(plan): "Merge" secenegi -- plani, kurulu yamayi kaynak alan
               tek bir forge_birlesik ogesine cevirir (yazmaz).
    kur(): boyle bir plan icin `ustune=True` ISTENMEZ; birlestirme bilincli
               bir secimdir ve ezilen degil ICINE ALINAN yama `birlesik_icinde`
               ile isaretlenir.
    kaldir(): birlesik yama kaldirilinca yazici onceki yamayi geri koyar; o yama
               defterde "ustune_yazildi" duruyorsa ve yazicinin dogrula'si
               "taze" derse yeniden "kurulu" olur (`geri_gelen`).
  Cakisan varlikta kural SONUNCU KAZANIR (mod_birlestir'de aciklandi).
"""
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
import time

__all__ = ["kur", "liste", "catisma", "kaldir", "dogrula", "unut", "birlesik_plan",
           "kayit_yolu", "kayit_yolu_ayarla", "oyun_acik_mi", "arsiv_olc",
           "KAYIT_SURUM", "FORGE_TURLERI"]

KAYIT_SURUM = 1
_VARSAYILAN_KAYIT = os.path.join(os.path.expanduser("~"), "Documents", "Workshop",
                                 "installed_mods.json")
_KAYIT = _VARSAYILAN_KAYIT


# --------------------------------------------------------------- kayit dosyasi
def kayit_yolu():
    return _KAYIT


def kayit_yolu_ayarla(yol=None):
    """Defterin yerini degistir (testler geciciye yonlendirir). Doner: yeni yol."""
    global _KAYIT
    _KAYIT = os.path.abspath(yol) if yol else _VARSAYILAN_KAYIT
    return _KAYIT


def _bos_defter():
    return {"surum": KAYIT_SURUM, "arac": "mod_kayit", "modlar": []}


def _defter_oku():
    """Doner (defter, bozuk_yol). ASLA istisna atmaz -- bozuk dosya uygulamayi cokertemez."""
    yol = _KAYIT
    if not os.path.isfile(yol):
        return _bos_defter(), None
    try:
        with io.open(yol, encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict) or not isinstance(d.get("modlar"), list):
            raise ValueError("shape")
        for m in d["modlar"]:
            if not isinstance(m, dict) or not isinstance(m.get("ogeler"), list):
                raise ValueError("shape")
        d.setdefault("surum", KAYIT_SURUM)
        return d, None
    except Exception:                                           # noqa: BLE001
        return _bos_defter(), yol


def _defter_yaz(defter, bozuk=None):
    """ATOMIK + fsync. Bozuk bir dosyanin ustune yazmadan once onu KENARA CEKER
    (silmeyiz: kullanicinin kaydi, adli inceleme icin durur)."""
    import tempfile
    kl = os.path.dirname(_KAYIT)
    if kl:
        os.makedirs(kl, exist_ok=True)
    if bozuk and os.path.isfile(bozuk):
        try:
            os.replace(bozuk, bozuk + ".damaged_" + time.strftime("%Y%m%d_%H%M%S"))
        except OSError:
            pass
    fd, gecici = tempfile.mkstemp(dir=kl or None, prefix=".installed_mods_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(defter, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(gecici, _KAYIT)
    except BaseException:
        try:
            os.remove(gecici)
        except OSError:
            pass
        raise
    return _KAYIT


def _mod_bul(defter, mod_id):
    for m in defter.get("modlar", []):
        if m.get("id") == mod_id:
            return m
    return None


def _yeni_mod_id(defter, plan):
    var = {m.get("id") for m in defter.get("modlar", [])}
    tohum = "%s|%s" % (plan.get("ad") or "", plan.get("kaynak") or "")
    taban = "%s_%s" % (time.strftime("%Y%m%d_%H%M%S"),
                       hashlib.sha256(tohum.encode("utf-8")).hexdigest()[:6])
    if taban not in var:
        return taban
    i = 2
    while "%s_%d" % (taban, i) in var:
        i += 1
    return "%s_%d" % (taban, i)


# --------------------------------------------------------------- ortak kapilar
def oyun_acik_mi():
    """Oyun calisiyor mu? Olcumu kur_mesh yapar (tasklist ciktisi BAYT olarak
    karsilastirilir; kod sayfasindan bagimsiz)."""
    try:
        return _km().oyun_acik_mi()
    except Exception:                                           # noqa: BLE001
        return False


def _yazma_kilidi():
    try:
        return _km().yazma_kilidi()
    except Exception:                                           # noqa: BLE001
        return None


def _kalip_metin(k):
    """{"t": "... {0} ...", "a": [...]} -> duz Ingilizce metin.

    Doldurma kurali sunucu.py `_duz_metin` ve arayuzdeki `msj()` ile BIREBIR
    ayni: {0}, {1} ... sirayla str()."""
    if not isinstance(k, dict) or not k.get("t"):
        return "" if k is None else str(k)
    s = str(k["t"])
    for i, d in enumerate(k.get("a") or []):
        s = s.replace("{%d}" % i, str(d))
    return s


def _yazma_kapisi_kalip():
    """Yazma kapisinin CEVRILEBILIR hali: {"t": ..., "a": [...]} ya da None.

    Cumleyi URETEN tek yer burasi. Ikiye ayirmanin sebebi olculdu: kilit
    cumlesi icinde bir DOSYA YOLU tasir, yani duz metin sozluge anahtar olarak
    giremez ve dort dilde de Ingilizce kaliyordu (kaptanin 2026-09-07 ekran
    goruntusundeki ucuncu satir)."""
    if oyun_acik_mi():
        return {"t": "The game is running. Close Assassin's Creed IV before "
                     "installing or removing a mod."}
    k = _yazma_kilidi()
    if k:
        return {"t": "Writing to the game files is locked on this computer by the "
                     "file {0}. Delete that file if you want to write again.",
                "a": [k]}
    return None


def _yazma_kapisi():
    """Yazmadan ONCE gecilmesi gereken kapilar. Sorun varsa INGILIZCE metin, yoksa None.

    AYRI FONKSIYON: testler bunu etkisiz hale getirip kapinin gercekten ayirt edici
    oldugunu olcer."""
    k = _yazma_kapisi_kalip()
    return _kalip_metin(k) if k else None


def _yazma_engeli():
    """Kapinin REDDI, sonuc sozlugune konulacak bicimde: {"mesaj", "mesaj_kalip"}
    ya da engel yoksa None.

    `kur()` ve `kaldir()` bunu kullanir. Testler de AYNI seyi olcsun diye ayri
    fonksiyon: aksi halde kapi urunun gonderdigi bicimi degil, bir alt katmani
    olcer ve "cevirdim" derken urunun Ingilizce kaldigini goremez (2026-09-07)."""
    kapi = _yazma_kapisi()
    if not kapi:
        return None
    return {"mesaj": kapi, "mesaj_kalip": _yazma_kapisi_kalip()}


# --------------------------------------------------------------- yardimcilar
def _log(progress, metin):
    if progress:
        try:
            progress(metin)
        except Exception:                                       # noqa: BLE001
            pass


def _sayi(x, varsayilan=None):
    """'0x02011D780FBA' / 2199... / None -> int. Cozulemezse varsayilan."""
    if x is None:
        return varsayilan
    if isinstance(x, int):
        return x
    t = str(x).strip()
    try:
        return int(t, 16) if t[:2].lower() == "0x" else int(t, 0)
    except ValueError:
        return varsayilan


def _bayt(n):
    return "{:,}".format(int(n)).replace(",", " ")


def arsiv_olc(yol):
    """Bir arsivin bugunku boyutu (bayt) ya da None."""
    try:
        return os.path.getsize(yol)
    except OSError:
        return None


def _km():
    from export3d import kur_mesh as KM
    return KM


def _varlik_adi(gid, icid=None):
    """Girisin INSAN OKUYABILIR adi (varlik_indeks'ten) ya da None."""
    try:
        import varlik_indeks as VI
        k = VI.kayit(gid, icid)
    except Exception:                                           # noqa: BLE001
        return None
    if not k:
        return None
    ad = (k.get("ad") or "").strip()
    return {"ad": ad or None, "sinif": k.get("sinif"), "forge": k.get("forge")}


# ============================================================ ADAPTORLER
# Her adaptor UC seyi bilir: bu oge NEYE dokunuyor (catisma anahtari), DUZ DILLE
# ne yapiyor (ozet), ve hangi MEVCUT yazici cagrilir. Yazma kurali TASINMAZ.

# ---------------------------------------------------------------- mesh / ham
def _mesh_coz(oge):
    """Oge -> (forge, gid, icid, ic_bayt). Eksik/bozuksa ValueError."""
    forge = oge.get("forge")
    if not forge:
        raise ValueError("This item does not say which game archive it belongs to.")
    forge = os.path.abspath(forge)
    gid = _sayi(oge.get("gid"))
    if gid is None:
        raise ValueError("This item does not say which game entry it replaces.")
    icid = _sayi(oge.get("icid"), gid)
    ic = oge.get("ic_bayt")
    if ic is None:
        yol = oge.get("ic_dosya")
        if not yol or not os.path.isfile(yol):
            raise ValueError("The replacement file for this item was not found: %s"
                             % (yol or "(no file given)"))
        with open(yol, "rb") as f:
            ic = f.read()
    return forge, gid, icid, bytes(ic)


def _mesh_anahtar(oge):
    forge, gid, _icid, _ic = _mesh_coz(oge)
    return ["archive:%s:0x%012X" % (_km()._forge_anahtari(forge), gid)]


def _mesh_arsivler(oge):
    return [_mesh_coz(oge)[0]]


def _mesh_ozet(oge):
    forge, gid, icid, _ic = _mesh_coz(oge)
    v = _varlik_adi(gid, icid)
    dosya = os.path.basename(forge)
    if v and v.get("ad"):
        tur = {"Mesh": "3D model", "Texture": "texture", "Material": "material"}.get(
            v.get("sinif"), (v.get("sinif") or "game entry"))
        return "Replaces the %s \"%s\" in %s." % (tur, v["ad"], dosya)
    return "Replaces the game entry 0x%012X in %s." % (gid, dosya)


def _mesh_kur(oge, progress=None, ustune=False):
    """ustune=True yalniz kullanici CATISMA uyarisini bilerek gectiginde gelir;
    kur_mesh'in kendi "Revert it first, or install over it on purpose" kapisi
    o karar olmadan ACILMAZ (olculdu: kapi olmadan ikinci kurulum reddediliyor)."""
    KM = _km()
    forge, gid, icid, ic = _mesh_coz(oge)
    _log(progress, "Installing: %s" % _mesh_ozet(oge))
    r = KM.kur(forge, gid, icid, ic, etiket=str(oge.get("etiket") or ""),
               yontem=oge.get("yontem") or "ek", ustune=bool(ustune))
    if not r.get("ok"):
        return {"ok": False, "mesaj": r.get("mesaj") or "The writer refused this item."}
    return {"ok": True, "tutamak": {"yazici": "kur_mesh", "kayit_id": r.get("kayit_id"),
                                    "forge": forge, "gid_sayi": gid, "icid_sayi": icid},
            "buyume": r.get("buyume"), "uyari": r.get("uyari")}


def _mesh_kaldir(tut, progress=None):
    KM = _km()
    _log(progress, "Undoing one change in %s..." % os.path.basename(tut.get("forge") or "?"))
    r = KM.geri_al(tut.get("kayit_id"))
    return {"ok": bool(r.get("ok")), "mesaj": r.get("mesaj"),
            "kuyruk_bayt": r.get("kuyruk_bayt")}


def _mesh_dogrula(tut):
    """Doner (durum, mesaj). durum: taze | bayat | kayip.

    Olcum kur_mesh'in KENDI kapisiyla yapilir (`_kayit_arsivle_tutuyor_mu`):
    kural kopyalanmaz."""
    KM = _km()
    forge = tut.get("forge") or ""
    gid = int(tut.get("gid_sayi") or 0)
    kid = tut.get("kayit_id")
    if not os.path.isfile(forge):
        return ("kayip", "The game archive %s was not found, so this change cannot be "
                         "checked." % os.path.basename(forge))
    g = None
    for x in KM._kayit_oku().get("girisler", []):
        if x.get("id") == kid:
            g = x
            break
    if g is None:
        return ("kayip", "This change is no longer listed in the tool's own patch record.")
    if g.get("durum") == "bayat":
        return ("bayat", "The game files changed after this was installed (a game update "
                         "or a Steam file verification), so this change is no longer in "
                         "the archive.")
    if g.get("durum") != "uygulandi":
        return ("kayip", "This change was already reverted or replaced by another patch.")
    try:
        _ti, _tp, off, ln, _ext, _satir = KM._toc_bilgi(forge, gid)
        ham = KM._giris_oku(forge, off, ln)
    except Exception as e:                                      # noqa: BLE001
        return ("bayat", "The archive no longer describes this entry (%s)." % str(e)[:120])
    if KM._kayit_arsivle_tutuyor_mu(g, KM._sha(ham)):
        return ("taze", "")
    return ("bayat", "The game archive no longer holds the bytes this mod wrote. The game "
                     "was most likely updated or its files were verified.")


# ---------------------------------------------------------------- kiyafet
def _outfit_core():
    import outfit_core as C
    return C


def _outfit_slotlari(oge):
    """[(mat_id_int, slot_idx)] — SALT OKUNUR, encode YOK, forge'a dokunmaz.

    Ogenin kendisi `slotlar` tasiyorsa o kullanilir (paketleyici cozmusse yeniden
    hesaplamayiz); yoksa outfit_core'un kendi aday cozucusu cagrilir."""
    acik = oge.get("slotlar")
    if acik:
        out = []
        for s in acik:
            m = _sayi(s.get("mat"))
            if m is not None and s.get("slot") is not None:
                out.append((m, int(s["slot"])))
        return out
    klasor = oge.get("klasor")
    if not klasor or not os.path.isdir(klasor):
        raise ValueError("The design folder for this item was not found: %s"
                         % (klasor or "(no folder given)"))
    C = _outfit_core()
    kaynak = C._design_kaynak(klasor)
    adaylar, _tani = C._design_adaylari(kaynak)
    # Klasorde oyunun kendi DDS biciminde doku da olabilir (topluluk modlarinin
    # cogu boyle dagitiliyor). Yalniz PNG sayilirsa defter o modun hangi
    # materyallere dokundugunu BILMEZ: catisma kapisi ve kaldirma yanlis calisir.
    if hasattr(C, "_design_dds_adaylari"):
        dds_adaylar, _dt = C._design_dds_adaylari(kaynak)
        adaylar = list(adaylar) + list(dds_adaylar)
    # `_design_adaylari` materyali HEX DIZE dondurur ("0x2201..."); catisma
    # anahtari ise "%X" ile bicimlenir, yani INT ister. Cevrilmezse bu yol
    # TypeError ile duserdi.
    out, goruldu = [], set()
    for a in adaylar:
        m = _sayi(a[1])
        if m is None:
            continue
        anahtar = (int(m), int(a[2]))
        if anahtar in goruldu:
            continue
        goruldu.add(anahtar)
        out.append(anahtar)
    return out


def _outfit_anahtar(oge):
    """CATISMA ANAHTARI = MATERYAL (slot DEGIL). Bu bir kisitlama degil, OLCUM.

    Kaldirmayi yapan `doku_enjekte2.gerial_secmeli` bir materyalin TOC satirini
    BUTUN halinde vanilla'ya dondurur; kaydi da materyal basina tutar (`gomulu`
    girisi `mat` ile anahtarlanir, slotlar onun icinde liste olarak birikir --
    dosyanin kendi kaynagindan okundu). Yani o yazicida SLOT BAZLI KALDIRMA
    YOKTUR: bir materyali geri alan, o materyalin butun slotlarini geri alir.

    Catisma anahtari kaldirmadan INCE olursa arac yalan soyler. OLCULDU
    (2026-09-07): A = ayni materyalin s0'i, B = s3'u; `catisma(B)` "var=False,
    This mod does not clash with anything you have installed." diyordu, ama
    A'yi kaldirmak B'nin baytlarini da vanilla'ya donduruyordu ve B defterde
    "kurulu" kaliyordu. Kapi bu yuzden KALDIRMANIN taneciginde durur.

    Neden ters yon (slot bazli kaldirma) secilmedi: kaldirmayi ince yapmak
    doku_enjekte2'yi degistirmeyi gerektirir -- o dosya bu isin kapsami disinda
    ve "kayittaki HER girisi dogrula, biri tutmazsa TEK BAYT yazma" kapisini
    gevsetmeden materyalin ortasindan bir slot cikarilamaz. Ince taneciklik
    KAYBOLMAZ: `_outfit_ince_anahtar` onu tasir ve catisma mesajinin "ustune
    yazilir" mi yoksa "birlikte geri alinir" mi dedigini belirler."""
    return sorted({"outfit:0x%X" % m for m, _s in _outfit_slotlari(oge)})


def _outfit_ince_anahtar(oge):
    """AYNI SLOT'a mi dokunuyor? Yalniz IKI is icin: (a) catisma mesajinin dogru
    cumleyi secmesi, (b) mod ICINDEKI kopya tespiti. KALDIRMA TANECIGI DEGILDIR."""
    return sorted({"outfit:0x%X:s%d" % (m, s) for m, s in _outfit_slotlari(oge)})


def _outfit_arsivler(_oge):
    try:
        return [_outfit_core().FORGE]
    except Exception:                                           # noqa: BLE001
        return []


def _gorunen_kiyafet_adi(mat, slot):
    """Materyal+slot -> kullanicinin bildigi kiyafet adi ("Edward Kenway's Robes").

    OLCULDU 2026-09-07 (gercek mod matrisi): burasi `_varlik_adi` kullaniyordu ve
    o, indeksin HAM VARLIK ADINI donduruyor -- kurulu modlar listesinde
    "Hood_EdwardKenway_Assassin", "Tunic_U_Edward_Legend_MAT" gibi MOTOR IC ADLARI
    goruntuyordu. Plan ekrani temizdi, defter kirliydi; ayni kusurun ikinci ekrani.

    Duz-dil katmani `mod_paket`te ZATEN var (outfit katalogunun `gorunen_ad`
    alani). Kurali buraya KOPYALAMIYORUZ, o katmani CAGIRIYORUZ -- iki yerde iki
    ad kurali olursa er gec ayrisirlar.
    """
    try:
        import mod_paket as MP
        slotlar = (MP._outfit_katalog() or {}).get("slotlar") or {}
        # `_mat_anahtar` HEX DIZE bekliyor; tamsayi verilirse ondalik yaziya cevirip
        # sessizce kacirir ("2351290091238"). Once hex bicimine sokuyoruz.
        anahtar = MP._mat_anahtar(mat if isinstance(mat, str) else "0x%X" % int(mat))
        kayitlar = slotlar.get((anahtar, int(slot))) or []
        if kayitlar:
            k = kayitlar[0]
            ad = (k or {}).get("gorunen_ad")
            if ad:
                return ad
    except Exception:                                           # noqa: BLE001
        pass
    # Katalogda yoksa HAM ADI DA YAZMAYIZ: motor ic adi kullaniciya bir sey
    # anlatmiyor ve tam da kacindigimiz sey. Kimlik daha durust.
    return "0x%X" % mat


def _outfit_ozet(oge):
    slot = _outfit_slotlari(oge)
    # Ad ARTIK (mat, slot) ciftinden cozuluyor: ayni materyalin farkli slotlari
    # farkli kiyafetlere ait olabilir (olculdu: 55 slot birden cok kiyafette).
    adlar = []
    for m, s in slot:
        ad = _gorunen_kiyafet_adi(m, s)
        if ad not in adlar:
            adlar.append(ad)
    gorunen = adlar[:4]
    ek = "" if len(adlar) <= 4 else " and %d more" % (len(adlar) - 4)
    return ("Repaints %d outfit texture slot(s) on: %s%s."
            % (len(slot), ", ".join(gorunen), ek))


# Kiyafet yazma kapisi: arayuz (v09_arayuz/sunucu.py) KENDI standart apply kapisini
# buraya takar -- `mod_kayit.OUTFIT_UYGULA = <callable(klasor, progress) -> dict>`.
# Boylece kapi dizisi (uygula_kontrol -> status_outfit -> base-shift 'safe' ->
# reddedilenler -> DE.uygula) TEK yerde kalir ve buraya KOPYALANMAZ. Takilmadiginda
# outfit_core'un kendi kapisi (`apply_outfit`, reddi RuntimeError olarak yukseltir)
# kullanilir; o da forge'a kendisi yazmaz, doku_enjekte2'yi cagirir.
OUTFIT_UYGULA = None


def _outfit_kur(oge, progress=None, ustune=False):
    C = _outfit_core()
    klasor = oge.get("klasor")
    if not klasor or not os.path.isdir(klasor):
        return {"ok": False, "mesaj": "The design folder for this item was not found."}
    _log(progress, "Installing: %s" % _outfit_ozet(oge))
    slot = _outfit_slotlari(oge)
    kapi = OUTFIT_UYGULA if callable(OUTFIT_UYGULA) else C.apply_outfit
    try:
        r = kapi(klasor, progress=progress) or {}
    except Exception as e:                                      # noqa: BLE001
        return {"ok": False, "mesaj": str(e)[:300]}
    if r.get("red_sebep"):
        return {"ok": False, "mesaj": r["red_sebep"]}
    yazilan = int(r.get("yazilan_giris") or 0) or (int(r.get("harici", 0))
                                                   + int(r.get("gomulu", 0)))
    if not yazilan:
        return {"ok": False, "mesaj": "Nothing was written for this item."}
    return {"ok": True, "tutamak": {"yazici": "doku_enjekte2",
                                    "matler": sorted({"0x%X" % m for m, _s in slot}),
                                    "yazilan": yazilan}}


def _outfit_kaldir(tut, progress=None):
    C = _outfit_core()
    _log(progress, "Undoing the outfit textures of this mod...")
    try:
        r = C.DE.gerial_secmeli(tut.get("matler") or []) or {}
    except Exception as e:                                      # noqa: BLE001
        return {"ok": False, "mesaj": str(e)[:300]}
    if r.get("red_sebep"):
        return {"ok": False, "mesaj": r["red_sebep"]}
    return {"ok": True, "geri_alinan": r.get("geri_alindi"), "kalan": r.get("kalan")}


def _outfit_dogrula(tut):
    C = _outfit_core()
    try:
        d = C.DE.gerial_dagilim() or {}
    except Exception as e:                                      # noqa: BLE001
        return ("bayat", "The outfit patch record could not be read (%s)." % str(e)[:120])
    if not d.get("kayit"):
        return ("kayip", "The outfit patch record is empty, so these textures are no "
                         "longer installed.")
    var = {str(k).lstrip("0").upper() for k in (d.get("materyaller") or {}).keys()}
    ister = set()
    for m in tut.get("matler") or []:
        v = _sayi(m)
        if v is not None:
            ister.add(("%X" % v).lstrip("0").upper() or "0")
    eksik = sorted(ister - var)
    if eksik:
        return ("kayip", "%d of this mod's outfit textures are no longer in the patch "
                         "record." % len(eksik))
    return ("taze", "")


# ---------------------------------------------------------------- gemi
def _ship_core():
    import ship_core as SC
    if not SC.bagli_mi():
        raise RuntimeError("The Ships engine is not connected to a game folder yet.")
    return SC


def _ship_anahtar(oge):
    a = oge.get("anahtar")
    if not a:
        raise ValueError("This ship item does not say which target it paints.")
    return ["ship:%s" % a]


def _ship_arsivler(oge):
    try:
        SC = _ship_core()
        h = SC.hedef_bul(oge.get("anahtar"))
        kok = SC._D.get("oyun")
        if kok and h.get("forge"):
            return [os.path.join(kok, h["forge"])]
    except Exception:                                           # noqa: BLE001
        pass
    return []


# Motor ici adlarin imzasi. `test_gercek_mod_matrisi.TEKNIK_IZ` ile ayni ruh:
# ham kimlik, export adi, doku kimligi, motor son ekleri, ic alan adlari.
_MOTOR_IZI = re.compile(
    r"(?i)"                        # tumu buyuk/kucuk harf duyarsiz
    r"0x[0-9A-Fa-f]{6,}"           # 0x22D9...
    r"|\bIC_[0-9A-Fa-f]{6,}"       # IC_00A1B2...
    r"|\btm[0-9A-Fa-f]{8,}"        # tm0012ABCD
    r"|\d+x\d+_BC\d"              # 1024x1024_BC3
    r"|_diffusemap|_normalmap|_specularmap|_emissivemap"
    r"|\bmat_id\b|\bslot_idx\b|\bgid\b"
    r"|\bOBD_[A-Z]{3}_")           # OBD_SHP_...


def _gorunen_gemi_adi(anahtar):
    """Gemi hedef anahtari -> kullanicinin anlayacagi ifade ("a ship's hull").

    OLCULDU 2026-09-08 (gercek mod matrisi, dogrulama turu): kiyafet yolunu
    duzelttim ama GEMI yolunu atlamistim; defterde
    "OBD_SHP_Decal_Wood_Damage_01_DiffuseMap" goruntuyordu -- ayni kusurun ucuncu
    ekrani. Duz-dil katmani `mod_paket`te var (`_gemi_aciklama_kalip`), kurali
    kopyalamiyoruz, CAGIRIYORUZ.
    """
    try:
        import mod_paket as MP
        h = (MP._ship_katalog() or {}).get(str(anahtar or "").lower())
        if h:
            return MP.kalip_metin(MP._gemi_aciklama_kalip(h))
    except Exception:                                           # noqa: BLE001
        pass
    return None


def _ship_ozet(oge):
    anahtar = oge.get("anahtar")
    ad = _gorunen_gemi_adi(anahtar)
    if ad:
        # Ifadeler TEK BASINA duracak sekilde yazilmis ("A ship's hull", "The
        # Jackdaw's captain's cabin"); cumleye gomerken artikel kucuk harfe iner,
        # yoksa "Repaints A ship's hull." cikar.
        # NOT (v0.15): kalici cozum bu ozeti de KALIP+ARGUMAN yapmak -- o zaman
        # cumleyi ceviren dil kurar ve artikel sorunu dile ozel kalmaz.
        for artikel in ("A ", "An ", "The "):
            if ad.startswith(artikel):
                ad = artikel.lower() + ad[len(artikel):]
                break
        return "Repaints %s." % ad
    # ---- GERI DUSUS: katalogda yok --------------------------------------
    # Anahtari HAM basmak, matrisin yakaladigi sizintiyi katalogun ARKASINA
    # saklamak olurdu: katalog disi tek bir hedef onu geri getirirdi. Anahtar
    # yalniz motor izi TASIMIYORSA gosterilir; tasiyorsa hic gosterilmez.
    a = str(anahtar or "").strip()
    if not a:
        return "Repaints a ship part."
    if _MOTOR_IZI.search(a):
        return "Repaints a ship part."
    return "Repaints the ship part \"%s\"." % a


def _ship_kur(oge, progress=None, ustune=False):
    try:
        SC = _ship_core()
    except RuntimeError as e:
        return {"ok": False, "mesaj": str(e)}
    png = oge.get("png")
    if not png or not os.path.isfile(png):
        return {"ok": False, "mesaj": "The image file for this ship item was not found."}
    _log(progress, "Installing: %s" % _ship_ozet(oge))
    r = SC.uygula(oge["anahtar"], png, alfa=oge.get("alfa") or "auto",
                  gunluk=progress) or {}
    if not r.get("ok"):
        return {"ok": False, "mesaj": r.get("mesaj") or "The writer refused this item."}
    return {"ok": True, "tutamak": {"yazici": "ship_core", "anahtar": oge["anahtar"]}}


def _ship_kaldir(tut, progress=None):
    try:
        SC = _ship_core()
    except RuntimeError as e:
        return {"ok": False, "mesaj": str(e)}
    r = SC.geri_al(tut.get("anahtar"), gunluk=progress) or {}
    return {"ok": bool(r.get("ok")), "mesaj": r.get("mesaj")}


def _ship_dogrula(tut):
    try:
        SC = _ship_core()
    except RuntimeError as e:
        return ("bayat", str(e))
    try:
        if tut.get("anahtar") in SC.yamali_hedefler():
            return ("taze", "")
    except Exception as e:                                      # noqa: BLE001
        return ("bayat", "The ship patch record could not be read (%s)." % str(e)[:120])
    return ("kayip", "This ship texture is no longer patched.")


ADAPTORLER = {
    "mesh":   {"anahtar": _mesh_anahtar, "ozet": _mesh_ozet, "kur": _mesh_kur,
               "kaldir": _mesh_kaldir, "dogrula": _mesh_dogrula, "arsivler": _mesh_arsivler},
    # "ham" (Explorer'in geri koydugu ic dosya) AYNI TOC girisine dokunur; ayni
    # adaptor kullanilir ki mesh <-> ham catismasi GORULEBILSIN.
    "ham":    {"anahtar": _mesh_anahtar, "ozet": _mesh_ozet, "kur": _mesh_kur,
               "kaldir": _mesh_kaldir, "dogrula": _mesh_dogrula, "arsivler": _mesh_arsivler},
    # "ince": catisma anahtarindan DAHA INCE bir kimlik varsa. Yalniz kiyafette
    # var (materyal vs. slot); otekilerde yazicinin geri alma tanecigi zaten
    # girisin kendisidir, yani ince = kaba.
    "outfit": {"anahtar": _outfit_anahtar, "ince": _outfit_ince_anahtar,
               "ozet": _outfit_ozet, "kur": _outfit_kur,
               "kaldir": _outfit_kaldir, "dogrula": _outfit_dogrula,
               "arsivler": _outfit_arsivler},
    "ship":   {"anahtar": _ship_anahtar, "ozet": _ship_ozet, "kur": _ship_kur,
               "kaldir": _ship_kaldir, "dogrula": _ship_dogrula, "arsivler": _ship_arsivler},
}


def _adaptor(tur):
    a = ADAPTORLER.get(str(tur or "").lower())
    if a is None:
        raise ValueError("This mod contains an item of an unknown kind (%r). The tool "
                         "does not know how to install it." % tur)
    return a


# ====================================================== BIRLESIK HAZIR YAMA
# "forge_birlesik": N hazir yamayi (patch_02) mod_birlestir ile TEK dosyada
# birlestirir, sonra MEVCUT hazir yama yazicisina verir. Yazici ADAPTORLER["forge"]
# olarak sunucu tarafindan CALISMA ANINDA takilir (sunucu._forge_adaptoru); bu
# yuzden asagidaki fonksiyonlar onu cagri aninda arar, import aninda degil.
FORGE_TURLERI = frozenset(("forge", "forge_birlesik"))


def _mb():
    import mod_birlestir as MB
    return MB


def _forge_yazicisi():
    a = ADAPTORLER.get("forge")
    if a is None:
        raise ValueError("Ready-made patches cannot be installed from here: the patch "
                         "writer is not connected.")
    return a


def _birlesik_kaynaklar(oge):
    """oge["kaynaklar"]: [yol | {dosya, ad, kaynak, adlar, kurulu_mod_id}] -> [dict].

    Ad verilmemisse ust klasorden turetilir (mod_birlestir ayni kurali uygular)."""
    ks = (oge or {}).get("kaynaklar") or []
    out = []
    for k in ks:
        if isinstance(k, str):
            k = {"dosya": k}
        if not isinstance(k, dict) or not k.get("dosya"):
            raise ValueError("One of the patches to combine has no file.")
        d = dict(k)
        d["dosya"] = os.path.abspath(str(k["dosya"]))
        if not d.get("ad"):
            ust = os.path.basename(os.path.dirname(d["dosya"]))
            d["ad"] = ust or os.path.splitext(os.path.basename(d["dosya"]))[0]
        out.append(d)
    if len(out) < 2:
        raise ValueError("A combined patch needs at least two patches.")
    return out


def _birlesik_adlar(kaynaklar):
    """Defterde gorunecek adlar; onceki bir birlesim (`adlar`) parcalarina acilir."""
    adlar = []
    for k in kaynaklar:
        for ad in (k.get("adlar") or [k.get("ad")]):
            if ad and str(ad) not in adlar:
                adlar.append(str(ad))
    return adlar


def _birlesik_anahtar(oge):
    """Catisma anahtari = hazir yama yazicisininki (yuva TEKTIR). Once kaynaklar
    ACMB'nin kapisindan gecer (yapisal dogrulama + sistem girisi seti); gecemeyen
    plan icin TEK BAYT yazilmaz."""
    a = _forge_yazicisi()
    ks = _birlesik_kaynaklar(oge)
    plan = _mb().birlestir_plani(ks)
    if not plan.get("ok"):
        raise ValueError(plan.get("mesaj") or "These patches cannot be combined.")
    # Kurulu yamanin KENDISI kaynak olabilir ("Merge" yolu); yazicinin dosya
    # denetimi onu "That IS the installed patch" diye reddeder -- anahtar YENI
    # bir kaynaktan alinir.
    hedefler = {os.path.normcase(os.path.abspath(y))
                for y in (a["arsivler"](oge) or []) if y}
    yeni = [k for k in ks if os.path.normcase(k["dosya"]) not in hedefler]
    if not yeni:
        raise ValueError("Every patch in this list is the one already installed; there "
                         "is nothing new to combine.")
    return list(a["anahtar"]({"dosya": yeni[0]["dosya"], "kaynak": yeni[0].get("kaynak")}))


def _birlesik_ozet(oge):
    adlar = _birlesik_adlar(_birlesik_kaynaklar(oge))
    return ("Combines %d ready-made patches into one (%s)."
            % (len(adlar), " + ".join(adlar)))


def _birlesik_arsivler(oge):
    return _forge_yazicisi()["arsivler"](oge)


def _birlesik_kur(oge, progress=None, ustune=False):
    """Birlestir (gecici klasor) -> mevcut yaziciya ver -> gecici sil.

    Tutamak yazicinin tutamagidir (yedek, durum_once, sha) + `birlesik` bolumu.
    Yazici ustune yazmadan once yerindeki yamayi ADIYLA yedekler; kaldirma o
    yedegi geri koyar -- birlesik yama icin de ayni yol."""
    a = _forge_yazicisi()
    MB = _mb()
    ks = _birlesik_kaynaklar(oge)
    adlar = _birlesik_adlar(ks)
    gecici = tempfile.mkdtemp(prefix="Workshop_combined_patch_")
    try:
        cikti = os.path.join(gecici, MB.birlesik_dosya_adi(adlar))
        r = MB.birlestir(ks, cikti, progress=progress)
        if not r.get("ok"):
            return {"ok": False, "mesaj": r.get("mesaj") or
                    "The patches could not be combined."}
        s = a["kur"]({"dosya": cikti, "kaynak": os.path.basename(cikti)},
                     progress, ustune=ustune) or {}
        if not s.get("ok"):
            return s
        t = dict(s.get("tutamak") or {})
        t["birlesik"] = {"kaynaklar": adlar, "sha256": r.get("sha256"),
                         "giris_sayisi": r.get("giris_sayisi"),
                         "catisan": r.get("catisan") or []}
        return {"ok": True, "tutamak": t, "mesaj": s.get("mesaj"),
                "kaynaklar": adlar, "uyari": r.get("uyari") or ""}
    finally:
        shutil.rmtree(gecici, ignore_errors=True)


def _birlesik_kaldir(tut, progress=None):
    return _forge_yazicisi()["kaldir"](tut, progress)


def _birlesik_dogrula(tut):
    return _forge_yazicisi()["dogrula"](tut)


ADAPTORLER["forge_birlesik"] = {
    "anahtar": _birlesik_anahtar, "ince": _birlesik_anahtar, "ozet": _birlesik_ozet,
    "kur": _birlesik_kur, "kaldir": _birlesik_kaldir, "dogrula": _birlesik_dogrula,
    "arsivler": _birlesik_arsivler}


def _birlesik_kaynak_idleri(ogeler):
    """Plandaki birlesik ogelerin KURULU bir modu kaynak olarak aldigi mod id'leri."""
    idler = set()
    for o in ogeler or []:
        if o.get("tur") != "forge_birlesik":
            continue
        for k in o.get("kaynaklar") or []:
            if isinstance(k, dict) and k.get("kurulu_mod_id"):
                idler.add(k["kurulu_mod_id"])
    return idler


def _kurulu_forge_ogesi(m):
    """Bir mod kaydinin KURULU hazir yama ogesi (ya da None)."""
    for o in (m or {}).get("ogeler") or []:
        if o.get("durum") == "kurulu" and o.get("tur") in FORGE_TURLERI:
            return o
    return None


# ============================================================ CATISMA
def _plan_ogeleri(plan):
    o = (plan or {}).get("ogeler") or []
    if not isinstance(o, list):
        raise ValueError("This mod's item list is not in the expected shape.")
    return o


def _ince_anahtarlar(a, oge):
    """Adaptorun INCE kimligi; yoksa kaba anahtarin kendisi."""
    f = a.get("ince")
    return list(f(oge)) if f else list(a["anahtar"](oge))


def _plan_anahtarlari(plan):
    """[(indeks, oge, [kaba...], [ince...], ozet, hata)] — forge'a DOKUNMAZ."""
    out = []
    for i, oge in enumerate(_plan_ogeleri(plan)):
        try:
            a = _adaptor(oge.get("tur"))
            anah = list(a["anahtar"](oge))
            ince = _ince_anahtarlar(a, oge)
            try:
                ozet = a["ozet"](oge)
            except Exception:                                   # noqa: BLE001
                ozet = "Changes one part of the game."
            out.append((i, oge, anah, ince, ozet, None))
        except Exception as e:                                  # noqa: BLE001
            out.append((i, oge, [], [], "", str(e)[:300]))
    return out


def _kurulu_anahtarlar(defter=None):
    """kaba anahtar -> {mod_id, mod_ad, ozet, ince} (yalniz KURULU modlar).

    `ince` bos olabilir: bu alani tasimayan ESKI defter kayitlari icin ince
    kimlik BILINMIYOR demektir. O durumda catisma mesaji daha GUCLU olan
    "ustune yazilir" cumlesini secer -- bilmedigimiz seyi "zararsiz" saymayiz."""
    d = defter if defter is not None else _defter_oku()[0]
    harita = {}
    for m in d.get("modlar", []):
        if m.get("durum") != "kurulu":
            continue
        for o in m.get("ogeler", []):
            if o.get("durum") != "kurulu":
                continue
            for a in o.get("anahtarlar") or []:
                harita.setdefault(a, {"mod_id": m.get("id"), "mod_ad": m.get("ad"),
                                      "ozet": o.get("ozet"), "tur": o.get("tur"),
                                      "kaynaklar": list(o.get("kaynaklar") or ()),
                                      "ince": set(o.get("ince_anahtarlar") or ())})
    return harita


def _catisma_kapisi(plan, defter=None):
    """KURULMADAN ONCE: bu plan, kurulu bir modun dokundugu girise dokunuyor mu?

    Karsilastirma KABA (= kaldirma tanecigi) anahtarla yapilir; ince anahtar
    yalnizca hangi CUMLENIN dogru oldugunu secer:
      tur="ustune"   : ayni ince kimlik -> yeni mod eskisinin ustune yazar.
      tur="birlikte" : ayni giris, farkli parca -> ikisi de yasar ama yazici o
                       girisi butun halinde geri alir, yani birini kaldirmak
                       otekini de geri alir.
      tur="birlestirilebilir" : kurulu bir HAZIR YAMA varken yeni bir hazir yama
                       geliyor -> ikisi tek yamada BIRLESTIRILEBILIR (mod_birlestir)
                       ya da yenisi eskisinin yerine gecer. Karar kullanicinin.

    AYRI FONKSIYON: testler bunu etkisiz hale getirip kapinin gercekten ayirt edici
    oldugunu olcer."""
    kurulu = _kurulu_anahtarlar(defter)
    disari, gorulen = [], {}
    ic = []
    for i, oge, anahtarlar, ince, ozet, hata in _plan_anahtarlari(plan):
        if hata:
            continue
        ince_kume = set(ince)
        for a in anahtarlar:
            v = kurulu.get(a)
            if not v:
                continue
            ad = v["mod_ad"] or v["mod_id"]
            birlikte = bool(v["ince"]) and bool(ince_kume) and not (v["ince"] & ince_kume)
            birlesir = (v.get("tur") in FORGE_TURLERI
                        and (oge or {}).get("tur") in FORGE_TURLERI)
            if birlesir:
                # Yama yuvasi TEKTIR; ama iki yama tek dosyada BIRLESTIRILEBILIR.
                # Kurulu yama zaten bir birlesimse adlari ayri ayri soylenir.
                icindekiler = v.get("kaynaklar") or []
                gosterilen = (" + ".join(icindekiler)
                              if len(icindekiler) > 1 else ad)
                tur = "birlestirilebilir"
                mesaj = ("A ready-made patch is already installed (%s). This one can be "
                         "merged with it, or replace it." % gosterilen)
            elif birlikte:
                tur = "birlikte"
                mesaj = ("The mod \"%s\" changes a different part of the same outfit: "
                         "%s Both can be installed, but this tool puts an outfit back "
                         "in one piece, so removing either mod would also undo the "
                         "other." % (ad, (v["ozet"] or a)))
            else:
                tur = "ustune"
                mesaj = ("The mod \"%s\" already changes this part of the game: %s "
                         "If you install this one on top, the change from \"%s\" is "
                         "overwritten." % (ad, (v["ozet"] or a), ad))
            disari.append({
                "anahtar": a, "oge": i, "ozet": ozet,
                "mod_id": v["mod_id"], "mod_ad": v["mod_ad"],
                "tur": tur, "mesaj": mesaj})
        # Mod ICI kopya INCE anahtarla aranir: ayni materyalin FARKLI slotlarina
        # dokunan iki dosya birbirini ezmez, ikisi de yasar. Kaba anahtarla
        # bakmak burada YANLIS uyari verirdi.
        for a in ince:
            if a in gorulen:
                ic.append({"anahtar": a, "oge": i, "oteki_oge": gorulen[a],
                           "mesaj": "Two files in this mod change the same part of the "
                                    "game; only the last one would survive."})
            else:
                gorulen[a] = i
    return disari, ic


def _catisma_ozeti(disari, ic, kuyruk=""):
    """Catisma listesinden KULLANICI cumlesi. `kuyruk` sonuna eklenir."""
    ust = [c for c in disari if c.get("tur") not in ("birlikte", "birlestirilebilir")]
    bir = [c for c in disari if c.get("tur") == "birlikte"]
    yama = [c for c in disari if c.get("tur") == "birlestirilebilir"]
    parcalar = []
    if ust and bir:
        parcalar.append("%d change(s) in this mod would overwrite a mod you already have "
                        "installed, and %d more change the same outfit as one, so the "
                        "two could not be removed separately." % (len(ust), len(bir)))
    elif ust:
        parcalar.append("%d change(s) in this mod would overwrite a mod you already have "
                        "installed." % len(ust))
    elif bir:
        parcalar.append("%d change(s) in this mod change the same outfit as a mod you "
                        "already have installed, so the two could not be removed "
                        "separately." % len(bir))
    if yama:
        # Yuva tek oldugu icin butun yama catismalari AYNI kurulu yamayi soyler;
        # cumle bir kez yeter.
        parcalar.append(yama[0]["mesaj"])
    if parcalar:
        return " ".join(parcalar) + kuyruk
    if ic:
        return "This mod changes the same part of the game more than once."
    return "This mod does not clash with anything you have installed."


def _birlestirilebilir_bilgi(disari, defter):
    """"Merge" secenegi icin arayuze gereken her sey (SALT OKUNUR):
    {var, mod_id, mod_ad, kaynaklar, dosya, taze, mesaj}"""
    c = next((x for x in disari if x.get("tur") == "birlestirilebilir"), None)
    if not c:
        return {"var": False}
    m = _mod_bul(defter, c.get("mod_id"))
    o = _kurulu_forge_ogesi(m)
    if not m or not o:
        return {"var": False}
    tut = o.get("tutamak") or {}
    try:
        d, _msj = _adaptor(o.get("tur"))["dogrula"](tut)
    except Exception:                                           # noqa: BLE001
        d = "bayat"
    adlar = list(o.get("kaynaklar") or [m.get("ad") or m.get("id")])
    return {"var": True, "mod_id": m.get("id"), "mod_ad": m.get("ad"),
            "kaynaklar": adlar, "dosya": tut.get("hedef"), "taze": d == "taze",
            "mesaj": c.get("mesaj")}


def catisma(plan):
    """Bu plan kurulursa nereye carpar? SALT OKUNUR, forge'a tek bayt yazmaz.

    Doner: {ok, var, catismalar[], ic_catismalar[], sorunlu_ogeler[], mesaj}"""
    try:
        anahtarlar = _plan_anahtarlari(plan)
    except Exception as e:                                      # noqa: BLE001
        return {"ok": False, "var": False, "catismalar": [], "ic_catismalar": [],
                "sorunlu_ogeler": [], "mesaj": str(e)[:300]}
    defter, bozuk = _defter_oku()
    disari, ic = _catisma_kapisi(plan, defter)
    sorunlu = [{"oge": i, "mesaj": h} for i, _o, _a, _n, _z, h in anahtarlar if h]
    mesaj = _catisma_ozeti(disari, ic)
    return {"ok": True, "var": bool(disari), "catismalar": disari, "ic_catismalar": ic,
            "sorunlu_ogeler": sorunlu, "defter_bozuktu": bool(bozuk), "mesaj": mesaj,
            "birlestirilebilir": _birlestirilebilir_bilgi(disari, defter)}


def birlesik_plan(plan):
    """"MERGE" SECENEGI: bu plani, KURULU hazir yamayla BIRLESTIREN plana cevir.

    SALT OKUNUR, yazmaz. Planin hazir yama ogeleri (forge / forge_birlesik) tek
    bir forge_birlesik ogesinde toplanir; ilk kaynak KURULU yamanin oyundaki
    dosyasidir (kurulu_mod_id ile), ardindan yeni yamalar gelir -- yani cakisan
    varlikta YENI yama kazanir (SONUNCU KAZANIR). Oteki ogeler (kiyafet, gemi)
    oldugu gibi kalir.

    Doner: {ok, plan, mesaj, kaynaklar}. Kurulu yama yoksa ya da artik oyunda
    duran dosya o degilse (bayat) ok=False ve ne yapilacagi soylenir."""
    try:
        ogeler = _plan_ogeleri(plan)
    except Exception as e:                                      # noqa: BLE001
        return {"ok": False, "mesaj": str(e)[:300]}
    yama_ogeleri = [(i, o) for i, o in enumerate(ogeler) if o.get("tur") in FORGE_TURLERI]
    if not yama_ogeleri:
        return {"ok": False, "mesaj": "This mod has no ready-made patch to combine."}
    defter, _bozuk = _defter_oku()
    disari, _ic = _catisma_kapisi(plan, defter)
    b = _birlestirilebilir_bilgi(disari, defter)
    if not b.get("var"):
        return {"ok": False, "mesaj": ("No ready-made patch is installed, so there is "
                                       "nothing to combine with. Install this mod as "
                                       "it is.")}
    if not b.get("taze") or not b.get("dosya") or not os.path.isfile(b["dosya"]):
        return {"ok": False, "mesaj": ("The patch on the list (\"%s\") is no longer the "
                                       "one in the game folder, so it cannot be "
                                       "combined. Remove it from the list first, or "
                                       "install this one over it." % b.get("mod_ad"))}
    kaynaklar = [{"dosya": b["dosya"], "ad": " + ".join(b["kaynaklar"]),
                  "adlar": list(b["kaynaklar"]), "kurulu_mod_id": b["mod_id"],
                  "kaynak": "the patch that is installed now"}]
    gorulen = set(b["kaynaklar"])
    for i, o in yama_ogeleri:
        if o.get("tur") == "forge_birlesik":
            for k in _birlesik_kaynaklar(o):
                kaynaklar.append(dict(k))
            continue
        ad = str(o.get("ad") or plan.get("ad") or
                 os.path.splitext(os.path.basename(str(o.get("dosya") or "patch")))[0])
        taban, n = ad, 2
        while ad in gorulen:
            ad = "%s (%d)" % (taban, n)
            n += 1
        gorulen.add(ad)
        kaynaklar.append({"dosya": o.get("dosya"), "ad": ad, "kaynak": o.get("kaynak")})
    adlar = _birlesik_adlar(kaynaklar)
    yeni = dict(plan)
    # Kaydin adi ICINDEKILERI soyler ("Captain Jack Sparrow + Black Beard"):
    # listede "Black Beard" diye duran bir satirin aslinda Sparrow'u da tuttugu
    # ancak boyle gorunur. Planin kendi adi `kaynak_ad` olarak saklanir.
    yeni["kaynak_ad"] = plan.get("ad")
    yeni["ad"] = " + ".join(adlar)
    yeni["ogeler"] = ([o for o in ogeler if o.get("tur") not in FORGE_TURLERI]
                      + [{"tur": "forge_birlesik", "kaynaklar": kaynaklar,
                          "kaynak": " + ".join(adlar)}])
    return {"ok": True, "plan": yeni, "kaynaklar": adlar,
            "mesaj": ("The patch \"%s\" will be combined with the one that is installed "
                      "(%s). Where both change the same part of the game, the new one "
                      "wins." % (plan.get("ad") or "this mod", " + ".join(b["kaynaklar"])))}


# ====================================================== YAZICI IZI (yarim yazim)
# "HEPSI YA DA HIC"in en kolay kacirilan yarisi: bir oge {"ok": False} donerse
# bunun anlami "hicbir sey yazilmadi" DEGILDIR. Yazicilar giris giris / materyal
# materyal yazar (doku_enjekte2._uygula tam olarak boyle calisir) ve ortasinda
# durabilir. Tutamak ise yalnizca BASARILI ogeden gelir -- yani basarisiz ogenin
# arsivde biraktigi baytin adresi elimizde OLMAZ.
#
# OLCULDU (2026-09-07, kum havuzu = DataPC_WhiteRoom.forge kopyasi): bayt yazip
# sonra {"ok": False} donen TEK ogeli bir plan icin geri sarma listesi bos
# kaliyordu (`{temiz: True, ayrinti: []}`), arac "the game is back to how it was"
# diyordu ve arsiv 38 814 bayt BUYUK kaliyordu; defterde de kullanicinin
# kaldirabilecegi bir kayit yoktu.
#
# COZUM: her yazma DENEMESINDEN once YAZICILARIN KENDI defterlerinin fotografi
# cekilir; deneme patlarsa fotograftan SONRA beliren girisler geri alinir. Bu
# yontem adaptorun ne dondurdugune BAKMAZ -- adaptoru hic tanimasak bile yaziciyi
# cagirdiysa izi yakalanir. Kural 7 gecerli: yazma yine YAZICININ kendi geri alma
# yolundan yapilir, burada tek bayt yazilmaz.
def _iz_kur_mesh(_zorla=False):
    """kur_mesh'in defterindeki CANLI giris kimlikleri (ya da None = bilinmiyor)."""
    try:
        return {x.get("id") for x in _km()._kayit_oku().get("girisler", [])
                if x.get("durum") in ("uygulandi", "yarim", "yaziliyor")}
    except Exception:                                           # noqa: BLE001
        return None


def _iz_outfit(zorla=False):
    """doku_enjekte2'nin kayitindaki materyal dagilimi (ya da None).

    outfit_core hic yuklenmediyse o yazici bu surecte YAZAMAZ; agir modulu
    yalnizca izlemek icin yuklemeyiz (plan kiyafet iceriyorsa `zorla` gelir)."""
    if not zorla and "outfit_core" not in sys.modules:
        return None
    try:
        d = _outfit_core().DE.gerial_dagilim() or {}
    except Exception:                                           # noqa: BLE001
        return None
    if not d.get("kayit"):
        return {}
    return {k: dict(v) for k, v in (d.get("materyaller") or {}).items()}


def _iz_ship(zorla=False):
    """ship_core'un YAMALI hedefleri (ya da None)."""
    if not zorla and "ship_core" not in sys.modules:
        return None
    try:
        return set(_ship_core().yamali_hedefler())
    except Exception:                                           # noqa: BLE001
        return None


def _yazici_izi_al(turler=()):
    """Yazmadan ONCE: her yazicinin kendi defterinin fotografi.

    AYRI FONKSIYON: testler bunu etkisiz hale getirip kapinin gercekten ayirt
    edici oldugunu olcer."""
    t = {str(x or "").lower() for x in (turler or ())}
    return {"kur_mesh": _iz_kur_mesh(),
            "outfit": _iz_outfit("outfit" in t),
            "ship": _iz_ship("ship" in t)}


def _temizle_kur_mesh(once, progress=None):
    """Fotograftan SONRA beliren kur_mesh girislerini TERS SIRADA geri al."""
    if once is None:
        return None                     # fotograf yok -> iddia da yok
    KM = _km()
    try:
        yeni = [x for x in KM._kayit_oku().get("girisler", [])
                if x.get("durum") in ("uygulandi", "yarim", "yaziliyor")
                and x.get("id") not in once]
    except Exception as e:                                      # noqa: BLE001
        return [{"yazici": "kur_mesh", "ok": False, "tutamak": None, "tur": "mesh",
                 "mesaj": "The tool's own patch record could not be read (%s)."
                          % str(e)[:120]}]
    ayrinti = []
    for g in reversed(yeni):
        _log(progress, "Undoing a half-finished change in %s..."
             % os.path.basename(g.get("forge") or "?"))
        try:
            r = KM.geri_al(g.get("id")) or {}
        except Exception as e:                                  # noqa: BLE001
            r = {"ok": False, "mesaj": str(e)[:300]}
        ok = bool(r.get("ok"))
        ayrinti.append({
            "yazici": "kur_mesh", "ok": ok, "tur": "mesh", "mesaj": r.get("mesaj"),
            # Geri alinamayan giris bir TUTAMAK olarak defterine yazilir: kullanici
            # onu daha sonra Remove ile yeniden deneyebilsin (cikissiz kalmasin).
            "tutamak": (None if ok else
                        {"yazici": "kur_mesh", "kayit_id": g.get("id"),
                         "forge": g.get("forge"), "gid_sayi": g.get("gid_sayi"),
                         "icid_sayi": g.get("icid_sayi")})})
    return ayrinti


def _temizle_outfit(once, progress=None):
    """Fotograftan sonra doku_enjekte2 kayitina giren materyalleri geri al."""
    if once is None:
        return None
    try:
        C = _outfit_core()
        d = C.DE.gerial_dagilim() or {}
    except Exception as e:                                      # noqa: BLE001
        return [{"yazici": "doku_enjekte2", "ok": False, "tutamak": None,
                 "tur": "outfit",
                 "mesaj": "The outfit patch record could not be read (%s)."
                          % str(e)[:120]}]
    simdi = ({k: dict(v) for k, v in (d.get("materyaller") or {}).items()}
             if d.get("kayit") else {})
    yeni, buyuyen = [], []
    for k, v in sorted(simdi.items()):
        o = once.get(k)
        if o is None:
            yeni.append(k)
        elif (int(v.get("gomulu") or 0) > int(o.get("gomulu") or 0)
              or int(v.get("harici") or 0) > int(o.get("harici") or 0)):
            buyuyen.append(k)
    ayrinti = []
    if yeni:
        _log(progress, "Undoing the outfit textures this mod had already written...")
        matler = ["0x%s" % k for k in yeni]
        try:
            r = C.DE.gerial_secmeli(matler) or {}
        except Exception as e:                                  # noqa: BLE001
            r = {"red_sebep": str(e)[:300]}
        ok = not r.get("red_sebep")
        ayrinti.append({"yazici": "doku_enjekte2", "ok": ok, "tur": "outfit",
                        "mesaj": r.get("red_sebep"),
                        "tutamak": (None if ok else
                                    {"yazici": "doku_enjekte2", "matler": matler})})
    for k in buyuyen:
        # Bu materyalde BIZDEN ONCE de yazi vardi. Yazici materyali butun halinde
        # geri alir, yani geri almak BASKA bir modun baytini da silerdi. Yapilmaz;
        # kullaniciya oldugu gibi SOYLENIR.
        ayrinti.append({
            "yazici": "doku_enjekte2", "ok": False, "tur": "outfit",
            "tutamak": {"yazici": "doku_enjekte2", "matler": ["0x%s" % k]},
            "mesaj": ("Part of an outfit was written before this mod stopped, but "
                      "another mod had already changed the same outfit, so putting "
                      "it back would have undone that mod as well. It was left "
                      "alone.")})
    return ayrinti


def _temizle_ship(once, progress=None):
    """Fotograftan sonra YAMALI hale gelen gemi hedeflerini geri al."""
    if once is None:
        return None
    try:
        SC = _ship_core()
        simdi = set(SC.yamali_hedefler())
    except Exception as e:                                      # noqa: BLE001
        return [{"yazici": "ship_core", "ok": False, "tutamak": None, "tur": "ship",
                 "mesaj": "The ship patch record could not be read (%s)."
                          % str(e)[:120]}]
    ayrinti = []
    for a in sorted(simdi - once):
        _log(progress, "Undoing a half-finished ship change...")
        try:
            r = SC.geri_al(a, gunluk=progress) or {}
        except Exception as e:                                  # noqa: BLE001
            r = {"ok": False, "mesaj": str(e)[:300]}
        ok = bool(r.get("ok"))
        ayrinti.append({"yazici": "ship_core", "ok": ok, "tur": "ship",
                        "mesaj": r.get("mesaj"),
                        "tutamak": (None if ok else
                                    {"yazici": "ship_core", "anahtar": a})})
    return ayrinti


def _yarim_temizle(iz, progress=None):
    """Tutamak DONDURMEDEN bayt yazmis bir denemenin arkasinda birakigini temizle.

    Doner: (bulduklarinin hepsi geri alindi mi, [ayrinti...]).
    AYRI FONKSIYON: testler bunu etkisiz hale getirip kapinin gercekten ayirt
    edici oldugunu olcer."""
    iz = iz or {}
    ayrinti = []
    for ad, fn in (("kur_mesh", _temizle_kur_mesh),
                   ("outfit", _temizle_outfit),
                   ("ship", _temizle_ship)):
        try:
            r = fn(iz.get(ad), progress)
        except Exception as e:                                  # noqa: BLE001
            r = [{"yazici": ad, "ok": False, "tutamak": None, "tur": None,
                  "mesaj": str(e)[:300]}]
        ayrinti.extend(r or [])
    return all(x.get("ok") for x in ayrinti), ayrinti


def _bayt_olc(arsivler):
    """Arsivler ILK BAYTTAN ONCEKI boylarina dondu mu? SALT OLCUM, yazmaz.

    Doner: (durum, [satir...]).
      durum True  : olculebilen her arsiv tam olarak eski boyunda.
      durum False : en az biri farkli -- arsivde bir sey KALDI ya da fazladan gitti.
      durum None  : hicbiri olculemedi. "Temiz" DEMEK DEGILDIR, "bilinmiyor"dur.

    AYRI FONKSIYON: testler bunu etkisiz hale getirip kapinin gercekten ayirt
    edici oldugunu olcer."""
    satirlar, bilinen, sapan = [], 0, 0
    for y, bilgi in (arsivler or {}).items():
        once = (bilgi or {}).get("boyut_once")
        simdi = arsiv_olc(y)
        fark = None if (once is None or simdi is None) else simdi - once
        satirlar.append({"yol": y, "ad": os.path.basename(y), "boyut_once": once,
                         "boyut_simdi": simdi, "fark": fark})
        if fark is None:
            continue
        bilinen += 1
        if fark != 0:
            sapan += 1
    if not bilinen:
        return None, satirlar
    return (sapan == 0), satirlar


def _sapan_satir(bayt):
    """Eski boyuna DONMEYEN ilk arsiv satiri (yoksa None)."""
    for x in (bayt or []):
        if x.get("fark"):
            return x
    return None


_ERRNO_DESEN = re.compile(r"\[Errno\s+-?\d+\]\s*", re.I)
_WINERR_DESEN = re.compile(r"\[WinError\s+-?\d+\]\s*", re.I)


def _kullanici_cumlesi(m, yedek="one of its parts could not be written"):
    """Yazicidan gelen sebebi KULLANICI cumlesine cevirir.

    Yazicilarin bir kismi ham istisna metni donduruyor. Kullanici ekraninda
    "[Errno 13] Permission denied: 'C:\\\\Users\\\\...\\\\DataPC_boot_patch_02.forge'"
    goruyordu: errno jargonu, cift ters bolu ve nokta ile bitmeyen bir parca.
    Burada (a) errno/WinError oneki atilir, (b) yollar tek ters boluye indirilir,
    (c) cumle nokta ile biter -- boylece bir sonraki cumleyle temiz birlesir.
    """
    s = str(m or "").strip()
    if not s:
        return yedek + "."
    s = _ERRNO_DESEN.sub("", s)
    s = _WINERR_DESEN.sub("", s)
    s = s.replace("\\\\", "\\")
    s = " ".join(s.split())
    if s and s[-1] not in ".!?":
        s += "."
    return s[0].upper() + s[1:] if s and s[0].islower() and " " in s else s


def _geri_sarma_cumlesi(temiz, bayt_ok, bayt):
    """Geri sarmanin sonucunu KULLANICIYA anlatan cumle.

    "back to how it was" YALNIZCA ikisi de kanitliysa kurulur: her adim geri
    alindi VE arsiv ilk bayttan onceki boyuna birebir dondu. Adimlar "ok" dese
    bile dosya buyuk kaldiysa bu cumle KURULMAZ -- eski surum tam burada yalan
    soyluyordu (olculdu: mesaj "back to how it was", arsiv +38 814 bayt)."""
    sapan = _sapan_satir(bayt)
    if not temiz:
        s = ("Some of the changes it had already written could NOT be undone - open "
             "Health Check before starting the game, then press Remove on this mod to "
             "try again.")
        if sapan and sapan.get("fark", 0) > 0:
            s += (" %s is %s bytes larger than it was before this mod started."
                  % (sapan["ad"], _bayt(sapan["fark"])))
        return s
    if bayt_ok is True:
        ilk = (bayt or [None])[0]
        if ilk and ilk.get("boyut_simdi") is not None:
            return ("Everything it had written was undone, so the game is back to how "
                    "it was (%s is back to %s bytes)."
                    % (ilk["ad"], _bayt(ilk["boyut_simdi"])))
        return "Everything it had written was undone, so the game is back to how it was."
    if bayt_ok is False and sapan:
        if sapan["fark"] > 0:
            return ("It put back every change it had made, but %s is still %s bytes "
                    "larger than it was before this mod started. Open Health Check "
                    "before starting the game."
                    % (sapan["ad"], _bayt(sapan["fark"])))
        return ("It put back every change it had made, but %s is now %s bytes smaller "
                "than it was before this mod started, so something else was taken out "
                "as well. Open Health Check before starting the game."
                % (sapan["ad"], _bayt(-sapan["fark"])))
    # Olculemedi: "temiz" DIYE YAZMA, ne bilindigini yaz.
    return ("It put back every change it had made. The size of the game files could "
            "not be checked, so open Health Check if the game does not look right.")


# ============================================================ KURULUM
def _geri_sar(yapilanlar, progress=None):
    """HEPSI YA DA HIC'in ikinci yarisi: o ana kadar yazilanlari TERS SIRADA geri al.

    `yapilanlar`in her ogesi bir YAZMA DENEMESIDIR. Tutamak dondurmus olan
    yazicinin kendi kaldirma yolundan gider; tutamak DONDURMEYEN (yani yarim
    kalan) deneme yazicilarin kendi defterinden cikarilir (`_yarim_temizle`).

    Doner: (hepsi_geri_alindi, [ayrinti...]). Geri alinamayan bir sey varsa o
    ayrinti satiri bir "tutamak" tasir; cagiran onu DEFTERE yazar ki kullanici
    daha sonra Remove ile yeniden deneyebilsin.
    AYRI FONKSIYON: testler bunu etkisiz hale getirip kapinin gercekten ayirt edici
    oldugunu olcer."""
    ayrinti, hepsi = [], True
    for oge in reversed(yapilanlar):
        tut = oge.get("tutamak")
        if tut:
            try:
                r = _adaptor(oge["tur"])["kaldir"](tut, progress) or {}
            except Exception as e:                              # noqa: BLE001
                r = {"ok": False, "mesaj": str(e)[:300]}
            ok = bool(r.get("ok"))
            ayrinti.append({"oge": oge.get("indeks"), "ozet": oge.get("ozet"),
                            "ok": ok, "mesaj": r.get("mesaj"),
                            "tur": oge.get("tur"),
                            "tutamak": (None if ok else tut)})
            if not ok:
                hepsi = False
            continue
        # TUTAMAK YOK = yazma denemesi yarim kaldi. Yazicilarin kendi defterine bak.
        t, det = _yarim_temizle(oge.get("iz"), progress)
        for x in det:
            ayrinti.append({"oge": oge.get("indeks"), "ozet": oge.get("ozet"),
                            "ok": bool(x.get("ok")), "mesaj": x.get("mesaj"),
                            "yazici": x.get("yazici"),
                            "tur": x.get("tur") or oge.get("tur"),
                            "tutamak": x.get("tutamak")})
        if not det:
            ayrinti.append({"oge": oge.get("indeks"), "ozet": oge.get("ozet"),
                            "ok": True, "tutamak": None, "tur": oge.get("tur"),
                            "mesaj": "This part had not written anything yet."})
        if not t:
            hepsi = False
    return hepsi, ayrinti


def kur(plan, progress=None, ustune=False):
    """Plandaki her ogeyi ILGILI MEVCUT YAZICIYA yollar; hepsini TEK kayit yapar.

    plan = {"ad", "yazar", "surum", "kaynak", "ogeler": [...]}
    ustune=True: catisma uyarisini kullanici bilerek gecti demektir.

    Doner: {ok, mod_id, kurulan, mesaj, catisma?, geri_sarma?}"""
    r = {"ok": False, "mod_id": None, "kurulan": 0}
    try:
        ogeler = _plan_ogeleri(plan)
    except Exception as e:                                      # noqa: BLE001
        r["mesaj"] = str(e)[:300]
        return r
    if not ogeler:
        r["mesaj"] = "This mod does not contain anything to install."
        return r

    engel = _yazma_engeli()
    if engel:
        # CEVIRI: duz metin AYNEN durur (eski cagiranlar bozulmasin), yaninda
        # sozluge girebilen kalip ikizi gider.
        r.update(engel)
        return r

    defter, bozuk = _defter_oku()

    # --- her ogenin ANAHTARI ve OZETI once cozulur: cozulemeyen varsa TEK BAYT yazma
    anahtarlar = _plan_anahtarlari(plan)
    bozuk_ogeler = [{"oge": i, "mesaj": h} for i, _o, _a, _n, _z, h in anahtarlar if h]
    if bozuk_ogeler:
        r["mesaj"] = ("This mod could not be installed because %d of its parts could not "
                      "be read. Nothing was written." % len(bozuk_ogeler))
        r["sorunlu_ogeler"] = bozuk_ogeler
        return r

    # --- CATISMA: kurmadan ONCE
    disari, ic = _catisma_kapisi(plan, defter)
    # BILEREK BIRLESTIRME: plan, KURULU yamayi kaynak alan bir forge_birlesik ogesi
    # tasiyorsa o yamayla catisma "ustune yazma" degil "icine alma"dir; kullanici
    # bunu "Merge" diyerek zaten secti, ikinci bir "INSTALL ANYWAY" istenmez.
    # Oteki catismalar (kiyafet, gemi, BASKA bir yama) icin kural aynen surer.
    birlesik_idler = _birlesik_kaynak_idleri(ogeler)
    kalan = [c for c in disari
             if not (c.get("tur") == "birlestirilebilir"
                     and c.get("mod_id") in birlesik_idler)]
    if kalan and not ustune:
        r["mesaj"] = _catisma_ozeti(kalan, ic, kuyruk=" Nothing was written.")
        r["catisma"] = disari
        return r
    if ic:
        r["ic_catisma"] = ic

    # --- arsiv boyutlari: ILK BAYTTAN ONCE olculur (kaldirmada karsilastirilir)
    arsivler = {}
    for _i, oge, _a, _n, _z, _h in anahtarlar:
        try:
            for y in _adaptor(oge.get("tur"))["arsivler"](oge) or []:
                b = arsiv_olc(y)
                if b is not None:
                    arsivler.setdefault(os.path.abspath(y), {"boyut_once": b})
        except Exception:                                       # noqa: BLE001
            pass

    # Yalniz GERCEKTEN catisan ogeler yazicinin "ustune yaz" kapisini acar; kullanici
    # uyariyi gectiyse bile catismayan ogeler normal kapidan gecmeye devam eder.
    catisan_ogeler = {c["oge"] for c in disari}
    mod_id = _yeni_mod_id(defter, plan)
    kayit_ogeleri, yapilanlar = [], []
    _log(progress, "Installing \"%s\" (%d change(s))..."
         % (plan.get("ad") or "this mod", len(ogeler)))

    for i, oge, anah, ince, ozet, _h in anahtarlar:
        a = _adaptor(oge.get("tur"))
        # YAZMA DENEMESI KAYDI: tutamak GELMEDEN, ilk bayttan ONCE listeye girer.
        # Yazici ortada durursa geri sarma bu kaydi bulur ve ne yazildigini
        # yazicinin KENDI defterinden cikarir. (Eskiden yalniz tutamak donduren
        # oge kaydediliyordu; olculdu: yarim yazim 38 814 bayt geride kaliyordu.)
        deneme = {"tur": oge.get("tur"), "tutamak": None, "indeks": i, "ozet": ozet,
                  "iz": _yazici_izi_al([oge.get("tur")])}
        yapilanlar.append(deneme)
        try:
            s = a["kur"](oge, progress, ustune=(i in catisan_ogeler)) or {}
        except Exception as e:                                  # noqa: BLE001
            s = {"ok": False, "mesaj": str(e)[:300]}
        if s.get("ok") and not s.get("tutamak"):
            # Yazici "kurdum" diyor ama neyi degistirdigini SOYLEMIYOR: bu kayit
            # kaldirilamaz olurdu. Basarisiz sayilir ve geri sarilir.
            s = {"ok": False, "mesaj": ("The writer did not say what it changed, so "
                                        "this mod could not be recorded.")}
        if not s.get("ok"):
            # --- HEPSI YA DA HIC
            _log(progress, "Part %d of %d failed: %s" % (i + 1, len(ogeler),
                                                         s.get("mesaj") or "unknown"))
            _log(progress, "Undoing everything this mod wrote so far...")
            temiz, ayrinti = _geri_sar(yapilanlar, progress)
            # "Geri aldim" DEMEDEN once ARSIVIN BOYUTU olculur. Adimlarin hepsi
            # "ok" dese bile dosya eski boyuna donmediyse geride bir sey vardir.
            bayt_ok, bayt = _bayt_olc(arsivler)
            kalinti = (not temiz) or (bayt_ok is False)
            # Sebep bir YAZICIDAN gelir ve bazen ham istisna metnidir ("[Errno 13]
            # Permission denied: 'C:\\...'"). Iki cumle noktalama duzeltilmeden
            # birlestirilince kullanici tek uzun karisik satir goruyordu; ustelik
            # errno jargonu ve cift ters bolu ekranda duruyordu.
            r["mesaj"] = ("This mod could not be installed: %s %s"
                          % (_kullanici_cumlesi(s.get("mesaj")),
                             _geri_sarma_cumlesi(temiz, bayt_ok, bayt)))
            r["geri_sarma"] = {"temiz": temiz and (bayt_ok is not False),
                               "adimlar_temiz": temiz, "bayt_temiz": bayt_ok,
                               "arsivler": bayt, "ayrinti": ayrinti}
            r["basarisiz_oge"] = {"oge": i, "ozet": ozet, "mesaj": s.get("mesaj")}
            if kalinti:
                # Yarim kalan is DEFTERE gecer: kullanici neyin kaldigini gorsun ve
                # Remove ile yeniden deneyebilsin.
                # Geri alinabilen ogeler "kurulu" DIYE YAZILMAZ: onlar geri alindi.
                geri_ok = {}
                for x in ayrinti:
                    if x.get("oge") is None:
                        continue
                    geri_ok[x["oge"]] = geri_ok.get(x["oge"], True) and bool(x.get("ok"))
                for o in kayit_ogeleri:
                    if geri_ok.get(o.get("indeks")):
                        o["durum"] = "kaldirildi"
                        o["kaldirma_notu"] = ("This was put back when the install "
                                              "failed.")
                # Geri alinamayan YARIM yazimlar da defterine gecer. Tutamagi
                # ZATEN kayitli olan ogeler atlanir: onlar yukarida "kurulu"
                # olarak duruyor, ikinci kez yazmak `kaldir`in ayni girisi iki
                # kere geri almasina calismasina yol acardi.
                kayitli = {o.get("indeks") for o in kayit_ogeleri}
                for x in ayrinti:
                    if x.get("ok") or not x.get("tutamak") or x.get("oge") in kayitli:
                        continue
                    kayit_ogeleri.append({
                        "indeks": x.get("oge"), "tur": x.get("tur"),
                        "ozet": (x.get("ozet")
                                 or "A change this mod wrote but could not take back."),
                        "anahtarlar": [], "ince_anahtarlar": [],
                        "tutamak": x["tutamak"], "durum": "kurulu",
                        "uyari": x.get("mesaj") or ""})
                defter["modlar"].append({
                    "id": mod_id, "ad": plan.get("ad") or "(unnamed mod)",
                    "yazar": plan.get("yazar") or "", "mod_surum": plan.get("surum") or "",
                    "kaynak": plan.get("kaynak") or "",
                    "tarih": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "durum": "yarim", "arsivler": arsivler, "ogeler": kayit_ogeleri})
                _defter_yaz(defter, bozuk)
                r["mod_id"] = mod_id
            return r
        deneme["tutamak"] = s["tutamak"]
        kayit_ogesi = {"indeks": i, "tur": oge.get("tur"), "ozet": ozet,
                       "anahtarlar": anah, "ince_anahtarlar": ince,
                       "tutamak": s["tutamak"],
                       "durum": "kurulu", "uyari": s.get("uyari") or ""}
        if s.get("kaynaklar"):
            # Birlesik yama: icindeki yamalarin adlari AYRI AYRI defterde durur;
            # kullanici "neyi kurdum" sorusuna "Sparrow + Black Beard" cevabini
            # gorur, "1 patch" degil.
            kayit_ogesi["kaynaklar"] = [str(x) for x in s["kaynaklar"]]
        if s.get("uyari"):
            r.setdefault("uyarilar", []).append(str(s["uyari"]))
        kayit_ogeleri.append(kayit_ogesi)
        _log(progress, "Part %d of %d done." % (i + 1, len(ogeler)))

    # --- USTUNE YAZILANLARI ISARETLE. Kullanici catisma uyarisini bilerek gectiyse
    # ezilen modun girisi ARTIK CANLI DEGILDIR; defter "kurulu" demeye devam ederse
    # kullanici geri alabilecegini sanir. (Guvenlik zaten `dogrula` kapisindadir:
    # kaldirma korlemesine yazmaz. Bu, LISTENIN dogru soylemesi icin.)
    #   YALNIZ tur="ustune" isaretlenir. tur="birlikte" (ayni materyalin BASKA
    #   slotu) ustune YAZMAZ: oteki modun baytlari oyunda DURUYOR, onu
    #   "ustune yazildi" saymak da yalan olurdu. O modun akibeti kaldirma aninda
    #   belli olur ve `kaldir` onu o zaman "kaldirildi" yapar.
    #   Birlesik yamanin ICINE ALINAN yama da "ustune_yazildi" olur (dosyasi
    #   yuvada artik tek basina durmuyor) ama `birlesik_icinde` ile ayrica
    #   isaretlenir: listede "ezildi" degil "su yamanin icinde yasiyor" denebilsin
    #   ve birlesik yama kaldirilinca geri gelebilsin (bkz. kaldir).
    if disari:
        ezilen = {}
        for c in disari:
            if c.get("tur") == "birlikte":
                continue
            ezilen.setdefault(c["mod_id"], set()).add(c["anahtar"])
        for m in defter.get("modlar", []):
            anah_set = ezilen.get(m.get("id"))
            if not anah_set:
                continue
            icine_alindi = m.get("id") in birlesik_idler
            for o in m.get("ogeler", []):
                if o.get("durum") == "kurulu" and (set(o.get("anahtarlar") or []) & anah_set):
                    o["durum"] = "ustune_yazildi"
                    o["ustune_yazan"] = mod_id
                    if icine_alindi:
                        o["birlesik_icinde"] = mod_id
            if all(o.get("durum") != "kurulu" for o in m.get("ogeler", [])):
                m["durum"] = "ustune_yazildi"
                m["ustune_yazan"] = mod_id
                if icine_alindi:
                    m["birlesik_icinde"] = mod_id

    kayit = {"id": mod_id, "ad": plan.get("ad") or "(unnamed mod)",
             "yazar": plan.get("yazar") or "", "mod_surum": plan.get("surum") or "",
             "kaynak": plan.get("kaynak") or "", "tarih": time.strftime("%Y-%m-%d %H:%M:%S"),
             "durum": "kurulu", "arsivler": arsivler, "ogeler": kayit_ogeleri}
    defter["modlar"].append(kayit)
    yol = _defter_yaz(defter, bozuk)
    r.update(ok=True, mod_id=mod_id, kurulan=len(kayit_ogeleri), kayit=yol,
             mesaj=("\"%s\" is installed (%d change(s)). Start the game to see it, or "
                    "press Remove to put everything back."
                    % (kayit["ad"], len(kayit_ogeleri))))
    if disari:
        r["catisma"] = disari
    return r


# ============================================================ LISTE
def liste():
    """Kurulu (ve yarim / kaldirilmis) modlarin defteri. SALT OKUNUR.

    Doner: [{id, ad, yazar, tarih, oge_sayisi, ozet[], durum, ...}]"""
    defter, bozuk = _defter_oku()
    out = []
    for m in defter.get("modlar", []):
        ogeler = m.get("ogeler") or []
        # Birlesik yamanin icindeki yamalarin adlari AYRI AYRI (arayuz "Sparrow +
        # Black Beard" diye gosterebilsin); yoksa bos liste.
        kaynaklar = []
        for o in ogeler:
            for ad in o.get("kaynaklar") or []:
                if ad not in kaynaklar:
                    kaynaklar.append(ad)
        out.append({
            "id": m.get("id"), "ad": m.get("ad") or "(unnamed mod)",
            "yazar": m.get("yazar") or "", "tarih": m.get("tarih") or "",
            "oge_sayisi": len(ogeler),
            "ozet": [o.get("ozet") or "Changes one part of the game." for o in ogeler],
            "durum": m.get("durum") or "kurulu",
            "surum": m.get("mod_surum") or "", "kaynak": m.get("kaynak") or "",
            "arsivler": sorted(os.path.basename(y) for y in (m.get("arsivler") or {})),
            "kaynaklar": kaynaklar,
            "birlesik_icinde": m.get("birlesik_icinde"),
        })
    if bozuk:
        # Bozuk defter uygulamayi cokertmez; ama SESSIZ de kalmaz.
        out.append({"id": None, "ad": "(the list of installed mods could not be read)",
                    "yazar": "", "tarih": "", "oge_sayisi": 0, "durum": "bozuk",
                    "ozet": ["The file %s is damaged, so the tool cannot tell which mods "
                             "are installed. It will be renamed and a fresh list started "
                             "the next time a mod is installed." % bozuk],
                    "surum": "", "kaynak": "", "arsivler": []})
    return out


# ============================================================ DOGRULAMA
def dogrula(mod_id):
    """Bu modun kaydi HALA gecerli mi? (oyun guncellendi mi, baska arac yazdi mi)

    SALT OKUNUR. KILITLEMEZ: "bayat" cikan bir mod icin kullaniciya yol gosterilir
    (`kaldir` onu defterden temizler), cikissiz birakilmaz."""
    defter, bozuk = _defter_oku()
    m = _mod_bul(defter, mod_id)
    if m is None:
        return {"ok": False, "mod_id": mod_id, "durum": "yok", "kilitli": False,
                "mesaj": "That mod is not in the list of installed mods.",
                "defter_bozuktu": bool(bozuk)}
    satirlar = []
    for o in m.get("ogeler") or []:
        try:
            d, msj = _adaptor(o.get("tur"))["dogrula"](o.get("tutamak") or {})
        except Exception as e:                                  # noqa: BLE001
            d, msj = "bayat", "This change could not be checked (%s)." % str(e)[:120]
        satirlar.append({"oge": o.get("indeks"), "ozet": o.get("ozet"),
                         "durum": d, "mesaj": msj})
    durumlar = {s["durum"] for s in satirlar}
    if not durumlar or durumlar == {"taze"}:
        genel, mesaj = "taze", "This mod is installed and its changes are still in place."
    elif "taze" not in durumlar and durumlar <= {"bayat"}:
        genel, mesaj = ("bayat",
                        "The game files changed after this mod was installed (most likely "
                        "a game update or a Steam file verification), so none of its "
                        "changes are in the game any more. Press Remove to take it off "
                        "this list.")
    elif "taze" not in durumlar:
        genel, mesaj = ("kayip",
                        "None of this mod's changes are in the game any more. Something "
                        "else reverted or replaced them.")
    else:
        genel, mesaj = ("karisik",
                        "Only part of this mod is still in the game (%d of %d changes). "
                        "Removing it will put back what is left."
                        % (sum(1 for s in satirlar if s["durum"] == "taze"), len(satirlar)))
    # Arsiv bugun ne kadar? (kaldirma sonrasi olcumle ayni sozlesme)
    arsiv = []
    for y, bilgi in (m.get("arsivler") or {}).items():
        simdi = arsiv_olc(y)
        arsiv.append({"yol": y, "ad": os.path.basename(y),
                      "boyut_once": bilgi.get("boyut_once"), "boyut_simdi": simdi})
    return {"ok": True, "mod_id": mod_id, "ad": m.get("ad"), "durum": genel,
            "kilitli": False, "mesaj": mesaj, "ogeler": satirlar, "arsivler": arsiv,
            "defter_bozuktu": bool(bozuk)}


# ============================================================ KALDIRMA
def kaldir(mod_id, progress=None):
    """Yalniz O modun dokundugu girisleri geri al. Digerlerine DOKUNULMAZ.

    Kaldirmadan sonra ARSIV BOYUTU olculur ve raporlanir (v0.13 dersi)."""
    r = {"ok": False, "mod_id": mod_id, "geri_alinan": 0}
    engel = _yazma_engeli()
    if engel:
        # CEVIRI: duz metin AYNEN durur (eski cagiranlar bozulmasin), yaninda
        # sozluge girebilen kalip ikizi gider.
        r.update(engel)
        return r
    defter, bozuk = _defter_oku()
    m = _mod_bul(defter, mod_id)
    if m is None:
        r["mesaj"] = "That mod is not in the list of installed mods."
        return r
    ogeler = [o for o in (m.get("ogeler") or []) if o.get("durum") == "kurulu"]
    _log(progress, "Removing \"%s\" (%d change(s))..." % (m.get("ad"), len(ogeler)))

    ayrinti, basarisiz, bayat = [], 0, 0
    yazilan_anahtarlar = set()
    for o in reversed(ogeler):                      # yeniden eskiye
        try:
            d, _msj = _adaptor(o.get("tur"))["dogrula"](o.get("tutamak") or {})
        except Exception:                                       # noqa: BLE001
            d = "bayat"
        if d in ("bayat", "kayip"):
            # Arsivde bu modun bayti KALMAMIS. Yazmaya kalkmak yikici olur; kayit
            # temizlenir ve kullaniciya NEDEN yazilmadigi soylenir.
            o["durum"] = "kaldirildi"
            o["kaldirma_notu"] = ("Nothing was written back for this change: the game "
                                  "archive no longer holds it.")
            bayat += 1
            ayrinti.append({"oge": o.get("indeks"), "ozet": o.get("ozet"), "ok": True,
                            "yazildi": False, "mesaj": o["kaldirma_notu"]})
            continue
        try:
            s = _adaptor(o.get("tur"))["kaldir"](o.get("tutamak") or {}, progress) or {}
        except Exception as e:                                  # noqa: BLE001
            s = {"ok": False, "mesaj": str(e)[:300]}
        if s.get("ok"):
            o["durum"] = "kaldirildi"
            r["geri_alinan"] += 1
            yazilan_anahtarlar |= set(o.get("anahtarlar") or [])
        else:
            basarisiz += 1
        ayrinti.append({"oge": o.get("indeks"), "ozet": o.get("ozet"),
                        "ok": bool(s.get("ok")), "yazildi": True, "mesaj": s.get("mesaj")})

    m["durum"] = "kaldirildi" if not basarisiz else "yarim"
    m["kaldirma_tarihi"] = time.strftime("%Y-%m-%d %H:%M:%S")

    # --- BIRLIKTE GERI ALINANLAR. Yazicilar bazi girisleri BUTUN halinde geri
    # alir (kiyafette bir materyalin butun slotlari birden). Ayni girise dokunan
    # BASKA bir mod da bu yazmayla geri alinmis olur; defter "kurulu" demeye
    # devam ederse kullanici oyunda olmayan bir modu kurulu sanir ve onu
    # kaldirmaya calisir. Kurulum kapisi bunu zaten onceden soyluyor
    # (`_catisma_kapisi`, tur="birlikte"); burada olan bitene defter de uyar.
    birlikte = []
    for x in defter.get("modlar", []):
        if x.get("id") == mod_id or x.get("durum") != "kurulu":
            continue
        dokunulan = [o2 for o2 in (x.get("ogeler") or [])
                     if o2.get("durum") == "kurulu"
                     and (set(o2.get("anahtarlar") or []) & yazilan_anahtarlar)]
        if not dokunulan:
            continue
        for o2 in dokunulan:
            o2["durum"] = "kaldirildi"
            o2["kaldirma_notu"] = ("This was put back at the same time, because it "
                                   "changes the same part of the game as \"%s\"."
                                   % (m.get("ad") or mod_id))
        if all(o2.get("durum") != "kurulu" for o2 in (x.get("ogeler") or [])):
            x["durum"] = "kaldirildi"
            x["kaldirma_tarihi"] = m["kaldirma_tarihi"]
            x["kaldiran"] = mod_id
        birlikte.append(x.get("ad") or x.get("id"))
    r["birlikte"] = birlikte

    # --- GERI GELEN HAZIR YAMA. Hazir yama yazicisi kaldirmada ONCEKI yamayi
    # adiyla alinmis yedekten geri koyar. O yama defterde "ustune_yazildi" (ya da
    # birlesik yamanin icinde) duruyorsa ve yazicinin KENDI dogrula'si simdi
    # "taze" diyorsa, o mod yeniden oyundadir: defter "ezildi" demeye devam
    # ederse kullanici oyunda duran bir modu listede goremez ve kaldiramaz.
    # YALNIZ hazir yama turleri: oteki yazicilarin geri koyma tanecigi burada
    # olculmedi, onlar icin iddia yok.
    #   SIRA ONEMLI (olculdu, K6b): bu blok "birlikte geri alinanlar"dan SONRA
    #   gelir. Onden gelirse canlandirilan mod "kurulu" gorunur ve yukaridaki
    #   blok onu ayni anahtari paylastigi icin yeniden "kaldirildi" yapar.
    geri_gelen = []
    if r["geri_alinan"] and any(o.get("tur") in FORGE_TURLERI for o in ogeler):
        for x in defter.get("modlar", []):
            if x.get("id") == mod_id or x.get("ustune_yazan") != mod_id:
                continue
            canlandi = False
            for o2 in x.get("ogeler") or []:
                if (o2.get("durum") != "ustune_yazildi"
                        or o2.get("tur") not in FORGE_TURLERI
                        or o2.get("ustune_yazan") != mod_id):
                    continue
                try:
                    d2, _m2 = _adaptor(o2.get("tur"))["dogrula"](o2.get("tutamak") or {})
                except Exception:                               # noqa: BLE001
                    d2 = "bayat"
                if d2 == "taze":
                    o2["durum"] = "kurulu"
                    o2.pop("ustune_yazan", None)
                    o2.pop("birlesik_icinde", None)
                    canlandi = True
            if canlandi and any(o2.get("durum") == "kurulu" for o2 in x.get("ogeler") or []):
                x["durum"] = "kurulu"
                x.pop("ustune_yazan", None)
                x.pop("birlesik_icinde", None)
                x.pop("kaldirma_tarihi", None)
                geri_gelen.append(x.get("ad") or x.get("id"))
    r["geri_gelen"] = geri_gelen

    # --- ARSIV BOYUTU: "geri alindi" demek YETMEZ, OLCULUR (v0.13 dersi)
    kalan_modlar = [x for x in defter.get("modlar", [])
                    if x.get("durum") == "kurulu" and x.get("id") != mod_id]
    olcum = []
    for y, bilgi in (m.get("arsivler") or {}).items():
        once, simdi = bilgi.get("boyut_once"), arsiv_olc(y)
        paylasan = [x.get("ad") or x.get("id") for x in kalan_modlar
                    if os.path.abspath(y) in {os.path.abspath(z)
                                              for z in (x.get("arsivler") or {})}]
        satir = {"yol": y, "ad": os.path.basename(y), "boyut_once": once,
                 "boyut_simdi": simdi,
                 "fark": (None if (once is None or simdi is None) else simdi - once),
                 "diger_modlar": paylasan}
        try:
            satir["kuyruk_bayt"] = _km().kuyruk_bayt(y)
        except Exception:                                       # noqa: BLE001
            satir["kuyruk_bayt"] = None
        # `kuyruk_bayt` = arsiv, BU ARACIN ilk yazisindan onceki boyutunun kac bayt
        # ustunde. 0 ise bu aracin ekledigi hicbir sey kalmamis demektir; `fark` ise
        # yalniz BU MODUN kurulum anina gore olculur. Ikisi ayri sorulardir: A'dan
        # sonra kurulan B kaldirilinca `fark` NEGATIF cikar (A da gitmistir) --
        # eski surum bunu "still -38 814 bytes larger" diye yaziyordu (olculdu).
        temiz = (satir["kuyruk_bayt"] == 0)
        if satir["fark"] is None:
            satir["mesaj"] = "%s could not be measured." % satir["ad"]
        elif satir["fark"] == 0:
            satir["mesaj"] = ("%s is back to %s bytes, exactly what it was before this "
                              "mod was installed." % (satir["ad"], _bayt(simdi)))
            if temiz:
                satir["mesaj"] += " Nothing this tool added is left in it."
        elif temiz:
            satir["mesaj"] = ("%s is now %s bytes. Nothing this tool added to it is left, "
                              "so every mod it wrote has been taken back out."
                              % (satir["ad"], _bayt(simdi)))
        elif satir["fark"] < 0:
            satir["mesaj"] = ("%s is now %s bytes, %s bytes smaller than when this mod was "
                              "installed, because other mods were removed as well."
                              % (satir["ad"], _bayt(simdi), _bayt(-satir["fark"])))
        elif paylasan:
            satir["mesaj"] = ("%s is %s bytes larger than before this mod was installed, "
                              "because %s still installed on the same archive."
                              % (satir["ad"], _bayt(satir["fark"]),
                                 ("the mod \"%s\" is" % paylasan[0]) if len(paylasan) == 1
                                 else ("%d other mods are" % len(paylasan))))
        else:
            satir["mesaj"] = ("%s is still %s bytes larger than before this mod was "
                              "installed. Open Health Check to see what is left."
                              % (satir["ad"], _bayt(satir["fark"])))
        _log(progress, satir["mesaj"])
        olcum.append(satir)

    _defter_yaz(defter, bozuk)
    r["ok"] = not basarisiz
    r["ayrinti"] = ayrinti
    r["arsivler"] = olcum
    r["yazilmayan"] = bayat
    if basarisiz:
        r["mesaj"] = ("%d of this mod's %d change(s) could not be put back. Open Health "
                      "Check before starting the game."
                      % (basarisiz, len(ogeler)))
    elif not ogeler:
        r["mesaj"] = ("\"%s\" was taken off the list. Nothing had to be written back: a "
                      "newer mod had already been installed over it." % m.get("ad"))
    elif bayat and not r["geri_alinan"]:
        r["mesaj"] = ("\"%s\" was taken off the list. Nothing had to be written back: the "
                      "game files had already changed, so none of its changes were still "
                      "in the game." % m.get("ad"))
    else:
        r["mesaj"] = ("\"%s\" was removed and %d change(s) were put back."
                      % (m.get("ad"), r["geri_alinan"]))
        if olcum:
            r["mesaj"] += " " + olcum[0]["mesaj"]
    if len(birlikte) == 1:
        r["mesaj"] += (" This also put back \"%s\", because it changes the same part of "
                       "the game and the two could only be taken out together."
                       % birlikte[0])
    elif birlikte:
        r["mesaj"] += (" This also put back %d other mods that change the same parts of "
                       "the game, because they could only be taken out together."
                       % len(birlikte))
    if len(geri_gelen) == 1:
        r["mesaj"] += (" The patch \"%s\" that was there before is back in the game and "
                       "back on the list." % geri_gelen[0])
    elif geri_gelen:
        r["mesaj"] += (" %d patches that were there before are back in the game and back "
                       "on the list." % len(geri_gelen))
    return r


def unut(mod_id):
    """Defterden SIL (arsive dokunmadan). Yalniz artik arsivde bayti kalmamis
    ya da kaldirilmis modlar icin: kullanici cikissiz kalmasin."""
    defter, bozuk = _defter_oku()
    m = _mod_bul(defter, mod_id)
    if m is None:
        return {"ok": False, "mesaj": "That mod is not in the list of installed mods."}
    if m.get("durum") == "kurulu":
        d = dogrula(mod_id)
        if d.get("durum") == "taze":
            return {"ok": False, "mesaj": ("\"%s\" is still installed in the game. Remove "
                                           "it first so its changes are put back."
                                           % m.get("ad"))}
    defter["modlar"] = [x for x in defter.get("modlar", []) if x.get("id") != mod_id]
    _defter_yaz(defter, bozuk)
    return {"ok": True, "mesaj": "\"%s\" was taken off the list. The game files were not "
                                 "touched." % m.get("ad")}


if __name__ == "__main__":                                      # elle yoklama
    import pprint
    pprint.pprint({"kayit": kayit_yolu(), "modlar": liste()})
