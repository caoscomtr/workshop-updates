# -*- coding: utf-8 -*-
r"""
onizleme3d — Outfit Workshop 3D ONIZLEME MOTORU  (tek modul, GPU YOK)
=====================================================================
Bir kiyafetin 3D modelini, uzerindeki DOKULARLA birlikte yazilimda render eder.
Kullanicinin BOYADIGI dokuyu da uygulayabilir ("bu Hood'u kirmizi yaptim,
Edward'in ustunde nasil duruyor?").

DISA ACIK API
-------------
    kiyafet_render(kiyafet_adi, doku_ust_yazim=None, aci=0, boyut=512) -> PIL.Image | None
        doku_ust_yazim : {mat_id: PIL.Image}  — kullanicinin boyadigi dokular.
                         mat_id int ya da "0x22D90B0A877" olabilir.
                         Verilmezse vanilla forge dokusu kullanilir.
        Mesh bulunamayan / cozulemeyen kiyafette ISTISNA FIRLATMAZ, None doner.

    kiyafetler()                 -> [(ad, gorunen_ad), ...]
    Oturum()                     -> GUI icin sicak tutulan oturum (mesh onbellegi)
    indeks_kur(yol=None)         -> kiyafet->mesh indeksini (yeniden) uretir

BAGIMLILIK
----------
numpy + PIL + stdlib(struct/sqlite3/ctypes) + aracin KENDI modulleri
(outfit_core -> BC cozucu, yalin_forge -> forge okuyucu + Oodle DLL).
OpenGL / moderngl / trimesh / pyrender YOK ve olmayacak.

YAZMA GUVENLIGI
---------------
Oyun arsivi YALNIZCA open(path,"rb") ile okunur. Bu modulde tek bir yazma cagrisi
yoktur. Forge taniticisi is bitince KAPATILIR (`_kapat()` -> outfit_core.release_forge);
Windows bu taniticiya FILE_SHARE_DELETE vermedigi icin acik birakmak Steam'in
"dosya butunlugunu dogrula" adimini "Content file locked" ile dusuruyor.

VERI ZINCIRI  (dordu de forge'dan OLCULEREK turetildi)
------------------------------------------------------
 1) kiyafet -> mesh :  EntityGroup girisinin cozulmus govdesinde gecen 8 baytlik
    little-endian kimliklerden Mesh olanlar. Ad suzgeci YETMEZ — Feline kiyafeti
    govdesi icin HUNTER meshlerini kullanir (ad suzgeci 2, EG 40 kayit verir).
 2) TOC girisi -> ic dosyalar :  giris HAM DEGIL, BMS konteyneri.
      block1 = kayit tablosu: <H sayi, sonra (ic_id <Q, uzunluk <I) 18 BAYT adim
      block2 = ic dosyalarin ardisik govdesi
 3) mesh govdesi -> geometri :  0xC351EE43 isaretcisi stride tablosunu, alt-mesh
    sayisini ve sinir kutusunu verir; tampon zinciri [<I uzunluk][veri] halkalari
    halinde ARANIR (sabit ofset YOK; js37'nin "kn=<I@41" / "45+kn*81" sabitleri
    boot.forge meshlerinde GECERSIZ). Konum olcegi P = int16/32768 * s, s sabit
    DEGIL (olculen dagilim 2.0 x67, 1.0 x5, 3.0 x1) ve sinir kutusuna GERI dogrulanir.
 4) alt-mesh -> materyal :  materyalin 8B LE kimligi mesh govdesinin KUYRUGUNDAKI
    bagimlilik listesinde, alt-mesh sirasiyla AYNI sirada gecer.

Indeks (adim 1-2-4'un sonucu) `onizleme3d_indeks.json` icine PISIRILIR; boylece
calisma aninda ansiklopedi veritabanlari (varliklar.db / dokular.db) GEREKMEZ.
Indeks yoksa modul o kiyafeti canli olarak veritabanlarindan cikarir.
"""
import os, re, sys, json, time, struct

import numpy as np

__all__ = ["kiyafet_render", "kiyafetler", "Oturum", "indeks_kur", "INDEKS_YOL"]

_BURASI = os.path.dirname(os.path.abspath(__file__))
INDEKS_YOL = os.path.join(_BURASI, "onizleme3d_indeks.json")

# Aracin kendi kaynaklari (yeni bagimlilik DEGIL: GUI zaten bunlari yukluyor)
_SRC = os.path.join(os.path.dirname(_BURASI), "src")
for _p in (_SRC,):
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

# Ansiklopedi veritabanlari — YALNIZ indeks kurarken gerekir, render'da DEGIL.
VARLIK_DB = os.path.join(_BURASI, "varliklar.db")   # yalniz indeks uretimi
DOKU_DB = os.path.join(_BURASI, "dokular.db")       # yalniz indeks uretimi

TIP_MESH = 1096652136                        # crc32("Mesh")
TIP_MATERIAL = 2244483011                    # crc32("Material")
MAGIC_ALT = struct.pack("<I", 0xA57387EF)    # alt-mesh sayaci
MARK_VF = struct.pack("<I", 0xC351EE43)      # vertex bicimi nesnesi
UV_BOLEN = 2048.0
KIMLIK_ALT, KIMLIK_UST = 0x20000000000, 0x30000000000

ISIK = np.array([0.35, 0.5, 0.75]); ISIK = ISIK / np.linalg.norm(ISIK)
DOKUSUZ_RENK = np.array([150.0, 148.0, 145.0])
ARKA_PLAN = (24, 26, 30)


# ===================================================================== outfit_core
_OC = [None]


def _oc():
    """outfit_core'u ILK KULLANIMDA yukle (import maliyeti 0,4 sn; GUI'de zaten yuklu)."""
    if _OC[0] is None:
        import outfit_core
        _OC[0] = outfit_core
    return _OC[0]


def _forge():
    """Aracin PAYLASILAN salt-okunur forge taniticisi. Ayri bir tanitici ACMIYORUZ:
    her acik tanitici Steam'in 'Content file locked' hatasinin bir olasiligi."""
    return _oc()._forge()


def _kapat(onbellek=False):
    """Forge taniticisini birak. onbellek=True cozulmus materyal govdelerini de
    atar (forge'a yazildiktan sonra sart)."""
    if _OC[0] is not None:
        try:
            _OC[0].release_forge(onbellek=onbellek)
        except Exception:
            pass


def katalog():
    return _oc().CATALOG


def kiyafetler():
    return [(o["ad"], o["gorunen_ad"]) for o in katalog()]


def _kiyafet_bul(ad):
    for o in katalog():
        if o["ad"] == ad or o["gorunen_ad"] == ad:
            return o
    dusuk = str(ad).lower()
    for o in katalog():
        if dusuk in o["gorunen_ad"].lower() or dusuk in o["ad"].lower():
            return o
    return None


def _mid(v):
    return v if isinstance(v, int) else int(str(v), 16)


# =============================================================== BMS ic dosyalar
def _ic_dosyalar(raw):
    """TOC girisinin HAM baytlarini ic dosyalara bol -> [(ic_id, bytes)].
    block1 uzunlugu 2+18n degilse giris bir kap DEGILDIR (ham kaynak)."""
    from yalin_forge import read_block
    b1, n1 = read_block(raw, 0)
    if b1 is None:
        return []
    b2, _ = read_block(raw, n1)
    if b2 is None:
        return []
    n = struct.unpack_from("<H", b1, 0)[0]
    if len(b1) != 2 + 18 * n:
        return []
    out, pos = [], 0
    for i in range(n):
        icid, ln = struct.unpack_from("<QI", b1, 2 + 18 * i)
        out.append((icid, b2[pos:pos + ln]))
        pos += ln
    if pos != len(b2):
        return []
    return out


def _giris_ic_dosyalari(giris_id):
    lf = _forge()
    if giris_id not in lf.by_id:
        return []
    return _ic_dosyalar(lf.read_raw(giris_id))


def _id_adaylari(buf):
    """Tamponun HER BAYT OFSETINDE <Q oku, kimlik araligindakileri {deger: ilk_ofset}
    olarak dondur. Vektorel: duz Python dongusu 62 KB govdede 62.000 unpack demekti."""
    a = np.frombuffer(buf, dtype=np.uint8)
    n = len(a) - 8
    if n <= 0:
        return {}
    v = np.zeros(n, dtype=np.uint64)
    for k in range(8):
        v |= a[k:k + n].astype(np.uint64) << np.uint64(8 * k)
    ofs = np.where((v > np.uint64(KIMLIK_ALT)) & (v < np.uint64(KIMLIK_UST)))[0]
    out = {}
    for i in ofs.tolist():
        d = int(v[i])
        if d not in out:
            out[d] = i
    return out


# ================================================================== MESH COZUCU
def _zincir(md, bas, azami=10):
    p, halka, n = bas, [], len(md)
    while p + 4 <= n and len(halka) < azami:
        ln = struct.unpack_from("<I", md, p)[0]
        if ln > n - p - 4:
            break
        halka.append((p + 4, ln))
        p += 4 + ln
    return halka


def mesh_coz(md, dogrula=True):
    """Bir Mesh ic dosyasini geometriye cevir.
    -> dict(P (V,3) karakter uzayi, UV (V,2), TRI (T,3), altlar, us, kuyruk)"""
    n = len(md)
    if n < 64 or struct.unpack_from("<I", md, 0)[0] != TIP_MESH:
        raise ValueError("Mesh degil")
    nl = struct.unpack_from("<I", md, 8)[0]

    M = md.find(MARK_VF, 12 + nl)
    if M < 0:
        raise ValueError("vertex bicimi isaretcisi (0xC351EE43) yok")
    stridelar = struct.unpack_from("<4I", md, M + 9)
    alt_sayi = struct.unpack_from("<I", md, M + 25)[0]
    merkez = np.array(struct.unpack_from("<3f", md, M + 29), dtype=np.float64)
    yari = np.array(struct.unpack_from("<3f", md, M + 41), dtype=np.float64)
    bmin, bmax = merkez - yari, merkez + yari
    if stridelar[0] == 0 or stridelar[1] == 0:
        raise ValueError("beklenmeyen stride tablosu %s" % (stridelar,))

    def _altlari_oku(bas):
        alt, q = [], md.find(MAGIC_ALT, bas)
        while q >= 0 and len(alt) < alt_sayi:
            if q + 24 > n:
                break
            alt.append(struct.unpack_from("<QIII", md, q + 4))
            q = md.find(MAGIC_ALT, q + 4)
        return alt

    # Aday zincir baslangicini VEKTOREL suz (duz tarama mesh basina ~16k tur).
    bas0, bas1 = M + 54, min(n - 8, M + 54 + 16384)
    a8 = np.frombuffer(md, dtype=np.uint8)

    def _u32(o):
        o = np.asarray(o, dtype=np.int64)
        return (a8[o].astype(np.uint32) | (a8[o + 1].astype(np.uint32) << 8) |
                (a8[o + 2].astype(np.uint32) << 16) | (a8[o + 3].astype(np.uint32) << 24))

    kaba = np.arange(bas0, bas1, dtype=np.int64)
    if len(kaba) == 0:
        raise ValueError("zincir araligi bos")
    L0v = _u32(kaba).astype(np.int64)
    ok = (L0v >= 3 * stridelar[0]) & (L0v % stridelar[0] == 0) & (kaba + 8 + L0v <= n)
    kaba, L0v = kaba[ok], L0v[ok]
    if len(kaba):
        Vv = L0v // stridelar[0]
        L1v = _u32(kaba + 4 + L0v).astype(np.int64)
        ok = (Vv >= 3) & (L1v == Vv * stridelar[1])
        kaba = kaba[ok]

    secim = yedek = None
    for bas in kaba.tolist():
        h = _zincir(md, bas)
        if len(h) < 3:
            continue
        V = h[0][1] // stridelar[0]
        for k in range(len(h) - 1, 1, -1):
            io, il = h[k]
            if il < 6 or il % 6 or il // 2 > 3 * V * 8:
                continue
            ib = np.frombuffer(md[io:io + il], dtype="<u2")
            if int(ib.max()) >= V:
                continue
            alt = _altlari_oku(io + il)
            # KABUL KOSULU: zincirin yurumesi YETMEZ, alt-mesh tablosuyla capraz
            # dogrulanir -> sum(vertexSayisi)==V ve sum(ucgenSayisi)*6==len(indeks)
            tam = (alt and sum(a[1] for a in alt) == V and sum(a[3] for a in alt) * 6 == il)
            aday = (h, V, ib.reshape(-1, 3).astype(np.int32), io + il,
                    list(alt) if tam else [(0, V, 0, il // 6)])
            if tam:
                secim = aday
                break
            if yedek is None:
                yedek = aday
        if secim:
            break
    secim = secim or yedek
    if secim is None:
        raise ValueError("vertex/indeks tampon zinciri bulunamadi (stride %s)" % (stridelar,))
    h, V, TRI, kuyruk, altlar = secim

    uv_i = poz_i = None
    for k in range(min(4, len(h))):
        if h[k][1] == V * 8 and uv_i is None and stridelar[k] == 8:
            uv_i = k
        if h[k][1] == V * 12 and poz_i is None and stridelar[k] == 12:
            poz_i = k
    if poz_i is None:
        raise ValueError("stride-12 konum akisi yok (%s)" % (stridelar,))

    po, pl = h[poz_i]
    ham = np.frombuffer(md[po:po + pl], dtype="<i2").reshape(-1, 6)[:, :3].astype(np.float64)
    P0 = ham / 32768.0
    e0, eB = P0.max(0) - P0.min(0), bmax - bmin
    with np.errstate(divide="ignore", invalid="ignore"):
        oran = np.where(e0 > 1e-9, eB / np.maximum(e0, 1e-12), np.nan)
    if not np.isfinite(oran).any():
        raise ValueError("konum olcegi turetilemedi")
    us = float(np.median(oran[np.isfinite(oran)]))
    if abs(us - round(us)) < 0.01:
        us = float(round(us))
    P = P0 * us
    hata = float(max(np.abs(P.min(0) - bmin).max(), np.abs(P.max(0) - bmax).max()))
    if dogrula and hata > 2e-3:
        raise ValueError("olcek=%.4f sinir kutusuna oturmuyor (hata %.5f)" % (us, hata))

    if uv_i is None:
        UV = np.zeros((V, 2))
    else:
        uo, ul = h[uv_i]
        b4 = np.frombuffer(md[uo:uo + ul], dtype=np.uint8).reshape(-1, 8)[:, 4:8]
        UV = np.frombuffer(b4.tobytes(), dtype="<i2").reshape(-1, 2).astype(np.float64) / UV_BOLEN

    return dict(V=V, P=P, UV=UV, TRI=TRI, altlar=altlar, us=us, kuyruk=kuyruk,
                bbox_hata=hata, stridelar=stridelar)


# ==================================================================== DOKU YOLU
def _harici_mip(doku_id, seviye):
    base = (0xA0000000000 | doku_id) << 20
    lf = _forge()
    rid = base | seviye
    if rid not in lf.by_id:
        return None
    off, ln, _ext = lf.by_id[rid]
    lf.f.seek(off)
    return lf.f.read(ln)


_AILE_ENUM = {"BC1": 3, "BC1 varyanti": 2, "BC3": 5, "BC7": 10}


def _kucult(a, hedef):
    """KUTU (alan) filtresiyle kucult. Bu, onizlemedeki 'gokkusagi benek'in
    ilacidir: 2048^2 bir dokuyu ekranda 1-2 piksel kaplayan ucgenlerde nokta
    ornekleme yapmak MINIFIKASYON ALIASING'i uretiyordu (olculdu: Edward'in
    onkolundaki benek piksellerinin %55'i tek bir 2048'lik atlastan geliyordu)."""
    H, W = a.shape[0], a.shape[1]
    if max(H, W) <= hedef:
        return a
    from PIL import Image
    o = max(H, W) / float(hedef)
    nw, nh = max(1, int(round(W / o))), max(1, int(round(H / o)))
    im = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)).resize((nw, nh), Image.BOX)
    return np.asarray(im).astype(np.float64)


def _doku_oku(slot, hedef):
    """Slot tanimindan (H,W,3) float64 RGB dizi. Hedefe YETEN EN KUCUK harici mip
    seviyesi secilir: 2048^2 BC3 icin 4.194.304 B yerine 262.144 B okunur."""
    W, H = int(slot["W"]), int(slot["H"])
    doku_id = _mid(slot["doku_id"])
    fe = _AILE_ENUM.get(slot.get("aile"))
    if fe is None:
        fe = 3 if str(slot.get("aile")).startswith("BC1") else 5
    sec, veri = None, None
    for lvl in range(0, 8):
        w, h = max(1, W >> lvl), max(1, H >> lvl)
        d = _harici_mip(doku_id, lvl)
        if d is not None:
            sec, veri = lvl, d
        if max(w, h) <= hedef:
            break
    if veri is None:
        d2 = _oc().slot_mip0_bc(_mid(slot["_mat_id"]), int(slot["idx"])) if "_mat_id" in slot else (None, None)
        veri, tanim = d2
        if veri is None:
            return None
        w, h, fe = tanim["W"], tanim["H"], tanim["fmt_enum"]
    else:
        w, h = max(1, W >> sec), max(1, H >> sec)
    try:
        rgba = _oc()._bc_decode_rgba(veri, w, h, fe)
    except Exception:
        return None
    rgb = rgba[..., :3].astype(np.float64)
    renk = slot.get("renk")
    if renk:
        # zone-palet materyali (karakterler): doku GRI detay, gercek renk
        # materyal paletinde -> gri x renk x 2 (carpan-2 karisimi, olculdu)
        gri = rgb.mean(axis=2, keepdims=True) / 255.0
        rgb = np.clip(gri * np.asarray(renk, dtype=np.float64) * 2.0, 0, 255)
    return _kucult(rgb, hedef)


def _png_oku(im, hedef):
    """Kullanicinin BOYADIGI dokuyu (PIL.Image ya da yol) atlasa cevir."""
    from PIL import Image
    if isinstance(im, (str, bytes, os.PathLike)):
        if not os.path.isfile(im):
            return None
        im = Image.open(im)
    im = im.convert("RGB")
    if max(im.size) > hedef:
        o = max(im.size) / float(hedef)
        im = im.resize((max(1, int(round(im.size[0] / o))), max(1, int(round(im.size[1] / o)))),
                       Image.BOX)
    return np.asarray(im).astype(np.float64)


# ====================================================================== RENDER
def _donustur(P, merkez, aci, egim=0.0):
    """Z-yukari karakter uzayindan ekran uzayina (X saga, Y yukari, Z izleyiciye)."""
    a = np.radians(aci)
    c, s = np.cos(a), np.sin(a)
    Q = P - merkez
    x = Q[:, 0] * c + Q[:, 1] * s
    y = -Q[:, 0] * s + Q[:, 1] * c
    z = Q[:, 2]
    if egim:
        b = np.radians(egim)
        cb, sb = np.cos(b), np.sin(b)
        y, z = y * cb - z * sb, y * sb + z * cb
    return np.stack([x, z, -y], 1)


def _vertex_normalleri(P, TRI):
    fn = np.cross(P[TRI[:, 1]] - P[TRI[:, 0]], P[TRI[:, 2]] - P[TRI[:, 0]])
    _, grp = np.unique(np.round(P, 5), axis=0, return_inverse=True)
    Ng = np.zeros((int(grp.max()) + 1, 3))
    for k in range(3):
        np.add.at(Ng, grp[TRI[:, k]], fn)
    Ng /= np.maximum(np.linalg.norm(Ng, axis=1, keepdims=True), 1e-12)
    return Ng[grp]


def _tara(XY, Z, TRI, boyut):
    """Ucgenleri PIKSEL KUTUSU boyutuna gore kovalayip toplu tarar.
    Ucgen basina Python dongusu YOK: bir kiyafette 200.000+ ucgen var."""
    p0, p1, p2 = XY[TRI[:, 0]], XY[TRI[:, 1]], XY[TRI[:, 2]]
    det = ((p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1]) -
           (p2[:, 0] - p0[:, 0]) * (p1[:, 1] - p0[:, 1]))
    xmin = np.floor(np.minimum(np.minimum(p0[:, 0], p1[:, 0]), p2[:, 0]))
    xmax = np.ceil(np.maximum(np.maximum(p0[:, 0], p1[:, 0]), p2[:, 0]))
    ymin = np.floor(np.minimum(np.minimum(p0[:, 1], p1[:, 1]), p2[:, 1]))
    ymax = np.ceil(np.maximum(np.maximum(p0[:, 1], p1[:, 1]), p2[:, 1]))
    gecerli = ((np.abs(det) > 1e-12) & (det < 0) &          # det<0 : arka yuz eleme
               (xmax >= 0) & (ymax >= 0) & (xmin < boyut) & (ymin < boyut))
    idx = np.where(gecerli)[0]
    if len(idx) == 0:
        return None
    x0 = np.clip(xmin[idx], 0, boyut - 1).astype(np.int32)
    y0 = np.clip(ymin[idx], 0, boyut - 1).astype(np.int32)
    gw = np.clip(xmax[idx], 0, boyut - 1).astype(np.int32) - x0 + 1
    gh = np.clip(ymax[idx], 0, boyut - 1).astype(np.int32) - y0 + 1
    us = np.ceil(np.log2(np.maximum(np.maximum(gw, gh), 1))).astype(np.int32)
    cikti = []
    for u in np.unique(us):
        s = int(1 << u)
        sel = np.where(us == u)[0]
        adim = max(1, int(4_000_000 // (s * s)))
        oy, ox = np.divmod(np.arange(s * s), s)
        for b in range(0, len(sel), adim):
            ss = sel[b:b + adim]
            tt = idx[ss]
            px = x0[ss][:, None] + ox[None, :]
            py = y0[ss][:, None] + oy[None, :]
            ic = (px < boyut) & (py < boyut)
            q0, q1, q2 = p0[tt], p1[tt], p2[tt]
            d = det[tt][:, None]
            fx, fy = px + 0.5, py + 0.5
            w1 = ((fx - q0[:, 0:1]) * (q2[:, 1:2] - q0[:, 1:2]) -
                  (q2[:, 0:1] - q0[:, 0:1]) * (fy - q0[:, 1:2])) / d
            w2 = ((q1[:, 0:1] - q0[:, 0:1]) * (fy - q0[:, 1:2]) -
                  (fx - q0[:, 0:1]) * (q1[:, 1:2] - q0[:, 1:2])) / d
            w0 = 1.0 - w1 - w2
            m = ic & (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
            if not m.any():
                continue
            ti, pi = np.where(m)
            gt = tt[ti]
            a0, a1, a2 = w0[ti, pi], w1[ti, pi], w2[ti, pi]
            zz = a0 * Z[TRI[gt, 0]] + a1 * Z[TRI[gt, 1]] + a2 * Z[TRI[gt, 2]]
            cikti.append((py[ti, pi].astype(np.int64) * boyut + px[ti, pi], zz, gt, a0, a1, a2))
    if not cikti:
        return None
    return [np.concatenate([c[k] for c in cikti]) for k in range(6)]


def kamera_hesapla(parcalar, kenar=1.06):
    """Tum parcalarin sinir kutusundan (merkez, R). Karakter uzayi Z YUKARI."""
    mn, mx = np.full(3, np.inf), np.full(3, -np.inf)
    for p in parcalar:
        if len(p["P"]):
            mn = np.minimum(mn, p["P"].min(0))
            mx = np.maximum(mx, p["P"].max(0))
    if not np.isfinite(mn).all():
        return None
    return ((mn + mx) / 2.0, max(max(mx[0] - mn[0], mx[2] - mn[2]) / 2.0 * kenar, 1e-6))


def render_coklu(parcalar, boyut=512, aci=0.0, egim=0.0, arka=ARKA_PLAN,
                 ambiyans=0.35, istatistik=None, kamera=None):
    """parcalar: [dict(P, UV, TRI, atlas|None, renk?)] -> (boyut,boyut,3) uint8

    TUM parcalar ORTAK derinlik cozumune girer; parca parca render edip ust uste
    yapistirmak derinligi karistirir (kabul testi K7 bunu AYNI kamerayla olcer)."""
    kamera = kamera or kamera_hesapla(parcalar)
    if kamera is None:
        return np.tile(np.asarray(arka, np.uint8), (boyut, boyut, 1))
    merkez, R = kamera
    S = boyut / (2.0 * R)

    pix_h, z_h, tri_h, w_h, par_h, VNs = [], [], [], [], [], []
    n_tri = n_frag = 0
    for i, p in enumerate(parcalar):
        P, TRI = p["P"], p["TRI"]
        if len(TRI) == 0:
            VNs.append(None); continue
        Pd = _donustur(P, merkez, aci, egim)
        XY = np.stack([Pd[:, 0] * S + boyut / 2.0, boyut / 2.0 - Pd[:, 1] * S], 1)
        VN = _vertex_normalleri(Pd, TRI)
        VNs.append(VN)
        n_tri += len(TRI)
        r = _tara(XY, Pd[:, 2], TRI, boyut)
        if r is None:
            continue
        pix, zz, gt, a0, a1, a2 = r
        n_frag += len(pix)
        pix_h.append(pix); z_h.append(zz); tri_h.append(gt)
        w_h.append(np.stack([a0, a1, a2], 1))
        par_h.append(np.full(len(pix), i, np.int32))

    img = np.empty((boyut * boyut, 3), np.float64)
    img[:] = np.asarray(arka, np.float64)
    if not pix_h:
        return img.reshape(boyut, boyut, 3).astype(np.uint8)

    pix = np.concatenate(pix_h); zz = np.concatenate(z_h)
    tri = np.concatenate(tri_h); wgt = np.concatenate(w_h); par = np.concatenate(par_h)
    # ORTAK derinlik cozumu: pikselde en ONDEKI (en buyuk z) parcacik kazanir
    sira = np.lexsort((-zz, pix))
    pix_s = pix[sira]
    kaz = sira[np.concatenate(([True], pix_s[1:] != pix_s[:-1]))]
    kpix, ktri, kw, kpar = pix[kaz], tri[kaz], wgt[kaz], par[kaz]

    for i, p in enumerate(parcalar):
        sel = np.where(kpar == i)[0]
        if len(sel) == 0:
            continue
        TRI, UV, VN = p["TRI"], p["UV"], VNs[i]
        t3, w = TRI[ktri[sel]], kw[sel]
        atlas = p.get("atlas")
        if atlas is None:
            renk = np.tile(np.asarray(p.get("renk", DOKUSUZ_RENK), np.float64), (len(sel), 1))
        else:
            AH, AW = atlas.shape[0], atlas.shape[1]
            uu = w[:, 0] * UV[t3[:, 0], 0] + w[:, 1] * UV[t3[:, 1], 0] + w[:, 2] * UV[t3[:, 2], 0]
            vv = w[:, 0] * UV[t3[:, 0], 1] + w[:, 1] * UV[t3[:, 1], 1] + w[:, 2] * UV[t3[:, 2], 1]
            ax = np.clip(np.mod(uu, 1.0) * AW, 0, AW - 1.001)
            ay = np.clip(np.mod(vv, 1.0) * AH, 0, AH - 1.001)
            xi, yi = ax.astype(np.int32), ay.astype(np.int32)
            fx, fy = (ax - xi)[:, None], (ay - yi)[:, None]
            x1, y1 = np.minimum(xi + 1, AW - 1), np.minimum(yi + 1, AH - 1)
            renk = (atlas[yi, xi] * ((1 - fx) * (1 - fy)) + atlas[yi, x1] * (fx * (1 - fy)) +
                    atlas[y1, xi] * ((1 - fx) * fy) + atlas[y1, x1] * (fx * fy))
        nrm = w[:, 0:1] * VN[t3[:, 0]] + w[:, 1:2] * VN[t3[:, 1]] + w[:, 2:3] * VN[t3[:, 2]]
        nrm /= np.maximum(np.linalg.norm(nrm, axis=1, keepdims=True), 1e-12)
        parlak = ambiyans + (1.0 - ambiyans) * np.maximum(0.0, nrm @ ISIK)
        img[kpix[sel]] = np.clip(renk * parlak[:, None], 0, 255)

    if istatistik is not None:
        istatistik.update(ucgen=n_tri, parcacik=int(n_frag), kazanan=int(len(kaz)),
                          parca=len(parcalar))
    return img.reshape(boyut, boyut, 3).astype(np.uint8)


# ====================================================================== INDEKS
def _indeks_yukle():
    if not os.path.isfile(INDEKS_YOL):
        return {}
    try:
        with open(INDEKS_YOL, encoding="utf-8") as f:
            d = json.load(f)
        return d.get("kiyafetler", {})
    except Exception:
        return {}


_INDEKS = [None]


def indeks():
    if _INDEKS[0] is None:
        _INDEKS[0] = _indeks_yukle()
    return _INDEKS[0]


def _db(yol):
    import sqlite3
    return sqlite3.connect("file:%s?mode=ro" % yol.replace("\\", "/"), uri=True)


def _canli_kiyafet_indeksi(o, vdb, ddb):
    """Bir kiyafetin mesh+materyal+doku haritasini ansiklopediden CIKAR (indeks kurulumu).
    Calisma aninda cagrilmaz — pisirilmis JSON kullanilir."""
    eg_id = _mid(o["EG_id"])
    # 1) EG govdesindeki kimlikler -> Mesh olanlar
    gorulen = set()
    for _icid, b in _giris_ic_dosyalari(eg_id):
        gorulen.update(_id_adaylari(b))
    satirlar = []
    if gorulen:
        q = ",".join(str(v) for v in gorulen)
        satirlar = list(vdb.execute(
            "select giris_id, ic_id, ad, boyut from ic_dosyalar "
            "where forge='DataPC_boot.forge' and tip=%d and ic_id in (%s)" % (TIP_MESH, q)))
    # 2) ad suzgeci (EG'nin ISARET ETMEDIGI LOD'lar icin) — LOD0 daima en BUYUKTUR
    ad_satir = list(vdb.execute(
        "select giris_id, ic_id, ad, boyut from ic_dosyalar "
        "where tip=? and forge='DataPC_boot.forge' and ad like ?", (TIP_MESH, "%" + o["ad"] + "%")))
    var = set((r[0], r[1]) for r in satirlar)
    for r in ad_satir:
        if (r[0], r[1]) not in var:
            satirlar.append(r)

    gruplar = {}
    for gid, icid, ad, boy in satirlar:
        taban, i = ad, ad.rfind("_L")
        if i > 0 and len(ad) - i <= 5:          # '_LOD0' / '_LOD?' / '_L???'
            taban = ad[:i]
        gruplar.setdefault(taban, []).append([boy, gid, icid, ad])
    for lst in gruplar.values():
        lst.sort(key=lambda t: -t[0])

    matset = set(r[0] for r in vdb.execute(
        "select ic_id from ic_dosyalar where forge='DataPC_boot.forge' and tip=?", (TIP_MATERIAL,)))
    katalog_mat = set(_mid(m["mat_id"]) for m in o["materyaller"])

    mesh_mat, kap = {}, {}
    for lst in gruplar.values():
        for boy, gid, icid, ad in lst:
            if gid not in kap:
                kap[gid] = dict(_giris_ic_dosyalari(gid))
            md = kap[gid].get(icid)
            if md is None:
                continue
            try:
                m = mesh_coz(md)
            except Exception:
                continue
            bul = [(v, off) for v, off in _id_adaylari(md[m["kuyruk"]:]).items() if v in matset]
            bul.sort(key=lambda t: t[1])
            if len(bul) != len(m["altlar"]):
                b2 = []
                for mid in katalog_mat:
                    q = md.find(struct.pack("<Q", mid), m["kuyruk"])
                    if q >= 0:
                        b2.append((mid, q))
                b2.sort(key=lambda t: t[1])
                if len(b2) == len(m["altlar"]):
                    bul = b2
            mesh_mat["%d:%d" % (gid, icid)] = ["0x%X" % v for v, _ in bul]
        kap.clear()

    # 3) her materyalin DIFFUSE slotu (katalogdakiler dahil — 3 Edward materyalinin
    #    katalogda 0 slotu var, forge'dan olculur)
    doku = {}
    kat = {_mid(m["mat_id"]): m for m in o["materyaller"]}
    tum = set()
    for v in mesh_mat.values():
        tum.update(_mid(x) for x in v)
    for mid in sorted(tum):
        s = None
        m = kat.get(mid)
        if m:
            for sl in m.get("slotlar", []):
                rol = (sl.get("rol") or "").lower()
                if "colour" in rol or "diffuse" in rol:
                    s = dict(idx=sl["idx"], doku_id=sl["doku_id"], W=sl["W"], H=sl["H"],
                             aile=sl["aile"], srgb=sl.get("srgb", 1))
                    break
        if s is None:
            s = _mat_diffuse_olc(mid, vdb, ddb)
        doku["0x%X" % mid] = s
    return dict(ad=o["ad"], gorunen_ad=o["gorunen_ad"], EG_id=o["EG_id"],
                gruplar=[dict(taban=t, lodlar=l) for t, l in sorted(gruplar.items())],
                mesh_mat=mesh_mat, doku=doku)


def _mat_govde(mat_id, vdb):
    OC = _oc()
    try:
        return OC._material_res(mat_id)
    except KeyError:
        pass
    row = list(vdb.execute("select giris_id from ic_dosyalar where forge='DataPC_boot.forge' "
                           "and ic_id=? limit 1", (mat_id,)))
    if not row:
        return None
    for icid, b in _giris_ic_dosyalari(row[0][0]):
        if icid == mat_id:
            return b
    return None


def _mat_diffuse_olc(mat_id, vdb, ddb):
    """Katalogda slotu OLMAYAN materyalin diffuse dokusunu forge'dan olc.
    Kural: TextureMap tanimlarinda srgb=1 olan ILK slot renk slotudur. Hic
    TextureMap yoksa (Fire kiyafetinin govde materyalleri) doku bagimlilik
    listesinde ADIYLA durur -> dokular.db'de '..._DiffuseMap' olani sec."""
    OC = _oc()
    res = None
    try:
        res = _mat_govde(mat_id, vdb)
        if res is not None:
            for i, (hdr, tex) in enumerate(OC.DE.tm_bloklari(res)):
                t = OC.DE.tanim_oku(res, hdr)
                if t.get("srgb"):
                    return dict(idx=i, doku_id="0x%X" % tex, W=t["W"], H=t["H"],
                                aile=t["aile"], srgb=1)
    except Exception:
        res = res
    if res is None or ddb is None:
        return None
    adaylar = _id_adaylari(res)
    if not adaylar:
        return None
    q = ",".join(str(v) for v in adaylar)
    rows = list(ddb.execute("select ic_id, ad, w, h, fmt_ad, gamma, gorsel_tur from dokular "
                            "where forge='DataPC_boot.forge' and ic_id in (%s)" % q))
    if not rows:
        return None
    rows.sort(key=lambda r: (0 if "diffusemap" in (r[1] or "").lower()
                             else (1 if (r[6] or "") == "diffuse" else 2), adaylar[r[0]]))
    r = rows[0]
    if "diffuse" not in ((r[1] or "").lower() + (r[6] or "")):
        return None
    return dict(idx=0, doku_id="0x%X" % r[0], W=r[2], H=r[3], aile=r[4] or "BC3",
                srgb=bool(r[5]))


def indeks_kur(yol=None, yaz=True, ilerleme=None):
    """20 kiyafetin mesh/materyal/doku haritasini uret ve JSON'a yaz.
    ANSIKLOPEDI GEREKTIRIR (varliklar.db + dokular.db). Render bunu GEREKTIRMEZ."""
    yol = yol or INDEKS_YOL
    vdb = _db(VARLIK_DB)
    ddb = _db(DOKU_DB) if os.path.isfile(DOKU_DB) else None
    out = {}
    try:
        for o in katalog():
            t0 = time.time()
            out[o["ad"]] = _canli_kiyafet_indeksi(o, vdb, ddb)
            if ilerleme:
                ilerleme("%-22s %2d mesh grubu, %3d mesh, %2d materyal  %.2f sn" % (
                    o["ad"], len(out[o["ad"]]["gruplar"]), len(out[o["ad"]]["mesh_mat"]),
                    len(out[o["ad"]]["doku"]), time.time() - t0))
    finally:
        vdb.close()
        if ddb:
            ddb.close()
        _kapat()
    veri = dict(surum=1, uretim=time.strftime("%Y-%m-%d %H:%M"), kiyafetler=out)
    if yaz:
        with open(yol, "w", encoding="utf-8") as f:
            json.dump(veri, f, ensure_ascii=False, separators=(",", ":"))
    _INDEKS[0] = out
    return veri


# ====================================================================== OTURUM
class Oturum:
    """Mesh/doku onbellegini SICAK tutar. GUI bunu uygulama omru boyunca acik
    tutmali, ama pencere kapanirken `.kapat()` cagirmalidir (Steam kilidi)."""

    def __init__(self):
        self._mesh = {}       # (gid, icid) -> cozulmus mesh
        self._atlas = {}      # (mat_id, hedef) -> atlas
        self._giris = {}      # gid -> {icid: bytes}   (kucuk, temizlenir)

    # -------------------------------------------------------------- ic yardimcilar
    def _giris_oku(self, gid):
        if gid not in self._giris:
            if len(self._giris) > 8:
                self._giris.clear()
            self._giris[gid] = dict(_giris_ic_dosyalari(gid))
        return self._giris[gid]

    def _mesh_al(self, gid, icid):
        a = (gid, icid)
        if a not in self._mesh:
            md = self._giris_oku(gid).get(icid)
            if md is None:
                raise KeyError("ic dosya yok")
            self._mesh[a] = mesh_coz(md)
        return self._mesh[a]

    def _atlas_al(self, mat_id, slot, hedef, ust_yazim):
        if ust_yazim is not None:
            return _png_oku(ust_yazim, hedef)
        a = (mat_id, hedef)
        if a not in self._atlas:
            if len(self._atlas) > 200:
                self._atlas.clear()
            s = dict(slot); s["_mat_id"] = mat_id
            try:
                self._atlas[a] = _doku_oku(s, hedef)
            except Exception:
                self._atlas[a] = None
        return self._atlas[a]

    # ------------------------------------------------------------------ sahne
    def sahne(self, kiyafet_adi, doku_ust_yazim=None, lod=0, doku_hedef=256, olcum=None):
        """-> parca listesi ya da None (mesh yok / kiyafet yok)."""
        o = _kiyafet_bul(kiyafet_adi)
        if o is None:
            # katalogda yok ama indekste pisirilmis olabilir (CHR_* karakter
            # girisleri katalogsuz yasar) -> indeksten kimlik uydur
            ix0 = indeks().get(str(kiyafet_adi))
            if ix0 is not None:
                o = {"ad": str(kiyafet_adi),
                     "gorunen_ad": ix0.get("gorunen_ad", str(kiyafet_adi))}
            else:
                if olcum is not None:
                    olcum["sebep"] = "kiyafet katalogda yok: %r" % (kiyafet_adi,)
                return None
        ix = indeks().get(o["ad"])
        if ix is None:
            if olcum is not None:
                olcum["sebep"] = ("indekste yok: %s (indeks_kur() calistirilmali)" % o["ad"])
            return None
        ust = {}
        for k, v in (doku_ust_yazim or {}).items():
            ust[_mid(k)] = v

        t0 = time.time()
        parcalar, sorunlar = [], []
        for g in ix["gruplar"]:
            lodlar = g["lodlar"]
            boy, gid, icid, ad = lodlar[min(lod, len(lodlar) - 1)]
            try:
                m = self._mesh_al(gid, icid)
            except Exception as e:
                sorunlar.append((ad, str(e)))
                continue
            matlar = ix["mesh_mat"].get("%d:%d" % (gid, icid), [])
            for i, (iv, vc, ii, tc) in enumerate(m["altlar"]):
                tri = m["TRI"][ii // 3: ii // 3 + tc]
                if len(tri) == 0:
                    continue
                # ALT-MESH INDEKSLERI GORELIDIR (0..vertexSayisi-1); ilkVertex
                # EKLENMEZ. Yanlis yorum ucgenleri modelin karsi ucuna baglar.
                if int(tri.max()) < vc:
                    Ps, Us, Ts, nv = m["P"][iv:iv + vc], m["UV"][iv:iv + vc], tri, int(vc)
                else:
                    lo, hi = int(tri.min()), int(tri.max())
                    Ps, Us, Ts, nv = m["P"][lo:hi + 1], m["UV"][lo:hi + 1], tri - lo, hi - lo + 1
                mid = _mid(matlar[i]) if i < len(matlar) else None
                parcalar.append(dict(ad="%s#%d" % (ad, i), mesh_ad=ad, alt=i, mat_id=mid,
                                     P=Ps, UV=Us, TRI=Ts.astype(np.int32),
                                     ucgen=int(tc), vertex=nv))
        t_mesh = time.time() - t0
        if not parcalar:
            if olcum is not None:
                olcum["sebep"] = "hicbir mesh cozulemedi"
                olcum["sorun"] = sorunlar
            return None

        t0 = time.time()
        dokulu = boyali = 0
        for p in parcalar:
            p["atlas"] = None
            mid = p["mat_id"]
            if mid is None:
                continue
            slot = ix["doku"].get("0x%X" % mid)
            if slot == "GIZLE":
                # oyunun gizleme materyali (CHR_Tmp_Hide): parca hic cizilmez
                p["gizle"] = True
                continue
            uy = ust.get(mid)
            if slot is None and uy is None:
                continue
            p["atlas"] = self._atlas_al(mid, slot or {}, doku_hedef, uy)
            if p["atlas"] is not None:
                dokulu += 1
                if uy is not None:
                    boyali += 1
        parcalar = [p for p in parcalar if not p.get("gizle")]
        t_doku = time.time() - t0
        if olcum is not None:
            olcum.update(kiyafet=o["gorunen_ad"], kod=o["ad"], lod=lod,
                         parca=len(parcalar), dokulu=dokulu, boyali=boyali,
                         mesh=len(ix["gruplar"]), sorun=sorunlar,
                         vertex=sum(p["vertex"] for p in parcalar),
                         ucgen=sum(p["ucgen"] for p in parcalar),
                         t_mesh=t_mesh, t_doku=t_doku)
        return parcalar

    def render(self, kiyafet_adi, doku_ust_yazim=None, aci=0, boyut=512, lod=0,
               egim=0.0, ssaa=2, doku_hedef=None, olcum=None):
        olcum = olcum if olcum is not None else {}
        hedef = doku_hedef or max(128, boyut // 2)
        parcalar = self.sahne(kiyafet_adi, doku_ust_yazim, lod, hedef, olcum)
        if parcalar is None:
            return None
        ssaa = max(1, int(ssaa))
        ist = {}
        t0 = time.time()
        img = render_coklu(parcalar, boyut=boyut * ssaa, aci=aci, egim=egim, istatistik=ist)
        olcum.update(ist)
        olcum["t_render"] = time.time() - t0
        olcum["ssaa"] = ssaa
        olcum["doku_hedef"] = hedef
        from PIL import Image
        im = Image.fromarray(img)
        if ssaa > 1:
            im = im.resize((boyut, boyut), Image.BOX)      # kenar yumusatma
        return im

    def kapat(self):
        self._mesh.clear(); self._atlas.clear(); self._giris.clear()
        _kapat()


# ======================================================================== API
def kiyafet_render(kiyafet_adi, doku_ust_yazim=None, aci=0, boyut=512, **k):
    """Kiyafetin dokulu 3D onizlemesi -> PIL.Image, ya da None.

    doku_ust_yazim : {mat_id: PIL.Image}  kullanicinin BOYADIGI dokular
    aci            : derece, karakter ekseni etrafinda dondurme
    boyut          : kare cikti kenari (piksel)
    ek anahtarlar  : lod=0, egim=0.0, ssaa=2, doku_hedef=None, olcum=dict

    Mesh bulunamayan / cozulemeyen kiyafette ISTISNA FIRLATMAZ -> None doner
    (cagiran taraf panelde "no 3D preview for this outfit" yazabilsin).
    Forge taniticisi cagri bitince KAPATILIR."""
    olcum = k.pop("olcum", None)
    o = Oturum()
    try:
        return o.render(kiyafet_adi, doku_ust_yazim, aci, boyut, olcum=olcum, **k)
    except Exception as e:                       # hicbir kosulda GUI'yi dusurme
        if olcum is not None:
            olcum["sebep"] = "%s: %s" % (type(e).__name__, e)
        return None
    finally:
        o.kapat()                                # forge taniticisi KAPANIR


# ========================================================================= CLI
def _yardim():
    print(__doc__)
    print("Kullanim:")
    print("  python onizleme3d.py --indeks               # indeksi (yeniden) kur")
    print("  python onizleme3d.py <kiyafet> [boyut] [aci] [cikti.png]")
    print("\nKiyafetler:")
    for ad, gad in kiyafetler():
        print("   %-22s %s" % (ad, gad))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        _yardim()
        sys.exit(0)
    if sys.argv[1] == "--indeks":
        t0 = time.time()
        v = indeks_kur(ilerleme=lambda s: print("  " + s))
        print("indeks yazildi: %s  (%d kiyafet, %.1f sn, %d B)" % (
            INDEKS_YOL, len(v["kiyafetler"]), time.time() - t0, os.path.getsize(INDEKS_YOL)))
        sys.exit(0)
    ad = sys.argv[1]
    boyut = int(sys.argv[2]) if len(sys.argv) > 2 else 512
    aci = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
    cikti = sys.argv[4] if len(sys.argv) > 4 else None
    ol = {}
    t0 = time.time()
    im = kiyafet_render(ad, aci=aci, boyut=boyut, olcum=ol)
    top = time.time() - t0
    if im is None:
        print("3D onizleme YOK: %s" % ol.get("sebep"))
        sys.exit(1)
    if cikti:
        im.save(cikti)
    print("  %-12s %s" % ("kiyafet", ol.get("kiyafet")))
    for anah in ("parca", "mesh", "dokulu", "boyali", "vertex", "ucgen", "parcacik",
                 "kazanan", "ssaa", "doku_hedef", "t_mesh", "t_doku", "t_render"):
        if anah in ol:
            v = ol[anah]
            print("  %-12s %s" % (anah, ("%.3f sn" % v) if anah.startswith("t_") else v))
    print("  %-12s %.3f sn" % ("TOPLAM", top))
    if ol.get("sorun"):
        print("  sorun: %s" % (ol["sorun"],))
    if cikti:
        print("  png          %s" % cikti)
