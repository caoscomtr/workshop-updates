# -*- coding: utf-8 -*-
"""SAVE CORE — AC IV Resynced kayit dosyasi okuma/yazma cekirdegi (Workshop).

Kullanici metinleri INGILIZCE, kod yorumlari Turkce (proje kurali).

GUVENLIK ILKELERI (hepsi kodda zorunlu):
  * Her yazimdan ONCE otomatik yedek alinir; yedek alinamazsa YAZILMAZ.
  * Oyun calisiyorsa yazim REDDEDILIR (Anvil kaydi ezip geri alir).
  * Yazim sonrasi tur-donus dogrulanir: coz(sifrele(x)) == x.
  * Boyut ASLA degismez — XOR anahtarinin donusu (rot) yuk boyutuna baglidir.
  * Kayit kimligi hesaba BAGLI: anahtar, hesabin UUID'sinden turer.

Sifreleme (olculmus): pre = rotr(reversed(MD5(uuid)), 1)
                      post = rotr(pre, len(yuk) % 16)
                      duz[i] = yuk[i] XOR post[i % 16]
Dogrulama kapisi: duz[0:4] == AC DB FE 00 (MAGIC)
"""
import hashlib
import json
import os
import shutil
import struct
import subprocess
import time

MAGIC = bytes.fromhex("acdbfe00")
IMZA = bytes.fromhex("33AAFB5799FA0410")
HDR = 40                                   # sifrelenmemis baslik uzunlugu
OYUN_ID = "66088"                          # Ubisoft oyun kimligi (AC4 Resynced)

_KOKLER = [
    r"C:\Program Files (x86)\Ubisoft\Ubisoft Game Launcher\savegames",
    r"C:\Program Files\Ubisoft\Ubisoft Game Launcher\savegames",
]


# ------------------------------------------------------------------ sifreleme
def _rotr(b, n):
    n %= len(b)
    return b[-n:] + b[:-n] if n else b


def _pre_uuid(uuid):
    return _rotr(bytes(reversed(hashlib.md5(uuid.lower().encode()).digest())), 1)


def _post(pre, yuk_len):
    return _rotr(pre, yuk_len % 16)


def coz_ham(ham, pre):
    """Ham dosya baytlarini coz. Doner: (baslik, duz_govde)."""
    baslik, yuk = ham[:HDR], ham[HDR:]
    p = _post(pre, len(yuk))
    return baslik, bytes(y ^ p[i % 16] for i, y in enumerate(yuk))


def sifrele_ham(baslik, govde, pre):
    p = _post(pre, len(govde))
    return baslik + bytes(g ^ p[i % 16] for i, g in enumerate(govde))


def gecerli(govde):
    """Cozulmus govde gercekten bu oyunun kaydi mi?"""
    return govde[:4] == MAGIC and govde[36:44] == IMZA


# ------------------------------------------------------------ hesap / klasor
def _profil_kokleri():
    for kok in _KOKLER:
        if os.path.isdir(kok):
            yield kok


def hesaplar():
    """Makinedeki AC4 Resynced kayit klasorlerini bul.
    Doner: [{uuid, klasor, kayit_sayisi}]"""
    out = []
    for kok in _profil_kokleri():
        for uuid in sorted(os.listdir(kok)):
            k = os.path.join(kok, uuid, OYUN_ID)
            if not os.path.isdir(k):
                continue
            # DIKKAT: glob KULLANMA — dosya adindaki [ ] karakter sinifi sayilir
            n = len([f for f in os.listdir(k) if f.endswith(".save")])
            if n:
                out.append({"uuid": uuid, "klasor": k, "kayit_sayisi": n})
    return out


def anahtar_dogrula(klasor, uuid):
    """Bu UUID bu klasorun kayitlarini gercekten cozuyor mu? (MAGIC kapisi)"""
    pre = _pre_uuid(uuid)
    adlar = [f for f in os.listdir(klasor) if f.endswith(".save")]
    if not adlar:
        return False
    for f in adlar[:3]:
        ham = open(os.path.join(klasor, f), "rb").read()
        if len(ham) <= HDR:
            continue
        _b, g = coz_ham(ham, pre)
        if not gecerli(g):
            return False
    return True


def _son_oynama(klasor):
    """Klasordeki en yeni .save'in mtime'i (hesap siralamasi icin)."""
    try:
        return max(os.path.getmtime(os.path.join(klasor, f))
                   for f in os.listdir(klasor) if f.endswith(".save"))
    except (OSError, ValueError):
        return 0.0


def dogrulanmis_hesaplar():
    """MAGIC ile dogrulanan hesaplar, EN SON OYNANAN once.
    Doner: [{uuid, klasor, kayit_sayisi, son_oynama}]"""
    out = []
    for h in hesaplar():
        try:
            if anahtar_dogrula(h["klasor"], h["uuid"]):
                h = dict(h); h["son_oynama"] = _son_oynama(h["klasor"])
                out.append(h)
        except Exception:
            continue
    out.sort(key=lambda x: -x["son_oynama"])
    return out


def otomatik_hesap():
    """Kendi kendine calisan hesap secimi: klasor adi = UUID, MAGIC ile
    dogrulanir. Birden fazla hesap varsa EN SON OYNANAN secilir (eskiden
    alfabetik ilk hesap seciliyordu — cok hesapli PC'de yanlis kayit
    duzenlenebilirdi; denetimde olculdu). Doner: {uuid, klasor} veya None."""
    h = dogrulanmis_hesaplar()
    return h[0] if h else None


# ------------------------------------------------------------------- oturum
class Kayitlar:
    """Bir hesabin kayitlari uzerinde guvenli okuma/yazma oturumu."""

    def __init__(self, klasor=None, uuid=None):
        if klasor is None or uuid is None:
            h = otomatik_hesap()
            if not h:
                raise RuntimeError("No Assassin's Creed IV save folder was found "
                                   "for any Ubisoft account on this PC.")
            klasor, uuid = h["klasor"], h["uuid"]
        self.klasor, self.uuid = klasor, uuid
        self.pre = _pre_uuid(uuid)
        if not anahtar_dogrula(klasor, uuid):
            raise RuntimeError("These saves belong to a different Ubisoft "
                               "account and cannot be read.")

    # ---------------------------------------------------------- listeleme
    def liste(self):
        out = []
        for f in sorted(os.listdir(self.klasor)):
            if not f.endswith(".save"):
                continue
            yol = os.path.join(self.klasor, f)
            try:
                ham = open(yol, "rb").read()
                _b, g = coz_ham(ham, self.pre)
                ok = gecerli(g)
            except Exception:
                ok = False
                g = b""
            ad = f.replace("ACBlackFlag[", "").replace("].save", "")
            out.append({"ad": ad, "dosya": f, "boyut": len(g), "okunur": ok,
                        "zaman": time.strftime("%Y-%m-%d %H:%M",
                                               time.localtime(os.path.getmtime(yol)))})
        return out

    def yol(self, ad):
        return os.path.join(self.klasor, "ACBlackFlag[%s].save" % ad)

    def govde(self, ad):
        ham = open(self.yol(ad), "rb").read()
        baslik, g = coz_ham(ham, self.pre)
        if not gecerli(g):
            raise RuntimeError("This save could not be read (wrong account?).")
        return baslik, g

    # ------------------------------------------------------------- yedek
    def yedek_klasoru(self):
        return os.path.join(os.path.expanduser("~"), "Documents",
                            "OutfitWorkshop", "save_backup")

    def yedekle(self, ad):
        """Yazimdan ONCE cagrilir. Yedek alinamazsa istisna firlatir."""
        kok = os.path.join(self.yedek_klasoru(),
                           time.strftime("%Y%m%d_%H%M%S"))
        os.makedirs(kok, exist_ok=True)
        kaynak = self.yol(ad)
        hedef = os.path.join(kok, os.path.basename(kaynak))
        shutil.copy2(kaynak, hedef)
        if not os.path.isfile(hedef) or os.path.getsize(hedef) != os.path.getsize(kaynak):
            raise RuntimeError("Backup failed - nothing was written.")
        return hedef

    # -------------------------------------------------------------- yazma
    def oyun_acik_mi(self):
        try:
            c = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ACBlackFlag.exe"],
                               capture_output=True, text=True, timeout=10,
                               creationflags=getattr(subprocess,
                                                     "CREATE_NO_WINDOW", 0))
            return "ACBlackFlag.exe" in (c.stdout or "")
        except Exception:
            return False

    def yaz(self, ad, yamalar):
        """yamalar: [(ofset, bytes), ...]. Kapilardan gecerse dosyayi degistirir.

        Doner: {"yedek": yol, "degisen_bayt": n}
        """
        if self.oyun_acik_mi():
            raise RuntimeError("Close the game first - Anvil would overwrite "
                               "the file when it exits.")
        baslik, govde = self.govde(ad)
        yeni = bytearray(govde)
        for off, veri in yamalar:
            if off < 0 or off + len(veri) > len(yeni):
                raise RuntimeError("Internal error: offset outside the save.")
            yeni[off:off + len(veri)] = veri
        yeni = bytes(yeni)
        if len(yeni) != len(govde):
            raise RuntimeError("Internal error: save size changed.")
        degisen = sum(1 for i in range(len(govde)) if govde[i] != yeni[i])

        ham_yeni = sifrele_ham(baslik, yeni, self.pre)
        _b, geri = coz_ham(ham_yeni, self.pre)
        if geri != yeni:                      # tur-donus kapisi
            raise RuntimeError("Internal error: verification failed, nothing "
                               "was written.")

        yedek = self.yedekle(ad)              # once yedek, sonra yazim
        with open(self.yol(ad), "wb") as f:
            f.write(ham_yeni)
        os.utime(self.yol(ad), None)          # mtime'i simdiye cek
        return {"yedek": yedek, "degisen_bayt": degisen}

    # ------------------------------------------------------------ degerler
    def u32(self, ad, off):
        _b, g = self.govde(ad)
        return struct.unpack_from("<I", g, off)[0]

    def u32_yaz(self, ad, off, deger):
        return self.yaz(ad, [(off, struct.pack("<I", deger & 0xFFFFFFFF))])


# ---------------------------------------------------------------- kesif
def fark(govde_a, govde_b, en_fazla=400):
    """Iki cozulmus govdenin farki. Ayni boyut sart.
    Doner: [{ofset, a, b, fark}] — 4 baytlik sayisal adaylar one alinir."""
    if len(govde_a) != len(govde_b):
        return None
    idx = [i for i in range(len(govde_a)) if govde_a[i] != govde_b[i]]
    if not idx:
        return []
    bolge, bas, son = [], idx[0], idx[0]
    for i in idx[1:]:
        if i - son <= 4:
            son = i
        else:
            bolge.append((bas, son)); bas = son = i
    bolge.append((bas, son))
    out = []
    for bs, sn in bolge:
        if bs + 4 > len(govde_a):
            continue
        va = struct.unpack_from("<I", govde_a, bs)[0]
        vb = struct.unpack_from("<I", govde_b, bs)[0]
        out.append({"ofset": bs, "boy": sn - bs + 1, "a": va, "b": vb,
                    "fark": vb - va})
    # kucuk sayisal degisim = daha iyi aday
    out.sort(key=lambda d: (abs(d["fark"]) > 10_000_000, abs(d["fark"])))
    return out[:en_fazla]



# ---------------------------------------------------------------- deger avi
# Cheat Engine mantigi, KAYIT DOSYASI uzerinde: kullanici oyunda gordugu
# degeri yazar, arac kayitta o degeri arar; birden fazla eslesme cikarsa
# kullanici degeri oyunda DEGISTIRIP tekrar arar ve liste daralir.
_TURLER = {"u32": ("<I", 4), "i32": ("<i", 4), "u16": ("<H", 2),
           "u64": ("<Q", 8), "f32": ("<f", 4)}


def ara_deger(govde, deger, turler=("u32", "i32"), hizala=None):
    """Govdede `deger`e esit tum konumlari bul.

    hizala: None = her bayt konumu (en genis), 4 = 4'e hizali (daha hizli/az
    gurultu). Kayit alanlari genelde hizali ama garanti degil -> varsayilan
    None (hicbir adayi kacirma).
    Doner: [{ofset, tur, deger}]
    """
    out = []
    for tur in turler:
        fmt, boy = _TURLER[tur]
        try:
            hedef = struct.pack(fmt, deger)
        except (struct.error, OverflowError):
            continue
        bas = 0
        adim = hizala or 1
        while True:
            i = govde.find(hedef, bas)
            if i < 0:
                break
            if not hizala or i % hizala == 0:
                out.append({"ofset": i, "tur": tur, "deger": deger})
            bas = i + adim
            if len(out) > 20000:              # patolojik durum korumasi
                break
    # AYNI KONUM birden fazla turde eslesebilir (or. u32 ve i32 ayni bayt
    # dizisi) — kullaniciya 1 konum 1 aday gorunmeli, yoksa "4 eslesme" der
    # ama gercekte 2 yer vardir.
    gorulen, tekil = set(), []
    for a in out:
        if a["ofset"] in gorulen:
            continue
        gorulen.add(a["ofset"]); tekil.append(a)
    return tekil


def daralt(govde, adaylar, yeni_deger):
    """Onceki aday listesini, YENI degere gore daralt (ikinci tarama)."""
    kalan = []
    for a in adaylar:
        fmt, boy = _TURLER[a["tur"]]
        if a["ofset"] + boy > len(govde):
            continue
        try:
            v = struct.unpack_from(fmt, govde, a["ofset"])[0]
        except Exception:
            continue
        if v == yeni_deger:
            kalan.append(dict(a, deger=yeni_deger))
    return kalan


def deger_oku(govde, ofset, tur="u32"):
    fmt, boy = _TURLER[tur]
    if ofset + boy > len(govde):
        return None
    return struct.unpack_from(fmt, govde, ofset)[0]


def deger_paketle(deger, tur="u32"):
    fmt, _boy = _TURLER[tur]
    return struct.pack(fmt, deger)

# ------------------------------------------------------------- alan katalogu
def _tohum_yolu():
    """Paketle gelen (salt-okunur) baslangic alanlari."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "save_alanlar.json")


def katalog_yolu():
    """Kullanicinin kaydettigi hileler KULLANICI verisi: uygulama klasorune
    degil %LOCALAPPDATA%'ya yazilir (guncellemede kaybolmasin, Program Files
    altinda yazma reddi olmasin — denetimde olculdu, F35)."""
    kok = os.environ.get("LOCALAPPDATA") or os.path.join(
        os.path.expanduser("~"), "AppData", "Local")
    return os.path.join(kok, "OutfitWorkshop", "save_alanlar.json")


def alanlar():
    """Bilinen alanlar: kullanicinin kaydettikleri + paketle gelen tohum
    (ad catisirsa kullanicininki kazanir). Bos liste = henuz alan yok."""
    out, adlar = [], set()
    for y in (katalog_yolu(), _tohum_yolu()):
        if not os.path.isfile(y):
            continue
        try:
            with open(y, encoding="utf-8") as f:
                for a in json.load(f).get("alanlar", []):
                    if a.get("ad") in adlar:
                        continue
                    adlar.add(a.get("ad")); out.append(a)
        except Exception:
            continue
    return out
