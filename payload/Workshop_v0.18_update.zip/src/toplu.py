# -*- coding: utf-8 -*-
"""toplu -- ALAN T: bir forge'un girislerini TOPLU ac, DEGISENLERI toplu geri koy.

Rakip arac (AnvilToolkit) forge'u KOMPLE acar ve KOMPLE yeniden paketler. Bu modul
ayni ISI yapar (tek tek giris secmeden calisan bir "unpack/repack" hatti) ama
YAZMA tarafinda ONU TAKLIT ETMEZ -- neden, asagida "REPACK KARARI" basliginda.

BU MODUL YENI BIR MOTOR DEGILDIR. Tek bir dongu katmani koyar; her isi ZATEN VAR
OLAN modul yapar:

    giris listesi   yalin_forge.LeanForge (CANLI TOC -- tek otorite)
    ad / sinif      varlik_indeks.kayit  (+ explorer_core'un kendi sinif cozucusu)
    disa aktarma    explorer_core.disa_aktar(bicim="ham")   -> .bin + bilgi.json
    geri yazma      explorer_core.geri_yukle                -> kur_mesh.kur
    geri alma       explorer_core.durum / geri_al           -> kur_mesh kaydi

TEK YAZICI KURALI: bu dosyada forge'a yazan TEK BIR satir yoktur. "r+b" gecmez;
yazma daima explorer_core.geri_yukle -> kur_mesh.kur uzerinden gider. Boylece
Health Check, "Revert all" ve catisma korumalari toplu yazmalari da gorur.

--- REPACK KARARI (Anvil'den BILINCLI SAPMA) -------------------------------------
Anvil forge'u bastan yazar: TOC yeniden uretilir, her giris yeniden sikistirilir.
Biz bunu YAPMIYORUZ. Bizim yolumuz "yeni girisi dosyanin SONUNA ekle + TOC satirini
yonlendir"; orijinal baytlar YERINDE DURUR ve kur_mesh yedegi + WAL kaydi sayesinde
geri alinabilir (olculdu: bu dosyanin testinde ac -> degistir -> geri koy -> geri al
sonunda arsiv sha256'si vanilla ile BIREBIR ayni).

Tam yeniden paketleme uc seyi ayni anda kirardi:
  1. TOC bastan yazilinca "orijinal ofset" diye bir sey kalmaz -- kur_mesh kaydinin
     ve yedeklerinin anlattigi arsiv ortadan kalkar, "Revert all" anlamsizlasir.
  2. Dokunulmayan 126.248 giris de yeniden sikistirilirdi; bizim Oodle yazicimiz
     oyunun kullandigi kodlayicinin BIREBIR ayni ciktisini vermez, yani "hic
     degistirmedim" denen baytlar da degisirdi.
  3. 23,9 GB'lik DataPC_boot.forge tek seferde yeniden yazilirdi; yarida kesilen bir
     yazma oyunu kurtarilamaz hale getirirdi. Ek yonteminde en kotu durum kuyrukta
     bir artik bloktur, arsiv acilir kalir.
Bu yuzden "Anvil ne yapiyorsa aynisi" DEGIL, "ayni sonuc, geri alinabilir yoldan".

--- DISK VE SURE ------------------------------------------------------------------
DataPC_boot.forge 23,9 GB / 126.249 giris. Hepsini acmak diski doldurabilir ve
saatler surer. Bu yuzden `ac` ONCE `tahmin` cagirir ve esik asilirsa TEK BAYT
YAZMADAN `onay_gerekli` ile doner. Tahmin katmanli ornekleme ile olculur (duz
ornekleme %63-222 sapiyordu; olcum bu dosyanin testinde tekrarlanir).

--- SUZGEC ------------------------------------------------------------------------
`suzgec` bir sozluktur; verilmeyen alan SUZMEZ (varsayilan hicbir sinifi GIZLEMEZ --
explorer_core'un "hicbir sey gizlenmez" kurali burada da gecerlidir; guvenlik
varsayilan bir suzgecle degil, ONAY KAPISI ile saglanir):
    {"gid": [...],            yalniz bu TOC kimlikleri
     "sinif": "Mesh" | [...], sinif adi ya da "0x415D9568" (buyuk/kucuk harf farksiz)
     "ad": "*Jackdaw*",       ad ya da turetilmis etiket deseni (* ? varsa glob,
                              yoksa ICEREN arama); varlik_indeks GEREKTIRIR
     "boyut_min": int,        TOC girisinin ARSIVDEKI boyutu (sikistirilmis bayt)
     "boyut_max": int,
     "limit": int}            en fazla kac giris (en buyukten degil, TOC sirasiyla)
"""
import fnmatch
import hashlib
import json
import os
import re
import shutil
import sys
import time

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)

import outfit_core as C                                          # noqa: E402
import explorer_core as EX                                       # noqa: E402
from export3d import kur_mesh as KM                              # noqa: E402

from yalin_forge import LeanForge                                # noqa: E402

__all__ = ["ac", "geri_koy", "plan_geri_koy", "tahmin", "adaylar", "rapor",
           "SURUM", "TOPLU_AD", "ONAY_SINIRI_BAYT", "ONAY_SINIRI_GIRIS"]

SURUM = "1.0"
TOPLU_AD = "toplu.json"          # agacin kokune yazilan toplu isin kunyesi
BILGI_AD = EX.BILGI_AD           # giris klasorundeki kimlik kagidi (explorer yazar)
ETIKET = "batch"                 # kur_mesh kaydinda gorunen aciklama oneki

# --- ONAY KAPISI -------------------------------------------------------------------
# Esikler ASILIRSA `ac` tek bayt yazmadan doner. Cagiran onay=True derse gecer.
ONAY_SINIRI_BAYT = 2 * 1024 ** 3          # 2 GiB tahmini cikti
ONAY_SINIRI_GIRIS = 20000                 # 20.000 giris (~5,5 dk; 16,5 ms/giris olculdu)

# --- TAHMIN ------------------------------------------------------------------------
# Katmanli ornekleme: girisler ARSIV BOYUTUNA gore siralanir, en buyukler TEK TEK
# olculur, kalanlar esit sayili katmanlara bolunup her katmandan ornek alinir.
# DUZ ornekleme neden yetmiyor (olculdu, DataPC_WhiteRoom.forge, gercek 39,2 MB):
#     duz  8 ornek -> 126,2 MB (+%222)     katmanli (16 tepe + 8x4) -> 36,0 MB (-%8,2)
#     duz 16 ornek ->  65,9 MB  (+%68)     katmanli (10 tepe + 4x6) -> 40,2 MB (+%2,7)
#     duz 48 ornek ->  63,9 MB  (+%63)
# Sebep: kucuk girisler cok genisler, buyuk girisler az; duz ornek kucukleri fazla
# temsil eder ve orani sisirir.
ORNEK_GIRIS = 48                          # en fazla kac giris OLCULUR
ORNEK_BAYT = 48 << 20                     # olcum icin en fazla kac ARSIV bayti acilir
# TEK bir girise harcanabilecek en buyuk arsiv bayti. OLCULEN KUSUR: bu sinir yokken
# DataPC_boot.forge'un en buyuk girisi (118,2 MB) tum bayt butcesini tek basina yiyordu;
# geriye TEK olcum kaliyor ve o dev girisin "giris basina dosya" orani 126.249 girise
# yayilinca tahmin 1.592.252.388 DOSYA diyordu. Sinirin ustundeki giris OLCULMEZ,
# butceden de DUSMEZ; boyutu genel oranla tahmin edilir.
ORNEK_TEK_SINIR = 8 << 20
TEPE = 16                                 # en buyuk kac giris tek tek olculur
KATMAN = 8                                # kalanin kac katmana bolunecegi
KATMAN_ORNEK = 4                          # her katmandan kac ornek
# Hicbir olcum yapilamazsa (ornegin her ornek acilamadi) kullanilan yedek oran.
# DataPC_WhiteRoom.forge'un TAMAMI acilarak olculdu: 29.917.184 B -> 41.081.477 B.
VARSAYILAN_ORAN = 1.373
# Disk kapisi tahmini bu payla carpar. Katmanli tahminin olculen EN KOTU sapmasi
# -%9,4 idi; %25 pay onu rahatca kapsar.
DISK_PAYI = 1.25

# Kunyeye yazilan liste uzunluk siniri: 126.249 girislik bir kosuda "atlanan" listesi
# dosyayi sisirirdi. Sayac DAIMA tam, liste kirpilir ve kirpildigi SOYLENIR.
LISTE_SINIRI = 500

# Ilerleme her girise degil, bu araliga bir bildirilir (126k girislik kosuda satir
# basina bir log satiri arayuzu bogardi).
ILERLEME_ADIMI = 25


# =====================================================================================
#  yardimcilar
# =====================================================================================
def _log(progress, s):
    C._log(progress, s)


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _dosya_sha(yol):
    """bilgi.json'daki `sha256` ile AYNI algoritma (explorer_core govde uzerinde
    sha256 aliyor; burada ayni bayt dizisi dosyadan parca parca okunuyor)."""
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for blok in iter(lambda: f.read(1 << 22), b""):
            h.update(blok)
    return h.hexdigest()


def _hex(x, genislik=12):
    return None if x is None else ("0x%0*X" % (genislik, int(x)))


def _int(x):
    if x is None:
        return None
    if isinstance(x, int) and not isinstance(x, bool):
        return int(x)
    s = str(x).strip()
    return int(s, 16) if s else None


_AD_TEMIZ = re.compile(r"[^A-Za-z0-9_.-]+")


def _ad_temiz(ad, yedek):
    """Dosya sistemi icin guvenli ad. explorer_core'un KENDI temizleyicisi kullanilir
    ki klasor adi ile icindeki .bin adlari ayni kaliptan ciksin; modul degisirse
    ayni kalibin kopyasina duser (islev: ASCII disi -> '_', en fazla 80 karakter)."""
    f = getattr(EX, "_dosya_adi", None)
    if f is not None:
        try:
            return f(ad, yedek)
        except Exception:                                        # noqa: BLE001
            pass
    t = _AD_TEMIZ.sub("_", str(ad or "")).strip("._")
    return t[:80] or yedek


def _sinif_ad(crc, gid=None):
    """Sinif adi. explorer_core'un cozucusu (yerlesik tablo -> OYUNUN KENDI sinif
    sozlugu -> varlik_indeks -> crc) kullanilir; ikinci bir sinif tablosu tutmak
    iki tabloyu zamanla ayristirirdi."""
    f = getattr(EX, "_sinif_adi", None)
    if f is not None:
        try:
            return f(crc, gid)[0]
        except Exception:                                        # noqa: BLE001
            pass
    return EX.SINIF_ADI.get(crc) or ("0x%08X" % (crc or 0))


def _indeks():
    try:
        import varlik_indeks                                     # noqa: F401
    except Exception:                                            # noqa: BLE001
        return None
    return sys.modules.get("varlik_indeks")


def _indeks_adi(gid):
    """(ad, etiket) -- varlik_indeks'ten. Indeks yoksa/tanimazsa ("", "")."""
    vi = _indeks()
    if vi is None:
        return "", ""
    try:
        k = vi.kayit(gid)
    except Exception:                                            # noqa: BLE001
        return "", ""
    if not isinstance(k, dict):
        return "", ""
    return str(k.get("ad") or ""), str(k.get("etiket") or "")


def _iptal_mi(iptal):
    """threading.Event, cagrilabilir ya da duz dogruluk degeri -- hepsini kabul et."""
    if iptal is None:
        return False
    isset = getattr(iptal, "is_set", None)
    if callable(isset):
        return bool(isset())
    if callable(iptal):
        return bool(iptal())
    return bool(iptal)


def _mb(x):
    return "%.1f MB" % (float(x) / 1048576.0)


def _gb(x):
    return "%.2f GB" % (float(x) / 1073741824.0)


def _boy(x):
    """Insan icin boyut. Kucuk degerler MB olarak yazilinca "0.0 MB" cikiyordu ve
    1 KB'lik bir sinir "0.0 MB limit" diye raporlaniyordu (olculdu, duman testi)."""
    x = float(x or 0)
    if x >= 1073741824:
        return _gb(x)
    if x >= 1048576:
        return _mb(x)
    if x >= 1024:
        return "%.1f KB" % (x / 1024.0)
    return "%d bytes" % int(x)


def _sure_metni(sn):
    """Sure metni. "0,25 saniye" once "roughly 1 minutes" diye yuvarlaniyordu."""
    sn = float(sn or 0)
    if sn < 90:
        n = max(1, int(round(sn)))
        return "%d second%s" % (n, "" if n == 1 else "s")
    if sn < 5400:
        n = int(round(sn / 60.0))
        return "%d minute%s" % (n, "" if n == 1 else "s")
    return "%.1f hours" % (sn / 3600.0)


def _kirp(liste):
    """Kunyeye yazilan listeyi kirp (sayac cagiranda TAM kalir)."""
    if len(liste) <= LISTE_SINIRI:
        return list(liste), 0
    return list(liste[:LISTE_SINIRI]), len(liste) - LISTE_SINIRI


def _toc(forge):
    """CANLI TOC: [(gid, ln, ext)]. Dosya taniticisi HEMEN kapatilir -- forge acik
    kaldigi surece Steam 'dosyalari dogrula' 'Content file locked' ile duser."""
    with LeanForge(forge) as lf:
        return [(fid, ln, ext) for fid, (off, ln, ext) in lf.by_id.items()]


# =====================================================================================
#  T1a -- SUZGEC / ADAY SECIMI
# =====================================================================================
def _desen_uyar(desen, *metinler):
    d = str(desen or "").strip().lower()
    if not d:
        return True
    glob = ("*" in d) or ("?" in d) or ("[" in d)
    for m in metinler:
        m = str(m or "").lower()
        if not m:
            continue
        if fnmatch.fnmatchcase(m, d) if glob else (d in m):
            return True
    return False


def _sinif_uyar(istenen, ad, crc):
    """istenen: tek metin ya da liste. 'Mesh' | '0x415D9568' | 'Texture*'."""
    if not istenen:
        return True
    if isinstance(istenen, (str, bytes)):
        istenen = [istenen]
    crc_metin = "0x%08x" % (crc or 0)
    for s in istenen:
        s = str(s or "").strip().lower()
        if not s:
            continue
        if s == crc_metin or s == str(ad or "").lower():
            return True
        if ("*" in s or "?" in s) and fnmatch.fnmatchcase(str(ad or "").lower(), s):
            return True
    return False


def adaylar(forge, suzgec=None, progress=None):
    """T1a -- suzgecten gecen girisler. FORGE'A YAZMAZ, yalniz TOC'u okur.

    Doner: {ok, forge, forge_ad, toc_giris, secilen, arsiv_bayt, satirlar, uyari, mesaj}
    `satirlar` = [{gid, gid_sayi, ln, ext, sinif, ad, etiket}] -- TOC sirasinda.

    Ad/sinif suzgeci istendiginde ad cozumu (varlik_indeks) YALNIZCA o zaman
    yapilir: 126.249 girislik bir forge'da her satirin adini cozmek bosuna
    saniyeler yakardi ve suzgecsiz cagriya hicbir sey katmazdi.
    """
    r = {"ok": False, "tur": "adaylar", "forge": None, "forge_ad": None,
         "toc_giris": 0, "secilen": 0, "arsiv_bayt": 0, "satirlar": [],
         "uyari": [], "mesaj": None, "surum": SURUM}
    forge = os.path.abspath(forge or EX.arsiv_yolu())
    r["forge"], r["forge_ad"] = forge, os.path.basename(forge)
    if not os.path.isfile(forge):
        r["mesaj"] = "Game archive not found: %s" % forge
        return r
    try:
        toc = _toc(forge)
    except Exception as e:                                       # noqa: BLE001
        r["mesaj"] = "The archive table of contents could not be read (%s)." % str(e)[:120]
        return r
    r["toc_giris"] = len(toc)

    s = dict(suzgec or {})
    gidler = s.get("gid")
    if gidler is not None:
        if isinstance(gidler, (str, bytes, int)):
            gidler = [gidler]
        gidler = set(x for x in (_int(g) for g in gidler) if x is not None)
    bmin = s.get("boyut_min")
    bmax = s.get("boyut_max")
    sinif = s.get("sinif")
    ad_desen = s.get("ad")
    limit = s.get("limit")

    if ad_desen and _indeks() is None:
        r["mesaj"] = ("Names come from the asset index, which is not available in this "
                      "build, so a name filter cannot be applied. Filter by class or by "
                      "entry id instead, or drop the name filter to take every entry.")
        return r

    ad_cozulsun = bool(ad_desen) or bool(sinif)
    satirlar = []
    bakilan = 0
    for gid, ln, ext in toc:
        bakilan += 1
        if gidler is not None and gid not in gidler:
            continue
        if bmin is not None and ln < int(bmin):
            continue
        if bmax is not None and ln > int(bmax):
            continue
        sinif_ad = ad = etiket = ""
        if ad_cozulsun:
            sinif_ad = _sinif_ad(ext, gid)
            if not _sinif_uyar(sinif, sinif_ad, ext):
                continue
            if ad_desen:
                ad, etiket = _indeks_adi(gid)
                if not _desen_uyar(ad_desen, ad, etiket):
                    continue
        satirlar.append({"gid": _hex(gid), "gid_sayi": gid, "ln": int(ln),
                         "ext": "0x%08X" % ext, "ext_sayi": int(ext),
                         "sinif": sinif_ad, "ad": ad, "etiket": etiket})
        if limit and len(satirlar) >= int(limit):
            # "Bakilmayan" sayisi TOC - SECILEN degildir: suzgecin eledigi girisler
            # BAKILDI. Aradaki fark limit dusukken buyuk bir yalan olurdu.
            r["uyari"].append("The filter's limit of %d entries was reached; %d further "
                              "entries in %s were not looked at."
                              % (int(limit), len(toc) - bakilan, r["forge_ad"]))
            break
    r["satirlar"] = satirlar
    r["secilen"] = len(satirlar)
    r["arsiv_bayt"] = sum(x["ln"] for x in satirlar)
    r["ok"] = True
    if not satirlar:
        r["mesaj"] = ("No entry in %s matches this filter (the archive holds %d entries)."
                      % (r["forge_ad"], len(toc)))
    _log(progress, "Selected %d of %d entries in %s (%s in the archive)."
         % (len(satirlar), len(toc), r["forge_ad"], _boy(r["arsiv_bayt"])))
    return r


# =====================================================================================
#  T1b -- TAHMIN (yazmadan once: kac bayt, ne kadar sure)
# =====================================================================================
def _olc_giris(gid, forge):
    """(cikan_bayt, dosya_sayisi) -- bu giris acilinca diske ne yazilir?

    Olcum explorer_core.tani ile yapilir: kap BMS ise ic dosyalarin ACILMIS boyutlari,
    degilse girisin kendi baytlari cikar (explorer'in `_ham_yaz` yolu ile ayni karar).
    """
    try:
        t = EX.tani(gid, forge=forge)
    except Exception:                                            # noqa: BLE001
        return None
    if not t.get("ok"):
        return None
    if t.get("kap") == "bms" and t.get("ic_dosyalar"):
        return sum(int(k.get("boyut") or 0) for k in t["ic_dosyalar"]), len(t["ic_dosyalar"])
    return int(t.get("boyut") or 0), 1


def _yayili(grup, kac):
    """Gruptan `kac` tane YAYILMIS eleman sec (bastan degil, esit araliklarla)."""
    if kac >= len(grup):
        return list(grup)
    adim = max(1, len(grup) // kac)
    return grup[::adim][:kac]


def _gruplar(satirlar):
    """[(grup, kac_ornek)] -- once en buyuk TEPE giris (tek tek), sonra katmanlar."""
    sirali = sorted(satirlar, key=lambda x: -x["ln"])
    tepe = sirali[:TEPE]
    kalan = sirali[TEPE:]
    out = []
    if tepe:
        out.append((tepe, len(tepe)))
    if kalan:
        k = max(1, len(kalan) // KATMAN)
        for i in range(0, len(kalan), k):
            grup = kalan[i:i + k]
            if grup:
                out.append((grup, KATMAN_ORNEK))
    return out


def tahmin(forge, suzgec=None, progress=None, secim=None, ornek=ORNEK_GIRIS,
           ornek_bayt=ORNEK_BAYT, tek_sinir=ORNEK_TEK_SINIR, iptal=None):
    """T1b -- YAZMADAN once: kac giris, tahmini kac bayt, tahmini kac dakika.

    `kesin=True` yalnizca HER giris tek tek olculdugunde doner; aksi halde sayi bir
    TAHMINDIR ve `olcum` kac girisin gercekten acildigini soyler. Yalan soylememek
    icin iki alan ayri: `arsiv_bayt` (kesin, TOC'tan) ve `tahmin_bayt` (ornekten).
    """
    t0 = time.time()
    r = {"ok": False, "tur": "tahmin", "kesin": False, "olcum": 0, "olcum_bayt": 0,
         "oran": None, "tahmin_bayt": 0, "tahmin_dosya": 0, "tahmin_sure": 0.0,
         "gerekli_bayt": 0, "sure": 0.0, "onay_gerekli": False, "mesaj": None,
         "surum": SURUM, "iptal": False}
    sec = secim if secim is not None else adaylar(forge, suzgec, progress)
    r.update({k: sec.get(k) for k in ("forge", "forge_ad", "toc_giris", "secilen",
                                      "arsiv_bayt")})
    r["uyari"] = list(sec.get("uyari") or [])
    if not sec.get("ok"):
        r["mesaj"] = sec.get("mesaj")
        return r
    satirlar = sec["satirlar"]
    if not satirlar:
        r["ok"] = True
        r["mesaj"] = sec.get("mesaj")
        return r

    forge = sec["forge"]
    _log(progress, "Measuring a sample of the selection to estimate the output size...")

    butce_adet = int(ornek)
    butce_bayt = int(ornek_bayt)
    # Kucuk secim: hepsini tek tek olc -> tahmin degil, KESIN sayi.
    kesin = len(satirlar) <= butce_adet and sec["arsiv_bayt"] <= butce_bayt
    gruplar = [(list(satirlar), len(satirlar))] if kesin else _gruplar(satirlar)

    toplam_bayt = 0.0
    toplam_dosya = 0.0
    olculen = 0
    olculen_bayt = 0
    genel_ln = 0
    genel_cikan = 0
    genel_dosya = 0
    bekleyen = []                       # olcum yapilamayan gruplar -> genel oran
    for grup, kac in gruplar:
        if _iptal_mi(iptal):
            r["iptal"] = True
            break
        o_ln = o_cikan = o_dosya = 0
        n = 0
        for a in _yayili(grup, kac):
            if butce_adet <= 0 or butce_bayt <= 0 or _iptal_mi(iptal):
                break
            if a["ln"] > tek_sinir:
                continue                    # dev giris butceyi yer -- genel orana birak
            m = _olc_giris(a["gid_sayi"], forge)
            butce_adet -= 1
            butce_bayt -= a["ln"]
            olculen += 1
            olculen_bayt += a["ln"]
            if m is None:
                continue
            o_ln += a["ln"]
            o_cikan += m[0]
            o_dosya += m[1]
            n += 1
        g_ln = sum(x["ln"] for x in grup)
        if n and o_ln:
            genel_ln += o_ln
            genel_cikan += o_cikan
            genel_dosya += o_dosya
            toplam_bayt += g_ln * (float(o_cikan) / o_ln)
            toplam_dosya += len(grup) * (float(o_dosya) / n)
        else:
            bekleyen.append((grup, g_ln))
    genel_oran = (float(genel_cikan) / genel_ln) if genel_ln else VARSAYILAN_ORAN
    genel_dpg = (float(genel_dosya) / max(1, olculen)) if genel_dosya else 1.0
    for grup, g_ln in bekleyen:
        toplam_bayt += g_ln * genel_oran
        toplam_dosya += len(grup) * genel_dpg

    r["kesin"] = bool(kesin and olculen == len(satirlar) and not r["iptal"])
    r["olcum"] = olculen
    r["olcum_bayt"] = olculen_bayt
    r["oran"] = round(genel_oran, 4)
    r["oran_kaynagi"] = "sample" if genel_ln else "fallback (measured on DataPC_WhiteRoom.forge)"
    r["tahmin_bayt"] = int(round(toplam_bayt))
    r["tahmin_dosya"] = int(round(toplam_dosya))
    # Sure tahmini: bu makinede 16,5 ms/giris olculdu (WhiteRoom, 495 giris, 8,2 sn).
    r["tahmin_sure"] = round(len(satirlar) * 0.0165, 1)
    r["gerekli_bayt"] = int(round(toplam_bayt * DISK_PAYI))
    r["disk_payi"] = DISK_PAYI
    r["sure"] = round(time.time() - t0, 2)
    r["ok"] = True
    r["mesaj"] = ("%s holds %d entries; the filter selected %d of them, %s in the archive. "
                  "Unpacking them writes %s %s in %d files%s."
                  % (r["forge_ad"], r["toc_giris"], r["secilen"], _boy(r["arsiv_bayt"]),
                     "exactly" if r["kesin"] else "about",
                     _boy(r["tahmin_bayt"]), r["tahmin_dosya"],
                     " (every selected entry was opened to measure this)" if r["kesin"]
                     else " (estimated from %d entries opened as a sample)" % olculen))
    _log(progress, r["mesaj"])
    return r


# =====================================================================================
#  T1 -- TOPLU AC
# =====================================================================================
_GID_SONEK = re.compile(r"_([0-9A-Fa-f]{12,16})$")


def _hedef_klasor(kok, sinif, ad, gid):
    """<kok>\\<sinif>\\<ad>_<GID> -- kullanici dosyayi ADIYLA bulsun.

    `_<GID>` soneki ad CAKISMASINI YAPISAL olarak cozer: iki varlik ayni adi
    tasiyabilir ama ayni TOC kimligini tasiyamaz."""
    return os.path.join(kok, _ad_temiz(sinif or "", "Unknown"),
                        "%s_%012X" % (_ad_temiz(ad, "Entry"), gid))


def _mevcut_gidler(kok):
    """Agacta ZATEN acilmis girislerin kimlikleri {gid: klasor}.

    Kontrol AD ile degil KIMLIK ile yapilir: klasor adi indeksten mi yoksa canli K1
    cozumunden mi geldigine gore degisebilir, ama `_<GID>` soneki degismez. Ad ile
    bakan bir kontrol ayni girisi ikinci kez acardi (olculdu: adsiz girislerde
    beklenen ad 'Entry_...', gerceklesen ad canli cozumden geliyordu)."""
    out = {}
    if not os.path.isdir(kok):
        return out
    for sinif in os.listdir(kok):
        d = os.path.join(kok, sinif)
        if not os.path.isdir(d):
            continue
        for ad in os.listdir(d):
            m = _GID_SONEK.search(ad)
            if m and os.path.isdir(os.path.join(d, ad)):
                try:
                    out[int(m.group(1), 16)] = os.path.join(d, ad)
                except ValueError:
                    pass
    return out


def _kunye_yaz(kok, k):
    yol = os.path.join(kok, TOPLU_AD)
    try:
        with open(yol, "w", encoding="utf-8") as f:
            json.dump(k, f, indent=1, ensure_ascii=False)
    except OSError:
        return None
    return yol


def ac(forge, klasor, suzgec=None, progress=None, onay=False, iptal=None,
       ustune=False, onay_siniri=None, giris_siniri=None):
    """T1 -- forge'un secilen girislerini `klasor` altina ac.

    Her giris icin explorer_core.disa_aktar(bicim="ham") cagrilir: ic dosyalar ayri
    .bin olarak cikar ve yanlarina bilgi.json yazilir (gid/icid/sinif/ad/sha256).
    Klasor agaci `<klasor>\\<sinif>\\<ad>_<GID>` seklindedir.

    ONAY KAPISI: tahmini cikti `onay_siniri` (varsayilan 2 GiB) ya da giris sayisi
    `giris_siniri` (varsayilan 20.000) asilirsa TEK BAYT YAZILMADAN doner ve
    `onay_gerekli=True` der. Cagiran onay=True ile tekrar cagirir.
    DISK KAPISI: tahmin + %25 pay bos alandan buyukse yazma BASLAMAZ (onay bunu
    gecmez -- disk dolarsa yarim agac kalir).

    Doner: {ok, onay_gerekli, klasor, acilan, atlanan, basarisiz, dosya, bayt,
            tahmin, kunye, iptal, sure, mesaj}
    """
    t0 = time.time()
    r = {"ok": False, "tur": "ac", "onay_gerekli": False, "klasor": None,
         "acilan": 0, "atlanan": [], "basarisiz": [], "dosya": 0, "bayt": 0,
         "iptal": False, "mesaj": None, "sure": 0.0, "surum": SURUM}
    if not klasor:
        raise ValueError("an output folder is required")
    kok = os.path.abspath(klasor)
    r["klasor"] = kok

    sec = adaylar(forge, suzgec, progress)
    r["secim"] = {k: sec.get(k) for k in ("forge", "forge_ad", "toc_giris", "secilen",
                                          "arsiv_bayt", "uyari")}
    if not sec.get("ok"):
        r["mesaj"] = sec.get("mesaj")
        return r
    if not sec["satirlar"]:
        r["ok"] = True
        r["mesaj"] = sec.get("mesaj")
        return r
    forge = sec["forge"]

    t = tahmin(forge, suzgec, progress, secim=sec, iptal=iptal)
    r["tahmin"] = t
    if not t.get("ok"):
        r["mesaj"] = t.get("mesaj")
        return r
    if t.get("iptal"):
        r["iptal"] = True
        r["mesaj"] = "Cancelled before anything was written."
        return r

    b_siniri = ONAY_SINIRI_BAYT if onay_siniri is None else int(onay_siniri)
    g_siniri = ONAY_SINIRI_GIRIS if giris_siniri is None else int(giris_siniri)
    buyuk = t["tahmin_bayt"] > b_siniri
    cok = sec["secilen"] > g_siniri
    if (buyuk or cok) and not onay:
        r["onay_gerekli"] = True
        sebep = []
        if buyuk:
            sebep.append("about %s would be written, over the %s limit"
                         % (_boy(t["tahmin_bayt"]), _boy(b_siniri)))
        if cok:
            sebep.append("%d entries were selected, over the %d limit"
                         % (sec["secilen"], g_siniri))
        r["mesaj"] = ("Nothing was written yet: %s. Unpacking %d entries of %s takes "
                      "roughly %s and produces about %d files. Narrow the filter "
                      "(by class, name or size), or run this again with approval."
                      % (" and ".join(sebep), sec["secilen"], sec["forge_ad"],
                         _sure_metni(t["tahmin_sure"]), t["tahmin_dosya"]))
        _log(progress, r["mesaj"])
        return r

    try:
        os.makedirs(kok, exist_ok=True)
    except OSError as e:
        r["mesaj"] = "The output folder could not be created (%s)." % e
        return r
    try:
        bos = shutil.disk_usage(kok).free
    except OSError:
        bos = None
    r["disk_bos"] = bos
    gerek = t["gerekli_bayt"]
    if bos is not None and gerek > bos:
        r["mesaj"] = ("Not enough free disk space: about %s is needed (%s estimated plus a "
                      "%d%% margin) but only %s is free on this drive. Narrow the filter or "
                      "choose another folder. Nothing was written."
                      % (_boy(gerek), _boy(t["tahmin_bayt"]), int((DISK_PAYI - 1) * 100),
                         _boy(bos)))
        _log(progress, r["mesaj"])
        return r

    kunye = {"arac": "toplu", "surum": SURUM, "bicim": EX.BICIM_HAM,
             "zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
             "forge": forge, "forge_ad": sec["forge_ad"],
             "forge_boyut": os.path.getsize(forge),
             "forge_mtime": int(os.path.getmtime(forge)),
             "suzgec": dict(suzgec or {}), "toc_giris": sec["toc_giris"],
             "secilen": sec["secilen"], "tahmin": {k: t.get(k) for k in
                                                   ("tahmin_bayt", "tahmin_dosya",
                                                    "kesin", "oran", "olcum")},
             "tamam": False, "iptal": False}
    r["kunye"] = _kunye_yaz(kok, kunye)

    n = len(sec["satirlar"])
    mevcut = _mevcut_gidler(kok)
    _log(progress, "Unpacking %d entries of %s into %s ..." % (n, sec["forge_ad"], kok))
    for i, satir in enumerate(sec["satirlar"], 1):
        if _iptal_mi(iptal):
            r["iptal"] = True
            _log(progress, "Cancelled after %d of %d entries; what was written so far "
                           "is complete and can be imported back." % (i - 1, n))
            break
        gid = satir["gid_sayi"]
        if gid in mevcut:
            if not ustune:
                r["atlanan"].append({"gid": satir["gid"], "klasor": mevcut[gid],
                                     "sebep": "this entry is already unpacked here"})
                continue
            shutil.rmtree(mevcut[gid], ignore_errors=True)
            mevcut.pop(gid, None)
        if not satir.get("sinif"):
            satir["sinif"] = _sinif_ad(satir["ext_sayi"], gid)
        sinif_dizin = os.path.join(kok, _ad_temiz(satir["sinif"], "Unknown"))
        try:
            os.makedirs(sinif_dizin, exist_ok=True)
            s = EX.disa_aktar(gid, None, sinif_dizin, bicim=EX.BICIM_HAM, forge=forge)
        except OSError as e:
            r["basarisiz"].append({"gid": satir["gid"], "sebep": str(e)[:160]})
            if getattr(e, "errno", None) == 28:                  # ENOSPC: disk doldu
                r["mesaj"] = ("The drive ran out of space after %d of %d entries. What was "
                              "written is complete and can be imported back." % (i - 1, n))
                break
            continue
        except Exception as e:                                   # noqa: BLE001
            r["basarisiz"].append({"gid": satir["gid"], "sebep": str(e)[:160]})
            continue
        if not s.get("ok"):
            r["basarisiz"].append({"gid": satir["gid"],
                                   "sebep": s.get("mesaj") or "unknown reason"})
            continue
        # Ad SIRASI: canli K1 cozumu (explorer'in `tani`si) > indeks adi > indeks
        # etiketi. Canli cozum otoritedir; indekste hic gecmeyen girisler var
        # (olculdu: DataPC_WhiteRoom.forge'da 495 TOC girisinin 30'u indekste yok).
        ad = (s.get("tani") or {}).get("ad") or ""
        if not ad:
            i_ad, i_etiket = _indeks_adi(gid)
            ad = i_ad or i_etiket
        hedef = _hedef_klasor(kok, satir["sinif"], ad, gid)
        if os.path.exists(hedef) and os.path.abspath(hedef) != os.path.abspath(s["klasor"]):
            hedef = os.path.join(os.path.dirname(hedef),
                                 os.path.basename(hedef) + "_2")
        try:
            if os.path.abspath(hedef) != os.path.abspath(s["klasor"]):
                os.rename(s["klasor"], hedef)
        except OSError:
            hedef = s["klasor"]                                  # ad agaci kurulamadi
        mevcut[gid] = hedef
        r["acilan"] += 1
        r["dosya"] += len(s.get("dosyalar") or [])
        for d in (s.get("dosyalar") or []):
            try:
                r["bayt"] += os.path.getsize(os.path.join(hedef, os.path.basename(d)))
            except OSError:
                pass
        if i % ILERLEME_ADIMI == 0 or i == n:
            _log(progress, "  %d of %d entries unpacked (%s written)."
                 % (i, n, _boy(r["bayt"])))

    kunye["tamam"] = not r["iptal"] and not r.get("mesaj")
    kunye["iptal"] = r["iptal"]
    kunye["acilan"] = r["acilan"]
    kunye["dosya"] = r["dosya"]
    kunye["bayt"] = r["bayt"]
    kunye["atlanan"], kirp1 = _kirp(r["atlanan"])
    kunye["basarisiz"], kirp2 = _kirp(r["basarisiz"])
    kunye["liste_kirpildi"] = {"atlanan": kirp1, "basarisiz": kirp2}
    kunye["bitis"] = time.strftime("%Y-%m-%d %H:%M:%S")
    _kunye_yaz(kok, kunye)

    r["atlanan_sayi"] = len(r["atlanan"])
    r["basarisiz_sayi"] = len(r["basarisiz"])
    r["ok"] = r["acilan"] > 0 or (sec["secilen"] == len(r["atlanan"]))
    r["sure"] = round(time.time() - t0, 2)
    if not r.get("mesaj"):
        r["mesaj"] = ("%d of %d entries unpacked into %s: %d files, %s. %d entries were "
                      "skipped and %d could not be opened."
                      % (r["acilan"], sec["secilen"], kok, r["dosya"], _boy(r["bayt"]),
                         len(r["atlanan"]), len(r["basarisiz"])))
    _log(progress, r["mesaj"])
    return r


# =====================================================================================
#  T2/T3 -- GERI KOY (once PLAN, sonra yazma)
# =====================================================================================
def _giris_klasorleri(kok):
    """Agacta bilgi.json tasiyan her klasor (explorer'in cikti birimi)."""
    out = []
    for dizin, altlar, dosyalar in os.walk(kok):
        if BILGI_AD in dosyalar:
            out.append(dizin)
            altlar[:] = []                                       # ic ice giris yok
    out.sort()
    return out


def plan_geri_koy(klasor, forge=None, progress=None):
    """T3 -- YAZMADAN once plan: hangi giris, hangi ic dosya, kac bayt, neden red.

    DEGISIKLIK OLCUSU: bilgi.json'daki `sha256` alani. Dosyanin bugunku sha256'si
    kayitlidakiyle ayniysa kullanici o baytlara DOKUNMAMISTIR ve yazilmaz -- boylece
    "ac -> hic degistirme -> geri koy" turu sifir yazma ile biter.

    Doner: {ok, klasor, forgeler, giris, dosya, degisti, degismedi, yazilacak,
            red, eksik, kayitsiz, uyari, not, mesaj}
    """
    t0 = time.time()
    r = {"ok": False, "tur": "plan", "klasor": os.path.abspath(klasor or ""),
         "forgeler": [], "giris": 0, "dosya": 0, "degisti": 0, "degismedi": 0,
         "yazilacak": [], "red": [], "eksik": [], "kayitsiz": [], "uyari": [],
         "mesaj": None, "surum": SURUM, "sure": 0.0}
    kok = r["klasor"]
    if not os.path.isdir(kok):
        r["mesaj"] = "Folder not found: %s" % kok
        return r

    kunye = None
    ky = os.path.join(kok, TOPLU_AD)
    if os.path.isfile(ky):
        try:
            with open(ky, encoding="utf-8") as f:
                kunye = json.load(f)
        except Exception:                                        # noqa: BLE001
            kunye = None
    r["kunye"] = kunye
    if kunye and not kunye.get("tamam"):
        r["uyari"].append("The unpack that produced this folder did not finish, so some "
                          "entries may be missing. What is here is still complete and can "
                          "be imported back.")

    klasorler = _giris_klasorleri(kok)
    if not klasorler:
        r["mesaj"] = ("No unpacked entry was found under %s (a %s file next to the .bin "
                      "files is what marks one)." % (kok, BILGI_AD))
        return r

    hedef_forge = os.path.abspath(forge) if forge else None
    forgeler = {}
    for d in klasorler:
        bilgi, _kl = EX.bilgi_oku(d)
        if not bilgi:
            r["red"].append({"klasor": d, "sebep": "%s could not be read here" % BILGI_AD})
            continue
        r["giris"] += 1
        bicim = bilgi.get("bicim")
        if bicim and bicim != EX.BICIM_HAM:
            r["red"].append({"klasor": d, "bicim": bicim,
                             "sebep": ("this folder was exported as %s, not raw bytes; "
                                       "import it from the Explorer, which compares it "
                                       "against its own manifest" % bicim)})
            continue
        f = hedef_forge or bilgi.get("forge")
        gid = bilgi.get("gid_sayi")
        gid = _int(gid if gid is not None else bilgi.get("gid"))
        if f:
            forgeler[os.path.abspath(f)] = forgeler.get(os.path.abspath(f), 0) + 1
        if hedef_forge and bilgi.get("forge") and \
                os.path.normcase(os.path.abspath(bilgi["forge"])) != os.path.normcase(hedef_forge):
            r["uyari"].append("Entry %s was exported from %s but will be written into %s."
                              % (bilgi.get("gid"), os.path.basename(bilgi["forge"]),
                                 os.path.basename(hedef_forge)))

        parcalar = list(bilgi.get("parcalar") or [])
        kayitli = set()
        for p in parcalar:
            adi = p.get("dosya")
            if not adi:
                continue
            kayitli.add(str(adi))
            yol = os.path.join(d, str(adi))
            r["dosya"] += 1
            if not os.path.isfile(yol):
                r["eksik"].append({"klasor": d, "dosya": adi, "gid": bilgi.get("gid"),
                                   "sebep": "this file was exported but is not here any more"})
                continue
            yeni = _dosya_sha(yol)
            if yeni == p.get("sha256"):
                r["degismedi"] += 1
                continue
            r["degisti"] += 1
            if p.get("yazilabilir") is False:
                r["red"].append({"klasor": d, "dosya": adi, "gid": bilgi.get("gid"),
                                 "sebep": (p.get("sebep") or "these bytes were exported "
                                           "from an entry that cannot be written back")})
                continue
            r["yazilacak"].append({
                "klasor": d, "dosya": adi, "yol": yol, "forge": f,
                "gid": bilgi.get("gid"), "gid_sayi": gid,
                "icid": p.get("icid"), "icid_sayi": _int(p.get("icid_sayi")
                                                         if p.get("icid_sayi") is not None
                                                         else p.get("icid")),
                "ad": bilgi.get("ad"), "sinif": bilgi.get("sinif"),
                "bayt": os.path.getsize(yol), "eski_bayt": p.get("boyut"),
                "uzunluk_degisti": (p.get("boyut") is not None
                                    and os.path.getsize(yol) != p.get("boyut")),
                "sha_eski": p.get("sha256"), "sha_yeni": yeni})
            if r["yazilacak"][-1]["uzunluk_degisti"]:
                r["uzunluk_degisen"] = r.get("uzunluk_degisen", 0) + 1
        for adi in sorted(os.listdir(d)):
            if adi.lower().endswith(".bin") and adi not in kayitli:
                r["kayitsiz"].append({"klasor": d, "dosya": adi,
                                      "sebep": ("this file is not recorded in %s, so there "
                                                "is no inner file to write it into; export "
                                                "the entry again to add it" % BILGI_AD)})

    r["forgeler"] = [{"forge": f, "giris": n} for f, n in sorted(forgeler.items())]
    r["ok"] = True
    r["sure"] = round(time.time() - t0, 2)
    r["not"] = ("Only the files whose bytes changed are written, and each one is appended "
                "to the archive with its table-of-contents row redirected, so the original "
                "bytes stay in place and every write can be reverted. The archive is never "
                "repacked from scratch.")
    r["mesaj"] = ("%d unpacked entries hold %d files here: %d changed, %d are untouched. "
                  "%d file(s) will be written, %d were refused, %d are missing and %d are "
                  "not recorded."
                  % (r["giris"], r["dosya"], r["degisti"], r["degismedi"],
                     len(r["yazilacak"]), len(r["red"]), len(r["eksik"]),
                     len(r["kayitsiz"])))
    _log(progress, r["mesaj"])
    return r


def geri_koy(klasor, forge=None, progress=None, iptal=None, etiket="", ustune=False,
             plan=None):
    """T2 -- agactaki DEGISMIS dosyalari oyuna geri koy. TEK YAZICI: kendi yazicimiz YOK.

    Her dosya explorer_core.geri_yukle ile TEK TEK yazilir (klasorun tamami degil):
    boylece degismemis kardes ic dosyalar YENIDEN YAZILMAZ. Ayni girise ait ikinci ve
    sonraki dosyalar `ustune=True` ile gider -- olculdu: birinci degisiklik ayakta
    kalir, dokunulmayan ic dosyalar vanilla kalir, tek bir kayit geri alinca arsiv
    vanilla sha256'ya doner.

    ARSIV KOMPLE YENIDEN PAKETLENMEZ (modul basligindaki "REPACK KARARI").

    Doner: {ok, yazilan, yazilan_sayi, basarisiz, atlanan, kayit, plan, iptal, mesaj}
    """
    t0 = time.time()
    r = {"ok": False, "tur": "geri_koy", "yazilan": [], "yazilan_sayi": 0,
         "basarisiz": [], "kayit": [], "ic_yazma": 0, "iptal": False, "mesaj": None,
         "surum": SURUM, "sure": 0.0}
    p = plan if plan is not None else plan_geri_koy(klasor, forge, progress)
    r["plan"] = {k: p.get(k) for k in ("giris", "dosya", "degisti", "degismedi",
                                       "red", "eksik", "kayitsiz", "uyari", "forgeler",
                                       "not", "mesaj")}
    if not p.get("ok"):
        r["mesaj"] = p.get("mesaj")
        return r
    isler = list(p.get("yazilacak") or [])
    if not isler:
        # "Degisen yok" ile "degisen vardi ama hepsi reddedildi" AYRI seylerdir. Ilk
        # surumde ikisi de "nothing differs" diyordu ve red edilen dosya kullaniciya
        # gorunmuyordu (olculdu: duman testi, kap olmayan giris degistirildi).
        engel = len(p.get("red") or []) + len(p.get("eksik") or []) + \
            len(p.get("kayitsiz") or [])
        r["ok"] = not p.get("red") and not p.get("kayitsiz")
        if p.get("degisti") or engel:
            r["mesaj"] = ("Nothing was written: %d of %d unpacked files were edited, but "
                          "none of them can be written back (%d refused, %d missing, %d "
                          "not recorded). The first reason is: %s"
                          % (p.get("degisti") or 0, p.get("dosya") or 0,
                             len(p.get("red") or []), len(p.get("eksik") or []),
                             len(p.get("kayitsiz") or []),
                             ((p.get("red") or p.get("eksik") or p.get("kayitsiz") or
                               [{}])[0].get("sebep") or "not stated")))
        else:
            r["mesaj"] = ("Nothing to write: none of the %d unpacked files differ from the "
                          "bytes that came out of the archive." % (p.get("dosya") or 0))
        _log(progress, r["mesaj"])
        return r

    # On kapilar: explorer_core her cagrida ayni ikisine bakar, ama YARIM is birakmamak
    # icin burada BIR KEZ ve BASTAN sorulur.
    kilit = KM.yazma_kilidi()
    if kilit:
        r["mesaj"] = KM._kilit_mesaji(kilit)
        return r
    if KM.oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        return r

    _log(progress, "Writing %d changed file(s) back ..." % len(isler))
    gorulen = set()
    for i, w in enumerate(isler, 1):
        if _iptal_mi(iptal):
            r["iptal"] = True
            _log(progress, "Cancelled after %d of %d files; what was written is recorded "
                           "and can be reverted." % (i - 1, len(isler)))
            break
        anahtar = (os.path.normcase(str(w.get("forge") or "")), w.get("gid_sayi"))
        et = "%s %s %s/%s" % (ETIKET, etiket or os.path.basename(w["klasor"]),
                              w.get("gid"), w.get("icid"))
        g = EX.geri_yukle(w["yol"], forge=w.get("forge"), etiket=et.strip(),
                          ustune=ustune or (anahtar in gorulen))
        if not g.get("ok"):
            r["basarisiz"].append({"dosya": w["dosya"], "klasor": w["klasor"],
                                   "gid": w.get("gid"), "icid": w.get("icid"),
                                   "sebep": g.get("mesaj") or "the archive could not be written"})
            continue
        gorulen.add(anahtar)
        r["kayit"].extend(list(g.get("kayit") or []))
        # `ic_yazma` = YAZICININ bildirdigi ic dosya sayisi; `yazilan_sayi` = bizim
        # yazmak ISTEDIGIMIZ dosya sayisi. Ikisi ayri tutulur cunku secmeli yazmanin
        # kaniti tam da bu farktir: klasorun tamami explorer'a verilseydi bizim
        # sayacimiz yine 1 derdi ama yazicininki 5 derdi (olculdu: sabotaj S4 ilk
        # surumde YAKALANMADI, cunku kapi yalnizca bizim sayacimiza bakiyordu).
        r["ic_yazma"] += len(g.get("yazilan") or [])
        r["yazilan"].append({"dosya": w["dosya"], "klasor": w["klasor"],
                             "gid": w.get("gid"), "icid": w.get("icid"),
                             "bayt": w.get("bayt"), "ic_yazma": len(g.get("yazilan") or []),
                             "kayit": list(g.get("kayit") or [])})
        if i % ILERLEME_ADIMI == 0 or i == len(isler):
            _log(progress, "  %d of %d files written." % (i, len(isler)))

    r["yazilan_sayi"] = len(r["yazilan"])
    r["basarisiz_sayi"] = len(r["basarisiz"])
    r["ok"] = r["yazilan_sayi"] > 0 and not r["basarisiz"]
    r["geri_alinabilir"] = True
    r["sure"] = round(time.time() - t0, 2)
    r["mesaj"] = ("%d of %d changed file(s) written into the archive; %d failed. Every "
                  "write is in the patch record and can be reverted from the Explorer."
                  % (r["yazilan_sayi"], len(isler), r["basarisiz_sayi"]))
    if r["basarisiz"]:
        r["mesaj"] += " First failure: %s" % r["basarisiz"][0]["sebep"]
    _log(progress, r["mesaj"])
    return r


# =====================================================================================
#  T3 -- RAPOR (Explorer uslubu: INGILIZCE, tam cumle, sayili)
# =====================================================================================
def _satirla(satirlar):
    return ["%d. %s" % (i, s) for i, s in enumerate(satirlar, 1) if s]


def rapor(r):
    """`adaylar` / `tahmin` / `ac` / `plan_geri_koy` / `geri_koy` sonucu -> numarali
    Ingilizce satirlar. Arayuz bunu oldugu gibi basar."""
    if not isinstance(r, dict):
        return []
    tur = r.get("tur")
    s = []
    if tur in ("adaylar", "tahmin"):
        s.append("%s holds %d entries and the filter selected %d of them, %s as stored in "
                 "the archive." % (r.get("forge_ad"), r.get("toc_giris") or 0,
                                   r.get("secilen") or 0, _boy(r.get("arsiv_bayt") or 0)))
        if tur == "tahmin" and r.get("ok"):
            if r.get("kesin"):
                s.append("Unpacking them writes exactly %s in %d files; every selected "
                         "entry was opened to measure this."
                         % (_boy(r.get("tahmin_bayt")), r.get("tahmin_dosya") or 0))
            else:
                s.append("Unpacking them writes about %s in roughly %d files. This is an "
                         "estimate: %d entries were opened as a sample and expanded %.2f "
                         "times on average." % (_boy(r.get("tahmin_bayt")),
                                                r.get("tahmin_dosya") or 0,
                                                r.get("olcum") or 0, r.get("oran") or 0))
            s.append("The run should take about %s on this machine."
                     % _sure_metni(r.get("tahmin_sure")))
        for u in (r.get("uyari") or []):
            s.append(u)
        if r.get("mesaj") and not r.get("ok"):
            s.append(r["mesaj"])
        return _satirla(s)

    if tur == "ac":
        t = r.get("tahmin") or {}
        sec = r.get("secim") or {}
        s.append("The archive %s holds %d entries and the filter selected %d of them."
                 % (sec.get("forge_ad"), sec.get("toc_giris") or 0, sec.get("secilen") or 0))
        if t:
            s.append("The estimate before writing was %s in %d files."
                     % (_boy(t.get("tahmin_bayt") or 0), t.get("tahmin_dosya") or 0))
        if r.get("onay_gerekli"):
            s.append(r.get("mesaj") or "Approval is required before writing.")
            s.append("Nothing was written to disk and the game archive was only read.")
            return _satirla(s)
        if r.get("disk_bos") is not None:
            s.append("The drive holding the output folder had %s free."
                     % _boy(r["disk_bos"]))
        s.append("%d entries were unpacked into %s as %d files totalling %s."
                 % (r.get("acilan") or 0, r.get("klasor"), r.get("dosya") or 0,
                    _boy(r.get("bayt") or 0)))
        if r.get("atlanan"):
            s.append("%d entries were skipped because they are already unpacked here; the "
                     "first one is %s." % (len(r["atlanan"]), r["atlanan"][0].get("gid")))
        if r.get("basarisiz"):
            s.append("%d entries could not be opened; the first reason is: %s"
                     % (len(r["basarisiz"]), r["basarisiz"][0].get("sebep")))
        if r.get("iptal"):
            s.append("The run was cancelled, so the selection is only partly unpacked.")
        s.append("The game archive was opened read-only for this; not one byte was written "
                 "into it.")
        return _satirla(s)

    if tur == "plan":
        s.append("%d unpacked entries were found under %s and they hold %d exported files."
                 % (r.get("giris") or 0, r.get("klasor"), r.get("dosya") or 0))
        s.append("%d of those files were edited and %d still carry the bytes that came out "
                 "of the archive." % (r.get("degisti") or 0, r.get("degismedi") or 0))
        s.append("%d file(s) will be written." % len(r.get("yazilacak") or []))
        if r.get("uzunluk_degisen"):
            s.append("%d of them changed length; the inner file's own size field is rewritten "
                     "for each, and any counts inside the object are yours to keep right."
                     % r["uzunluk_degisen"])
        for w in (r.get("yazilacak") or [])[:20]:
            s.append("Entry %s inner file %s will receive %s from %s (%d bytes, was %s)."
                     % (w.get("gid"), w.get("icid"), w.get("dosya"),
                        os.path.basename(w.get("klasor") or ""), w.get("bayt") or 0,
                        w.get("eski_bayt")))
        if len(r.get("yazilacak") or []) > 20:
            s.append("%d further files are in the same list and are not printed here."
                     % (len(r["yazilacak"]) - 20))
        for x in (r.get("red") or [])[:10]:
            s.append("Refused: %s in %s - %s." % (x.get("dosya") or "this folder",
                                                  os.path.basename(x.get("klasor") or ""),
                                                  x.get("sebep")))
        for x in (r.get("eksik") or [])[:10]:
            s.append("Missing: %s in %s - %s." % (x.get("dosya"),
                                                  os.path.basename(x.get("klasor") or ""),
                                                  x.get("sebep")))
        for x in (r.get("kayitsiz") or [])[:10]:
            s.append("Not recorded: %s in %s - %s." % (x.get("dosya"),
                                                       os.path.basename(x.get("klasor") or ""),
                                                       x.get("sebep")))
        for u in (r.get("uyari") or []):
            s.append(u)
        if r.get("not"):
            s.append(r["not"])
        return _satirla(s)

    if tur == "geri_koy":
        p = r.get("plan") or {}
        s.append("%d files were checked against the bytes they were exported from and %d "
                 "of them had changed." % (p.get("dosya") or 0, p.get("degisti") or 0))
        s.append(r.get("mesaj") or "")
        for x in (r.get("basarisiz") or [])[:10]:
            s.append("Failed: %s in entry %s - %s"
                     % (x.get("dosya"), x.get("gid"), x.get("sebep")))
        if r.get("iptal"):
            s.append("The run was cancelled; the writes already made are recorded and can "
                     "be reverted.")
        if p.get("not"):
            s.append(p["not"])
        return _satirla(s)
    return _satirla([r.get("mesaj")])


if __name__ == "__main__":                                       # elle yoklama
    import pprint
    if len(sys.argv) > 2 and sys.argv[1] == "plan":
        pprint.pprint(rapor(plan_geri_koy(sys.argv[2])))
    elif len(sys.argv) > 1:
        pprint.pprint(rapor(tahmin(sys.argv[1])))
    else:
        print("usage: toplu.py <forge>   |   toplu.py plan <folder>")
