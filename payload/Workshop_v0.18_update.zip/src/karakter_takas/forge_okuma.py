# -*- coding: utf-8 -*-
"""
forge_okuma.py — forge/BMS/TagRules OKUYUCU katmani (karakter_takas portu)
==========================================================================
Kaynak moduller (bayt-birebir davranis korunarak tasindi, mantik DEGISMEDI):
  * cwlib.py                 (ansiklopedi projesi, workshoplar\\character)
      konteyner_oku, oodle (cw cagri bicimi)
  * lz4blok.py               (karakter modu projesi)  — saf Python LZ4 blok cozucu
  * karakter_workshop_proto  (IcDosya, Kural, tagset_alanlari, kurallari_coz,
      kural_blob_yeniden, ad_parcala, kural_sahipligi, sabitler)
  * A1_kural_diff            (GirisYol, toc_yukle_yol)

TASINABILIRLIK: makineye ozel mutlak yol YOKTUR. Oyun klasoru daima parametre;
Oodle DLL'i GORELI adaylardan aranir (asagida `oodle_dll_yolu`).

SALT OKUNUR: bu modul hicbir dosyaya yazmaz; oyun dosyalari yalniz "rb" acilir.
"""
from __future__ import annotations

import collections
import ctypes
import glob as _glob
import os
import re
import struct
import zlib

# ---------------------------------------------------------------- sabitler
BMS = bytes.fromhex("33aafb5799fa0410")

ANA_GIRIS = 0x0228EA9158E7            # tum kostum sistemi (1 BuildTable + 10 TagRules)
IC_HUMAN_UNIQUE = 0x022DB216CA80      # Human-Unique TagRules ic dosyasi
TIP_TAGRULES = 0x02071BC3

ALAN_IMZA = b"\xf8\xfb"
CRC_TAGSET = zlib.crc32(b"TagSet") & 0xFFFFFFFF          # 0x0566C02B (olculdu)
KOD_HARFLERI = set("USGPCFDBA")


# ---------------------------------------------------------------- Oodle DLL
def oodle_dll_yolu() -> str | None:
    """Oodle DLL'ini ARAR (yuklemez). Yalniz GORELI yollara ve OODLE_DLL cevre
    degiskenine bakar; makineye ozel mutlak yol icermez.

    Paket duzeni: <paket>\\src\\karakter_takas\\  ->  <paket>\\tools\\oo2core_7_win64.dll
    """
    kok = os.path.dirname(os.path.abspath(__file__))
    adaylar = []
    ev = os.environ.get("OODLE_DLL")
    if ev:
        adaylar.append(ev)
    for d in (kok,
              os.path.join(kok, "tools"),
              os.path.join(kok, "..", "tools"),
              os.path.join(kok, "..", "..", "tools")):
        adaylar.append(os.path.join(d, "oo2core_7_win64.dll"))
        adaylar.extend(sorted(_glob.glob(os.path.join(d, "oo2core_*_win64.dll"))))
    for a in adaylar:
        if a and os.path.isfile(a):
            return os.path.abspath(a)
    return None


OODLE_YOK = ("oo2core_7_win64.dll bulunamadi. Paketin 'tools' klasorunde olmali "
             "(veya OODLE_DLL cevre degiskeniyle gosterin). Aranan yerler: "
             "modul klasoru, tools, ..\\tools, ..\\..\\tools")

_DLL = None


def _oodle_dll():
    global _DLL
    if _DLL is None:
        yol = oodle_dll_yolu()
        if yol is None:
            # Ayni pakette yasayan yalin_forge zaten dogru cozucuye sahip
            # (gelistirme agacinda SAIL tools'u, pakette ../tools). Kendi
            # aramamiz bos dondugunde ona sor — iki ortamda da tek davranis.
            try:
                import yalin_forge as _yf
                yol = _yf.oodle_dll_yolu()
            except Exception:                                   # noqa: BLE001
                yol = None
        if yol is None:
            raise RuntimeError(OODLE_YOK)
        _DLL = ctypes.WinDLL(yol)
    return _DLL


def oodle_hazir():
    """DLL'i simdiden yukle; yoksa NET hata ver. (Sessizce yanlis bayt uretmek
    yerine kosunun BASINDA durmak icin — sablon oylamasi Oodle'siz kalirsa
    32+ vanilla 0xFFA girisi sessizce atlanir ve cikti degisirdi.)"""
    _oodle_dll()


def oodle_cw(data: bytes, ulen: int):
    """cwlib.oodle ile AYNI cagri bicimi (restype c_int, son parametre 3,
    tam boy tampon). konteyner_oku bu bicimi kullanir."""
    d = _oodle_dll()
    fn = d.OodleLZ_Decompress
    fn.restype = ctypes.c_int
    out = ctypes.create_string_buffer(ulen)
    n = fn(data, ctypes.c_int64(len(data)), out, ctypes.c_int64(ulen),
           1, 0, 0, None, 0, None, None, None, 0, 3)
    return out.raw if n == ulen else None


def oodle_kl(veri: bytes, hamBoy: int) -> bytes:
    """kl_lib.oodle_ac ile AYNI cagri bicimi (argtypes'li, +64 tampon, hata
    durumunda istisna). bms_ac bu bicimi kullanir."""
    d = _oodle_dll()
    fn = d.OodleLZ_Decompress
    fn.restype = ctypes.c_longlong
    fn.argtypes = [ctypes.c_char_p, ctypes.c_longlong, ctypes.c_char_p,
                   ctypes.c_longlong, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                   ctypes.c_void_p, ctypes.c_longlong, ctypes.c_void_p,
                   ctypes.c_void_p, ctypes.c_void_p, ctypes.c_longlong, ctypes.c_int]
    buf = ctypes.create_string_buffer(hamBoy + 64)
    r = fn(veri, len(veri), buf, hamBoy, 1, 0, 0, None, 0, None, None, None, 0, 0)
    if r != hamBoy:
        raise RuntimeError("oodle r=%d beklenen=%d" % (r, hamBoy))
    return buf.raw[:hamBoy]


def oodle_yf(comp: bytes, rawlen: int):
    """yalin_forge.oodle ile AYNI cagri bicimi (+64 tampon, son parametre 3,
    None doner). 0x091 ic konteynerleri bu bicimi kullanir."""
    d = _oodle_dll()
    fn = d.OodleLZ_Decompress
    fn.restype = ctypes.c_longlong
    out = ctypes.create_string_buffer(rawlen + 64)
    n = fn(comp, ctypes.c_int64(len(comp)), out, ctypes.c_int64(rawlen),
           1, 0, 0, None, 0, None, None, None, 0, 3)
    return out.raw[:rawlen] if n == rawlen else None


# ---------------------------------------------------------------- LZ4 (saf Python)
def lz4_decompress(src, dst_len=None):
    """lz4blok.py'nin birebir kopyasi (saf Python LZ4 blok cozucu)."""
    ip = 0
    n = len(src)
    out = bytearray()
    while ip < n:
        token = src[ip]; ip += 1
        lit = token >> 4
        if lit == 15:
            while True:
                b = src[ip]; ip += 1
                lit += b
                if b != 255:
                    break
        out += src[ip:ip + lit]; ip += lit
        if ip >= n:
            break  # son dizi (match yok)
        off = src[ip] | (src[ip + 1] << 8); ip += 2
        if off == 0:
            raise ValueError("offset 0 - corrupt stream")
        ml = token & 15
        if ml == 15:
            while True:
                b = src[ip]; ip += 1
                ml += b
                if b != 255:
                    break
        ml += 4
        pos = len(out) - off
        if pos < 0:
            raise ValueError("kotu offset %d @out=%d" % (off, len(out)))
        for _ in range(ml):
            out.append(out[pos]); pos += 1
    if dst_len is not None and len(out) != dst_len:
        raise ValueError("size mismatch: %d != %d" % (len(out), dst_len))
    return bytes(out)


# ---------------------------------------------------------------- BMS konteyner
def konteyner_oku(d, off):
    """cwlib.konteyner_oku'nun birebir kopyasi (tablolu + akis form)."""
    assert d[off:off + 8] == BMS, "BMS magic not found"
    ver, algo = struct.unpack_from("<HB", d, off + 8)
    raw = struct.unpack_from("<I", d, off + 11)[0]
    p = off + 15
    icerik = bytearray()
    if raw >> 31:
        cnt = struct.unpack_from("<I", d, p)[0]; p += 4
        sizes = []
        for _ in range(cnt):
            u, c = struct.unpack_from("<II", d, p); p += 8
            sizes.append((u, c))
        for u, c in sizes:
            p += 4
            v = d[p:p + c]; p += c
            if u == c:
                icerik += v
            elif algo == 4:
                icerik += lz4_decompress(v, u)
            else:
                icerik += oodle_cw(v, u)
    else:
        while p < len(d):
            flag = d[p]; p += 1
            if flag == 0:
                u = struct.unpack_from("<I", d, p)[0]; p += 4
                icerik += d[p:p + u]; p += u
            else:
                cc, uu, crc = struct.unpack_from("<III", d, p); p += 12
                v = d[p:p + cc]; p += cc
                icerik += (lz4_decompress(v, uu) if algo == 4 else oodle_cw(v, uu))
            if p >= len(d):
                break
    return bytes(icerik), p


# ---------------------------------------------------------------- forge TOC (tam yol)
def toc_yukle_yol(yol: str) -> dict:
    """A1_kural_diff.toc_yukle_yol'un birebir kopyasi: {fid: (off, ln, ext)}."""
    with open(yol, "rb") as f:
        f.seek(13)
        hoff = struct.unpack("<q", f.read(8))[0]
        f.seek(hoff)
        count = struct.unpack("<I", f.read(4))[0]
        toc_off = struct.unpack("<q", f.read(8))[0]
        f.seek(toc_off)
        td = f.read(count * 24)
    toc = {}
    for i in range(count):
        off, fid, ln, ext = struct.unpack_from("<QQII", td, i * 24)
        toc[fid] = (off, ln, ext)
    return toc


# ---------------------------------------------------------------- ic dosya / giris
class IcDosya:
    """karakter_workshop_proto.IcDosya'nin birebir kopyasi."""

    def __init__(self, ic_id: int, sira: int, veri: bytes, govde_ofset: int):
        self.ic_id = ic_id
        self.sira = sira
        self.veri = veri
        self.govde_ofset = govde_ofset          # giris govdesi icindeki mutlak ofset
        self.tip_crc = struct.unpack_from("<I", veri, 0)[0]
        self.boyut_alani = struct.unpack_from("<I", veri, 4)[0]
        self.ad_len = struct.unpack_from("<I", veri, 8)[0]
        self.govde_basi = 25 + self.ad_len
        self.nesne_id = struct.unpack_from("<Q", veri, 13 + self.ad_len)[0]

    def boyut_tutarli(self) -> bool:
        """boyut alani = len - 13 - adLen  (olculdu: 37.131-13-12 = 37.106)"""
        return self.boyut_alani == len(self.veri) - 13 - self.ad_len


class GirisYol:
    """A1_kural_diff.GirisYol'un birebir kopyasi (TAM dosya yolu alir).
    (bilgi-amacli baslik_bilgi/govde_bilgi alanlari cikartildi; hicbir uretim
    baytina etkileri yoktu.)"""

    def __init__(self, yol: str, fid: int):
        self.yol = yol
        self.fid = fid
        toc = toc_yukle_yol(yol)
        if fid not in toc:
            raise KeyError("0x%012X is not present in %s" % (fid, yol))
        self.toc_sayisi = len(toc)
        self.toc = toc
        self.toc_off, self.toc_len, self.ext = toc[fid]
        with open(yol, "rb") as f:
            f.seek(self.toc_off)
            self.ham = f.read(self.toc_len)
        self.baslik, self.govde_baslangic = konteyner_oku(self.ham, 0)
        self.govde, _ = konteyner_oku(self.ham, self.govde_baslangic)
        self.sayi = struct.unpack_from("<H", self.baslik, 0)[0]
        self.ic_dosyalar = []
        p = 0
        for i in range(self.sayi):
            cid, cl = struct.unpack_from("<QI", self.baslik, 2 + i * 18)
            self.ic_dosyalar.append(IcDosya(cid, i, self.govde[p:p + cl], p))
            p += cl
        self.govde_toplam = p

    def bul(self, ic_id: int):
        for d in self.ic_dosyalar:
            if d.ic_id == ic_id:
                return d
        return None


class GirisYolHam:
    """takas_uret.GirisYolHam'in birebir kopyasi (ham baytlardan calisir;
    dosya yazmadan once kurulan girisi dogrulamak icin)."""

    def __init__(self, ham: bytes):
        self.ham = ham
        self.baslik, p1 = konteyner_oku(ham, 0)
        self.govde, _ = konteyner_oku(ham, p1)
        self.sayi = struct.unpack_from("<H", self.baslik, 0)[0]
        self.ic_dosyalar = []
        p = 0
        for i in range(self.sayi):
            cid, cl = struct.unpack_from("<QI", self.baslik, 2 + i * 18)
            self.ic_dosyalar.append(IcDosya(cid, i, self.govde[p:p + cl], p))
            p += cl

    def bul(self, ic_id):
        for d in self.ic_dosyalar:
            if d.ic_id == ic_id:
                return d
        return None


# ---------------------------------------------------------------- TagRules
class Kural:
    """TagRules kurali: [1 tag'lik ANAHTAR TagSet][N tag'lik UYE TagSet]."""

    __slots__ = ("no", "anahtar_off", "anahtar_tag", "uye_off", "uye_n", "uyeler")

    def __init__(self, no, anahtar_off, anahtar_tag, uye_off, uye_n, uyeler):
        self.no = no
        self.anahtar_off = anahtar_off
        self.anahtar_tag = anahtar_tag
        self.uye_off = uye_off          # ic dosya icindeki alan basi
        self.uye_n = uye_n
        self.uyeler = uyeler

    @property
    def uye_sayi_ofseti(self) -> int:
        return self.uye_off + 12        # [u16 sira][F8FB][u32 0][u32 crc] -> +12 sayi

    @property
    def uye_veri_ofseti(self) -> int:
        return self.uye_off + 16


def tagset_alanlari(blob: bytes):
    """[(alan_ofseti, tag_sayisi)] — imza taramasi + alan kalibi dogrulamasi."""
    hits = []
    i = 0
    n = len(blob)
    while True:
        j = blob.find(ALAN_IMZA, i)
        if j < 0:
            break
        if j >= 2 and j + 16 <= n:
            sifir, crc = struct.unpack_from("<II", blob, j + 2)
            if sifir == 0 and crc == CRC_TAGSET:
                h = j - 2
                cnt = struct.unpack_from("<I", blob, h + 12)[0]
                if cnt < 0x10000 and h + 16 + 4 * cnt <= n:
                    hits.append((h, cnt))
        i = j + 1
    return hits


def kurallari_coz(blob: bytes):
    """TagRules ic dosyasi -> kural listesi. Ayrica yapi dogrulamasi doner."""
    uyari = []
    alanlar = tagset_alanlari(blob)
    if len(alanlar) % 2:
        uyari.append("TagSet alan sayisi TEK (%d) — anahtar/uye eslesmesi bozulabilir"
                     % len(alanlar))
    kurallar = []
    for i in range(0, len(alanlar) - 1, 2):
        (ha, na), (hm, nm) = alanlar[i], alanlar[i + 1]
        if na != 1:
            uyari.append("kural #%d anahtar TagSet'inde %d tag var (1 bekleniyordu)"
                         % (i // 2, na))
        anahtar = struct.unpack_from("<I", blob, ha + 16)[0]
        uyeler = list(struct.unpack_from("<%dI" % nm, blob, hm + 16))
        kurallar.append(Kural(i // 2, ha, anahtar, hm, nm, uyeler))
    return kurallar, uyari


def kural_blob_yeniden(blob: bytes, degisim: dict) -> bytes:
    """degisim: {kural_no: yeni_uye_tag_listesi} -> yeni ic dosya baytlari.

    Sadece UYE TagSet govdeleri degisir. Sarmalayicidaki `boyut` alani
    (= len - 13 - adLen) delta kadar duzeltilir.
    """
    kurallar, _ = kurallari_coz(blob)
    parcalar = []
    imlec = 0
    for k in sorted(kurallar, key=lambda x: x.uye_off):
        if k.no not in degisim:
            continue
        yeni = degisim[k.no]
        parcalar.append(blob[imlec:k.uye_sayi_ofseti])
        parcalar.append(struct.pack("<I", len(yeni)))
        parcalar.append(struct.pack("<%dI" % len(yeni), *yeni))
        imlec = k.uye_veri_ofseti + 4 * k.uye_n
    parcalar.append(blob[imlec:])
    yeni_blob = bytearray(b"".join(parcalar))
    ad_len = struct.unpack_from("<I", yeni_blob, 8)[0]
    struct.pack_into("<I", yeni_blob, 4, len(yeni_blob) - 13 - ad_len)
    return bytes(yeni_blob)


# ---------------------------------------------------------------- ad cozumleme
_AD_RE = re.compile(r"^([A-Za-z]+)_([A-Z])_([A-Za-z0-9]+)(?:_(.*))?$")


def ad_parcala(ad: str):
    """'Tunic_U_BlackBeard_X_SashBelt' -> parca/kod/karakter/kiyafet/alt.
    (karakter_workshop_proto.ad_parcala'nin birebir kopyasi)"""
    if not ad:
        return None
    m = _AD_RE.match(ad)
    if not m:
        return None
    parca, kod, karakter, kalan = m.groups()
    if kod not in KOD_HARFLERI:
        return None
    kiyafet, alt = "BASE", None
    if kalan:
        # OLCULDU: kalan ya 'Kiyafet', ya 'Kiyafet_X_Alt', ya da dogrudan 'X_Alt'
        if kalan.startswith("X_"):
            kiyafet, alt = "BASE", kalan[2:]
        elif "_X_" in kalan:
            once, sonra = kalan.split("_X_", 1)
            kiyafet = once or "BASE"
            alt = sonra
        else:
            kiyafet = kalan
    return {"ad": ad, "parca": parca, "kod": kod, "karakter": karakter,
            "kiyafet": kiyafet.rstrip("?") or "BASE", "alt": alt,
            "kirpik": ad.endswith("?") or "?" in ad}


def kural_sahipligi(kurallar, tag_ad: dict):
    """kural_no -> {karakter(KUCUK HARF): o karaktere ait cozulmus uye sayisi}
    (karakter_workshop_proto.kural_sahipligi'nin birebir kopyasi)"""
    out = {}
    for k in kurallar:
        d = collections.Counter()
        for t in k.uyeler:
            a = tag_ad.get(t, (None, None))[0]
            b = ad_parcala(a) if a else None
            if b:
                d[b["karakter"].lower()] += 1
        out[k.no] = dict(d)
    return out
