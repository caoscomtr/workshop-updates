# -*- coding: utf-8 -*-
"""
motor.py — NPC TAKAS URETECI cekirdegi (takas_uret.py'nin TASINABILIR portu)
============================================================================
Kaynak: karakter atolyesi (npc_takas\\uretec\\takas_uret.py) (dogrulanmis surum;
41/41 bagimsiz kapi + 2 reproduksiyon sha esitligi). URETIM MANTIGI DEGISMEDI:
ayni fonksiyonlar, ayni kapilar, ayni bayt davranisi. Degisen yalniz:

  * oyun klasoru sabit degil, PARAMETRE (`oyun`);
  * ad havuzu parca_sozlugu.db'den degil, pakete PISIRILMIS tag_adlari.json'dan
    (ayni birlesim: kwp.VERI.tag_ad + ek_tag_adlar — uretim aninda dondu);
  * gelistirme-donemi _YazmaKalkani portta YOK; guvenlik esdegeri:
    yaz_guvenli() YALNIZ cikti_yol'a yazar ve oyun klasoru ile
    %LOCALAPPDATA%\\ACBFR_Modding altina yazmayi REDDEDER. Oyun klasorune
    yazan hicbir API yoktur; oyun dosyalari yalniz "rb" acilir.

MEKANIZMA (uc seridin olcumleri uzerine):
  1) Kostum girisi 0x0228EA9158E7 **vanilla patch_01**'den okunur (SERIT A:
     Kamzik'in boot tabani, patch_01'in 11 kurallik Human-Unique duzeltmesini
     sessizce geri aliyordu — uretec DAIMA p01 tabanindan baslar).
  2) Human-Unique (0x022DB216CA80) icinde hedef kiyafet slotunun kural(lar)i
     bulunur (anahtar listesi verilirse ad aramasi atlanir).
  3) Donor = hedef karakter ailesinin BASKIN sahip oldugu Human-Unique kurali.
     Yeni uye listesi = donor listesi SIRASI KORUNARAK + olculen ek tag
     0x3B018EE1 (Kamzik eki; vanilla HU#80/#99 ve HS#9 uyesi).
  4) Ic dosya sarmalayici ADLARI KORUNUR.
  5) Giris yeniden sarilir: tablolu BMS, bloklar STORED (u==c), adler init=0,
     ver/algo/raw alanlari VANILLA p01 konteynerinden AYNEN.
  6) Kap = SERIT C receti: baslik p01[:1050] (cift-turetim kapili), sistem
     girisleri 0x0C1/0xFFA/0xFF8/0x091/0x010 vanilla'dan hesap,
     TOC sirasi [kostum, C1, FFA, FF8, 91, 10], hiza 32768.

DETERMINISTIK: ayni girdiyle ayni bayt cikar (icerde iki kez kurulup sha
karsilastirilir). Zaman damgasi / rastgelelik forge'a girmez.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import struct
import sys
import zlib

from . import forge_okuma as F
from . import sistem_giris as S
from .forge_okuma import GirisYol, GirisYolHam

BURASI = os.path.dirname(os.path.abspath(__file__))

# Konsolsuz calistirmada (pythonw/.pyw) sys.stdout None olur; ilerleme satirlari
# o durumda sessizce yutulur. Uretim baytlarina ETKISI YOKTUR.
if sys.stdout is None:                                     # pragma: no cover
    def print(*a, **k):  # noqa: A001 - bilincli golgeleme
        pass

# ---------------------------------------------------------------- sabitler
ANA = F.ANA_GIRIS                       # 0x0228EA9158E7 (tum kostum sistemi)
HU = F.IC_HUMAN_UNIQUE                  # 0x022DB216CA80 (Human-Unique TagRules)

# SERIT A olcumu: Kamzik'in 20'lik listesindeki tek "donor disi" tag.
# Ad COZULEMEDI; vanilla yayilimi HU#80/#99 + HS#9 (yani mesru vanilla tagi).
EK_TAG_VARSAYILAN = 0x3B018EE1

SISTEM_SIRA = [0x0C1, 0xFFA, 0xFF8, 0x091, 0x010]   # 83/83 vanilla yama kalibi
HIZALAMA = 32768

TAG_ADLARI_DOSYA = os.path.join(BURASI, "tag_adlari.json")


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _p01(oyun: str) -> str:
    return S.p01_yolu(oyun)


def _boot(oyun: str) -> str:
    return S.boot_yolu(oyun)


def oyun_dogrula(oyun: str) -> str:
    """Oyun klasoru parametresini dogrula (vanilla p01 + boot mevcut olmali)."""
    oyun = os.path.abspath(oyun)
    if not os.path.isdir(oyun):
        raise FileNotFoundError("game folder not found: %s" % oyun)
    for y in (_boot(oyun), _p01(oyun)):
        if not os.path.isfile(y):
            raise FileNotFoundError(
                "oyun klasorunde beklenen forge yok: %s" % y)
    return oyun


# ---------------------------------------------------------------- yazma kapisi
def _acbfr_modding_koku() -> str | None:
    la = os.environ.get("LOCALAPPDATA")
    return os.path.join(la, "ACBFR_Modding") if la else None


def yaz_guvenli(yol: str, veri: bytes, oyun: str) -> int:
    """YALNIZ cikti_yol'a yazar. Oyun klasoru ve ACBFR_Modding altina yazmayi
    REDDEDER (kaynak uretecin yaz_guvenli + _YazmaKalkani ikilisinin tasinabilir
    guvenlik esdegeri: bu paketin oyun klasorune yazan HICBIR yolu yoktur)."""
    tam = os.path.abspath(yol)
    yasaklar = [os.path.abspath(oyun)]
    acbfr = _acbfr_modding_koku()
    if acbfr:
        yasaklar.append(os.path.abspath(acbfr))
    for kok in yasaklar:
        try:
            ortak = os.path.commonpath([os.path.normcase(tam), os.path.normcase(kok)])
        except ValueError:
            continue                     # farkli surucu — kesisim yok
        if ortak == os.path.normcase(kok):
            raise AssertionError("WRITE REFUSED (protected folder): %s" % tam)
    ust = os.path.dirname(tam)
    if ust and not os.path.isdir(ust):
        os.makedirs(ust, exist_ok=True)
    with open(tam, "wb") as f:
        f.write(veri)
        f.flush()
        os.fsync(f.fileno())
    return len(veri)


# ---------------------------------------------------------------- ad havuzu
_HAVUZ = None


def ad_havuzu() -> dict:
    """tag -> ad. Pakete pisirilmis tag_adlari.json'dan (uretim aninda
    kwp.VERI.tag_ad + ek_tag_adlar.json birlesimi olarak donduruldu; DB pakete
    girmez). Kaynak uretecin ad_havuzu() ciktisiyla AYNI icerik."""
    global _HAVUZ
    if _HAVUZ is None:
        with open(TAG_ADLARI_DOSYA, encoding="utf-8") as f:
            ham = json.load(f)
        if not ham:
            raise RuntimeError("tag_adlari.json is empty - this installation is damaged")
        _HAVUZ = {int(k, 16) & 0xFFFFFFFF: a for k, a in ham.items()}
    return dict(_HAVUZ)


def sahiplik(kurallar, havuz):
    """kural_no -> {karakter(kucuk): cozulmus uye sayisi}."""
    tag_ad = {t: (a, "") for t, a in havuz.items()}
    return F.kural_sahipligi(kurallar, tag_ad)


# ---------------------------------------------------------------- BMS tablolu
def tablolu_coz(ham: bytes, off: int) -> dict:
    """Tablolu BMS konteynerin param + blok tablosunu okur (cozmeden)."""
    assert ham[off:off + 8] == F.BMS, "BMS magic not found @%d" % off
    ver, algo = struct.unpack_from("<HB", ham, off + 8)
    raw = struct.unpack_from("<I", ham, off + 11)[0]
    assert raw >> 31, "tablolu form bekleniyordu (raw=0x%08X)" % raw
    p = off + 15
    cnt = struct.unpack_from("<I", ham, p)[0]
    p += 4
    boylar = []
    for _ in range(cnt):
        u, c = struct.unpack_from("<II", ham, p)
        p += 8
        boylar.append((u, c))
    for _u, c in boylar:
        p += 4 + c
    return dict(ver=ver, algo=algo, raw=raw, cnt=cnt, boylar=boylar, son=p)


def bms_tablolu_stored(veri: bytes, ver: int, algo: int, raw: int) -> bytes:
    """TEK blok STORED (u==c) tablolu konteyner; ver/algo/raw AYNEN korunur.
    Vanilla kostum girisinde her iki konteyner de 1 blok (olculdu) — ayni
    bolumleme korunur. adler32 init=0 (format referansi + boru_boya kaniti)."""
    o = bytearray(F.BMS)
    o += struct.pack("<HB", ver, algo)
    o += struct.pack("<I", raw)
    o += struct.pack("<I", 1)
    o += struct.pack("<II", len(veri), len(veri))
    o += struct.pack("<I", zlib.adler32(veri, 0) & 0xFFFFFFFF)
    o += veri
    return bytes(o)


# ---------------------------------------------------------------- kural secimi
def hedef_kurallari_bul(kurallar, havuz, sahip, slotlar):
    """Slot adlarini Human-Unique kurallarina cozer.
    Kural secilir <=> (a) cozulmus bir uyesinin adi slotu iceriyor (normalize)
                      (b) kuralin cozulmus uyeleri icinde BASKIN sahip Edward.
    Donen: {kural_no: {"anahtar":..., "slotlar": [eslesen slotlar], ...}}"""
    slot_n = [(s, norm(s)) for s in slotlar if norm(s)]
    secim, atlanan = {}, []
    for k in kurallar:
        adlar = [(t, havuz.get(t)) for t in k.uyeler]
        eslesen = sorted({s for s, sn in slot_n
                          if any(a and sn in norm(a) for _t, a in adlar)})
        if not eslesen:
            continue
        sh = sahip[k.no]
        baskin = max(sh.items(), key=lambda kv: kv[1])[0] if sh else None
        if baskin != "edward":
            atlanan.append(dict(kural=k.no, anahtar="0x%08X" % k.anahtar_tag,
                                slotlar=eslesen, baskin=baskin,
                                sebep="baskin sahip Edward degil — oyuncu kurali "
                                      "olmadigi icin dokunulmadi"))
            continue
        secim[k.no] = dict(anahtar=k.anahtar_tag, slotlar=eslesen,
                           uye_n=k.uye_n,
                           cozulen=[a for _t, a in adlar if a],
                           cozulmeyen=["0x%08X" % t for t, a in adlar if not a])
    return secim, atlanan


def donor_kural_bul(kurallar, havuz, aile, donor_anahtar=None):
    """Hedef karakter ailesinin NPC kostum kurali: ailenin BASKIN sahip oldugu
    (owned >= diger her sahip ve owned >= 2) kurallar icinden EN COK parcaya
    sahip olani (esitlikte kucuk kural no). Kamzik kaniti: BlackBeard -> #14."""
    an = norm(aile)
    adaylar = []
    for k in kurallar:
        sayim = {}
        for t in k.uyeler:
            a = havuz.get(t)
            b = F.ad_parcala(a) if a else None
            if b:
                kk = b["karakter"].lower()
                sayim[kk] = sayim.get(kk, 0) + 1
        owned = sayim.get(an, 0)
        if donor_anahtar is not None:
            if k.anahtar_tag == donor_anahtar:
                adaylar.append((k, owned, sayim))
            continue
        if owned >= 2 and owned == max(sayim.values()):
            adaylar.append((k, owned, sayim))
    if not adaylar:
        return None, []
    adaylar.sort(key=lambda x: (-x[1], x[0].no))
    return adaylar[0], [dict(kural=k.no, anahtar="0x%08X" % k.anahtar_tag,
                             aile_parcasi=o, sahipler=s) for k, o, s in adaylar]


# ---------------------------------------------------------------- giris kurucu
def giris_yeniden_kur(giris: GirisYol, degisim: dict):
    """p01 kostum girisini Human-Unique kural degisimiyle yeniden kurar.
    Ic dosya adlari ve sirasi AYNEN korunur; yalniz HU govdesi degisir."""
    hu = giris.bul(HU)
    assert hu is not None, "Human-Unique inner file not found"
    yeni_hu = F.kural_blob_yeniden(hu.veri, degisim)

    parcalar, boylar = [], {}
    for d in giris.ic_dosyalar:
        v = yeni_hu if d.ic_id == HU else d.veri
        parcalar.append(v)
        boylar[d.ic_id] = len(v)
    yeni_govde = b"".join(parcalar)

    # baslik: [u16 sayi] + sayi x [id u64][len u32][6B kuyruk AYNEN]
    assert len(giris.baslik) == 2 + 18 * giris.sayi, \
        "baslik tablosunda beklenmeyen kuyruk var (%d != %d)" % (
            len(giris.baslik), 2 + 18 * giris.sayi)
    yb = bytearray(struct.pack("<H", giris.sayi))
    for d in giris.ic_dosyalar:
        yb += struct.pack("<QI", d.ic_id, boylar[d.ic_id])
        yb += giris.baslik[2 + d.sira * 18 + 12: 2 + d.sira * 18 + 18]
    yeni_baslik = bytes(yb)

    # sarmal parametreleri VANILLA girisin kendi konteynerlerinden
    pb = tablolu_coz(giris.ham, 0)
    pg = tablolu_coz(giris.ham, pb["son"])
    assert pb["cnt"] == 1 and pg["cnt"] == 1, \
        "vanilla kostum girisinde 1+1 blok bekleniyordu (%d+%d)" % (pb["cnt"], pg["cnt"])
    assert pb["son"] + (pg["son"] - pb["son"]) == len(giris.ham)

    ham = (bms_tablolu_stored(yeni_baslik, pb["ver"], pb["algo"], pb["raw"])
           + bms_tablolu_stored(yeni_govde, pg["ver"], pg["algo"], pg["raw"]))

    # gidis-donus: cozunce ayni baslik/govde cikmali
    b2, p2 = F.konteyner_oku(ham, 0)
    g2, p3 = F.konteyner_oku(ham, p2)
    assert b2 == yeni_baslik and g2 == yeni_govde and p3 == len(ham), \
        "giris sarmal gidis-donusu tutmadi"
    return ham, dict(yeni_hu=yeni_hu, yeni_baslik=yeni_baslik,
                     yeni_govde=yeni_govde,
                     eski_params=dict(baslik=pb, govde=pg))


# ---------------------------------------------------------------- kap (SERIT C)
def forge_kur(sablon1050: bytes, girisler, hiza=HIZALAMA):
    """[0:1050] baslik | @1050 u32 n | @1054 i64 tocOff | @1062 8xFF | govdeler |
    TOC nx<QQII> | 0x00 dolgu -> boy % hiza == 0  (83/83 vanilla yama kalibi)"""
    assert len(sablon1050) == 1050
    fidler = [f for f, _, _ in girisler]
    assert len(set(fidler)) == len(fidler), "duplicate fid"
    kayitlar, govde, pos = [], bytearray(), 1070
    for fid, veri, ext in girisler:
        kayitlar.append((pos, fid, len(veri), ext))
        govde += veri
        pos += len(veri)
    f = bytearray(sablon1050)
    f += struct.pack("<I", len(kayitlar)) + struct.pack("<q", pos) + b"\xff" * 8
    f += govde
    assert len(f) == pos
    for off, fid, ln, ext in kayitlar:
        f += struct.pack("<QQII", off, fid, ln, ext)
    f += b"\x00" * ((-len(f)) % hiza)
    return bytes(f), kayitlar


def sistem_girisleri_uret(oyun: str):
    """SERIT C receti — tamami guncel vanilla boot/p01'den hesap. Deterministik."""
    g0c1 = S.c1_giris()

    sab, ns, celiski, _taniksiz, _tolere = S.sablon_oyla(oyun)
    # celiski = SADECE beraberlik (gercek belirsizlik). Cogunlukla cozulen
    # anlasmazlik _tolere'ye gider ve uretimi durdurmaz — ikinci bir mod kuran
    # kullanicilar eskiden burada bloke oluyordu (bkz. ucuncu_taraf_kap_mi).
    # Mesaj INGILIZCE: kullaniciya dogrudan gorunur.
    assert not celiski, (
        "Could not read this game installation: its archive files disagree "
        "and there is no clear majority. This usually means an extra "
        "third-party .forge mod is installed under an unexpected name — "
        "remove extra .forge mods from the game folder and try again.")
    van_ids = S.vanilla_p01_boot_idleri(oyun)
    ids = sorted(set(van_ids) | {ANA})
    gffa_ic = S.ffa_ic_uret([(S.ATA_P01, []), (S.ATA_BOOT, ids)], sab)
    gffa = S.bms_stored_sar(gffa_ic)

    gff8 = S.blowpipe_ff8(oyun)[0]

    p01_091 = S.giris_bul(_p01(oyun), 0x091)[0]
    r91 = S.coz_091(p01_091)
    acik91, _ = S.coz_konteynerler(p01_091, r91["kuyruk_off"])
    taban91 = {k["fid"]: acik91[k["c"]:k["c"] + k["a"]] for k in r91["kayitlar"]}
    assert ANA in taban91, "HEDEF p01'in 0x091 tabaninda kayitli degil"
    grup = taban91[ANA]
    t91, k91 = struct.unpack_from("<HH", grup, 0)
    deps91 = list(struct.unpack_from("<%dQ" % k91, grup, 4))
    g091 = S.uret_091([(ANA, deps91, t91)])

    g010, g010_ham = S.urun_s010(oyun)
    assert g010 == g010_ham, "0x010 round-trip mismatch"

    return {0x0C1: g0c1, 0xFFA: gffa, 0xFF8: gff8, 0x091: g091, 0x010: g010}, \
        dict(ffa_id_sayisi=len(ids), ffa_vanilla_id=len(van_ids),
             sablon_kayit=ns, s091_dep=["0x%X" % x for x in deps91])


# ---------------------------------------------------------------- ana uretim
def uret(slotlar, aile, oyun: str, cikti_yol: str,
         ek_taglar=(EK_TAG_VARSAYILAN,),
         anahtarlar=None,
         anahtar_slot_idx=None,
         donor_anahtar=None,
         uye_takas=None) -> dict:
    """takas_uret.uret'in birebir portu (oyun klasoru parametreli).
    Kapilardan biri kirmizi ise AssertionError firlatir; dosya YAZILMAZ ya da
    yarim birakilmaz (yazma en sonda, tum on-kapilar yesilken yapilir).

    v0.8 genisletmesi (2026-08-14 sayimina dayali, eski cagrilar bayt-birebir):
      aile          : str  -> her slota AYNI karakter (eski davranis)
                      list -> slot-paralel karakter listesi (coklu kurulum)
      donor_anahtar : skaler ya da slot-paralel liste
      uye_takas     : {eski_tag: yeni_tag} ya da slot-paralel liste; donor
                      SIRASI korunarak yerinde ikame (sac/yuz karisimi tabani)"""
    oyun = oyun_dogrula(oyun)
    F.oodle_hazir()      # DLL yoksa BASTA net hata (sessiz yanlis uretim olmasin)

    slotlar = list(slotlar)
    n_slot = len(slotlar)

    def _coklu(v, ad):
        """skaler -> slot sayisi kadar cogalt; liste -> uzunlugu dogrula."""
        if isinstance(v, (list, tuple)):
            if len(v) != n_slot:
                raise ValueError("%s must have the same length as the slot list "
                                 "(%d != %d)" % (ad, len(v), n_slot))
            return list(v)
        return [v] * n_slot

    aileler = _coklu(aile, "aile")
    donorlar = _coklu(donor_anahtar, "donor_anahtar")
    takaslar = _coklu(uye_takas, "uye_takas")
    tek_donor = len(set(zip(aileler, [str(d) for d in donorlar],
                            [str(t) for t in takaslar]))) == 1

    R = {"girdi": dict(slotlar=slotlar, aile=aile if isinstance(aile, str) else list(aile),
                       ek_taglar=["0x%08X" % t for t in ek_taglar],
                       anahtarlar=(["0x%08X" % a for a in anahtarlar]
                                   if anahtarlar else None),
                       donor_anahtar=([("0x%08X" % d) if d is not None else None
                                       for d in donorlar]),
                       uye_takas=[({"0x%08X" % k: "0x%08X" % v for k, v in t.items()}
                                   if t else None) for t in takaslar]),
         "kapilar": []}

    def kapi(ad, ok, notu=""):
        R["kapilar"].append([ad, bool(ok), notu])
        print("  [%s] %-64s %s" % ("OK " if ok else "RED", ad, notu))
        if not ok:
            raise AssertionError("KAPI KIRMIZI: %s %s" % (ad, notu))

    print("=" * 88)
    print("TAKAS URETECI: %s" % " · ".join("%s->%s" % (s, a)
                                           for s, a in zip(slotlar, aileler)))
    print("=" * 88)

    # ---- 0) taban girisler -------------------------------------------------
    print("\n[0] taban: vanilla p01 + boot (SALT OKUNUR)")
    P01 = _p01(oyun)
    BOOT = _boot(oyun)
    p01g = GirisYol(P01, ANA)
    bootg = GirisYol(BOOT, ANA)
    print("  p01  kostum: toc_len=%d ic=%d govde=%d" % (p01g.toc_len, p01g.sayi, p01g.govde_toplam))
    print("  boot kostum: toc_len=%d ic=%d govde=%d" % (bootg.toc_len, bootg.sayi, bootg.govde_toplam))
    kapi("G0 p01/boot kostum girisi 11'er ic dosya", p01g.sayi == 11 and bootg.sayi == 11)
    kapi("G0b ic dosya boyut alanlari tutarli 11/11",
         all(d.boyut_tutarli() for d in p01g.ic_dosyalar))

    with open(P01, "rb") as f:
        bas_p01 = f.read(1050)
    with open(BOOT, "rb") as f:
        bas_boot = bytearray(f.read(1050))
    bas_boot[25] |= 0x10
    kapi("G1 baslik cift turetim p01[:1050]==boot[:1050]|@25|=0x10",
         bas_p01 == bytes(bas_boot))

    # ---- 1) kural cozumu ---------------------------------------------------
    print("\n[1] Human-Unique kural cozumu (taban=p01)")
    hu_p01 = p01g.bul(HU)
    hu_boot = bootg.bul(HU)
    kur_p01, uy1 = F.kurallari_coz(hu_p01.veri)
    kur_boot, _ = F.kurallari_coz(hu_boot.veri)
    kapi("G2 kural yapisi uyarisiz, p01/boot kural sayisi esit",
         not uy1 and len(kur_p01) == len(kur_boot),
         "n=%d" % len(kur_p01))
    havuz = ad_havuzu()
    sahip = sahiplik(kur_p01, havuz)
    print("  ad havuzu: %d tag adli" % len(havuz))

    # p01'in boot'a gore duzelttigi kurallar (KAMZIK TUZAGI olcumu)
    p01_duzeltilen = [i for i, (a, b) in enumerate(zip(kur_boot, kur_p01))
                      if a.anahtar_tag != b.anahtar_tag or a.uyeler != b.uyeler]
    print("  p01'in duzelttigi kurallar: %s" % p01_duzeltilen)

    # hedef kurallar
    if anahtarlar:
        # anahtar -> slot indeksi eslemesi KORUNUR (coklu-donor icin sart).
        # anahtar_slot_idx verilirse anahtarlarla PARALELDIR: bir slot birden
        # cok kurala yayilabilir (Walpole = 6 kural, olculdu). Verilmezse eski
        # davranis: i'inci anahtar i'inci slotundur (golden yol degismez).
        if anahtar_slot_idx is not None and len(anahtar_slot_idx) != len(anahtarlar):
            raise ValueError("anahtar_slot_idx must have the same length as the key list")
        anahtar_slot = {}
        for i, a in enumerate(anahtarlar):
            if a in anahtar_slot:
                raise ValueError("ayni anahtar iki slota verilemez: 0x%08X" % a)
            anahtar_slot[a] = (anahtar_slot_idx[i] if anahtar_slot_idx is not None
                               else i)
        secim = {k.no: dict(anahtar=k.anahtar_tag,
                            slotlar=[slotlar[anahtar_slot[k.anahtar_tag]]],
                            slot_idx=anahtar_slot[k.anahtar_tag],
                            uye_n=k.uye_n, cozulen=[], cozulmeyen=[])
                 for k in kur_p01 if k.anahtar_tag in anahtar_slot}
        atlanan = []
    else:
        secim, atlanan = hedef_kurallari_bul(kur_p01, havuz, sahip, slotlar)
        slot_idx_map = {s: i for i, s in enumerate(slotlar)}
        for s in secim.values():
            eslesen = [slot_idx_map[x] for x in s["slotlar"] if x in slot_idx_map]
            s["slot_idx"] = eslesen[0] if eslesen else 0
            if not tek_donor and len(set(eslesen)) != 1:
                # coklu-donor kipinde kural TEK slota ait olmali; ad aramasi
                # belirsiz kaldiysa anahtar sabitlemesiyle cagrilmali
                kapi("G3b coklu-donor: kural %d tek slota atanabildi" % s.get("uye_n", -1),
                     False, "slotlar=%s" % s["slotlar"])
    for no, s in sorted(secim.items()):
        print("  HEDEF kural #%-3d anahtar=0x%08X uye=%-3d slot=%s"
              % (no, s["anahtar"], s["uye_n"], "+".join(s["slotlar"])))
    for a in atlanan:
        print("  (atlandi) kural #%-3d %s baskin=%s" % (a["kural"], a["anahtar"], a["baskin"]))
    kapi("G3 hedef slot kurali bulundu", len(secim) >= 1, "%d kural" % len(secim))
    R["hedef_kurallar"] = {str(no): dict(s, anahtar="0x%08X" % s["anahtar"])
                           for no, s in sorted(secim.items())}
    R["atlanan_kurallar"] = atlanan

    # donor kurallar (slot-paralel; tek-donor yolunda eski davranisla BIREBIR)
    vanilla_uyeler = {t for k in kur_p01 for t in k.uyeler}
    listeler, R["donorlar"], R["yeni_listeler"] = [], [], {}
    for i, (slot_i, aile_i, danahtar_i, takas_i) in enumerate(
            zip(slotlar, aileler, donorlar, takaslar)):
        donor, donor_adaylar = donor_kural_bul(kur_p01, havuz, aile_i, danahtar_i)
        kapi("G4 donor (NPC kostum) kurali bulundu [%s]" % slot_i,
             donor is not None, "aday=%d" % len(donor_adaylar))
        dk, downed, dsayim = donor
        print("  DONOR[%s] kural #%-3d anahtar=0x%08X uye=%d (%s'e ait cozulmus=%d)"
              % (slot_i, dk.no, dk.anahtar_tag, dk.uye_n, aile_i, downed))
        for t in dk.uyeler:
            print("     0x%08X  %s" % (t, havuz.get(t, "")))
        kapi("G4b donor hedef kurallardan farkli [%s]" % slot_i, dk.no not in secim)
        taban = list(dk.uyeler)
        if takas_i:
            kapi("G4c takas anahtarlarinin tumu donor uyesi [%s]" % slot_i,
                 set(takas_i) <= set(dk.uyeler),
                 "disarida=%s" % ["0x%08X" % t for t in set(takas_i) - set(dk.uyeler)])
            taban = [takas_i.get(t, t) for t in taban]
        yeni_i = taban + [t for t in ek_taglar if t not in taban]
        if takas_i:
            kapi("G4d yeni liste tekrarsiz [%s]" % slot_i,
                 len(set(yeni_i)) == len(yeni_i))
            kapi("G4e her yeni tagin vanilla HU'da emsali var [%s]" % slot_i,
                 set(yeni_i) <= vanilla_uyeler,
                 "emsalsiz=%s" % ["0x%08X" % t for t in set(yeni_i) - vanilla_uyeler])
        listeler.append(yeni_i)
        R["donorlar"].append(dict(
            slot=slot_i, aile=aile_i, kural=dk.no, anahtar="0x%08X" % dk.anahtar_tag,
            uye_n=dk.uye_n, aile_parcasi=downed, sahipler=dsayim,
            uyeler=[dict(tag="0x%08X" % t, ad=havuz.get(t)) for t in dk.uyeler],
            adaylar=donor_adaylar))
        R["yeni_listeler"][slot_i] = [dict(tag="0x%08X" % t, ad=havuz.get(t))
                                      for t in yeni_i]
    R["donor"] = R["donorlar"][0]                # eski okuyucular icin
    R["yeni_liste"] = R["yeni_listeler"][slotlar[0]]

    # degisim: her hedef kural KENDI slotunun listesini alir
    degisim = {}
    for no, s in secim.items():
        degisim[no] = list(listeler[s["slot_idx"]])
    kapi("G4f her hedef kural tek bir slot listesine baglandi",
         len(degisim) == len(secim))
    delta_beklenen = sum(4 * (len(degisim[no]) - s["uye_n"])
                         for no, s in secim.items())
    print("  yeni uye listeleri: %s · beklenen govde delta %+d B"
          % (" · ".join("%s=%d tag" % (s, len(l))
                        for s, l in zip(slotlar, listeler)), delta_beklenen))

    # ---- 2) giris yeniden kurulumu ----------------------------------------
    print("\n[2] kostum girisi yeniden kuruluyor (adlar KORUNUR, stored sarmal)")
    ham, ara = giris_yeniden_kur(p01g, degisim)
    kapi("G5 govde delta beklendigi gibi",
         len(ara["yeni_govde"]) - p01g.govde_toplam == delta_beklenen,
         "%+d B" % (len(ara["yeni_govde"]) - p01g.govde_toplam))

    # yeni HU'yu geri coz: hedefler yeni listede, kalan her kural p01 ile ayni
    kur_yeni, uy2 = F.kurallari_coz(ara["yeni_hu"])
    ayni, farkli_dis = 0, []
    for i, (a, b) in enumerate(zip(kur_p01, kur_yeni)):
        if i in degisim:
            continue
        if a.anahtar_tag == b.anahtar_tag and a.uyeler == b.uyeler:
            ayni += 1
        else:
            farkli_dis.append(i)
    kapi("G6 yeni HU: hedef kurallar tam yeni listeyle",
         not uy2 and all(kur_yeni[no].uyeler == degisim[no]
                         and kur_yeni[no].anahtar_tag == kur_p01[no].anahtar_tag
                         for no in degisim))
    kapi("G6b yeni HU: hedef disi %d kuralin tumu p01 ile ayni" % (len(kur_p01) - len(degisim)),
         ayni == len(kur_p01) - len(degisim) and not farkli_dis,
         "farkli=%s" % farkli_dis)

    # KAMZIK TUZAGI kapisi: p01 duzeltmeleri korunuyor mu?
    korunan = [i for i in p01_duzeltilen if i not in degisim
               and kur_yeni[i].uyeler == kur_p01[i].uyeler
               and kur_yeni[i].uyeler != kur_boot[i].uyeler]
    tuzak_ok = len(korunan) == len([i for i in p01_duzeltilen if i not in degisim])
    kapi("G7 KAMZIK TUZAGI kapali: p01 duzeltmeleri korunuyor", tuzak_ok,
         "%d/%d kural p01 surumunde" % (len(korunan),
                                        len([i for i in p01_duzeltilen if i not in degisim])))
    R["p01_duzeltilen_kurallar"] = p01_duzeltilen

    # ad koruma kapisi
    g2 = GirisYolHam(ham)
    kapi("G8 sarmalayici adlari korunmus (adLen p01 ile 11/11 ayni)",
         all(x.ad_len == y.ad_len for x, y in zip(g2.ic_dosyalar, p01g.ic_dosyalar))
         and all(x.ic_id == y.ic_id for x, y in zip(g2.ic_dosyalar, p01g.ic_dosyalar)))

    # ---- 3) sistem girisleri + kap ----------------------------------------
    print("\n[3] sistem girisleri (SERIT C receti) + kap")
    sistem, sistem_meta = sistem_girisleri_uret(oyun)
    for fid in SISTEM_SIRA:
        print("  0x%03X  %8d B  sha=%s" % (fid, len(sistem[fid]), sha(sistem[fid])[:16]))
    R["sistem"] = dict(sistem_meta,
                       boylar={"0x%03X" % f: len(v) for f, v in sistem.items()},
                       shalar={"0x%03X" % f: sha(v) for f, v in sistem.items()})

    ext = p01g.ext
    girisler = [(ANA, ham, ext)] + [(fid, sistem[fid], 0) for fid in SISTEM_SIRA]
    veri, kayitlar = forge_kur(bas_p01, girisler)
    veri2, _ = forge_kur(bas_p01, girisler)     # ayni girdiden ikinci kurulum
    kapi("G9 DETERMINIZM: iki kurulum bayt-birebir", veri == veri2)

    n = yaz_guvenli(cikti_yol, veri, oyun)
    print("  YAZILDI: %s" % cikti_yol)
    print("  boyut=%d (%dx%d) sha256=%s" % (n, n // HIZALAMA, HIZALAMA, sha(veri)))
    R["cikti"] = dict(yol=os.path.abspath(cikti_yol), boyut=n, sha256=sha(veri),
                      kostum_len=len(ham), kostum_sha=sha(ham), ext="0x%08X" % ext,
                      kayitlar=[[o, "%012X" % f, l, "%08X" % e] for o, f, l, e in kayitlar])

    # ---- 4) dosyadan gidis-donus dogrulamasi ------------------------------
    print("\n[4] dosyadan gidis-donus dogrulamasi")
    surum, _h, nn, _tp, kay = S.toc_oku(cikti_yol)
    kapi("G10 TOC: 6 giris, surum 50", nn == 6 and surum == 50)
    kapi("G10b TOC sirasi [kostum, C1, FFA, FF8, 91, 10]",
         [f for _o, f, _l, _e in kay] == [ANA] + SISTEM_SIRA)
    geri = {f: S.giris(cikti_yol, o, l) for o, f, l, _e in kay}
    kapi("G11 kostum girisi bayt-birebir geri okundu", geri[ANA] == ham)

    son = GirisYol(cikti_yol, ANA)
    kur_son, uy3 = F.kurallari_coz(son.bul(HU).veri)
    kapi("G12 dosyadan cozum: hedef kurallar yeni listede",
         not uy3 and all(kur_son[no].uyeler == degisim[no] for no in degisim))
    kapi("G12b dosyadan cozum: 11 ic dosya, id sirasi p01 ile ayni",
         son.sayi == 11 and [d.ic_id for d in son.ic_dosyalar]
         == [d.ic_id for d in p01g.ic_dosyalar])

    ic_ffa, _m = S.bms_ac(geri[0xFFA])
    d_ffa = S.ffa_coz(ic_ffa)
    kapi("G13 0xFFA: nAta=2, HEDEF listede, artik=0",
         d_ffa["n"] == 2 and d_ffa["artik"] == 0
         and ANA in d_ffa["atalar"][1]["idler"],
         "boot id=%d" % d_ffa["atalar"][1]["m"])
    _v8, nata8, bl8 = S.ff8_bloklari(geri[0xFF8])
    kapi("G14 0xFF8: nAta=2 (p01+boot), artiksiz",
         nata8 == 2 and 6 + sum(len(x[2]) for x in bl8) == len(geri[0xFF8]),
         "N=[%d,%d]" % (bl8[0][1], bl8[1][1]))
    d91 = S.s091_coz(geri[0x091])
    kapi("G15 0x091: HEDEF kaydi var", any(k == ANA for k, _u, _o in d91["kayitlar"]),
         "N=%d" % d91["N"])
    oz10 = S.s010_ozet(geri[0x010])
    kapi("G16 0x010: kanonik sira", oz10["kanonik"], "damga=%s" % (oz10["derleme"],))
    kapi("G17 0x0C1: 43 B", len(geri[0x0C1]) == 43)

    gecen = sum(1 for _a, ok, _n in R["kapilar"] if ok)
    print("\nKAPI OZETI: %d/%d yesil" % (gecen, len(R["kapilar"])))
    return R
