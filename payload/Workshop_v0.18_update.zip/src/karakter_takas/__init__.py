# -*- coding: utf-8 -*-
"""
karakter_takas — NPC KIYAFET TAKAS uretici (Outfit Workshop paketi icin port)
=============================================================================
Edward'in secili kiyafet slotlarini (varsayilan: SharkHunter + Whaler) bir NPC
karakterinin kostum setiyle degistiren DataPC_boot_patch_02.forge uretir.

Kaynak: karakter atolyesi (npc_takas\\uretec\\takas_uret.py) — 2026-08-13'te
bagimsiz skeptik seritle dogrulanmis surum (41/41 kapi + reproduksiyon sha
esitligi + "vanilla disi aciklanamayan bayt = 0" koken kaniti). Uretim mantigi
bu portta DEGISTIRILMEDI; yalniz yollar tasinabilir yapildi (bkz. motor.py).

DIS API
-------
  uret(karakter_adi, oyun_klasoru, cikti_yol,
       slotlar=("SharkHunter", "Whaler")) -> rapor dict
      * oyun_klasoru: AC4 Resynced kurulum klasoru (SALT OKUNUR kullanilir).
      * cikti_yol: uretilecek forge dosyasi. Oyun klasorune ve
        %LOCALAPPDATA%\\ACBFR_Modding altina yazmak REDDEDILIR — kurulum
        (dosyayi oyuna kopyalama) bu API'nin isi DEGILDIR.
      * rapor dict: girdi/kapilar/donor/yeni_liste/sistem/cikti(sha256)...
        Ayrica cikti_yol + ".rapor.json" dosyasina yazilir.

  roster() -> [{"ad", "gorunen_ad", "parca_sayisi", "kiyafetler"}, ...]
      Pisirilmis aday listesi (TAM cekirdekli + donor kurali bu makinede
      DOGRULANMIS karakterler). `ad` alani uret()'e verilir.

  roster_dogrula(oyun_klasoru) -> dict
      Hizli kapi: her aday icin pisirilmis donor anahtarinin GUNCEL p01
      Human-Unique kurallarinda hala bulundugunu dogrular (uret cagirmadan).

VERI DOSYALARI (modul klasorunden okunur, os.path.dirname(__file__)):
  tag_adlari.json — tag->ad havuzu (parca_sozlugu + ek_tag_adlar birlesiminin
                    pisirilmis hali; veritabani pakete GIRMEZ)
  roster.json     — aday listesi + slot/donor anahtar sabitlemeleri

SABITLENMIS ANAHTARLAR (neden):
  * Hedef slot kurallari AD ARAMASIYLA degil, dogrulanmis kosunun kullandigi
    ANAHTARLARLA secilir (SharkHunter=0x87EE0487, Whaler=0x95F41ED4). Olculdu:
    ad aramasi ayni isimli UCUNCU bir kurali (#202, 0x06D8B1EF) da secip
    dogrulanmamis fazladan degisiklik uretirdi.
  * Her adayin donor kurali roster.json'da anahtarla sabitlidir. BlackBeard
    icin bu, oyunda calistigi KANITLI Kamzik donoru 0xD0FF1C0D'dir (otomatik
    sezgisel #22'yi secerdi; dogrulanmis cikti #14 ile uretildi).

GUVENLIK: oyun dosyalari yalniz "rb" ile acilir; bu pakette oyun klasorune
yazan hicbir kod yolu yoktur.
"""
from __future__ import annotations

import json
import os

from . import motor
from .motor import EK_TAG_VARSAYILAN, donor_kural_bul, norm  # noqa: F401
from . import forge_okuma as _F

__version__ = "1.0"

_BURASI = os.path.dirname(os.path.abspath(__file__))
_ROSTER_DOSYA = os.path.join(_BURASI, "roster.json")

_ROSTER = None


def _roster_yukle() -> dict:
    global _ROSTER
    if _ROSTER is None:
        with open(_ROSTER_DOSYA, encoding="utf-8") as f:
            _ROSTER = json.load(f)
        if not _ROSTER.get("adaylar"):
            raise RuntimeError("roster.json is empty - this installation is damaged")
    return _ROSTER


def roster():
    """Aday listesi: [{"ad", "gorunen_ad", "parca_sayisi", "kiyafetler"}, ...]"""
    r = _roster_yukle()
    return [{"ad": a["ad"], "gorunen_ad": a["gorunen_ad"],
             "parca_sayisi": a["parca_sayisi"], "kiyafetler": list(a["kiyafetler"])}
            for a in r["adaylar"]]


def _aday_bul(karakter_adi: str):
    r = _roster_yukle()
    n = norm(karakter_adi)
    for a in r["adaylar"]:
        if norm(a["ad"]) == n or norm(a["gorunen_ad"]) == n:
            return a
    return None


def _slot_anahtarlari(slotlar):
    """Slot adlarini pisirilmis (dogrulanmis) kural anahtarlarina cevir.
    Tablo degeri TEK anahtar (str) ya da COKLU anahtar (liste — kiyafet birden
    cok kurala yayiliyorsa, orn. Walpole 6 kural) olabilir.
    Doner: (anahtarlar, slot_idx_listesi) — paralel listeler; herhangi bir slot
    tabloda yoksa None (motor ad aramasina duser — dogrulanmamis secim)."""
    r = _roster_yukle()
    tablo = {norm(k): v for k, v in r["slot_anahtarlari"].items()}
    anahtarlar, idxler = [], []
    for i, s in enumerate(slotlar):
        v = tablo.get(norm(s))
        if v is None:
            return None
        for a in (v if isinstance(v, list) else [v]):
            anahtarlar.append(int(a, 16))
            idxler.append(i)
    return anahtarlar, idxler


def uret(karakter_adi: str, oyun_klasoru: str, cikti_yol: str,
         slotlar=("SharkHunter", "Whaler"),
         ek_taglar=(EK_TAG_VARSAYILAN,),
         anahtarlar=None,
         donor_anahtar=None,
         rapor_yol=None) -> dict:
    """Edward'in `slotlar` kiyafet slotlarini `karakter_adi` NPC'sinin kostum
    setiyle degistiren patch_02 forge'unu `cikti_yol`a uretir.

    karakter_adi roster()'daki `ad` (veya gorunen_ad); roster disi bir aile adi
    da verilebilir (donor otomatik aranir — dogrulanmamis kullanim).
    Oyun klasoru SALT OKUNUR; yazma yalniz cikti_yol (+ .rapor.json) icindir.
    """
    aday = _aday_bul(karakter_adi)
    if aday is not None:
        aile = aday["ad"]
        if donor_anahtar is None and aday.get("donor_anahtar"):
            donor_anahtar = int(aday["donor_anahtar"], 16)
    else:
        aile = karakter_adi

    slotlar = list(slotlar)
    anahtar_idx = None
    if anahtarlar is None:
        cift = _slot_anahtarlari(slotlar)
        if cift is None:
            print("UYARI: slot adlari pisirilmis anahtar tablosunda yok — ad "
                  "aramasina dusuluyor (dogrulanmamis secim yapabilir): %s"
                  % (slotlar,))
        else:
            anahtarlar, anahtar_idx = cift

    R = motor.uret(slotlar, aile, oyun_klasoru, cikti_yol,
                   ek_taglar=tuple(ek_taglar),
                   anahtarlar=anahtarlar,
                   anahtar_slot_idx=anahtar_idx,
                   donor_anahtar=donor_anahtar)
    R["port"] = {"surum": __version__,
                 "karakter_girdisi": karakter_adi,
                 "roster_kaydi": (aday["ad"] if aday else None),
                 "donor_sabitleme": ("roster" if (aday and aday.get("donor_anahtar")
                                                 and donor_anahtar is not None)
                                     else "parametre/otomatik")}

    ryol = rapor_yol or (cikti_yol + ".rapor.json")
    motor.yaz_guvenli(ryol, json.dumps(R, ensure_ascii=False, indent=1).encode("utf-8"),
                      motor.oyun_dogrula(oyun_klasoru))
    print("rapor -> %s" % ryol)
    return R


def hedef_slotlar():
    """Karakter kurulabilir hedef slotlarin sirali listesi (roster'daki
    sabitlenmis anahtar tablosundan). Ilk eleman GUI varsayilanidir.
    Walpole ILK: hikayede erken acilan, herkeste olan kiyafet — 2026-08-30'da
    oyunda KANITLANDI (Jenny/6-kural coklu slot, kaptan gozuyle)."""
    r = _roster_yukle()
    adlar = list(r["slot_anahtarlari"])
    for s in ("Whaler", "Walpole"):          # ters sirayla one ekle
        if s in adlar:
            adlar.remove(s)
            adlar.insert(0, s)
    return adlar


def uret_coklu(atamalar, oyun_klasoru: str, cikti_yol: str,
               ek_taglar=(EK_TAG_VARSAYILAN,),
               rapor_yol=None) -> dict:
    """COKLU kurulum: her kiyafet slotuna AYRI karakter (v0.8).

    atamalar: sirali {slot_adi: karakter_adi} (ya da (slot, karakter) listesi).
    Ornek: {"Whaler": "BlackBeard", "SharkHunter": "AnneBonny"} — oyunda Whaler
    giyince Blackbeard, SharkHunter giyince Anne Bonny olursun.
    Tum slot adlari pisirilmis anahtar tablosunda OLMAK ZORUNDA (ad aramasi
    coklu kipte belirsizlik uretebilir; motor bu durumda kapiyla durur)."""
    if not isinstance(atamalar, dict):
        atamalar = dict(atamalar)
    if not atamalar:
        raise ValueError("atamalar bos")
    slotlar = list(atamalar)
    cift = _slot_anahtarlari(slotlar)
    if cift is None:
        raise ValueError("coklu kurulumda tum slotlar sabitlenmis anahtar "
                         "tablosunda olmali: %s" % (slotlar,))
    anahtarlar, anahtar_idx = cift
    aileler, donorlar, roster_k = [], [], []
    for s in slotlar:
        aday = _aday_bul(atamalar[s])
        if aday is None:
            raise ValueError("character not in roster: %r" % (atamalar[s],))
        aileler.append(aday["ad"])
        donorlar.append(int(aday["donor_anahtar"], 16)
                        if aday.get("donor_anahtar") else None)
        roster_k.append(aday["ad"])

    R = motor.uret(slotlar, aileler, oyun_klasoru, cikti_yol,
                   ek_taglar=tuple(ek_taglar),
                   anahtarlar=anahtarlar,
                   anahtar_slot_idx=anahtar_idx,
                   donor_anahtar=donorlar)
    R["port"] = {"surum": __version__, "kip": "coklu",
                 "atamalar": {s: k for s, k in atamalar.items()},
                 "roster_kayitlari": roster_k}
    ryol = rapor_yol or (cikti_yol + ".rapor.json")
    motor.yaz_guvenli(ryol, json.dumps(R, ensure_ascii=False, indent=1).encode("utf-8"),
                      motor.oyun_dogrula(oyun_klasoru))
    print("rapor -> %s" % ryol)
    return R


def roster_dogrula(oyun_klasoru: str) -> dict:
    """Hizli roster kapisi (uret cagirmadan): her adayin sabitlenmis donor
    anahtari ve slot anahtarlari GUNCEL p01 Human-Unique'te bulunuyor mu?"""
    oyun = motor.oyun_dogrula(oyun_klasoru)
    _F.oodle_hazir()
    r = _roster_yukle()
    havuz = motor.ad_havuzu()
    p01g = motor.GirisYol(motor._p01(oyun), motor.ANA)
    kurallar, uyari = _F.kurallari_coz(p01g.bul(motor.HU).veri)
    mevcut = {k.anahtar_tag for k in kurallar}
    sonuc = {"kural_sayisi": len(kurallar), "yapi_uyarilari": uyari,
             "slotlar": {}, "adaylar": {}, "bulunamayan": []}
    for s, v in r["slot_anahtarlari"].items():
        sonuc["slotlar"][s] = (int(v, 16) in mevcut)
    for a in r["adaylar"]:
        pin = int(a["donor_anahtar"], 16)
        donor, _ad = donor_kural_bul(kurallar, havuz, a["ad"], pin)
        ok = donor is not None
        sonuc["adaylar"][a["ad"]] = {
            "ok": ok,
            "donor_anahtar": a["donor_anahtar"],
            "kural_no": (donor[0].no if ok else None),
            "uye_n": (donor[0].uye_n if ok else None),
        }
        if not ok:
            sonuc["bulunamayan"].append(a["ad"])
    sonuc["ok"] = (not sonuc["bulunamayan"]) and all(sonuc["slotlar"].values())
    return sonuc
