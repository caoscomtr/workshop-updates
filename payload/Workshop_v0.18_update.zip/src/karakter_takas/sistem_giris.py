# -*- coding: utf-8 -*-
"""
sistem_giris.py — patch_02 SISTEM GIRISI ureticileri (karakter_takas portu)
===========================================================================
Kaynak moduller (BLOWPIPE_TEMIZ; mantik ve bayt davranisi DEGISMEDI, yalniz
oyun klasoru sabit yerine PARAMETRE oldu):
  * kl_lib.py        — toc_oku, giris, giris_bul, bms_ac, ffa_coz, s010_coz/ozet, forgeler
  * kl_uret.py       — s010 kodek, sablon_oyla (0xFFA 128 B ata sablonu oy coklugu),
                       ata_kaydi, ffa_ic_uret, bms_stored_sar, vanilla_p01_boot_idleri,
                       urun_s010
  * s091lib.py       — coz_091, coz_konteynerler (0x091 ic konteynerleri)
  * s091_uret.py     — 0x091 ureticisi (grup/yuk/konteyner/uret)
  * bf_ff8_patch01.py— 0xFF8 ata blogu ureticisi (blowpipe_ff8)
  * sistem_ffa_c1.py — bms_stored + c1_giris (0x0C1, 43 B sabit)

SALT OKUNUR: oyun dosyalari yalniz open(yol, "rb") ile okunur; bu modul hicbir
dosyaya yazmaz. Her cagride diskten taze okur (onbellek yok).
"""
from __future__ import annotations

import hashlib
import os
import re
import struct
import zlib

from . import forge_okuma as F

BMS_SIHIR = F.BMS

ATA_P01 = b"DataPC_boot_patch_01.forge"
ATA_BOOT = b"DataPC_boot.forge"
P01_AD = "DataPC_boot_patch_01.forge"
BOOT_AD = "DataPC_boot.forge"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def p01_yolu(oyun: str) -> str:
    return os.path.join(oyun, P01_AD)


def boot_yolu(oyun: str) -> str:
    return os.path.join(oyun, BOOT_AD)


# ------------------------------------------------------------------ forge TOC (kl_lib)
def toc_oku(yol):
    """(surum, hdrOff, n, tocPos, [(off, fid, ln, ext)...])  — kl_lib.toc_oku"""
    with open(yol, "rb") as f:
        bas = f.read(64)
        if bas[0:8] != b"scimitar":
            raise ValueError("scimitar magic not found: %s" % yol)
        surum = struct.unpack_from("<I", bas, 9)[0]
        hdrOff = struct.unpack_from("<q", bas, 13)[0]
        f.seek(hdrOff)
        h = f.read(20)
        n = struct.unpack_from("<I", h, 0)[0]
        tocPos = struct.unpack_from("<Q", h, 4)[0]
        f.seek(tocPos)
        ham = f.read(24 * n)
    if len(ham) != 24 * n:
        raise ValueError("TOC kisa okundu: %s" % yol)
    kay = [struct.unpack_from("<QQII", ham, 24 * i) for i in range(n)]
    return surum, hdrOff, n, tocPos, kay


def giris(yol, off, ln):
    with open(yol, "rb") as f:
        f.seek(off)
        b = f.read(ln)
    if len(b) != ln:
        raise ValueError("giris kisa okundu: %s @%d" % (yol, off))
    return b


def giris_bul(yol, hedef_fid):
    """fid'e gore giris baytlarini dondur, yoksa None.  — kl_lib.giris_bul"""
    _, _, _, _, kay = toc_oku(yol)
    for off, fid, ln, ext in kay:
        if fid == hedef_fid:
            return giris(yol, off, ln), off, ln, ext
    return None, None, None, None


def forgeler(kok):
    """Oyun kokundeki .forge dosyalari (sirali).  — kl_lib.forgeler"""
    return [os.path.join(kok, a) for a in sorted(os.listdir(kok))
            if a.lower().endswith(".forge")]


# ------------------------------------------------------------------ BMS ac (kl_lib)
def bms_ac(b):
    """BMS sarmalini coz (STORED + Oodle). (ic, meta)  — kl_lib.bms_ac"""
    meta = {}
    if len(b) < 16 or b[0:8] != BMS_SIHIR:
        meta["durum"] = "ham"
        return b, meta
    ver, comp = struct.unpack_from("<HB", b, 8)
    bayrak = struct.unpack_from("<I", b, 11)[0]
    meta.update(ver=ver, comp=comp, bayrak=bayrak)
    if not (bayrak & 0x80000000):
        meta["durum"] = "formS"
        return None, meta
    p = 15
    nblok = struct.unpack_from("<I", b, p)[0]; p += 4
    boy = []
    for _ in range(nblok):
        u, c = struct.unpack_from("<II", b, p); p += 8
        boy.append((u, c))
    parca, stored, adler = [], True, []
    for (u, c) in boy:
        adl = struct.unpack_from("<I", b, p)[0]; p += 4
        veri = b[p:p + c]; p += c
        adler.append(zlib.adler32(veri, 0) == adl)
        if u == c:
            parca.append(veri)
        else:
            stored = False
            parca.append(F.oodle_kl(veri, u))
    meta.update(durum="stored" if stored else "oodle", nblok=nblok, boy=boy,
                adler=adler, kuyruk=len(b) - p)
    return b"".join(parca), meta


# ------------------------------------------------------------------ 0x010 (kl_lib + kl_uret)
KANONIK = [0x007, 0x004, 0x005, 0x003, 0x002, 0x00A, 0x00B, 0x00C, 0x00D,
           0x00E, 0x00F, 0x3E7, 0x021, 0x028, 0x006, 0x008, 0x018, 0x01F,
           0x023, 0x025, 0x026, 0x027, 0x02A]


def s010_coz(d):
    """Ham 0x010 -> {anahtar: (tip, deger/None, yuk/None, ofset)}; sira listesi de doner."""
    surum = struct.unpack_from("<I", d, 0)[0]
    p, alan, sira = 4, {}, []
    while p + 8 <= len(d) - 4:
        k, t = struct.unpack_from("<II", d, p)
        q = p + 8
        if t == 0:
            v = struct.unpack_from("<I", d, q)[0]
            alan[k] = (t, v, None, q)
            q += 4
        elif t in (1, 2, 6):
            ln = struct.unpack_from("<I", d, q)[0]; q += 4
            yuk = d[q:q + ln]; q += ln
            if t == 1:
                assert d[q] == 0, "type-1 NUL not found @%d" % q
                q += 1
            alan[k] = (t, ln, yuk, q)
        else:
            raise ValueError("bilinmeyen tip %d @%d k=0x%X" % (t, p, k))
        sira.append(k)
        p = q
    assert p == len(d) - 4, "kayitlar kuyruga oturmadi p=%d len=%d" % (p, len(d))
    kuyruk = struct.unpack_from("<I", d, p)[0]
    return surum, alan, sira, kuyruk


def s010_ozet(d):
    surum, alan, sira, kuyruk = s010_coz(d)
    def v(k): return alan[k][1]
    n_sinif = len(alan[0x021][2]) // 16
    return dict(
        surum=surum, kuyruk=kuyruk, kanonik=(sira == KANONIK),
        derleme=(v(0x002), v(0x00C), v(0x00D)),
        temel=(v(0x025), v(0x026), v(0x027)),
        yansima=v(0x02A), yama=v(0x008),
        paket=alan[0x006][2].decode("latin-1"),
        guid=alan[0x028][2].hex(),
        n_sinif=n_sinif,
        sha021=sha(alan[0x021][2]), sha023=sha(alan[0x023][2]),
        ofs002=alan[0x002][3], ofs00C=alan[0x00C][3], ofs00D=alan[0x00D][3],
        ofs02A=alan[0x02A][3], ofs025=alan[0x025][3],
        boy=len(d), sha=sha(d),
    )


def s010_kodla(surum, kayitlar, kuyruk):
    """kayitlar: [(anahtar, tip, deger|None, yuk|None)] -> ham bayt  — kl_uret"""
    o = bytearray(struct.pack("<I", surum))
    for k, t, v, y in kayitlar:
        o += struct.pack("<II", k, t)
        if t == 0:
            o += struct.pack("<I", v)
        elif t == 1:
            o += struct.pack("<I", len(y)) + y + b"\x00"
        elif t in (2, 6):
            o += struct.pack("<I", len(y)) + y
        else:
            raise ValueError("tip %d" % t)
    o += struct.pack("<I", kuyruk)
    return bytes(o)


def s010_kayitlari(d):
    """Ham 0x010 -> sirali kayit listesi (kodlayiciya birebir geri verilebilir)."""
    surum = struct.unpack_from("<I", d, 0)[0]
    p, ks = 4, []
    while p + 8 <= len(d) - 4:
        k, t = struct.unpack_from("<II", d, p); q = p + 8
        if t == 0:
            ks.append((k, t, struct.unpack_from("<I", d, q)[0], None)); q += 4
        elif t in (1, 2, 6):
            ln = struct.unpack_from("<I", d, q)[0]; q += 4
            ks.append((k, t, None, d[q:q + ln])); q += ln
            if t == 1:
                assert d[q] == 0; q += 1
        else:
            raise ValueError("tip %d" % t)
        p = q
    return surum, ks, struct.unpack_from("<I", d, p)[0]


def urun_s010(oyun):
    """VANILLA p01'in 0x010'unu COZ -> YENIDEN KODLA (blok kopyasi degil)."""
    ham = giris_bul(p01_yolu(oyun), 0x10)[0]
    surum, ks, kuyruk = s010_kayitlari(ham)
    return s010_kodla(surum, ks, kuyruk), ham


# ------------------------------------------------------------------ 0xFFA (kl_lib + kl_uret)
def ffa_coz(ic):
    """[u16 surum][u32 nAta] + nAta x ([128 B kayit][u32 idSayisi][idSayisi x u64])"""
    surum = struct.unpack_from("<H", ic, 0)[0]
    n = struct.unpack_from("<I", ic, 2)[0]
    p, atalar = 6, []
    for _ in range(n):
        kay = ic[p:p + 128]; p += 128
        nul = kay.find(b"\x00")
        ad = kay[:nul].decode("latin-1")
        m = struct.unpack_from("<I", ic, p); m = m[0]; p += 4
        idofs = p
        idler = list(struct.unpack_from("<%dQ" % m, ic, p)) if m else []
        p += 8 * m
        atalar.append(dict(ad=ad, adLen=nul, m=m, idler=idler, kayit=kay,
                           idofs=idofs, idbayt=ic[idofs:idofs + 8 * m]))
    return dict(surum=surum, n=n, atalar=atalar, artik=len(ic) - p, ic_boy=len(ic))


# vanilla YALNIZCA _patch_01 kullanir — 2026-08-31 olculdu: oyun kokunde
# 82 dosya patch_01, patch_02+ SIFIR. Dolayisiyla _patch_02 ve uzeri her forge
# ucuncu-taraf mod kabidir.
_PATCH_NO = re.compile(r"_patch_(\d+)\.forge$")


def ucuncu_taraf_kap_mi(ad):
    """Dosya adi ucuncu-taraf mod kabi mi? (_patch_02 ve uzeri)

    ESKIDEN yalnizca 'datapc_boot_patch_02.forge' adi dislaniyordu; IKINCI bir
    mod kuran kullanici o modu zorunlu olarak patch_03 adiyla koydugu icin mod
    sablon oyuna siziyor ve "0xFFA" hatasi aliniyordu (QinkyQink, Nexus 197,
    2026-08-31 — ucuncu-taraf kaydin vanilla sablondan 25 baytta farkli oldugu
    olculdu)."""
    m = _PATCH_NO.search(str(ad).lower())
    return bool(m) and int(m.group(1)) >= 2


def sablon_oyla(oyun):
    """128 B ata kaydi sablonunu TUM vanilla 0xFFA kayitlarindan OY COKLUGU ile
    turet. Ad tarafindan ezilen ofsetler o kayit icin oy kullanmaz.
    — kl_uret.sablon_oyla (oyun parametreli)

    Doner: (sablon, kayit_sayisi, celiski, taniksiz, tolere)
      celiski -> SADECE gercek belirsizlik (birinci ile ikinci BERABERE).
                 Cagiran yalniz bunda patlamali.
      tolere  -> anlasmazlik vardi ama cogunluk NET; sablon dogru, bilgi amacli.

    Ucuncu-taraf mod kaplari (_patch_02+) oylamaya KATILMAZ."""
    oy = [dict() for _ in range(128)]
    kayit_sayisi = 0
    for yol in forgeler(oyun):
        if ucuncu_taraf_kap_mi(os.path.basename(yol)):
            continue                      # ucuncu-taraf: sablon oyuna KATILMAZ
        try:
            b = giris_bul(yol, 0xFFA)[0]
        except Exception:
            continue
        if b is None:
            continue
        try:
            ic, _ = bms_ac(b)
            d = ffa_coz(ic)
        except Exception:
            continue
        for a in d["atalar"]:
            kayit_sayisi += 1
            bas = a["adLen"] + 1          # ad + NUL bolgesi oy kullanmaz
            for i in range(bas, 128):
                oy[i][a["kayit"][i]] = oy[i].get(a["kayit"][i], 0) + 1
    sab = bytearray(128)
    celiski, taniksiz, tolere = [], [], []
    for i in range(128):
        if not oy[i]:
            taniksiz.append(i); continue
        sirali = sorted(oy[i].items(), key=lambda kv: -kv[1])
        sab[i] = sirali[0][0]
        if len(sirali) > 1:
            # Cogunluk net ise sablon DOGRU kalir; adi beklenmedik bir mod
            # kabinin (ornegin _patch_ adlandirmasina uymayan) birkac oyu
            # tum uretimi durdurmamali. Yalniz BERABERLIK gercekten belirsiz.
            (tolere if sirali[0][1] > sirali[1][1] else celiski).append((i, oy[i]))
    return bytes(sab), kayit_sayisi, celiski, taniksiz, tolere


def ata_kaydi(ad, sablon):
    if len(ad) > 47:
        raise ValueError("ancestor name too long (%d) - no vanilla precedent" % len(ad))
    k = bytearray(sablon)
    k[0:len(ad)] = ad
    k[len(ad)] = 0
    return bytes(k)


def ffa_ic_uret(atalar, sablon, surum=1):
    """atalar: [(ad_bytes, [id...])] -> ic veri (BMS'siz).  — kl_uret.ffa_ic_uret"""
    o = bytearray(struct.pack("<HI", surum, len(atalar)))
    for ad, idler in atalar:
        if list(idler) != sorted(idler):
            raise ValueError("id list is not in ascending order")
        if len(set(idler)) != len(idler):
            raise ValueError("id list contains duplicates")
        o += ata_kaydi(ad, sablon)
        o += struct.pack("<I", len(idler))
        for i in idler:
            o += struct.pack("<Q", i)
    return bytes(o)


def bms_stored_sar(veri, surum=3, comp=10, bayrak=0x80040000):
    """Form T / tek blok / STORED sarmal. adler32 init=0.  — kl_uret.bms_stored_sar"""
    if len(veri) > 65536:
        raise ValueError("tek blok 65536'yi asamaz: %d" % len(veri))
    o = bytearray(BMS_SIHIR)
    o += struct.pack("<HB", surum, comp)
    o += struct.pack("<I", bayrak)
    o += struct.pack("<I", 1)
    o += struct.pack("<II", len(veri), len(veri))
    o += struct.pack("<I", zlib.adler32(veri, 0))
    o += veri
    return bytes(o)


def vanilla_p01_boot_idleri(oyun):
    """VANILLA patch_01'in 'DataPC_boot.forge' atasi icin beyan ettigi id listesi."""
    b = giris_bul(p01_yolu(oyun), 0xFFA)[0]
    ic, _ = bms_ac(b)
    d = ffa_coz(ic)
    for a in d["atalar"]:
        if a["ad"] == "DataPC_boot.forge":
            return list(a["idler"])
    raise RuntimeError("vanilla p01'de boot atasi yok")


# ------------------------------------------------------------------ 0x0C1 (sistem_ffa_c1)
BLOK = 0x40000


def _adler(b):
    """forge boyunca adler32 init=0 (0x0C1'in sifir adler alani bunu kanitlar)."""
    return zlib.adler32(b, 0) & 0xFFFFFFFF


def bms_stored(veri, algo=10):
    """Vanilla-yerli Form T / STORED BMS konteyneri.  — sistem_ffa_c1.bms_stored"""
    assert len(veri) <= BLOK, "veri tek bloga sigmiyor (%d > %d)" % (len(veri), BLOK)
    return (BMS_SIHIR
            + struct.pack("<HB", 3, algo)
            + struct.pack("<I", 0x80000000 | BLOK)
            + struct.pack("<I", 1)
            + struct.pack("<II", len(veri), len(veri))
            + struct.pack("<I", _adler(veri))
            + veri)


def c1_giris():
    """43 B; diskteki 84 dosyanin hepsiyle birebir (sha b9122e5592be568b...)."""
    return bms_stored(b"\x00" * 12)


# ------------------------------------------------------------------ 0x091 cozucu (s091lib)
MAGIC091 = bytes.fromhex("33aafb5799fa0410")


def coz_091(b):
    """0x091 ust duzey semasi.  — s091lib.coz_091"""
    r = {"boy": len(b), "sha": sha(b)}
    if len(b) < 4:
        r["hata"] = "kisa"
        return r
    n = struct.unpack_from("<I", b, 0)[0]
    r["n"] = n
    if len(b) == 4:
        r["form"] = "bos"
        return r
    r["form"] = "dolu"
    r["u32ler"] = list(struct.unpack_from("<4I", b, 0))
    kuyruk_off = len(b) - 16 * n
    r["kuyruk_off"] = kuyruk_off
    r["govde"] = b[4:kuyruk_off]
    kay = []
    for i in range(n):
        o = kuyruk_off + 16 * i
        fid, a, c = struct.unpack_from("<QII", b, o)
        kay.append({"fid": fid, "a": a, "c": c, "ham": b[o:o + 16]})
    r["kayitlar"] = kay
    return r


def coz_konteynerler(b, kuy):
    """0x091 govdesinden acik yuk baytlarini uret. (yuk, bilgi).  — s091lib"""
    o, yuk, bilgi = 8, bytearray(), []
    while o + 8 <= kuy:
        kL, aL = struct.unpack_from("<II", b, o)
        if b[o + 8:o + 16] != MAGIC091:
            bilgi.append(("MAGIC_YOK", o)); break
        bayrak = b[o + 23]
        if bayrak == 0x00:
            sik = struct.unpack_from("<I", b, o + 24)[0]
            yuk += b[o + 28:o + 28 + sik]
            son = o + 28 + sik
        else:
            sik, acik, adler = struct.unpack_from("<III", b, o + 24)
            d = F.oodle_yf(b[o + 36:o + 36 + sik], acik)
            if d is None:
                return None, [("OODLE_BASARISIZ", o)]
            yuk += d
            son = o + 36 + sik
        bilgi.append((("STORED" if bayrak == 0 else "OODLE"), o, kL, aL))
        o = son
    return bytes(yuk), bilgi


# ------------------------------------------------------------------ 0x091 uretici (s091_uret)
BMS16_STORED = bytes.fromhex("33aafb5799fa041003000a0000040000")
MAX_ACIK = 65536


def grup_uret(fidler, t=0):
    """Tek bir bagimlilik grubunun baytlari: [u16 t][u16 k][k x u64]."""
    return struct.pack("<HH", t, len(fidler)) + b"".join(struct.pack("<Q", f) for f in fidler)


def yuk_uret(kayitlar):
    """kayitlar: [(fid, deps)] ya da (fid, deps, t). ILK-GORULEN dedup."""
    yuk = bytearray()
    harita = {}
    cikti = []
    for kayit in kayitlar:
        fid, deps = kayit[0], kayit[1]
        t = kayit[2] if len(kayit) > 2 else 0
        blob = grup_uret(deps, t)
        if blob in harita:
            off = harita[blob]
        else:
            off = len(yuk)
            harita[blob] = off
            yuk += blob
        cikti.append((fid, len(blob), off))
    return bytes(yuk), cikti


def konteyner_uret_stored(parca):
    aL = len(parca)
    return struct.pack("<II", 24 + aL, aL) + BMS16_STORED + struct.pack("<I", aL) + parca


def uret_091(kayitlar):
    """Tam 0x091 girisi. kayitlar = [(fid, deps[, t])] kayit sirasinda.  — s091_uret.uret"""
    yuk, kay = yuk_uret(kayitlar)
    parcalar = [yuk[i:i + MAX_ACIK] for i in range(0, len(yuk), MAX_ACIK)] or [b""]
    if yuk == b"":
        parcalar = []
    govde = b"".join(konteyner_uret_stored(p) for p in parcalar)
    b = struct.pack("<II", len(kay), len(parcalar)) + govde
    for fid, ln, off in kay:
        b += struct.pack("<QII", fid, ln, off)
    return b


# ------------------------------------------------------------------ 0xFF8 (bf_ff8_patch01)
S091_FID = 0x091
FF8_FID = 0xFF8
SABLON_BOY = 128


def giris_oku(forge_yolu, fid):
    """Bir forge'un tek sistem girisini HAM dondur.  — bf_ff8_patch01.giris_oku"""
    if not os.path.exists(forge_yolu):
        raise FileNotFoundError(forge_yolu)
    for off, f2, ln, ext in toc_oku(forge_yolu)[4]:
        if f2 == fid:
            with open(forge_yolu, "rb") as f:
                f.seek(off)
                v = f.read(ln)
            if len(v) != ln:
                raise IOError("short read %s fid=0x%X" % (forge_yolu, fid))
            return v
    return None


def ff8_sablon(ad):
    """128 B ata sablonu: forge adi ASCII @0, kalani 0x00.  — bf_ff8_patch01.sablon"""
    b = ad.encode("ascii")
    if len(b) >= SABLON_BOY:
        raise ValueError("name too long: %r" % ad)
    return b + b"\x00" * (SABLON_BOY - len(b))


def s091_coz(h):
    """0x091 (veya FF8 blogunun 128. bayttan sonrasi) -> dict.  — bf_ff8_patch01.s091_coz"""
    N, npar = struct.unpack_from("<II", h, 0)
    p = 8
    par = []
    for _ in range(npar):
        A, ulen = struct.unpack_from("<II", h, p)
        par.append(dict(A=A, ulen=ulen, off=p + 8, kon=h[p + 8:p + 4 + A]))
        p = p + 4 + A
    kay = [struct.unpack_from("<QII", h, p + i * 16) for i in range(N)]
    return dict(N=N, npar=npar, parcalar=par, kayitlar=kay,
                kayit_off=p, artik=len(h) - p - 16 * N)


def ff8_bloklari(ham):
    """0xFF8 ham -> [(ad, N, hamBlokBaytlari)].  Oodle GEREKMEZ."""
    ver, nata = struct.unpack_from("<HI", ham, 0)
    p, out = 6, []
    for _ in range(nata):
        b = p
        ad = ham[b:b + 67].split(b"\x00")[0].decode("latin1")
        d = s091_coz(ham[b + SABLON_BOY:])
        p = b + SABLON_BOY + d["kayit_off"] + 16 * d["N"]
        out.append((ad, d["N"], ham[b:p]))
    return ver, nata, out


def ata_blogu(ad, s091_baytlari, dusurulecek_idler=()):
    """MODEL: ata blogu = 128 B sablon + o atanin 0x091 girisi."""
    if dusurulecek_idler:
        raise NotImplementedError(
            "kayit dusurme yeniden sikistirma gerektirir; bizim yamamizda gerekmiyor")
    return ff8_sablon(ad) + s091_baytlari


def blowpipe_ff8(oyun):
    """boot_patch_02 icin TAM 0xFF8 girisi uret. Diskten TAZE okur."""
    p01 = p01_yolu(oyun)
    s091 = giris_oku(p01, S091_FID)
    ff8 = giris_oku(p01, FF8_FID)
    if s091 is None or ff8 is None:
        raise RuntimeError("vanilla patch_01'de 0x091/0xFF8 bulunamadi")
    # patch_01'in kendi 0xFF8'i tek atalidir: [6 B baslik][128 B sablon][boot'un
    # filtrelenmis 0x091'i].  Biz o govdeyi AYNEN devraliriz.
    ver, nata = struct.unpack_from("<HI", ff8, 0)
    if nata != 1:
        raise RuntimeError("vanilla patch_01 0xFF8 nata=%d (1 bekleniyordu)" % nata)
    boot_govde = ff8[6 + SABLON_BOY:]
    b0 = ata_blogu(P01_AD, s091)          # en yakin ata ONCE
    b1 = ata_blogu(BOOT_AD, boot_govde)
    return struct.pack("<HI", 1, 2) + b0 + b1, b0, b1, s091, boot_govde
