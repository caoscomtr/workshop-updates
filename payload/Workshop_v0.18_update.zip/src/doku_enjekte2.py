# -*- coding: utf-8 -*-
"""SLOT-BILINCLI DOKU ENJEKTORU (doku_enjekte.py'nin slot farkindali halefi).

doku_enjekte.py materyalin SADECE ILK TextureMap'ini (slot0 = diffuse) yaziyordu.
Bu arac dosya adindan SLOT INDEKSINI de okur ve materyaldeki N. TextureMap'i hedefler,
boylece MASKE (slot1) ve NORMAL (slot3) haritalari da degistirilebilir.

================================ DESTEKLENEN DOSYA ADLARI ================================
Girdi HER ZAMAN .dds olmali (kodlanmis BCn). Uc adlandirma taninir:

  (A) DISA AKTARMA FORMATI  -- oncelikli
      IC_<matID>_tm<texID>_<SLOT>_<WxH>_<WxH>_<FMT>.dds
      ornek: IC_22D90B0A877_tm22D90B0A877_3_2048x2048_2048x2048_BC7.dds
      matID  : basindaki hex (0x YOK)
      SLOT   : ucuncu alan, ondalik tamsayi
      NOT: `tm<texID>` alanina GUVENILMEZ -- disa aktarici oraya materyal id'sini
           yaziyor (OLCULDU: tum dosyalarda tm<id> == mat<id>). Arac bu alani
           YOK SAYAR ve gercek doku id'sini materyalden kendisi cozer.

  (B) 0x + ACIK SLOT ETIKETI
      ... 0x<matID> ... (_s<N> | _slot<N> | _S<N>) ... .dds       (buyuk/kucuk harf farketmez)
      ornek: kapuson_0x22D90B0A877_s3.dds
             hood_0x22D90B0A877_slot1_mask.dds

  (C) 0x + SLOT ETIKETI YOK  -> slot 0 varsayilir (eski doku_enjekte.py davranisi)
      ornek: 01_HOOD_0x22D90B0A877_2048x2048_BC1_sRGB.dds

=================================== KAPILAR (GATES) ===================================
Asagidakilerden BIRI bile tutmazsa dosya REDDEDILIR, forge'a yazilmaz:
  1. slot indeksi materyaldeki TextureMap sayisindan kucuk olmali
  2. DDS W,H == forge tanimlayicisindaki W,H
  3. DDS DXGI formati == slotun format ailesi (BC1/BC3/BC7) VE sRGB bayragi ayni
     (sadece uzunluk bakmak yetmez: BC3 ve BC7 ayni blok boyutuna sahip!)
  4. UZUNLUK KAPISI: forge'da bulunan HER harici mip icin
     forge_mip_uzunlugu == dds_mip_uzunlugu  (birebir, tolerans yok)
  5. DDS mip zinciri harici mip sayisini karsilamali

================================= GOMULU MIP KUYRUGU =================================
OLCULDU (bkz. rapor): incelenen 6 kiyafet materyalinin HER SLOTUNDA gomulu piksel blogu
var (2048'lik slotlarda 25.600 B, 256/2048-BC1 slotlarinda 50.176 B). Yani slot0 disindaki
slotlar icin de gomulu kuyruk yamalanmak ZORUNDA -- yoksa uzaktan/egik acida orijinal
doku sizar. Bu arac gomulu kuyrugu da yamalar (inline_mip_yama.py yontemi, slot-genel hale
getirilmis): materyal yeniden paketlenip forge SONUNA eklenir, TOC yonlendirilir.
`--sadece-harici` ile kapatilabilir (o zaman UYARI basar).

===================================== KULLANIM =====================================
  doku_enjekte2.py durum  <dds_klasoru>          # forge'a DOKUNMAZ, plani basar
  doku_enjekte2.py uygula <dds_klasoru> [--sadece-harici]
  doku_enjekte2.py gerial

Kayit dosyasi doku_enjekte2_kayit.json -- doku_enjekte.py'nin kaydindan AYRI.
"""
import os, sys, re, glob, json, struct, ctypes, hashlib, tempfile, shutil, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import yalin_forge
from yalin_forge import LeanForge, decompress, read_block

GAME  = r"C:\Program Files (x86)\Steam\steamapps\common\Assassin's Creed Black Flag Resynced"
FORGE = os.path.join(GAME, "DataPC_boot.forge")
K     = os.path.dirname(os.path.abspath(__file__))
KAYIT_ESKI   = os.path.join(K, "doku_enjekte_kayit.json")
KAYIT_INLINE = os.path.join(K, "inline_mip_kayit.json")

# --- geri-alma verisi NEREDE durur --------------------------------------------
# Eskiden kayit ve yedekler modulun YANINDA (kurulum klasorunde) duruyordu. Yeni
# surumu baska bir klasore acan kullanicinin forge'u yamali kaliyor ama kaydi
# eski klasorde oksuz kaliyordu: "geri alacak bir sey yok" denip ustune yeniden
# yaziliyor ve YAMALI baytlar "vanilla" diye kaydediliyordu. Artik veri kullanici
# profilinde, FORGE KIMLIGINE gore anahtarli duruyor: kurulum tasinsa, silinse,
# uzerine yeni surum acilsa da ayni forge'un geri donusu bulunur.
VERI_KOK = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
                        "ACBFR_Modding")


def _forge_anahtari(forge):
    return hashlib.sha256(os.path.normcase(os.path.abspath(forge)).encode("utf-8")
                          ).hexdigest()[:12]


_YAZIYOR = [False]        # uygula/gerial forge'u acikken True


def yaziyor_mu():
    """Su an forge'a yazan bir islem var mi? GUI dugmeleri disaridan kapatiyor
    ama tek savunma o olmamali: `set_game` bunu gorup reddediyor."""
    return _YAZIYOR[0]


# Kimligi DOGRULANAMAYAN bir geri-alma kaydi goruldugunde sebebi burada durur.
# `_uygula` bunu okur: "kayit yok" ile "kaydi bulamadim/emin olamadim" AYNI SEY
# DEGILDIR. Ikisini ayirt etmemek, tur-3'te olculen arsiv-bozma yoluydu.
_KIMLIK_SUPHESI = [None]


def _kayit_bu_arsivi_mi(kayit, forge):
    """Bu kayit SU ANKI arsivi mi tarif ediyor? YOLA degil BAYTLARA bakar.

    Yol tabanli kimlik ("ad ayni + eski yol artik yok") hep tahminti; uzerine
    konan her yeni 'emin olamiyorum' dali `None` donuyor ve cagiran taraf bunu
    "kayit YOK" saniyordu -- yani forge'daki YAMALI baytlar vanilla diye
    kaydediliyordu (geri donusun kalici kaybi). Oysa kayit NE YAZDIGINI zaten
    sakliyor: harici mip'ler icin `sha_yeni`, gomulu materyaller icin
    `yeni_off/yeni_len`. Arsivde o baytlar duruyorsa kimlik TAHMIN degil OLCUM.

    Doner: True  (bu arsiv bu kaydin yamasini tasiyor)
           False (baska arsiv, ya da bu arsiv zaten vanilla)
           None  (soylenemedi: v1/bos kayit, okunamayan arsiv)"""
    try:
        boyut = os.path.getsize(forge)
    except OSError:
        return None
    harici = [h for h in kayit.get("harici", []) if h.get("sha_yeni")][:8]
    gomulu = [g for g in kayit.get("gomulu", []) if "yeni_off" in g][:4]
    if not harici and not gomulu:
        return None                       # soyleyecek bir seyi yok
    try:
        with open(forge, "rb") as f:
            for h in harici:
                off, ln = h.get("off"), h.get("len")
                if off is None or ln is None or off + ln > boyut:
                    continue
                f.seek(off)
                if _sha(f.read(ln), len(h["sha_yeni"])) == h["sha_yeni"]:
                    return True           # BIZIM yazdigimiz baytlar hala orada
            for g in gomulu:
                tp = g.get("tocPos")
                if tp is None or tp + 24 > boyut:
                    continue
                f.seek(tp); satir = f.read(24)
                if struct.unpack_from("<Q", satir, 8)[0] != int(g["mat"], 16):
                    continue
                if (struct.unpack_from("<Q", satir, 0)[0],
                        struct.unpack_from("<I", satir, 16)[0]) == (g["yeni_off"], g["yeni_len"]):
                    return True           # TOC hala bizim ekledigimiz bloga bakiyor
    except OSError:
        return None
    return False


def _kimlikten_bul(forge):
    """Anahtar tutmadiginda: depodaki TUM kayitlari tara, BU arsivi tarif edeni bul.

    Depo forge YOLUNA gore anahtarli. Steam'in "oyunu tasi"si, surucu harfi
    degisimi ya da klasor yeniden adlandirmasi anahtari degistiriyor ve kayit +
    yedekler BIRLIKTE oksuz kaliyordu: Revert pasif, sonraki apply yamali baytlari
    vanilla saniyor.

    Doner: (dizin | None, suphe_sebebi | None). ⭐ Iki ayri "None" vardir ve
    KARISTIRILMAMALIDIR: (None, None) = ortada kayit yok, arsiv gercekten temiz;
    (None, sebep) = bir kayit VAR ama kime ait oldugu dogrulanamadi -> cagiran
    taraf yazmayi REDDETMELI."""
    ad = os.path.basename(os.path.abspath(forge))
    try:
        forge_boyut = os.path.getsize(forge)
    except OSError:
        forge_boyut = None
    eslesen, supheli, zararsiz = [], [], []
    for kj in glob.glob(os.path.join(VERI_KOK, "*", "doku_enjekte2_kayit.json")):
        try:
            with open(kj, encoding="utf-8") as f:
                k = json.load(f)
        except Exception:
            continue
        kf = k.get("forge")
        if not kf or os.path.basename(kf).lower() != ad.lower():
            continue
        dizin = os.path.dirname(kj)
        bizim = _kayit_bu_arsivi_mi(k, forge)
        # ⚠️ AD YETMEZ: her kurulumun arsivi "DataPC_boot.forge" adini tasir.
        # Kaydin isaret ettigi yol HALA VARSA o kayit YASAYAN baska bir kuruluma
        # aittir, tasima. Ama baytlar buradaki arsivde de duruyorsa, bu arsiv o
        # kurulumun YAMALI bir kopyasidir; "vanilla" sayip ustune yazmak
        # vanilla'nin son kopyasini yok eder -> supheye yaz, yazmayi durdur.
        if os.path.exists(kf):
            if bizim is True:
                supheli.append("%s  (kayit YASAYAN kuruluma ait: %s)" % (dizin, kf))
            continue
        if bizim is True:
            eslesen.append(dizin)
        elif (not k.get("harici") and not k.get("gomulu")
              and (k.get("durum") != "in_progress"
                   or (forge_boyut is not None
                       and k.get("forge_boyut") == forge_boyut))):
            # Kayit HICBIR yazim tarif etmiyor. WAL geregi yazilan her harici mip
            # forge'a dokunulmadan ONCE kaydedilir; gomulu faz da (arsivin sonuna
            # blok ekledigi icin) BOYUTU degistirir. Ikisi de yoksa ortada
            # korunacak vanilla yoktur -> tasimak zararsiz, eski davranis korunur.
            zararsiz.append(dizin)
        elif bizim is None and glob.glob(os.path.join(dizin, "doku_enjekte2_yedek*",
                                                      "RAW_*.bin")):
            # Kimligini olcemedik AMA vanilla yedekleri duruyor: korumaya deger.
            supheli.append("%s  (kimligi olculemedi, vanilla yedekleri duruyor)" % dizin)
    if len(eslesen) == 1:
        return eslesen[0], None
    if len(eslesen) > 1:
        return None, ("%d ayri geri-alma kaydi BU arsivi tarif ediyor:\n         %s"
                      % (len(eslesen), "\n         ".join(eslesen)))
    if supheli:
        return None, ("kimligi dogrulanamayan geri-alma kaydi:\n         %s"
                      % "\n         ".join(supheli))
    # Hicbiri bu arsivi tarif etmiyor: yazim tarif etmeyen TEK kayit varsa onu
    # tasi (kullanicinin gecmisi oyunla birlikte gelsin), yoksa dokunma.
    return (zararsiz[0] if len(zararsiz) == 1 else None), None


def _kimlik_damgala():
    """Benimsenen kaydin "hangi forge" alanini GUNCEL arsive gore yenile.

    Kaydi bulmak/tasimak YETMIYOR: `kayit["forge"]` eski yolu gosterdigi surece
    `_uygula` da `_gerial_dogrula` da "BASKA bir kuruluma ait" deyip HEM apply'i
    HEM revert'i reddediyor -- yani kullanici tasimadan sonra iki kapida da kaliyor.
    Kaydi zaten BAYT KIMLIGIYLE dogruladik (`_kayit_bu_arsivi_mi`), damgalamak
    guvenli. Tasima yarim kalip kayit eski klasorde kalsa da cagrilir; onemli olan
    kaydin NEREDE durdugu degil, KIMI tarif ettigi."""
    try:
        with open(KAYIT, encoding="utf-8") as f:
            _k = json.load(f)
        _k["forge"] = os.path.abspath(FORGE)
        # BOYUTU TAZELEME: `forge_boyut` apply ANINDAKI boyuttur ve `_yarim_kalmis`
        # "hicbir sey yazilmadi"yi ona dayandirir. Tasima boyutu degistirmez; guncel
        # degeri yazmak YAMALI bir arsivi "dokunulmamis" gosterebilirdi.
        _k.setdefault("forge_boyut", os.path.getsize(FORGE))
        _kayit_yaz(_k, KAYIT)
    except Exception as e:                                      # noqa: BLE001
        print("UYARI: tasinan kaydin forge kimligi guncellenemedi (%s); "
              "apply/revert bu kaydi reddedebilir." % e)


def veri_yolu_ayarla(tasi=True):
    """KAYIT/YEDEK yollarini GUNCEL FORGE'a gore hesaplar. FORGE degistiginde
    (set_game) yeniden cagrilmali. `tasi=False` ise gecis/benimseme yapilmaz --
    import aninda FORGE hala VARSAYILAN yol oldugu icin oyle cagrilir."""
    global KAYIT, YEDEK, VERI_DIZIN
    VERI_DIZIN = os.path.join(VERI_KOK, _forge_anahtari(FORGE))
    KAYIT = os.path.join(VERI_DIZIN, "doku_enjekte2_kayit.json")
    YEDEK = os.path.join(VERI_DIZIN, "doku_enjekte2_yedek")
    _KIMLIK_SUPHESI[0] = None

    if not tasi:
        return KAYIT

    # Anahtar tutmuyor ama depoda bu arsive ait bir kayit olabilir (oyun tasindi).
    if not os.path.exists(KAYIT) and os.path.isfile(FORGE):
        baska, suphe = _kimlikten_bul(FORGE)
        if suphe:
            _KIMLIK_SUPHESI[0] = suphe
            print("UYARI: " + suphe)
        if baska and os.path.normcase(baska) != os.path.normcase(VERI_DIZIN):
            try:
                os.makedirs(VERI_DIZIN, exist_ok=True)
                # ⭐ KAYIT DOSYASI EN SONA: once yedekler tasinir. Yarim kalirsa
                # kayit hala ESKI klasorde olur ve fallback onu bulur. Ters sirada
                # (kayit once) bir kilit yuzunden yedek takilinca kayit yeni,
                # yedekler eski klasorde kaliyor; fallback eski klasore donunce
                # `os.path.exists(KAYIT)` False oluyor ve arsiv "vanilla" sanilip
                # YAMALI baytlar orijinal diye kaydediliyordu (olculdu).
                for oge in sorted(os.listdir(baska),
                                  key=lambda a: a.lower() == "doku_enjekte2_kayit.json"):
                    src = os.path.join(baska, oge)
                    dst = os.path.join(VERI_DIZIN, oge)
                    if os.path.exists(dst):
                        # `shutil.move` var olan bir KLASORUN icine gomer
                        # (yedek/yedek) ve okuyan hicbir yer orayi bulamaz.
                        # Buradaki yerel veri oksuz: kenara al, benimsenen kayit
                        # kendi yedekleriyle es kalsin.
                        os.rename(dst, dst + ".oksuz_" + time.strftime("%Y%m%d_%H%M%S"))
                    shutil.move(src, dst)
                os.rmdir(baska)
                _kimlik_damgala()
                print("NOT: oyun tasinmis gorunuyor; geri-alma verisi kimliginden bulunup\n"
                      "     %s -> %s altina alindi." % (baska, VERI_DIZIN))
            except OSError as e:
                # TASIMA YARIM KALDI. Kor kor eski klasore donmek yanlis: kayit
                # ONCE tasinmis olabilirdi (artik en sona aliyoruz ama AV/kilit her
                # an araya girebilir). Kayit HANGI klasordeyse ORAYI kullan; hicbir
                # yerde bulamazsak "kayit yok" DEME -- supheye yaz, yazma dursun.
                yeni_k = os.path.join(VERI_DIZIN, "doku_enjekte2_kayit.json")
                eski_k = os.path.join(baska, "doku_enjekte2_kayit.json")
                if os.path.isfile(eski_k):
                    print("UYARI: geri-alma verisi tasinamadi (%s); eski yeri kullaniliyor: %s"
                          % (e, baska))
                    KAYIT, VERI_DIZIN = eski_k, baska
                    YEDEK = os.path.join(baska, "doku_enjekte2_yedek")
                    # Tasiyamadik ama kaydi BAYT KIMLIGIYLE dogruladik: kimligi
                    # damgalamazsak apply de revert de "baska kuruluma ait" der ve
                    # kullanici IKI KAPIDA birden kalir (tur-2'de olculen kilit).
                    _kimlik_damgala()
                    return KAYIT
                if os.path.isfile(yeni_k):
                    _KIMLIK_SUPHESI[0] = (
                        "geri-alma verisi tasinirken hata (%s); kayit yeni yerde ama "
                        "yedeklerin bir kismi hala burada olabilir:\n         %s" % (e, baska))
                    print("UYARI: " + _KIMLIK_SUPHESI[0])
                    return KAYIT
                _KIMLIK_SUPHESI[0] = (
                    "geri-alma verisi tasinirken hata (%s) ve kayit HICBIR klasorde "
                    "bulunamadi; vanilla yedekleri burada olabilir:\n         %s" % (e, baska))
                print("UYARI: " + _KIMLIK_SUPHESI[0])
                return KAYIT

    eski_kayit = os.path.join(K, "doku_enjekte2_kayit.json")
    eski_yedek = os.path.join(K, "doku_enjekte2_yedek")
    if not os.path.exists(KAYIT) and os.path.exists(eski_kayit):
        try:
            os.makedirs(VERI_DIZIN, exist_ok=True)
            if os.path.isdir(eski_yedek) and not os.path.isdir(YEDEK):
                shutil.move(eski_yedek, YEDEK)
            shutil.move(eski_kayit, KAYIT)
            print("NOT: geri-alma kaydi kurulum klasorunden %s altina tasindi "
                  "(kurulum tasinsa/silinse bile geri alinabilsin diye)." % VERI_DIZIN)
        except OSError as e:
            print("UYARI: eski kayit tasinamadi (%s); eski yerinde kullaniliyor." % e)
            KAYIT, YEDEK = eski_kayit, eski_yedek
    return KAYIT


def _yedek_dizin(kayit=None):
    """Bu KAYDIN yedeklerinin gercekten durdugu klasor.

    `_uygula` yedek klasorunu YEREL bir degiskende tutuyor ve eski klasor
    kilitliyse (AV taramasi / Explorer onizlemesi) `.yeni_<ts>` altina yaziyor --
    ama `gerial` uc yerde modul-global YEDEK'i okuyordu. Olculen sonuc: apply
    "basarili" der, revert "yedek dosyasi yok" deyip reddeder, ikinci apply
    "vanilla yedegi kayip" deyip kilitlenir; vanilla'ya donus kalmaz.
    Artik klasorun ADI kayitta durur, okuyan taraf yolu kayittan cozer.
    Anahtari olmayan ESKI kayitlar global YEDEK'e duser (geri uyum)."""
    ad = (kayit or {}).get("yedek_dir")
    if not ad:
        return YEDEK
    # Kayitta ADI durur, mutlak yolu DEGIL: kayit A3 ile baska bir veri
    # klasorune tasindiginda yol degisir, ad degismez.
    return os.path.join(os.path.dirname(KAYIT), os.path.basename(ad))


VERI_DIZIN = None
# Import aninda FORGE hala VARSAYILAN Steam yolu: gercek kurulum baska yerdeyse
# eski kaydi burada tasimak onu YANLIS anahtara filelerdi ve set_game sonrasi
# hicbir yerde bulunamazdi. Yollari hesapla, ama tasima/benimseme YAPMA;
# outfit_core.set_game() zaten tam yolu ogrenince yeniden cagiriyor.
veri_yolu_ayarla(tasi=False)

# --- kayit bicimi -------------------------------------------------------------
# 1 = eski: sadece off/len/tocPos, hangi forge'a ait oldugu YAZMIYOR.
# 2 = journal: ilk bayttan ONCE yazilir, forge kimligi + ham TOC satiri +
#     yazdigimiz baytlarin sha'si da durur, boylece 'gerial' tek bayt yazmadan
#     her seyi dogrulayabilir. Eski kayitlar OKUNMAYA DEVAM EDER (geri uyum).
KAYIT_SURUM = 2


def _kayit_yaz(kayit, yol=None):
    """Kaydi ATOMIK yaz (tempfile -> fsync -> os.replace).

    Duz json.dump kesilirse yarim/bozuk kayit kalir ve o kayit forge'un tek geri
    donus yolu. Burada ya eski dosya ya yeni dosya vardir, arasi yoktur."""
    yol = yol or KAYIT
    fd, gecici = tempfile.mkstemp(dir=os.path.dirname(yol) or ".",
                                  prefix=".kayit_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(kayit, f, indent=1)
            f.flush(); os.fsync(f.fileno())
        os.replace(gecici, yol)
    except BaseException:
        try: os.remove(gecici)
        except OSError: pass
        raise


def _forge_kimlik():
    """Kaydin HANGI forge'a ait oldugunu yazar. Bu olmadan 'gerial' baska bir
    kuruluma kor seek yapip alakasiz TOC satirlarini bozabiliyordu."""
    return {"forge": os.path.abspath(FORGE), "forge_boyut": os.path.getsize(FORGE)}


def _sha(b, n=16):
    return hashlib.sha256(b).hexdigest()[:n]

TM_HASH = 0xA2B7E917
# DLL yolu yalin_forge'un goreli arayicisindan gelir -- makineye ozel mutlak yol YOK.
OODLE_DLL = yalin_forge.oodle_dll_yolu()

# --- DDS/DXGI tablosu: dxgi -> (blok_bayt, srgb, aile) ---
DXGI = {
    71: (8, 0, "BC1"), 72: (8, 1, "BC1"),
    74: (16, 0, "BC2"), 75: (16, 1, "BC2"),
    77: (16, 0, "BC3"), 78: (16, 1, "BC3"),
    80: (8, 0, "BC4"), 83: (16, 0, "BC5"),
    95: (16, 0, "BC6H"),
    98: (16, 0, "BC7"), 99: (16, 1, "BC7"),
}
DXGI_AD = {71: "BC1", 72: "BC1_sRGB", 74: "BC2", 75: "BC2_sRGB", 77: "BC3", 78: "BC3_sRGB",
           80: "BC4", 83: "BC5", 95: "BC6H", 98: "BC7", 99: "BC7_sRGB"}

# --- TextureMap tanimlayicisindaki format enum'u (19/19 slotta OLCULEREK dogrulandi) ---
#     +14 W(u32) +18 H(u32) +30 fmt_enum(u32) +38 srgb(u32) +42 mipcount(u32)
ENUM_AILE = {0x02: "BC1", 0x03: "BC1", 0x05: "BC3", 0x0A: "BC7"}
AILE_BLOK = {"BC1": 8, "BC2": 16, "BC3": 16, "BC4": 8, "BC5": 16, "BC6H": 16, "BC7": 16}

_OODLE_C = {}


def _oodle_comp():
    """Sikistirma fonksiyonunu ILK KULLANIMDA yukler (import aninda DEGIL).

    Import aninda ctypes.CDLL cagirmak, DLL yoksa/AV karantinaya aldiysa bu modulu
    import eden GUI'yi pencere acilmadan sessizce olduruyordu."""
    if "fn" not in _OODLE_C:
        yol = yalin_forge.oodle_dll_yolu()
        if not yol:
            raise RuntimeError(yalin_forge.OODLE_YOK)
        lib = ctypes.CDLL(yol)
        fn = lib.OodleLZ_Compress
        fn.restype = ctypes.c_int
        fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p,
                       ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, ctypes.c_size_t]
        _OODLE_C["lib"] = lib
        _OODLE_C["fn"] = fn
    return _OODLE_C["fn"]


def oodle_sik(v, codec=9, sev=6):
    out = ctypes.create_string_buffer(len(v) + 65536)
    n = _oodle_comp()(codec, v, len(v), out, sev, None, None, None, None, 0)
    assert n > 0, "Oodle sikistirma basarisiz"
    return out.raw[:n]


def lzo_adler32(a2):
    num = num2 = i = 0; n = len(a2)
    while n:
        n5 = min(n, 5552); n -= n5
        while n5 >= 16:
            for k in range(16):
                num = (num + a2[i + k]) & 0xffffffff; num2 = (num2 + num) & 0xffffffff
            i += 16; n5 -= 16
        while n5:
            num = (num + a2[i]) & 0xffffffff; num2 = (num2 + num) & 0xffffffff; i += 1; n5 -= 1
        num %= 65521; num2 %= 65521
    return (num | (num2 << 16)) & 0xffffffff


def align(x, a=256): return ((x + a - 1) // a) * a


# ------------------------------------------------------------------ dosya adi cozumleme
RE_IC   = re.compile(r"^IC_([0-9A-Fa-f]{9,13})_tm([0-9A-Fa-f]{9,13})_(\d+)_", re.I)
RE_0X   = re.compile(r"0x([0-9A-Fa-f]{9,13})")
RE_SLOT = re.compile(r"(?:^|[_\-.])s(?:lot)?(\d+)(?:[_\-.]|$)", re.I)


def ad_coz(ad):
    """dosya adi -> (mat_id, slot, bicim_adi) ya da (None, None, sebep)"""
    m = RE_IC.match(ad)
    if m:
        return int(m.group(1), 16), int(m.group(3)), "A(IC_export)"
    m = RE_0X.search(ad)
    if m:
        mat = int(m.group(1), 16)
        s = RE_SLOT.search(ad)
        if s:
            return mat, int(s.group(1)), "B(0x+slot_etiketi)"
        return mat, 0, "C(0x, slot yok -> 0)"
    return None, None, "materyal id bulunamadi"


# ------------------------------------------------------------------ forge tarafi
def tm_bloklari(res):
    """materyaldeki TextureMap ic dosyalarini SIRAYLA dondurur: [(hdr_off, texture_id), ...]"""
    pat = struct.pack("<I", TM_HASH); out = []
    i = res.find(pat)
    while i >= 0:
        if i >= 9 and i + 5 <= len(res) and res[i + 4] == 0x01:
            g = struct.unpack_from("<Q", res, i - 8)[0]
            if 0x10000000 < g < 0xFFFFFFFFFFFFF:
                out.append((i - 9, g))
        i = res.find(pat, i + 1)
    return sorted(out)


def tanim_oku(res, hdr):
    """TextureMap tanimlayicisi -> dict(W,H,fmt_enum,srgb,mipcount,aile,blok)"""
    W  = struct.unpack_from("<I", res, hdr + 14)[0]
    H  = struct.unpack_from("<I", res, hdr + 18)[0]
    fe = struct.unpack_from("<I", res, hdr + 30)[0]
    sr = struct.unpack_from("<I", res, hdr + 38)[0]
    mc = struct.unpack_from("<I", res, hdr + 42)[0]
    aile = ENUM_AILE.get(fe)
    return {"W": W, "H": H, "fmt_enum": fe, "srgb": sr, "mipcount": mc,
            "aile": aile, "blok": AILE_BLOK.get(aile)}


def cipa_bul(res, bas, son_limit, tolerans=64):
    """gomulu piksel blogunun u32 uzunluk cipasi"""
    ic_len = son_limit - bas
    en_iyi = None
    for q in range(bas, max(bas, min(bas + 4096, son_limit - 4))):
        v = struct.unpack_from("<I", res, q)[0]
        if not (10000 < v < ic_len): continue
        bitis = q + 4 + v
        if bitis <= son_limit and (son_limit - bitis) <= tolerans:
            if en_iyi is None or v > en_iyi[2]:
                en_iyi = (q, q + 4, v)
    return en_iyi


def yerlesim(W, blok, ilk_lvl, uzunluk, Hh=None):
    """gomulu mip yerlesimi: [(lvl, goreli_ofset, pitch, satir, rowbytes)], toplam

    DUZELTME 2026-09-09 (DDS tur donusu): iki kural src/ship/hkm_ortak.yerlesim'den
    (2026-07-29/30 olcumleri) ve src/export3d/doku_png._yerlesim'den (1.207 slotta
    olculdu) BURAYA da tasindi -- ayni depoda iki farkli yerlesim kurali vardi:
      (a) SATIR SAYISI bh'dir, bw degil. Eskiden doku KARE varsayiliyordu; kare
          olmayan dokularda (2048x512 gibi) `n = pitch*bw` havuzdan buyuk cikiyor,
          dongu ILK ADIMDA kiriliyor ve yerlesim BOS donuyordu -> yazici o materyalin
          gomulu mip'lerinin HICBIRINI yazmiyor ama yine de "yazildi" diyordu.
      (b) Her mipin TOPLAMI 512'ye yuvarlanir (`align(pitch*bh, 512)`); 36.501/36.911
          dokuda olculmus kural. Eskiden ham `pitch*bh` kullaniliyordu ve 4x4'ten
          kucuk mip'ler 256/512 B ERKEN yaziliyordu ("768 B bos kuyruk").
    OLCUM (2026-09-09, testler/test_doku_dds.py D8): WhiteRoom 256x256 BC1 ve
    2048x512 BC7 havuzlarinda bu fonksiyon artik doku_png._yerlesim ile SEVIYE SEVIYE
    ayni ve toplami havuz uzunluguna TAM oturuyor.
    `Hh` verilmezse eski KARE varsayimi korunur (geriye donuk uyumlu cagri sekli)."""
    if Hh is None:
        Hh = W
    out = []; off = 0; lvl = ilk_lvl
    w = max(1, W >> ilk_lvl); h = max(1, Hh >> ilk_lvl)
    while w >= 1 and h >= 1:
        bw = max(1, (w + 3) // 4)
        bh = max(1, (h + 3) // 4)
        rowbytes = bw * blok
        pitch = align(rowbytes, 256)
        n = align(pitch * bh, 512)
        if off + n > uzunluk: break
        out.append((lvl, off, pitch, bh, rowbytes))
        off += n
        if w == 1 and h == 1: break
        w = max(1, w // 2); h = max(1, h // 2); lvl += 1
    return out, off


# ------------------------------------------------------------------ DDS
def dds_mipler(p):
    d = open(p, "rb").read()
    if d[:4] != b"DDS ": raise ValueError("not a DDS file")
    H = struct.unpack_from("<I", d, 12)[0]
    W = struct.unpack_from("<I", d, 16)[0]
    fc = d[84:88]
    if fc == b"DX10":
        dxgi = struct.unpack_from("<I", d, 128)[0]; veri = 148
    else:
        dxgi = {b"DXT1": 71, b"DXT3": 74, b"DXT5": 77}.get(fc, 0); veri = 128
    if dxgi not in DXGI: raise ValueError(f"unsupported texture format (DXGI={dxgi})")
    blok = DXGI[dxgi][0]
    out = []; off = veri; w, h = W, H
    while off < len(d):
        n = max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * blok
        if off + n > len(d): break
        out.append({"lvl": len(out), "veri": d[off:off + n], "w": w, "h": h})
        if w == 1 and h == 1: break
        off += n; w = max(1, w // 2); h = max(1, h // 2)
    return out, W, H, dxgi, blok


# ------------------------------------------------------------------ plan
def plan(klasor):
    lf = LeanForge(FORGE)
    isler, red = [], []
    mat_res = {}
    for p in sorted(glob.glob(os.path.join(klasor, "*.dds"))):
        ad = os.path.basename(p)
        mat, slot, bicim = ad_coz(ad)
        if mat is None:
            red.append((ad, bicim)); continue
        if mat not in lf.by_id:
            red.append((ad, f"material 0x{mat:X} is not in this game archive")); continue
        if mat not in mat_res:
            mat_res[mat] = decompress(lf.read_raw(mat))
        res = mat_res[mat]
        tms = tm_bloklari(res)
        if slot >= len(tms):
            red.append((ad, f"there is no slot {slot} here (this material has {len(tms)} textures)")); continue
        hdr, tex = tms[slot]
        t = tanim_oku(res, hdr)
        if t["aile"] is None:
            red.append((ad, f"unknown texture format in the archive (enum 0x{t['fmt_enum']:X})")); continue
        try:
            mipler, W, H, dxgi, blok = dds_mipler(p)
        except ValueError as e:
            red.append((ad, str(e))); continue

        # --- KAPI 2: boyut
        if (W, H) != (t["W"], t["H"]):
            red.append((ad, f"the image is {W}x{H} but this slot needs {t['W']}x{t['H']} - keep the PNG "
                            f"at the size Export produced")); continue
        # --- KAPI 3: format ailesi + sRGB
        d_blok, d_srgb, d_aile = DXGI[dxgi]
        if d_aile != t["aile"]:
            red.append((ad, f"this file is {d_aile} but the slot needs {t['aile']} - do not rename the "
                            f"exported PNGs; export this outfit again and paint over them")); continue
        if d_srgb != t["srgb"]:
            red.append((ad, f"colour space mismatch: this slot needs "
                            f"{t['aile']}{'_sRGB' if t['srgb'] else ' (linear)'} - do not rename the exported PNGs")); continue

        # --- harici mip'ler + KAPI 4: uzunluk
        base = (0xA0000000000 | tex) << 20
        harici = []
        for lvl in range(t["mipcount"]):
            rid = base | lvl
            if rid not in lf.by_id: continue
            off, ln, ext = lf.by_id[rid]
            dm = next((m for m in mipler if m["lvl"] == lvl), None)
            harici.append({"rid": rid, "lvl": lvl, "off": off, "forge_len": ln,
                           "dds_len": len(dm["veri"]) if dm else None,
                           "w": dm["w"] if dm else None, "h": dm["h"] if dm else None,
                           "uyum": bool(dm) and ln == len(dm["veri"])})
        kotu = [h for h in harici if not h["uyum"]]
        if kotu:
            red.append((ad, "size gate: the encoded texture does not fit the space reserved in the "
                "archive - " + ", ".join(
                f"mip{h['lvl']} archive={h['forge_len']} file={h['dds_len']}" for h in kotu))); continue

        # --- gomulu kuyruk
        veri_bas = hdr + 14
        veri_son = tms[slot + 1][0] if slot + 1 < len(tms) else len(res)
        c = cipa_bul(res, veri_bas, veri_son)
        gom = None
        if c:
            cipa_ofs, piksel_bas, uzunluk = c
            ilk_lvl = len(harici)
            yer, toplam = yerlesim(t["W"], t["blok"], ilk_lvl, uzunluk, t["H"])
            eksik = [lvl for lvl, *_ in yer if not any(m["lvl"] == lvl for m in mipler)]
            gom = {"piksel_bas": piksel_bas, "uzunluk": uzunluk, "ilk_lvl": ilk_lvl,
                   "yer": yer, "kullanilan": toplam, "eksik_mip": eksik}

        isler.append({"dds": p, "ad": ad, "bicim": bicim, "mat": mat, "slot": slot,
                      "tex": tex, "hdr": hdr, "tanim": t, "dxgi": dxgi,
                      "mipler": mipler, "harici": harici, "gom": gom,
                      "res_len": len(res), "tm_sayisi": len(tms)})
    return lf, isler, red, mat_res


# ------------------------------------------------------------------ modlar
def durum(klasor, sadece_harici=False):
    print("=" * 78)
    print("DURUM MODU -- forge'a HICBIR sey yazilmaz (salt okunur)")
    print("=" * 78)
    lf, isler, red, _ = plan(klasor)
    print(f"\nklasor : {klasor}")
    print(f"kabul  : {len(isler)}   red: {len(red)}\n")
    for ad, sebep in red:
        print(f"  [RED] {ad}\n         -> {sebep}")
    if red: print()
    for j in isler:
        t = j["tanim"]
        print(f"  [OK ] {j['ad']}")
        print(f"        ad bicimi     : {j['bicim']}")
        print(f"        materyal      : 0x{j['mat']:X}  ({j['tm_sayisi']} TextureMap)")
        print(f"        SLOT           : {j['slot']}   -> HEDEF DOKU ID 0x{j['tex']:X}"
              f"   (tanimlayici @{j['hdr']})")
        print(f"        forge slot    : {t['W']}x{t['H']} {t['aile']}"
              f"{'_sRGB' if t['srgb'] else ''} enum=0x{t['fmt_enum']:02X} mipcount={t['mipcount']}")
        print(f"        dds           : {t['W']}x{t['H']} {DXGI_AD.get(j['dxgi'], j['dxgi'])}"
              f"  ({len(j['mipler'])} mip)")
        print(f"        HARICI MIP (yerinde bayt yazimi): {len(j['harici'])}")
        for h in j["harici"]:
            print(f"           mip{h['lvl']} {h['w']}x{h['h']}  forge_len={h['forge_len']:>10,}"
                  f"  dds_len={h['dds_len']:>10,}  off={h['off']:>14,}  "
                  f"{'ESIT' if h['uyum'] else 'FARKLI'}")
        g = j["gom"]
        if g is None:
            print(f"        GOMULU KUYRUK: cipa BULUNAMADI -- UYARI: uzak/egik acida orijinal sizabilir")
        elif sadece_harici:
            print(f"        GOMULU KUYRUK: @{g['piksel_bas']} {g['uzunluk']:,}B ATLANIYOR"
                  f" (--sadece-harici) -- UYARI: uzak/egik acida orijinal sizacak")
        else:
            print(f"        GOMULU KUYRUK: @{g['piksel_bas']} havuz={g['uzunluk']:,}B"
                  f"  mip{g['ilk_lvl']}..{g['yer'][-1][0] if g['yer'] else '-'}"
                  f"  ({len(g['yer'])} mip, {g['kullanilan']:,}B kullanilir,"
                  f" {g['uzunluk']-g['kullanilan']} B bos)")
            if g["eksik_mip"]:
                print(f"           !! DDS'te olmayan seviyeler: {g['eksik_mip']} (atlanacak)")
        print()
    # ozet
    yaz_har = sum(len(j["harici"]) for j in isler)
    mats = sorted({j["mat"] for j in isler if j["gom"]}) if not sadece_harici else []
    print("-" * 78)
    print(f"OZET: {yaz_har} harici mip yerinde yazilacak; "
          f"{len(mats)} materyal yeniden paketlenip forge sonuna eklenecek (gomulu kuyruk)")
    print(f"kayit: {'VAR (yamali!)' if os.path.exists(KAYIT) else 'yok (bu arac acisindan vanilla)'}")
    if os.path.exists(KAYIT_ESKI):
        print("UYARI: doku_enjekte_kayit.json VAR -- eski arac slot0'i yamali durumda.")
    if os.path.exists(KAYIT_INLINE):
        print("UYARI: inline_mip_kayit.json VAR -- 'uygula' REDDEDILIR (TOC catismasi).")
    # REDDEDILENLER de dondurulur. Eskiden sadece `isler` donuyordu: kapilardan
    # gecemeyen dosyalarin listesi yalnizca ekrana basiliyordu ve GUI'de ekran
    # yoktu -> kullanici 12 slot boyayip 9'u yazildiginda bunu HIC ogrenemiyordu.
    return isler, red


def _toc_bul(mat):
    with open(FORGE, "rb") as f:
        f.seek(13); hoff = struct.unpack("<q", f.read(8))[0]
        f.seek(hoff); count = struct.unpack("<I", f.read(4))[0]
        toc = struct.unpack("<q", f.read(8))[0]
        f.seek(toc); td = f.read(count * 24)
    for i in range(count):
        if struct.unpack_from("<Q", td, i * 24 + 8)[0] == mat:
            return (toc + i * 24,
                    struct.unpack_from("<Q", td, i * 24)[0],
                    struct.unpack_from("<I", td, i * 24 + 16)[0])
    return None


def uygula(klasor, sadece_harici=False):
    """`_uygula`yi sarar; nasil biterse bitsin yazma bayragini indirir.
    (Govdeyi girintilememek icin ayri sarmalayici -- try/finally tek yerde.)"""
    try:
        return _uygula(klasor, sadece_harici)
    finally:
        _YAZIYOR[0] = False


def _erken_kapilar():
    """`uygula`nin PLAN'dan ve KODLAMADAN once verebilecegi retler.

    Neden ayri: GUI once TUM dokulari BC7'ye kodluyor (kiyafete gore DAKIKALAR),
    sonra yaziciyi cagiriyordu. Kayit 'in_progress' ise ret ancak o noktada
    geliyordu; kullanici bir sey yazilmayacagini ogrenmek icin butun kodlamayi
    bekliyordu (sahadan gelen ekran goruntusu: cubuk %99, "encoding 99/100",
    sonra "Nothing was applied"). Ayni kurallari ikinci bir yere KOPYALAMAK bu
    projenin tekrar eden hatasi oldugu icin kapilar TEK YERDE durur; hem `_uygula`
    hem de disaridan cagrilabilen `uygula_kontrol()` bunu kullanir.

    Doner: (onceki_kayit|None, red_sebep|None). Hicbir sey yazmaz."""
    onceki = None
    if os.path.exists(KAYIT):
        try:
            onceki = json.load(open(KAYIT, encoding="utf-8"))
        except Exception as e:
            return None, ("Mevcut geri-alma kaydi okunamadi (%s). Guvenlik icin durdum; "
                          "kaydi elle incele." % e)
        if onceki.get("durum") == "in_progress":
            # ⚠️ KULLANICI-GORUNUR METIN INGILIZCE (bkz. modul basindaki DIL notu).
            # Bu mesaj Nexus'ta Turkce olarak sikayet edildi (typelev, 2026-07-28) ve
            # GUI'de karsiligi olmayan 'gerial' komutunu tarif ediyordu.
            return onceki, ("A previous apply was interrupted, so the undo record is "
                            "still marked as unfinished and part of a design may already "
                            "be in the game archive. Nothing was written this time.\n"
                            "   Click 'Revert everything' to put the archive back to "
                            "original, then apply again.\n"
                            "   If Revert is refused as well, use Steam > Properties > "
                            "Installed Files > 'Verify integrity of game files'.")
        kf = onceki.get("forge")
        if kf and os.path.normcase(kf) != os.path.normcase(os.path.abspath(FORGE)):
            return onceki, ("The undo record belongs to a DIFFERENT game install, so "
                            "applying here would lose the way back to the original:\n"
                            "   record : %s\n   current: %s\n"
                            "   Nothing was written. Use 'Select game folder' to point at "
                            "the install named above, click 'Revert everything', then come "
                            "back." % (kf, FORGE))
    if onceki is None and _KIMLIK_SUPHESI[0]:
        return None, ("An undo record that may belong to this archive was found, but its\n"
                      "   identity could not be confirmed:\n         %s\n"
                      "   Continuing would have recorded the archive's current (probably\n"
                      "   already patched) bytes as 'original' and permanently broken the "
                      "way\n   back. Nothing was written.\n"
                      "   Do this: use 'Select game folder' to point at the install the "
                      "record\n   names and click 'Revert everything'; or use Steam > "
                      "Properties >\n   Installed Files > 'Verify integrity of game files'."
                      % _KIMLIK_SUPHESI[0])
    if os.path.exists(KAYIT_INLINE):
        return onceki, ("inline_mip_kayit.json is present. Two tools would redirect the "
                        "same material's archive entry and break each other's undo. "
                        "Run first: inline_mip_yama.py gerial")
    return onceki, None


def uygula_kontrol():
    """SALT OKUNUR: `uygula` su an reddeder mi? Doner: red_sebep | None.
    GUI bunu PAHALI kodlamadan ONCE cagirir."""
    return _erken_kapilar()[1]


def _uygula(klasor, sadece_harici=False):
    """Doner: {'harici': n, 'gomulu': m, 'red': [...], 'red_sebep': None|str}

    'red_sebep' doluysa forge'a TEK BAYT yazilmadi. Eskiden bu fonksiyon bos
    'return' ediyordu; cagiran taraf basarisizligi goremedigi icin GUI "SUCCESS"
    yaziyordu. Artik her cikis yolu sonuc dondurur."""
    def _red(sebep):
        print("!! " + sebep)
        return {"harici": 0, "gomulu": 0, "red": [], "red_sebep": sebep}

    # ---- ERKEN KAPILAR: kurallar TEK YERDE (`_erken_kapilar`). GUI ayni
    # kapilari `uygula_kontrol()` ile KODLAMADAN ONCE soruyor; burada tekrar
    # cagriliyor cunku CLI ve dogrudan cagrilar da ayni korumayi almali.
    onceki, _red_sebep = _erken_kapilar()
    if _red_sebep:
        return _red(_red_sebep)

    lf, isler, red, mat_res = plan(klasor)
    for ad, sebep in red:
        print(f"  [RED] {ad} -> {sebep}")
    if not isler:
        r = _red("yazilacak dosya yok.")
        r["red"] = red
        return r
    if os.path.exists(KAYIT_ESKI):
        s0 = {j["mat"] for j in isler if j["slot"] == 0}
        if s0:
            r = _red(f"doku_enjekte_kayit.json VAR ve plan slot0 iceriyor "
                     f"({[hex(m) for m in s0]}). Cakisma riski -- once eski araci 'gerial'.")
            r["red"] = red
            return r

    # ---- OKSUZ YEDEKLER: kayit yokken diskte duran RAW_*.bin dosyalari BASKA bir
    # kusagin vanilla'sidir. Sorgusuz kullanilirsa "vanilla" sandigimiz seyler
    # aslinda ONCEKI bir tasarimin baytlari olur ve geri alma oraya doner.
    # (2026-07-27'de birebir yasandi: Steam dogrulamasi forge'u vanilla'ya
    # dondurdu, kayit silindi ama yedek klasoru kaldi; sonraki apply o bayat
    # yedekleri benimsedi ve revert oyunu vanilla'ya DEGIL eski tasarima dondurdu.)
    # Bu kosunun yedek klasoru (global'e ATAMA YOK). Onceki bir kayit varsa onun
    # klasorunu SURDURURUZ: apply#1 kilitli klasor yuzunden `.yeni_<ts>`e yazmis
    # olabilir; global YEDEK'e donmek apply#2'de "vanilla yedegi kayip" kilidini
    # verirdi (yedekler orada, biz baska yere bakiyorduk).
    yedek_dir = _yedek_dizin(onceki)
    if onceki is None and os.path.isdir(yedek_dir):
        artik = glob.glob(os.path.join(yedek_dir, "RAW_*.bin"))
        if artik:
            karantina = yedek_dir + ".oksuz_" + time.strftime("%Y%m%d_%H%M%S")
            try:
                shutil.move(yedek_dir, karantina)
                print("NOT: kayit yokken %d oksuz yedek bulundu; bunlar baska bir "
                      "kusaga ait olabilir.\n     Karantinaya alindi: %s\n"
                      "     Bu uygulama vanilla'yi forge'un GUNCEL halinden alacak."
                      % (len(artik), karantina))
            except OSError as e:
                # Tasiyamamak REDDETME sebebi DEGIL: amac bayat yedekleri
                # BENIMSEMEMEK, o da klasoru bu kosuda yok sayarak saglanir.
                # (AV taramasi/Explorer onizlemesi tek bir RAW dosyasini kitler ve
                # arac tertemiz bir forge'da bile kullanilamaz hale gelirdi.)
                yedek_dir = yedek_dir + ".yeni_" + time.strftime("%Y%m%d_%H%M%S")
                print("NOT: eski yedek klasoru kenara alinamadi (%s).\n"
                      "     Yok sayiliyor; bu kosunun yedekleri suraya yazilacak:\n"
                      "     %s" % (e, yedek_dir))
    os.makedirs(yedek_dir, exist_ok=True)

    # ---- JOURNAL: ilk forge baytindan ONCE diske yaz.
    # Eskiden kayit en SONA yaziliyordu; arada cokme/kill/AV olursa forge yamali
    # kaliyor ama kayit hic olusmuyordu -> 'gerial' "geri alacak sey yok, vanilla"
    # diyordu. Artik 'in_progress' bir kayit var, yarim kalan yazim geri alinabilir.
    kayit = dict(onceki) if onceki else {}
    kayit.setdefault("harici", [])
    kayit.setdefault("gomulu", [])
    kayit.setdefault("ek_bloklar", [])       # forge sonuna eklenen HER blok (oksuzler dahil)
    kayit["surum"] = KAYIT_SURUM
    # 'in_progress' ILK GERCEK YAZMADAN hemen once konur (asagida). Burada
    # konsaydi, tek bayt yazmadan reddedilen bir apply bile kaydi 'in_progress'
    # birakir ve SONRAKI tum apply'lar kilitlenirdi (cikis yolu: her seyi geri al).
    kayit.setdefault("durum", "done")
    kayit.update(_forge_kimlik())
    # Yedekler NEREDE: `gerial` bunu okumadan once global YEDEK'e bakiyordu ve
    # kilitli klasor senaryosunda yedekleri hic bulamiyordu. ILK `_kayit_yaz`den
    # once konur ki yarim kalan bir apply'in yedekleri de bulunabilsin.
    kayit["yedek_dir"] = os.path.basename(yedek_dir)
    kayit["planlanan"] = {"harici": sum(len(j["harici"]) for j in isler),
                          "materyal": len({j["mat"] for j in isler if j["gom"]})}
    # var olan girisleri anahtarla: ustune yazarken VANILLA alanlarina dokunmayalim
    har_idx = {k["rid"]: k for k in kayit["harici"]}
    gom_idx = {k["mat"]: k for k in kayit["gomulu"]}
    # BU KOSUDA yazilanlar. Donus degeri birlesmis kaydin TOPLAMINI verirse
    # "hicbir sey yazilmadiysa SUCCESS yazma" guvencesi ikinci apply'dan itibaren
    # olur: sayi asla sifir olmaz cunku onceki yamalar da sayiliyordu.
    bu_kosu = {"harici": 0, "gomulu": 0}
    if onceki:
        print("  onceki kayitla birlestiriliyor: %d harici + %d materyal zaten yamali"
              % (len(kayit["harici"]), len(kayit["gomulu"])))

    # ---- ON-UCUS: yedeklerin TAMAMI, TEK BAYT YAZILMADAN once dogrulanir.
    # Bu uc kontrol eskiden yazma dongusunun ICINDEydi: bir sonraki dosyada
    # takilinca "hicbir sey yazilmadi" deniyordu ama onceki mip'ler ZATEN
    # yazilmisti -- kayit tasarim 1'i, forge tasarim 2'yi anlatiyordu ve ne apply
    # ne revert calisiyordu. Artik tutmayan varsa hicbiri yazilmaz.
    vanilla_map = {}
    for j in isler:
        for h in j["harici"]:
            rid = f"0x{h['rid']:016X}"
            yp = os.path.join(yedek_dir, f"RAW_{h['rid']:016X}.bin")
            giris = har_idx.get(rid)
            if os.path.exists(yp):
                vanilla = open(yp, "rb").read()
                if len(vanilla) != h["forge_len"]:
                    return _red("Yedek dosyasi bozuk: %s boyu %d, beklenen %d. "
                                "Hicbir sey yazilmadi." % (os.path.basename(yp),
                                                           len(vanilla), h["forge_len"]))
                if giris and giris.get("sha_orig") and _sha(vanilla) != giris["sha_orig"]:
                    return _red("Yedek dosyasi kayitla uyusmuyor (%s). Hangi baytlarin "
                                "vanilla oldugu belirsiz -- hicbir sey yazilmadi. "
                                "Once 'gerial-kontrol' calistir." % rid)
                vanilla_map[rid] = vanilla
            elif giris is not None:
                # Slot kayitta yamali gorunuyor ama vanilla yedegi kayip. Forge'daki
                # baytlar ONCEKI TASARIM; onlari "orijinal" diye kaydetmek vanilla'nin
                # tek kopyasini yok eder. (2026-07-27'de gercek arsivde yasandi.)
                return _red("'%s' icin vanilla yedegi kayip ama slot kayitta yamali "
                            "gorunuyor. Forge'daki baytlar vanilla DEGIL, onlari orijinal "
                            "diye kaydetmek geri donusu kalici bozar. Hicbir sey yazilmadi.\n"
                            "   Beklenen yedek: %s" % (rid, yp))
            # yedek yok ve kayitta da yok -> vanilla forge'dan alinacak (asagida)

    # Buradan sonrasi GERCEKTEN yaziyor.
    kayit["durum"] = "in_progress"
    _kayit_yaz(kayit)
    _YAZIYOR[0] = True

    # ---- 1) harici mip'ler: yerinde bayt yazimi (ayni uzunluk, TOC islemi YOK)
    with open(FORGE, "r+b") as f:
        for j in isler:
            vmap = {m["lvl"]: m["veri"] for m in j["mipler"]}
            for h in j["harici"]:
                rid = f"0x{h['rid']:016X}"
                yp = os.path.join(yedek_dir, f"RAW_{h['rid']:016X}.bin")
                giris = har_idx.get(rid)
                # VANILLA baytlar ON-UCUSTA dogrulandi (vanilla_map). Yedegi hic
                # olmayan slotun vanilla'si forge'un GUNCEL halidir -- bu slot
                # kayitta da yok, yani daha once hic yamalanmamis.
                if rid in vanilla_map:
                    vanilla = vanilla_map[rid]
                else:
                    f.seek(h["off"]); vanilla = f.read(h["forge_len"])
                    open(yp, "wb").write(vanilla)
                yeni = vmap[h["lvl"]]
                # WAL: ne yazacagimizi yazmadan ONCE kaydet. Kayit is basina
                # yazilirken, is ortasinda cokme/pencere-kapatma olunca yazilmis
                # mip'ler kayitta gorunmuyordu; 'gerial' "geri alacak sey yok"
                # deyip kaydi siliyor ve yedekleri kenara cekiyordu.
                if giris is None:
                    giris = {"rid": rid, "off": h["off"], "len": h["forge_len"],
                             "sha_orig": _sha(vanilla)}
                    kayit["harici"].append(giris)
                    har_idx[rid] = giris
                # ne yazdigimizin izi: 'gerial' geri yazmadan once baytlarin HALA
                # bizim oldugunu dogrular. off/len/sha_orig VANILLA alanlaridir,
                # tekrar uygulamada DOKUNULMAZ.
                giris.update({"dosya": j["ad"], "slot": j["slot"], "lvl": h["lvl"],
                              "sha_yeni": _sha(yeni[:h["forge_len"]])})
                _kayit_yaz(kayit)                 # <-- ONCE kayit
                f.seek(h["off"]); f.write(yeni)   # <-- SONRA forge
                f.flush(); os.fsync(f.fileno())
                bu_kosu["harici"] += 1
            print(f"  {j['ad']}: slot{j['slot']} doku 0x{j['tex']:X} -> "
                  f"{len(j['harici'])} harici mip yazildi", flush=True)

    if sadece_harici:
        print("\nUYARI: --sadece-harici verildi, gomulu mip kuyrugu YAMALANMADI.\n"
              "       Uzaktan/egik acida ORIJINAL doku sizabilir.")
        kayit["durum"] = "done"
        _kayit_yaz(kayit)
        print(f"{len(kayit['harici'])} harici mip yamandi. yedek -> {yedek_dir}")
        return {"harici": bu_kosu["harici"], "gomulu": 0, "toplam_kayit": len(kayit["harici"]),
                "red": red, "red_sebep": None}

    # ---- 2) gomulu kuyruk: materyal basina TEK yeniden paketleme (tum slotlar birlikte)
    by_mat = {}
    for j in isler:
        if j["gom"]: by_mat.setdefault(j["mat"], []).append(j)
    for mat, grup in sorted(by_mat.items()):
        res = bytearray(mat_res[mat])
        toplam_yaz = 0
        for j in grup:
            g = j["gom"]; mipmap = {m["lvl"]: m for m in j["mipler"]}
            for lvl, roff, pitch, satir, rb in g["yer"]:
                m = mipmap.get(lvl)
                if m is None: continue
                src = m["veri"]
                if len(src) < rb * satir: continue
                taban = g["piksel_bas"] + roff
                for r in range(satir):
                    res[taban + r * pitch: taban + r * pitch + rb] = src[r * rb:(r + 1) * rb]
                toplam_yaz += 1
        res = bytes(res)
        assert len(res) == len(mat_res[mat]), "gomulu yazim boyu degistirdi -- DURDUM"

        tp = _toc_bul(mat)
        if tp is None:
            print(f"  !! mat 0x{mat:X} TOC'ta yok, gomulu atlandi"); continue
        tocPos, off, ln = tp
        with open(FORGE, "rb") as f:
            # ham TOC satirini oldugu gibi sakla: 'gerial' geri yazmadan once
            # bu satirin HALA bu materyale ait oldugunu dogrulayabilsin
            f.seek(tocPos); toc_satiri = f.read(24)
            f.seek(off); raw = f.read(ln)
        b1, n1 = read_block(raw, 0); block1 = raw[0:n1]; hdr = raw[n1:n1 + 19]
        pc = struct.unpack_from("<I", raw, n1 + 15)[0]
        boyutlar = []; q = n1 + 19
        for _ in range(pc):
            u, c = struct.unpack_from("<II", raw, q); q += 8; boyutlar.append(u)
        assert sum(boyutlar) == len(res), "parca boyutlari tutmuyor -- DURDUM"
        parcalar = []; o = 0
        for u in boyutlar:
            veri = res[o:o + u]; o += u
            cv = oodle_sik(veri)
            if len(cv) >= u: cv = veri
            parcalar.append((u, cv))
        sizes = b"".join(struct.pack("<II", u, len(cv)) for u, cv in parcalar)
        govde = b"".join(struct.pack("<I", lzo_adler32(cv)) + cv for u, cv in parcalar)
        entry = block1 + hdr + sizes + govde
        with open(FORGE, "r+b") as f:
            f.seek(0, os.SEEK_END); yeni_off = f.tell()
            f.write(entry)
            f.seek(tocPos); f.write(struct.pack("<Q", yeni_off))
            f.seek(tocPos + 16); f.write(struct.pack("<I", len(entry)))
            f.flush(); os.fsync(f.fileno())
        # VANILLA off/len'e ASLA ikinci kez yazma: `_toc_bul` o anki (yamali) TOC
        # degerini dondurur, onu "orijinal" diye kaydetmek revert'i vanilla'ya
        # degil BIR ONCEKI TASARIMA dondururdu.
        giris = gom_idx.get(f"0x{mat:X}")
        if giris is None:
            giris = {"mat": f"0x{mat:X}", "tocPos": tocPos, "off": off, "len": ln,
                     "toc_satiri": toc_satiri.hex(), "slotlar": []}
            kayit["gomulu"].append(giris)
            gom_idx[f"0x{mat:X}"] = giris
        giris.update({"slotlar": sorted(set(giris.get("slotlar", []))
                                        | {j["slot"] for j in grup}),
                      "mip_yazildi": toplam_yaz,
                      "yeni_off": yeni_off, "yeni_len": len(entry)})
        # eklenen HER blok kaydedilir; oksuz kalanlar dahil, ki 'gerial' kuyrugu
        # tam olarak geri kazanabilsin (yoksa her cevrim arsivi kalici buyutur)
        kayit["ek_bloklar"].append([yeni_off, len(entry)])
        bu_kosu["gomulu"] += 1
        _kayit_yaz(kayit)
        print(f"  mat 0x{mat:X}: slot{[j['slot'] for j in grup]} gomulu {toplam_yaz} mip -> "
              f"yeni off={yeni_off:,} len={len(entry):,}")

    kayit["durum"] = "done"
    _kayit_yaz(kayit)
    print(f"\n{len(kayit['harici'])} harici mip + {len(kayit['gomulu'])} materyal (gomulu) yamandi.")
    print(f"yedek -> {yedek_dir}")
    # BU KOSUDA yazilan sayilar (birlesmis kaydin toplami DEGIL)
    return {"harici": bu_kosu["harici"], "gomulu": bu_kosu["gomulu"],
            "toplam_kayit": len(kayit["harici"]) + len(kayit["gomulu"]),
            "red": red, "red_sebep": None}


def _yarim_kalmis(kayit, yap_gom, yap_har, atlanan, sorunlar, ydir):
    """'in_progress' kayit + geri alinacak HICBIR giris yok. Bu an IKI ayri
    senaryodan gelir ve ikisi ZIT tedavi ister:

      (a) apply ilk forge baytini yazmadan kesildi  -> arsiv TERTEMIZ.
      (b) kayda GECMEMIS yazimlar olabilir         -> kaydi silip yedekleri
          kenara cekmek vanilla'ya donusun son izini yok eder.

    Eskiden ikisi de (b) sayilip REDDEDILIYORDU: revert "once apply" der, apply
    "once gerial" der, `--zorla` bile kurtarmazdi (red testi zorla'dan ONCEYDI);
    tek cikis %LOCALAPPDATA% klasorunu elle silmekti -- ve arsiv tertemizken.

    Ayirt edici, OLCULEBILIR sinyal arsivin BOYUTU: gomulu faz forge'un SONUNA
    blok ekler (kaydi sonra yazar), harici faz WAL sayesinde yazmadan ONCE
    kaydeder. Boyut kayittaki ile ayni + dogrulamada sorun yok + kayitli her
    giris zaten vanilla ise, yazilmis bir sey YOKTUR.
    Doner: reddetme sebebi (str) ya da None."""
    if kayit.get("durum") != "in_progress" or yap_gom or yap_har:
        return None
    if not glob.glob(os.path.join(ydir, "RAW_*.bin")):
        return None            # yedek de yok: saklanacak bir vanilla izi yok
    girisler = len(kayit.get("harici", [])) + len(kayit.get("gomulu", []))
    if (not sorunlar and atlanan == girisler
            and kayit.get("forge_boyut") == os.path.getsize(FORGE)):
        return None            # (a) arsiv dokunulmamis -- kilitlemek icin sebep yok
    return ("a previous apply was interrupted and nothing in the record can be restored; "
            "the backups are kept. Use Steam > Properties > Installed Files > "
            "'Verify integrity of game files' to put the archive back to original, then "
            "delete the folder this tool names in the log")


def gerial(zorla=False):
    """Yamayi geri al. ONCE HEPSINI DOGRULA, SONRA YAZ.

    Eski hali uc sekilde zarar verebiliyordu:
      - kayit hangi forge'a ait belliolmadigi icin baska bir kuruluma kor seek
        edip ALAKASIZ TOC satirlarini bozuyordu,
      - eksik yedegi 'continue' ile atlayip yine de kaydi siliyordu (yari-yamali
        forge, geri donusu yok),
      - kac tanesini gercekten geri aldigina bakmadan hepsini geri aldim diyordu.
    Simdi: tek bayt yazmadan once her giris dogrulanir, biri bile tutmazsa hicbir
    sey yazilmaz ve KAYIT SILINMEZ. Doner: {'geri_alindi', 'red_sebep', 'sorunlar'}"""
    if not os.path.exists(KAYIT):
        print("kayit yok, bu arac acisindan vanilla.")
        return {"geri_alindi": 0, "red_sebep": "kayit yok", "sorunlar": []}

    kayit = json.load(open(KAYIT, encoding="utf-8"))
    ydir = _yedek_dizin(kayit)          # yedekler kayitta yazan klasorde
    yap_gom, yap_har, atlanan, sorunlar = _gerial_dogrula(kayit)

    # YARIM KALMIS YAZIM: kayitta GORUNMEYEN yazimlar olabilir. Boyle bir anda
    # "0 giris geri alindi, forge orijinal" deyip kaydi silmek ve yedekleri kenara
    # cekmek, vanilla'ya donusun son izini yok eder: sonraki apply forge'daki
    # YAMALI baytlari vanilla sanir. Arsivin gercekten dokunulmadigi OLCULEBILIYORSA
    # (bkz. `_yarim_kalmis`) reddetmeye gerek yok -- eskiden orada kilitleniyorduk.
    yarim = _yarim_kalmis(kayit, yap_gom, yap_har, atlanan, sorunlar, ydir)
    if yarim and not zorla:
        print("\n!! Onceki 'uygula' yarim kalmis ve kayitta geri alinacak giris yok,")
        print("   ama yedek dosyalari duruyor. Forge'da kayda GECMEMIS yazimlar")
        print("   olabilir; kaydi silmiyor ve yedeklere dokunmuyorum.")
        print("   Guvenli yol: Steam > oyun > Ozellikler > Yuklu Dosyalar >")
        print("   'Dosyalarin butunlugunu dogrula'. Sonra bu klasoru silebilirsin:")
        print("   %s" % os.path.dirname(KAYIT))
        print("   (Bu redde ragmen devam etmek icin: gerial --zorla)")
        return {"geri_alindi": 0, "red_sebep": "yarim kalmis yazim",
                "sorunlar": [yarim]}
    if yarim:
        print("NOT: '--zorla' verildi, 'yarim kalmis yazim' reddi atlaniyor.")
    elif kayit.get("durum") == "in_progress" and not yap_gom and not yap_har:
        print("NOT: onceki 'uygula' ilk forge bayti yazilmadan kesilmis; arsiv boyutu "
              "kayitla ayni ve\n     dogrulama temiz -- yazilmis bir sey yok, kayit "
              "temizleniyor.")

    if sorunlar and not zorla:
        print("\n!! GERI ALMA DURDURULDU -- forge'a TEK BAYT yazilmadi:")
        for s in sorunlar: print("   - " + s)
        print(f"\n   Kayit SILINMEDI: {KAYIT}")
        print("   Oyun guncellendiyse veya 'dosya butunlugunu dogrula' yapildiysa bu beklenen")
        print("   sonuctur: forge zaten vanilla'ya donmustur, kaydi elle silebilirsin.")
        return {"geri_alindi": 0, "red_sebep": "dogrulama basarisiz", "sorunlar": sorunlar}

    gomulu = kayit.get("gomulu", [])
    surum = kayit.get("surum", 1)
    boyut = os.path.getsize(FORGE)

    # ---- 2) YAZMA
    yapildi = 0
    with open(FORGE, "r+b") as f:
        for k in yap_gom:
            f.seek(k["tocPos"]); f.write(struct.pack("<Q", k["off"]))
            f.seek(k["tocPos"] + 16); f.write(struct.pack("<I", k["len"]))
            yapildi += 1
            print(f"  mat {k['mat']} TOC geri alindi")
        for k, yedek in yap_har:
            f.seek(k["off"]); f.write(yedek)
            yapildi += 1
        f.flush(); os.fsync(f.fileno())

    # ---- 3) kuyruk geri kazanimi: eklenen bloklar artik oksuz. Sadece HEPSI geri
    #         alindiysa ve eklenenler dosyanin sonunu TAM olarak kapliyorsa kirp.
    #         (Yoksa her uygula/gerial cevrimi 25,7 GB arsivi kalici buyutuyor.)
    #         `ek_bloklar` HER eklenen blogu tutar (tekrar uygulamalarda oksuz
    #         kalanlar dahil); yoksa eski kayitlar icin son bloklara duseriz.
    ek = kayit.get("ek_bloklar")
    if not ek and gomulu and all("yeni_off" in k for k in gomulu):
        ek = [[k["yeni_off"], k["yeni_len"]] for k in gomulu]
    if surum >= 2 and ek and not sorunlar:
        bas = min(o for o, l in ek)
        son = max(o + l for o, l in ek)
        if son == boyut and sum(l for _, l in ek) == boyut - bas:
            try:
                with open(FORGE, "r+b") as f:
                    f.truncate(bas)
                print(f"  kuyruk geri kazanildi: {boyut - bas:,} bayt kirpildi")
            except OSError as e:
                print(f"  (kuyruk kirpilamadi, zararsiz: {e})")

    # `--zorla` "yarim kalmis yazim" reddinden CIKARIR ama geri alinacak giris
    # yoksa hicbir sey duzeltmez. Bu durumda kaydi silip yedekleri kenara cekmek
    # SAF KAYIP olurdu: vanilla'nin tek kopyasi o yedekler ve arsivin yamali olup
    # olmadigini bilmiyoruz. Zorla'nin isi redden cikmak, veri silmek degil.
    if yarim and yapildi == 0:
        print("\n!! --zorla ile devam edildi ama geri alinabilecek giris yoktu.")
        print("   Kayit ve yedekler KORUNUYOR (vanilla'nin tek kopyasi onlar).")
        print("   Guvenli yol: Steam > Ozellikler > Yuklu Dosyalar > "
              "'Dosyalarin butunlugunu dogrula'.")
        return {"geri_alindi": 0, "atlanan": atlanan,
                "red_sebep": "yarim kalmis yazim", "sorunlar": [yarim]}

    os.remove(KAYIT)
    # Yedekler artik gecmise ait: forge vanilla'ya dondu. Yerlerinde birakirsak
    # SONRAKI bir uygulama onlari "vanilla" sanip benimser (bkz. uygula icindeki
    # oksuz-yedek notu). Silmiyoruz, tarihli klasore cekiyoruz.
    if os.path.isdir(ydir) and glob.glob(os.path.join(ydir, "RAW_*.bin")):
        try:
            shutil.move(ydir, ydir + ".kullanildi_" + time.strftime("%Y%m%d_%H%M%S"))
        except OSError as e:
            print("  (yedek klasoru kenara alinamadi, zararsiz: %s)" % e)
    print(f"\n{yapildi} giris GERI ALINDI"
          + (f", {atlanan} zaten vanilla idi" if atlanan else "") + ".")
    return {"geri_alindi": yapildi, "atlanan": atlanan, "red_sebep": None, "sorunlar": sorunlar}


# =====================================================================
#  SECMELI GERI ALMA  (Nexus talebi: "sadece sectigim kiyafeti geri al")
# =====================================================================
_IC_AD = re.compile(r"^IC_([0-9A-Fa-f]+)_", re.I)


def _mat_anahtar(x):
    """Materyal kimligini KIYASLANABILIR bicime getir: '0x22373CE1241' ->
    '22373CE1241'. None/bos icin None doner."""
    if x is None:
        return None
    t = str(x).strip()
    if t[:2].lower() == "0x":
        t = t[2:]
    t = t.lstrip("0").upper()
    return t or "0"


def _giris_mat(k, tur):
    """Bir kayit girisinin ait oldugu materyal (kiyaslanabilir bicimde).

    * gomulu girisinde materyal DOGRUDAN yazar (`mat`).
    * harici girisinde yazmaz; dosya adindan cozulur:
      `IC_<matID>_tm<texID>_<slot>_...dds` (uretici: bu dosyanin basindaki
      ad semasi). Cozulemezse None -> o giris SECILEBILIR DEGILDIR ve
      secmeli geri almada ASLA yazilmaz (sessizce dokunmak yerine disarida
      birakmak dogru davranis).
    """
    if tur == "gomulu":
        return _mat_anahtar(k.get("mat"))
    m = _IC_AD.match(str(k.get("dosya") or ""))
    return _mat_anahtar(m.group(1)) if m else None


def gerial_dagilim():
    """SALT OKUNUR: geri alinabilir girisler materyale gore nasil dagiliyor?

    GUI 'hangi kiyafetler geri alinabilir' listesini bundan kurar. Forge'a tek
    bayt yazmaz; `gerial_kontrol` ile AYNI dogrulamayi kullanir ki liste ile
    gercek davranis asla ayrisamasin.
    Doner: {'kayit':bool, 'sorunlar':[...], 'materyaller':{mat:{'gomulu':n,
            'harici':n}}, 'coz\u00fclemeyen':n}
    """
    if not os.path.exists(KAYIT):
        return {"kayit": False, "sorunlar": [], "materyaller": {},
                "cozulemeyen": 0}
    kayit = json.load(open(KAYIT, encoding="utf-8"))
    yap_gom, yap_har, atlanan, sorunlar = _gerial_dogrula(kayit)
    mat = {}
    cozulemeyen = 0
    for k in yap_gom:
        a = _giris_mat(k, "gomulu")
        if a is None:
            cozulemeyen += 1; continue
        mat.setdefault(a, {"gomulu": 0, "harici": 0})["gomulu"] += 1
    for k, _yedek in yap_har:
        a = _giris_mat(k, "harici")
        if a is None:
            cozulemeyen += 1; continue
        mat.setdefault(a, {"gomulu": 0, "harici": 0})["harici"] += 1
    return {"kayit": True, "sorunlar": sorunlar, "materyaller": mat,
            "atlanan": atlanan, "cozulemeyen": cozulemeyen}


def gerial_secmeli(mat_idler, zorla=False):
    """SECMELI geri alma: yalnizca verilen materyallerin yazimlarini geri alir.

    Tam `gerial`den farklari ve NEDENLERI:
      * DOGRULAMA AYNI ve TAM. Kayittaki HER giris dogrulanir; biri bile
        tutmazsa TEK BAYT yazilmaz. Secmeli olmak guvenlik kapisini
        GEVSETMEZ -- bozuk bir kayitta arsivin durumu belirsizdir, o zaman
        secerek yazmak da guvenli degildir.
      * Yalniz secilen materyallerin girisleri yazilir.
      * KUYRUK KIRPILMAZ (kismi durumda): arsiv sonundaki eklenen bloklarin
        bir kismi hala CANLI (baska kiyafetler onlari kullaniyor). Kirpmak
        onlari yok ederdi. Geri alinan bloklar oksuz kalir; zararsiz olu
        alandir. `ek_bloklar` AYNEN korunur ki ileride kayit BOSALDIGINDA
        kuyruk tek seferde geri kazanilabilsin.
      * KAYIT SILINMEZ, KUCULTULUR. Geri alinan girisler cikarilir, kalanlar
        durur.
      * YEDEK KLASORU YERINDE KALIR. Kalan girislerin vanilla'sinin TEK
        kopyasi orada; tam `gerial`in yaptigi gibi klasoru kenara cekmek
        onlarin geri donusunu yok ederdi.
    Doner: {'geri_alindi', 'kalan', 'red_sebep', 'sorunlar', 'secilmeyen'}
    """
    bos = {"geri_alindi": 0, "kalan": 0, "sorunlar": []}
    if not os.path.exists(KAYIT):
        return dict(bos, red_sebep="kayit yok")

    istenen = set(a for a in (_mat_anahtar(m) for m in (mat_idler or [])) if a)
    if not istenen:
        return dict(bos, red_sebep="secim bos")

    kayit = json.load(open(KAYIT, encoding="utf-8"))
    yap_gom, yap_har, atlanan, sorunlar = _gerial_dogrula(kayit)

    # Tam `gerial` ile AYNI kapi: dogrulama tutmuyorsa hicbir sey yazilmaz.
    if sorunlar and not zorla:
        print("\n!! SECMELI GERI ALMA DURDURULDU -- forge'a TEK BAYT yazilmadi:")
        for x in sorunlar:
            print("   - " + x)
        return dict(bos, red_sebep="dogrulama basarisiz", sorunlar=sorunlar)

    # yarim kalmis yazim varsa secmeli yola HIC girme: kayitta gorunmeyen
    # yazimlar olabilir, o durumda "neyi sectigimizi" bilemeyiz.
    ydir = _yedek_dizin(kayit)
    yarim = _yarim_kalmis(kayit, yap_gom, yap_har, atlanan, sorunlar, ydir)
    if yarim and not zorla:
        return dict(bos, red_sebep="yarim kalmis yazim", sorunlar=[yarim])

    sec_gom = [k for k in yap_gom if _giris_mat(k, "gomulu") in istenen]
    sec_har = [(k, y) for (k, y) in yap_har
               if _giris_mat(k, "harici") in istenen]
    if not sec_gom and not sec_har:
        return dict(bos, red_sebep="secilen materyalde geri alinacak giris yok",
                    kalan=len(yap_gom) + len(yap_har))

    # ---- YAZMA (yalniz secilenler) ----------------------------------
    yapildi = 0
    with open(FORGE, "r+b") as f:
        for k in sec_gom:
            f.seek(k["tocPos"]); f.write(struct.pack("<Q", k["off"]))
            f.seek(k["tocPos"] + 16); f.write(struct.pack("<I", k["len"]))
            yapildi += 1
            print("  mat %s TOC geri alindi (secmeli)" % k["mat"])
        for k, yedek in sec_har:
            f.seek(k["off"]); f.write(yedek)
            yapildi += 1
        f.flush(); os.fsync(f.fileno())

    # ---- KAYDI KUCULT (silme!) --------------------------------------
    gom_kimlik = set(id(k) for k in sec_gom)
    har_kimlik = set(id(k) for k, _ in sec_har)
    kayit["gomulu"] = [k for k in kayit.get("gomulu", [])
                       if id(k) not in gom_kimlik]
    kayit["harici"] = [k for k in kayit.get("harici", [])
                       if id(k) not in har_kimlik]
    kalan = len(kayit["gomulu"]) + len(kayit["harici"])
    # kismi bir gerial yapildigini kalici olarak isaretle (tani icin)
    kayit["kismi_gerial"] = int(kayit.get("kismi_gerial", 0)) + 1

    if kalan:
        tmp = KAYIT + ".yeni"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(kayit, f, indent=1)
        os.replace(tmp, KAYIT)          # atomik: yarim kayit birakma
        print("\n%d giris GERI ALINDI (secmeli); kayitta %d giris kaldi."
              % (yapildi, kalan))
    else:
        # Kayit bosaldi: durum artik TAM geri alinmis. Kuyrugu ancak burada
        # ve tam `gerial` ile AYNI kosul altinda geri kazanabiliriz (tum
        # eklenen bloklar artik oksuz).
        boyut = os.path.getsize(FORGE)
        ek = kayit.get("ek_bloklar")
        if kayit.get("surum", 1) >= 2 and ek and not sorunlar:
            bas = min(o for o, l in ek)
            son = max(o + l for o, l in ek)
            if son == boyut and sum(l for _, l in ek) == boyut - bas:
                try:
                    with open(FORGE, "r+b") as f:
                        f.truncate(bas)
                    print("  kuyruk geri kazanildi: %d bayt kirpildi"
                          % (boyut - bas))
                except OSError as e:
                    print("  (kuyruk kirpilamadi, zararsiz: %s)" % e)
        os.remove(KAYIT)
        if os.path.isdir(ydir) and glob.glob(os.path.join(ydir, "RAW_*.bin")):
            try:
                shutil.move(ydir, ydir + ".kullanildi_"
                            + time.strftime("%Y%m%d_%H%M%S"))
            except OSError as e:
                print("  (yedek klasoru kenara alinamadi, zararsiz: %s)" % e)
        print("\n%d giris GERI ALINDI (secmeli); kayitta giris kalmadi." % yapildi)

    return {"geri_alindi": yapildi, "kalan": kalan, "red_sebep": None,
            "sorunlar": sorunlar, "atlanan": atlanan}


def _gerial_dogrula(kayit):
    """Kaydi forge'a karsi dogrular. HICBIR SEY YAZMAZ (salt okunur).
    Doner: (yapilacak_gomulu, [(harici, yedek_baytlari)], atlanan, sorunlar)"""
    surum = kayit.get("surum", 1)
    gomulu = kayit.get("gomulu", [])
    harici = kayit.get("harici", [])
    ydir = _yedek_dizin(kayit)      # global YEDEK DEGIL: bkz. `_yedek_dizin`
    sorunlar = []

    if kayit.get("durum") == "in_progress":
        print("NOT: onceki 'uygula' yarim kalmis (journal 'in_progress'). "
              "Yazilabilmis olanlar geri alinacak.")

    # ---- 0) bu kayit BU forge'a mi ait?
    if surum >= 2 and kayit.get("forge"):
        if os.path.normcase(kayit["forge"]) != os.path.normcase(os.path.abspath(FORGE)):
            sorunlar.append("the undo record belongs to a different game install:\n"
                            "       record : %s\n       current: %s"
                            % (kayit["forge"], os.path.abspath(FORGE)))
    elif surum < 2:
        print("UYARI: eski surum (v1) kayit -- hangi forge'a ait oldugu yazmiyor. "
              "TOC satiri ve yedek dogrulamasi yine de yapiliyor.")

    # ---- 1) DOGRULAMA: forge'a tek bayt yazilmaz
    yap_gom, yap_har, atlanan = [], [], 0
    boyut = os.path.getsize(FORGE)
    with open(FORGE, "rb") as f:
        for k in gomulu:
            mat = int(k["mat"], 16)
            if k["tocPos"] + 24 > boyut:
                sorunlar.append(f"{k['mat']}: the recorded archive entry is past the end of the file"); continue
            f.seek(k["tocPos"]); satir = f.read(24)
            kimlik = struct.unpack_from("<Q", satir, 8)[0]
            if kimlik != mat:
                sorunlar.append(f"{k['mat']}: that archive entry now belongs to a different resource "
                                f"(0x{kimlik:X}) - the game archive changed, or this is another install")
                continue
            s_off = struct.unpack_from("<Q", satir, 0)[0]
            s_len = struct.unpack_from("<I", satir, 16)[0]
            if (s_off, s_len) == (k["off"], k["len"]):
                atlanan += 1; continue                      # zaten vanilla
            if surum >= 2 and "yeni_off" in k and (s_off, s_len) != (k["yeni_off"], k["yeni_len"]):
                sorunlar.append(f"{k['mat']}: the archive entry no longer holds the value this tool wrote "
                                f"(off={s_off} len={s_len}) - another mod or tool changed it")
                continue
            yap_gom.append(k)

        for k in harici:
            yp = os.path.join(ydir, "RAW_" + k["rid"][2:] + ".bin")
            if not os.path.exists(yp):
                sorunlar.append(f"{k['rid']}: the backup of the original texture is missing ({os.path.basename(yp)})"); continue
            yedek = open(yp, "rb").read()
            if len(yedek) != k["len"]:
                sorunlar.append(f"{k['rid']}: backup is {len(yedek)} bytes, expected {k['len']}"); continue
            n = len(k.get("sha_orig") or "") or 16
            if k.get("sha_orig") and _sha(yedek, n) != k["sha_orig"]:
                sorunlar.append(f"{k['rid']}: the backup file is damaged (checksum does not match)"); continue
            if k["off"] + k["len"] > boyut:
                sorunlar.append(f"{k['rid']}: the target position is past the end of the game archive"); continue
            f.seek(k["off"]); simdi = f.read(k["len"])
            if k.get("sha_orig") and _sha(simdi, n) == k["sha_orig"]:
                atlanan += 1; continue                      # zaten vanilla
            if surum >= 2 and k.get("sha_yeni") and _sha(simdi, len(k["sha_yeni"])) != k["sha_yeni"]:
                sorunlar.append(f"{k['rid']}: the bytes in the game archive are not the ones this tool "
                                f"wrote - another mod or tool has overwritten them")
                continue
            yap_har.append((k, yedek))

    return yap_gom, yap_har, atlanan, sorunlar


def kayit_sifirla():
    """Bayat geri-alma kaydini KENARA CEKER (silmez) — 'oyun guncellendi' kurtarmasi.

    Saha durumu (2026-08-05, Nexus): oyun guncellenince Steam boot.forge'u
    YENILEDI. Kullanicinin tasarimi zaten arsivden gitti ama kayit + yedekler
    duruyor; revert 'dogrulama basarisiz' diyor, sonraki apply de bayat yedekler
    yuzunden reddediyor -> arac kullanilamaz gorunuyor ('cant use it').
    Tek cikis %LOCALAPPDATA% klasorunu ELLE silmekti.

    Bu islev kaydi ve yedekleri tarihli adlarla KENARA ALIR: hicbir sey
    silinmez (yanlis teshiste vanilla kaniti kaybolmasin), ama yol acilir.
    Doner: {'kayit': tasinan_kayit|None, 'yedek': tasinan_klasor|None}"""
    ts = time.strftime("%Y%m%d_%H%M%S")
    sonuc = {"kayit": None, "yedek": None}
    ydir = YEDEK
    if os.path.exists(KAYIT):
        try:
            k = json.load(open(KAYIT, encoding="utf-8"))
            ydir = _yedek_dizin(k)
        except Exception:                                       # noqa: BLE001
            pass
        hedef = KAYIT + ".guncelleme_" + ts
        shutil.move(KAYIT, hedef)
        sonuc["kayit"] = hedef
    if os.path.isdir(ydir) and glob.glob(os.path.join(ydir, "RAW_*.bin")):
        hedef = ydir + ".guncelleme_" + ts
        shutil.move(ydir, hedef)
        sonuc["yedek"] = hedef
    return sonuc


def gerial_kontrol():
    """SALT OKUNUR: geri alma su an guvenli mi? Forge'a hicbir sey yazmaz.
    GUI 'Revert' dugmesine basmadan once bunu cagirip kullaniciya sorunu gosterebilir."""
    if not os.path.exists(KAYIT):
        return {"kayit": False, "sorunlar": [], "geri_alinacak": 0, "atlanan": 0}
    kayit = json.load(open(KAYIT, encoding="utf-8"))
    g, h, atlanan, sorunlar = _gerial_dogrula(kayit)
    # `gerial`in reddedecegi durumu ON KONTROL de gormeli: yoksa GUI "0 giris geri
    # alinacak" diye onay alir, `gerial` reddeder, GUI yine "forge orijinale dondu"
    # yazardi. Ayni testi ayni yerden cagiriyoruz ki ikisi asla ayrisamasin.
    yarim = _yarim_kalmis(kayit, g, h, atlanan, sorunlar, _yedek_dizin(kayit))
    if yarim:
        sorunlar = sorunlar + [yarim]
    return {"kayit": True, "surum": kayit.get("surum", 1),
            "durum": kayit.get("durum", "done"), "forge": kayit.get("forge"),
            "geri_alinacak": len(g) + len(h), "atlanan": atlanan, "sorunlar": sorunlar}


if __name__ == "__main__":
    argv = sys.argv[1:]
    sh = "--sadece-harici" in argv
    zorla = "--zorla" in argv
    argv = [a for a in argv if not a.startswith("--")]
    m = argv[0] if argv else "durum"
    if m == "gerial": gerial(zorla)
    elif m == "gerial-kontrol":
        r = gerial_kontrol()
        print(json.dumps(r, indent=1, ensure_ascii=False))
    elif m == "uygula": uygula(argv[1], sh)
    elif m == "durum": durum(argv[1], sh)
    else: print(__doc__)
