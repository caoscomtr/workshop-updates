# -*- coding: utf-8 -*-
"""SES CORE v2 — Workshop'un Sounds sekmesinin cekirdegi.

Kullanici metinleri INGILIZCE, kod yorumlari Turkce (proje kurali).

NE YAPAR
  * TAM katalog: 24.767 gomulu (Wwise DIDX/DATA) + 1.084 akis sesi = 25.851
    (30.778 ham kayittan 6.010'u patch_01'in golgeledigi taban kopyasiydi).
    Her ses: banka adi -> kategori, sure, olculmus SESSIZLIK orani, yazilabilirlik.
  * ARAMA: kelime (banka adi parcalari, kategori, kimlik) + kategori + suzgecler
    (diyalog VARSAYILAN GIZLI, %90+ sessiz olanlar VARSAYILAN GIZLI).
  * ON DINLEME: sesi cikarir, vgmstream ile WAV'a cevirir (onbellekli).
  * SUSTUR / SESI AC: fmt govdesindeki +24 ornek sayisini 1 yapar
    (0 yapmak decoder'i DUSURUYOR: vgmstream "failed opening" — olculdu;
     1 = 0,000 sn = etkin sessizlik, dosya gecerli kalir).
  * TAKAS: bir sesin yerine baska bir sesi koyar (akis: parca govdeleri;
    gomulu: DATA icindeki RIFF yuvasi), yeni ses yuvaya SIGMALI.
  * GERI AL: takas + susturma yedeklerinden birebir.

GUVENLIK (hepsi kodda zorunlu)
  * TOC'a DOKUNULMAZ · arsiv boyutu DEGISMEZ · yalniz STORED parcalara yazilir
  * Yazilacak konum CANLI TOC'tan cozulur; katalogtaki ofset yalniz cozulmus
    giris ICINDEKI konumdur ve yazmadan once RIFF/DIDX/deger kapilariyla
    dogrulanir — tutmazsa TEK BAYT yazilmaz
  * Yazimdan ONCE yedek (orijinal baytlar + sha); yedek yoksa yazilmaz
  * Kayit ONCE yazilir (WAL), sonra arsive dokunulur
  * Oyun acikken yazim REDDEDILIR
  * Geri alma TUM yedekleri once dogrular — asla yarim geri alma
"""
import hashlib
import io
import json
import os
import re
import struct
import subprocess
import threading
import time

BURA = os.path.dirname(os.path.abspath(__file__))
KATALOG2 = os.path.join(BURA, "ses_katalog2.json")
KATALOG_ESKI = os.path.join(BURA, "ses_katalog.json")
BMS = bytes.fromhex("33AAFB5799FA0410")
SES_TABAN = "DataPC_boot_sound.forge"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

VERI_KOK = os.path.join(os.environ.get("LOCALAPPDATA") or
                        os.path.join(os.path.expanduser("~"), "AppData", "Local"),
                        "ACBFR_Modding", "ses")
KAYIT = os.path.join(VERI_KOK, "ses_takas_kayit.json")      # takaslar (v1 ile uyumlu)
SUSTUR_KAYIT = os.path.join(VERI_KOK, "ses_sustur_kayit.json")
YEDEK_DIR = os.path.join(VERI_KOK, "yedek")
ONIZLEME_DIR = os.path.join(os.environ.get("LOCALAPPDATA") or
                            os.path.expanduser("~"), "OutfitWorkshop", "onizleme_ses")

# vgmstream: pakette tools\vgmstream\; gelistirme agacinda kardes bir arac klasorunde.
# YAYIN KURALI: kardes klasorun adi kodda YAZILI DEGIL (yayinlanan pakette anlamsiz
# olurdu ve gelistirme agacinin adini kullaniciya tasirdi). Sira: pakete gomulu kopya ->
# ACBFR_VGMSTREAM ortam degiskeni -> proje kokunun kardeslerinde `tools\vgmstream-cli.exe`.
_VGM_ADAYLAR = [
    os.path.join(os.path.dirname(BURA), "tools", "vgmstream", "vgmstream-cli.exe"),
]


def _vgm_gelistirme():
    """Gelistirme agacindaki vgmstream adaylari (pakette bos liste doner)."""
    ov = os.environ.get("ACBFR_VGMSTREAM")
    if ov and os.path.isfile(ov):
        return [ov]
    kok = os.path.dirname(os.path.dirname(BURA))
    try:
        return [os.path.join(kok, ad, "tools", "vgmstream-cli.exe")
                for ad in sorted(os.listdir(kok))[:400]]
    except OSError:                          # kok okunamiyor = aday yok
        return []
SESSIZ_ESIK = 0.90                       # bu oran ve ustu "bos ses" sayilir
_KAT = {"yuklendi": False, "sesler": [], "bankalar": {}, "indeks": {}, "olcum": {}}
_KILIT = threading.Lock()


def _sha(b, n=16):
    return hashlib.sha256(b).hexdigest()[:n]


def vgmstream_yolu():
    for p in _VGM_ADAYLAR:
        if os.path.isfile(p):
            return p
    for p in _vgm_gelistirme():              # yalniz gelistirme agacinda tutar
        if os.path.isfile(p):
            return p
    return None


# ------------------------------------------------------------------- forge
def _yalin():
    """yalin_forge modulunu bul (pakette src/, gelistirmede scriptler/)."""
    import importlib
    try:
        return importlib.import_module("yalin_forge")
    except ImportError:
        raise RuntimeError("forge reader not available")


def oyun_kok():
    """Oyun klasoru — outfit_core zaten bulmus olur."""
    try:
        import outfit_core as C
        if C.game_found():
            return os.path.dirname(C.DE.FORGE)
    except Exception:
        pass
    return None


def ses_forge_yolu(ad=SES_TABAN):
    k = oyun_kok()
    return os.path.join(k, ad) if k else None


class SesForge:
    def __init__(self, ad=SES_TABAN):
        YF = _yalin()
        self.ad = ad
        self.yol = ses_forge_yolu(ad)
        if not self.yol or not os.path.isfile(self.yol):
            raise RuntimeError("The game's sound archive was not found.")
        self.lf = YF.LeanForge(self.yol)
        self._YF = YF

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.lf.close()
        return False

    def var_mi(self, fid):
        return fid in self.lf.by_id

    def konum(self, fid):
        """(off, len) — CANLI TOC'tan."""
        off, ln, _e = self.lf.by_id[fid]
        return off, ln

    def ham(self, fid):
        return self.lf.read_raw(fid)

    def ac(self, fid):
        return bms_ac(self.ham(fid), self._YF)[0]


def bms_ac(raw, YF=None):
    """BMS zincirini SINIR-GUVENLI ac."""
    if YF is None:
        YF = _yalin()
    p, out, n = 0, bytearray(), len(raw)
    while p + 8 <= n and raw[p:p + 8] == BMS:
        q = p + 8
        if q + 11 > n:
            break
        q += 2
        algo = raw[q]; q += 1
        q += 4
        pc = struct.unpack_from("<I", raw, q)[0]; q += 4
        if pc > 1000000 or q + pc * 8 > n:
            break
        boylar = []
        for _ in range(pc):
            u, c = struct.unpack_from("<II", raw, q); q += 8
            boylar.append((u, c))
        kirik = False
        for u, c in boylar:
            q += 4
            if q + c > n:
                kirik = True; break
            veri = raw[q:q + c]; q += c
            try:
                out += veri if c == u else YF.oodle(veri, u)
            except Exception:
                kirik = True; break
        if kirik:
            break
        p = q
    return bytes(out), p


def parca_haritasi(raw):
    """Ham girisin BMS parcalari -> [(dek_bas, dek_son, ham_veri_bas, stored)]."""
    p, n, dek, out = 0, len(raw), 0, []
    while p + 8 <= n and raw[p:p + 8] == BMS:
        q = p + 8 + 2 + 1 + 4
        pc = struct.unpack_from("<I", raw, q)[0]; q += 4
        if pc > 1000000 or q + pc * 8 > n:
            break
        boylar = []
        for _ in range(pc):
            u, c = struct.unpack_from("<II", raw, q); q += 8
            boylar.append((u, c))
        for u, c in boylar:
            q += 4
            if q + c > n:
                return out
            out.append((dek, dek + u, q, u == c))
            dek += u
            q += c
        p = q
    return out


def ham_konum(harita, dek_off, boy):
    """Cozulmus [dek_off, dek_off+boy) araligi tek bir STORED parcadaysa ham
    girisin icindeki ofseti doner; degilse None."""
    for db, ds, hb, st in harita:
        if db <= dek_off < ds:
            if not st or dek_off + boy > ds:
                return None
            return hb + (dek_off - db)
    return None


def alt_id(fid, parca):
    """Alt-giris kimligi. >>20 sonrasi 0x8 isareti bit 43'te kalir."""
    return (0x8 << 60) | (fid << 20) | parca


def parca_listesi(sf, fid):
    """Akis medyasi: [(alt_id, toc_off, toc_len, baslik_boyu, kapasite)]"""
    out, i = [], 0
    while True:
        aid = alt_id(fid, i)
        if not sf.var_mi(aid):
            break
        off, ln = sf.konum(aid)
        acik = sf.ac(aid)
        if i == 0:
            bas = None
            for aday in (24, 28):
                if aday + 4 <= len(acik):
                    a = struct.unpack_from("<I", acik, aday)[0]
                    if a < len(acik) and acik[50 + a:50 + a + 4] == b"RIFF":
                        bas = 50 + a; break
            if bas is None:
                return None
        else:
            bas = out[0][3]
        out.append((aid, off, ln, bas, len(acik) - bas))
        i += 1
    return out or None


def wem_cikar(sf, fid):
    pl = parca_listesi(sf, fid)
    if not pl:
        return None
    out = bytearray()
    for aid, _o, _l, bas, _k in pl:
        out += sf.ac(aid)[bas:]
    return bytes(out)


def riff_bilgi(b):
    if not b or b[:4] != b"RIFF":
        return None
    bilgi = {"boyut": len(b)}
    p = 12
    while p + 8 <= len(b):
        tag = b[p:p + 4]
        sz = struct.unpack_from("<I", b, p + 4)[0]
        if tag == b"fmt " and sz >= 16:
            fmt, ch, sr = struct.unpack_from("<HHI", b, p + 8)
            bilgi.update(codec=fmt, kanal=ch, hz=sr, fmt_off=p + 8, fmt_boy=sz)
            if sz >= 28:                      # toplam ornek fmt+24'te
                orn = struct.unpack_from("<I", b, p + 8 + 24)[0]
                bilgi["ornek"] = orn
                bilgi["sure"] = orn / sr if sr else 0
        p += 8 + sz + (sz & 1)
    return bilgi


# ------------------------------------------------------------------ katalog
def _yukle():
    if _KAT["yuklendi"]:
        return
    with _KILIT:
        if _KAT["yuklendi"]:
            return
        try:
            d = json.load(io.open(KATALOG2, encoding="utf-8"))
            sesler, bankalar = d.get("sesler", []), d.get("bankalar", {})
            _KAT["olcum"] = d.get("olcum", {})
        except Exception:
            sesler, bankalar = [], {}
        # her sese banka bilgisi + gorunen ad + arama metni + benzersiz anahtar
        sayac = {}
        for s in sesler:
            b = bankalar.get(str(s["bid"])) or {}
            s["kod"] = b.get("kod", "other")
            s["kategori"] = b.get("etiket", "Other effects")
            s["banka"] = b.get("ad", "?")
            okunur = b.get("okunur") or s["banka"]
            s["adsiz"] = s["banka"].startswith("BNK_?")
            if s["adsiz"]:
                okunur = "Unnamed bank " + s["banka"].rsplit("_", 1)[-1]
            n = sayac.get(s["bid"], 0) + 1
            sayac[s["bid"]] = n
            s["sira"] = n
            s["ad"] = "%s · %d" % (okunur, n)
            s["anahtar"] = ("a|%d" % s["fid"]) if s.get("akis") else \
                           ("g|%s|%d|%d" % (s["forge"], s["bid"], s["sid"]))
            s["bos"] = (s.get("sessiz") or 0) >= SESSIZ_ESIK
            s["susturulabilir"] = bool(s.get("fmt_stored")) and bool(s.get("orn_off") or s.get("akis"))
            s["_ara"] = (" ".join([okunur, s["banka"].replace("_", " "), s["kategori"],
                                   str(s["sid"]), s["kod"]])).lower()
            s["_takma"] = _takma_adlar(okunur, s["banka"])
            s["_ara"] += s["_takma"]
        # ayni bankada sayac -> "n/N"
        for s in sesler:
            s["ad"] = "%s · %d/%d" % (s["ad"].rsplit(" · ", 1)[0], s["sira"], sayac[s["bid"]])
            # satir numarasiyla arama: "170/422", "#170" (uygulamadaki satir adi yapistirilabilsin)
            s["_ara"] += " %d/%d #%d" % (s["sira"], sayac[s["bid"]], s["sira"])
        _KAT["sesler"], _KAT["bankalar"] = sesler, bankalar
        _KAT["indeks"] = {s["anahtar"]: s for s in sesler}
        _KAT["yuklendi"] = True


def katalog():
    _yukle()
    return _KAT["sesler"]


def ses_bul(anahtar):
    _yukle()
    return _KAT["indeks"].get(anahtar)


def sid_kopyalari(sid, akis=False):
    """Ayni sourceID'nin katalogtaki TUM canli kopyalari (banka ayni sesi
    birden fazla bankada tasiyabilir; susturma hepsine yazilir)."""
    _yukle()
    return [s for s in _KAT["sesler"] if s["sid"] == sid and bool(s.get("akis")) == akis]


def _durum_haritasi():
    """anahtar -> {"sustur": bool, "takas": bool}"""
    out = {}
    for g in _kayit_oku()["girisler"]:
        for a in g.get("anahtarlar") or []:
            out.setdefault(a, {})["takas"] = True
    for g in _sustur_oku()["girisler"]:
        for a in g.get("anahtarlar") or []:
            out.setdefault(a, {})["sustur"] = True
    return out


def kategoriler(diyalog=False, bos=False):
    """Kategori listesi (gorunur sayilarla). Sira: ses sayisina gore."""
    _yukle()
    say = {}
    for s in _KAT["sesler"]:
        if not diyalog and s["kod"] == "voice":
            continue
        if not bos and s["bos"]:
            continue
        d = say.setdefault(s["kod"], {"kod": s["kod"], "ad": s["kategori"], "ses": 0})
        d["ses"] += 1
    SIRA = ["menu", "assassin", "combat", "ship", "shanty", "music", "ambience",
            "animal", "foley", "props", "cutscene", "voice", "other"]
    return sorted(say.values(), key=lambda x: (SIRA.index(x["kod"]) if x["kod"] in SIRA else 99))


def ozet():
    _yukle()
    S = _KAT["sesler"]
    return {"toplam": len(S), "gomulu": sum(1 for s in S if not s.get("akis")),
            "akis": sum(1 for s in S if s.get("akis")),
            "diyalog": sum(1 for s in S if s["kod"] == "voice"),
            "bos": sum(1 for s in S if s["bos"]),
            "susturulabilir": sum(1 for s in S if s["susturulabilir"]),
            "olcum": _KAT["olcum"]}


# ARAMA TAKMA ADLARI (2026-10-12). Katalogda ad = ses BANKASI adi ("SFX Fight Weapon Global All");
# oyuncu ise olayi arar ("assassination", "hidden blade"). Nexus'ta bir kullanici suikast sesini
# bu yuzden bulamadi. Banka adina uyan desene kavram kelimeleri eklenir; yalniz ARAMA metnine
# girer, gorunen ad ve siralama mantigi degismez. Desenler kucuk harfli banka/ad metnine uyar.
TAKMA_ADLAR = (
    (r"weapon pa medium blade|fight weapon global",
     "assassination assassinate double hidden blade hiddenblade kill takedown stab finisher"),
    (r"weapon sword|weapon heavy bladed|weapon pa medium blade",
     "sword blade slash cutlass"),
    (r"weapon ranged pistol", "pistol gun shot gunshot fire"),
    (r"weapon ranged bow|blowpipe", "bow arrow dart blowpipe"),
    (r"impact bloodpack", "blood gore hit flesh"),
    (r"animal air eagle", "eagle bird screech cry"),
    (r"naval|cannon|mortar", "cannon ship naval broadside"),
    (r"\bui\b|menu|hud", "menu interface ui hud click"),
)


def _takma_adlar(okunur, banka):
    metin = ("%s %s" % (okunur, banka)).lower().replace("_", " ")
    ek = [kel for desen, kel in TAKMA_ADLAR if re.search(desen, metin)]
    return (" " + " ".join(ek)) if ek else ""


def _puan(s, kelimeler):
    """Arama puani: dusuk daha iyi. Her kelime AND (arama metninde gecmeyen
    kelime = eslesme yok).

    Katmanlar (guclu -> zayif):
      1. TAM kimlik: bir kelime == str(sid)         -> -1000 (en guclu; daha
         uzun bir sid'in icinde gecen rakam dizisi bunun ALTINDA kalir —
         eskiden +3 ile alt-dize eslesmesinin (+2) gerisine dusuyordu)
      2. TUM IFADE: kelimeler bosluklu birlesince gorunen adin basinda -> -100,
         icinde -> -50 ("bootstrap media 108" -> "Bootstrap Media · 108/597",
         "Bootstrap HUB Media ALl · 108/111" DEGIL)
      3. kelime basina: adin basinda 0, adda gecen 1, arama metninde TAM
         belirtec ("108/597", "#108") 0, baska yerde (banka, kategori, kimlik
         alt-dizesi) 2.
    Gorunen ad " · " -> " " ile normallestirilir ("/" korunur)."""
    if not kelimeler:
        return 0
    ara = s["_ara"]
    for k in kelimeler:
        if k not in ara:
            return None
    ad = s["ad"].lower().replace(" · ", " ")
    sid = str(s["sid"])
    puan = 0
    if any(k == sid for k in kelimeler):
        puan -= 1000
    ifade = " ".join(kelimeler)
    if ad.startswith(ifade):
        puan -= 100
    elif ifade in ad:
        puan -= 50
    belirtecler = None
    for k in kelimeler:
        if ad.startswith(k):
            continue
        if belirtecler is None:
            belirtecler = set(ara.split())
        if k in belirtecler and (k[:1] == "#" or "/" in k):
            continue                              # satir belirteci = bas eslesmesi gibi
        if k in ad:
            puan += 1
        elif k in s.get("_takma", ""):
            continue                              # olay kelimesi (takma ad) = bas eslesmesi gibi
        else:
            puan += 2
    return puan


def ara(kelime="", kategori=None, diyalog=False, bos=False, yalniz_susturulabilir=False,
        en_az_sure=None, en_cok_sure=None, sirala="ad", en_fazla=400, baslangic=0):
    """Arama (SAYFALI). Doner: {"sayi": toplam eslesen, "sesler": [satirlar],
    "baslangic": ofset, "bitti": bu sayfadan sonra satir kalmadi}.
    en_fazla = sayfa boyu, baslangic = sirali eslesme listesinde ofset (sonsuz
    kaydirma). Tum liste her cagrida yeniden suzulup siralanir (bos aramada
    ~20 ms, olculdu — onbellek gerekmedi); satirlar dilimleme aninda TAZE
    sustur/takas durumuyla kurulur, susturma hemen gorunur."""
    _yukle()
    try:
        baslangic = max(0, int(baslangic or 0))
    except (TypeError, ValueError, OverflowError):     # OverflowError: int(inf)
        baslangic = 0
    if en_fazla is not None:                            # None = sinirsiz (tam liste)
        try:
            en_fazla = max(0, int(en_fazla))
        except (TypeError, ValueError, OverflowError):
            en_fazla = 400
    # "·" bitisik de gelebilir ("Media·", "·108/597"): once bosluga cevir, sonra bol
    metin = (kelime or "").lower().replace("·", " ")
    kelimeler = [k for k in re.split(r"\s+", metin.strip())
                 if k and k not in ("-", "—")                # ayrac isaretleri kelime degil
                 and not re.fullmatch(r"\d{1,4}[.)]", k)]    # listeden yapistirilan "7." sira no
    durum = _durum_haritasi()
    out = []
    for s in _KAT["sesler"]:
        if kategori and s["kod"] != kategori:
            continue
        if not diyalog and s["kod"] == "voice" and kategori != "voice":
            continue
        if not bos and s["bos"]:
            continue
        if yalniz_susturulabilir and not s["susturulabilir"]:
            continue
        sure = s.get("gercek_sure") if s.get("gercek_sure") is not None else s.get("sure", 0)
        if en_az_sure is not None and (s.get("sure") or 0) < en_az_sure:
            continue
        if en_cok_sure is not None and (s.get("sure") or 0) > en_cok_sure:
            continue
        p = _puan(s, kelimeler)
        if p is None:
            continue
        out.append((p, s))
    sayi = len(out)
    if sirala == "sure":
        out.sort(key=lambda x: (x[0], -(x[1].get("sure") or 0)))
    elif sirala == "kisa":
        out.sort(key=lambda x: (x[0], (x[1].get("sure") or 0)))
    else:
        # adsiz bankalar (BNK_?_xxxx) listenin sonuna
        out.sort(key=lambda x: (x[0], x[1].get("adsiz", False), x[1]["ad"].lower()))
    satirlar = []
    dilim = out[baslangic:] if en_fazla is None else out[baslangic:baslangic + en_fazla]
    for _p, s in dilim:
        d = durum.get(s["anahtar"], {})
        satirlar.append({
            "anahtar": s["anahtar"], "sid": s["sid"], "fid": s["fid"], "ad": s["ad"],
            "banka": s["banka"], "kategori": s["kategori"], "kod": s["kod"],
            "sure": round(s.get("sure") or 0, 2),
            "gercek_sure": s.get("gercek_sure"), "sessiz": s.get("sessiz"),
            "kanal": s.get("kanal"), "akis": bool(s.get("akis")),
            "boyut": s.get("boy"), "bos": s["bos"],
            "susturulabilir": s["susturulabilir"],
            "susturuldu": bool(d.get("sustur")), "takasli": bool(d.get("takas")),
        })
    return {"sayi": sayi, "sesler": satirlar, "baslangic": baslangic,
            "bitti": baslangic + len(satirlar) >= sayi}


# ------------------------------------------------------------- ses baytlari
def ses_baytlari(s, sf_onbellek=None):
    """Sesin tam .wem baytlari (gomulu: cozulmus giristen dilim; akis: parcalar)."""
    if s.get("akis"):
        with SesForge(SES_TABAN) as sf:
            return wem_cikar(sf, s["fid"])
    with SesForge(s["forge"]) as sf:
        veri = sf.ac(s["fid"])
    b = veri[s["riff"]:s["riff"] + s["boy"]]
    return b if b[:4] == b"RIFF" else None


def wav_uret(anahtar):
    """On dinleme: .wav dosya yolu (onbellekli). vgmstream yoksa None."""
    s = ses_bul(anahtar)
    if not s:
        return None, "unknown sound"
    vgm = vgmstream_yolu()
    if not vgm:
        return None, "vgmstream-cli.exe is missing (tools\\vgmstream)"
    os.makedirs(ONIZLEME_DIR, exist_ok=True)
    ad = re.sub(r"[^A-Za-z0-9_]+", "_", anahtar)[:80]
    wav = os.path.join(ONIZLEME_DIR, ad + ".wav")
    if os.path.isfile(wav) and os.path.getsize(wav) > 44:
        return wav, None
    wem = ses_baytlari(s)
    if not wem:
        return None, "That sound could not be read."
    tmp = os.path.join(ONIZLEME_DIR, ad + ".wem")
    with open(tmp, "wb") as f:
        f.write(wem)
    try:
        r = subprocess.run([vgm, "-i", "-o", wav, tmp], capture_output=True,
                           timeout=120, creationflags=NO_WINDOW)
        if r.returncode != 0 or not os.path.isfile(wav):
            return None, "The sound could not be decoded."
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    _onizleme_temizle()
    return wav, None


def _onizleme_temizle(en_fazla=300):
    try:
        d = [os.path.join(ONIZLEME_DIR, f) for f in os.listdir(ONIZLEME_DIR)
             if f.endswith(".wav")]
        if len(d) <= en_fazla:
            return
        d.sort(key=os.path.getmtime)
        for f in d[:len(d) - en_fazla]:
            try:
                os.remove(f)
            except OSError:
                pass
    except OSError:
        pass


# -------------------------------------------------------------------- kayit
def _json_oku(yol):
    if os.path.isfile(yol):
        try:
            return json.load(io.open(yol, encoding="utf-8"))
        except Exception:
            pass
    return {"surum": 2, "girisler": []}


def _json_yaz(yol, k):
    os.makedirs(VERI_KOK, exist_ok=True)
    t = yol + ".yeni"
    with io.open(t, "w", encoding="utf-8") as f:
        f.write(json.dumps(k, indent=1))
        f.flush(); os.fsync(f.fileno())
    os.replace(t, yol)


def _kayit_oku():
    return _json_oku(KAYIT)


def _kayit_yaz(k):
    _json_yaz(KAYIT, k)


def _sustur_oku():
    return _json_oku(SUSTUR_KAYIT)


def _sustur_yaz(k):
    _json_yaz(SUSTUR_KAYIT, k)


def oyun_acik_mi():
    """Bayt karsilastirmasi (OEM kod sayfasindan bagimsiz)."""
    try:
        c = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ACBlackFlag.exe"],
                           capture_output=True, timeout=10, creationflags=NO_WINDOW)
        return b"ACBlackFlag.exe" in (c.stdout or b"")
    except Exception:
        return False


# ----------------------------------------------------------- konum cozucu
def _ornek_alani_konumu(s):
    """Sesin fmt+24 (ornek sayisi) alaninin HAM DOSYADAKI konumu.

    Doner: (forge_yolu, raw_off, mevcut_deger) ya da (None, None, sebep).
    Her adim CANLI TOC'tan ve cozulmus icerikten dogrulanir:
      gomulu: giris canli TOC'ta · cozulmus giriste DIDX kaydi ayni sid ·
              RIFF imzasi yerinde · alan STORED parcada · ham dosyadaki 4 bayt
              cozulmus icerikteki 4 baytla AYNI
      akis  : parca0 canli TOC'ta · RIFF@bas · fmt alani stored parcada
    """
    if s.get("akis"):
        with SesForge(SES_TABAN) as sf:
            pl = parca_listesi(sf, s["fid"])
            if not pl:
                return None, None, "The stream could not be read."
            aid, off, ln, bas, _k = pl[0]
            ham = sf.ham(aid)
            acik = sf.ac(aid)
            b = riff_bilgi(acik[bas:bas + 4096]) or {}
            if not b.get("fmt_off") or (b.get("fmt_boy") or 0) < 28:
                return None, None, "This sound has no sample-count field (cannot mute)."
            dek = bas + b["fmt_off"] + 24
            harita = parca_haritasi(ham)
            hk = ham_konum(harita, dek, 4)
            if hk is None:
                return None, None, "The header of this sound is compressed (cannot mute)."
            raw_off = off + hk
            deger = struct.unpack_from("<I", acik, dek)[0]
            with open(sf.yol, "rb") as f:
                f.seek(raw_off)
                disk = f.read(4)
            if struct.unpack("<I", disk)[0] != deger:
                return None, None, "Archive bytes do not match the decoded entry (refused)."
            return sf.yol, raw_off, deger
    with SesForge(s["forge"]) as sf:
        if not sf.var_mi(s["fid"]):
            return None, None, "The sound bank entry is not in the archive's table of contents."
        off, ln = sf.konum(s["fid"])
        ham = sf.ham(s["fid"])
        veri = bms_ac(ham, sf._YF)[0]
        # DIDX kaydi ayni sid mi? RIFF yerinde mi?
        try:
            sid, doff, dboy = struct.unpack_from("<III", veri, s["didx"])
        except struct.error:
            return None, None, "The sound bank layout changed (refused)."
        if sid != s["sid"] or veri[s["riff"]:s["riff"] + 4] != b"RIFF":
            return None, None, "The sound bank layout changed (refused)."
        if not s.get("orn_off"):
            return None, None, "This sound has no sample-count field (cannot mute)."
        harita = parca_haritasi(ham)
        hk = ham_konum(harita, s["orn_off"], 4)
        if hk is None:
            return None, None, "The header of this sound is compressed (cannot mute)."
        raw_off = off + hk
        deger = struct.unpack_from("<I", veri, s["orn_off"])[0]
        with open(sf.yol, "rb") as f:
            f.seek(raw_off)
            disk = f.read(4)
        if struct.unpack("<I", disk)[0] != deger:
            return None, None, "Archive bytes do not match the decoded entry (refused)."
        return sf.yol, raw_off, deger


def _u32_yaz(yol, off, deger):
    with open(yol, "r+b") as f:
        f.seek(off); f.write(struct.pack("<I", deger))
        f.flush(); os.fsync(f.fileno())
    with open(yol, "rb") as f:
        f.seek(off)
        return struct.unpack("<I", f.read(4))[0] == deger


SUSTUR_DEGERI = 1          # 0 -> decoder acamiyor (olculdu); 1 ornek = 0,000 sn


def sustur_plani(anahtar):
    """SALT OKUMA: susturma mumkun mu? Hangi kopyalar yazilacak?"""
    s = ses_bul(anahtar)
    if not s:
        return {"ok": False, "mesaj": "unknown sound"}
    kopyalar = sid_kopyalari(s["sid"], bool(s.get("akis")))
    if not kopyalar:
        kopyalar = [s]
    yaz, atla = [], []
    for k in kopyalar:
        yol, raw_off, deger = _ornek_alani_konumu(k)
        if yol is None:
            atla.append({"anahtar": k["anahtar"], "sebep": deger})
        else:
            yaz.append({"anahtar": k["anahtar"], "forge": os.path.basename(yol),
                        "raw_off": raw_off, "eski": deger})
    if not yaz:
        return {"ok": False, "mesaj": (atla[0]["sebep"] if atla else "cannot mute"),
                "atlanan": atla}
    return {"ok": True, "yazilacak": yaz, "atlanan": atla,
            "zaten": all(y["eski"] == SUSTUR_DEGERI for y in yaz)}


def sustur(anahtar, etiket=""):
    """Sesi sustur: ornek sayisi alanini 1 yap (tum canli kopyalarda)."""
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    plan = sustur_plani(anahtar)
    if not plan.get("ok"):
        return plan
    if plan.get("zaten"):
        return {"ok": False, "mesaj": "This sound is already muted."}
    kayit = _sustur_oku()
    for g in kayit["girisler"]:
        if anahtar in (g.get("anahtarlar") or []):
            return {"ok": False, "mesaj": "This sound is already muted."}
    giris = {"zaman": time.strftime("%Y-%m-%d %H:%M:%S"), "etiket": etiket,
             "anahtarlar": [y["anahtar"] for y in plan["yazilacak"]],
             "yazmalar": [], "durum": "in_progress"}
    for y in plan["yazilacak"]:
        yol = ses_forge_yolu(y["forge"])
        giris["yazmalar"].append({"forge": y["forge"], "raw_off": y["raw_off"],
                                  "eski": y["eski"], "yeni": SUSTUR_DEGERI,
                                  "sha_once": _sha(open(yol, "rb").read(0) or b"")})
    kayit["girisler"].append(giris)
    _sustur_yaz(kayit)                          # WAL: once kayit
    yazilan = 0
    for y in giris["yazmalar"]:
        yol = ses_forge_yolu(y["forge"])
        if not _u32_yaz(yol, y["raw_off"], y["yeni"]):
            giris["durum"] = "half"
            _sustur_yaz(kayit)
            return {"ok": False, "mesaj": "Write verification failed - revert to be safe."}
        yazilan += 1
    giris["durum"] = "uygulandi"
    _sustur_yaz(kayit)
    return {"ok": True, "yazilan": yazilan, "atlanan": plan["atlanan"]}


def sesi_ac(anahtar):
    """Tek bir sesin susturmasini geri al (kayittan eski degeri yazar)."""
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    kayit = _sustur_oku()
    hedef = None
    for g in kayit["girisler"]:
        if anahtar in (g.get("anahtarlar") or []):
            hedef = g; break
    if not hedef:
        return {"ok": False, "mesaj": "This sound is not muted."}
    # once dogrula: her konumda su an 'yeni' deger duruyor mu?
    for y in hedef["yazmalar"]:
        yol = ses_forge_yolu(y["forge"])
        if not yol or not os.path.isfile(yol):
            return {"ok": False, "mesaj": "The sound archive was not found."}
        with open(yol, "rb") as f:
            f.seek(y["raw_off"]); v = struct.unpack("<I", f.read(4))[0]
        if v not in (y["yeni"], y["eski"]):
            return {"ok": False, "mesaj": "The archive changed since the mute - refused."}
    for y in hedef["yazmalar"]:
        _u32_yaz(ses_forge_yolu(y["forge"]), y["raw_off"], y["eski"])
    kayit["girisler"] = [g for g in kayit["girisler"] if g is not hedef]
    _sustur_yaz(kayit)
    return {"ok": True, "geri_alindi": len(hedef["yazmalar"])}


# -------------------------------------------------------------------- takas
def _parca_yaz(ham, yeni_acik):
    """Stored BMS blogunun ICINDEKI veriyi degistir; boyut/bicim korunur."""
    p, n, dilimler = 0, len(ham), []
    while p + 8 <= n and ham[p:p + 8] == BMS:
        q = p + 8 + 2 + 1 + 4
        pc = struct.unpack_from("<I", ham, q)[0]; q += 4
        boylar = []
        for _ in range(pc):
            u, c = struct.unpack_from("<II", ham, q); q += 8
            boylar.append((u, c))
        for u, c in boylar:
            q += 4
            if u != c:
                return None
            dilimler.append((q, c)); q += c
        p = q
    if not dilimler or sum(c for _o, c in dilimler) != len(yeni_acik):
        return None
    yeni = bytearray(ham)
    kalan = yeni_acik
    for off, c in dilimler:
        yeni[off:off + c] = kalan[:c]; kalan = kalan[c:]
    return bytes(yeni)


def takas_plani(hedef_anahtar, kaynak_anahtar):
    h, k = ses_bul(hedef_anahtar), ses_bul(kaynak_anahtar)
    if not h or not k:
        return {"ok": False, "mesaj": "unknown sound"}
    if h["anahtar"] == k["anahtar"]:
        return {"ok": False, "mesaj": "Pick two different sounds."}
    yeni = ses_baytlari(k)
    if not yeni:
        return {"ok": False, "mesaj": "The replacement sound could not be read."}
    if h.get("akis"):
        with SesForge(SES_TABAN) as sf:
            pl = parca_listesi(sf, h["fid"])
        if not pl:
            return {"ok": False, "mesaj": "That sound could not be read."}
        kap = sum(x[4] for x in pl)
    else:
        if not h.get("stored"):
            return {"ok": False, "mesaj":
                    "This sound is stored compressed and cannot be replaced yet (mute works)."}
        kap = h["boy"]
    if len(yeni) > kap:
        return {"ok": False, "mesaj":
                {"t": "This slot only has room for about {0} seconds, and the replacement "
                      "is about {1} seconds. Pick a shorter sound.",
                 "a": ["%.1f" % (h.get("sure") or 0), "%.1f" % (k.get("sure") or 0)]},
                "kapasite": kap, "gerekli": len(yeni)}
    return {"ok": True, "kapasite": kap, "gerekli": len(yeni)}


def takas(hedef_anahtar, kaynak_anahtar, etiket=""):
    """Sesi takas et. Kapilardan gecmezse TEK BAYT yazilmaz."""
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    plan = takas_plani(hedef_anahtar, kaynak_anahtar)
    if not plan.get("ok"):
        return plan
    h, k = ses_bul(hedef_anahtar), ses_bul(kaynak_anahtar)
    yeni = ses_baytlari(k)
    os.makedirs(YEDEK_DIR, exist_ok=True)
    yazim, imza = [], []
    if h.get("akis"):
        forge_ad = SES_TABAN
        with SesForge(SES_TABAN) as sf:
            pl = parca_listesi(sf, h["fid"])
            kalan = yeni
            for aid, off, ln, bas, kap in pl:
                dilim, kalan = kalan[:kap], kalan[kap:]
                ham = sf.ham(aid)
                acik = sf.ac(aid)
                yeni_ham = _parca_yaz(ham, acik[:bas] + dilim + b"\x00" * (kap - len(dilim)))
                if not yeni_ham or len(yeni_ham) != ln:
                    return {"ok": False, "mesaj":
                            "This sound is stored in a format that cannot be replaced yet."}
                yazim.append((off, yeni_ham))
                yb = os.path.join(YEDEK_DIR, "RAW_%016X.bin" % aid)
                if not os.path.isfile(yb):
                    with open(yb, "wb") as f:
                        f.write(ham)
                    ysha = _sha(ham)
                else:
                    ysha = _sha(open(yb, "rb").read())
                imza.append({"alt": str(aid), "off": off, "len": ln, "sha": ysha,
                             "yedek": os.path.basename(yb)})
    else:
        forge_ad = h["forge"]
        with SesForge(forge_ad) as sf:
            off, ln = sf.konum(h["fid"])
            ham = sf.ham(h["fid"])
            veri = bms_ac(ham, sf._YF)[0]
            if veri[h["riff"]:h["riff"] + 4] != b"RIFF":
                return {"ok": False, "mesaj": "The sound bank layout changed (refused)."}
            harita = parca_haritasi(ham)
            # RIFF yuvasi birden fazla stored parcaya yayilabilir: parca parca yaz
            govde = yeni + b"\x00" * (h["boy"] - len(yeni))
            konumlar = []
            p = 0
            while p < len(govde):
                dek = h["riff"] + p
                for db, ds, hb, st in harita:
                    if db <= dek < ds:
                        if not st:
                            return {"ok": False, "mesaj":
                                    "This sound is stored compressed and cannot be replaced yet."}
                        n = min(ds - dek, len(govde) - p)
                        konumlar.append((off + hb + (dek - db), govde[p:p + n],
                                         ham[hb + (dek - db):hb + (dek - db) + n]))
                        p += n
                        break
                else:
                    return {"ok": False, "mesaj": "The sound bank layout changed (refused)."}
            yb = os.path.join(YEDEK_DIR, "SLOT_%s_%d_%d.bin" % (
                re.sub(r"\W+", "_", forge_ad), h["fid"], h["sid"]))
            eski_govde = b"".join(e for _o, _y, e in konumlar)
            if not os.path.isfile(yb):
                with open(yb, "wb") as f:
                    f.write(eski_govde)
                ysha = _sha(eski_govde)
            else:
                ysha = _sha(open(yb, "rb").read())
            for raw_off, parca, _e in konumlar:
                yazim.append((raw_off, parca))
            imza.append({"gomulu": True, "yedek": os.path.basename(yb), "sha": ysha,
                         "konumlar": [[o, len(pr)] for o, pr, _e in konumlar]})
    forge = ses_forge_yolu(forge_ad)
    for g in imza:                              # yedek kapisi
        if not os.path.isfile(os.path.join(YEDEK_DIR, g["yedek"])):
            return {"ok": False, "mesaj": "Backup failed - nothing written."}
    kayit = _kayit_oku()                        # WAL: once kayit
    kayit["girisler"].append({"zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
                              "forge": forge_ad,
                              "hedef": hedef_anahtar, "kaynak": kaynak_anahtar,
                              "anahtarlar": [hedef_anahtar],
                              "hedef_fid": h["fid"], "kaynak_fid": k["fid"],
                              "etiket": etiket, "parcalar": imza})
    _kayit_yaz(kayit)
    with open(forge, "r+b") as f:
        for off, ham in yazim:
            f.seek(off); f.write(ham)
        f.flush(); os.fsync(f.fileno())
    # geri okuma kapisi
    dogru = False
    try:
        _KAT["yuklendi"] = _KAT["yuklendi"]
        b = ses_baytlari(h)
        dogru = bool(b) and b[:len(yeni)] == yeni
    except Exception:
        pass
    return {"ok": True, "dogrulandi": dogru, "parca": len(yazim)}


def geri_al():
    """Tum takas ve susturmalari geri al (once TUM yedekleri dogrular)."""
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    kayit = _kayit_oku()
    sus = _sustur_oku()
    if not kayit["girisler"] and not sus["girisler"]:
        return {"ok": True, "geri_alindi": 0, "mesaj": "Nothing to revert."}
    isler = []                                  # (forge_yolu, off, bytes)
    for g in kayit["girisler"]:
        forge_ad = g.get("forge") or SES_TABAN
        yol = ses_forge_yolu(forge_ad)
        if not yol or not os.path.isfile(yol):
            return {"ok": False, "mesaj": "The sound archive was not found."}
        for p in g["parcalar"]:
            yb = os.path.join(YEDEK_DIR, p.get("yedek") or ("RAW_%016X.bin" % int(p["alt"])))
            if not os.path.isfile(yb):
                return {"ok": False, "mesaj":
                        "A backup file is missing - nothing was written."}
            ham = open(yb, "rb").read()
            if _sha(ham) != p["sha"]:
                return {"ok": False, "mesaj":
                        "A backup does not match the record - nothing was written."}
            if p.get("gomulu"):
                q = 0
                for off, n in p["konumlar"]:
                    isler.append((yol, off, ham[q:q + n])); q += n
            else:
                if len(ham) != p["len"]:
                    return {"ok": False, "mesaj":
                            "A backup does not match the record - nothing was written."}
                isler.append((yol, p["off"], ham))
    for g in sus["girisler"]:
        for y in g["yazmalar"]:
            yol = ses_forge_yolu(y["forge"])
            if not yol or not os.path.isfile(yol):
                return {"ok": False, "mesaj": "The sound archive was not found."}
            isler.append((yol, y["raw_off"], struct.pack("<I", y["eski"])))
    dosyalar = {}
    for yol, off, b in isler:
        dosyalar.setdefault(yol, []).append((off, b))
    for yol, liste in dosyalar.items():
        with open(yol, "r+b") as f:
            for off, b in liste:
                f.seek(off); f.write(b)
            f.flush(); os.fsync(f.fileno())
    n = len(kayit["girisler"]) + len(sus["girisler"])
    for yol in (KAYIT, SUSTUR_KAYIT):
        try:
            os.remove(yol)
        except OSError:
            pass
    return {"ok": True, "geri_alindi": n, "parca": len(isler)}


def durum():
    k, s = _kayit_oku(), _sustur_oku()
    return {"takas": len(k["girisler"]), "sustur": len(s["girisler"]),
            "girisler": [{"tur": "takas", "hedef": g.get("hedef"), "kaynak": g.get("kaynak"),
                          "etiket": g.get("etiket", ""), "zaman": g.get("zaman")}
                         for g in k["girisler"]] +
                        [{"tur": "sustur", "anahtarlar": g.get("anahtarlar"),
                          "etiket": g.get("etiket", ""), "zaman": g.get("zaman")}
                         for g in s["girisler"]]}
