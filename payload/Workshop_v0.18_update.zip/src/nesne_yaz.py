# -*- coding: utf-8 -*-
"""NESNE_YAZ -- duzenlenmis nesne XML'ini OYUN ARSIVINE geri yazan katman.

Anvil'in "ac -> duzenle -> geri paketle" zincirinin SON halkasi. Katman dizilimi
(nesne_xml.py'nin basindaki semanin devami):

    XML metni  --(nesne_xml.xml_al)-->  agac
    agac       --(nesne.yaz)-->         GOVDE baytlari
    govde + orijinal ic dosya --(_ic_dosya_kur)--> TAM ic dosya   <- BU MODUL
    tam ic dosya --(explorer_core.disa_aktar + geri_yukle)--> kurulum  <- TEK YAZICI

⛔ BU MODULUN KENDI YAZICISI YOKTUR. Forge'a giden tek yol
   explorer_core.geri_yukle -> kur_mesh.kur'dur. `open(..., "r+b")` burada gecmez.
   geri_yukle atlanirsa su kapilar kaybolur: yazma kilidi, "oyun acik", golge
   (patch zincirinde ust kopya), bilgi.json kimlik esitligi, WAL kaydi + yedek +
   yazma sonrasi dogrulama, Health Check gorunurlugu ve "Revert" geri alma.

=============================================================================
 UC KAPI (hepsi OLCULDU, testler/test_nesne_yaz.py)
=============================================================================
1) UZUNLUK -- CANLI arsive karsi. nesne_xml'in kapisi XML'in KENDI govde_boy
   iddiasina bakar; niteligi tutarli guncelleyen bir duzenleme (+1/-1 bayt,
   nesne silme) o kapidan gecer. Burada uretilen govde, arsivden O ANDA okunan
   govdeyle karsilastirilir: uzunluk farkliysa yazma REDDEDILIR. Uzunluk
   degistiren yazma bugun BILEREK yoktur -- sayac alanlari ve yerel siralar
   yeniden kurulmadan uzunluk degistirmek oyunu bozar (silah_stat bunu tek sinif
   ailesi icin yapiyor; genellestirmek ayri istir).

2) SARMALAYICI -- ic dosya = [u32 tip][u32 boyut][u32 adLen][ad][u8 flag][u64 nid]
   [u32 tip] + govde (+ kuyruk). `boyut` alani govdenin uzunlugunu tasir ve
   KUYRUGU (bazi Animation girislerinde 55-199 B) DISLAR. kur_mesh.giris_kur
   yalnizca K1 tablosundaki u32'yi duzeltir, bu alana dokunmaz (olculdu: "sarmalayici"
   kur_mesh'te 0 kez gecer). silah_stat 2026-09-05'te OYUN ICI testte ogrendi:
   alan eski kalinca oyun da bizim okuyucumuz da girisi reddediyor. Bu yuzden
   `_ic_dosya_kur` ayni kalipla alani yeniden hesaplar, kuyrugu korur ve sonucu
   KENDI cozucusuyle (forge_giris.sarmalayici_coz) geri okuyup esitligi arar.

3) KIMLIK -- XML kokundeki gid/icid ile cagiranin istedigi hedef CAKISAMAZ;
   disa aktarilan .bin arsivden okunan orijinalle BIREBIR olmali (okuma ile yazma
   arasinda arsiv degistiyse dur). bilgi.json'daki kimlik kapisi explorer_core'da.

Neden gecici klasor + disa_aktar: explorer_core._geri_ham bilgi.json'un
`parcalar[].dosya -> icid` eslemesini okur. O dosyayi ELLE kurmak yerine ayni
modulun `disa_aktar(bicim="ham")` cagrisiyla urettiririz, sonra .bin'in icini
yeni ic dosyayla degistiririz: bicim suruklenemez, kimlik kagidi gercek olcumden
gelir (giris sha256, sinif, ad) ve golge uyarisi da ayni yoldan gelir.

Kullanici metinleri INGILIZCE tam cumle; kod yorumlari TURKCE (ASCII).
"""
import os
import shutil
import struct
import sys
import tempfile
import time

BURA = os.path.dirname(os.path.abspath(__file__))
KOK = os.path.dirname(BURA)
if BURA not in sys.path:
    sys.path.insert(0, BURA)

import nesne as N                                          # noqa: E402
import nesne_xml as X                                      # noqa: E402
import outfit_core as C                                    # noqa: E402
from export3d import forge_giris as FG                     # noqa: E402

__all__ = ["xml_hazirla", "xml_yaz", "SURUM", "ETIKET_ONEK"]

SURUM = 1
# explorer_core kaydinda bu modulun yazmalarini isaretleyen onek. explorer_core
# kendi onekini ("explorer:") onune koyar; Health Check / Revert onunla suzer.
ETIKET_ONEK = "xml"
# degisen_yer listesinde her parca icin tasinan en fazla eski/yeni bayt (hex).
_YER_HEX_SINIR = 32


# =====================================================================================
#  YARDIMCILAR
# =====================================================================================
def _ex():
    """explorer_core -- TEMBEL: doku/mesh motorlarini `import nesne_yaz` uyandirmasin."""
    import explorer_core as EX
    return EX


def _uz():
    """uzman (expert mode) -- TEMBEL, `_ex()` ile ayni gerekce."""
    import uzman as UZ
    return UZ


def _uzunluk_serbest_mi(deger):
    """Cagirandan gelen acik istek yoksa KURESEL uzman anahtarina bak. FAIL-CLOSED:
    uzman modulu okunamazsa kapi KAPALI sayilir."""
    if deger is not None:
        return bool(deger)
    try:
        return bool(_uz().kapi("uzunluk_degisimi"))
    except Exception:                                       # noqa: BLE001
        return False


def _int(x):
    """int | '0x1FDD...' | '1FDD...' -> int (kimlikler daima ONALTILIK yazilir)."""
    if x is None:
        return None
    if isinstance(x, bool):
        raise TypeError("id must be an integer or a hex string")
    if isinstance(x, int):
        return int(x)
    s = str(x).strip()
    if not s:
        return None
    return int(s, 16)


def _hex(x):
    return None if x is None else ("0x%012X" % int(x))


def _log(progress, s):
    C._log(progress, s)


def _fark(a, b):
    """Iki es-uzunluklu bayt dizisinin farkli PARCALARI: [[ofset, uzunluk, eski, yeni]].

    Ofset govdeye goredir (sarmalayici basligi haric). eski/yeni hex, parca basina
    _YER_HEX_SINIR bayt ile sinirlidir (ozet icindir, tam yuk degil)."""
    if a == b:
        return []
    out = []
    n = len(a)
    i = 0
    while i < n:
        if a[i] == b[i]:
            i += 1
            continue
        j = i + 1
        while j < n and a[j] != b[j]:
            j += 1
        out.append([i, j - i, a[i:min(j, i + _YER_HEX_SINIR)].hex().upper(),
                    b[i:min(j, i + _YER_HEX_SINIR)].hex().upper()])
        i = j
    return out


# =====================================================================================
#  UZMAN MODU -- KAYIT DUZEYINDE FARK + BILINMEYEN SAYAC TARAMASI
# =====================================================================================
# 0xE0EE0EB5: govdesinde UYE SAYISI tasidigi KANITLANMIS tek sinif (silah_stat.py:53).
# build/nesne_semasi.json'da "sayac" diye bir tip YOK; asagidaki tarama bu yuzden bir
# SEMA degil bir ARAMADIR: bayat kalabilecek adaylari gosterir, hicbirini duzeltmez.
KANITLI_SAYAC_CRC = 0xE0EE0EB5
_SAYAC_SINIRI = 20


def _duz(agac):
    """{(kimlik_turu, sira): dugum} -- iki agaci kayit kayit karsilastirmak icin."""
    out = {}
    for d, _dr in N.gez(agac):
        out[(d["kimlik_turu"], d["sira"])] = d
    return out


def _kayit_bayt(d):
    return bytes(d["yuk"]) + bytes(d["yuk_son"])


def _fark_kayit(orij, agac, icid):
    """Uzunluk DEGISEN duzenlemede kayit kayit fark: eklenen / silinen / degisen.

    Es-uzunluklu govdede `_fark` bayt araliklarini verir; uzunluk degisince o
    liste anlamsizlasir (tek bayt kayma her seyi "farkli" gosterir), bu yuzden
    karsilastirma KAYIT duzeyine cikar. Anahtar = (kimlik uzayi, sira)."""
    eski = N.oku_govde(orij, icid)
    a = _duz(eski["kok"])
    b = _duz(agac["kok"])
    out = []
    for k in sorted(set(a) | set(b), key=lambda t: (str(t[0]), t[1])):
        da, db = a.get(k), b.get(k)
        kayit = {"uzay": k[0], "sira": k[1],
                 "crc": (db or da)["sinif_crc"],
                 "eski_boy": None if da is None else len(_kayit_bayt(da)),
                 "yeni_boy": None if db is None else len(_kayit_bayt(db)),
                 "durum": "eklendi" if da is None else
                          ("silindi" if db is None else "ayni")}
        if da is not None and db is not None:
            ba, bb = _kayit_bayt(da), _kayit_bayt(db)
            if len(ba) != len(bb):
                kayit["durum"] = "uzunluk"
            elif ba != bb:
                kayit["durum"] = "degisti"
                kayit["yer"] = _fark(ba, bb)
        if kayit["durum"] != "ayni":
            out.append(kayit)
    onek_a = bytes(eski.get("onek") or b"")
    onek_b = bytes(agac.get("onek") or b"")
    if onek_a != onek_b:
        out.append({"uzay": None, "sira": None, "crc": None,
                    "eski_boy": len(onek_a), "yeni_boy": len(onek_b),
                    "durum": "uzunluk" if len(onek_a) != len(onek_b) else "degisti",
                    "yer": _fark(onek_a, onek_b) if len(onek_a) == len(onek_b) else []})
    return eski, out


def _u_tara(b, hedefler, sinir):
    """`b` icindeki HER konumda u32 ve u16 oku; `hedefler`deki degerleri bildir."""
    bul = []
    for genislik, fmt in ((4, "<I"), (2, "<H")):
        for i in range(0, max(0, len(b) - genislik + 1)):
            v = struct.unpack_from(fmt, b, i)[0]
            if v in hedefler:
                bul.append((i, genislik, v, hedefler[v]))
                if len(bul) >= sinir:
                    return bul
    return bul


def _sayac_adaylari(eski, degisenler):
    """DURUST TARAMA: uzunluk degisince BAYAT kalabilecek sayac/uzunluk alanlari.

    Nesne yukunun ICINDEKI sayaclar KONUMSALDIR ve adsizdir; sema onlari
    tanimiyor. Burada yalnizca DEGISMEYEN kayitlarda ve onekte, degeri
    "eski kayit sayisi / eski sinif sayisi / eski govde boyu / degisen bir
    kaydin eski boyu" olan u32-u16 alanlari isaretleriz. Bulunan sey bir
    KANIT DEGIL, bir ADAYDIR -- kullanicinin bakmasi gereken yerdir."""
    if not degisenler:
        return []
    kok = list(eski.get("kok") or [])
    hedef = {}
    hedef[len(kok)] = "the old number of records in this body (%d)" % len(kok)
    gb = int(eski.get("govde_boy") or 0)
    hedef.setdefault(gb, "the old body length (%d bytes)" % gb)
    for crc in {d["crc"] for d in degisenler if d.get("crc") is not None}:
        n = sum(1 for k in kok if k["sinif_crc"] == crc)
        hedef.setdefault(n, "the old number of class 0x%08X records (%d)" % (crc, n))
    for d in degisenler:
        eb = d.get("eski_boy")
        if eb:
            hedef.setdefault(eb, "the old length of a record that changed (%d bytes)" % eb)
    for kucuk in (0, 1):                    # her yerde gecen degerler = gurultu
        hedef.pop(kucuk, None)
    degisen_anahtar = {(d.get("uzay"), d.get("sira")) for d in degisenler}
    out = []
    parcalar = [(None, None, None, bytes(eski.get("onek") or b""))]
    for k in kok:
        if (k["kimlik_turu"], k["sira"]) in degisen_anahtar:
            continue                        # kendisi degisti; sayacini kullanici yazdi
        parcalar.append((k["kimlik_turu"], k["sira"], k["sinif_crc"], _kayit_bayt(k)))
    for uzay, sira, crc, b in parcalar:
        if len(out) >= _SAYAC_SINIRI:
            break
        if crc == KANITLI_SAYAC_CRC:
            # KANITLI sayac (silah_stat: A_SAYI yukunun 5. baytindaki u32 = uye sayisi).
            # Tarama sonucundan BAGIMSIZ bildirilir: deger kucuk oldugu icin
            # yukaridaki hedef kumesine hicbir zaman girmez, ama bayat kalabilir.
            d5 = (struct.unpack_from("<I", b, 5)[0] if len(b) >= 9 else None)
            out.append({"uzay": uzay, "sira": sira, "ofset": 5, "genislik": 4,
                        "deger": d5, "kanitli_sayac": True,
                        "sebep": "class 0x%08X is the one PROVEN count field in this "
                                 "format (member count = %s) and this edit did not "
                                 "rewrite it" % (KANITLI_SAYAC_CRC, d5)})
            continue
        for off, genislik, deger, sebep in _u_tara(b, hedef, _SAYAC_SINIRI - len(out)):
            out.append({"uzay": uzay, "sira": sira, "ofset": off, "genislik": genislik,
                        "deger": deger, "sebep": sebep, "kanitli_sayac": False})
    return out


# =====================================================================================
#  SARMALAYICI (silah_stat._ic_dosya_kur kalibi -- oyun ici testle ogrenilmis ders)
# =====================================================================================
def _boyut_alanini_duzelt(yeni, beklenen_boyut):
    """Sarmalayicinin [u32 boyut] alanini (ofset 4) yaz.

    AYRI fonksiyon, cunku bir KAPI: test K6 bunu sokup `_ic_dosya_kur`un kendi
    cozucu kontrolunun gercekten dustugunu olcer (uzunluk degisen govdede alan
    eski kalinca sarmalayici_coz ya tasma bildirir ya da esitlik tutmaz)."""
    struct.pack_into("<I", yeni, 4, beklenen_boyut)


def _ic_dosya_kur(ham, govde_off, yeni_govde):
    """Yeni govdeyi ic dosya SARMALAYICISIYLA birlestir, boyut alanini duzelt, kuyrugu koru.

    Bicim (forge_giris.sarmalayici_coz): boyut == len(ic_dosya) - 13 - adLen - kuyruk.
    `kuyruk` ORIJINALDEN olculur ve yeni dosyada da ayni sayida bayt boyutun
    disinda birakilir. Sonuc KENDI cozucumuzle geri okunur; esitlik tutmazsa
    ValueError -- hicbir sey yazilmaz.
    """
    # TEK KURUCU (v0.17): govde forge_giris.sarmalayici_kur'da. Boyut alanini hala
    # BU modulun `_boyut_alanini_duzelt`i yazar -- kanca cagri aninda modul
    # sozlugunden okunur, yani test K6'nin monkeypatch'i kapiyi hala sabote eder.
    return FG.sarmalayici_kur(ham, govde_off, yeni_govde,
                              duzelt=lambda y, b: _boyut_alanini_duzelt(y, b))


# =====================================================================================
#  OKUMA (salt) -- orijinal ic dosya, PAYLASILAN taniticiyla
# =====================================================================================
_TANITICI_DAMGA = {"id": None, "damga": None}


def _taze_tanitici(forge):
    """Paylasilan LeanForge -- arsiv ACILDIGINDAN BERI degistiyse yeniden acilir.

    OLCULDU (test K3, ilk kosu): kur_mesh.kur girisi dosyanin sonuna ekleyip TOC
    satirini yonlendirir, geri_al ise TOC'u eski yere cevirip kuyrugu KIRPAR. Bu
    arada acik kalan paylasilan tanitici ESKI TOC'u tasir; geri almadan sonra onunla
    okuyan cagri kirpilmis bolgeye gitti ve "not a BMS container" aldi. Ikinci bir
    tanitici ACILMAZ (Steam "Content file locked" dersi): bayatsa paylasilan olan
    birakilip AYNI yoldan yeniden acilir. Damga = (boyut, mtime_ns) + nesne kimligi."""
    st = os.stat(forge)
    damga = (st.st_size, st.st_mtime_ns)
    lf = C._forge()
    if _TANITICI_DAMGA["id"] != id(lf) or _TANITICI_DAMGA["damga"] != damga:
        C.release_forge(onbellek=True)
        lf = C._forge()
        _TANITICI_DAMGA["id"] = id(lf)
        _TANITICI_DAMGA["damga"] = damga
    return lf


def _orijinal_ic(gid, icid, forge):
    """Canli forge'dan ic dosyanin TAM baytlari (sarmalayici + govde + kuyruk).

    Ikinci bir dosya taniticisi ACILMAZ: explorer_core._baglam icinde
    outfit_core._forge() kullanilir (Steam "Content file locked" dersi); bayatsa
    `_taze_tanitici` onu ayni yoldan yeniler."""
    EX = _ex()
    with EX._baglam(forge) as yol:
        lf = _taze_tanitici(yol)
        if gid not in lf.by_id:
            raise KeyError("Entry %s is not in %s." % (_hex(gid), os.path.basename(forge)))
        return FG.ic_dosya(lf, gid, icid)


def _hedef_coz(agac, gid, icid):
    """XML kokundeki kimlik ile cagiranin verdigi kimlik -> (gid, icid, hata)."""
    x_gid = agac.get("gid")
    x_icid = agac.get("icid")
    if gid is None:
        gid = x_gid
    elif x_gid is not None and int(x_gid) != gid:
        return None, None, ("This XML says it was exported from entry %s, but %s was asked "
                            "for - refused. Nothing was written."
                            % (_hex(x_gid), _hex(gid)))
    if gid is None:
        return None, None, ("The XML carries no gid attribute and no entry id was given, "
                            "so there is no record of where these bytes belong. Export "
                            "the object again, or pass the entry id explicitly.")
    if icid is None:
        icid = x_icid
    elif x_icid is not None and int(x_icid) != icid:
        return None, None, ("This XML says it was exported from inner file %s, but %s was "
                            "asked for - refused. Nothing was written."
                            % (_hex(x_icid), _hex(icid)))
    return int(gid), int(icid), None


def _uzunluk_kapisi(orij, govde, icid):
    """CANLI uzunluk kapisi: arsivdeki govde ile yeni govde ayni boyda degilse mesaj.

    AYRI fonksiyon, cunku bir KAPI: test K6 bunu (ve nesne_xml'in kapisini) bilerek
    kapatip sarmalayici kurucusunun tek basina ne yaptigini olcer. Normal yolda
    HER ZAMAN calisir; None donerse yazma surebilir."""
    if len(govde) != len(orij):
        return ("This edit changes the length of the object body from %d to %d bytes; "
                "only same-length edits can be written back. The archive copy of inner "
                "file %s is %d bytes long, so this XML was either edited to a different "
                "length or exported from a different version of the archive. Nothing was "
                "written." % (len(orij), len(govde), _hex(icid), len(orij)))
    return None


# =====================================================================================
#  1) HAZIRLA -- yazmaz, farki olcer
# =====================================================================================
def xml_hazirla(xml_metni, gid=None, icid=None, forge=None, uzunluk_serbest=None):
    """XML -> yeni govde + yeni TAM ic dosya; arsivdeki orijinalle FARKI olcer. YAZMAZ.

    Doner {ok, gid, icid, forge, govde, orijinal, yeni_ic, orijinal_ic, degisen_bayt,
           degisen_yer:[[ofset, uzunluk, eski_hex, yeni_hex]], degisti, sarmalayici,
           mesaj, (satir, sutun)}
    ok=False iken `mesaj` INGILIZCE tam cumledir ve neden yazilamayacagini soyler.
    Ayni-uzunluk kurali BURADA canli arsive karsi uygulanir (bkz. modul basligi).

    UZMAN MODU: `uzunluk_serbest=True` (ya da None + kuresel `uzman` anahtari acik)
    uzunluk kapisini gecirir; sonuca `uzunluk` (kayit duzeyinde fark) ve
    `uzman_uyarilari` (bilinmeyen sayac taramasi dahil) eklenir. Kapali modda
    mesajlar HARFI HARFINE ayni kalir.
    """
    serbest = _uzunluk_serbest_mi(uzunluk_serbest)
    r = {"ok": False, "gid": None, "icid": None, "forge": None, "govde": None,
         "orijinal": None, "yeni_ic": None, "orijinal_ic": None, "degisen_bayt": 0,
         "degisen_yer": [], "degisti": False, "sarmalayici": None, "mesaj": None,
         "uzunluk": None, "degisen_kayit": [], "uzman_uyarilari": [],
         "uzman": serbest, "surum": SURUM}
    try:
        agac = X.xml_al(xml_metni, uzunluk_serbest=serbest)
    except X.XmlHatasi as e:
        r["mesaj"] = str(e)
        r["satir"], r["sutun"] = e.satir, e.sutun
        return r
    try:
        gid, icid, hata = _hedef_coz(agac, _int(gid), _int(icid))
    except (TypeError, ValueError) as e:
        r["mesaj"] = "The entry id is not a valid hexadecimal id (%s)." % e
        return r
    if hata:
        r["mesaj"] = hata
        return r
    r["gid"], r["icid"] = _hex(gid), _hex(icid)
    r["gid_sayi"], r["icid_sayi"] = gid, icid

    EX = _ex()
    forge = os.path.abspath(forge or EX.arsiv_yolu())
    r["forge"] = forge
    if not os.path.isfile(forge):
        r["mesaj"] = "Game archive not found: %s" % forge
        return r
    try:
        ham = _orijinal_ic(gid, icid, forge)
    except (KeyError, ValueError, AssertionError, struct.error) as e:
        r["mesaj"] = ("Inner file %s of entry %s could not be read from %s (%s), so there "
                      "is nothing to compare the XML against. Nothing was written."
                      % (_hex(icid), _hex(gid), os.path.basename(forge), str(e)[:160]))
        return r
    try:
        w0 = FG.sarmalayici_coz(ham)
    except (ValueError, struct.error, IndexError) as e:
        r["mesaj"] = ("Inner file %s of entry %s does not have the wrapper header this "
                      "writer knows (%s). Nothing was written." % (_hex(icid), _hex(gid), e))
        return r
    orij = ham[w0["govde_off"]:]
    govde = N.yaz(agac)
    r["orijinal"], r["govde"], r["orijinal_ic"] = orij, govde, ham
    r["sarmalayici"] = {"adLen": w0["adLen"], "flag": w0["flag"], "nid": w0["nid"],
                        "boyut": w0["boyut"], "kuyruk": w0["kuyruk"],
                        "govde_off": w0["govde_off"], "tip": w0["tip"]}
    # KAPI 1: uzunluk, CANLI arsive karsi (XML'in kendi iddiasina degil).
    if not serbest:
        hata = _uzunluk_kapisi(orij, govde, icid)
        if hata:
            r["mesaj"] = hata
            return r
    if len(govde) == len(orij):
        fark = _fark(orij, govde)
        r["degisen_yer"] = fark
        r["degisen_bayt"] = sum(p[1] for p in fark)
        r["degisti"] = bool(fark)
    else:
        # UZMAN YOLU: bayt araligi farki anlamsiz (tek ekleme her seyi kaydirir),
        # karsilastirma KAYIT duzeyine cikar.
        eski_agac, kayitlar = _fark_kayit(orij, agac, icid)
        r["degisen_kayit"] = kayitlar
        r["degisen_bayt"] = abs(len(govde) - len(orij))
        r["degisti"] = True
        xu = agac.get("uzunluk") or {}
        adaylar = _sayac_adaylari(eski_agac, kayitlar)
        r["uzunluk"] = {
            "eski": len(orij), "yeni": len(govde), "fark": len(govde) - len(orij),
            "kayitlar": kayitlar,
            "yeniden_numaralanan": int(xu.get("yeniden_numaralanan") or 0),
            "turetilmis_bosluk": list(xu.get("turetilmis_bosluk") or []),
            "ofset_uyusmazlik": int(xu.get("ofset_uyusmazlik") or 0),
            "sayac_adaylari": adaylar}
        if adaylar:
            sayac = (" - %d candidate count/length field(s) were NOT updated: %s"
                     % (len(adaylar), "; ".join("%s at +%d (%s)"
                                                % (("record %s/%d" % (a["uzay"], a["sira"]))
                                                   if a["sira"] is not None else "prefix",
                                                   a["ofset"], a["sebep"])
                                                for a in adaylar[:3])))
        else:
            sayac = (" - no stale count/length candidate was found, but the scan only "
                     "knows one proven count field, so this is not a clean bill of health")
        try:
            UZ = _uz()
            r["uzman_uyarilari"] = [UZ.uyari("uzunluk_degisimi", icid=_hex(icid),
                                             eski=len(orij), yeni=len(govde),
                                             fark=len(govde) - len(orij), sayac=sayac)]
            if r["uzunluk"]["turetilmis_bosluk"]:
                r["uzman_uyarilari"].append(
                    "Expert mode: %d derived object ordinal(s) are missing (%s) and "
                    "derived ordinals are NOT renumbered - the game can drop or "
                    "mis-address those objects. %s"
                    % (len(r["uzunluk"]["turetilmis_bosluk"]),
                       ", ".join(str(i) for i in r["uzunluk"]["turetilmis_bosluk"][:8]),
                       UZ.GERI_AL))
        except Exception as e:                              # noqa: BLE001
            r["uzman_uyarilari"] = [
                "Expert mode: the byte length of inner file %s changed from %d to %d "
                "(%+d) and the warning text could not be built (%s). Counts inside the "
                "object are yours to keep right. Revert puts it back."
                % (_hex(icid), len(orij), len(govde), len(govde) - len(orij), e)]
    # KAPI 2: sarmalayici -- boyut alani + kuyruk + kendi cozucuyle geri okuma.
    # (Uzunluk esitligi burada TEKRAR olculmez: len(yeni_ic) == len(ham) ancak ve ancak
    #  len(govde) == len(orij) -- o kapi yukarida `_uzunluk_kapisi`dir ve K3 onu olcer.
    #  Ayni kosulu ikinci kez, kapatilamayan bir satirla yazmak K6'nin "kurucu yerinde,
    #  kapilar kapali" olcumunu kor ediyordu: olculdu, 2026-09-08.)
    try:
        r["yeni_ic"] = _ic_dosya_kur(ham, w0["govde_off"], govde)
    except (ValueError, RuntimeError) as e:
        r["mesaj"] = str(e)
        return r
    r["ok"] = True
    if r["uzunluk"]:
        u = r["uzunluk"]
        r["mesaj"] = ("Expert mode: the object body changes length from %d to %d bytes "
                      "(%+d) in %d record(s); %d local ordinal(s) were re-numbered."
                      % (u["eski"], u["yeni"], u["fark"], len(u["kayitlar"]),
                         u["yeniden_numaralanan"]))
    elif r["degisen_yer"]:
        r["mesaj"] = ("%d byte(s) differ from the archive in %d place(s); the body length "
                      "(%d bytes) is unchanged." % (r["degisen_bayt"],
                                                    len(r["degisen_yer"]), len(govde)))
    else:
        r["mesaj"] = "The XML matches what is in the archive; there is nothing to write."
    return r


# =====================================================================================
#  2) YAZ -- TEK YAZICI uzerinden (explorer_core.geri_yukle -> kur_mesh.kur)
# =====================================================================================
def xml_yaz(xml_metni, gid=None, icid=None, forge=None, etiket="", progress=None,
            klasor=None, ustune=False, golge_yoksay=False, uzunluk_serbest=None):
    """XML'i oyuna yaz. Doner: explorer_core.geri_yukle sonucu + hazirlik ozeti.

    Zincir: xml_hazirla (uzunluk + sarmalayici + kimlik kapilari)
            -> explorer_core.disa_aktar(bicim="ham") gecici klasore (.bin + bilgi.json)
            -> .bin'in icine YENI ic dosya
            -> explorer_core.geri_yukle(klasor, gid, icid, etiket) [kilit / oyun acik /
               golge / bilgi.json kimlik / kur_mesh: yedek + WAL + dogrulama]
    `klasor` verilirse gecici dosyalar orada birakilir (inceleme icin); verilmezse
    sistem gecici dizininde acilir ve sonunda SILINIR.
    `ustune`: bu giriste zaten bizim yamamiz varsa uzerine yaz (explorer_core ile ayni).
    """
    t0 = time.time()
    r = {"ok": False, "bicim": None, "yazilan": [], "kayit": [], "mesaj": None,
         "sure": 0.0, "surum": SURUM, "hazirlik": None}
    # Yazma turu TAZE taniticiyla baslar: hazirlik, sahneleme (disa_aktar) ve kimlik
    # kapisi ayni TOC'u gormeli (bkz. _taze_tanitici).
    C.release_forge(onbellek=True)
    hz = xml_hazirla(xml_metni, gid, icid, forge, uzunluk_serbest=uzunluk_serbest)
    r["hazirlik"] = {k: hz.get(k) for k in ("ok", "gid", "icid", "forge", "degisen_bayt",
                                            "degisen_yer", "degisti", "sarmalayici",
                                            "mesaj", "satir", "sutun", "uzunluk",
                                            "degisen_kayit", "uzman_uyarilari", "uzman")}
    r["uzunluk"] = hz.get("uzunluk")
    r["uzman_uyarilari"] = list(hz.get("uzman_uyarilari") or [])
    r["degisen_kayit"] = list(hz.get("degisen_kayit") or [])
    r["forge"] = hz.get("forge")
    if not hz["ok"]:
        r["mesaj"] = hz["mesaj"]
        r["sure"] = round(time.time() - t0, 3)
        return r
    if not hz["degisti"]:
        r["mesaj"] = ("The XML matches what is in the archive; there is nothing to write. "
                      "Nothing was written.")
        r["sure"] = round(time.time() - t0, 3)
        return r
    gid, icid, forge = hz["gid_sayi"], hz["icid_sayi"], hz["forge"]
    EX = _ex()
    gecici = os.path.abspath(klasor) if klasor else tempfile.mkdtemp(prefix="nesne_yaz_")
    try:
        _log(progress, "- xml: %d byte(s) differ in inner file %s of %s"
             % (hz["degisen_bayt"], _hex(icid), _hex(gid)))
        d = EX.disa_aktar(gid, icid, klasor=gecici, bicim=EX.BICIM_HAM, forge=forge,
                          progress=progress)
        if not d.get("ok"):
            r["mesaj"] = d.get("mesaj") or "The entry could not be staged for writing."
            r["disa_aktar"] = {k: d.get(k) for k in ("mesaj", "bicim", "klasor")}
            return r
        if d.get("uyari"):
            r["uyari"] = d["uyari"]
        dosyalar = list(d.get("dosyalar") or [])
        if len(dosyalar) != 1:
            r["mesaj"] = ("Expected exactly one raw inner file for %s/%s, found %d - "
                          "refused. Nothing was written." % (_hex(gid), _hex(icid),
                                                             len(dosyalar)))
            return r
        bin_yol = dosyalar[0]
        # KAPI 3: disa aktarilan .bin, hazirlikta okunan orijinalle BIREBIR olmali.
        with open(bin_yol, "rb") as f:
            cikan = f.read()
        if cikan != hz["orijinal_ic"]:
            r["mesaj"] = ("The archive entry changed between reading and writing - refused. "
                          "Nothing was written.")
            return r
        with open(bin_yol, "wb") as f:
            f.write(hz["yeni_ic"])
        et = "%s %s/%s%s" % (ETIKET_ONEK, _hex(gid), _hex(icid),
                             (" " + str(etiket).strip()) if str(etiket or "").strip() else "")
        if hz.get("uzunluk"):
            # Etikete YAZ: Health Check / Revert listesi (kur_mesh.durum, explorer_core.durum)
            # boylece uzunluk degistiren yazmayi tek bakista gosterir.
            et += " expert len %d->%d" % (hz["uzunluk"]["eski"], hz["uzunluk"]["yeni"])
        uyarilar = list(r["uzman_uyarilari"])
        # explorer_core._geri_ham UZUNLUK DEGISIMINI ZATEN tasiyor (v0.16: sarmalayici
        # boyut alani + kuyruk korunur, kur_mesh K1/K2/TOC'u yeniden dizer). Ek bayrak
        # GECMEZ: kapi burada, xml_hazirla'da, uzman anahtariyla acilip kapaniyor.
        g = EX.geri_yukle(d["klasor"], gid=gid, icid=icid, forge=forge, etiket=et,
                          progress=progress, ustune=ustune, golge_yoksay=golge_yoksay)
        # geri_yukle sonucu OLDUGU GIBI tasinir (ok, mesaj, yazilan, kayit, golge, ...).
        for k, v in g.items():
            if k not in ("hazirlik",):
                r[k] = v
        for u in (g.get("uzman_uyarilari") or []):
            if u not in uyarilar:
                uyarilar.append(u)
        r["uzman_uyarilari"] = uyarilar
        r["uzunluk"] = hz.get("uzunluk")
        r["etiket"] = et
        r["klasor_gecici"] = d["klasor"]
        r["degisen_bayt"] = hz["degisen_bayt"]
        r["degisen_yer"] = hz["degisen_yer"]
        if r.get("ok") and hz.get("uzunluk"):
            r["mesaj"] = ("Inner file %s of entry %s was rewritten from %d to %d bytes "
                          "(%+d). Revert puts the original bytes back."
                          % (_hex(icid), _hex(gid), hz["uzunluk"]["eski"],
                             hz["uzunluk"]["yeni"], hz["uzunluk"]["fark"]))
        elif r.get("ok"):
            r["mesaj"] = ("%d byte(s) written into inner file %s of entry %s. Revert puts "
                          "the original bytes back." % (hz["degisen_bayt"], _hex(icid),
                                                        _hex(gid)))
        return r
    finally:
        # Yazdiktan sonra paylasilan tanitici BAYAT TOC tasir (kur_mesh girisi dosyanin
        # sonuna ekleyip TOC satirini yonlendirdi); bir sonraki okuma taze acsin.
        C.release_forge(onbellek=True)
        if not klasor:
            shutil.rmtree(gecici, ignore_errors=True)
        r["sure"] = round(time.time() - t0, 3)
