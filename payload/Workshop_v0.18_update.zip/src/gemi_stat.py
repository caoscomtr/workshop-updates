# -*- coding: utf-8 -*-
"""GEMI STAT -- ship stats: hull health per armour level, ram damage per level, Jackdaw speed.

silah_stat.py'nin ikizi: ayni dis kalip (katalog -> oku -> plan -> uygula -> geri_al ->
durum), ayni TEK YAZICI kurali. Topluluk "gemi canini / hizini degistiremezsin" diyordu;
2026-09-08 avi nesneleri bayt kanitiyla buldu (testler/senaryo_gemi_can.py kuru provasi:
600 -> 6000 = 3 bayt @0x27..0x29, govde 42 B sabit).

NEREDE DURUYORLAR (hepsi DataPC_boot.forge, patch golgesi YOK -- canli TOC'a bakilir):
  Gemi cani = kayitli govde zirhi esyalari; baslangic preseti L1 verir.
    NavalShipUpgradeStatsSettings_Health_L1..L5   sinif VehicleHealthItemStatsSettings
    (0x9998571D), govde 42 B: [..][u32 A_FLOAT crc 0x0CAB069A @0x21][01 @0x25][f32 @0x26]
    600 / 1200 / 2000 / 3200 / 5000
  Koc hasari
    NavalShipUpgradeStatsSettings_RamDamage_L0..L4  sinif 0x21EA68A4, AYNI 42 B yerlesim
    300 / 600 / 1200 / 2000 / 4000
  Hiz (azami hiz ADAYI -- oyun ici kanit HENUZ YOK)
    BoatAccelerationSettings_OBD_Jackdaw  govde 2652 B, onek f32 @0x01 = 14.0
    (oyuncu gemileri 14, AI 30, sandal 16); @0x06 = 8.0 hepsinde ayni (yerlesim tanigi).

NASIL YAZAR (ezber ofset YOK -- her sey canli govdeden okunur ve kapidan gecer):
  nesne_xml.xml_ver  -> XML (bu siniflarin semasi yok: govde <onek> hex blogu)
  nesne_xml.xml_al   -> agac; agac["onek"] icinde f32 degistirilir (ayni uzunluk)
  nesne_xml.xml_ver_agac -> yeni XML
  nesne_yaz.xml_hazirla  -> yeni govde + fark (YAZMAZ); burada UC KAPI:
        (1) uretilen govde == bizim bagimsiz beklentimiz (orijinal + 4 bayt f32)
        (2) 1..4 bayt degisti
        (3) degisen her parca [ofset, ofset+4) penceresinin ICINDE
  nesne_yaz.xml_yaz      -> explorer_core.geri_yukle -> kur_mesh.kur   (TEK YAZICI)
  yazdiktan sonra deger TAZE taniticiyla geri okunur; tutmazsa bu kosunun her yazmasi
  geri sarilir (explorer_core.geri_al).

Kayit etiketi: nesne_yaz "xml 0xGID/0xICID <etiket>" kurar, explorer_core onune
"explorer:" koyar. Bizim etiketimiz "ship stat <anahtar> <eski> -> <yeni>" ile baslar;
geri_al / durum YALNIZ bu etiketi tasiyan kayitlara bakar (Health Check ayirt eder).

Guvenlik: bu modulun KENDI YAZICISI YOKTUR ("r+b" burada gecmez). Oyun arsivine giden
tek yol nesne_yaz.xml_yaz'dir; kilit, "oyun acik", golge, yedek, WAL ve Revert oradan gelir.
Kullanici metinleri INGILIZCE; kod yorumlari TURKCE (ASCII).
"""
import math
import os
import re
import struct
import sys

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)

__all__ = ["KATALOG", "katalog", "oku", "hepsini_oku", "plan", "uygula", "geri_al",
           "durum", "SURUM", "ETIKET_ONEK", "SABIT_METINLER"]

SURUM = 1
FORGE_AD = "DataPC_boot.forge"
# Etiket oneki: nesne_yaz "xml gid/icid " + BU + " ..." kurar. Health Check ve geri_al
# bununla suzer; "weapon stats" / duz Explorer XML yazmalarindan ayrisir.
ETIKET_ONEK = "ship stat"
# Ic sinif kimligi (crc32("A_FLOAT" benzeri) -- silah_stat.A_FLOAT ile ayni olcum):
# 42 B'lik esya nesnelerinde f32'nin 5 bayt onunde durur, ardindan 01 gelir.
A_FLOAT = 0x0CAB069A

# ------------------------------------------------------------------ katalog
# "kapi": canli govdenin bu yerlesimde oldugunu KANITLAYAN yapisal kosullar. Oyun
# guncellenir ve govde degisirse oku() durustce duser ("stored differently ...").
_KAPI_42 = {"boy": 42, "crc_ofset": 0x21}
_KAPI_JACKDAW = {"boy": 2652, "surum_bayti": 0x01, "tanik": [(0x06, 8.0)]}

KATALOG = [
    {"anahtar": "hull_L1", "grup": "Hull armour", "seviye": 1,
     "ad": "Hull armour level 1", "birim": "HP",
     "gid": 0x220F05281B2, "icid": 0x22B2996A4A6, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 600.0, "kapi": _KAPI_42,
     "aciklama": "Ship health with hull armour level 1 - a new game starts here."},
    {"anahtar": "hull_L2", "grup": "Hull armour", "seviye": 2,
     "ad": "Hull armour level 2", "birim": "HP",
     "gid": 0x220F05281BA, "icid": 0x22B2996A4A9, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 1200.0, "kapi": _KAPI_42,
     "aciklama": "Ship health with hull armour level 2."},
    {"anahtar": "hull_L3", "grup": "Hull armour", "seviye": 3,
     "ad": "Hull armour level 3", "birim": "HP",
     "gid": 0x220F05281C2, "icid": 0x22B2996A4AF, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 2000.0, "kapi": _KAPI_42,
     "aciklama": "Ship health with hull armour level 3."},
    {"anahtar": "hull_L4", "grup": "Hull armour", "seviye": 4,
     "ad": "Hull armour level 4", "birim": "HP",
     "gid": 0x220F05281CA, "icid": 0x22B2996A4B2, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 3200.0, "kapi": _KAPI_42,
     "aciklama": "Ship health with hull armour level 4."},
    {"anahtar": "hull_L5", "grup": "Hull armour", "seviye": 5,
     "ad": "Hull armour level 5", "birim": "HP",
     "gid": 0x220F05281D2, "icid": 0x22B2996A4AC, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 5000.0, "kapi": _KAPI_42,
     "aciklama": "Ship health with hull armour level 5 - the last upgrade."},
    {"anahtar": "ram_L0", "grup": "Ram", "seviye": 0,
     "ad": "Ram level 0 (no upgrade)", "birim": "damage",
     "gid": 0x2374D5F69CC, "icid": 0x238F923C729, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 300.0, "kapi": _KAPI_42,
     "aciklama": "Ram damage before any ram upgrade is bought."},
    {"anahtar": "ram_L1", "grup": "Ram", "seviye": 1,
     "ad": "Ram level 1", "birim": "damage",
     "gid": 0x220F052C3DE, "icid": 0x22B2997FAC3, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 600.0, "kapi": _KAPI_42,
     "aciklama": "Ram damage with ram upgrade level 1."},
    {"anahtar": "ram_L2", "grup": "Ram", "seviye": 2,
     "ad": "Ram level 2", "birim": "damage",
     "gid": 0x220F052C3E6, "icid": 0x22B2997FDB3, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 1200.0, "kapi": _KAPI_42,
     "aciklama": "Ram damage with ram upgrade level 2."},
    {"anahtar": "ram_L3", "grup": "Ram", "seviye": 3,
     "ad": "Ram level 3", "birim": "damage",
     "gid": 0x220F052C3EE, "icid": 0x22B299800A3, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 2000.0, "kapi": _KAPI_42,
     "aciklama": "Ram damage with ram upgrade level 3."},
    {"anahtar": "ram_L4", "grup": "Ram", "seviye": 4,
     "ad": "Ram level 4", "birim": "damage",
     "gid": 0x220F052C3F6, "icid": 0x22B2998067F, "forge": FORGE_AD,
     "ofset": 0x26, "tip": "f32", "vanilla": 4000.0, "kapi": _KAPI_42,
     "aciklama": "Ram damage with ram upgrade level 4 - the last upgrade."},
    {"anahtar": "jackdaw_speed", "grup": "Jackdaw", "seviye": None,
     "ad": "Jackdaw speed", "birim": "",
     "gid": 0x218CC916B22, "icid": 0x218CC917B2F, "forge": FORGE_AD,
     "ofset": 0x01, "tip": "f32", "vanilla": 14.0, "kapi": _KAPI_JACKDAW,
     "aciklama": "Speed setting of the Jackdaw (player ships use 14, enemy ships 30). "
                 "The write is proven, the in-game effect is not yet."},
]
KATALOG_HARITA = dict((k["anahtar"], k) for k in KATALOG)

# Kullaniciya giden cumle KALIPLARI -- tek yerde, ceviri envanteri buradan toplar.
# {0} {1} yer tutuculari str.format ile doldurulur; arayuze hem dolu cumle hem de
# {"t": kalip, "a": [degerler]} bicimi gider (sunucu.py _bildir kalibi).
METIN = {
    "bilinmeyen": "Unknown ship stat: {0}.",
    "sayi_degil": "{0} cannot be set: {1} is not a number.",
    "sonlu_degil": "{0} cannot be set: the value must be a finite number.",
    "negatif": "{0} cannot be set to {1}: it cannot be negative.",
    "buyuk": "{0} cannot be set to {1}: the value is too large to store.",
    "arsiv_yok": "Game archive not found: {0}",
    "okunamadi": "{0} could not be read from {1} ({2}). Nothing was written.",
    "yerlesim": "{0} is stored differently in this game build than this tool expects "
                "({1}); refusing to touch it.",
    "golge": "{0} is also in {1}, which the game loads after {2}; the game would keep "
             "showing that copy, so nothing was written.",
    "ayni": "{0} is already {1}; nothing to change.",
    "xml_yok": "{0} could not be turned into an editable object ({1}). Nothing was written.",
    "yazici_red": "{0} cannot be written: {1}",
    "govde_uyusmaz": "{0} cannot be written: the rebuilt object does not match the "
                     "expected edit, so nothing was written.",
    "bayt_sayisi": "{0} cannot be written: {1} byte(s) would change, but a single value "
                   "edit changes 1 to 4 bytes. Nothing was written.",
    "pencere": "{0} cannot be written: a change would land outside the value's 4-byte "
               "window. Nothing was written.",
    "ozet": "{0} value(s) will change in {1}.",
    "ozet_red": "{0} value(s) will change in {1}; {2} refused.",
    "ozet_ayni": "Nothing to change - every value is already what you asked for.",
    "hic": "Nothing to change.",
    "red_var": "{0} value(s) were refused, so nothing was written: {1}",
    "yazildi": "{0} ship stat value(s) written to {1}. Start the game to see them; "
               "Revert puts the original numbers back.",
    "yazma_dustu": "Writing {0} failed: {1} {2} earlier write(s) of this run were rolled "
                   "back, so nothing is left half-done.",
    "geri_okuma": "{0} did not read back as {1} after writing; every write of this run "
                  "was rolled back.",
    "baska_yama": "{0} already carries a patch from another tool ({1}). Revert that first.",
    "geri_yok": "No ship stat change is installed in {0}.",
    "geri_alindi": "{0} of {1} ship stat change(s) reverted.",
    "geri_yabanci": "Patch {0} was not written by the ship stat tool - refused.",
    "durum": "{0} value(s) differ from the original game; {1} ship stat patch(es) installed.",
}

# arayuze giden sabit metinler (ceviri envanteri bunlari toplar)
SABIT_METINLER = ([k["ad"] for k in KATALOG] + [k["aciklama"] for k in KATALOG]
                  + sorted(set(k["grup"] for k in KATALOG))
                  + ["Ship stats", "Original", "Current", "New value",
                     "This value is not proven in-game yet."]
                  + list(METIN.values()))

# explorer_core.durum()'daki "aciklama" = etiket - "explorer:" =
# "xml 0xGID/0xICID ship stat <anahtar> <eski> -> <yeni> [ek]"
_ETIKET_RE = re.compile(r"^xml\s+0x[0-9A-Fa-f]+/0x[0-9A-Fa-f]+\s+" + re.escape(ETIKET_ONEK)
                        + r"(\s|$)")


# ------------------------------------------------------------------ yardimcilar
def _m(anahtar, *a):
    """(dolu cumle, {"t": kalip, "a": [...]}) -- arayuz ceviri icin ikisini de alir."""
    t = METIN[anahtar]
    return t.format(*a), {"t": t, "a": list(a)}


def _gost(v):
    """Sayiyi gosterim bicimine cevir: 600 -> '600', 1.12 -> '1.12'."""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if f != f or f in (float("inf"), float("-inf")):
        return str(f)
    if abs(f) >= 1e12:                      # 1e39 gibi tasan girdiler 40 haneli basilmasin
        return "%g" % f
    t = ("%.4f" % f).rstrip("0").rstrip(".")
    return t or "0"


def _esit(a, b):
    """Iki f32 degeri ayni mi (mutlak 1e-4 ya da goreli 1e-6 tolerans)."""
    try:
        a, b = float(a), float(b)
    except (TypeError, ValueError):
        return False
    return abs(a - b) <= max(1e-4, 1e-6 * max(abs(a), abs(b)))


def _yuvarla(v):
    return round(float(v), 4)


def _hex(x):
    return "0x%012X" % int(x)


def _cekirdek():
    import outfit_core as C
    return C


def _ex():
    import explorer_core as EX
    return EX


def _forge_yolu(forge=None):
    """Hedef arsivin TAM yolu. Verilmezse Outfits'in hedefi (DataPC_boot.forge).

    Explorer'in sectigi arsiv (explorer_core.arsiv_yolu) BILEREK kullanilmaz: kullanici
    Explorer'da baska bir forge'a bakiyor olabilir; gemi statlari boot'ta yasar."""
    if forge:
        return os.path.abspath(str(forge))
    C = _cekirdek()
    f = getattr(C, "FORGE", None)
    if not f:
        raise FileNotFoundError(METIN["arsiv_yok"].format("DataPC_boot.forge"))
    return os.path.abspath(f)


def _ic_dosya(gid, icid, forge):
    """Canli arsivden ic dosyanin TAM baytlari (sarmalayici + govde).

    nesne_yaz._orijinal_ic: paylasilan taniticiyi kullanir, arsiv yazildiysa (boyut /
    mtime damgasi) AYNI yoldan yeniden acar. Ikinci bir tanitici ACILMAZ (Steam
    "Content file locked" dersi) ve yazmadan sonra bayat TOC gorulmez."""
    import nesne_yaz as NY
    return NY._orijinal_ic(gid, icid, forge)


def _govde_al(k, forge):
    """(tam ic dosya, sarmalayici, govde)"""
    from export3d import forge_giris as FG
    ham = _ic_dosya(k["gid"], k["icid"], forge)
    w = FG.sarmalayici_coz(ham)
    return ham, w, ham[w["govde_off"]:]


def _yerlesim_kapisi(k, gv):
    """Canli govde katalogun bildigi yerlesimde mi? None = evet; yoksa INGILIZCE sebep."""
    kapi = k["kapi"]
    if len(gv) != kapi["boy"]:
        return "the object body is %d bytes, expected %d" % (len(gv), kapi["boy"])
    if k["ofset"] + 4 > len(gv):
        return "the value offset is past the end of the object"
    co = kapi.get("crc_ofset")
    if co is not None:
        crc = struct.unpack_from("<I", gv, co)[0]
        if crc != A_FLOAT or gv[co + 4] != 1 or co + 5 != k["ofset"]:
            return ("no decimal-stat marker in front of the value (found 0x%08X, flag %d)"
                    % (crc, gv[co + 4]))
    sb = kapi.get("surum_bayti")
    if sb is not None and gv[0] != sb:
        return "the object starts with 0x%02X, expected 0x%02X" % (gv[0], sb)
    for off, bek in kapi.get("tanik") or ():
        v = struct.unpack_from("<f", gv, off)[0]
        if not _esit(v, bek):
            return ("the neighbouring layout witness at offset %d reads %s, expected %s"
                    % (off, _gost(v), _gost(bek)))
    return None


def _deger_coz(k, v):
    """Istenen deger -> (f32'ye yuvarlanmis float, None) ya da (None, (sebep, kalip))."""
    ad = k["ad"]
    if v is None or isinstance(v, bool):
        return None, _m("sayi_degil", ad, repr(v))
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None, _m("sayi_degil", ad, repr(v))
    if math.isnan(f) or math.isinf(f):
        return None, _m("sonlu_degil", ad)
    if f < 0:
        return None, _m("negatif", ad, _gost(f))
    try:
        f32 = struct.unpack("<f", struct.pack("<f", f))[0]
    except (OverflowError, struct.error):
        return None, _m("buyuk", ad, _gost(f))
    if math.isinf(f32):
        return None, _m("buyuk", ad, _gost(f))
    return f32, None


# ------------------------------------------------------------------ katalog / okuma
def _katalog_girisi(k):
    """Kullaniciya giden katalog satiri: DUZ DIL, teknik kimlik (gid/icid/ofset) YOK."""
    return {"anahtar": k["anahtar"], "grup": k["grup"], "seviye": k["seviye"],
            "ad": k["ad"], "aciklama": k["aciklama"], "birim": k["birim"],
            "vanilla": k["vanilla"], "vanilla_metin": _gost(k["vanilla"]),
            "kanitli": k["anahtar"] != "jackdaw_speed"}


def katalog():
    """Duzenlenebilir gemi statlari (sabit liste; forge acilmaz)."""
    return [_katalog_girisi(k) for k in KATALOG]


def oku(anahtar, forge=None):
    """Tek statin CANLI degeri. SALT OKUMA.

    Doner {ok, anahtar, ad, grup, seviye, birim, vanilla, deger, deger_metin, degismis,
           golge, forge, mesaj}. ok=False iken `mesaj` INGILIZCE sebeptir.
    """
    k = KATALOG_HARITA.get(anahtar)
    if k is None:
        s, kal = _m("bilinmeyen", anahtar)
        return {"ok": False, "anahtar": anahtar, "mesaj": s, "mesaj_kalip": kal}
    r = dict(_katalog_girisi(k))
    r.update({"ok": False, "deger": None, "deger_metin": None, "degismis": False,
              "golge": None, "forge": None, "mesaj": None, "mesaj_kalip": None})
    try:
        forge = _forge_yolu(forge)
    except FileNotFoundError as e:
        r["mesaj"] = str(e)
        return r
    r["forge"] = os.path.basename(forge)
    if not os.path.isfile(forge):
        r["mesaj"], r["mesaj_kalip"] = _m("arsiv_yok", forge)
        return r
    try:
        _ham, _w, gv = _govde_al(k, forge)
    except (KeyError, ValueError, AssertionError, struct.error, OSError, IndexError) as e:
        r["mesaj"], r["mesaj_kalip"] = _m("okunamadi", k["ad"], os.path.basename(forge),
                                          str(e)[:160])
        return r
    hata = _yerlesim_kapisi(k, gv)
    if hata:
        r["mesaj"], r["mesaj_kalip"] = _m("yerlesim", k["ad"], hata)
        return r
    v = struct.unpack_from("<f", gv, k["ofset"])[0]
    r["deger"] = _yuvarla(v)
    r["deger_metin"] = _gost(v)
    r["degismis"] = not _esit(v, k["vanilla"])
    try:
        r["golge"] = _ex().golgeleyen(k["gid"], forge)
    except Exception as e:                                      # noqa: BLE001
        r["golge"] = {"golgede": False, "hata": str(e)[:160]}
    r["ok"] = True
    return r


def hepsini_oku(forge=None):
    """Katalogdaki HER stat icin oku(). Katalog sirasinda."""
    return [oku(k["anahtar"], forge) for k in KATALOG]


# ------------------------------------------------------------------ plan (yazmaz)
def _xml_duzenle(k, forge, yeni):
    """Canli nesneyi XML'e cevir, <onek> icindeki f32'yi degistir, XML'i yeniden uret.

    Uzunluk DEGISMEZ (4 bayt yerinde). Sema olmayan siniflarda govde tek <onek>
    blogudur; Jackdaw'da onek 11 B ve deger @0x01 onun icindedir (olculdu)."""
    import nesne_xml as X
    xml = X.xml_ver(k["gid"], k["icid"], forge=forge, adlar=False)
    agac = X.xml_al(xml)
    onek = bytearray(agac.get("onek") or b"")
    if k["ofset"] + 4 > len(onek):
        raise RuntimeError("the value is not inside the %d-byte object prefix this tool "
                           "edits" % len(onek))
    struct.pack_into("<f", onek, k["ofset"], yeni)
    agac["onek"] = bytes(onek)
    return X.xml_ver_agac(agac, adlar=False)


def _hazirlik_kapisi(k, hz, gv, yeni):
    """nesne_yaz.xml_hazirla sonucunu BAGIMSIZ beklentiyle karsilastir. None = gecti.

    AYRI fonksiyon, cunku bir KAPI: test K8 xml_hazirla'yi 'degisen_bayt=0' donduren bir
    sahteyle degistirir ve planin/uygulanin burada DUSTUGUNU olcer."""
    ad = k["ad"]
    if not isinstance(hz, dict) or not hz.get("ok"):
        return _m("yazici_red", ad, (hz or {}).get("mesaj") or "the writer refused this edit.")
    beklenen = bytearray(gv)
    struct.pack_into("<f", beklenen, k["ofset"], yeni)
    if hz.get("govde") != bytes(beklenen):
        return _m("govde_uyusmaz", ad)
    try:
        n = int(hz.get("degisen_bayt") or 0)
    except (TypeError, ValueError):
        n = 0
    yer = hz.get("degisen_yer") or []
    if not (1 <= n <= 4) or not yer or sum(int(p[1]) for p in yer) != n:
        return _m("bayt_sayisi", ad, n)
    lo, hi = k["ofset"], k["ofset"] + 4
    for p in yer:
        if not (lo <= int(p[0]) and int(p[0]) + int(p[1]) <= hi):
            return _m("pencere", ad)
    return None


def _plan_ic(degisiklikler, forge=None):
    """Plan + her is icin yazilacak XML (ic kullanim; plan() XML'i disari vermez)."""
    import nesne_yaz as NY
    out = {"ok": False, "isler": [], "red": [], "atlanan": [], "ozet": "",
           "ozet_kalip": None, "forge": None, "yazilacak": 0, "surum": SURUM}
    try:
        forge = _forge_yolu(forge)
    except FileNotFoundError as e:
        out["ozet"] = str(e)
        return out
    out["forge"] = os.path.basename(forge)
    if not os.path.isfile(forge):
        out["ozet"], out["ozet_kalip"] = _m("arsiv_yok", forge)
        return out
    istek = dict(degisiklikler or {})
    for a in list(istek):
        if a not in KATALOG_HARITA:
            s, kal = _m("bilinmeyen", a)
            out["red"].append({"anahtar": a, "sebep": s, "sebep_kalip": kal})
            istek.pop(a)
    for k in KATALOG:                                       # kararli sira
        a = k["anahtar"]
        if a not in istek:
            continue
        yeni, hata = _deger_coz(k, istek[a])
        if hata:
            out["red"].append({"anahtar": a, "sebep": hata[0], "sebep_kalip": hata[1]})
            continue
        c = oku(a, forge)
        if not c.get("ok"):
            out["red"].append({"anahtar": a, "sebep": c.get("mesaj"),
                               "sebep_kalip": c.get("mesaj_kalip")})
            continue
        g = c.get("golge") or {}
        if g.get("golgede"):
            s, kal = _m("golge", k["ad"], g.get("forge"), os.path.basename(forge))
            out["red"].append({"anahtar": a, "sebep": s, "sebep_kalip": kal})
            continue
        try:
            _ham, _w, gv = _govde_al(k, forge)
        except (KeyError, ValueError, AssertionError, struct.error, OSError, IndexError) as e:
            s, kal = _m("okunamadi", k["ad"], os.path.basename(forge), str(e)[:160])
            out["red"].append({"anahtar": a, "sebep": s, "sebep_kalip": kal})
            continue
        eski = struct.unpack_from("<f", gv, k["ofset"])[0]
        if _esit(eski, yeni):
            s, kal = _m("ayni", k["ad"], _gost(eski))
            out["atlanan"].append({"anahtar": a, "sebep": s, "sebep_kalip": kal})
            continue
        try:
            yeni_xml = _xml_duzenle(k, forge, yeni)
        except Exception as e:                                  # noqa: BLE001
            s, kal = _m("xml_yok", k["ad"], str(e)[:160])
            out["red"].append({"anahtar": a, "sebep": s, "sebep_kalip": kal})
            continue
        # uzunluk_serbest=False ACIKTIR: gemi duzenlemeleri AYNI UZUNLUKTA f32
        # yazmalaridir; kuresel uzman anahtari acik olsa bile bu yol kapali kalir.
        hz = NY.xml_hazirla(yeni_xml, k["gid"], k["icid"], forge=forge,
                            uzunluk_serbest=False)
        hata = _hazirlik_kapisi(k, hz, gv, yeni)
        if hata:
            out["red"].append({"anahtar": a, "sebep": hata[0], "sebep_kalip": hata[1]})
            continue
        out["isler"].append({"anahtar": a, "ad": k["ad"], "grup": k["grup"],
                             "birim": k["birim"],
                             "eski": _yuvarla(eski), "yeni": _yuvarla(yeni),
                             "eski_metin": _gost(eski), "yeni_metin": _gost(yeni),
                             "vanilla": k["vanilla"],
                             "degisen_bayt": int(hz["degisen_bayt"]),
                             "degisen_yer": list(hz["degisen_yer"]),
                             "_xml": yeni_xml, "_gid": k["gid"], "_icid": k["icid"]})
    n, r = len(out["isler"]), len(out["red"])
    out["yazilacak"] = n
    if r:
        out["ozet"], out["ozet_kalip"] = _m("ozet_red", n, out["forge"], r)
    elif n:
        out["ozet"], out["ozet_kalip"] = _m("ozet", n, out["forge"])
    elif out["atlanan"]:
        out["ozet"], out["ozet_kalip"] = _m("ozet_ayni")
    else:
        out["ozet"], out["ozet_kalip"] = _m("hic")
    out["ok"] = bool(n) and not r
    return out


def plan(degisiklikler, forge=None):
    """{anahtar: yeni_deger} -> ne yazilacaginin OZETI. HICBIR SEY YAZMAZ.

    Doner {ok, isler:[{anahtar, ad, eski, yeni, degisen_bayt, degisen_yer, ...}],
           red:[{anahtar, sebep, sebep_kalip}], atlanan:[...], ozet, ozet_kalip,
           yazilacak, forge}
    ok = en az bir is var VE hicbir istek reddedilmedi (hep-ya-da-hic).
    Reddetme: sayi degil / sonlu degil / negatif / f32'ye sigmiyor / okunamadi /
    yerlesim tanimadi / patch golgesinde / yazici kapilari.
    """
    p = _plan_ic(degisiklikler, forge)
    p["isler"] = [dict((kk, vv) for kk, vv in i.items() if not kk.startswith("_"))
                  for i in p["isler"]]
    return p


# ------------------------------------------------------------------ yazma
def _kayitlar(forge):
    """explorer_core kaydindaki AKTIF yamalardan yalniz bizim etiketimizi tasiyanlar."""
    d = _ex().durum(forge)
    return [y for y in (d.get("yamalar") or [])
            if _ETIKET_RE.match(str(y.get("aciklama") or ""))]


def _bizim_mi(kayit_id, forge):
    return any(y.get("id") == kayit_id for y in _kayitlar(forge))


def _geri_sar(kayitlar, forge):
    """Bu kosuda yazilanlari yeniden eskiye geri al -> [{id, ok, mesaj}]."""
    EX = _ex()
    out = []
    for kid in reversed(list(kayitlar)):
        g = EX.geri_al(kid, forge=forge)
        out.append({"id": kid, "ok": bool(g.get("ok")), "mesaj": g.get("mesaj")})
    try:
        _cekirdek().release_forge(onbellek=True)
    except Exception:                                           # noqa: BLE001
        pass
    return out


def uygula(degisiklikler, forge=None, etiket="", progress=None):
    """Plani oyuna yaz. TEK YAZICI: her is nesne_yaz.xml_yaz'dan gecer.

    Hep-ya-da-hic: plan reddedilmisse hicbir sey yazilmaz; bir yazma duserse ya da geri
    okuma istenen degeri gostermezse bu kosunun her yazmasi geri sarilir ve ok=False.
    Doner {ok, yazilan:[{anahtar, eski, yeni, degisen_bayt, kayit}], kayit:[...],
           geri_sarilan:[...], mesaj, mesaj_kalip, plan}
    """
    import nesne_yaz as NY
    C = _cekirdek()
    r = {"ok": False, "yazilan": [], "kayit": [], "geri_sarilan": [], "mesaj": "",
         "mesaj_kalip": None, "plan": None, "surum": SURUM}
    p = _plan_ic(degisiklikler, forge)
    r["plan"] = dict((kk, vv) for kk, vv in p.items() if kk != "isler")
    r["plan"]["isler"] = [dict((kk, vv) for kk, vv in i.items() if not kk.startswith("_"))
                          for i in p["isler"]]
    if p["red"]:
        r["mesaj"], r["mesaj_kalip"] = _m("red_var", len(p["red"]),
                                          " ".join(x["sebep"] for x in p["red"]))
        return r
    if not p["isler"]:
        r["mesaj"], r["mesaj_kalip"] = (p["ozet"], p["ozet_kalip"]) if p["ozet"] else _m("hic")
        return r
    forge = _forge_yolu(forge)
    ek = (" " + str(etiket).strip()) if str(etiket or "").strip() else ""
    n = len(p["isler"])
    for i, is_ in enumerate(p["isler"]):
        C._log(progress, "- %s %s: %s -> %s  (%d / %d)"
               % (ETIKET_ONEK, is_["anahtar"], is_["eski_metin"], is_["yeni_metin"], i + 1, n))
        et = "%s %s %s -> %s%s" % (ETIKET_ONEK, is_["anahtar"], is_["eski_metin"],
                                   is_["yeni_metin"], ek)
        w = NY.xml_yaz(is_["_xml"], is_["_gid"], is_["_icid"], forge=forge, etiket=et,
                       progress=progress, uzunluk_serbest=False)
        if not w.get("ok"):
            mevcut = (w.get("basarisiz") or {}).get("mevcut_yama")
            if mevcut:
                if _bizim_mi(mevcut, forge):
                    # ayni stat ikinci kez degisiyor: kendi yamamizin USTUNE yaz
                    w = NY.xml_yaz(is_["_xml"], is_["_gid"], is_["_icid"], forge=forge,
                                   etiket=et, progress=progress, ustune=True,
                                   uzunluk_serbest=False)
                else:
                    w = dict(w)
                    w["mesaj"], w["mesaj_kalip"] = _m("baska_yama", is_["ad"], mevcut)
        if not w.get("ok"):
            r["geri_sarilan"] = _geri_sar(r["kayit"], forge)
            r["mesaj"], r["mesaj_kalip"] = _m("yazma_dustu", is_["ad"],
                                              w.get("mesaj") or "the archive could not be "
                                                                 "written.",
                                              len(r["geri_sarilan"]))
            r["hata"] = {"anahtar": is_["anahtar"], "mesaj": w.get("mesaj")}
            return r
        kayit = list(w.get("kayit") or [])
        r["kayit"].extend(kayit)
        r["yazilan"].append({"anahtar": is_["anahtar"], "ad": is_["ad"],
                             "eski": is_["eski"], "yeni": is_["yeni"],
                             "eski_metin": is_["eski_metin"], "yeni_metin": is_["yeni_metin"],
                             "degisen_bayt": w.get("degisen_bayt", is_["degisen_bayt"]),
                             "kayit": kayit, "etiket": w.get("etiket")})
    # GERI OKUMA KAPISI: taze taniticiyla her deger istenen sayiyi gostermeli.
    for is_ in p["isler"]:
        c = oku(is_["anahtar"], forge)
        if not c.get("ok") or not _esit(c.get("deger"), is_["yeni"]):
            r["geri_sarilan"] = _geri_sar(r["kayit"], forge)
            r["mesaj"], r["mesaj_kalip"] = _m("geri_okuma", is_["ad"], is_["yeni_metin"])
            r["hata"] = {"anahtar": is_["anahtar"], "okunan": c.get("deger"),
                         "mesaj": c.get("mesaj")}
            r["yazilan"], r["kayit"] = [], []
            return r
    r["ok"] = True
    r["mesaj"], r["mesaj_kalip"] = _m("yazildi", len(r["yazilan"]), os.path.basename(forge))
    C._log(progress, "SUCCESS: %d ship stat value(s) written; every write is in the undo "
                     "record." % len(r["yazilan"]))
    return r


def geri_al(forge=None, kayit_id=None):
    """Bizim yamalarimizi geri al (explorer_core.geri_al sozlesmesi).

    kayit_id verilmezse etiketi "ship stat" ile baslayan TUM aktif kayitlar, yeniden
    eskiye. Baska bir aracin (Outfits / Weapon stats / duz Explorer XML) yamasi ASLA
    geri alinmaz.
    Doner {ok, geri_alinan, istenen, sonuclar:[{id, ok, mesaj}], kuyruk_bayt, mesaj}
    """
    EX = _ex()
    try:
        forge = _forge_yolu(forge)
    except FileNotFoundError as e:
        return {"ok": False, "geri_alinan": 0, "istenen": 0, "sonuclar": [], "mesaj": str(e)}
    benim = _kayitlar(forge)
    if kayit_id:
        if not any(y.get("id") == kayit_id for y in benim):
            s, kal = _m("geri_yabanci", kayit_id)
            return {"ok": False, "geri_alinan": 0, "istenen": 0, "sonuclar": [],
                    "mesaj": s, "mesaj_kalip": kal}
        hedefler = [kayit_id]
    else:
        hedefler = [y["id"] for y in benim][::-1]
    if not hedefler:
        s, kal = _m("geri_yok", os.path.basename(forge))
        return {"ok": False, "geri_alinan": 0, "istenen": 0, "sonuclar": [],
                "mesaj": s, "mesaj_kalip": kal}
    sonuc, kac = [], 0
    for kid in hedefler:
        g = EX.geri_al(kid, forge=forge)
        sonuc.append({"id": kid, "ok": bool(g.get("ok")), "mesaj": g.get("mesaj"),
                      "kuyruk_bayt": g.get("kuyruk_bayt")})
        kac += 1 if g.get("ok") else 0
    try:
        _cekirdek().release_forge(onbellek=True)
    except Exception:                                           # noqa: BLE001
        pass
    s, kal = _m("geri_alindi", kac, len(hedefler))
    out = {"ok": kac == len(hedefler), "geri_alinan": kac, "istenen": len(hedefler),
           "sonuclar": sonuc, "mesaj": s, "mesaj_kalip": kal}
    try:
        from export3d import kur_mesh as KM
        out["kuyruk_bayt"] = KM.kuyruk_bayt(forge)
    except Exception:                                           # noqa: BLE001
        out["kuyruk_bayt"] = None
    return out


def durum(forge=None):
    """Canli durum: hangi statlar vanilladan sapmis + kac bizim kaydimiz kurulu.

    Doner {ok, forge, degismis_anahtarlar, okunamayan, kayit_sayisi, kayitlar, yamali,
           mesaj, mesaj_kalip}
    `degismis_anahtarlar` CANLI degere bakar (kayda degil): baska bir yol da degistirmis
    olsa gorunur. `kayit_sayisi` yalniz bizim etiketimizi tasiyan aktif yamalardir.
    """
    try:
        forge = _forge_yolu(forge)
    except FileNotFoundError as e:
        return {"ok": False, "forge": None, "degismis_anahtarlar": [], "okunamayan": [],
                "kayit_sayisi": 0, "kayitlar": [], "yamali": False, "mesaj": str(e)}
    okunan = hepsini_oku(forge)
    degismis = [c["anahtar"] for c in okunan if c.get("ok") and c.get("degismis")]
    okunamayan = [{"anahtar": c["anahtar"], "mesaj": c.get("mesaj")}
                  for c in okunan if not c.get("ok")]
    try:
        kayitlar = _kayitlar(forge)
    except Exception as e:                                      # noqa: BLE001
        kayitlar = []
        okunamayan.append({"anahtar": "*", "mesaj": str(e)[:200]})
    s, kal = _m("durum", len(degismis), len(kayitlar))
    return {"ok": True, "forge": os.path.basename(forge), "degismis_anahtarlar": degismis,
            "okunamayan": okunamayan, "kayit_sayisi": len(kayitlar),
            "kayitlar": [{"id": y.get("id"), "zaman": y.get("zaman"),
                          "aciklama": y.get("aciklama"), "gid": y.get("gid"),
                          "icid": y.get("icid")} for y in kayitlar],
            "yamali": bool(kayitlar), "mesaj": s, "mesaj_kalip": kal}


if __name__ == "__main__":                                      # elle yoklama (salt okuma)
    import json
    print(json.dumps({"katalog": katalog(), "canli": hepsini_oku(), "durum": durum()},
                     indent=1, default=str))
