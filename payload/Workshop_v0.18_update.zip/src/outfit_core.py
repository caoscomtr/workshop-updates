# -*- coding: utf-8 -*-
"""
OUTFIT WORKSHOP - cekirdek motor  (v0.1)
=========================================
Assassin's Creed IV Black Flag RESYNCED icin KIYAFET dokusu tasarim araci.
"Sail Workshop"un kiyafet karsiligi. Bu modul GUI'nin altinda calisan motordur.

TASARIM KURALLARI (Sail Workshop derslerinden + fizibiliteden):
  * OKUMA  tarafi: forge yalnizca open(path,"rb") ile OKUNUR. Oyun BASLATILMAZ.
  * YAZMA  tarafi: TEK YAZICI = doku_enjekte2.py (slot-bilincli enjektor). Bu modul
    forge'a KENDISI YAZMAZ; PNG'leri DDS'e cevirip doku_enjekte2'yi cagirir.
  * sail_engine yazma tarafi (rebuild_entry/apply_design/backup) HIC kullanilmaz ->
    cift-yedek / araclar-arasi TOC catismasi riski YOK.
  * 190 B TABAN KAYMASI: sail_engine.resource()=block1+block2, yalin_forge.decompress()
    =block2. Bu modul okuma icin YALNIZ yalin_forge modelini (doku_enjekte2 ile ayni)
    kullanir; sail_engine.layout()/resource() KIYAFETTE cagrilmaz. verify_base_shift()
    bunu bellekte round-trip ile "safe/unsafe" olarak KANITLAR.
  * FLIP YOK. Export mevcut dosyanin ustune yazmaz. Yanlis boyut reddedilmez,
    yeniden boyutlandirilir + uyari. sRGB/gAMA profili atilir.

KATALOG: 12 kiyafet (PLAN.md v1). Her kiyafet TEK EntityGroup birimi (asla birlesim).
Modulun icine GOMULU (CATALOG). Forge'dan salt-okunur dogrulandi: 440/440 slot birebir.
"""
import os, sys, re, glob, json, struct, tempfile, subprocess, hashlib

# ----------------------------------------------------------------- ortam / yollar
GAME_DEFAULT = r"C:\Program Files (x86)\Steam\steamapps\common\Assassin's Creed Black Flag Resynced"
_DE_DIR   = os.path.dirname(os.path.abspath(__file__))
_SCR_DIR  = os.path.dirname(os.path.abspath(__file__))
_TOOLS    = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools")   # TexEncode.exe
for _p in (_DE_DIR, _SCR_DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import doku_enjekte2 as DE          # TEK YAZICI + slot cozumleme (olculmus, calisan)
from yalin_forge import LeanForge, decompress, read_block   # okuma tabani (block2)

FORGE = DE.FORGE                    # DataPC_boot.forge (doku_enjekte2 ile AYNI hedef)
TOOLS_DIR = _TOOLS


# ----------------------------------------------------------------- oyun bulma
# Sail Workshop (sail_engine.find_game) ile BIREBIR ayni mantik: kullanicinin
# Steam-disi surumleri (Ubi Store, farkli kutuphane surucu) icin oyunu tarar ya
# da GUI'den elle sectirir. Bulunan/secilen klasor HEM okuma (outfit_core.FORGE)
# HEM yazma (DE.FORGE / DE.GAME) yoluna set edilir; ikisi ayrilirsa okuma dogru,
# yazma sabit yanlis forge'a gider. DE fonksiyonlari (durum/uygula/gerial) modul
# global DE.FORGE'u CAGRI ANINDA okur (import-aninda sabitlemez), bu yuzden
# runtime'da DE.FORGE'u degistirmek yazma yolunu da dogru forge'a tasir.
FORGE_NAME = "DataPC_boot.forge"
OYUN_ADI = "Assassin's Creed Black Flag Resynced"

# Secilen oyun klasoru burada saklanir. Ne Outfit ne de Sail Workshop bunu
# yapiyordu: oyunu otomatik bulunamayan bir kullanici (Ubisoft Connect, D:
# surucusu, tasinmis kutuphane) HER ACILISTA elle secmek zorunda kaliyordu --
# "her seferinde oyunu baglamam gerekiyor" diye bildirildi.
AYAR_DOSYA = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
                          "OutfitWorkshop", "config.json")


def _kayitli_oyun():
    try:
        with open(AYAR_DOSYA, encoding="utf-8") as f:
            p = json.load(f).get("game")
        return [p] if p else []
    except Exception:
        return []


def _kayitli_oyun_yaz(path):
    try:
        os.makedirs(os.path.dirname(AYAR_DOSYA), exist_ok=True)
        with open(AYAR_DOSYA, "w", encoding="utf-8") as f:
            json.dump({"game": path}, f, indent=1)
    except Exception as e:                                      # noqa: BLE001
        print("config yazilamadi (zararsiz): %s" % e)


def _steam_libraries():
    """Steam kutuphane klasorlerini yerel kurulumdan oku (varsa)."""
    paths = []
    try:
        import winreg
        for root, sub in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
                          (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam")):
            try:
                with winreg.OpenKey(root, sub) as k:
                    p = winreg.QueryValueEx(k, "SteamPath")[0]
                    paths.append(p.replace("/", "\\"))
            except OSError:
                pass
    except Exception:
        pass
    extra = []
    for p in paths:
        vdf = os.path.join(p, "steamapps", "libraryfolders.vdf")
        if os.path.isfile(vdf):
            try:
                text = open(vdf, encoding="utf-8", errors="ignore").read()
                extra += [m.replace("\\\\", "\\")
                          for m in re.findall(r'"path"\s+"([^"]+)"', text)]
            except Exception:
                pass
    return paths + extra


def find_game(manual=None):
    """Oyun klasorunu bul. `manual` verilirse once o denenir. Steam kutuphaneleri
    (libraryfolders.vdf) + C..H surucude yaygin Steam/Ubi yollari taranir. Bir
    aday gecerli sayilir ancak icinde DataPC_boot.forge dosyasi VARSA. Ilk tutan
    klasor dondurulur, hicbiri tutmazsa None."""
    # ELLE SECIM ASLA OTOMATIGE DUSMEZ. Eskiden `manual` sadece listenin basina
    # eklenen bir adaydi: yanlis bir klasor secen kullaniciya sessizce BASKA bir
    # kurulum baglaniyor, "secilen klasorde forge yok" uyarisi hic gorunmuyordu.
    # Iki oyun kurulumu olan biri bir kuruluma bakip digerine yazabilirdi.
    if manual:
        return check_game(manual)

    for c in _aday_yollar():
        if c and os.path.isfile(os.path.join(c, FORGE_NAME)):
            return c
    return None


def _yerel_surucu(d):
    """Surucu harfi tahmin taramasina girmeli mi? AG surucusu (kopuk olabilir) ve optik surucu
    DISARIDA: kopuk bir ag surucusunde os.path.isfile saniyelerce takilir (2026-10-12, Nexus
    ryanryanx1 "not responding when choosing the game folder"). Windows disinda hep True.
    Steam kutuphanesi listesi (libraryfolders.vdf) bu suzgece TABI DEGILDIR."""
    try:
        import ctypes
        tip = ctypes.windll.kernel32.GetDriveTypeW(d + ":" + os.sep)
    except Exception:                                           # noqa: BLE001
        return True
    return tip in (2, 3, 6)            # cikarilabilir, sabit, RAM disk


def _aday_yollar():
    """find_game / find_games icin aday klasorler (sirali, kontrolsuz)."""
    candidates = list(_kayitli_oyun())
    for lib in _steam_libraries():
        candidates.append(os.path.join(lib, "steamapps", "common", OYUN_ADI))
    candidates += _ubisoft_kokleri()
    for d in "CDEFGH":
        if not _yerel_surucu(d):
            continue
        candidates += [
            r"%s:\Program Files (x86)\Steam\steamapps\common\%s" % (d, OYUN_ADI),
            r"%s:\Steam\steamapps\common\%s" % (d, OYUN_ADI),
            r"%s:\SteamLibrary\steamapps\common\%s" % (d, OYUN_ADI),
            r"%s:\Games\steamapps\common\%s" % (d, OYUN_ADI),
            # Ubisoft Connect: 32-bit Program Files varyanti EKSIKTI -- bu makinede
            # Launcher gercekten "Program Files (x86)" altinda kurulu.
            r"%s:\Program Files\Ubisoft\Ubisoft Game Launcher\games\%s" % (d, OYUN_ADI),
            r"%s:\Program Files (x86)\Ubisoft\Ubisoft Game Launcher\games\%s" % (d, OYUN_ADI),
            r"%s:\Ubisoft\Ubisoft Game Launcher\games\%s" % (d, OYUN_ADI),
            r"%s:\Program Files\Epic Games\%s" % (d, OYUN_ADI),
            r"%s:\Epic Games\%s" % (d, OYUN_ADI),
            r"%s:\XboxGames\%s\Content" % (d, OYUN_ADI),
        ]
    return candidates


def find_games():
    """Bu bilgisayarda bulunan TUM gecerli kurulumlar (tekil, sirali). Oyun klasoru paneli
    bunu listeler; kullanici Windows klasor penceresine mecbur kalmaz."""
    gorulen, out = set(), []
    for c in _aday_yollar():
        if not c:
            continue
        k = os.path.normcase(os.path.abspath(c))
        if k in gorulen:
            continue
        gorulen.add(k)
        if os.path.isfile(os.path.join(c, FORGE_NAME)):
            out.append(os.path.abspath(c))
    return out


def check_game(path):
    """Bu klasor GERCEKTEN oyun mu? Oyleyse yolu, degilse None doner. Tarama YAPMAZ."""
    if path and os.path.isfile(os.path.join(path, FORGE_NAME)):
        return path
    return None


def _ubisoft_kokleri():
    """Ubisoft Connect'in kurulu oldugu yeri kayit defterinden ogren."""
    yollar = []
    try:
        import winreg
    except ImportError:
        return yollar
    for kok, anahtar in ((winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Ubisoft\Launcher"),
                         (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Ubisoft\Launcher")):
        try:
            with winreg.OpenKey(kok, anahtar) as k:
                d = winreg.QueryValueEx(k, "InstallDir")[0]
            if d:
                yollar.append(os.path.join(d, "games", OYUN_ADI))
        except OSError:
            pass
    # her oyunun kendi InstallDir'i ayrica kayitli olabilir
    for kok, anahtar in ((winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs"),
                         (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Ubisoft\Launcher\Installs")):
        try:
            with winreg.OpenKey(kok, anahtar) as k:
                for i in range(winreg.QueryInfoKey(k)[0]):
                    try:
                        with winreg.OpenKey(k, winreg.EnumKey(k, i)) as alt:
                            d = winreg.QueryValueEx(alt, "InstallDir")[0]
                        if d:
                            yollar.append(d)
                    except OSError:
                        pass
        except OSError:
            pass
    return yollar


def set_game(path, kaydet=True):
    """Secilen oyun klasorunu HEM okuma HEM yazma yoluna uygula.
      * outfit_core.FORGE  -> okuma (LeanForge, _forge())
      * DE.FORGE / DE.GAME -> yazma (doku_enjekte2.durum/uygula/gerial)
    Okuma onbellegini (_LF, _RES_CACHE) temizler ki yeni forge okunsun.
    `path` gecersizse (forge yok) ValueError firlatir; FORGE degismez."""
    global FORGE, _LF, _RES_CACHE
    # Yazma suruyorken oyun klasorunu DEGISTIRME. `uygula` FORGE/KAYIT/YEDEK'i
    # her materyalde modul-globalinden yeniden okuyor, dolayisiyla is ortasinda
    # yon degistirmek yazimlarin bir kismini BASKA kuruluma gonderir ve iki
    # kurulumun da geri-alma kaydini bozar.
    if getattr(DE, "yaziyor_mu", lambda: False)():
        raise RuntimeError("A write is in progress - cannot switch game folder now.")
    forge = os.path.join(path, FORGE_NAME)
    if not os.path.isfile(forge):
        raise ValueError("DataPC_boot.forge not found in: %s" % path)
    FORGE = forge
    DE.GAME = path
    DE.FORGE = forge          # DE fonksiyonlari FORGE'u cagri aninda okur -> yazma da buraya gider
    # Geri-alma verisi FORGE KIMLIGINE gore anahtarli duruyor: oyun klasoru
    # degisince kayit/yedek yollari da o kuruluma ait olanlara donmeli, yoksa
    # bir kurulumun kaydiyla digerine geri alma denenir.
    if hasattr(DE, "veri_yolu_ayarla"):
        DE.veri_yolu_ayarla()
    # config'e YALNIZCA kullanici bilincli sectiginde yaz. Modul import aninda
    # otomatik arama yapip set_game cagiriyor; kaydetseydi ikinci bir kurulumu
    # olan kullanicinin BILINCLI secimi, arama sonucu ne cikarsa onunla EZILIRDI
    # (D7'nin "elle secim asla otomatige dusmez" guvencesini geri alirdi).
    if kaydet:
        _kayitli_oyun_yaz(path)
    _LF = None                # okuma onbellegini bosalt: yeni forge acilsin
    _RES_CACHE = {}
    return forge


def game_found():
    """Su an ayarli forge gercekten var mi? (GUI acilis kontrolu)."""
    return os.path.isfile(FORGE)

# ----------------------------------------------------------------- gomulu katalog
_CATALOG_JSON = r"""[{"ad":"Edward_Assassin","gorunen_ad":"Edward Kenway's Robes","EG_id":"0x23EDD08F45A","sinif":"flagship","guvenlik_puani":0.0,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x2128A456A2D","parca_adi":"Necklace","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x257340FC0BE","W":512,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Necklace_U_EdSailor_DiffuseMap"},{"idx":1,"doku_id":"0x257340FC0C2","W":256,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Necklace_U_EdSailor_EmissiveMap"},{"idx":2,"doku_id":"0x257340FC0C4","W":32,"H":64,"aile":"BC1","srgb":0,"mip":7,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Necklace_U_EdSailor_Mask1Map"},{"idx":3,"doku_id":"0x257340FC0C6","W":512,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Necklace_U_EdSailor_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_PirateCloak","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0A877","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AB0A","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB0E","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB10","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB12","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AB73","parca_adi":"(no editable texture) 1","boot_forge_icinde":true,"slot_sayisi":0,"slotlar":[],"paylasim":{"renk":"SARI","kapsam":"also changes 3 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Diplomat","U_Edward_Naoe","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[],"dokusuz":true},{"mat_id":"0x22D90B0ABE4","parca_adi":"(no editable texture) 2","boot_forge_icinde":true,"slot_sayisi":0,"slotlar":[],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[],"dokusuz":true},{"mat_id":"0x22D90B0AC48","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AB15","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB19","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB1B","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB1D","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Diplomat","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC7A","parca_adi":"(no editable texture) 3","boot_forge_icinde":true,"slot_sayisi":0,"slotlar":[],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Diplomat","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[],"dokusuz":true},{"mat_id":"0x22D90B0ACAC","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AB2B","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB2F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB31","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB33","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Diplomat","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24906BD5384","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x255E553F20A","W":256,"H":256,"aile":"BC3","srgb":1,"mip":9,"harici_mip":1,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x255E553F20E","W":128,"H":128,"aile":"BC3","srgb":0,"mip":8,"harici_mip":0,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x255E553F210","W":128,"H":128,"aile":"BC1","srgb":0,"mip":8,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x255E553F212","W":256,"H":256,"aile":"BC7","srgb":0,"mip":9,"harici_mip":1,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Yasuke","gorunen_ad":"Yasuke's Outfit","EG_id":"0x24E8EF8930B","sinif":"A","guvenlik_puani":98.8,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x23040ECC8FC","parca_adi":"Utils 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACDC","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Utils_YasukeIconic_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACE0","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Utils_YasukeIconic_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACE2","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Utils_YasukeIconic_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACE4","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Utils_YasukeIconic_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCA2F","parca_adi":"Utils 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACD2","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Utils_PlayerYasuke_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACD6","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Utils_PlayerYasuke_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACD8","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Utils_PlayerYasuke_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACDA","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Utils_PlayerYasuke_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCA62","parca_adi":"Straps","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACC8","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Straps_YasukeIconic_Kusazuri_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACCC","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Straps_YasukeIconic_Kusazuri_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACCE","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Straps_YasukeIconic_Kusazuri_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACD0","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Straps_YasukeIconic_Kusazuri_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCA95","parca_adi":"Strap","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACBE","W":16,"H":16,"aile":"BC3","srgb":1,"mip":5,"harici_mip":0,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Strap_Yasuke_LayeringFix_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACC2","W":8,"H":8,"aile":"BC3","srgb":0,"mip":4,"harici_mip":0,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Strap_Yasuke_LayeringFix_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACC4","W":8,"H":8,"aile":"BC1","srgb":0,"mip":4,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Strap_Yasuke_LayeringFix_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACC6","W":16,"H":16,"aile":"BC7","srgb":0,"mip":5,"harici_mip":0,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Strap_Yasuke_LayeringFix_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCAC8","parca_adi":"Skirt","boot_forge_icinde":true,"slot_sayisi":8,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACB4","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Skirt_YasukeIconic_Haidate_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACB8","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Skirt_YasukeIconic_Haidate_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACBA","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Skirt_YasukeIconic_Haidate_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACBC","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Skirt_YasukeIconic_Haidate_Custo_NormalMap"},{"idx":4,"doku_id":"0x243F4D7ED5C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Skirt_YasukeIconic_Haidate_DiffuseMap"},{"idx":5,"doku_id":"0x243F4D7ED60","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Skirt_YasukeIconic_Haidate_EmissiveMap"},{"idx":6,"doku_id":"0x243F4D7ED62","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Skirt_YasukeIconic_Haidate_Mask1Map"},{"idx":7,"doku_id":"0x243F4D7ED64","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Skirt_YasukeIconic_Haidate_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCAFB","parca_adi":"Shoulders 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACAA","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Shoulders_Sode_YasukeIconic_Utils_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACAE","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Shoulders_Sode_YasukeIconic_Utils_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACB0","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Shoulders_Sode_YasukeIconic_Utils_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACB2","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Shoulders_Sode_YasukeIconic_Utils_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCB2E","parca_adi":"Shoulders 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6ACA0","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Shoulders_Sode_YasukeIconic_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6ACA4","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Shoulders_Sode_YasukeIconic_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6ACA6","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Shoulders_Sode_YasukeIconic_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6ACA8","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Shoulders_Sode_YasukeIconic_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCB62","parca_adi":"Shoes","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC96","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Shoes_YasukeIconic_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC9A","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Shoes_YasukeIconic_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC9C","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Shoes_YasukeIconic_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC9E","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Shoes_YasukeIconic_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCB95","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC8C","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_YasukeIconic_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC90","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_YasukeIconic_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC92","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_YasukeIconic_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC94","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_YasukeIconic_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCBC8","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D72376","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_ShinobiBakamaNaoe_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D7237A","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_ShinobiBakamaNaoe_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D7237C","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_ShinobiBakamaNaoe_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D7237E","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_ShinobiBakamaNaoe_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCBFB","parca_adi":"Belt 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC46","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_H_YasukeIconic_B_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC4A","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_H_YasukeIconic_B_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC4C","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_H_YasukeIconic_B_Custo_Mask1Map"},{"idx":3,"doku_id":"0x252CE287F17","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_H_YasukeIconic_B_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCC2E","parca_adi":"Jewelry","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC82","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Jewelry_YasukeIconic_Necklace_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC86","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Jewelry_YasukeIconic_Necklace_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC88","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Jewelry_YasukeIconic_Necklace_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC8A","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Jewelry_YasukeIconic_Necklace_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCC61","parca_adi":"Helmet 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC6E","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_Menpo_PlayerYasuke_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC72","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_Menpo_PlayerYasuke_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC74","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_Menpo_PlayerYasuke_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC76","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_Menpo_PlayerYasuke_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCC94","parca_adi":"Helmet 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6E298","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_Maedate_PlayerYasuke_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6E29C","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_Maedate_PlayerYasuke_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6E29E","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_Maedate_PlayerYasuke_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6E2A0","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_Maedate_PlayerYasuke_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCCC7","parca_adi":"Helmet 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC64","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_Kabuto_PlayerYasuke_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC68","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_Kabuto_PlayerYasuke_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC6A","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_Kabuto_PlayerYasuke_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC6C","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_Kabuto_PlayerYasuke_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCCFA","parca_adi":"Greaves","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC50","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Greaves_Yasuke_Suneate_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC54","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Greaves_Yasuke_Suneate_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC56","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Greaves_Yasuke_Suneate_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC58","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Greaves_Yasuke_Suneate_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCD2D","parca_adi":"Dress 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6D45A","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_ShinobiKosodeNaoe_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6D45E","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_ShinobiKosodeNaoe_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6D460","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_ShinobiKosodeNaoe_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6D462","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_ShinobiKosodeNaoe_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCD60","parca_adi":"Belt 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC3C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_H_YasukeIconic_A_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC40","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_H_YasukeIconic_A_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC42","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_H_YasukeIconic_A_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC44","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_H_YasukeIconic_A_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCDF9","parca_adi":"Armor 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC28","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Armor_YasukeIconic_Do_Utils_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC2C","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Armor_YasukeIconic_Do_Utils_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC2E","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Armor_YasukeIconic_Do_Utils_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC30","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Armor_YasukeIconic_Do_Utils_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCE2C","parca_adi":"Armor 2","boot_forge_icinde":true,"slot_sayisi":8,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC0A","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Armor_YasukeIconic_Do_A_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC0E","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Armor_YasukeIconic_Do_A_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC10","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Armor_YasukeIconic_Do_A_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC12","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Armor_YasukeIconic_Do_A_Custo_NormalMap"},{"idx":4,"doku_id":"0x243F4D7C440","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Armor_YasukeIconic_Do_A_DiffuseMap"},{"idx":5,"doku_id":"0x243F4D7C444","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Armor_YasukeIconic_Do_A_EmissiveMap"},{"idx":6,"doku_id":"0x243F4D7C446","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Armor_YasukeIconic_Do_A_Mask1Map"},{"idx":7,"doku_id":"0x243F4D7C448","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Armor_YasukeIconic_Do_A_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCE5F","parca_adi":"Arm 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC00","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_Rope_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC04","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_Rope_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC06","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_Rope_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC08","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_Rope_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCE92","parca_adi":"Arm 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AAF6","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_KotePlates_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AAFA","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_KotePlates_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AAFC","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_KotePlates_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AAFE","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_KotePlates_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCEC5","parca_adi":"Arm 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AAEC","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_KoteBend_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AAF0","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_KoteBend_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AAF2","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_KoteBend_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AAF4","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_KoteBend_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23040ECCEF8","parca_adi":"Arm 4","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AAE2","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_Kote_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AAE6","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_Kote_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AAE8","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Arm_R_YasukeIconic_Kote_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AAEA","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Arm_R_YasukeIconic_Kote_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x243F4D7658E","parca_adi":"Helmet 4","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D6AC78","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_YasukeIconic_Utils_Custo_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D6AC7C","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_YasukeIconic_Utils_Custo_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D6AC7E","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Helmet_YasukeIconic_Utils_Custo_Mask1Map"},{"idx":3,"doku_id":"0x243F4D6AC80","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Helmet_YasukeIconic_Utils_Custo_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x243F4D768EA","parca_adi":"Yasuke 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D77294","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Yasuke_Iconic_Utility_Yellow_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D77298","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Yasuke_Iconic_Utility_Yellow_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D7729A","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Yasuke_Iconic_Utility_Yellow_Mask1Map"},{"idx":3,"doku_id":"0x243F4D7729C","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Yasuke_Iconic_Utility_Yellow_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x243F4D775C9","parca_adi":"Yasuke 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x243F4D77F73","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Yasuke_Iconic_Flower_DiffuseMap"},{"idx":1,"doku_id":"0x243F4D77F77","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Yasuke_Iconic_Flower_EmissiveMap"},{"idx":2,"doku_id":"0x243F4D77F79","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Yasuke_Iconic_Flower_Mask1Map"},{"idx":3,"doku_id":"0x243F4D77F7B","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Yasuke_Iconic_Flower_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24B54552CE9","parca_adi":"Belt 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24B54557559","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_YasukeIconic_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24B5455755D","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_YasukeIconic_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24B5455755F","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_YasukeIconic_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24B54557561","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_YasukeIconic_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24B5455809B","parca_adi":"Dress 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24B5455859B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_YasukeIconic_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24B5455859F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_YasukeIconic_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24B545585A1","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_YasukeIconic_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24B545585A3","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_YasukeIconic_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_LateGame","gorunen_ad":"Late Game Outfit","EG_id":"0x24E8EF7DB0F","sinif":"A","guvenlik_puani":96.9,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x22F3A951FF7","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522FF","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A952303","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A952305","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A952307","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A952129","parca_adi":"Belt 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522B9","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A9522BD","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A9522BF","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A9522C1","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A95215B","parca_adi":"Bracer","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522C3","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A9522C7","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A9522C9","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A9522CB","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A95218D","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522CD","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A9522D1","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A9522D3","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A9522D5","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A9521BF","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522D7","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A9522DB","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A9522DD","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A9522DF","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A9521F1","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522E1","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A9522E5","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A9522E7","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A9522E9","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A952223","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A9522EB","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A9522EF","W":128,"H":128,"aile":"BC3","srgb":0,"mip":8,"harici_mip":0,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A9522F1","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A9522F3","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A952255","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A952316","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A95231A","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A95231C","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A95231E","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22F3A952287","parca_adi":"Tunic013","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22F3A95230C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_U_LategameReward_DiffuseMap"},{"idx":1,"doku_id":"0x22F3A952310","W":128,"H":128,"aile":"BC3","srgb":0,"mip":8,"harici_mip":0,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_U_LategameReward_EmissiveMap"},{"idx":2,"doku_id":"0x22F3A952312","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_U_LategameReward_Mask1Map"},{"idx":3,"doku_id":"0x22F3A952314","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_U_LategameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x249A67C897D","parca_adi":"Belt 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x249A67C87DA","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_LategameReward_Reuse_DiffuseMap"},{"idx":1,"doku_id":"0x249A67C87DE","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_LategameReward_Reuse_EmissiveMap"},{"idx":2,"doku_id":"0x249A67C87E0","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_LategameReward_Reuse_Mask1Map"},{"idx":3,"doku_id":"0x249A67C87E2","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_LategameReward_Reuse_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x249A67CB4F7","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x249A67CB4ED","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_LategameReward_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x249A67CB4F1","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_LategameReward_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x249A67CB4F3","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_LategameReward_Mat_Mask1Map"},{"idx":3,"doku_id":"0x249A67CB4F5","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_LategameReward_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Morgan","gorunen_ad":"Captain Morgan's Redingote","EG_id":"0x23EDD0C3887","sinif":"A","guvenlik_puani":94.2,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x22373CF86E6","parca_adi":"Tunic","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C3ECFF","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Morgan_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C3ED03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Morgan_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C3ED05","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Morgan_Mask1Map"},{"idx":3,"doku_id":"0x256F6C3ED07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Morgan_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373CF8AB7","parca_adi":"Hair","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C3ECF4","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hair_U_Edward_Morgan_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C3ECF8","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hair_U_Edward_Morgan_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C3ECFA","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hair_U_Edward_Morgan_Mask1Map"},{"idx":3,"doku_id":"0x256F6C3ECFC","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hair_U_Edward_Morgan_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C11053356","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C1105624B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_Morgan_Dress_DiffuseMap"},{"idx":1,"doku_id":"0x24C1105624F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_Morgan_Dress_EmissiveMap"},{"idx":2,"doku_id":"0x24C11056251","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_Morgan_Dress_Mask1Map"},{"idx":3,"doku_id":"0x24C11056253","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_Morgan_Dress_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C11053388","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11056241","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_Morgan_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x24C11056245","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_Morgan_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x24C11056247","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_Morgan_Belt_Mask1Map"},{"idx":3,"doku_id":"0x24C11056249","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_Morgan_Belt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C110533BA","parca_adi":"C H R 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11056255","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_Morgan_Trinket_DiffuseMap"},{"idx":1,"doku_id":"0x24C11056259","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_Morgan_Trinket_EmissiveMap"},{"idx":2,"doku_id":"0x24C1105625B","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_Morgan_Trinket_Mask1Map"},{"idx":3,"doku_id":"0x24C1105625D","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_Morgan_Trinket_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_SeaSerpent","gorunen_ad":"Sea Serpent Outfit","EG_id":"0x24E8EF892BA","sinif":"A","guvenlik_puani":94.1,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x22C64B6CD35","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22C64B6CD2B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_SeaSerpent_DiffuseMap"},{"idx":1,"doku_id":"0x22C64B6CD2F","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_SeaSerpent_EmissiveMap"},{"idx":2,"doku_id":"0x22C64B6CD31","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_SeaSerpent_Mask1Map"},{"idx":3,"doku_id":"0x22C64B6CD33","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_SeaSerpent_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22C64B6D1C9","parca_adi":"Cape","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22C64B6D1FB","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Cape_U_Edward_SeaSerpent_DiffuseMap"},{"idx":1,"doku_id":"0x22C64B6D1FF","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Cape_U_Edward_SeaSerpent_EmissiveMap"},{"idx":2,"doku_id":"0x22C64B6D201","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Cape_U_Edward_SeaSerpent_Mask1Map"},{"idx":3,"doku_id":"0x22C64B6D203","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Cape_U_Edward_SeaSerpent_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D6CC99EA4","parca_adi":"Torso","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D6CC943AB","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_SeaSerpent_DiffuseMap"},{"idx":1,"doku_id":"0x22D6CC943AF","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_SeaSerpent_EmissiveMap"},{"idx":2,"doku_id":"0x22D6CC943B1","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_SeaSerpent_Mask1Map"},{"idx":3,"doku_id":"0x22D6CC943B3","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_SeaSerpent_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2473AA507B7","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2473AA517C5","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_SeaSerpent_DiffuseMap"},{"idx":1,"doku_id":"0x2473AA517C9","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_SeaSerpent_EmissiveMap"},{"idx":2,"doku_id":"0x2473AA517CB","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_SeaSerpent_Mask1Map"},{"idx":3,"doku_id":"0x2473AA517CD","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_SeaSerpent_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Whaler","gorunen_ad":"Whaler Outfit","EG_id":"0x24E8EF892F0","sinif":"A","guvenlik_puani":81.5,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth"],"materyaller":[{"mat_id":"0x2372812C293","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2372812C301","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_streamer_SharkHunter_rose_DiffuseMap"},{"idx":1,"doku_id":"0x2372812C305","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_streamer_SharkHunter_rose_EmissiveMap"},{"idx":2,"doku_id":"0x2372812C307","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_streamer_SharkHunter_rose_Mask1Map"},{"idx":3,"doku_id":"0x2372812C309","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_streamer_SharkHunter_rose_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2372812C2C5","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2372812C2F7","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_SharkHunter_rose_DiffuseMap"},{"idx":1,"doku_id":"0x2372812C2FB","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_SharkHunter_rose_EmissiveMap"},{"idx":2,"doku_id":"0x2372812C2FD","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_SharkHunter_rose_Mask1Map"},{"idx":3,"doku_id":"0x2372812C2FF","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_SharkHunter_rose_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22A83D3F40B","parca_adi":"Torso 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F1424BB0","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_Whaler_DiffuseMap"},{"idx":1,"doku_id":"0x256F1424BB4","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_Whaler_EmissiveMap"},{"idx":2,"doku_id":"0x256F1424BB6","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_Whaler_Mask1Map"},{"idx":3,"doku_id":"0x256F1424BB8","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_Whaler_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"WARDROBE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22A83DAA246","parca_adi":"Torso 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F14124D3","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_EdSharkHunter_DiffuseMap"},{"idx":1,"doku_id":"0x256F14124D7","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_EdSharkHunter_EmissiveMap"},{"idx":2,"doku_id":"0x256F14124D9","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_EdSharkHunter_Mask1Map"},{"idx":3,"doku_id":"0x256F14124DB","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_EdSharkHunter_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"WARDROBE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x237281242E9","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x257E476E5D1","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_Whaler_X_BeltSash_DiffuseMap"},{"idx":1,"doku_id":"0x257E476E5D5","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_Whaler_X_BeltSash_EmissiveMap"},{"idx":2,"doku_id":"0x257E476E5D7","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_Whaler_X_BeltSash_Mask1Map"},{"idx":3,"doku_id":"0x257E476E5D9","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_Whaler_X_BeltSash_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"WARDROBE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24B5458CB54","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24B5458CB40","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdWhaler_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24B5458CB44","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdWhaler_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24B5458CB46","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdWhaler_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24B5458CB48","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdWhaler_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"WARDROBE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24B5458CB87","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24B5458CB4A","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EdWhaler_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24B5458CB4E","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EdWhaler_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24B5458CB50","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EdWhaler_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24B5458CB52","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EdWhaler_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"WARDROBE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2128A456A2D","parca_adi":"Necklace","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x257340FC0BE","W":512,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Necklace_U_EdSailor_DiffuseMap"},{"idx":1,"doku_id":"0x257340FC0C2","W":256,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Necklace_U_EdSailor_EmissiveMap"},{"idx":2,"doku_id":"0x257340FC0C4","W":32,"H":64,"aile":"BC1","srgb":0,"mip":7,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Necklace_U_EdSailor_Mask1Map"},{"idx":3,"doku_id":"0x257340FC0C6","W":512,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Necklace_U_EdSailor_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Stealth","gorunen_ad":"Stealth Outfit","EG_id":"0x23EDD0C3847","sinif":"A","guvenlik_puani":80.2,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x2234D66EA95","parca_adi":"Dress 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F143F14D","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_Edward_Stealth_DiffuseMap"},{"idx":1,"doku_id":"0x256F143F151","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_Edward_Stealth_EmissiveMap"},{"idx":2,"doku_id":"0x256F143F153","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_Edward_Stealth_Mask1Map"},{"idx":3,"doku_id":"0x256F143F155","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_Edward_Stealth_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2234D66EA9E","parca_adi":"Bracer 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F143F137","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_Edward_Stealth_DiffuseMap"},{"idx":1,"doku_id":"0x256F143F13B","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_Edward_Stealth_EmissiveMap"},{"idx":2,"doku_id":"0x256F143F13D","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_Edward_Stealth_Mask1Map"},{"idx":3,"doku_id":"0x256F143F13F","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_Edward_Stealth_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23889F13702","parca_adi":"Boots","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F143F12C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_Stealth_X_Fur_DiffuseMap"},{"idx":1,"doku_id":"0x256F143F130","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_Stealth_X_Fur_EmissiveMap"},{"idx":2,"doku_id":"0x256F143F132","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_Stealth_X_Fur_Mask1Map"},{"idx":3,"doku_id":"0x256F143F134","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_Stealth_X_Fur_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23889F13734","parca_adi":"Bracer 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F143F142","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_Edward_Stealth_X_Feathers_DiffuseMap"},{"idx":1,"doku_id":"0x256F143F146","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_Edward_Stealth_X_Feathers_EmissiveMap"},{"idx":2,"doku_id":"0x256F143F148","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_Edward_Stealth_X_Feathers_Mask1Map"},{"idx":3,"doku_id":"0x256F143F14A","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_Edward_Stealth_X_Feathers_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C5045984F","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C5045A3E2","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EdBonnet_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C5045A3E6","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EdBonnet_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C5045A3E8","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EdBonnet_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C5045A3EA","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EdBonnet_Costume_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C50459881","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C5045A3EC","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C5045A3F0","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C5045A3F2","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C5045A3F4","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Altair","gorunen_ad":"Altair Ibn-La'Ahad's Robes","EG_id":"0x23EDD0C4535","sinif":"A","guvenlik_puani":76.5,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x222DDFA5375","parca_adi":"Tunic 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C059A5A","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EDAltair_DiffuseMap"},{"idx":1,"doku_id":"0x2561C059A5E","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EDAltair_EmissiveMap"},{"idx":2,"doku_id":"0x2561C059A60","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EDAltair_Mask1Map"},{"idx":3,"doku_id":"0x2561C059A62","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EDAltair_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x222DDFA537E","parca_adi":"Tunic 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C059A65","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EDAltair_X_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x2561C059A69","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EDAltair_X_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x2561C059A6B","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EDAltair_X_Belt_Mask1Map"},{"idx":3,"doku_id":"0x2561C059A6D","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EDAltair_X_Belt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x222DDFA5387","parca_adi":"Tunic 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C059A70","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EDAltair_X_ChestBelt_DiffuseMap"},{"idx":1,"doku_id":"0x2561C059A74","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EDAltair_X_ChestBelt_EmissiveMap"},{"idx":2,"doku_id":"0x2561C059A76","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EDAltair_X_ChestBelt_Mask1Map"},{"idx":3,"doku_id":"0x2561C059A78","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EDAltair_X_ChestBelt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x249A67FAE5B","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x249A67FB825","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EDAltair_Costume_Mat_NormalMap"},{"idx":1,"doku_id":"0x249A67FB827","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EDAltair_Costume_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x249A67FB829","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EDAltair_Costume_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24C504048DC","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EDAltair_Costume_Mat_DiffuseMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x249A67FBB6D","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x249A67FB82F","W":512,"H":512,"aile":"BC1","srgb":1,"mip":10,"harici_mip":1,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EDAltair_Costume_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x249A67FB831","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EDAltair_Costume_Mat_NormalMap"},{"idx":2,"doku_id":"0x249A67FB833","W":512,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EDAltair_Costume_Mat_EmissiveMap"},{"idx":3,"doku_id":"0x249A67FB835","W":512,"H":512,"aile":"BC1","srgb":0,"mip":10,"harici_mip":1,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EDAltair_Costume_Mat_Mask1Map"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Connor","gorunen_ad":"Connor's Outfit","EG_id":"0x23EDD0C453D","sinif":"A","guvenlik_puani":69.2,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["U_Edward_Ezio"],"materyaller":[{"mat_id":"0x22A83D6518B","parca_adi":"Boots","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C04AFA7","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_Connor_DiffuseMap"},{"idx":1,"doku_id":"0x2561C04AFAB","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_Connor_EmissiveMap"},{"idx":2,"doku_id":"0x2561C04AFAD","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_Connor_Mask1Map"},{"idx":3,"doku_id":"0x2561C04AFAF","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_Connor_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22A83D65195","parca_adi":"Skirt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C04AF9C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Skirt_U_Edward_Connor_DiffuseMap"},{"idx":1,"doku_id":"0x2561C04AFA0","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Skirt_U_Edward_Connor_EmissiveMap"},{"idx":2,"doku_id":"0x2561C04AFA2","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Skirt_U_Edward_Connor_Mask1Map"},{"idx":3,"doku_id":"0x2561C04AFA4","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Skirt_U_Edward_Connor_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22A83D6519F","parca_adi":"Tunic","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C04AF91","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Connor_DiffuseMap"},{"idx":1,"doku_id":"0x2561C04AF95","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Connor_EmissiveMap"},{"idx":2,"doku_id":"0x2561C04AF97","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Connor_Mask1Map"},{"idx":3,"doku_id":"0x2561C04AF99","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Connor_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22A83D651A9","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C04AF86","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_Connor_DiffuseMap"},{"idx":1,"doku_id":"0x2561C04AF8A","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_Connor_EmissiveMap"},{"idx":2,"doku_id":"0x2561C04AF8C","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_Connor_Mask1Map"},{"idx":3,"doku_id":"0x2561C04AF8E","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_Connor_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C5040D96B","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50422D94","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EDConnor_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50422D98","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EDConnor_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50422D9A","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EDConnor_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50422D9C","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EDConnor_Costume_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C5040DB36","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50422D9E","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EDConnor_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50422DA2","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EDConnor_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50422DA4","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EDConnor_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50422DA6","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EDConnor_Costume_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1101ED5D","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11022B04","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x24C11022B08","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x24C11022B0A","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Belt_Mask1Map"},{"idx":3,"doku_id":"0x24C11022B0C","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Belt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Ezio"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1101F25A","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11022B0E","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Dress_DiffuseMap"},{"idx":1,"doku_id":"0x24C11022B12","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Dress_EmissiveMap"},{"idx":2,"doku_id":"0x24C11022B14","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Dress_Mask1Map"},{"idx":3,"doku_id":"0x24C11022B16","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Dress_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Ezio"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Ezio","gorunen_ad":"Ezio Auditore's Robes","EG_id":"0x23EDD0C4545","sinif":"A","guvenlik_puani":64.0,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["U_Edward_Connor"],"materyaller":[{"mat_id":"0x22373CE1241","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C0E3EBA","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_Ezio_DiffuseMap"},{"idx":1,"doku_id":"0x2561C0E3EBE","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_Ezio_EmissiveMap"},{"idx":2,"doku_id":"0x2561C0E3EC0","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_Ezio_Mask1Map"},{"idx":3,"doku_id":"0x2561C0E3EC2","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_Ezio_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373CE160C","parca_adi":"Tunic 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C0E3EC5","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Ezio_DiffuseMap"},{"idx":1,"doku_id":"0x2561C0E3EC9","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Ezio_EmissiveMap"},{"idx":2,"doku_id":"0x2561C0E3ECB","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Ezio_Mask1Map"},{"idx":3,"doku_id":"0x2561C0E3ECD","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Ezio_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373CE1615","parca_adi":"Boots","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C0E3EAF","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_Ezio_DiffuseMap"},{"idx":1,"doku_id":"0x2561C0E3EB3","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_Ezio_EmissiveMap"},{"idx":2,"doku_id":"0x2561C0E3EB5","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_Ezio_Mask1Map"},{"idx":3,"doku_id":"0x2561C0E3EB7","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_Ezio_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373CE161E","parca_adi":"Tunic 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C0E3ED0","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Ezio_X_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x2561C0E3ED4","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Ezio_X_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x2561C0E3ED6","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Ezio_X_Belt_Mask1Map"},{"idx":3,"doku_id":"0x2561C0E3ED8","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Ezio_X_Belt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1101ED5D","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11022B04","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x24C11022B08","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x24C11022B0A","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Belt_Mask1Map"},{"idx":3,"doku_id":"0x24C11022B0C","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Belt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Connor"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1101F25A","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11022B0E","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Dress_DiffuseMap"},{"idx":1,"doku_id":"0x24C11022B12","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Dress_EmissiveMap"},{"idx":2,"doku_id":"0x24C11022B14","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_Ezio_Dress_Mask1Map"},{"idx":3,"doku_id":"0x24C11022B16","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_Ezio_Dress_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfit in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Connor"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Drake","gorunen_ad":"Captain Drake's Outfit","EG_id":"0x23EDD0C4525","sinif":"A","guvenlik_puani":62.3,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x2236C9DF5F8","parca_adi":"Tunic","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2561C0BF662","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Drake_DiffuseMap"},{"idx":1,"doku_id":"0x2561C0BF666","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Drake_EmissiveMap"},{"idx":2,"doku_id":"0x2561C0BF668","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Drake_Mask1Map"},{"idx":3,"doku_id":"0x2561C0BF66A","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Drake_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C50426206","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50426282","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_Drake_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50426286","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_Drake_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50426288","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_Drake_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C5042628A","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_Drake_Costume_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C50426238","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C5042628C","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_Edward_Drake_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50426290","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_Edward_Drake_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50426292","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_Edward_Drake_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50426294","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_Edward_Drake_Costume_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Legend","gorunen_ad":"Edward the Legend Outfit","EG_id":"0x23EDD0C3857","sinif":"A","guvenlik_puani":62.3,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x226E46251DC","parca_adi":"Tunic","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C24451","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Legend_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C24455","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Legend_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C24457","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_Edward_Legend_Mask1Map"},{"idx":3,"doku_id":"0x256F6C24459","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_Edward_Legend_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C95511764","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C95511428","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_Legend_DiffuseMap"},{"idx":1,"doku_id":"0x24C9551142C","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_Legend_EmissiveMap"},{"idx":2,"doku_id":"0x24C9551142E","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_Legend_Mask1Map"},{"idx":3,"doku_id":"0x24C95511430","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_Legend_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C9551812A","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C9551848F","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_Edward_Legend_DiffuseMap"},{"idx":1,"doku_id":"0x24C95518493","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_Edward_Legend_EmissiveMap"},{"idx":2,"doku_id":"0x24C95518495","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_Edward_Legend_Mask1Map"},{"idx":3,"doku_id":"0x24C95518497","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_Edward_Legend_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Ultimate","gorunen_ad":"Ultimate Outfit","EG_id":"0x24E8EF892B1","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x2386DB1070F","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386DB10859","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_EndgameReward_DiffuseMap"},{"idx":1,"doku_id":"0x2386DB1085D","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_EndgameReward_EmissiveMap"},{"idx":2,"doku_id":"0x2386DB1085F","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_EndgameReward_Mask1Map"},{"idx":3,"doku_id":"0x2386DB10861","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_EndgameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386DB107A5","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386DB1086D","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_EndgameReward_DiffuseMap"},{"idx":1,"doku_id":"0x2386DB10871","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_EndgameReward_EmissiveMap"},{"idx":2,"doku_id":"0x2386DB10873","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_EndgameReward_Mask1Map"},{"idx":3,"doku_id":"0x2386DB10875","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_EndgameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386DB107D7","parca_adi":"Tunic013","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386DB10881","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_U_EndgameReward_DiffuseMap"},{"idx":1,"doku_id":"0x2386DB10885","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_U_EndgameReward_EmissiveMap"},{"idx":2,"doku_id":"0x2386DB10887","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_U_EndgameReward_Mask1Map"},{"idx":3,"doku_id":"0x2386DB10889","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_U_EndgameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386DB10809","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386DB10877","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_EndgameReward_DiffuseMap"},{"idx":1,"doku_id":"0x2386DB1087B","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_EndgameReward_EmissiveMap"},{"idx":2,"doku_id":"0x2386DB1087D","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_EndgameReward_Mask1Map"},{"idx":3,"doku_id":"0x2386DB1087F","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_EndgameReward_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386DB17FAB","parca_adi":"C H R","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386DB17FDD","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EndGameReward_Costume_LOD0_DiffuseMap"},{"idx":1,"doku_id":"0x2386DB17FE1","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EndGameReward_Costume_LOD0_EmissiveMap"},{"idx":2,"doku_id":"0x2386DB17FE3","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EndGameReward_Costume_LOD0_Mask1Map"},{"idx":3,"doku_id":"0x2386DB17FE5","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EndGameReward_Costume_LOD0_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x249A67DDB34","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x249A67D6310","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_Ultimate_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x249A67D6312","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_Ultimate_Mat_NormalMap"},{"idx":2,"doku_id":"0x249A67D6314","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_Ultimate_Mat_EmissiveMap"},{"idx":3,"doku_id":"0x249A67D6316","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_Ultimate_Mat_Mask1Map"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x249A67EE28A","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x249A67F1AB6","W":512,"H":512,"aile":"BC1","srgb":1,"mip":10,"harici_mip":1,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_Ultimate_DiffuseMap"},{"idx":1,"doku_id":"0x249A67F1AB8","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_Ultimate_NormalMap"},{"idx":2,"doku_id":"0x249A67F1ABA","W":512,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_Ultimate_EmissiveMap"},{"idx":3,"doku_id":"0x249A67F1ABC","W":512,"H":512,"aile":"BC1","srgb":0,"mip":10,"harici_mip":1,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_Ultimate_Mask1Map"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Fire","gorunen_ad":"Fire Outfit","EG_id":"0x24E8EF892C3","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x22D6CCFC162","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x22D6CCFC1C6","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Cape_DiffuseMap"},{"idx":1,"doku_id":"0x22D6CCFC1CA","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Cape_EmissiveMap"},{"idx":2,"doku_id":"0x22D6CCFC1CE","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Cape_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1103081C","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11032A1B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x24C11032A1F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x24C11032A21","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Belt_Mask1Map"},{"idx":3,"doku_id":"0x24C11032A23","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDFireTheme_Gearset_Costume_Belt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Asian","gorunen_ad":"Asian Outfit","EG_id":"0x24E8EF892CC","sinif":"A","guvenlik_puani":95.2,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23E0AB61C2D","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x23E0AB61C18","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Cape_DiffuseMap"},{"idx":1,"doku_id":"0x23E0AB61C1C","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Cape_EmissiveMap"},{"idx":2,"doku_id":"0x23E0AB61C1E","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Cape_Mask1Map"},{"idx":3,"doku_id":"0x23E0AB61C20","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Cape_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23E0AB61C8D","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x23E0AB61C22","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Torso_DiffuseMap"},{"idx":1,"doku_id":"0x23E0AB61C26","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Torso_EmissiveMap"},{"idx":2,"doku_id":"0x23E0AB61C28","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Torso_Mask1Map"},{"idx":3,"doku_id":"0x23E0AB61C2A","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_Torso_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23E0AB61D06","parca_adi":"C H R 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x23E0AB61CF2","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_belt_DiffuseMap"},{"idx":1,"doku_id":"0x23E0AB61CF6","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_belt_EmissiveMap"},{"idx":2,"doku_id":"0x23E0AB61CF8","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_belt_Mask1Map"},{"idx":3,"doku_id":"0x23E0AB61CFA","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_belt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23E0AB61D36","parca_adi":"C H R 4","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x23E0AB61CFC","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_rose_DiffuseMap"},{"idx":1,"doku_id":"0x23E0AB61D00","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_rose_EmissiveMap"},{"idx":2,"doku_id":"0x23E0AB61D02","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_rose_Mask1Map"},{"idx":3,"doku_id":"0x23E0AB61D04","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EDAsianTheme_Gearset_Costume_LOD0_rose_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24B5455EC85","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24B5455E7AD","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_Edward_AsianTheme_Gearset_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24B5455E7B1","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_Edward_AsianTheme_Gearset_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24B5455E7B3","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_Edward_AsianTheme_Gearset_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24B5455E7B5","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_Edward_AsianTheme_Gearset_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_FirstCiv","gorunen_ad":"Mayan Outfit","EG_id":"0x23EDD0C384F","sinif":"A","guvenlik_puani":92.5,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x235AED2208E","parca_adi":"Tunic","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x235AED220C0","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EdFirstCiv_X_SashBelt_DiffuseMap"},{"idx":1,"doku_id":"0x235AED220C4","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EdFirstCiv_X_SashBelt_EmissiveMap"},{"idx":2,"doku_id":"0x235AED220C6","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic_U_EdFirstCiv_X_SashBelt_Mask1Map"},{"idx":3,"doku_id":"0x235AED220C8","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic_U_EdFirstCiv_X_SashBelt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1105FCDA","parca_adi":"C H R 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11061DB7","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Dress_DiffuseMap"},{"idx":1,"doku_id":"0x24C11061DBB","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Dress_EmissiveMap"},{"idx":2,"doku_id":"0x24C11061DBD","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Dress_Mask1Map"},{"idx":3,"doku_id":"0x24C11061DBF","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Dress_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1105FD0C","parca_adi":"C H R 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11061DAD","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Belt_DiffuseMap"},{"idx":1,"doku_id":"0x24C11061DB1","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Belt_EmissiveMap"},{"idx":2,"doku_id":"0x24C11061DB3","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Belt_Mask1Map"},{"idx":3,"doku_id":"0x24C11061DB5","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Belt_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C1105FD3E","parca_adi":"C H R 3","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C11061DC1","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Trinket_DiffuseMap"},{"idx":1,"doku_id":"0x24C11061DC5","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Trinket_EmissiveMap"},{"idx":2,"doku_id":"0x24C11061DC7","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Trinket_Mask1Map"},{"idx":3,"doku_id":"0x24C11061DC9","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_EdwardKenway_FirstCiv_Trinket_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Templar","gorunen_ad":"Templar Outfit","EG_id":"0x23EDD0C383F","sinif":"A","guvenlik_puani":89.2,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x247FB4FFB96","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x247FB4FC50E","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardTemplar_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x247FB4FC512","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardTemplar_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x247FB4FC514","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardTemplar_Mat_Mask1Map"},{"idx":3,"doku_id":"0x247FB4FC516","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardTemplar_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24CC5600230","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x247FB4FC518","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EdwardTemplar_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x247FB4FC51C","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EdwardTemplar_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x247FB4FC51E","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_EdwardTemplar_Mat_Mask1Map"},{"idx":3,"doku_id":"0x247FB4FC520","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_EdwardTemplar_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24CC56323C7","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24CC562E6C3","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_EdwardTemplar_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24CC562E6C7","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_EdwardTemplar_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24CC562E6C9","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_EdwardTemplar_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24CC562E6CB","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_EdwardTemplar_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Hunter","gorunen_ad":"Hunter Outfit","EG_id":"0x23EDD0C385F","sinif":"A","guvenlik_puani":0.0,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x22373D554A4","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01A96","W":2048,"H":1024,"aile":"BC3","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_FelinePelt_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01A9A","W":1024,"H":512,"aile":"BC3","srgb":0,"mip":11,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_FelinePelt_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01A9C","W":1024,"H":512,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_FelinePelt_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01A9E","W":2048,"H":1024,"aile":"BC7","srgb":0,"mip":12,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_FelinePelt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373D554AD","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AA1","W":2048,"H":1024,"aile":"BC3","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_FelinePeltr_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01AA5","W":1024,"H":512,"aile":"BC3","srgb":0,"mip":11,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_FelinePeltr_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01AA7","W":1024,"H":512,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_FelinePeltr_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01AA9","W":2048,"H":1024,"aile":"BC7","srgb":0,"mip":12,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_FelinePeltr_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373D554B6","parca_adi":"Torso 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AB7","W":1024,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01ABB","W":512,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01ABD","W":512,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01ABF","W":1024,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373D56289","parca_adi":"Boots","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AAC","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_FelinePelt_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01AB0","W":512,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_FelinePelt_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01AB2","W":512,"H":512,"aile":"BC1","srgb":0,"mip":10,"harici_mip":1,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_FelinePelt_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01AB4","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_FelinePelt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D6CC3BE34","parca_adi":"Torso 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AC2","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01AC6","W":512,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01AC8","W":512,"H":512,"aile":"BC1","srgb":0,"mip":10,"harici_mip":1,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01ACA","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Feline","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C504435C9","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50447E1B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EdBonnet_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50447E1F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EdBonnet_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50447E21","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EdBonnet_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50447E23","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EdBonnet_Costume_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C5044412A","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50447E25","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50447E29","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50447E2B","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50447E2D","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Feline"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Feline","gorunen_ad":"Feline Pelt Outfit","EG_id":"0x23EDD0C3867","sinif":"A","guvenlik_puani":0.0,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x22373D554A4","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01A96","W":2048,"H":1024,"aile":"BC3","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_FelinePelt_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01A9A","W":1024,"H":512,"aile":"BC3","srgb":0,"mip":11,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_FelinePelt_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01A9C","W":1024,"H":512,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_FelinePelt_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01A9E","W":2048,"H":1024,"aile":"BC7","srgb":0,"mip":12,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_FelinePelt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373D554AD","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AA1","W":2048,"H":1024,"aile":"BC3","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_FelinePeltr_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01AA5","W":1024,"H":512,"aile":"BC3","srgb":0,"mip":11,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_FelinePeltr_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01AA7","W":1024,"H":512,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_FelinePeltr_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01AA9","W":2048,"H":1024,"aile":"BC7","srgb":0,"mip":12,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_FelinePeltr_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373D554B6","parca_adi":"Torso 1","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AB7","W":1024,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01ABB","W":512,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01ABD","W":512,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01ABF","W":1024,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePeltr_X_BelttHolster_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22373D56289","parca_adi":"Boots","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AAC","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_FelinePelt_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01AB0","W":512,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_FelinePelt_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01AB2","W":512,"H":512,"aile":"BC1","srgb":0,"mip":10,"harici_mip":1,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Boots_U_Edward_FelinePelt_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01AB4","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Boots_U_Edward_FelinePelt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D6CC3BE34","parca_adi":"Torso 2","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F6C01AC2","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_DiffuseMap"},{"idx":1,"doku_id":"0x256F6C01AC6","W":512,"H":512,"aile":"BC3","srgb":0,"mip":10,"harici_mip":2,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_EmissiveMap"},{"idx":2,"doku_id":"0x256F6C01AC8","W":512,"H":512,"aile":"BC1","srgb":0,"mip":10,"harici_mip":1,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_Mask1Map"},{"idx":3,"doku_id":"0x256F6C01ACA","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Torso_U_Edward_FelinePelt_X_ShoulderPelt_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Diplomat","U_Edward_Drake","U_Edward_Ezio","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C504435C9","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50447E1B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EdBonnet_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50447E1F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EdBonnet_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50447E21","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_EdBonnet_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50447E23","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_EdBonnet_Costume_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24C5044412A","parca_adi":"Trinket","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24C50447E25","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_DiffuseMap"},{"idx":1,"doku_id":"0x24C50447E29","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_EmissiveMap"},{"idx":2,"doku_id":"0x24C50447E2B","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_Mask1Map"},{"idx":3,"doku_id":"0x24C50447E2D","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Trinket_U_EdwardKenway_Drake_Costume_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["U_Edward_Hunter"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Diplomat","gorunen_ad":"Ferraro Diplomat Outfit","EG_id":"0x23EDD0ACE53","sinif":"A","guvenlik_puani":0.0,"guvenlik_etiketi":"SARI","etkilenen_diger_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"materyaller":[{"mat_id":"0x2236C9F4BD3","parca_adi":"C H R","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2236C9F526B","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_P_EdwardKenway_Foreigner_Body_DiffuseMap"},{"idx":1,"doku_id":"0x2236C9F526F","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_P_EdwardKenway_Foreigner_Body_EmissiveMap"},{"idx":2,"doku_id":"0x2236C9F5271","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_P_EdwardKenway_Foreigner_Body_Mask1Map"},{"idx":3,"doku_id":"0x2236C9F5273","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_P_EdwardKenway_Foreigner_Body_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["Edward_Assassin"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC16","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AAFF","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB03","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB05","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB07","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 12 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Bonnet","U_Edward_Drake","U_Edward_Feline","U_Edward_Hunter","U_Edward_Legend","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_Stealth","U_Edward_Whaler"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AC48","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AB15","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB19","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB1B","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB1D","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0ACAC","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0AB2B","W":2048,"H":2048,"aile":"BC1","srgb":1,"mip":12,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0AB2F","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0AB31","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Mat_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0AB33","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Mat_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 2 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_PirateCloak"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x22D90B0AD10","parca_adi":"Tunic013","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x22D90B0ABA5","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_EdwardKenway_DiffuseMap"},{"idx":1,"doku_id":"0x22D90B0ABA9","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_EdwardKenway_EmissiveMap"},{"idx":2,"doku_id":"0x22D90B0ABAB","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_EdwardKenway_Mask1Map"},{"idx":3,"doku_id":"0x22D90B0ABAD","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_EdwardKenway_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 1 outfits in the same wardrobe","kategori":"SHARED","etkilenen_kiyafetler":["Edward_Assassin"],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x23709626AC7","parca_adi":"Wardrobe mannequin (not worn)","boot_forge_icinde":true,"slot_sayisi":3,"slotlar":[{"idx":0,"doku_id":"0x23709626B92","W":1024,"H":1024,"aile":"BC7","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_DiffuseMap"},{"idx":1,"doku_id":"0x23709626B94","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_Mask0Map"},{"idx":2,"doku_id":"0x23709626B96","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"OBD_UNQ_STD_MAN_Mannequins_01A_NormalMap"}],"paylasim":{"renk":"SARI","kapsam":"also changes 23 outfits in the same wardrobe","kategori":"GLOBAL","etkilenen_kiyafetler":["Edward_Assassin","U_Edward_Altair","U_Edward_Asian","U_Edward_Bonnet","U_Edward_Connor","U_Edward_Drake","U_Edward_Ezio","U_Edward_Feline","U_Edward_FirstCiv","U_Edward_Hunter","U_Edward_LateGame","U_Edward_Legend","U_Edward_Morgan","U_Edward_Naoe","U_Edward_PirateCloak","U_Edward_RedBlackbeard","U_Edward_SeaSerpent","U_Edward_Stealth","U_Edward_Templar","U_Edward_Ultimate","U_Edward_Walpole","U_Edward_Whaler","U_Edward_Yasuke"],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Privateer","gorunen_ad":"Privateer Outfit","EG_id":"0x23EDD0C3807","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x24054B85221","parca_adi":"Tunic03","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84EE0","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic03_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84EE4","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic03_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84EE6","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic03_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84EE8","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic03_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B85254","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84ED5","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84ED9","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84EDB","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84EDD","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B85286","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84ECA","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84ECE","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84ED0","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84ED2","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B852B8","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84EBF","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84EC3","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84EC5","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84EC7","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B852EA","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84EB4","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84EB8","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84EBA","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84EBC","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B8531C","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84EA9","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84EAD","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84EAF","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84EB1","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B8534E","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84E9E","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84EA2","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84EA4","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84EA6","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B85380","parca_adi":"Bracer","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84E93","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84E97","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84E99","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84E9B","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B853B2","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x24054B84E88","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardKenway_Privateer_Mat_DiffuseMap"},{"idx":1,"doku_id":"0x24054B84E8C","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardKenway_Privateer_Mat_EmissiveMap"},{"idx":2,"doku_id":"0x24054B84E8E","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardKenway_Privateer_Mat_Mask1Map"},{"idx":3,"doku_id":"0x24054B84E90","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardKenway_Privateer_Mat_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_PirateCaptain","gorunen_ad":"Pirate Captain Outfit","EG_id":"0x23EDD0C380F","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x24054B624AC","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F1474717","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F147471B","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F147471D","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F147471F","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B624DE","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F14746CA","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F14746CE","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F14746D0","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F14746D2","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B62510","parca_adi":"Bracer","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F14746D5","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F14746D9","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F14746DB","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F14746DD","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B62542","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F14746E0","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F14746E4","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F14746E6","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F14746E8","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B62574","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F14746EB","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F14746EF","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F14746F1","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F14746F3","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B625A6","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F14746F6","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F14746FA","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F14746FC","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F14746FE","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B625D8","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F1474701","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F1474705","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F1474707","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F1474709","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B6260A","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F147470C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F1474710","W":1024,"H":1024,"aile":"BC3","srgb":0,"mip":11,"harici_mip":3,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F1474712","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F1474714","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x24054B6263C","parca_adi":"Tunic03","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x256F1474722","W":512,"H":512,"aile":"BC3","srgb":1,"mip":10,"harici_mip":2,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic03_U_Edward_PirateCaptain_DiffuseMap"},{"idx":1,"doku_id":"0x256F1474726","W":256,"H":256,"aile":"BC3","srgb":0,"mip":9,"harici_mip":1,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic03_U_Edward_PirateCaptain_EmissiveMap"},{"idx":2,"doku_id":"0x256F1474728","W":256,"H":256,"aile":"BC1","srgb":0,"mip":9,"harici_mip":0,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic03_U_Edward_PirateCaptain_Mask1Map"},{"idx":3,"doku_id":"0x256F147472A","W":512,"H":512,"aile":"BC7","srgb":0,"mip":10,"harici_mip":2,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic03_U_Edward_PirateCaptain_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Merchant","gorunen_ad":"Merchant Outfit","EG_id":"0x23EDD0C3817","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x240E9B9A131","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BAAD","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BAB1","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BAB3","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BAB5","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A163","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA4A","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA4E","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA50","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA52","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A195","parca_adi":"Bracer","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA55","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA59","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA5B","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA5D","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A1C7","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA60","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA64","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA66","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA68","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A1F9","parca_adi":"Gun Holster Back","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA6B","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA6F","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA71","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA73","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A32B","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA76","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA7A","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA7C","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA7E","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A35D","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA81","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA85","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA87","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA89","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A38F","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA8C","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA90","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA92","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA94","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A3C1","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BAA2","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BAA6","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BAA8","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BAAA","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9B9A3F3","parca_adi":"Tunic013","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9B9BA97","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_EdwardKenway_Assassin_Merchant_DiffuseMap"},{"idx":1,"doku_id":"0x240E9B9BA9B","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_EdwardKenway_Assassin_Merchant_EmissiveMap"},{"idx":2,"doku_id":"0x240E9B9BA9D","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_EdwardKenway_Assassin_Merchant_Mask1Map"},{"idx":3,"doku_id":"0x240E9B9BA9F","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_EdwardKenway_Assassin_Merchant_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_Explorer","gorunen_ad":"Explorer Outfit","EG_id":"0x23EDD0C3827","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x240E9BD1EEF","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD28DB","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD28DF","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD28E1","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD28E3","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD1F21","parca_adi":"Bracer","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD28E6","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD28EA","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD28EC","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD28EE","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_P_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD1F53","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD28F1","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD28F5","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD28F7","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_P_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD28F9","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_P_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD1F85","parca_adi":"Gun Holster Back","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD28FC","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD2900","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD2902","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD2904","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"GunHolsterBack_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD1FB7","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD2907","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD290B","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD290D","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD290F","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD1FE9","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD2912","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD2916","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD2918","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_P_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD291A","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_P_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD201B","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD291D","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD2921","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD2923","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD2925","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD204D","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD2933","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD2937","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD2939","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD293B","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD207F","parca_adi":"Tunic013","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD2928","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD292C","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD292E","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD2930","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x240E9BD20B1","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x240E9BD293E","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Assassin_Explorer_DiffuseMap"},{"idx":1,"doku_id":"0x240E9BD2942","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Assassin_Explorer_EmissiveMap"},{"idx":2,"doku_id":"0x240E9BD2944","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_EdwardKenway_Assassin_Explorer_Mask1Map"},{"idx":3,"doku_id":"0x240E9BD2946","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_EdwardKenway_Assassin_Explorer_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]},{"ad":"U_Edward_MasterAssassin","gorunen_ad":"Master Assassin Outfit","EG_id":"0x24E8EF892D5","sinif":"A","guvenlik_puani":100.0,"guvenlik_etiketi":"YESIL","etkilenen_diger_kiyafetler":[],"materyaller":[{"mat_id":"0x2386D70F1E2","parca_adi":"Belt","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F3F0","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F3F4","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F3F6","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Belt_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F3F8","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Belt_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F214","parca_adi":"Bracer","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F3FA","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F3FE","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F400","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Bracer_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F402","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Bracer_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F246","parca_adi":"Dress","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F404","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F408","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F40A","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Dress_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F40C","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Dress_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F278","parca_adi":"Hood","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F40E","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F412","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F414","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Hood_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F416","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Hood_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F2AA","parca_adi":"Pants","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F418","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F41C","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F41E","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Pants_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F420","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Pants_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F2DC","parca_adi":"Rope","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F422","W":1024,"H":1024,"aile":"BC3","srgb":1,"mip":11,"harici_mip":3,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F426","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F428","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Rope_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F42A","W":1024,"H":1024,"aile":"BC7","srgb":0,"mip":11,"harici_mip":3,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Rope_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F30E","parca_adi":"Tunic01","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F42C","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F430","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F432","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic01_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F434","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic01_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F340","parca_adi":"Tunic013","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F440","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F444","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F446","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic013_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F448","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic013_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D70F372","parca_adi":"Tunic02","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D70F436","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_MasterAssassinPackGearset_DiffuseMap"},{"idx":1,"doku_id":"0x2386D70F43A","W":2048,"H":2048,"aile":"BC3","srgb":0,"mip":12,"harici_mip":4,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_MasterAssassinPackGearset_EmissiveMap"},{"idx":2,"doku_id":"0x2386D70F43C","W":2048,"H":2048,"aile":"BC1","srgb":0,"mip":12,"harici_mip":3,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"Tunic02_U_MasterAssassinPackGearset_Mask1Map"},{"idx":3,"doku_id":"0x2386D70F43E","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"Tunic02_U_MasterAssassinPackGearset_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D71117A","parca_adi":"Hidden Blade Right","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D710AC2","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeRight_DiffuseMap"},{"idx":1,"doku_id":"0x2386D710AC6","W":128,"H":128,"aile":"BC3","srgb":0,"mip":8,"harici_mip":0,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeRight_EmissiveMap"},{"idx":2,"doku_id":"0x2386D710AC8","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeRight_Mask1Map"},{"idx":3,"doku_id":"0x2386D710ACA","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeRight_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]},{"mat_id":"0x2386D7111AC","parca_adi":"Hidden Blade Left","boot_forge_icinde":true,"slot_sayisi":4,"slotlar":[{"idx":0,"doku_id":"0x2386D710A83","W":2048,"H":2048,"aile":"BC3","srgb":1,"mip":12,"harici_mip":4,"rol":"Colour (diffuse)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeLeft_DiffuseMap"},{"idx":1,"doku_id":"0x2386D710A87","W":128,"H":128,"aile":"BC3","srgb":0,"mip":8,"harici_mip":0,"rol":"Glow map (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeLeft_EmissiveMap"},{"idx":2,"doku_id":"0x2386D710A89","W":1024,"H":1024,"aile":"BC1","srgb":0,"mip":11,"harici_mip":2,"rol":"Region mask (LOCKED)","duzenlenebilir":false,"referans_dokunma":true,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeLeft_Mask1Map"},{"idx":3,"doku_id":"0x2386D710A8B","W":2048,"H":2048,"aile":"BC7","srgb":0,"mip":12,"harici_mip":4,"rol":"Surface (normal)","duzenlenebilir":true,"referans_dokunma":false,"doku_adi":"CHR_U_MasterAssassinPackGearset_HiddenBladeLeft_NormalMap"}],"paylasim":{"renk":"YESIL","kapsam":"ONLY THIS OUTFIT","kategori":"PRIVATE","etkilenen_kiyafetler":[],"gardirop_disi":false},"kara_liste_doku":[]}]}]"""
CATALOG = json.loads(_CATALOG_JSON)

# --- SILAH KATALOGU (v0.7, BETA) ------------------------------------------------
# Ayni sema, ayri dosya: `silah_katalog.json` (88 silah / 312 slot; okuma yolu
# kiyafet zinciriyle birebir uyumlu olculdu, 99/99 base-shift SAFE). EG_id=None
# tasirlar (silahlar EntityGroup'a bagli degil) ve `sinif="weapon"` ile ayirt
# edilirler. Dosya yoksa arac KIYAFET-ONLY calisir -- silahlar hicbir yolu
# kilitleyemez. ⚠️ Silah diffuse alfasi ~0: SEPARATE_ALPHA duzeltmesi olmadan
# bu kategori ACILAMAZDI (alt mipler kararirdi; duzeltme kurulu + kanitli).
_SILAH_JSON = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "silah_katalog.json")
try:
    with open(_SILAH_JSON, encoding="utf-8") as _f:
        _silahlar = json.load(_f).get("silahlar", [])
    for _g in _silahlar:
        _g.setdefault("sinif", "weapon")
        _g.setdefault("EG_id", None)
        _g.setdefault("etkilenen_diger_kiyafetler", [])
    CATALOG.extend(_silahlar)
except Exception:                                               # noqa: BLE001
    pass                                    # silah dosyasi yok/bozuk -> kiyafet-only

_BY_NAME = {o["ad"]: o for o in CATALOG}
_BY_DISPLAY = {o["gorunen_ad"]: o for o in CATALOG}

# fmt_enum (TextureMap tanimlayicisi) -> imagecodecs BCn kodu ile ayni pf semasi:
#   0x02/0x03 -> BC1(2/3), 0x05 -> BC3(5), 0x0A -> BC7(10)   (sail_engine.bc_decode uyumlu)
_AILE_ENUM = {"BC1": 0x02, "BC3": 0x05, "BC7": 0x0A}
_FMT_BCN   = {"BC1": "bc1", "BC3": "bc3", "BC7": "bc7"}


# =================================================================== KATALOG API
def list_outfits():
    """GUI listesi: her kiyafet icin ozet dict."""
    out = []
    for o in CATALOG:
        boyanabilir = sum(1 for m in o["materyaller"] if not m.get("dokusuz")
                          for s in m["slotlar"] if s["duzenlenebilir"])
        out.append({
            "ad": o["ad"], "gorunen_ad": o["gorunen_ad"], "EG_id": o["EG_id"],
            "sinif": o["sinif"], "guvenlik_etiketi": o["guvenlik_etiketi"],
            "guvenlik_puani": o["guvenlik_puani"],
            "materyal_sayisi": len(o["materyaller"]),
            "boyanabilir_slot": boyanabilir,
            "etkilenen_diger_kiyafetler": o["etkilenen_diger_kiyafetler"],
        })
    return out


def get_outfit(ad):
    """ad ('U_Edward_Yasuke') veya gorunen_ad ('Yasuke') ile kiyafet dondurur."""
    return _BY_NAME.get(ad) or _BY_DISPLAY.get(ad)


def outfit_materials(outfit):
    o = get_outfit(outfit) if isinstance(outfit, str) else outfit
    return o["materyaller"]


def _pretty_outfit(code):
    """A raw forge code name -> a readable outfit name for outfits not in the
    catalogue (they have no gorunen_ad). e.g. U_Edward_SeaSerpent -> Sea Serpent."""
    if code in _BY_NAME:
        return _BY_NAME[code]["gorunen_ad"]
    base = code.replace("U_Edward_", "").replace("Edward_", "")
    return re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', base)


def sharing_label(mat):
    """Sharing label for a material -> (colour, line1, line2). GUI 'Affects' column.

    Confirmed in game on 2026-07-27: painting Edward Kenway's Robes also recoloured
    Pirate Cloak (shared materials) and left Duncan Walpole's Robes untouched (no
    shared material) - exactly as this list predicted, in both directions.

    The count used to be the raw total, which includes wardrobe entries this tool
    does not list (Pirate Cloak, Duncan Walpole, NPC-leaking sets). A user reading
    "also changes 12 outfits" then hunted for 12 in a list of 20 and found 9. The
    line now separates what is selectable here from what only shows up in game."""
    sh = mat["paylasim"]
    satir1 = sh["kapsam"]
    etk = sh["etkilenen_kiyafetler"]
    if not etk:
        return sh["renk"], satir1, "Changes no other outfit."
    katalogda = {o["ad"] for o in CATALOG}
    ic = sorted(_pretty_outfit(e) for e in etk if e in katalogda)
    dis = sorted(_pretty_outfit(e) for e in etk if e not in katalogda)
    def _liste(xs, n=8):
        return ", ".join(xs[:n]) + (" (+%d)" % (len(xs) - n) if len(xs) > n else "")

    if ic and dis:
        satir2 = ("Also changes %d outfit%s in this list: %s   plus %d worn in game but not "
                  "listed here (%s)" % (len(ic), "" if len(ic) == 1 else "s", _liste(ic),
                                        len(dis), _liste(dis, 4)))
    elif ic:
        satir2 = "Also changes %d outfit%s in this list: %s" % (
            len(ic), "" if len(ic) == 1 else "s", _liste(ic))
    else:
        satir2 = ("No other outfit in this list, but it does change %d worn in game: %s"
                  % (len(dis), _liste(dis, 4)))
    return sh["renk"], satir1, satir2


# =================================================================== FORGE OKUMA
_LF = None
_RES_CACHE = {}

# Modul yuklenirken oyunu otomatik bul. Bulursa okuma+yazma yolunu ona set et;
# bulamazsa mevcut sabit degeri KORU (kullanici GUI'den elle secene kadar).
_auto = find_game()
if _auto:
    try:
        set_game(_auto, kaydet=False)
    except ValueError:
        pass


# --- COK-FORGE OKUMA ZINCIRI (2026-09-12, export3d.cok_forge) --------------------------------
# None -> tek forge (FORGE). Aksi halde {"yollar": [...], "sabit": {gid: yol}, "istatistik": {}}:
# `_forge()` FORGE zincirin ILK halkasi oldugu surece birlesik okuma gorunumunu acar (mesh_glb:
# mesh shared_00'da, materyali/dokusu boot'ta -- olculdu, 71 kamara propunun 58'i dokusuzdu).
# YALNIZ OKUMA: yazicilar (doku_enjekte2, kur_mesh) kendi taniticilarini acar, bu zinciri gormez.
# FORGE zincirin ilk halkasi degilse (ic ice _baglam ile arsiv degistiyse) zincir YOKSAYILIR ve
# tek forge acilir -- yanlis birincil okunmasin.
_FORGE_ZINCIR = None


def forge_zinciri_ayarla(yollar=None, sabit=None, birincil=None):
    """Okuma gorunumunu cok-forge yap (`yollar`: oncelik sirasi -- birincilin YAMASI ondan once
    gelebilir) ya da tek forge'a don (None). `birincil`: kullanicinin sectigi arsiv (FORGE ile
    ayni olmali; verilmezse yollar[0]). Acik tanitici kapatilir ve cozulmus govde onbellegi
    bosaltilir -- baska halkanin baytlari eski adin altinda kalmasin. `sabit`: {gid: yol} golge
    kuralindan muaf kimlikler (secilen giris kendi arsivinde kalir)."""
    global _FORGE_ZINCIR
    release_forge(onbellek=True)
    if not yollar:
        _FORGE_ZINCIR = None
    else:
        yollar = [os.path.abspath(p) for p in yollar]
        _FORGE_ZINCIR = {"yollar": yollar,
                         "birincil": os.path.abspath(birincil or yollar[0]),
                         "sabit": {int(k): os.path.abspath(v) for k, v in (sabit or {}).items()},
                         "istatistik": {}}
    return _FORGE_ZINCIR


def forge_zinciri():
    """Etkin zincir sozlugu ya da None (istatistik, gorunum kapatildiktan sonra da okunabilir)."""
    return _FORGE_ZINCIR


def _cok_forge_sinifi():
    try:
        from export3d.cok_forge import CokForge
    except ImportError:                                 # modul dosya yolundan yuklendiyse
        _bura = os.path.dirname(os.path.abspath(__file__))
        if _bura not in sys.path:
            sys.path.insert(0, _bura)
        from export3d.cok_forge import CokForge
    return CokForge


def _forge():
    global _LF
    if _LF is None:
        z = _FORGE_ZINCIR
        if (z and FORGE and
                os.path.normcase(os.path.abspath(FORGE)) == os.path.normcase(z["birincil"])):
            _LF = _cok_forge_sinifi()(z["yollar"], sabit=z["sabit"], istatistik=z["istatistik"],
                                      birincil=z["birincil"])
        else:
            _LF = LeanForge(FORGE)
    return _LF


def _material_res(mat_id):
    """materyalin cozulmus govdesi (block2 = yalin_forge tabani). ONBELLEKLI."""
    key = mat_id if isinstance(mat_id, int) else int(mat_id, 16)
    if key not in _RES_CACHE:
        lf = _forge()
        if key not in lf.by_id:
            raise KeyError("material 0x%X not in forge" % key)
        _RES_CACHE[key] = decompress(lf.read_raw(key))
    return _RES_CACHE[key]


def _slot_tanim(mat_id, slot):
    """(hdr_off, doku_id, tanim) forge'dan olculur (doku_enjekte2 ile ayni yol)."""
    res = _material_res(mat_id)
    tms = DE.tm_bloklari(res)
    if slot >= len(tms):
        raise IndexError("slot %d does not exist (%d texture maps)" % (slot, len(tms)))
    hdr, tex = tms[slot]
    return hdr, tex, DE.tanim_oku(res, hdr), res, tms


def _external_mip0(doku_id):
    """slot dokusunun level-0 (tam cozunurluk) harici RawAsset baytlari, ya da None.

    Onek 0x8'dir, 0xA DEGIL (09-04 duzeltmesi -- eskiden bit 41'i de gereksiz set ediyordu;
    `ship/hkm_ortak.mip_fid` ayni kurali hep 0x8 ile yazmisti, export3d/doku_png.py'nin
    MIP_ID_ONEK'i de 0x8; bkz. o dosyadaki '(1) HARICI MIP KIMLIGI' notu). OLCULEN etki
    (outfit_core.CATALOG'un 25 kiyafet / 1.133 slotu, mip0_blast_radius.py, scratchpad):
    id URETIMI 0 slotta farkli (katalogdaki hicbir doku_id'nin bit 41'i bos degil) -> bu
    duzeltme APPLY/EDIT/export_outfit akisinda OLCULEBILIR HICBIR DAVRANIS DEGISTIRMEDI,
    yalniz export3d/CHR_* tarafinda (hair/beard gibi bit-41-bos id'lerde) kazanc saglar."""
    base = (0x80000000000 | doku_id) << 20
    rid = base | 0
    lf = _forge()
    if rid in lf.by_id:
        off, ln, ext = lf.by_id[rid]
        lf.f.seek(off)
        return lf.f.read(ln)
    return None


def _embedded_mip0(res, tanim, hdr, tms, slot):
    """harici mip'i olmayan slot icin gomulu kuyruktan level-0'i sik (de-pad) dondurur."""
    veri_bas = hdr + 14
    veri_son = tms[slot + 1][0] if slot + 1 < len(tms) else len(res)
    c = DE.cipa_bul(res, veri_bas, veri_son)
    if not c:
        return None
    _, piksel_bas, uzunluk = c
    # harici mip sayisi 0 varsayilir (bu yol yalniz harici=0 slotlarda cagrilir)
    yer, _tot = DE.yerlesim(tanim["W"], tanim["blok"], 0, uzunluk, tanim["H"])
    if not yer:
        return None
    lvl, roff, pitch, satir, rb = yer[0]      # level 0
    taban = piksel_bas + roff
    out = bytearray()
    for r in range(satir):
        out += res[taban + r * pitch: taban + r * pitch + rb]
    return bytes(out)


def slot_mip0_bc(mat_id, slot):
    """slotun level-0 sikistirilmis BC blok baytlari (harici varsa harici, yoksa gomulu)."""
    hdr, tex, tanim, res, tms = _slot_tanim(mat_id, slot)
    data = _external_mip0(tex)
    if data is None:
        data = _embedded_mip0(res, tanim, hdr, tms, slot)
    return data, tanim


# =================================================================== DECODE
_BCN = {}                    # secilen cozucu: {"ad", "fn", "hata"} (ilk kullanimda dolar)
_BCN_KOD = {"BC1": 1, "BC2": 2, "BC3": 3, "BC4": 4, "BC5": 5, "BC6H": 6, "BC7": 7}


def _bcn_cozucu():
    """(ad, fn) -- fn(chunk, kod, w4, h4) -> RGBA uint8 (h4, w4, 4).

    Once imagecodecs.bcn_decode (mevcut yol). OLCULDU (2026-09-12): bu makinede imagecodecs'in
    `_bcn` uzantisi Application Control tarafindan BLOKLU ("DelayedImportError: could not import
    name 'bcn_decode'") ve butun doku PNG ciktisi sessizce olu kaliyordu. Yedek: texture2ddecoder
    (BC1/BC3/BC7 ve varsa BC2/BC4/BC5/BC6H). Kapi (ALT_GUVERTE/disa_aktarma/kapi_bcn.py, gercek
    oyun dokulari): 14 dokunun 12'si Pillow'un BAGIMSIZ DDS cozucusuyle bayt-birebir; 2 fark
    yalniz GECERSIZ-MOD (tumu sifir) BC7 bloklarinin alfasinda (spec: seffaf siyah).
    Hangisinin kullanildigi `bcn_cozucu_adi()` ile sorulur; ikisi de yoksa ImportError."""
    if "fn" in _BCN:
        return _BCN["ad"], _BCN["fn"]
    import numpy as np
    hatalar = []
    try:
        from imagecodecs import bcn_decode
        bcn_decode(bytes(8), 1, shape=(4, 4, 4))          # tembel uzanti GERCEKTEN yukleniyor mu?

        def _ic(chunk, kod, w4, h4):
            return np.asarray(bcn_decode(chunk, kod, shape=(h4, w4, 4)))
        _BCN.update(ad="imagecodecs", fn=_ic, hata=None)
        return _BCN["ad"], _BCN["fn"]
    except Exception as e:                                  # noqa: BLE001 -- Import/Delayed/OSError
        hatalar.append("imagecodecs: %s" % str(e)[:160])
    try:
        import texture2ddecoder as T
        fnler = {}
        for kod, ad in ((1, "decode_bc1"), (2, "decode_bc2"), (3, "decode_bc3"), (4, "decode_bc4"),
                        (5, "decode_bc5"), (6, "decode_bc6"), (7, "decode_bc7")):
            if hasattr(T, ad):
                fnler[kod] = getattr(T, ad)
        if not fnler:
            raise ImportError("texture2ddecoder has no decode_bc* functions")

        def _t2(chunk, kod, w4, h4):
            if kod not in fnler:
                raise ValueError("texture2ddecoder cannot decode BC%d" % kod)
            raw = fnler[kod](bytes(chunk), w4, h4)         # BGRA32
            arr = np.frombuffer(raw, np.uint8).reshape(h4, w4, 4)
            return arr[:, :, [2, 1, 0, 3]]                 # BGRA -> RGBA
        _BCN.update(ad="texture2ddecoder", fn=_t2, hata="; ".join(hatalar))
        return _BCN["ad"], _BCN["fn"]
    except Exception as e:                                  # noqa: BLE001
        hatalar.append("texture2ddecoder: %s" % str(e)[:160])
    raise ImportError("no BCn decoder available (%s)" % "; ".join(hatalar))


def bcn_cozucu_adi():
    """'imagecodecs' | 'texture2ddecoder' (ilk cagride secilir); hicbiri yoksa ImportError."""
    return _bcn_cozucu()[0]


def _bc_decode_rgba(data, W, H, fmt_enum, report=None, aile=None):
    """BC blok verisini RGBA diziye acar (serit serit; buyuk dokuda bellek dostu).

    `aile` verilirse enum tablosuna bakilmaz: export tarafinin OLCULMUS ek enum'lari
    (doku_png.ENUM_AILE_EK: 0x06 -> BC1) yazicinin tablosuna (DE.ENUM_AILE) girmeden cozulur."""
    import numpy as np
    aile = aile or DE.ENUM_AILE[fmt_enum]
    code = _BCN_KOD[aile]
    bpb = DE.AILE_BLOK[aile]
    _ad, coz = _bcn_cozucu()
    BW, BH = (W + 3) // 4, (H + 3) // 4
    out = np.empty((BH * 4, BW * 4, 4), dtype=np.uint8)
    step = max(1, 256 // 4)
    for by in range(0, BH, step):
        n = min(step, BH - by)
        chunk = data[by * BW * bpb:(by + n) * BW * bpb]
        out[by * 4:(by + n) * 4] = coz(chunk, code, BW * 4, n * 4)
        if report:
            report(min(1.0, (by + n) / float(BH)))
    return out[:H, :W]


def _leather_or_cloth(alpha):
    """s3 (normal) alfa bandindan deri/kumas tahmini. deri 80-180, kumas 200-255."""
    import numpy as np
    a = np.asarray(alpha)
    med = int(np.median(a))
    deri = int(((a >= 80) & (a <= 180)).mean() * 100)
    kumas = int((a >= 200).mean() * 100)
    tur = "leather" if deri > kumas else ("cloth" if kumas > deri else "mixed")
    return {"medyan_alfa": med, "deri_yuzde": deri, "kumas_yuzde": kumas, "tur": tur}


# =================================================================== EXPORT
def _slot_filename(mat_id, slot_idx, W, H, aile, ext="png"):
    """doku_enjekte2'nin (A) formatinda okuyabilecegi dosya adi.
       IC_<matID>_tm<matID>_<SLOT>_<WxH>_<WxH>_<FMT>.<ext>   (matID: 0x YOK)"""
    hexid = ("%X" % (mat_id if isinstance(mat_id, int) else int(mat_id, 16)))
    return "IC_%s_tm%s_%d_%dx%d_%dx%d_%s.%s" % (
        hexid, hexid, slot_idx, W, H, W, H, aile, ext)


def _log(progress, text):
    if progress:
        try:
            progress(text)
        except Exception:
            pass


# --- degismemis-slot atlama yardimcilari --------------------------------------
# export ANINDA her EDIT png'sinin sha256'si `EDIT/.orijinal_sha.json` manifestine
# yazilir. status/apply, PNG'nin GUNCEL sha'sini manifesttekiyle karsilastirir:
# esitse kullanici o slotu HIC degistirmemis -> encode ATLANIR (forge zaten dogru).
MANIFEST_ADI = ".orijinal_sha.json"


def _sha256_file(path):
    """dosyanin sha256 hex ozeti (serit serit; buyuk PNG'de bellek dostu)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# encode sure tahmini: SADECE BC7 icin OLCULDU (2048 -> ~60sn, 4096 -> ~239sn;
# piksel basina ~1.43e-5 sn, ikisi de ayni orani veriyor -> piksel-lineer).
# BC1/BC3 encode suresi OLCULMEDI -> onlar icin tahmin dondurulmez (None).
_BC7_SN_PER_PX = 60.0 / (2048 * 2048)


def _encode_estimate_sec(aile, W, H):
    """slotun encode suresi kaba tahmini (sn) ya da olculmemisse None."""
    if aile == "BC7":
        return max(1, int(round(_BC7_SN_PER_PX * W * H)))
    return None


def export_outfit(outfit, out_dir, progress=None):
    """secili kiyafetin TUM materyallerinin TUM slotlarini PNG olarak cikarir.

    Klasor duzeni:
      out_dir/<kiyafet>/EDIT/<matid>/IC_..._0_...png   (s0 diffuse - EDITABLE)
                                        IC_..._3_...png   (s3 normal  - EDITABLE)
      out_dir/<kiyafet>/_reference_do_not_edit/<matid>/IC_..._1_...png (s1 mask - DO NOT EDIT)
                                                   IC_..._2_...png (s2       - DOKUNMA)
      out_dir/<outfit>/README.txt
    Dosya adlari doku_enjekte2'nin (A) formatiyla birebir uyumludur (apply icin).
    FLIP YOK. Normal (s3) alfasi (deri/kumas) korunarak RGBA yazilir.
    Doner: {kiyafet, klasor, yazilan:[...], atlanan:[...]}
    """
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = None
    o = get_outfit(outfit) if isinstance(outfit, str) else outfit
    if o is None:
        raise ValueError("outfit not found: %r" % outfit)
    kok = os.path.join(out_dir, o["ad"])
    duz = os.path.join(kok, "EDIT")
    ref = os.path.join(kok, "_reference_do_not_edit")
    os.makedirs(duz, exist_ok=True)
    os.makedirs(ref, exist_ok=True)

    yazilan, atlanan, korunan = [], [], []
    # Onceki export'un sha temeli: bir dosyanin BOYANMIS mi yoksa dokunulmamis mi
    # oldugunu ancak bununla ayirt edebiliriz.
    eski_manifest = {}
    _mp = os.path.join(duz, MANIFEST_ADI)
    if os.path.isfile(_mp):
        try:
            with open(_mp, encoding="utf-8") as f:
                eski_manifest = json.load(f)
        except Exception as e:
            _log(progress, "  UYARI: onceki manifest okunamadi (%s) -> var olan "
                           "PNG'ler boyanmis SAYILIR ve korunur." % e)
    slots_all = [(m, s) for m in o["materyaller"] if not m.get("dokusuz")
                 for s in m["slotlar"]]
    toplam = len(slots_all)
    done = 0
    safe_word = {"YESIL": "SAFE", "SARI": "CAUTION", "KIRMIZI": "RISK"}.get(
        o["guvenlik_etiketi"], o["guvenlik_etiketi"])
    okubeni = ["OUTFIT WORKSHOP export -- %s (%s)" % (o["gorunen_ad"], o["ad"]),
               "EntityGroup: %s   safety: %s (score %.1f)" % (
                   o["EG_id"], safe_word, o["guvenlik_puani"]),
               "=" * 68,
               "Paint the s0 (Colour) and s3 (Surface/normal) PNGs in the EDIT/ folder.",
               "Do NOT touch the _reference_do_not_edit/ folder - those are region "
               "masks and glow maps; painting them breaks the part boundaries.",
               "Do NOT change size or file names. Do NOT flip. Save as PNG.",
               ""]

    for m in o["materyaller"]:
        if m.get("dokusuz"):
            okubeni.append("  [NO TEXTURE] %s -> cannot be painted (no texture)" % m["mat_id"])
            continue
        renk, s1, s2 = sharing_label(m)
        okubeni.append("MATERIAL %s   [%s] %s" % (m["mat_id"], renk, s1))
        for s in m["slotlar"]:
            idx = s["idx"]; W, H, aile = s["W"], s["H"], s["aile"]
            fmt_enum = _AILE_ENUM[aile]
            hedef_kok = duz if s["duzenlenebilir"] else ref
            mdir = os.path.join(hedef_kok, m["mat_id"])
            os.makedirs(mdir, exist_ok=True)
            fn = _slot_filename(m["mat_id"], idx, W, H, aile)
            path = os.path.join(mdir, fn)
            try:
                data, tanim = slot_mip0_bc(m["mat_id"], idx)
                if data is None:
                    atlanan.append((fn, "mip0 not found (no external+embedded)"))
                    okubeni.append("    s%d %s  SKIPPED (no mip0)" % (idx, s["rol"]))
                    continue
                gerek = ((W + 3) // 4) * ((H + 3) // 4) * DE.AILE_BLOK[aile]
                if len(data) < gerek:
                    atlanan.append((fn, "mip0 kisa %d<%d" % (len(data), gerek)))
                    okubeni.append("    s%d %s  SKIPPED (mip0 too short)" % (idx, s["rol"]))
                    continue
                # BOYANMIS DOSYANIN USTUNE YAZMA. Export eskiden kosulsuz kaydediyordu:
                # ayni kiyafeti ikinci kez disa aktaran tasarimci butun emegini
                # kaybediyordu (README'de "asla ustune yazmaz" YAZIYORDU, dogru degildi).
                # Karar manifeste gore: sha export-anindakiyle ayniysa dosyaya
                # DOKUNULMAMIS demektir, tazelemek zararsiz; farkliysa BOYANMIS.
                if s["duzenlenebilir"] and os.path.exists(path):
                    onceki = eski_manifest.get(os.path.relpath(path, duz).replace("\\", "/"))
                    simdiki = _sha256_file(path)
                    if onceki is None or simdiki != onceki:
                        korunan.append(path)
                        okubeni.append("    s%d %s -> %s  KEPT (you painted this; "
                                       "delete it if you want a fresh copy)" % (idx, s["rol"], fn))
                        done += 1
                        _log(progress, "  kept (painted): %s" % fn)
                        continue
                arr = _bc_decode_rgba(data[:gerek], W, H, fmt_enum)
                # s0 diffuse: RGB (opak). s1/s2/s3: alfa tasiyabilir -> RGBA yaz.
                if idx == 0:
                    Image.fromarray(arr[..., :3]).save(path)
                else:
                    Image.fromarray(arr, "RGBA").save(path)
                info = ""
                if idx == 3:
                    lc = _leather_or_cloth(arr[..., 3])
                    info = "  (%s: leather%%%d cloth%%%d)" % (lc["tur"], lc["deri_yuzde"], lc["kumas_yuzde"])
                yazilan.append(path)
                okubeni.append("    s%d %s -> %s%s" % (idx, s["rol"], fn, info))
            except Exception as e:
                atlanan.append((fn, str(e)))
                okubeni.append("    s%d %s  ERROR: %s" % (idx, s["rol"], e))
            done += 1
            _log(progress, "  export %d/%d  %s s%d" % (done, toplam, m["mat_id"], idx))
        okubeni.append("      %s" % s2)
        okubeni.append("")

    with open(os.path.join(kok, "README.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(okubeni))

    # DEGISMEMIS-SLOT MANIFESTI: her png'nin export-anindaki sha256'si.
    # status/apply bunu kullanarak kullanicinin dokunmadigi slotlari encode ETMEZ.
    # KORUNAN (boyanmis) dosyalarin girisi ESKI HALIYLE kalir -- yoksa manifest
    # boyali dosyanin sha'sini "orijinal" diye kaydeder ve apply o slotu
    # "degismemis" sayip ATLAR; kullanicinin emegi hic uygulanmazdi.
    manifest = dict(eski_manifest)
    korunan_rel = {os.path.relpath(p, duz).replace("\\", "/") for p in korunan}
    for pf in glob.glob(os.path.join(duz, "**", "*.png"), recursive=True):
        rel = os.path.relpath(pf, duz).replace("\\", "/")
        # `and rel in eski_manifest` KOSULU YOKTU-EDILDI: koruma tam gerektigi anda
        # (manifest silinmis/bozuk) kendini iptal ediyordu -- korunan BOYALI dosyanin
        # sha'si "orijinal" diye kaydediliyor, apply o slotu "degismemis" sanip
        # atliyor ve kullanicinin emegi hic uygulanmiyordu. Anahtar yoksa iki okuyucu
        # da onu "degismis" sayar, ki dogru davranis budur.
        if rel in korunan_rel:
            continue                      # boyanmis: temeli BOZMA
        manifest[rel] = _sha256_file(pf)
    with open(os.path.join(duz, MANIFEST_ADI), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=1)
    _log(progress, "manifest: %d slot (%d korunan giris dokunulmadi)"
         % (len(manifest), len(korunan_rel & set(eski_manifest))))

    _log(progress, "export bitti: %d yazildi, %d korundu (boyanmis), %d atlandi -> %s" %
         (len(yazilan), len(korunan), len(atlanan), kok))
    if korunan:
        _log(progress, "  NOT: %d dosya boyanmis oldugu icin KORUNDU. Taze kopya "
                       "istiyorsan o dosyayi silip tekrar export et." % len(korunan))
    return {"kiyafet": o["ad"], "klasor": kok, "yazilan": yazilan, "atlanan": atlanan,
            "korunan": korunan, "manifest": manifest}


# =================================================================== ENCODE / UYGULA
# SONU BAGLI (\.png$): eskiden bu desen bir ON EK eslesmesiydi, yani
# "IC_..._BC3.png" ile onun yaninda duran "IC_..._BC3 (1).png" veya
# "IC_..._BC3_eski.png" AYNI (materyal, slot) cozuluyordu ve sirali listede
# hangisi one duserse forge'a O yaziliyordu -- kullanicinin boyadigi dosya
# degil. Paylasilan tasarimlarda tarayici indirmeleri tam olarak " (1)" ekler.
_SLOT_RE = re.compile(r"IC_([0-9A-Fa-f]+)_tm[0-9A-Fa-f]+_(\d+)_(\d+)x(\d+)_\d+x\d+_(BC[137])\.png$",
                      re.I)


def _prepare_png(png, W, H, aile, progress=None):
    """temiz, WxH boyutunda PNG dondurur. sRGB/gAMA/ICC profili atilir.
       s0 (BC1 diffuse) opak -> RGB. Alfa tasiyan slot (BC3/BC7) -> alfa KORUNUR."""
    import numpy as np
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = None
    with Image.open(png) as im:
        w, h = im.size
        alfa_koru = (aile != "BC1")
        if alfa_koru and "A" in im.getbands():
            work = im.convert("RGBA")
        elif alfa_koru:
            work = im.convert("RGBA")
        else:
            work = im.convert("RGB")
        if (w, h) != (W, H):
            if progress:
                if w < W or h < H:
                    _log(progress, "  UYARI: %dx%d -> %dx%d buyutuluyor (detay artmaz)." % (w, h, W, H))
                else:
                    _log(progress, "  yeniden boyut %dx%d -> %dx%d" % (w, h, W, H))
            work = work.resize((W, H), Image.LANCZOS)
        arr = np.asarray(work)
    clean = os.path.join(tempfile.gettempdir(),
                         "OutfitWorkshop_input_%s.png" % os.getpid())
    Image.fromarray(arr).save(clean)   # fromarray -> renk profili tasimaz
    return clean


# WINDOWS SMART APP CONTROL (2026-10-25): SAC acik makinede imzasiz tools\TexEncode.dll
# yuklenemiyor ("An Application Control policy has blocked this file", 0x800711C7). Uygulama
# calisir, yalniz PNG -> DDS kodlama durur. Ham .NET yigini yerine bunu soyleriz.
SAC_IMZALARI = ("Application Control policy", "0x800711C7")
TEXENCODE_SAC_MESAJ = (
    "Windows Smart App Control blocked Workshop's texture encoder (tools\\TexEncode.dll), so no "
    "texture could be converted and nothing was written to the game. This is a Windows security "
    "setting, not a broken download. Everything else in Workshop still works; painting and "
    "installing PNG textures need Windows to allow the encoder (Windows Security > App & "
    "browser control > Smart App Control).")


def _sac_engeli_mi(metin):
    return any(i in (metin or "") for i in SAC_IMZALARI)


def tex_encode_durumu():
    """Kodlayici GERCEKTEN calisabiliyor mu? Arguman vermeden bir kez kosturur (yazma yok).
    Doner {'var': bool, 'sac': bool, 'cikti': str}. SAC engeli ciktida imzadan anlasilir."""
    exe = os.path.join(TOOLS_DIR, "TexEncode.exe")
    if not os.path.isfile(exe):
        return {"var": False, "sac": False, "cikti": ""}
    try:
        p = subprocess.run([exe], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                           timeout=30, cwd=TOOLS_DIR,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        cikti = p.stdout or ""
    except Exception as e:                                      # noqa: BLE001
        cikti = str(e)
    return {"var": True, "sac": _sac_engeli_mi(cikti), "cikti": cikti[-400:]}


def _tex_encode(png, dds, srgb, bcn, progress=None, on_frac=None):
    """TexEncode.exe ile PNG -> DDS. exe kullanilir (dotnet dll apphost'ta calismaz).

    TexEncode calisirken `PROGRESS <yapilan> <toplam>` satirlari basiyor (bir 2048
    icin ~52 satir). Eskiden `subprocess.run` ile hepsi toplanip ATILIYORDU: bir
    BC7 slotu iki dakika surerken ekranda hicbir sey kimildamiyor, kullanici
    program dondu sanip pencereyi kapatiyordu -- ki yazma ortasinda kapatmak en
    tehlikeli an. Artik satir satir okunuyor ve `on_frac(0..1)` ile bildiriliyor."""
    exe = os.path.join(TOOLS_DIR, "TexEncode.exe")
    if not os.path.isfile(exe):
        raise RuntimeError("TexEncode.exe is missing: %s" % exe)
    args = [exe, png, dds]
    if srgb:
        args.append("srgb")
    args.append(bcn)
    NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    if os.path.exists(dds):
        try: os.remove(dds)
        except OSError: pass
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, bufsize=1, cwd=TOOLS_DIR, creationflags=NO_WINDOW)
    kuyruk = []
    for satir in p.stdout:
        satir = satir.strip()
        if not satir:
            continue
        if satir.startswith("PROGRESS "):
            if on_frac:
                bit = satir.split()
                try:
                    yapilan, toplam = int(bit[1]), int(bit[2])
                except (IndexError, ValueError):
                    continue
                if toplam > 0:
                    try:
                        on_frac(yapilan / float(toplam))
                    except Exception:
                        pass
            continue
        kuyruk.append(satir)
        if len(kuyruk) > 40:
            del kuyruk[0]
    p.wait()
    if p.returncode != 0 or not os.path.isfile(dds) or os.path.getsize(dds) < 128:
        if _sac_engeli_mi(" ".join(kuyruk)):
            raise RuntimeError(TEXENCODE_SAC_MESAJ)
        raise RuntimeError("TexEncode failed (%s): %s" % (bcn, " | ".join(kuyruk[-6:])))
    return dds


def _catalog_slot(mat_id, slot):
    """katalogdan slot kaydini bul (srgb/aile icin)."""
    for o in CATALOG:
        for m in o["materyaller"]:
            if m["mat_id"].upper() == ("0x%X" % int(mat_id, 16)).upper():
                for s in m["slotlar"]:
                    if s["idx"] == slot:
                        return s
    return None


def _design_pngleri(kaynak):
    """Bir tasarim klasorunde HANGI PNG'lerin sayilacagi.

    Tasarimcilar boyadiklari dosyanin yanina vanilla halini `Original\\` gibi bir
    alt klasorde saklıyor. Ic ice tarama o yedegi de tasarimin parcasi sanip AYNI
    slota iki dosya buluyor ve "hangisini kastettin" diye reddediyordu. Kural:
      * EDIT agaci  -> ic ice tara (materyaller zaten alt klasor)
      * klasorun KENDINDE doku varsa -> sadece o dosyalar + `0x<materyal>` klasorleri
        (baska adli alt klasorler kullanicinin kendi yedegi, karismayiz)
      * hicbiri -> ic ice tara"""
    dogrudan = sorted(glob.glob(os.path.join(kaynak, "*.png")))
    # Duz-paylasim modunu yalniz TANINAN adlar acar; ama moda girildiginde
    # taninmayanlar da dondurulur, yoksa "su dosyanin adini anlamadim" teshisi
    # kaybolur ve kullanici neden hicbir seyin uygulanmadigini ogrenemez.
    if (os.path.basename(os.path.normpath(kaynak)).upper() == "EDIT"
            or not any(_SLOT_RE.match(os.path.basename(p)) for p in dogrudan)):
        return sorted(glob.glob(os.path.join(kaynak, "**", "*.png"), recursive=True))
    ic = []
    for d in sorted(glob.glob(os.path.join(kaynak, "0x*"))):
        if os.path.isdir(d):
            ic.extend(sorted(glob.glob(os.path.join(d, "**", "*.png"), recursive=True)))
    return dogrudan + ic


def _gormezden_gelinenler(kaynak, alinanlar):
    """Sekil kurali yuzunden DISARIDA kalan, ama adi gecerli olan dokular.

    `Original\\` yedegini gormezden gelmek dogru; ama ayni kural `Bracers\\` gibi
    tasarimin GERCEK bir parcasini da sessizce atiyor -- yari uygulanmis kiyafet
    cikiyor ve log "basarili" diyor. Zaten kabul edilen bir (materyal, slot) icin
    yedek olanlar sessiz kalir; sadece HIC kapsanmayanlar bildirilir."""
    kapsanan = set()
    for p in alinanlar:
        m = _SLOT_RE.match(os.path.basename(p))
        if m:
            kapsanan.add(("0x" + m.group(1).upper(), int(m.group(2))))
    alinan_set = {os.path.normcase(p) for p in alinanlar}
    disarida = []
    for p in sorted(glob.glob(os.path.join(kaynak, "**", "*.png"), recursive=True)):
        if os.path.normcase(p) in alinan_set:
            continue
        if "/_reference_do_not_edit/" in p.replace("\\", "/"):
            continue
        m = _SLOT_RE.match(os.path.basename(p))
        if not m:
            continue
        if ("0x" + m.group(1).upper(), int(m.group(2))) in kapsanan:
            continue                      # ayni slotun yedek kopyasi -- sessiz kal
        disarida.append(os.path.relpath(p, kaynak))
    return disarida


def _design_adaylari(kaynak, progress=None):
    """Bir klasordeki (ic ice dahil) PNG'leri tanir. ENCODE ETMEZ, forge'a dokunmaz.

    Hem aracin kendi export duzenini (<kiyafet>/EDIT/<materyal>/IC_*.png) hem de
    PAYLASILAN DUZ klasorleri kabul eder: dosya adi materyal kimligini, slotu,
    boyutu ve formati zaten tasidigi icin klasor yapisinin bir onemi yok. Toplulukta
    tasarimlar zip olarak el degistiriyor ve o zipler duz bir PNG yigini.

    Doner: (adaylar, tani) -- adaylar: [(png, mat_id, slot, cs)]"""
    pngs = _design_pngleri(kaynak)
    adaylar = []
    tani = {"taninmayan": [], "katalog_disi": [], "kilitli": 0, "cakisan": [],
            "gormezden_gelinen": _gormezden_gelinenler(kaynak, pngs)}
    goruldu = {}
    for png in pngs:
        base = os.path.basename(png)
        yol = png.replace("\\", "/")
        if "/_reference_do_not_edit/" in yol:
            continue
        m = _SLOT_RE.match(base)
        if not m:
            tani["taninmayan"].append(base)
            _log(progress, "  skipped (name not recognised): %s" % base)
            continue
        mat_id = "0x" + m.group(1)
        slot = int(m.group(2))
        cs = _catalog_slot(mat_id, slot)
        if cs is None:
            tani["katalog_disi"].append(base)
            _log(progress, "  skipped (slot not in catalogue): %s" % base)
            continue
        # ⚠️ DUZENLENEBILIRLIGE TEK YER KARAR VERIR: KATALOG.
        # Burada eskiden `cs["idx"] in (1, 2)` yaziyordu, yani kilitlilik slot
        # INDEKSINDEN cikariliyordu. Ama rol slot indeksine gore SABIT DEGIL:
        # 2026-07-29 olcumu, idx2'nin cogu materyalde Mask1Map ama SEKIZ slotta
        # GERCEK NormalMap/DiffuseMap oldugunu gosterdi (ornek: Yasuke'nin haidate
        # etegi ve do zirhi -- kullanici bunlari hic boyayamiyordu).
        # Katalog artik rolu DOKU ADINDAN cozuyor; export o bayraga gore dosya
        # uretiyor. Burasi da ayni bayragi okumazsa export ettigi dosyayi kendi
        # reddeder (olculdu: Fire 4 PNG export etti, tarayici 3 tanidi).
        if not cs.get("duzenlenebilir", cs["idx"] not in (1, 2)):
            tani["kilitli"] += 1
            _log(progress, "  skipped (s%d is reference/locked): %s" % (cs["idx"], base))
            continue
        anahtar = (mat_id, slot)
        if anahtar in goruldu:
            tani["cakisan"].append("%s  <->  %s" % (os.path.basename(goruldu[anahtar]), base))
            continue
        goruldu[anahtar] = png
        adaylar.append((png, mat_id, slot, cs))
    return adaylar, tani


def _design_konteyner(design_dir):
    """design_dir tek bir tasarim mi, yoksa BIRDEN COK tasarimi tutan ust klasor mu?

    Ust klasor secildiginde ic ice tarama ALTTAKI TUM kiyafetlerin dokularini
    toplar ve hepsini birden uygulardi -- tek bir yanlis tiklamayla. Ayirt edici
    sinyal: bir tasarimin kendi alt klasorleri MATERYAL kimligiyle adlandirilir
    (`0x...`); baska adli bir alt klasor icinde doku varsa o AYRI bir tasarimdir.
    Doner: ayri tasarim gibi duran alt klasor adlari (bos ise design_dir tek tasarim)."""
    if os.path.isdir(os.path.join(design_dir, "EDIT")):
        return []                                   # aracin kendi export duzeni
    if [p for p in glob.glob(os.path.join(design_dir, "*.png"))
            if _SLOT_RE.match(os.path.basename(p))]:
        return []                                   # dogrudan icinde doku var -> duz paylasim
    # .dds de "doku"dur: topluluk modlarinin cogu oyunun kendi blok biciminde
    # dagitiliyor ve o klasorde tek bir PNG olmuyor. Burasi yalniz PNG'ye
    # baktigi surece DDS-only bir tasarim "duz paylasim" sayilmiyor, alt
    # klasorlere iniliyor ve klasor bos gorunuyordu (OLCULDU 2026-09-09:
    # EDWARD_ROBES_EDIT, 4 dds -> "No recognisable texture files").
    if [p for p in glob.glob(os.path.join(design_dir, "*.dds"))
            if _dds_hedefi(os.path.basename(p))[0] is not None]:
        return []
    alt = []
    try:
        for ad in sorted(os.listdir(design_dir)):
            p = os.path.join(design_dir, ad)
            if not os.path.isdir(p) or ad.lower().startswith("0x"):
                continue                            # 0x... = bu tasarimin materyal klasoru
            k = _design_kaynak(p)
            if _design_adaylari(k)[0] or _design_dds_adaylari(k)[0]:
                alt.append(ad)
    except OSError:
        pass
    return alt


def scan_design_dir(design_dir):
    """SALT OKUNUR on kontrol: bu klasor uygulanabilir mi? Encode etmez, yazmaz.

    GUI, Apply'a basildiginda "EDIT alt klasoru yok" diye reddetmek yerine bunu
    kullanir: kullanici ya paylasilan duz bir tasarim klasoru secmistir (gecerli),
    ya bir ust klasoru secmistir (icindekileri isimleriyle soyleriz), ya da tanidik
    hicbir dosya yoktur (nedenini soyleriz)."""
    alt = _design_konteyner(design_dir)
    if alt:
        return {"kaynak": design_dir, "sayi": 0, "materyaller": [],
                "alt_tasarimlar": alt,
                "degismis": 0, "manifest_var": False,
                "tani": {"taninmayan": [], "katalog_disi": [], "kilitli": 0,
                         "cakisan": [], "gormezden_gelinen": []}}
    kaynak = _design_kaynak(design_dir)
    adaylar, tani = _design_adaylari(kaynak)
    # DDS adaylari PNG'lerle AYNI listeye girer: bu kapi "bu klasorde uygulanacak
    # bir sey var mi" diye sorar, "PNG var mi" diye degil. Encode yolu (`_encode_
    # design_dir` -> `_design_dds_uygula`) DDS'i zaten yaziyordu; yalniz bu on
    # kapi PNG sayiyordu ve kurulumu daha baslamadan reddediyordu.
    dds_adaylar, dds_tani = _design_dds_adaylari(kaynak)
    adaylar = adaylar + dds_adaylar
    tani["taninmayan"] = list(tani["taninmayan"]) + dds_tani["taninmayan"]
    tani["katalog_disi"] = list(tani["katalog_disi"]) + dds_tani["katalog_disi"]
    tani["kilitli"] = tani["kilitli"] + dds_tani["kilitli"]
    tani["gormezden_gelinen"] = (list(tani.get("gormezden_gelinen") or [])
                                 + list(dds_tani.get("gormezden_gelinen") or []))
    # Kac dosya GERCEKTEN boyanmis? Manifest yoksa (paylasilan tasarim, elle
    # hazirlanmis klasor) hepsi degismis sayilir. GUI bunu, "bu klasorde is var mi"
    # sorusunu yanitlamak icin kullanir: dokunulmamis bir export klasoru varken
    # kullanicinin BASKA bir yerde hazirladigi tasarimi es gecmemeli.
    man = {}
    mp = os.path.join(kaynak, MANIFEST_ADI)
    if os.path.isfile(mp):
        try:
            with open(mp, encoding="utf-8") as f:
                man = json.load(f)
        except Exception:
            man = {}
    degismis = 0
    for png, _mat, _slot, _cs in adaylar:
        rel = os.path.relpath(png, kaynak).replace("\\", "/")
        if rel not in man or _sha256_file(png) != man[rel]:
            degismis += 1
    return {"kaynak": kaynak, "sayi": len(adaylar), "degismis": degismis,
            "manifest_var": bool(man),
            "materyaller": sorted({a[1] for a in adaylar}),
            "alt_tasarimlar": [], "tani": tani}


def _design_kaynak(design_dir):
    """Aracin kendi export duzeninde PNG'ler EDIT altinda; paylasilan klasorde
    dogrudan klasorun kendisinde."""
    duz = os.path.join(design_dir, "EDIT")
    return duz if os.path.isdir(duz) else design_dir


_DDS_IC_RE = re.compile(r"IC_([0-9A-Fa-f]{9,13})_tm[0-9A-Fa-f]{9,13}_(\d+)_", re.I)
_DDS_0X_RE = re.compile(r"0x([0-9A-Fa-f]{9,13})", re.I)
_DDS_SLOT_ET_RE = re.compile(r"(?:^|[_\-.])s(?:lot)?(\d+)(?:[_\-.]|$)", re.I)


def _design_ddsleri(kaynak):
    """Tasarim klasorundeki .dds dosyalari (_design_pngleri ile AYNI sekil kurali)."""
    dogrudan = sorted(glob.glob(os.path.join(kaynak, "*.dds")))
    if not dogrudan:
        dogrudan = sorted(glob.glob(os.path.join(kaynak, "**", "*.dds"), recursive=True))
    return [p for p in dogrudan
            if "/_reference_do_not_edit/" not in p.replace("\\", "/").lower()]


def _dds_hedefi(ad):
    """dosya adi -> (mat_id, slot) ya da (None, None) -- doku_enjekte2.ad_coz kurali."""
    m = _DDS_IC_RE.match(ad)
    if m:
        return "0x" + m.group(1), int(m.group(2))
    m = _DDS_0X_RE.search(ad)
    if not m:
        return None, None
    s = _DDS_SLOT_ET_RE.search(ad)
    return "0x" + m.group(1), (int(s.group(1)) if s else 0)


def _design_dds_adaylari(kaynak, progress=None):
    """`_design_adaylari`nin DDS ikizi: SALT OKUNUR, encode/decode YOK.

    Yalniz DOSYA ADI + KATALOG konusur; DDS basligi burada acilmaz, cunku bu
    cozucuyu on kapi (`scan_design_dir`) ve defter (`mod_kayit._outfit_slotlari`)
    de cagiriyor ve ikisi de tek bayt okumadan cevap vermeli. Bicim/boyut
    uygunlugunu (yeniden kodlama gerekiyor mu) YAZMA yolu `_design_dds_uygula`
    olcer -- kural iki yere BOLUNMEZ, sirayla uygulanir.

    Doner: (adaylar, tani) -- adaylar: [(dds, mat_id, slot, cs)]
    `tani["cozulen"]`: adi cozulen HER dosya [(base, MAT, slot)] -- katalog disi
    olanlar dahil; cakisma kapisi onu okur."""
    tani = {"taninmayan": [], "katalog_disi": [], "kilitli": 0, "cozulen": []}
    adaylar = []
    ddsler = _design_ddsleri(kaynak)
    for p in ddsler:
        base = os.path.basename(p)
        mat_id, slot = _dds_hedefi(base)
        if mat_id is None:
            tani["taninmayan"].append(base)
            _log(progress, "  skipped (name not recognised): %s" % base)
            continue
        tani["cozulen"].append((base, mat_id.upper(), int(slot)))
        cs = _catalog_slot(mat_id, slot)
        if cs is None:
            tani["katalog_disi"].append(base)
            _log(progress, "  skipped (slot not in catalogue): %s" % base)
            continue
        if not cs.get("duzenlenebilir", cs["idx"] not in (1, 2)):
            tani["kilitli"] += 1
            _log(progress, "  skipped (s%d is reference/locked): %s" % (cs["idx"], base))
            continue
        adaylar.append((p, mat_id, int(slot), cs))
    tani["gormezden_gelinen"] = _gormezden_gelinen_ddsler(kaynak, ddsler)
    return adaylar, tani


def _gormezden_gelinen_ddsler(kaynak, alinanlar):
    """`_gormezden_gelinenler`in DDS ikizi: sekil kurali yuzunden disarida kalan,
    ama adi gecerli olan .dds dosyalari. Ayni sessizlik tuzagi DDS'te de vardi --
    `Original\\` yanindaki `Bracers\\` sessizce dusuyordu."""
    kapsanan = set()
    for p in alinanlar:
        mat_id, slot = _dds_hedefi(os.path.basename(p))
        if mat_id is not None:
            kapsanan.add((mat_id.upper(), int(slot)))
    alinan_set = {os.path.normcase(p) for p in alinanlar}
    disarida = []
    for p in sorted(glob.glob(os.path.join(kaynak, "**", "*.dds"), recursive=True)):
        if os.path.normcase(p) in alinan_set:
            continue
        if "/_reference_do_not_edit/" in p.replace("\\", "/").lower():
            continue
        mat_id, slot = _dds_hedefi(os.path.basename(p))
        if mat_id is None:
            continue
        if (mat_id.upper(), int(slot)) in kapsanan:
            continue                      # ayni slotun yedek kopyasi -- sessiz kal
        disarida.append(os.path.relpath(p, kaynak))
    return disarida


def _design_dds_uygula(kaynak, dds_dir, png_adaylari, progress=None):
    """Tasarimdaki .dds'leri yazicinin klasorune koyar. Doner: (dogrudan, cevrilen).

    DOGRUDAN yol yeniden kodlama YAPMAZ: dosyanin baytlari oyunun kendi bloklaridir.
    Ayni (materyal, slot) icin hem PNG hem DDS varsa HANGISI oldugunu biz secmeyiz --
    PNG akisindaki 'Two files map to the same texture slot' hatasinin ayni sozleri."""
    ddsler = _design_ddsleri(kaynak)
    if not ddsler:
        return [], []
    try:
        from export3d import doku_dds as DD
    except ImportError:                                         # noqa: BLE001
        import doku_dds as DD
    png_slot = set((str(m).upper(), int(s)) for (_p, m, s, _cs) in png_adaylari)
    adaylar, tani = _design_dds_adaylari(kaynak, progress)
    # CAKISMA once olculur ve adi cozulen HER dosyayi kapsar (katalog disi
    # olanlar dahil): ayni slota iki dosya isaret ediyorsa hangisini kastettigini
    # biz secemeyiz, TEK BAYT yazmadan durmaliyiz.
    goruldu = {}
    for base, mat_u, slot_i in tani["cozulen"]:
        anahtar = (mat_u, slot_i)
        if anahtar in png_slot or anahtar in goruldu:
            raise RuntimeError(
                "Two files map to the same texture slot, so the tool cannot tell which "
                "one you meant:\n\n  %s\n\nKeep only one of each and put spare copies in "
                "a different folder." % base)
        goruldu[anahtar] = base
    dogrudan, cevrilen = [], []
    for (p, mat_id, slot, cs) in adaylar:
        base = os.path.basename(p)
        dds = DD.dds_oku(p)
        if not dds.get("ok"):
            _log(progress, "  skipped (%s): %s" % (dds.get("sebep"), base))
            continue
        try:
            zincir = DD.mip_zinciri(mat_id, int(cs["idx"]))
        except Exception:                                       # noqa: BLE001
            zincir = None
        rota, sebep = DD.uyumlu_mu(dds, cs, zincir)
        if rota == "red":
            _log(progress, "  skipped (%s): %s" % (sebep, base))
            continue
        hedef = os.path.join(dds_dir, _slot_filename(mat_id, slot, cs["W"], cs["H"],
                                                     cs["aile"], ext="dds"))
        if rota == "dogrudan":
            # BASLIK NORMALIZASYONU (OLCULDU 2026-09-09, EDWARD_ROBES_EDIT):
            # topluluk modlari dosyayi ESKI FourCC basligiyla (DXT1/DXT5) dagitiyor
            # ve o baslik sRGB bayragini TASIMAZ. Yazicinin KAPI 3'u ise dosyanin
            # DXGI'sini slotunkiyle karsilastirir; FourCC "linear" okundugu icin
            # dort dosyanin dordu de "colour space mismatch" ile reddediliyordu --
            # arac "kayipsiz girecek" deyip hicbir sey yazamiyordu.
            # BLOKLAR AYNEN korunur; yalniz baslik slotun DXGI'sine gore yeniden
            # yazilir. Bu bir yeniden kodlama DEGILDIR (tek piksel cozulmez).
            if dds.get("baslik") == "dx10" and int(dds.get("srgb", 0)) == int(bool(cs["srgb"])):
                import shutil as _sh
                _sh.copyfile(p, hedef)
            else:
                try:
                    DD.dds_yaz(hedef, {"seviyeler": dds["seviyeler"], "W": cs["W"],
                                       "H": cs["H"], "aile": cs["aile"],
                                       "srgb": int(bool(cs["srgb"]))})
                except Exception as _hb:                        # noqa: BLE001
                    # Baslik yeniden yazilamadi (ornegin mip zincirinde bosluk):
                    # sessizce "yazildi" DEMEYIZ, asagidaki cevirme yoluna duseriz.
                    _log(progress, "  %s: header could not be rewritten (%s) - re-encoding"
                         % (base, str(_hb)[:120]))
                    rota, sebep = "yeniden_kodla", "the header had to be rebuilt"
            if rota == "dogrudan":
                dogrudan.append(hedef)
                _log(progress, "  %s used as is - no re-encoding (%dx%d %s)"
                     % (base, cs["W"], cs["H"], cs["aile"]))
                continue
        _log(progress, "  %s: %s" % (base, sebep))
        arr = DD.dds_rgba(dds, 0)
        if (dds["W"], dds["H"]) != (cs["W"], cs["H"]):
            import numpy as _np
            from PIL import Image as _Im
            arr = _np.asarray(_Im.fromarray(arr, "RGBA").resize((cs["W"], cs["H"]),
                                                                _Im.LANCZOS))
        if cs["aile"] == "BC1":
            arr = arr.copy()
            arr[..., 3] = 255
        from PIL import Image as _Im2
        temiz = os.path.join(dds_dir, "_dds_%s_s%d.png" % (mat_id.replace("0x", ""), slot))
        _Im2.fromarray(arr).save(temiz)
        _tex_encode(temiz, hedef, cs["srgb"], _FMT_BCN[cs["aile"]], progress)
        try:
            os.remove(temiz)
        except OSError:
            pass
        cevrilen.append(hedef)
    return dogrudan, cevrilen


def _encode_design_dir(design_dir, progress=None, sadece_duzenle=True):
    """EDIT agacindaki PNG'leri slot formatina gore DDS'e cevirir -> temp dds klasoru.
       _reference_do_not_edit iceren dosyalar ATLANIR (maske/asla-import).

       DEGISMEMIS-SLOT ATLAMA: `EDIT/.orijinal_sha.json` manifesti varsa, PNG'nin
       GUNCEL sha256'si manifesttteki export-anindaki sha ile AYNI ise kullanici o
       slotu HIC degistirmemis demektir -> encode ATLANIR (o slot DDS klasorune
       HIC girmez; doku_enjekte2 materyali forge orijinalinden yeniden paketleyip
       yalniz degisen slotlari yamaladigi icin atlanan slot forge orijinaliyle
       birebir kalir -- materyal butunlugu KORUNUR). Manifest yoksa geriye donuk
       uyumlu: hepsi encode edilir (eski davranis).

       Doner: (dds_klasor, uretilen_dds_listesi, istatistik)."""
    alt = _design_konteyner(design_dir) if sadece_duzenle else []
    if alt:
        raise RuntimeError(
            "That folder holds several designs rather than being one itself. "
            "Open it and pick one of: %s" % ", ".join(alt[:12]))
    kaynak = _design_kaynak(design_dir) if sadece_duzenle else design_dir
    dds_dir = os.path.join(tempfile.gettempdir(),
                           "OutfitWorkshop_dds_%s" % hashlib.md5(
                               design_dir.encode("utf-8")).hexdigest()[:10])
    os.makedirs(dds_dir, exist_ok=True)
    for old in glob.glob(os.path.join(dds_dir, "*.dds")):
        try: os.remove(old)
        except OSError: pass

    # manifest yukle (varsa). yoksa geriye donuk: tum slotlari encode et.
    manifest = {}
    have_manifest = False
    mpath = os.path.join(kaynak, MANIFEST_ADI)
    if os.path.isfile(mpath):
        try:
            with open(mpath, encoding="utf-8") as f:
                manifest = json.load(f)
            have_manifest = True
        except Exception as e:
            _log(progress, "  UYARI: manifest okunamadi (%s) -> hepsi encode edilecek" % e)
    if not have_manifest:
        _log(progress, "  not: manifest yok -> tum slotlar encode edilecek (eski davranis)")

    adaylar, tani = _design_adaylari(kaynak, progress)
    if tani["cakisan"]:
        raise RuntimeError(
            "Two files map to the same texture slot, so the tool cannot tell which "
            "one you meant:\n\n  %s\n\nKeep only one of each and put spare copies in "
            "a different folder." % "\n  ".join(tani["cakisan"]))

    # --- 2) DEGISMEMIS-SLOT ATLAMA: manifestteki sha ile karsilastir
    encode_list = []
    atlanan_slot = 0
    for (png, mat_id, slot, cs) in adaylar:
        if have_manifest:
            rel = os.path.relpath(png, kaynak).replace("\\", "/")
            if rel in manifest and _sha256_file(png) == manifest[rel]:
                atlanan_slot += 1
                _log(progress, "  skipped %s s%d (unchanged)" % (mat_id, slot))
                continue
        encode_list.append((png, mat_id, slot, cs))

    _log(progress, "%d/%d slots to encode, %d skipped%s" % (
        len(encode_list), len(adaylar), atlanan_slot,
        "" if have_manifest else "  (no manifest -> all)"))

    # --- 3) ENCODE: yalniz degisen (ya da manifetsiz: tum) slotlar
    uretilen = []
    for i, (png, mat_id, slot, cs) in enumerate(encode_list, 1):
        srgb = cs["srgb"]
        bcn = _FMT_BCN[cs["aile"]]
        est = _encode_estimate_sec(cs["aile"], cs["W"], cs["H"])
        est_txt = (", ~%dsn" % est) if est else ""
        # Bu satirda ARTIK "[i/N]" YOK: ilerleme cubugu metindeki x/y'yi okuyor ve
        # son slotta i==N oldugu icin cubugu, tam da en uzun islemin BASINDA,
        # %100'e civiliyordu. Sayac artik "slot i of N" diye yaziliyor (regex'e
        # takilmaz); gercek ilerleme asagida encoder'in kendisinden geliyor.
        _log(progress, "  encoding %s s%d (%dx%d %s%s%s)  -- slot %d of %d" % (
            mat_id, slot, cs["W"], cs["H"], bcn.upper(),
            " sRGB" if srgb else "", est_txt, i, len(encode_list)))
        # ALFA POLITIKASI (v0.7): alfasiz/duz-255 PNG'ye kor 255 basmak yerine
        # VANILLA alfa geri konur. s3 alfasi oyunda GLOSS -> 255 "hep islak"
        # gorunum uretiyordu (Nexus: Princehama); s0-BC3'te vanilla alfa da
        # eziliyordu (41 slot). Kullanicinin BILINCLI alfasi (varyasyonlu ya da
        # 255-disi sabit) aynen korunur. SEPARATE_ALPHA duzeltmesi kurulu oldugu
        # icin alfa~0 bolgeler alt miplerde artik kararmiyor (ikisi de olculdu).
        try:
            import alfa_politika as _AP
            clean, _ap_karar = _AP.politika_hazirla(
                png, mat_id, slot, cs["W"], cs["H"], cs["aile"], progress)
        except Exception as _ap_e:                              # noqa: BLE001
            # Politika moduulu yoksa/coktuyse arac OLMEZ: eski yol devam eder.
            _log(progress, "  alpha policy unavailable (%s) - legacy path" % _ap_e)
            clean = _prepare_png(png, cs["W"], cs["H"], cs["aile"], progress)
        out_name = _slot_filename(mat_id, slot, cs["W"], cs["H"], cs["aile"], ext="dds")
        dds = os.path.join(dds_dir, out_name)

        # Encoder'in kendi ilerlemesini TUM slotlara yayilmis tek bir orana cevir.
        # Ekrani bogmamak icin yalnizca yuzde en az 2 puan degisince satir basilir.
        _son = [-99]

        def _ilerle(f, _i=i, _n=len(encode_list), _son=_son):
            genel = int(((_i - 1) + max(0.0, min(1.0, f))) * 100.0 / _n)
            if genel - _son[0] >= 2:
                _son[0] = genel
                _log(progress, "    encoding... %d/100" % genel)

        _tex_encode(clean, dds, srgb, bcn, progress, on_frac=_ilerle)
        uretilen.append(dds)

    # --- 4) TOPLULUK .dds: oyunun kendi blok bicimi. Slotla ayni bicim/boyuttaysa
    # HIC yeniden kodlanmaz (kayipsiz); degilse acilip slotun bicimine cevrilir.
    dds_ham, dds_cevrilen = _design_dds_uygula(kaynak, dds_dir, adaylar, progress)
    uretilen.extend(dds_ham + dds_cevrilen)

    ist = {"toplam": len(adaylar) + len(dds_ham) + len(dds_cevrilen),
           "encode": len(uretilen), "skip": atlanan_slot, "manifest": have_manifest,
           "dds_dogrudan": len(dds_ham), "dds_cevrilen": len(dds_cevrilen)}
    _log(progress, "encode bitti: %d DDS (%d atlandi/degismemis) -> %s" %
         (len(uretilen), atlanan_slot, dds_dir))
    return dds_dir, uretilen, ist


def status_outfit(design_dir, progress=None):
    """Forge'a YAZMADAN plan + kapilar (doku_enjekte2 durum) + base-shift 'safe/unsafe'.
       design_dir: export_outfit'in urettigi kiyafet klasoru (icinde EDIT)."""
    dds_dir, uretilen, ist = _encode_design_dir(design_dir, progress)
    if not uretilen:
        if ist["skip"] and ist["toplam"]:
            _log(progress, "durum: uygulanacak yok -- TUM slotlar degismemis "
                 "(%d atlandi, encode=0)." % ist["skip"])
        else:
            _log(progress, "durum: kodlanacak PNG yok (EDIT bos?).")
        return {"dds_dir": dds_dir, "kabul": 0, "safe": None,
                "atlanan": ist["skip"], "toplam": ist["toplam"]}
    _d = DE.durum(dds_dir)             # doku_enjekte2: forge'a DOKUNMAZ
    isler, reddedilen = _d if isinstance(_d, tuple) else (_d, [])
    # base-shift kanit satiri: her etkilenen materyal icin bellekte round-trip
    mats = sorted({j["mat"] for j in isler})
    safe_all = True
    satirlar = []
    for mat in mats:
        r = verify_base_shift(mat)
        satirlar.append(r)
        safe_all = safe_all and r["safe"]
    print("-" * 78)
    print("BASE-SHIFT DOGRULAMA (yaz(ma)madan, bellekte round-trip):")
    for r in satirlar:
        print("   mat 0x%X: len %s  block2-offset %s  -> %s" % (
            r["mat"], "KORUNDU" if r["len_ok"] else "DEGISTI!!",
            "KORUNDU" if r["offset_ok"] else "KAYDI!!", r["etiket"]))
    print("   GENEL: %s" % ("safe" if safe_all else "UNSAFE"))
    if reddedilen:
        _log(progress, "REDDEDILEN %d dosya (yazilmayacak):" % len(reddedilen))
        for ad, sebep in reddedilen:
            _log(progress, "   [RED] %s -> %s" % (ad, sebep))
    return {"dds_dir": dds_dir, "kabul": len(isler), "safe": safe_all,
            "base_shift": satirlar, "reddedilen": reddedilen,
            "atlanan": ist["skip"], "toplam": ist["toplam"]}


DOKU_GOLGE_MESAJ = (
    "This item was updated by a game patch: its full-size texture entries live in {0} as well as "
    "{1}, and the game reads the {0} copy. Painting it is not supported yet - the painted bytes "
    "would go to {1} and never show up in game. Nothing was written.")
DOKU_GOLGE_NOTU = (
    "{0} material(s) of this item were updated by a game patch ({1}). Their full-size textures "
    "were painted and will show in game; only the small embedded mip levels (seen from far away) "
    "could not be painted and stay original.")


def doku_golge_kontrol(dds_dir, forge=None):
    """GOLGE KAPISI (2026-10-12): boyama hedefleri oyunun OKUDUGU arsivde mi? SALT OKUMA.

    doku_enjekte2 TEK arsive (FORGE = boot) yazar ve yama zincirini bilmez. Ayni kimlik
    boot_patch_01'de de varsa oyun ORADAKINI okur: yazma basarili gorunur, oyunda hic bir sey
    degismez (kur_mesh.etkin_arsiv kurali; mesh tarafinda ayni kusur 2026-10-12'de kapatildi).
    OLCULDU: katalogun 310 materyalinin 6'si golgeli (Yasuke 3, Ezio 1, Weapon_Pistol_10 2).
    Kontrol edilen hedefler = yazicinin DOKUNDUGU girisler: materyal kabi (gomulu mip kuyrugu) +
    her slot dokusunun harici mip RawAsset girisleri (rid = (0x80000000000|doku_id)<<20 | lvl).
    OLCULDU (2026-10-25, 6 golgeli materyal: Ezio 1, Yasuke 3, Pistol_10 2): YALNIZ materyal KABI
    golgeli; tam boy harici mip'lerin hepsi (lvl 0-3) sadece boot'ta ve yamali materyal ayni doku
    kimliklerini kullaniyor -> tam boy dokular boyanirsa OYUNDA GORUNUR, yalniz gomulu kucuk mip'ler
    (uzaktan) orijinal kalir. Bu yuzden iki derece:
      sert  : harici (tam boy) bir mip golgeli -> boyama gorunmez -> ok False, `mesaj` (RED)
      kismi : yalniz kap golgeli -> ok True, `kismi` True, `not` (harici yazilir, gomulu atlanir;
              bkz. doku_yaz_golge_bilincli)
    Doner {ok, sert, kismi, golgeli:[{mat, tur, gid, arsiv}], golgeli_materyaller:[hex], arsiv,
    mesaj (sert), not (kismi)}."""
    from export3d import kur_mesh as KM
    forge = os.path.abspath(forge or DE.FORGE)
    nc = os.path.normcase(forge)
    golgeli, gorulen = [], set()
    for p in sorted(glob.glob(os.path.join(dds_dir, "*.dds"))):
        mat, _slot, _bicim = DE.ad_coz(os.path.basename(p))
        if mat is None or mat in gorulen:
            continue
        gorulen.add(mat)
        hedefler = [("material", int(mat))]
        try:
            res = _material_res(mat)
            lf = _forge()
            for _hdr, tex in DE.tm_bloklari(res):
                base = (0x80000000000 | int(tex)) << 20
                for lvl in range(16):
                    rid = base | lvl
                    if rid in lf.by_id:
                        hedefler.append(("mip", rid))
        except Exception:                                       # noqa: BLE001
            pass                              # materyal okunamadi: yalniz kap kontrol edilir
        for tur, gid in hedefler:
            e = KM.etkin_arsiv(forge, gid)
            if os.path.normcase(e) != nc:
                golgeli.append({"mat": "0x%X" % mat, "tur": tur, "gid": "0x%X" % gid,
                                "arsiv": os.path.basename(e)})
    sert = any(g["tur"] == "mip" for g in golgeli)
    mats = sorted({g["mat"] for g in golgeli})
    r = {"ok": not sert, "sert": sert, "kismi": bool(golgeli) and not sert, "golgeli": golgeli,
         "golgeli_materyaller": mats, "arsiv": os.path.basename(forge), "mesaj": None, "not": None}
    if sert:
        r["mesaj"] = DOKU_GOLGE_MESAJ.format(golgeli[0]["arsiv"], os.path.basename(forge))
    elif golgeli:
        r["not"] = DOKU_GOLGE_NOTU.format(len(mats), golgeli[0]["arsiv"])
    return r


def doku_yaz_golge_bilincli(dds_dir, progress=None):
    """TEK yazici cagrisi (DE.uygula), GOLGE BILINCLI. Doner DE.uygula sozlesmesi
    {harici, gomulu, red, red_sebep} + golge_notu, golgeli_materyaller, atlanan_gomulu_materyal.

    sert  -> yazmadan RED (red_sebep = DOKU_GOLGE_MESAJ).
    kismi -> yamali materyallerin .dds'leri gecici olarak `<dds_dir>_patchli` klasorune alinir;
             temiz grup normal (gomulu kuyruk dahil), yamali grup `sadece_harici=True` ile yazilir
             (gomulu kucuk mip'ler atlanir, oyun o kabi zaten patch'ten okuyor); dosyalar geri konur.
             Iki yazim da ayni doku defterine eklenir -> Revert hepsini gorur.
    yok   -> dogrudan DE.uygula(dds_dir)."""
    gk = doku_golge_kontrol(dds_dir)
    if gk["sert"]:
        _log(progress, "REFUSED (full-size textures updated by a game patch): %s" % gk["golgeli"][:3])
        return {"harici": 0, "gomulu": 0, "red": [], "red_sebep": gk["mesaj"], "golgeli": gk["golgeli"]}
    if not gk["kismi"]:
        return DE.uygula(dds_dir) or {}
    mats = set(gk["golgeli_materyaller"])
    ayri = dds_dir.rstrip("\\/") + "_patchli"
    os.makedirs(ayri, exist_ok=True)
    tasinan = []
    for p in sorted(glob.glob(os.path.join(dds_dir, "*.dds"))):
        mat, _s, _b = DE.ad_coz(os.path.basename(p))
        if mat is not None and ("0x%X" % mat) in mats:
            hedef = os.path.join(ayri, os.path.basename(p))
            os.replace(p, hedef)
            tasinan.append((hedef, p))
    try:
        if glob.glob(os.path.join(dds_dir, "*.dds")):
            r1 = DE.uygula(dds_dir) or {}
        else:
            r1 = {"harici": 0, "gomulu": 0, "red": [], "red_sebep": None}
        if r1.get("red_sebep"):
            return r1
        _log(progress, "%d material(s) updated by a game patch: writing their full-size textures "
                       "only (embedded far-view mips skipped) ..." % len(mats))
        r2 = DE.uygula(ayri, sadece_harici=True) or {}
    finally:
        for hedef, p in tasinan:
            try:
                os.replace(hedef, p)
            except OSError:
                pass
    r = {"harici": int(r1.get("harici") or 0) + int(r2.get("harici") or 0),
         "gomulu": int(r1.get("gomulu") or 0) + int(r2.get("gomulu") or 0),
         "red": list(r1.get("red") or []) + list(r2.get("red") or []),
         "red_sebep": r2.get("red_sebep"),
         "golge_notu": gk["not"], "golgeli_materyaller": gk["golgeli_materyaller"],
         "atlanan_gomulu_materyal": len(mats)}
    if not r["red_sebep"]:
        _log(progress, "NOTE: %s" % gk["not"])
    return r


def apply_outfit(design_dir, progress=None):
    """PNG -> DDS (slot fmt/srgb) -> doku_enjekte2 uygula (TEK YAZICI).
       Cakisma korumalari (inline_mip_kayit.json, doku_enjekte_kayit.json) KORUNUR:
       bu kontroller doku_enjekte2.uygula icinde ZATEN var, onlari devre disi birakmayiz."""
    dds_dir, uretilen, ist = _encode_design_dir(design_dir, progress)
    if not uretilen:
        if ist["skip"] and ist["toplam"]:
            _log(progress, "uygula: uygulanacak yok -- TUM slotlar degismemis "
                 "(%d atlandi)." % ist["skip"])
        else:
            _log(progress, "uygula: kodlanacak PNG yok.")
        return {"dds_dir": dds_dir, "yazildi": 0,
                "atlanan": ist["skip"], "toplam": ist["toplam"]}
    _log(progress, "doku_enjekte2 uygula cagriliyor (TEK YAZICI)... %d slot yazilacak, %d atlandi"
         % (len(uretilen), ist["skip"]))
    # GOLGE BILINCLI tek yazici cagrisi: yamali materyalde yalniz tam boy dokular, gomulu atlanir + NOT;
    # tam boy doku golgeliyse red_sebep (asagida yukseltilir).
    r = doku_yaz_golge_bilincli(dds_dir, progress=progress)
    # Eskiden burada donus degeri ATILIYOR ve basari `os.path.exists(DE.KAYIT)`ten
    # cikariliyordu -- oysa o dosya ONCEKI bir yamadan kalma oldugunda da True.
    # Yazici reddettiginde GUI yine "SUCCESS" yaziyordu. Artik reddi YUKSELTIYORUZ.
    if isinstance(r, dict) and r.get("red_sebep"):
        raise RuntimeError("The writer refused: %s" % r["red_sebep"])
    yazilan = (r or {}).get("harici", 0) + (r or {}).get("gomulu", 0)
    if isinstance(r, dict) and yazilan == 0:
        raise RuntimeError("Nothing was written to the game archive. "
                           "The writer accepted no slots.")
    # Forge DEGISTI: okuma onbellegi artik yamadan ONCEKI baytlari tutuyor.
    # Ikinci bir tasarim ayni oturumda uygulanabildigi icin bu artik canli bir
    # sorun: bayat indeksle yapilan base-shift kaniti yanlis seyi dogrular.
    _invalidate_cache()
    return {"dds_dir": dds_dir, "yazildi": len(uretilen), "yazilan_giris": yazilan,
            "kayit_var": os.path.exists(DE.KAYIT),
            "atlanan": ist["skip"], "toplam": ist["toplam"],
            "golge_notu": (r or {}).get("golge_notu")}


def _invalidate_cache():
    """Forge yazildiktan sonra okuma onbellegini bosalt VE dosyayi KAPAT."""
    global _LF, _RES_CACHE
    release_forge()
    _RES_CACHE = {}
    # Alfa politikasinin vanilla-alfa onbellegi de forge'a bagli: oyun klasoru
    # degisir ya da forge yazilirsa bayat alfa geri konmasin.
    try:
        import alfa_politika as _AP
        _AP.onbellek_temizle()
    except Exception:                                           # noqa: BLE001
        pass


def release_forge(onbellek=True):
    """Forge dosya tanitiscisini birak (okuma onbellegi disinda her sey durur).

    Arac forge'u tum oturum boyunca acik tutuyordu; Windows bu tanitiсiya
    FILE_SHARE_DELETE vermedigi icin Steam "dosya butunlugunu dogrula" ve oyun
    guncellemeleri **"Content file locked"** ile basarisiz oluyordu -- kullanici
    bunu Steam'in ya da oyunun hatasi saniyor. Her isten sonra ve pencere
    kapanirken cagrilir; bir sonraki okuma dosyayi yeniden acar."""
    global _LF, _RES_CACHE
    if _LF is not None:
        try:
            _LF.close()
        except Exception:
            pass
        _LF = None
    # Cozulmus materyal govdeleri de bayat: GUI `apply_outfit`i HIC cagirmiyor
    # (dogrudan `DE.uygula`), yani oradaki onbellek temizligi olu koddu. Ayni
    # oturumda apply'dan sonra tekrar Export alinca gomulu-mip'li slotlar (625'in
    # 42'si) yamadan ONCEKI pikselleri veriyordu -- yarisi eski, yarisi yeni bir export.
    if onbellek:
        _RES_CACHE = {}


def revert_check():
    """SALT OKUNUR: geri alma su an guvenli mi? Forge'a hicbir sey yazmaz."""
    if hasattr(DE, "gerial_kontrol"):
        return DE.gerial_kontrol()
    return {"kayit": os.path.exists(DE.KAYIT), "sorunlar": []}


# --- TAKILI BOYAMA ISI (2026-10-12; Nexus, Ninjozzo 2026-09-17: "can't use it anymore") --------
# Yarim kalan Apply: kayit 'in_progress', geri alinacak giris 0, motor `_yarim_kalmis` ile reddeder.
# Motor kaydi ve yedekleri BILEREK korur -- `gerial --zorla` bile bu durumda cikis vermez, cunku
# arsivin yamali olup olmadigini bilemez. Arsiv boyutu kayittan farkliysa (araya oyun guncellemesi
# girdiyse) Steam 'Verify' SONRASI da kilit kalkmaz; tek cikis "log'daki klasoru elle sil" idi.
# Cikis yolu: kullanici Steam'de dogrular, sonra bu fonksiyon kaydi + yedekleri TARIHLI klasore
# TASIR. Tek dosya silinmez, arsive tek bayt yazilmaz.
TAKILI_ONEK = "a previous apply was interrupted"
TAKILI_KLASOR = "takili_isler"


def boyama_takili_mi(rc=None):
    """Ne Revert ne yeni Apply calisabilen durum mu? (salt okuma)"""
    rc = rc if rc is not None else revert_check()
    return bool(rc.get("kayit") and rc.get("durum") == "in_progress"
                and not rc.get("geri_alinacak")
                and any(str(s).startswith(TAKILI_ONEK) for s in (rc.get("sorunlar") or [])))


def boyama_takili_temizle(progress=None):
    """YALNIZ takili durumda: kayit dosyasini ve yedek klasorunu
    <kayit dizini>/takili_isler/<zaman>/ altina TASIR ve NOT.json birakir.
    Doner {ok, mesaj, klasor, tasinan}. Takili degilse hicbir sey yapmaz."""
    import shutil
    import time
    if hasattr(DE, "yaziyor_mu") and DE.yaziyor_mu():
        return {"ok": False, "mesaj": "A paint job is running right now - wait for it to finish."}
    rc = revert_check()
    if not boyama_takili_mi(rc):
        return {"ok": False, "mesaj": "There is no stuck paint job to clear."}
    with open(DE.KAYIT, encoding="utf-8") as f:
        kayit = json.load(f)
    ydir = DE._yedek_dizin(kayit) if hasattr(DE, "_yedek_dizin") else getattr(DE, "YEDEK", None)
    kok = os.path.join(os.path.dirname(os.path.abspath(DE.KAYIT)), TAKILI_KLASOR)
    hedef = os.path.join(kok, time.strftime("%Y%m%d_%H%M%S"))
    n = 1
    while os.path.exists(hedef):
        n += 1
        hedef = os.path.join(kok, time.strftime("%Y%m%d_%H%M%S") + "_%d" % n)
    os.makedirs(hedef)
    try:
        boyut = os.path.getsize(DE.FORGE)
    except OSError:
        boyut = None
    with open(os.path.join(hedef, "NOT.json"), "w", encoding="utf-8") as f:
        json.dump({"ne": "stuck paint job cleared by the user after an interrupted Apply",
                   "zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
                   "forge": DE.FORGE, "forge_boyut_simdi": boyut,
                   "forge_boyut_kayitta": kayit.get("forge_boyut"),
                   "kayit": DE.KAYIT, "yedek": ydir, "sorunlar": rc.get("sorunlar")},
                  f, indent=1)
    tasinan = []
    shutil.move(DE.KAYIT, os.path.join(hedef, os.path.basename(DE.KAYIT)))
    tasinan.append(DE.KAYIT)
    if ydir and os.path.isdir(ydir):
        shutil.move(ydir, os.path.join(hedef, os.path.basename(os.path.normpath(ydir))))
        tasinan.append(ydir)
    _log(progress, "stuck paint job moved to %s" % hedef)
    if revert_check().get("kayit"):
        return {"ok": False, "klasor": hedef, "tasinan": tasinan,
                "mesaj": "The record could not be cleared; see %s" % hedef}
    return {"ok": True, "klasor": hedef, "tasinan": tasinan,
            "mesaj": {"t": "The stuck paint job was cleared. Its record and backups were moved, "
                           "not deleted, to: {0}", "a": [hedef]}}


def revert_outfit(progress=None):
    """doku_enjekte2 gerial -> forge vanilla. Dogrulama basarisizsa HATA firlatir."""
    _log(progress, "doku_enjekte2 gerial...")
    r = DE.gerial()
    _invalidate_cache()
    # Eskiden SADECE "dogrulama basarisiz" yukseltiliyordu; yazicinin diger reddi
    # ("yarim kalmis yazim") sessizce gecip GUI'ye "forge orijinale dondu"
    # yazdiriyordu -- forge'a tek bayt yazilmamisken. Artik reddin ADI onemli degil:
    # red_sebep varsa (kayit zaten yoksa o hata degil) revert OLMAMISTIR.
    red = (r or {}).get("red_sebep") if isinstance(r, dict) else None
    if red and red != "kayit yok":
        detay = [str(s) for s in ((r.get("sorunlar") or []) if isinstance(r, dict) else [])]
        raise RuntimeError("Revert was stopped before writing anything (%s)%s"
                           % (red, (":\n  - " + "\n  - ".join(detay)) if detay else "."))
    return {"kayit_var": os.path.exists(DE.KAYIT),
            "geri_alindi": (r or {}).get("geri_alindi", 0)}


# ------------------------------------------------------------------ SECMELI REVERT
def _mat_anahtar(x):
    """Materyal kimligini yazicinin kullandigi bicime getir ('22373CE1241')."""
    if hasattr(DE, "_mat_anahtar"):
        return DE._mat_anahtar(x)          # TEK KAYNAK: yazicidaki normalizasyon
    t = str(x or "").strip()
    if t[:2].lower() == "0x":
        t = t[2:]
    return t.lstrip("0").upper() or "0"


def revert_scope(outfit):
    """SALT OKUNUR: 'sadece bu kiyafeti geri al' dendiginde NE olur?

    Doner:
      kendi_materyal   -> bu kiyafetin geri alinabilir materyalleri
      paylasilan       -> bunlardan BASKA kiyafetleri de etkileyenler
                          [{mat, parca, etkilenen:[kiyafet...]}]
      diger_kalan      -> geri almadan sonra kayitta kalacak giris sayisi
      tumu_mu          -> secim kayittaki HER SEYI kapsiyor mu (o zaman tam
                          revert ile ayni sonuc verir)
    Forge'a tek bayt yazmaz.
    """
    o = get_outfit(outfit)
    dag = DE.gerial_dagilim() if hasattr(DE, "gerial_dagilim") else {}
    bekleyen = dag.get("materyaller") or {}
    kendi, paylasilan = [], []
    toplam_giris = 0
    for m in outfit_materials(o):
        a = _mat_anahtar(m["mat_id"])
        if a not in bekleyen:
            continue                      # bu materyal boyali degil
        kendi.append(m["mat_id"])
        toplam_giris += (bekleyen[a].get("gomulu", 0)
                         + bekleyen[a].get("harici", 0))
        p = m.get("paylasim") or {}
        etkilenen = [x for x in (p.get("etkilenen_kiyafetler") or [])
                     if x != o.get("ad")]
        if etkilenen:
            paylasilan.append({"mat": m["mat_id"],
                               "parca": m.get("parca_adi", m["mat_id"]),
                               "etkilenen": etkilenen})
    kayitta = sum(v.get("gomulu", 0) + v.get("harici", 0)
                  for v in bekleyen.values())
    return {"kayit": bool(dag.get("kayit")),
            "sorunlar": dag.get("sorunlar") or [],
            "kendi_materyal": kendi, "paylasilan": paylasilan,
            "giris": toplam_giris, "diger_kalan": kayitta - toplam_giris,
            "tumu_mu": bool(kendi) and kayitta == toplam_giris}


def revert_outfit_only(outfit, progress=None):
    """SADECE secili kiyafetin boyanmis dokularini geri al.

    Nexus talebi (Hary0Nicholas, 2026-08-20): "Revert neden sadece sectigim
    kiyafeti degil, duzenlenmis HER kiyafeti geri aliyor?"

    Guvenlik: yazicidaki `gerial_secmeli` kayittaki HER girisi dogrular; biri
    bile tutmazsa TEK BAYT yazilmaz. Yani secmeli olmak "asla yarim revert"
    ilkesini GEVSETMEZ, yalnizca YAZILACAK KUMEYI daraltir.

    ⚠️ PAYLASILAN MATERYAL: bir materyal birden fazla kiyafette kullanilabilir
    (katalogdaki `paylasim.etkilenen_kiyafetler`). Boyle bir materyali geri
    almak o kiyafetlerdeki boyayi da kaldirir -- bu kacinilmazdir, cunku
    dokunun tek bir kopyasi vardir. Cagiran KULLANICIYA once `revert_scope`
    ile bunu gostermelidir.
    """
    kapsam = revert_scope(outfit)
    if not kapsam["kendi_materyal"]:
        return {"geri_alindi": 0, "kalan": kapsam["diger_kalan"],
                "mesaj": "This outfit has no painted textures to revert."}
    _log(progress, "reverting %d material(s) of %s..."
         % (len(kapsam["kendi_materyal"]), outfit))
    r = DE.gerial_secmeli(kapsam["kendi_materyal"])
    _invalidate_cache()
    red = (r or {}).get("red_sebep")
    if red and red not in (None, "kayit yok"):
        detay = [str(x) for x in ((r or {}).get("sorunlar") or [])]
        raise RuntimeError("Revert was stopped before writing anything (%s)%s"
                           % (red, (":\n  - " + "\n  - ".join(detay))
                              if detay else "."))
    return {"geri_alindi": (r or {}).get("geri_alindi", 0),
            "kalan": (r or {}).get("kalan", 0),
            "paylasilan": kapsam["paylasilan"]}


# =================================================================== BASE-SHIFT KANIT
def verify_base_shift(mat_id):
    """190 B taban kaymasi riskini KANITLAR (forge'a YAZMADAN, bellekte).

    doku_enjekte2 gomulu-kuyruk yazimi: (1) block2 govdesini yerinde bayt-yamalar
    (uzunluk sabit), (2) materyali yeniden paketleyip (oodle sikistir) forge sonuna
    ekler. Riski test etmek icin materyali oldugu gibi (ayni baytlar) yeniden paketleyip
    tekrar cozer, sonra:
       * len(res_yeni) == len(res_orig)         (resource uzunlugu KORUNDU)
       * res_yeni == res_orig                   (block2 govdesi bit-bit AYNI)
       * ilk TextureMap tanimlayici ofseti      (block2-taban KAYMADI)
    Uc kosul da tutarsa 'safe'. Kayma varsa NEREDE oldugunu dondurur.
    """
    mid = mat_id if isinstance(mat_id, int) else int(mat_id, 16)
    lf = _forge()
    raw = lf.read_raw(mid)
    res = decompress(raw)                       # block2 (yalin_forge tabani)
    tms0 = DE.tm_bloklari(res)
    ilk_offset0 = tms0[0][0] if tms0 else -1

    # doku_enjekte2.uygula gomulu yolunun AYNISI ile yeniden paketle (ozdes baytlar)
    b1, n1 = read_block(raw, 0)
    block1 = raw[0:n1]
    hdr = raw[n1:n1 + 19]
    pc = struct.unpack_from("<I", raw, n1 + 15)[0]
    boyutlar = []; q = n1 + 19
    for _ in range(pc):
        u, c = struct.unpack_from("<II", raw, q); q += 8; boyutlar.append(u)
    len_ok_pre = (sum(boyutlar) == len(res))
    parcalar = []; o = 0
    for u in boyutlar:
        veri = res[o:o + u]; o += u
        cv = DE.oodle_sik(veri)
        if len(cv) >= u:
            cv = veri
        parcalar.append((u, cv))
    sizes = b"".join(struct.pack("<II", u, len(cv)) for u, cv in parcalar)
    govde = b"".join(struct.pack("<I", DE.lzo_adler32(cv)) + cv for u, cv in parcalar)
    entry = block1 + hdr + sizes + govde

    # yeni entry'yi tekrar coz -> res_yeni
    res_yeni = decompress(entry)
    tms1 = DE.tm_bloklari(res_yeni)
    ilk_offset1 = tms1[0][0] if tms1 else -2

    len_ok = (len(res_yeni) == len(res)) and len_ok_pre
    ozdes = (res_yeni == res)
    offset_ok = (ilk_offset0 == ilk_offset1)
    safe = len_ok and ozdes and offset_ok
    return {"mat": mid, "len_ok": len_ok, "ozdes": ozdes, "offset_ok": offset_ok,
            "ilk_offset": ilk_offset0, "ilk_offset_yeni": ilk_offset1,
            "res_len": len(res), "res_len_yeni": len(res_yeni),
            "safe": safe, "etiket": "safe" if safe else "UNSAFE"}


# =================================================================== KATALOG DOGRULA
def verify_catalog(progress=None):
    """Katalogu forge'dan SALT OKUNUR dogrular: her slot W/H/aile/srgb/doku_id tutmali."""
    lf = _forge()
    toplam = ok = 0
    hatalar = []
    for o in CATALOG:
        for m in o["materyaller"]:
            if m.get("dokusuz") or not m.get("boot_forge_icinde", True):
                continue
            mid = int(m["mat_id"], 16)
            if mid not in lf.by_id:
                hatalar.append((m["mat_id"], "forge'da yok")); continue
            res = _material_res(mid)
            tms = DE.tm_bloklari(res)
            for s in m["slotlar"]:
                toplam += 1
                if s["idx"] >= len(tms):
                    hatalar.append((m["mat_id"] + " s%d" % s["idx"], "slot yok")); continue
                hdr, tex = tms[s["idx"]]
                t = DE.tanim_oku(res, hdr)
                bad = []
                if (t["W"], t["H"]) != (s["W"], s["H"]): bad.append("boyut")
                if t["aile"] != s["aile"]: bad.append("aile")
                if t["srgb"] != s["srgb"]: bad.append("srgb")
                if ("0x%X" % tex).upper() != s["doku_id"].upper(): bad.append("doku_id")
                if bad:
                    hatalar.append((m["mat_id"] + " s%d" % s["idx"], ",".join(bad)))
                else:
                    ok += 1
    _log(progress, "katalog dogrulama: %d/%d slot ESIT, %d hata" % (ok, toplam, len(hatalar)))
    return {"ok": ok, "toplam": toplam, "hatalar": hatalar}


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        for r in list_outfits():
            print("%-22s %-26s %s  [%s] puan=%.1f  %d mat" % (
                r["ad"], r["gorunen_ad"], r["EG_id"], r["guvenlik_etiketi"],
                r["guvenlik_puani"], r["materyal_sayisi"]))
    elif a[0] == "dogrula":
        print(verify_catalog(print))
    elif a[0] == "export":
        print(export_outfit(a[1], a[2] if len(a) > 2 else ".", print))
    elif a[0] == "durum":
        print(status_outfit(a[1], print))
    elif a[0] == "uygula":
        print(apply_outfit(a[1], print))
    elif a[0] == "gerial":
        print(revert_outfit(print))
    elif a[0] == "base":
        print(verify_base_shift(a[1]))
