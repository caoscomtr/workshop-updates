# -*- coding: utf-8 -*-
"""
mod_paket.py -- AMBALAJ COZUCU: kullanici NE birakirsa biraksin anlasin.

Tek giris noktasi:

    import mod_paket
    plan = mod_paket.coz(r"C:\\Users\\me\\Downloads\\Bloody Crimson Robes.rar")
    ...                                   # plan["ogeler"] -> ilgili yaziciya ver
    mod_paket.temizle(plan)               # gecici klasoru sil

ya da baglam yoneticisiyle (temizlik garantili):

    with mod_paket.acilmis(yol) as plan:
        ...

NE YAPAR
  Kullanicinin surukleyip biraktigi HERHANGI bir seyi (arsiv / klasor / tek
  dosya / dosya listesi) normalize edilmis bir KURULUM PLANINA cevirir. Plan,
  var olan yazicilarin bekledigi kimlikleri tasir; bu modul HICBIR SEY YAZMAZ,
  oyun arsivine dokunmaz, tek bayt uretmez. Salt okuma + gecici klasore acma.

TEK ARSIV KAPISI
  Arsiv uyesinin adi/turu `arsiv_uye_denetle()` ile denetlenir. Katalogdan mod
  indiren mod_kutuphane de AYNI fonksiyonu cagirir; ikinci bir kural kopyasi yok.
  Gerekcesi ve olculmus kacaklar o fonksiyonun basindaki notta.

NE YAZMAZ (TEK YAZICI KURALI)
  Kurulum bu modulun isi degil. Her ogenin `yol` alani hangi VAR OLAN yazicinin
  cagrilacagini soyler:
      "outfit" -> sunucu.py standart apply kapisi (mod_uygula sahneleme yolu)
      "ship"   -> ship_core.mod_kur / uygula
      "mesh"   -> export3d/kur_mesh.py (mesh_ithal.plan uzerinden)
      "forge"  -> sunucu.py patch_02 kurulumu
      "forge_birlesik" -> mod_kayit'in "forge_birlesik" adaptoru: N hazir yamayi
                  mod_birlestir (ACMB) ile TEK patch_02'de birlestirir, sonra
                  AYNI patch_02 yazicisina verir. Yeni yazici DEGIL.
      "ses"    -> (henuz yok; dosya taninir ama kurulamaz olarak isaretlenir)

BIRDEN FAZLA HAZIR YAMA (2026-09-08, Discord "Sparrow + QAR ayni anda")
  Oyun tek DataPC_boot_patch_02.forge tutar. Bir paket IKI (ya da daha cok)
  boot yamasi tasiyorsa artik reddedilmez: `_forge_birlesik_ekle` bunlari tek
  bir "forge_birlesik" ogesinde toplar (kaynak dosyalar `kaynaklar` altinda,
  ACMB'nin YAZMAYAN on-raporu `plan` altinda). Tek tek forge ogeleri listede
  KALIR (Show details'ta gorunsunler diye) ama `birlesik_icinde=True` ile
  isaretlenir; ozet ve tur karari onlari saymaz. Yalniz boot yuvasi: adinda
  "shared" gecen yama farkli bir yuvaya gider, birlestirmeye ALINMAZ (Nosso
  Senhor: boot + shared_00 -> birlestirilmez, olculdu). Motor yoksa ya da bir
  yama yapisal olarak bozuksa birlesik oge URETILMEZ, uyari yazilir ve paket
  eskisi gibi cozulur (tek yama kuralini sunucu uygular).

GERCEK DUNYA OLCUMU (Downloads klasorundeki yayinlanmis topluluk modlari)
  * "Bloody Crimson Robes.rar" -> arsiv kokunde DUZ `IC_*.png` yigini
  * "Ezio.zip"                 -> ayni sekilde duz PNG yigini
  * "Admiral Edward Kenway.rar"-> <Mod>/<Kiyafet>/EDIT/0x<materyal>/IC_*.png
                                  + `_reference_do_not_edit/` (VANILLA yedek;
                                  kurulursa modu geri alir -> ATLANIR)
  * "Black Beard.zip", "Nosso Senhor.zip", "Captain Jack Sparrow.zip"
                               -> DataPC_*_patch_02.forge + README.txt
  * "EDWARD_ROBES_EDIT.rar"    -> `.dds` (topluluk adlandirmasi); bugunku
                                  kiyafet yazicisi PNG bekler -> kurulamaz
                                  olarak isaretlenir, UYDURULMAZ.

DUZ DIL KURALI
  `aciklama` ve `ozet` kullaniciya gorunur; teknik kimlik TASIMAZ. Materyal
  kimligi, slot numarasi, forge ic kimligi yalnizca `hedef` icinde durur --
  orasi yazicinin okudugu yer, kullanicinin okudugu yer degil.

CEVRILEBILIRLIK -- ARAYUZE VERILEN SOZ (2026-09-07)
  Kullaniciya gorunen her cumlenin IKI hali vardir:
      "ozet":       ["Changes Edward Kenway's Robes (dress, hood, tunic)"]   (duz)
      "ozet_kalip": [{"t": "Changes {0} ({1}, {2}, {3})",
                      "a": ["Edward Kenway's Robes", "dress", "hood", "tunic"]}]
  Kalibi olan alanlar:
      plan: ozet / ozet_kalip . uyarilar / uyarilar_kalip . mesaj / mesaj_kalip
      oge : aciklama / aciklama_kalip . sebep / sebep_kalip . soru / soru_kalip
      oge["adaylar"][i]: metin / metin_kalip (+ benzer_kalip)
      tanimayan[i], atlanan[i]: sebep / sebep_kalip
      cakisan[i]: aciklama / aciklama_kalip
  Arayuz KALIBI tercih etmeli (msj(x) -> Tf(x.t, ...x.a)); duz alanlar eski
  cagiranlar (mod_kayit, log satirlari, testler) icin AYNEN duruyor. Ikisi tek
  kaynaktan uretilir: duz metin = kalip_metin(kalip).
  ARGUMANLAR: varlik adlari ("Edward Kenway's Robes", "Jackdaw") CEVRILMEZ;
  parca adlari ("hood", "sails", "main colour") PARCA_ADLARI kumesindendir ve
  arayuz onlari da T() ile cevirmelidir.
  BILINEN EKSIK: arsiv acma hatalari (`_ac` / `_girisleri_denetle` sebepleri)
  hala duz dizedir; o yolda `mesaj_kalip` None doner ve arayuz Ingilizce metni
  gosterir -- bugunku davranisin aynisi, sessiz bir gerileme degil.
"""
import contextlib
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
TAR = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "tar.exe")

# --------------------------------------------------------------- kabul edilenler
ARSIV_UZANTI = (".zip", ".rar", ".7z")
DOKU_UZANTI = (".png",)
DDS_UZANTI = (".dds",)
MESH_UZANTI = (".glb", ".gltf", ".fbx")
SES_UZANTI = (".wav", ".ogg", ".wem", ".mp3", ".flac")
FORGE_UZANTI = (".forge",)
# paketin yaninda gelen, kurulmayacak ama sorun da olmayan dosyalar
SESSIZ_UZANTI = (".txt", ".md", ".json", ".nfo", ".url", ".pdf", ".jpg", ".jpeg",
                 ".webp", ".bmp", ".html", ".htm", ".ini", ".log")

# --------------------------------------------------------------- guvenlik siniri
EN_COK_DOSYA = 20000          # bir pakette makul dosya sayisi ust siniri
EN_COK_BAYT = 6 * 1024 ** 3   # acilmis toplam boyut ust siniri (forge'lar buyuk)
BOMBA_ORAN = 500              # sikistirma orani (acilmis/sikisik) ust siniri
BOMBA_TABAN = 64 * 1024 ** 2  # oran yalniz bu boyutun ustundeki girise bakilir

# --------------------------------------------------------------- guven esikleri
ESIK_OTOMATIK = 0.90          # "%90+ ise SORMA" -- kaptanin kurali
# ALT sinir (hangi eslesme aday olarak GOSTERILIR) burada TEKRARLANMAZ:
# eslestir.ESIK_ADAY tek kaynaktir. Iki yerde tutulursa biri bayatlar.
# Bu modulun esigi eslestirici'ninkinden YUKSEK (0.90 > 0.85): eslestirici
# "otomatik" dese bile, %90 altinda kullaniciya SORULUR.
# ICERIKTEN esleme goruntu basina ~10 ms + kod cozme maliyetidir. Olculdu:
# Workshop'un KENDI surum zip'i (2.000+ PNG) 27 saniye suruyordu ve hicbiri mod
# degildi. Bu sayinin ustunde icerik eslemesi KOSULMAZ ve bu ACIKCA soylenir --
# sessizce yarim taramaktansa "bakmadim" demek dogru.
EN_COK_ICERIK = 200

# Aracin KENDI kurulum paketi: mod degil, uygulamanin kendisi.
ARAC_IMZASI = ("workshop.exe", "outfitworkshop.exe", "outfitworkshop.dll",
               "surum.json", "workshop.bat", "outfit workshop.bat")

# tasarimcinin vanilla yedegini tuttugu klasorler: KURULMAZ (modu geri alirdi)
ATLANAN_KLASOR = ("_reference_do_not_edit", "original", "originals", "vanilla",
                  "backup", "backups", "yedek", "_backup", "reference",
                  "__macosx")

# Outfit Workshop'un kendi export dosya adi:
#   IC_<matID>_tm<matID>_<slot>_<WxH>_<WxH>_<BCn>.png
SLOT_RE = re.compile(
    r"IC_([0-9A-Fa-f]+)_tm[0-9A-Fa-f]+_(\d+)_(\d+)x(\d+)_\d+x\d+_(BC[137])\.png$",
    re.I)
# topluluk .dds adlandirmasi: 02_COAT_BODY_0x22D90B0ACAC_2048x2048_BC1_sRGB.dds
DDS_MAT_RE = re.compile(r"0x([0-9A-Fa-f]{9,13})", re.I)
# Aracin kendi (A) bicimi ve topluluk "sN"/"slotN" etiketi -- doku_enjekte2.ad_coz ile AYNI
# kural, ama BU modul yaziciyi import ETMEZ (bkz. _outfit_katalog), o yuzden burada tekrar.
DDS_IC_RE = re.compile(r"^IC_([0-9A-Fa-f]{9,13})_tm[0-9A-Fa-f]{9,13}_(\d+)_", re.I)
DDS_SLOT_RE = re.compile(r"(?:^|[_\-.])s(?:lot)?(\d+)(?:[_\-.]|$)", re.I)
# DDS basligindaki dxgi -> (aile, srgb). Yalniz oyunun kullandigi aileler + yaygin
# eski FourCC'ler; digerleri ADIYLA reddedilir (tahmin YOK).
DDS_DXGI = {71: ("BC1", 0), 72: ("BC1", 1), 74: ("BC2", 0), 75: ("BC2", 1),
            77: ("BC3", 0), 78: ("BC3", 1), 80: ("BC4", 0), 83: ("BC5", 0),
            95: ("BC6H", 0), 98: ("BC7", 0), 99: ("BC7", 1)}
DDS_YAZILABILIR = ("BC1", "BC3", "BC7")

# ozette ASLA gorunmemesi gereken teknik kimlik izleri (kendi kendini denetler)
TEKNIK_RE = re.compile(r"0x[0-9A-Fa-f]{6,}|(?<![A-Za-z])s\d|mat_id|tm[0-9A-F]{9,}", re.I)


# =============================================================== CEVIRI: KALIP + ARGUMAN
# NEDEN (2026-09-07, kaptanin ekran goruntusu): Turkce arayuzde birakilan modun
# ozeti INGILIZCE geliyordu. Sebep yapisal: bu modulun kullaniciya gorunen
# cumleleri KOSTURULARAK kuruluyordu ("Changes %s (%s)") ve boyle bir cumle
# sozlukte anahtar OLAMAZ -- kiyafet adi her modda baskadir.
#
# COZUM: cumlenin CERCEVESI sabit bir KALIP, degisen kisim ARGUMAN olur:
#     {"t": "Changes {0} ({1})", "a": ["Edward Kenway's Robes", "hood"]}
# Kalip sozlukte anahtar olur. Argumanin kendisi ya CEVRILMEZ (varlik adi:
# "Edward Kenway's Robes", "Jackdaw" -- oyunun kendi adlari) ya da PARCA_ADLARI
# kumesinden gelir (parca adi: "hood", "sails", "main colour" -- o kume de
# sozlukte durur). Bicim, projede zaten kullanilan bicimdir (sunucu.py'nin
# `_duz_metin`i, arayuzun `msj()`i); YENI bir sey uydurulmadi.
#
# IKI DEGISMEZ KURAL
#  1. Kalip metni KAYNAKTA `{"t": "..."}` SABITI olarak GORUNMELI. Envanter
#     (testler/ceviri_envanter.py) tam bu kalibi regex ile toplar; kalibi
#     calisma aninda kurarsan envanter goremez, cumle SESSIZCE Ingilizce kalir.
#     OLCULDU (2026-09-07): degisiklikten once ceviri_envanter.py_dizeleri()
#     bu dosyadan 0 (SIFIR) metin topluyordu -- yani MODS katmaninin tamami
#     dort dilde de Ingilizce'ye dusuyordu ve iki kapi da sessizdi.
#  2. COGUL EKI KALIBA GOMULMEZ. "Installs {0} ready-made game patch{1}" YANLIS:
#     Turkce/Rusca cogul kurallari Ingilizce'nin "s"ine benzemez. Tekil ve cogul
#     AYRI kaliptir (asagida hepsi ayri sabit).
#
# GERIYE UYUM: duz metin alanlari (`ozet`, `aciklama`, `sebep`, `mesaj`) AYNEN
# uretilmeye devam eder -- ama artik KALIPTAN DOLDURULARAK, yani tek kaynaktan.
# Boylece "kalip ile duz metin ayrisir" diye bir hata sinifi kalmaz. Yani
# cagiranlarin (mod_kayit, sunucu, testler) hicbiri kirilmaz; kalibi ISTEYEN
# arayuz `*_kalip` alanlarini okur, istemeyen eski alani okumaya devam eder.
def _k(sablon, *a):
    """Kalip SABITINI argumanlarla birlestirip {"t": ..., "a": [...]} uret.

    `sablon` daima cagri yerinde ya da bir tabloda duran `{"t": "..."}` SABITIDIR
    (yukaridaki 1. kural). Burada metin URETILMEZ, yalnizca kopyalanir."""
    return {"t": sablon["t"], "a": list(a)}


def kalip_metin(k):
    """Kalibi DUZ metne cevir.

    Doldurma kurali arayuzun `msj()` ve sunucu.py'nin `_duz_metin`i ile AYNIDIR:
    {0}, {1} ... sirayla, dize olarak yerine konur. Kalip yerine duz dize
    verilirse oldugu gibi doner (gecis donemi ve `_bos` gibi cagiranlar icin)."""
    if isinstance(k, dict) and k.get("t"):
        s = str(k["t"])
        for i, d in enumerate(k.get("a") or []):
            s = s.replace("{%d}" % i, str(d))
        return s
    return "" if k is None else str(k)


def kaliplar_metin(liste):
    """[kalip, ...] -> [duz metin, ...]"""
    return [kalip_metin(k) for k in (liste or [])]


# =============================================================== kucuk yardimcilar
def _norm(s):
    return (s or "").replace("\\", "/")


def _alt(s):
    return (s or "").lower()


def _uzanti(ad):
    return os.path.splitext(ad)[1].lower()


def _atlanan_yol_mu(gorece_yol):
    """Yolun herhangi bir klasoru 'vanilla yedegi' kaliplarindan biri mi?"""
    parcalar = [p for p in _norm(gorece_yol).split("/")[:-1] if p]
    return any(_alt(p) in ATLANAN_KLASOR for p in parcalar)


# =============================================================== ARSIV UYE KAPISI
# TEK KURAL TABLOSU -- iki kopya kural YOK.
#
# Bu fonksiyonu IKI yol da cagirir:
#   * kullanicinin BIRAKTIGI paket  -> bu modulun _girisleri_denetle / _ac'i
#   * katalogdan INEN mod           -> mod_kutuphane._zip_denetle / _ac
# Kanonik yer NEDEN burasi:
#   1. Arsiv uyesinin adi, arsiv formatindan bagimsiz bir DIZEDIR. Bu modul
#      hem zip'i (zipfile) hem rar/7z'yi (tar.exe) okudugu icin kurali zaten
#      dize uzerinde ifade etmek ZORUNDA; mod_kutuphane yalniz zip goruyor ve
#      kuralini ZipInfo alanlarina baglamisti.
#   2. Bagimlilik yonu: mod_kutuphane -> guncelle (yayin kanali) zaten var ve
#      bu modul HICBIR yerel modulu import etmiyor. Ok bu yonde dongu kuramaz;
#      ters yon, agsiz calismasi gereken birakma yoluna yayin kanalini sokardi.
#
# NEDEN GEREKTI (2026-09-07 olcumu): iki kopya ayrismisti. "resim.png:gizli.exe"
# adli zip uyesini mod_kutuphane ":" kuraliyla REDDEDIYOR, mod_paket KABUL
# ediyordu; diskte 208 baytlik bir NTFS gizli akisi olusuyor (dir /r ->
# "208 resim.png:gizli.exe:$DATA"), gorunen resim.png ise 0 BAYT kaliyordu.
# Ayni ayrisma symlink uyesinde de vardi (zip yolunda hic bakilmiyordu).
#
# ADIN DISKE INEN HALI, DENETLENEN HALIYLE AYNI OLMALI. Olculdu:
#   "kur.exe."     -> diskte "kur.exe"  (splitext ".exe" DEGIL "." verir)
#   "ok.png "      -> diskte "ok.png"   (splitext ".png " verir)
#   "a.png::$DATA" -> diskte "a.png"
#   "NUL"          -> hic dosya olusmaz, baytlar sessizce kaybolur
# Bu yuzden kuyruk nokta/bosluk ve ciplak aygit adi da REDDEDILIR.
_ARSIV_SEBEP = {
    "bos": "empty name",
    "mutlak": "absolute path",
    "surucu": "drive letter in path",
    "akis": "a colon, which Windows reads as a hidden stream name",
    "ust": "path escapes the package (..)",
    "kontrol": "a control character in the name",
    "karakter": "a character Windows cannot store in a file name",
    "kuyruk": "a name that begins or ends with a space, or ends with a dot, which "
              "Windows trims away",
    "aygit": "a name Windows keeps for a device",
    "baglanti": "a shortcut (symbolic link)",
    "program": "a program file",
    "uzanti": "a file type this tool cannot install",
}
# Ciplak aygit adlari: bunlara yazilan baytlar diske HIC inmez (olculdu).
# Uzantili hali ("nul.png") bu Windows'ta normal dosya oluyor, o yuzden
# yalnizca segmentin TAMAMI aygit adiysa reddedilir -- olcumun otesine gecme.
_AYGIT_ADI = frozenset(
    ("con", "prn", "aux", "nul", "clock$")
    + tuple("com%d" % i for i in range(1, 10))
    + tuple("lpt%d" % i for i in range(1, 10)))
# ":" ayri kodla yakalanir (surucu harfi / gizli akis ayrimi mesaja giriyor)
_YASAK_KARAKTER = '<>"|?*'


def arsiv_uye_denetle(ad, baglanti=False, yasak_uzanti=None, izinli_uzanti=None):
    """Bir arsiv uyesi diske yazilabilir mi? Doner (ok, kod, sebep).

    `baglanti`      : uye kisayol (symlink) olarak isaretli mi.
    `yasak_uzanti`  : verilirse bu uzantilar "program dosyasi" diye reddedilir.
    `izinli_uzanti` : verilirse LISTE DISI her uzanti reddedilir (fail-closed).

    Son iki parametre POLITIKADIR, kural degil: mod_kutuphane kendi kanalinda
    dar bir beyaz liste uygular; birakma yolu ise kullanicinin ne birakirsa
    biraksin duzgun ANLATILMASI gerektigi icin uzantiya gore paket REDDETMEZ
    (aracin kendi surum zip'i .exe/.dll tasir ve "bu Workshop'un kendisi"
    diye taninmasi gerekir). Yol/ad kurallari ise IKISINDE DE AYNIDIR."""
    if baglanti:
        return False, "baglanti", _ARSIV_SEBEP["baglanti"]
    # DIKKAT: burada `a.strip()` YAPILMAZ. Kirpilmis ad, diske INEN addan farkli
    # olurdu ve kural kendi olcecegi seyi gizlerdi -- "ok.png " tam da bu yuzden
    # ilk yazimda kapiyi gecmisti (olculdu). Bosluk/nokta kuyrugu ASAGIDA, segment
    # segment reddedilir.
    a = _norm(ad)
    if not a.strip() or not a.strip().strip("/"):
        return False, "bos", _ARSIV_SEBEP["bos"]
    if "\x00" in a:
        return False, "kontrol", _ARSIV_SEBEP["kontrol"]
    if a.startswith("/") or a.startswith("~"):
        return False, "mutlak", _ARSIV_SEBEP["mutlak"]
    if re.match(r"^[A-Za-z]:", a):
        return False, "surucu", _ARSIV_SEBEP["surucu"]
    if ":" in a:
        return False, "akis", _ARSIV_SEBEP["akis"]
    for p in a.split("/"):
        if p == "..":
            return False, "ust", _ARSIV_SEBEP["ust"]
        if not p:
            continue
        if any(ch < " " or ch == "\x7f" for ch in p):
            return False, "kontrol", _ARSIV_SEBEP["kontrol"]
        if any(ch in _YASAK_KARAKTER for ch in p):
            return False, "karakter", _ARSIV_SEBEP["karakter"]
        # bastaki nokta MESRU (".gitignore"); bastaki bosluk ve sondaki nokta/bosluk
        # degil -- Windows onlari sessizce atar, ad denetlenenden BASKA olur.
        if p[0] == " " or p[-1] in ". ":
            return False, "kuyruk", _ARSIV_SEBEP["kuyruk"]
        if p.lower() in _AYGIT_ADI:
            return False, "aygit", _ARSIV_SEBEP["aygit"]
    uz = os.path.splitext(a)[1].lower()
    if yasak_uzanti and uz in yasak_uzanti:
        return False, "program", _ARSIV_SEBEP["program"]
    if izinli_uzanti is not None and uz not in izinli_uzanti:
        return False, "uzanti", _ARSIV_SEBEP["uzanti"]
    return True, "", ""


def zip_uye_baglanti_mi(zi):
    """zip uyesi kisayol (symlink) olarak mi isaretli? (iki yol da bunu sorar)"""
    try:
        return ((zi.external_attr >> 16) & 0o170000) == 0o120000
    except Exception:                                             # noqa: BLE001
        return False


def _guvenli_ad(ad, baglanti=False):
    """Kanonik kapinin bu modulteki adi (eski cagiranlar degismesin diye)."""
    ok, _kod, sebep = arsiv_uye_denetle(ad, baglanti=baglanti)
    return ok, sebep


# =============================================================== arsiv acma
def tar_var_mi():
    return os.path.isfile(TAR)


def _tar_listele(arsiv):
    """(girisler, hata). giris: {"ad", "boyut", "klasor", "baglanti"}"""
    try:
        c = subprocess.run([TAR, "-tvf", arsiv], capture_output=True, timeout=180,
                           creationflags=NO_WINDOW)
    except Exception as e:                                        # noqa: BLE001
        return None, "the archive could not be read (%s)" % str(e)[:120]
    if c.returncode != 0:
        return None, ("the archive could not be read: %s"
                      % (c.stderr or b"").decode("utf-8", "replace").strip()[:200])
    out = []
    for satir in (c.stdout or b"").decode("utf-8", "replace").splitlines():
        p = satir.split(None, 8)
        if len(p) < 9:
            continue
        izin, boyut, ad = p[0], p[4], p[8]
        # Kisayol uyesi ERKEN DONMEZ: isaretlenir ve TEK kapidan (_girisleri_denetle
        # -> arsiv_uye_denetle) gecer. Boylece red sebebi iki yolda da ayni yerden gelir.
        baglanti = izin[:1] == "l"
        if baglanti and " -> " in ad:
            ad = ad.split(" -> ", 1)[0]
        try:
            boyut = int(boyut)
        except ValueError:
            boyut = 0
        out.append({"ad": ad, "boyut": boyut, "klasor": izin[:1] == "d",
                    "baglanti": baglanti})
    return out, ""


def _zip_listele(arsiv):
    try:
        with zipfile.ZipFile(arsiv) as z:
            out = []
            for zi in z.infolist():
                out.append({"ad": zi.filename, "boyut": zi.file_size,
                            "sikisik": zi.compress_size, "klasor": zi.is_dir(),
                            "baglanti": zip_uye_baglanti_mi(zi)})
            return out, ""
    except zipfile.BadZipFile:
        return None, "that file is not a zip archive"
    except Exception as e:                                        # noqa: BLE001
        return None, "the archive could not be read (%s)" % str(e)[:120]


def _girisleri_denetle(girisler):
    """Yol kacisi / zip bombasi / boyut kapilari. Doner (ok, sebep)."""
    dosyalar = [g for g in girisler if not g["klasor"]]
    if not dosyalar:
        return False, "the package is empty"
    if len(dosyalar) > EN_COK_DOSYA:
        return False, ("the package holds %d files, which is more than this tool "
                       "will open (%d)" % (len(dosyalar), EN_COK_DOSYA))
    toplam = 0
    for g in girisler:
        ok, sebep = _guvenli_ad(g["ad"], baglanti=bool(g.get("baglanti")))
        if not ok:
            return False, "unsafe entry in the package (%s): %s" % (sebep, g["ad"][:120])
        toplam += int(g.get("boyut") or 0)
        sik = g.get("sikisik")
        if (sik is not None and sik > 0 and g["boyut"] > BOMBA_TABAN
                and g["boyut"] / float(sik) > BOMBA_ORAN):
            return False, ("one file in the package expands %.0f times its packed size, "
                           "which is not a real mod file: %s"
                           % (g["boyut"] / float(sik), g["ad"][:100]))
    if toplam > EN_COK_BAYT:
        return False, ("the package would unpack to %.1f GB, which is larger than this "
                       "tool will open" % (toplam / float(1024 ** 3)))
    return True, ""


def _ac(arsiv, hedef):
    """Arsivi hedefe ac. Doner (ok, sebep). Kapilar ONCE, acma SONRA."""
    uz = _uzanti(arsiv)
    if uz == ".zip":
        girisler, hata = _zip_listele(arsiv)
    else:
        if not tar_var_mi():
            return False, ("this Windows does not have the archive reader (tar.exe) "
                           "that %s files need; unpack the file yourself and pick the "
                           "folder instead" % uz.lstrip("."))
        girisler, hata = _tar_listele(arsiv)
    if girisler is None:
        return False, hata
    ok, sebep = _girisleri_denetle(girisler)
    if not ok:
        return False, sebep

    os.makedirs(hedef, exist_ok=True)
    if uz == ".zip":
        # IKINCI KATMAN: ad kapisi acma anINDA tekrar sorulur ve varis yolunun
        # hedefin ICINDE kaldigi ayrica olculur. Listeleme ile acma arasinda ayni
        # dosyayi iki kez okuyoruz; arada degistirilmis bir arsiv burada duser.
        kok = os.path.abspath(hedef)
        try:
            with zipfile.ZipFile(arsiv) as z:
                for zi in z.infolist():
                    if zi.is_dir():
                        continue
                    ok2, sebep2 = _guvenli_ad(zi.filename,
                                              baglanti=zip_uye_baglanti_mi(zi))
                    if not ok2:
                        shutil.rmtree(hedef, ignore_errors=True)
                        return False, ("unsafe entry in the package (%s): %s"
                                       % (sebep2, str(zi.filename)[:120]))
                    varis = os.path.abspath(
                        os.path.join(kok, *[p for p in _norm(zi.filename).split("/") if p]))
                    if varis != kok and not varis.startswith(kok + os.sep):
                        shutil.rmtree(hedef, ignore_errors=True)
                        return False, ("unsafe entry in the package (it would be written "
                                       "outside the package): %s" % str(zi.filename)[:120])
                    os.makedirs(os.path.dirname(varis), exist_ok=True)
                    with z.open(zi) as kaynak, open(varis, "wb") as f:
                        shutil.copyfileobj(kaynak, f)
        except Exception as e:                                    # noqa: BLE001
            return False, "the package could not be unpacked (%s)" % str(e)[:150]
        return True, ""

    try:
        c = subprocess.run([TAR, "-xf", arsiv, "-C", hedef], capture_output=True,
                           timeout=1800, creationflags=NO_WINDOW)
    except Exception as e:                                        # noqa: BLE001
        return False, "the package could not be unpacked (%s)" % str(e)[:150]
    if c.returncode != 0:
        return False, ("the package could not be unpacked: %s"
                       % (c.stderr or b"").decode("utf-8", "replace").strip()[:200])
    # rar/7z boyutlari acilmadan once guvenilir degil: acildiktan SONRA da olc
    gercek = 0
    for kok, _d, dosyalar in os.walk(hedef):
        for f in dosyalar:
            try:
                gercek += os.path.getsize(os.path.join(kok, f))
            except OSError:
                pass
    if gercek > EN_COK_BAYT:
        shutil.rmtree(hedef, ignore_errors=True)
        return False, ("the package unpacked to %.1f GB, which is larger than this tool "
                       "will open" % (gercek / float(1024 ** 3)))
    return True, ""


def _tek_kok_duzle(kok):
    """Paket tek bir kok klasorle sarilmissa o klasoru paket koku say.

    `Mod.zip -> Mod/...` toplulukta standart. Duzlenmezse mod adi ve gorece
    yollar bir seviye kayar; dosya bulmayi degil, ADLANDIRMAYI bozar."""
    derinlik = 0
    while derinlik < 8:
        try:
            icerik = [a for a in os.listdir(kok) if not a.startswith(".")]
        except OSError:
            break
        if len(icerik) != 1:
            break
        tek = os.path.join(kok, icerik[0])
        if not os.path.isdir(tek):
            break
        kok = tek
        derinlik += 1
    return kok


# =============================================================== katalog kopruleri
_ONBELLEK = {}


def _outfit_katalog():
    """Kiyafet katalogu: [{ad, gorunen_ad, materyaller:[...]}].

    Once `outfit_core` denenir. O modul TEK YAZICI'yi (doku_enjekte2) import
    ettigi icin kurulum eksikse patlayabilir; katalog ise duz veridir ve
    kaynagin icine gomuludur. Bu yuzden yedek yol: kaynaktan JSON'u sok."""
    if "outfit" in _ONBELLEK:
        return _ONBELLEK["outfit"]
    kat = None
    try:
        import outfit_core as OC
        kat = OC.CATALOG
    except Exception:                                             # noqa: BLE001
        try:
            with open(os.path.join(BURA, "outfit_core.py"), encoding="utf-8") as f:
                metin = f.read()
            i = metin.index('_CATALOG_JSON = r"""') + len('_CATALOG_JSON = r"""')
            kat = json.loads(metin[i:metin.index('"""', i)])
        except Exception:                                         # noqa: BLE001
            kat = []
    # (mat_id, slot_idx) -> [kayit, ...]  -- TEK kayit DEGIL.
    # Olculdu (113 kiyafet, 1.002 slot): 55 slot BIRDEN COK kiyafette gecer
    # (ornek: mankenin dokusu 18 kiyafette ayni). Son kaydi tutmak, Ezio modunu
    # "Ferraro Diplomat Outfit" diye tanitiyordu. Hepsini tut, ATFI SONRA yap.
    slotlar = {}
    for o in kat or []:
        for m in o.get("materyaller") or []:
            mid = _mat_anahtar(m.get("mat_id"))
            for s in m.get("slotlar") or []:
                slotlar.setdefault((mid, int(s.get("idx", -1))), []).append({
                    "gorunen_ad": o.get("gorunen_ad") or o.get("ad"),
                    "kiyafet": o.get("ad"), "parca_adi": m.get("parca_adi"),
                    "rol": s.get("rol"), "duzenlenebilir": bool(s.get("duzenlenebilir")),
                    "W": s.get("W"), "H": s.get("H"),
                })
    _ONBELLEK["outfit"] = {"katalog": kat or [], "slotlar": slotlar}
    return _ONBELLEK["outfit"]


def _slot_kayitlari(mat, slot):
    """(mat, slot) icin TUM kiyafet kayitlari (paylasilan doku birden cok doner)."""
    return _outfit_katalog()["slotlar"].get((_mat_anahtar(mat), int(slot))) or []


def _kayit_sec(kayitlar, tercih=None):
    """Paylasilan bir dokuyu HANGI kiyafete atfedecegiz?

    `tercih` paketin baskin kiyafetidir (paketteki tekil dosyalardan sayilir).
    Tercih listede varsa o kazanir; yoksa ilk kayit. Duzenlenebilirlik butun
    kayitlarda ayni oldugu icin (olculdu: 55 paylasilan slotun 0'inda celiski)
    secim guvenligi degil, yalnizca ADI degistirir."""
    if not kayitlar:
        return None
    if tercih:
        for k in kayitlar:
            if k.get("kiyafet") == tercih or k.get("gorunen_ad") == tercih:
                return k
    return kayitlar[0]


def _ship_katalog():
    """Gemi hedefleri: anahtar(kucuk) -> hedef kaydi. Motoru YUKLEMEZ.

    ship_core.mod_tara ayni kataloga bakar ama Oodle DLL'ini de yukleyen motoru
    ayaga kaldirir; burada yalniz JSON okunur (paket cozumu oyun klasoru
    baglanmadan da calismali)."""
    if "ship" in _ONBELLEK:
        return _ONBELLEK["ship"]
    yol = os.path.join(BURA, "ship", "katalog", "ship_hedefler.json")
    hedefler = {}
    try:
        with open(yol, encoding="utf-8") as f:
            kat = json.load(f)
        for h in kat.get("hedefler") or []:
            if h.get("kullanilabilir", True):
                hedefler[_alt(h.get("anahtar"))] = h
    except Exception:                                             # noqa: BLE001
        pass
    _ONBELLEK["ship"] = hedefler
    return hedefler


# =============================================================== duz dil
SHP_GRUP_METIN = {
    "hull": "hull", "sail": "sails", "flag": "flags", "figurehead": "figurehead",
    "wheel": "wheel", "cabin": "captain's cabin", "cannon": "cannons",
    "crew": "crew clothing", "enemy": "enemy ships", "banner": "fort banners",
    "lut": "paint colour",
}
ROL_METIN = {
    "Colour (diffuse)": "main colour",
    "Surface (normal)": "surface detail",
    "Glow map (LOCKED)": "glow map",
    "Region mask (LOCKED)": "region mask",
}

# ---------------------------------------------------------------- PARCA ADLARI
# Kaliplarin ARGUMANI iki cinstir:
#   * VARLIK ADI  -- "Edward Kenway's Robes", "Jackdaw", "Captain Morgan's
#     Redingote". Bunlar OYUNUN KENDI adlari; CEVRILMEZ, oldugu gibi gecer.
#   * PARCA ADI   -- "hood", "sails", "main colour". Bunlar aracin KENDI duz-dil
#     sozcukleridir ve CEVRILIR. Kume KAPALI oldugu icin burada sabit durur:
#     hem envanter toplayabilsin (ceviri_envanter SABIT_METINLER'i okur), hem de
#     katalog buyudugunde YENI bir ad sessizce Ingilizce kalmasin -- test
#     ("parca adlarinin hepsi PARCA_ADLARI icinde") KIRMIZI yanar.
#
# OLCUM (2026-09-07, canli katalogdan uretildi): kiyafet katalogunun 161 ham
# parca adi + gemi katalogunun 8 grubu + 4 rol -> 108 AYRI duz-dil adi. Liste
# el yazimi degil, `_parca_duz` + SHP_GRUP_METIN + ROL_METIN ciktisidir.
#
# DURUSTLUK NOTU: bu 108 adin bir bolumu ("sword espada anchas", "musket
# blackbeard") oyunun silah adlarindan turer; cevirmenin onlari OLDUGU GIBI
# birakmasi dogrudur. Yine de kumeye girerler, cunku karari cevirmen verir --
# arac onlari sessizce Ingilizce'ye kilitlemez.
PARCA_ADLARI = frozenset((
    # -- kiyafet katalogundan (_parca_duz ciktisi)
    "arm", "armor", "asian trinket set", "belt", "bloody spanish medal", "body",
    "boots", "bracer", "cape", "captain drakes flintlock", "dress",
    "edward kenway cutlass", "fire trinket set", "golden pistol", "greaves",
    "gun holster back", "hair", "helmet", "hidden blade left",
    "hidden blade right", "hood", "jewelry", "kenway iconic pistol",
    "musket blackbeard", "musket blunderbuss right down holster",
    "musket canon barrel pistols", "musket captain morgans gun",
    "musket captain wheellock pistol", "musket dark animus", "musket fire set",
    "musket golden flintlock pistols", "musket jade set", "musket master assassin",
    "musket pirate flintlock", "musket sea serpent set",
    "musket spanish officer pistols", "musket tide worn", "musket ultimate pistol",
    "musket wheellock pistol", "necklace", "pants", "red bull trinket", "rope",
    "shoes", "shoulders", "skirt", "strap", "straps", "sword altair sword",
    "sword aveline machete", "sword black beard", "sword british cutlass",
    "sword broadsword scotting", "sword cutlasses colonial american",
    "sword cutlasses privateer", "sword dark animus", "sword drakes dual left hand",
    "sword drakes dual right hand", "sword espada anchas", "sword ezio",
    "sword ferraro rapiers", "sword fire set", "sword french court",
    "sword french dress swords", "sword german rapier left",
    "sword german rapier right", "sword golden left hand", "sword golden right hand",
    "sword jade set", "sword ke", "sword legend left hand", "sword legend right hand",
    "sword master assassin", "sword meat cleaver", "sword officer small",
    "sword persian scimitar", "sword pirate scimitar", "sword pistol swords primary",
    "sword rapier officer right hand", "sword sea serpent", "sword shadow",
    "sword shadow black", "sword shadow guard", "sword shadow handlacing",
    "sword shadow handle", "sword shadow men wnt", "sword shadow rayskin",
    "sword spanish rapier", "sword tide worn", "sword ultimate sw",
    "sword unique dual sword", "torso", "trinket", "tunic", "utils",
    "wardrobe mannequin",
    # -- gemi katalogundan (SHP_GRUP_METIN)
    "cannons", "captain's cabin", "crew clothing", "figurehead", "flags", "hull",
    "sails", "wheel",
    # -- slot rolleri (ROL_METIN)
    "glow map", "main colour", "region mask", "surface detail",
) + (
    # -- YEDEK adlar: katalogda karsiligi olmayan, yalniz ad bos/tanimsizken
    # kullanilan duz-dil sozcukleri. "Olu anahtar" testi bunlari ARAR.
    "part", "parts", "an unpaintable part",
))
# Yalniz yedek adlar (canli katalogdan URETILMEZ; testteki olu-anahtar kapisi
# bu uceyi ayri tutar, yoksa kapi kendi kendini kirmizi yakardi).
PARCA_YEDEK_ADLARI = frozenset(("part", "parts", "an unpaintable part"))

# ceviri_envanter.py'nin okudugu kanonik ad (ship_core / silah_stat ile ayni
# sozlesme): kullaniciya gorunen SABIT sozcukler. Cumle CERCEVELERI buraya
# girmez -- onlar kaynakta `{"t": "..."}` sabiti olarak zaten toplanir.
SABIT_METINLER = tuple(sorted(PARCA_ADLARI))


# Katalogdaki parca adlarinin basinda oyunun kendi kod on ekleri var
# (CHR_TRK_Anchor_Medallion, OBD_W_P_Pirate_Musket_Flintlock, ...). Bunlar
# kullaniciya gosterilecek metne giremez; olculdu: 161 parca adinin 104'u
# bu on eklerden en az birini tasiyor.
KOD_PARCACIK = {"obd", "chr", "trk", "shp", "gen", "std", "arc", "com", "unq",
                "lod", "mtx", "dlc", "wpn", "acc", "mdl", "md", "w", "p", "s",
                "u", "b", "a", "hdw", "atl", "tex", "mat", "grp", "pc", "store"}
# tek harflik EL isareti: kod degil, anlam tasir
EL_PARCACIK = {"r": "right hand", "l": "left hand"}


def _parca_duz(parca_adi):
    """Katalog parca adini konusma diline cevir.

    Katalogda 'Tunic013', 'C H R 2', 'CHR_TRK_Anchor_Medallion' gibi ham adlar
    var; kullaniciya gosterilecek metin bunlari tasiyamaz."""
    a = (parca_adi or "").strip()
    if not a:
        return "part"
    d = a.lower()
    if re.match(r"^c\s*h\s*r\b\s*\d*$", d):
        return "body"
    if "mannequin" in d:
        return "wardrobe mannequin"
    if "no editable texture" in d:
        return "an unpaintable part"
    a = re.sub(r"[()]", " ", a).replace("_", " ")
    a = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", a)
    parcalar = [p for p in a.split() if p]
    # sondaki varyant numaralarini at: '01A', '2', '013'
    while parcalar and re.match(r"^\d+[A-Za-z]?$", parcalar[-1]):
        parcalar.pop()
    # el isareti ('..._R_01A') numaralardan SONRA, kod elemesinden ONCE cozulur
    if parcalar and parcalar[-1].lower() in EL_PARCACIK:
        parcalar[-1] = EL_PARCACIK[parcalar[-1].lower()]
    # kod parcaciklarini at -- nerede olurlarsa olsunlar. Oyunun adlandirmasi
    # kodu ortaya da koyuyor ('Sword_OBD_W_STORE_Shadow_Black'). Olculdu:
    # 161 parca adinin 104'u en az bir kod parcacigi tasiyor.
    # varyant rakamlari ONCE dusmeli: 'B0' once 'B' olmali ki kod elemesi onu
    # yakalasin (olculdu: 'EdwardKenwayCutlass_B0' -> '... cutlass b' siziyordu)
    parcalar = [re.sub(r"\d+$", "", p) or p for p in parcalar]
    sade = [p for p in parcalar if p.lower() not in KOD_PARCACIK]
    parcalar = sade or parcalar                 # hepsi kodsa ham adi koru
    # ust uste tekrarlayan kelimeyi tek yaz ('sword sword golden')
    teksiz = []
    for p in parcalar:
        if not teksiz or teksiz[-1].lower() != p.lower():
            teksiz.append(p)
    metin = re.sub(r"\s+", " ", " ".join(teksiz)).strip().lower()
    return metin or "part"


# ---------------------------------------------------------- KIYAFET ACIKLAMASI
# Anahtar: (parca adi yaziliyor mu, rol yaziliyor mu, EK).
#   EK ""       -> yalin aciklama
#      "tek"    -> "...- this also changes 1 other outfit"    (TEKIL: ayri kalip)
#      "cok"    -> "...- this also changes {n} other outfits" (COGUL: ayri kalip)
#      "benzer" -> icerikten benzeyen ama SORULACAK dosya
# Cerceve tek parca halinde durur; yarim cumleler birlestirilmez. Sebep: cumle
# sirasi dilden dile degisir ("Edward Kenway's Robes - hood" Turkce'de baska
# dizilir) ve cevirmen ancak TAM cumleyi gorurse dogru cevirebilir.
_KIYAFET_KALIP = {
    (True, True, ""):        {"t": "{0} - {1} ({2})"},
    (True, False, ""):       {"t": "{0} - {1}"},
    (False, True, ""):       {"t": "{0} ({1})"},
    (False, False, ""):      {"t": "{0}"},
    (True, True, "tek"):     {"t": "{0} - {1} ({2}) - this also changes 1 other outfit"},
    (True, False, "tek"):    {"t": "{0} - {1} - this also changes 1 other outfit"},
    (False, True, "tek"):    {"t": "{0} ({1}) - this also changes 1 other outfit"},
    (False, False, "tek"):   {"t": "{0} - this also changes 1 other outfit"},
    (True, True, "cok"):     {"t": "{0} - {1} ({2}) - this also changes {3} other outfits"},
    (True, False, "cok"):    {"t": "{0} - {1} - this also changes {2} other outfits"},
    (False, True, "cok"):    {"t": "{0} ({1}) - this also changes {2} other outfits"},
    (False, False, "cok"):   {"t": "{0} - this also changes {1} other outfits"},
    (True, True, "benzer"):  {"t": "A picture that looks like {0} - {1} ({2})"},
    (True, False, "benzer"): {"t": "A picture that looks like {0} - {1}"},
    (False, True, "benzer"): {"t": "A picture that looks like {0} ({1})"},
    (False, False, "benzer"): {"t": "A picture that looks like {0}"},
}


def _kiyafet_parcalari(kayit):
    """Aciklamayi kuran UC parca: (varlik adi, parca adi, rol).

    Parca adi kiyafet adini tekrarliyorsa ("Espada Ancha - espada ancha") DUSER;
    kullaniciya bilgi katmiyor."""
    ad = kayit.get("gorunen_ad") or "an outfit"
    parca = _parca_duz(kayit.get("parca_adi"))
    rol = ROL_METIN.get(kayit.get("rol") or "") or None
    if _tekrar_mi(ad, parca):
        parca = None
    return ad, parca, rol


def _kiyafet_aciklama_kalip(kayit, ek="", n=0):
    """'{0} - {1} ({2})' + ["Captain Morgan's Redingote", "coat", "main colour"]"""
    ad, parca, rol = _kiyafet_parcalari(kayit)
    a = [ad]
    if parca:
        a.append(parca)
    if rol:
        a.append(rol)
    if ek == "cok":
        a.append(int(n))
    return _k(_KIYAFET_KALIP[(bool(parca), bool(rol), ek)], *a)


def _kiyafet_aciklama(kayit, ek="", n=0):
    """'Captain Morgan's Redingote - coat (main colour)' -- KALIPTAN doldurulur.

    Duz metin ile kalip tek kaynaktan cikar; ayrisamazlar."""
    return kalip_metin(_kiyafet_aciklama_kalip(kayit, ek, n))


def _tekrar_mi(ad, parca):
    sade = lambda s: re.sub(r"[^a-z ]", " ", (s or "").lower())      # noqa: E731
    a, p = set(sade(ad).split()), set(sade(parca).split())
    return bool(p) and p <= a


# ------------------------------------------------------------- GEMI ACIKLAMASI
# Anahtar: (tur, gemi adi yaziliyor mu, rol yaziliyor mu).
# Gemi ADI ("Jackdaw") arguman -- oyunun kendi adi, cevrilmez. Parca ("sails")
# ve rol ("surface detail") PARCA_ADLARI'ndan gelir, cevrilir.
_GEMI_ACIKLAMA_KALIP = {
    ("enemy", False, False):  {"t": "Enemy ships seen from a distance"},
    ("banner", False, False): {"t": "Fort banners"},
    ("lut", False, False):    {"t": "A ship paint colour"},
    ("gemi", True, False):    {"t": "The {0}'s {1}"},
    ("gemi", True, True):     {"t": "The {0}'s {1} ({2})"},
    ("gemi", False, False):   {"t": "A ship's {0}"},
    ("gemi", False, True):    {"t": "A ship's {0} ({1})"},
}
# Ozet satiri AYRI kaliptir, "Changes " + aciklama diye BIRLESTIRILMEZ: bircok
# dilde nesne cumlenin basina gecer ve yarim cumle birlestiren bir arayuz o
# dilde bozuk cumle uretir.
_GEMI_OZET_KALIP = {
    ("enemy", False, False):  {"t": "Changes enemy ships seen from a distance"},
    ("banner", False, False): {"t": "Changes fort banners"},
    ("lut", False, False):    {"t": "Changes a ship paint colour"},
    ("gemi", True, False):    {"t": "Changes the {0}'s {1}"},
    ("gemi", True, True):     {"t": "Changes the {0}'s {1} ({2})"},
    ("gemi", False, False):   {"t": "Changes a ship's {0}"},
    ("gemi", False, True):    {"t": "Changes a ship's {0} ({1})"},
}


def _gemi_parcalari(h):
    """Gemi hedefini CUMLE PARCALARINA ayir: (tur, gemi adi, parca, rol)."""
    grup = h.get("grup")
    if grup in ("enemy", "banner", "lut"):
        return grup, None, None, None
    gemi = "Jackdaw" if _sadece_jackdaw(h) else None
    if grup == "crew":
        return "gemi", gemi, "crew clothing", None
    rol = "surface detail" if h.get("kanal") == "normal" else None
    return "gemi", gemi, SHP_GRUP_METIN.get(grup, "parts"), rol


def _gemi_kalip(h, tablo):
    tur, gemi, parca, rol = _gemi_parcalari(h)
    a = [x for x in (gemi, parca, rol) if x]
    return _k(tablo[(tur, bool(gemi), bool(rol))], *a)


def _gemi_aciklama_kalip(h):
    """'The {0}'s {1}' + ["Jackdaw", "sails"]"""
    return _gemi_kalip(h, _GEMI_ACIKLAMA_KALIP)


def _gemi_ozet_kalip(h):
    """'Changes the {0}'s {1}' + ["Jackdaw", "sails"]"""
    return _gemi_kalip(h, _GEMI_OZET_KALIP)


def _gemi_ifade(h):
    """Ic kullanim: ozet gruplamasinin ANAHTARI (kucuk harfle baslar).

    Kullaniciya giden metin artik kaliptan gelir; bu dize yalniz ayni gemi
    parcasini bir kez saymak icin durur."""
    return _kucuk_harf(kalip_metin(_gemi_aciklama_kalip(h)))


def _kucuk_harf(s):
    """Yalniz ILK harfi kucult. (`_bas_harf`in tersi; o yardimcinin tek isi gemi
    aciklamasini buyuk harfle baslatmakti, artik kalibin kendisi oyle yaziyor.)"""
    return (s[:1].lower() + s[1:]) if s else s


# --------------------------------------------------- kalibi ve duz metni bir arada
# Her kullaniciya gorunen alanin IKI hali vardir: kalip (`*_kalip`) ve duz metin
# (eski alan adi). Ikisi de TEK cagriyla, TEK kaynaktan yazilir; birinin otekini
# unutmasi mumkun degil.
def _yaz_aciklama(oge, sablon, *a):
    oge["aciklama_kalip"] = _k(sablon, *a)
    oge["aciklama"] = kalip_metin(oge["aciklama_kalip"])
    return oge


def _yaz_sebep(oge, sablon, *a):
    oge["sebep_kalip"] = _k(sablon, *a)
    oge["sebep"] = kalip_metin(oge["sebep_kalip"])
    return oge


def _yaz_soru(oge, sablon, *a):
    oge["soru_kalip"] = _k(sablon, *a)
    oge["soru"] = kalip_metin(oge["soru_kalip"])
    return oge


def _kayit(kaynak, sablon, *a):
    """'tanimayan' / 'atlanan' satiri: {kaynak, sebep, sebep_kalip}"""
    k = _k(sablon, *a)
    return {"kaynak": kaynak, "sebep": kalip_metin(k), "sebep_kalip": k}


def _sadece_jackdaw(h):
    sinif = h.get("gemi_siniflari") or {}
    return bool(sinif) and set(sinif.keys()) <= {"BRG"}


def _mat_anahtar(v):
    """Materyal kimligini SOZLUK ANAHTARINA cevir: on ek yok, buyuk harf hex.
    ('0x2128A456A2D', '0X2128a456a2d', '2128A456A2D' hepsi ayni anahtar)."""
    s = str(v or "").strip()
    if s[:2].lower() == "0x":
        s = s[2:]
    return s.upper()


def _mat_metin(v):
    """Yaziciya giden bicim ('0x2128A456A2D'). outfit_core kimligi zaten
    int(mat_id, 16) ile okuyor, yani buyuk/kucuk harf farketmez."""
    return "0x" + _mat_anahtar(v)


# =============================================================== siniflandirma
def _kiyafet_png(gorece, tam, ad):
    """IC_*.png -> kiyafet dokusu ogesi (kendi export adimiz, guven 1.0)."""
    m = SLOT_RE.match(ad)
    if not m:
        return None
    mat = _mat_metin(m.group(1))
    slot = int(m.group(2))
    kayitlar = _slot_kayitlari(mat, slot)
    oge = {"tur": "kiyafet_doku", "yol": "outfit", "kaynak": gorece, "dosya": tam,
           "hedef": {"mat_id": mat, "slot_idx": slot},
           "guven": 1.0, "karar_gerekli": False, "adaylar": [], "kurulabilir": True,
           "_kayitlar": kayitlar}
    _yaz_aciklama(oge, {"t": "An outfit texture this tool made"})
    if not kayitlar:
        oge["kurulabilir"] = False
        oge["guven"] = 0.0
        _yaz_aciklama(oge, {"t": "An outfit texture, but not one this version of the "
                                 "tool knows how to install"})
        _yaz_sebep(oge, {"t": "the outfit part this file belongs to is not in this "
                              "tool's catalogue"})
        return oge
    if not kayitlar[0].get("duzenlenebilir"):
        oge["kurulabilir"] = False
        _yaz_sebep(oge, {"t": "this part of the outfit is locked - the game reads it "
                              "as a reference and painting it breaks the outfit"})
    return oge


def _kiyafet_atfet(ogeler):
    """Paylasilan dokulari PAKETIN baskin kiyafetine atfet, sonra metni yaz.

    Once yalnizca TEK kiyafete ait dosyalardan baskin kiyafeti bul; sonra
    paylasilanlari ona gore adlandir. Boylece Ezio paketindeki ortak doku
    "Ezio" der, alfabetik olarak once gelen baska bir kiyafet degil."""
    sayac = {}
    for o in ogeler:
        k = o.get("_kayitlar")
        if o["tur"] == "kiyafet_doku" and k and len(k) == 1:
            ad = k[0].get("kiyafet")
            sayac[ad] = sayac.get(ad, 0) + 1
    baskin = max(sayac, key=lambda a: (sayac[a], a)) if sayac else None

    for o in ogeler:
        kayitlar = o.pop("_kayitlar", None)
        if o["tur"] != "kiyafet_doku" or not kayitlar:
            continue
        kayit = _kayit_sec(kayitlar, baskin)
        o["hedef"] = dict(o["hedef"] or {})
        o["hedef"]["kiyafet"] = kayit.get("kiyafet")
        o["insan"] = {"kiyafet": kayit.get("gorunen_ad"),
                      "parca": _parca_duz(kayit.get("parca_adi"))}
        digerleri = sorted({k["gorunen_ad"] for k in kayitlar
                            if k["gorunen_ad"] != kayit.get("gorunen_ad")})
        # Kullanicinin BILMESI gereken sey: bu tek dosya baska kiyafetleri de
        # degistirir. Arac zaten bunu biliyordu (sharing_label), ama paket
        # akisinda hic soylenmiyordu. TEKIL ve COGUL ayri kaliptir.
        ek = "" if not digerleri else ("tek" if len(digerleri) == 1 else "cok")
        if digerleri:
            o["paylasilan"] = digerleri
        o["aciklama_kalip"] = _kiyafet_aciklama_kalip(kayit, ek, len(digerleri))
        o["aciklama"] = kalip_metin(o["aciklama_kalip"])
    return baskin


def _gemi_png(gorece, tam, ad, boyut):
    """<hedef_anahtari>.png -> gemi dokusu ogesi (ship_core.mod_tara ile ayni kural)."""
    kok = os.path.splitext(ad)[0]
    kat = _ship_katalog()
    h = kat.get(_alt(kok))
    if not h:
        aday = re.sub(r" \(\d+\)$", "", _alt(kok))       # 'Sails (2).png'
        h = kat.get(aday) or kat.get(re.sub(r"_\d+$", "", aday))
    if not h:
        return None
    ifade = _gemi_ifade(h)
    oge = {"tur": "gemi_doku", "yol": "ship", "kaynak": gorece, "dosya": tam,
           "hedef": {"anahtar": h["anahtar"], "kanal": h.get("kanal", "diffuse")},
           "guven": 1.0, "karar_gerekli": False,
           "adaylar": [], "kurulabilir": True,
           # `gemi_parca` ic gruplama anahtari; `gemi_ozet` + `gemi_ozet_kalip`
           # ise ozet satirinin duz ve cevrilebilir halleri (ikisi bir arada
           # durur: "X_kalip olan her alanin X ikizi var" kurali kapida olculur).
           "insan": {"gemi_parca": ifade,
                     "gemi_ozet": kalip_metin(_gemi_ozet_kalip(h)),
                     "gemi_ozet_kalip": _gemi_ozet_kalip(h)}}
    oge["aciklama_kalip"] = _gemi_aciklama_kalip(h)
    oge["aciklama"] = kalip_metin(oge["aciklama_kalip"])
    if boyut and (h.get("w"), h.get("h")) != boyut:
        # Ad tutuyor ama olcu tutmuyor: 'Empty'/'Assassin' gibi kisa anahtarlar
        # rastgele bir dosya adiyla da eslesebilir. Sessizce uygulamak yerine SOR.
        oge["guven"] = 0.55
        oge["karar_gerekli"] = True
        _yaz_sebep(oge, {"t": "the name matches a ship part but the picture is {0}x{1} "
                              "and the game wants {2}x{3}"},
                   boyut[0], boyut[1], h.get("w"), h.get("h"))
    return oge


def _png_boyut(tam):
    try:
        from PIL import Image
        with Image.open(tam) as im:
            return im.size
    except Exception:                                             # noqa: BLE001
        return None


def _dds_basligi(tam):
    """DDS basligini SADECE struct ile okur -> {W,H,aile,srgb,mip} ya da None.

    Bilerek bagimsiz: bu modul `outfit_core`/`doku_enjekte2` import etmez (kurulum
    eksikse paket ekrani yine de calismali). Piksel COZULMEZ, yalniz 148 bayt okunur."""
    import struct
    try:
        with open(tam, "rb") as f:
            d = f.read(148)
    except OSError:
        return None
    if len(d) < 128 or d[:4] != b"DDS ":
        return None
    H, W = struct.unpack_from("<I", d, 12)[0], struct.unpack_from("<I", d, 16)[0]
    mip = struct.unpack_from("<I", d, 28)[0]
    fc = d[84:88]
    if fc == b"DX10":
        if len(d) < 148:
            return None
        dxgi = struct.unpack_from("<I", d, 128)[0]
    else:
        dxgi = {b"DXT1": 71, b"DXT2": 74, b"DXT3": 74, b"DXT4": 77, b"DXT5": 77}.get(fc, 0)
    if dxgi not in DDS_DXGI or not W or not H:
        return None
    aile, srgb = DDS_DXGI[dxgi]
    return {"W": int(W), "H": int(H), "aile": aile, "srgb": int(srgb), "mip": int(mip)}


def _dds_hedefi(ad):
    """Dosya adindan (mat_id, slot) -- doku_enjekte2.ad_coz'un A/B/C bicimleri."""
    m = DDS_IC_RE.match(ad)
    if m:
        return _mat_metin(m.group(1)), int(m.group(2))
    m = DDS_MAT_RE.search(ad)
    if not m:
        return None, None
    s = DDS_SLOT_RE.search(ad)
    return _mat_metin(m.group(1)), (int(s.group(1)) if s else 0)


def _kiyafet_dds(gorece, tam, ad):
    """Topluluk .dds'i -> kiyafet dokusu ogesi (PNG ogesiyle AYNI sekil).

    DDS oyunun kendi blok bicimidir: slotun bicimi/boyutuyla ayniysa HIC yeniden
    kodlanmadan yazilir (kayipsiz). Farkliysa RED DEGIL: acilip slotun bicimine
    cevrilecegi SOYLENIR."""
    mat, slot = _dds_hedefi(ad)
    oge = {"tur": "kiyafet_doku", "yol": "outfit", "kaynak": gorece, "dosya": tam,
           "hedef": None, "guven": 0.0, "karar_gerekli": False, "adaylar": [],
           "kurulabilir": False}
    _yaz_aciklama(oge, {"t": "An outfit texture in the game's own DDS format"})
    if mat is None:
        _yaz_sebep(oge, {"t": "this DDS file does not say which part it belongs to"})
        return oge
    basli = _dds_basligi(tam)
    if basli is None:
        _yaz_sebep(oge, {"t": "this DDS file's header could not be read"})
        return oge
    if basli["aile"] not in DDS_YAZILABILIR:
        _yaz_sebep(oge, {"t": "this DDS file is saved as {0}; the game stores BC1, BC3 "
                              "and BC7 textures only"}, basli["aile"])
        return oge
    kayitlar = _slot_kayitlari(mat, slot)
    oge["hedef"] = {"mat_id": mat, "slot_idx": slot, "bicim": "dds",
                    "dds": {"W": basli["W"], "H": basli["H"], "aile": basli["aile"],
                            "srgb": basli["srgb"], "mip": basli["mip"]}}
    oge["_kayitlar"] = kayitlar
    if not kayitlar:
        _yaz_aciklama(oge, {"t": "An outfit texture, but not one this version of the "
                                 "tool knows how to install"})
        _yaz_sebep(oge, {"t": "the outfit part this file belongs to is not in this "
                              "tool's catalogue"})
        return oge
    if not kayitlar[0].get("duzenlenebilir"):
        _yaz_sebep(oge, {"t": "this part of the outfit is locked - the game reads it "
                              "as a reference and painting it breaks the outfit"})
        return oge
    oge["kurulabilir"] = True
    oge["guven"] = 1.0
    k0 = kayitlar[0]
    if (k0.get("W"), k0.get("H")) != (basli["W"], basli["H"]) \
            or (k0.get("aile") and k0["aile"] != basli["aile"]):
        oge["hedef"]["yeniden_kodla"] = True
        _yaz_aciklama(oge, {"t": "An outfit texture in DDS format; it will be converted "
                                 "to the format this part of the outfit uses"})
    else:
        _yaz_aciklama(oge, {"t": "An outfit texture in the game's own format; it goes in "
                                 "exactly as it is, with no quality loss"})
    return oge


def _mesh_oge(gorece, tam, ad, manifestler):
    """GLB/GLTF/FBX -> 3D ithalat ogesi. Hedef, YANINDAKI manifest.json'dan gelir."""
    klasor = os.path.dirname(tam)
    man = manifestler.get(os.path.normcase(klasor))
    oge = {"tur": "mesh", "yol": "mesh", "kaynak": gorece, "dosya": tam,
           "hedef": None, "guven": 0.0, "karar_gerekli": False, "adaylar": [],
           "kurulabilir": False}
    _yaz_aciklama(oge, {"t": "A 3D model file"})
    if _uzanti(ad) == ".fbx":
        _yaz_sebep(oge, {"t": "this tool imports .glb files; save the model as glTF "
                              "Binary (.glb) in Blender and try again"})
        return oge
    if not man:
        _yaz_sebep(oge, {"t": "a 3D model on its own does not say which part of the "
                              "game it replaces; it has to sit next to the "
                              "manifest.json that EXPORT 3D wrote"})
        oge["karar_gerekli"] = True
        return oge
    kendi = os.path.basename(str(man.get("glb") or ""))
    if kendi and os.path.normcase(ad) == os.path.normcase(kendi):
        _yaz_sebep(oge, {"t": "this is the untouched model EXPORT 3D wrote, not an "
                              "edited one"})
        return oge
    oge["hedef"] = {"anahtar": man.get("anahtar"), "klasor": klasor,
                    "manifest": os.path.join(klasor, "manifest.json")}
    oge["guven"] = 1.0
    oge["kurulabilir"] = True
    ad_ = man.get("gorunen_ad") or man.get("anahtar") or "a character or weapon"
    _yaz_aciklama(oge, {"t": "The shape of {0}"}, ad_)
    oge["insan"] = {"mesh": ad_}
    return oge


def _forge_oge(gorece, tam, ad):
    """Hazir patch_02 dosyasi. 'scimitar' imzasi olmayan dosya forge DEGILDIR."""
    oge = {"tur": "forge", "yol": "forge", "kaynak": gorece, "dosya": tam,
           "hedef": {"dosya_adi": os.path.basename(ad)},
           "guven": 1.0, "karar_gerekli": False, "adaylar": [], "kurulabilir": True}
    _yaz_aciklama(oge, {"t": "A ready-made patch that replaces a whole part of the game"})
    try:
        with open(tam, "rb") as f:
            bas = f.read(9)
        boyut = os.path.getsize(tam)
    except OSError as e:
        oge["kurulabilir"] = False
        oge["guven"] = 0.0
        _yaz_sebep(oge, {"t": "the file could not be read ({0})"}, str(e)[:80])
        return oge
    if not bas.startswith(b"scimitar"):
        oge["kurulabilir"] = False
        oge["guven"] = 0.0
        _yaz_sebep(oge, {"t": "the file is named .forge but does not carry a game "
                              "archive inside"})
        _yaz_aciklama(oge, {"t": "A file that claims to be a game patch but is not one"})
        return oge
    if boyut < 4096 or boyut > 2_000_000_000:
        oge["kurulabilir"] = False
        oge["guven"] = 0.0
        _yaz_sebep(oge, {"t": "the patch is {0} bytes, which is not a real patch size"},
                   boyut)
        return oge
    oge["hedef"]["boyut"] = boyut
    kok = os.path.basename(ad).lower()
    if "boot" in kok:
        _yaz_aciklama(oge, {"t": "A ready-made patch for characters, outfits and weapons"})
    elif "shared" in kok:
        _yaz_aciklama(oge, {"t": "A ready-made patch for shared world and ship parts"})
    return oge


# Nexus indirme adi: "<ad> <surum> <mod no> <surum> <tarih> <kod>". Surum IKI KEZ
# gecer; sikilastirilmis kalip (geri basvuru) ilk surumu de siler ("Black Beard
# 1.0 127 1.0 2026-..." -> "Black Beard"). Ilk surum tekrarlanmiyorsa ("Ezio 2
# 314 1 2026-...") eski gevsek kalip kullanilir ve "Ezio 2" KORUNUR -- adin
# parcasi olan bir sayi silinmez.
_NEXUS_SUSU_SIKI = re.compile(r"\s+([\d.]+)\s+\d+\s+\1\s+\d{4}-.*$")
_NEXUS_SUSU = re.compile(r"\s+\d+\s+[\d.]+\s+\d{4}-.*$")


def _nexus_susu_sil(ad):
    """'Captain Jack Sparrow 1.0 461 1.0 2026-08-28T12-01Z 4lqzqyC8y' -> 'Captain Jack Sparrow'.

    Nexus'un indirme adina ekledigi surum/kimlik/tarih kuyrugu. Hem paketin adi
    hem birlesik yamanin kaynak adlari ayni kuraldan gecer."""
    s = str(ad or "")
    t = _NEXUS_SUSU_SIKI.sub("", s)
    if t == s:
        t = _NEXUS_SUSU.sub("", s)
    return t.strip()


# --------------------------------------------------------------- birden fazla yama
_BIRLESIK_AD_YASAK = ("", ".", "..")


def _forge_kaynak_adi(oge, plan_ad, gorulen):
    """Birlesik yamanin bir kaynaginin KULLANICIYA gorunen adi.

    Nexus paketleri 'Sparrow/DataPC_boot_patch_02.forge' seklinde gelir: ad UST
    KLASORDUR. Ust klasor yoksa dosya govdesi; o da yamanin standart adiysa
    paketin adi. Ayni ad iki kez cikarsa ' (2)' eklenir -- ACMB modlari adiyla
    ayirt eder, ad benzersiz OLMAK ZORUNDA."""
    gorece = str(oge.get("kaynak") or "").replace("\\", "/")
    ust = os.path.basename(os.path.dirname(gorece))
    govde = os.path.splitext(os.path.basename(gorece))[0]
    if ust and ust not in _BIRLESIK_AD_YASAK:
        ad = _nexus_susu_sil(ust)
    elif govde and "patch_02" not in govde.lower() and "datapc" not in govde.lower():
        ad = _nexus_susu_sil(govde)
    else:
        ad = plan_ad or "patch"
    ad = ad or "patch"
    taban, n = ad, 2
    while ad in gorulen:
        ad = "%s (%d)" % (taban, n)
        n += 1
    gorulen.add(ad)
    return ad


def _forge_birlesik_adaylari(ogeler):
    """Birlestirmeye girecek hazir yamalar: kurulabilir + boot yuvasi.

    Adinda "shared" gecen yama BASKA bir yuvaya (DataPC_shared_00_patch_02) gider;
    ACMB yalniz boot patch_02'yi birlestirir, Workshop'un yazicisi da yalniz o
    yuvayi yazar. O yuzden disarida kalir."""
    return [o for o in ogeler
            if o.get("tur") == "forge" and o.get("kurulabilir")
            and "shared" not in os.path.basename(str(o.get("kaynak") or "")).lower()]


def _forge_birlesik_ekle(ogeler, uyarilar, plan_ad):
    """>=2 boot yamasi varsa TEK 'forge_birlesik' ogesi uret (YAZMAZ).

    Kaynak ogeler listede kalir ve `birlesik_icinde=True` ile isaretlenir. Motor
    yoksa / plan cikmazsa oge uretilmez, uyari yazilir, eski yol surer."""
    adaylar = _forge_birlesik_adaylari(ogeler)
    if len(adaylar) < 2:
        return None
    try:
        import mod_birlestir as MB
    except Exception as e:                                        # noqa: BLE001
        uyarilar.append(_k({"t": "This package holds {0} ready-made patches, but the "
                                 "part of the Workshop that combines patches is "
                                 "missing ({1}); they can only be installed one at a "
                                 "time."}, len(adaylar), str(e)[:100]))
        return None
    gorulen = set()
    kaynaklar = []
    for o in adaylar:
        kaynaklar.append({"dosya": o["dosya"], "kaynak": o["kaynak"],
                          "ad": _forge_kaynak_adi(o, plan_ad, gorulen)})
    try:
        plan = MB.birlestir_plani(kaynaklar)
    except Exception as e:                                        # noqa: BLE001
        plan = {"ok": False, "mesaj": str(e)[:200]}
    if not plan.get("ok"):
        uyarilar.append(_k({"t": "This package holds {0} ready-made patches that could "
                                 "not be combined into one: {1}"},
                           len(adaylar), plan.get("mesaj") or "unknown reason"))
        return None
    adlar = [k["ad"] for k in kaynaklar]
    oge = {"tur": "forge_birlesik", "yol": "forge_birlesik",
           "kaynak": " + ".join(adlar), "dosya": None,
           "hedef": {"dosya_adi": MB.YAMA_ADI, "kaynaklar": [k["kaynak"] for k in kaynaklar]},
           "guven": 1.0, "karar_gerekli": False, "adaylar": [], "kurulabilir": True,
           "kaynaklar": kaynaklar, "plan": plan,
           "insan": {"birlesik": adlar}}
    _yaz_aciklama(oge, _OZET_FORGE_BIRLESIK, len(adlar), " + ".join(adlar))
    for o in adaylar:
        o["birlesik_icinde"] = True
        _yaz_sebep(o, {"t": "installed as part of the combined patch"})
    if plan.get("catisan_gidler"):
        kazananlar = []
        for c in plan["catisan_gidler"]:
            if c.get("kazanan") and c["kazanan"] not in kazananlar:
                kazananlar.append(c["kazanan"])
        # SONUNCU KAZANIR kurali kullaniciya ACIKCA soylenir; teknik kimlik
        # (gid) `plan` icinde durur, cumleye girmez.
        oge["uyari_kalip"] = _k({"t": "{0} part(s) of the game are changed by more than "
                                      "one of these patches. Where that happens the "
                                      "patch listed last wins ({1}), and the other "
                                      "patch's change to that part is lost."},
                                len(plan["catisan_gidler"]), ", ".join(kazananlar))
        oge["uyari"] = kalip_metin(oge["uyari_kalip"])
        uyarilar.append(oge["uyari_kalip"])
    ogeler.append(oge)
    return oge


def _icerik_esle(oge_yollari, uyarilar):
    """Adi hicbir seye benzemeyen PNG'leri ICERIKTEN esle (eslestir.png_eslestir).

    Bu, "PICK PNG FILES" akisinin motorudur; burada yalniz esik degisir:
    %90 ustu SORULMAZ."""
    if not oge_yollari:
        return {}
    try:
        import eslestir as ES
    except Exception as e:                                        # noqa: BLE001
        uyarilar.append(_k({"t": "Some pictures could not be matched by their "
                                 "content ({0})."}, str(e)[:120]))
        return {}
    out = {}
    for tam in oge_yollari:
        try:
            e = ES.png_eslestir(tam)
        except Exception:                                         # noqa: BLE001
            continue
        out[os.path.normcase(tam)] = e
    return out


def _aday_listesi(eslesme, baskin=None):
    """eslestir adaylarini DUZ DILLE, tek satirlik seceneklere cevir."""
    duz = []
    goruldu = set()
    for g in eslesme.aday_listesi or []:
        for s in g["slotlar"]:
            if not s.get("duzenlenebilir"):
                continue
            anahtar = (_mat_anahtar(s["mat_id"]), int(s["slot_idx"]))
            if anahtar in goruldu:
                continue
            goruldu.add(anahtar)
            kayit = _kayit_sec(_slot_kayitlari(*anahtar), baskin) or {
                "gorunen_ad": s.get("gorunen_ad") or s.get("kiyafet"),
                "parca_adi": s.get("parca_adi"), "rol": s.get("rol")}
            duz.append({"hedef": {"mat_id": _mat_metin(anahtar[0]),
                                  "slot_idx": anahtar[1]},
                        "metin": _kiyafet_aciklama(kayit),
                        # secenek satiri (kullaniciya SORULAN liste) ve "buna
                        # benziyor" cumlesi AYRI kaliplardir; ikisi de burada
                        # kurulur, cunku kaydi yalniz burasi gorur.
                        "metin_kalip": _kiyafet_aciklama_kalip(kayit),
                        "benzer_kalip": _kiyafet_aciklama_kalip(kayit, "benzer"),
                        "guven": round(float(g["skor"]), 4)})
    duz.sort(key=lambda x: -x["guven"])
    return duz[:6]


# =============================================================== manifest / ad
def _mod_json_oku(kok, uyarilar):
    """Paketteki mod.json (varsa). Bozuksa COKMEZ: uyari verir, None doner."""
    adaylar = []
    for kalip in ("mod.json", "Mod.json", "MOD.json"):
        adaylar.append(os.path.join(kok, kalip))
    adaylar += sorted(glob.glob(os.path.join(kok, "*", "mod.json")))
    for p in adaylar:
        if not os.path.isfile(p):
            continue
        try:
            with open(p, encoding="utf-8-sig") as f:
                d = json.load(f)
        except Exception as e:                                    # noqa: BLE001
            uyarilar.append(_k({"t": "The package has a mod.json but it could not be "
                                     "read ({0}); the mod was read from its files "
                                     "instead."}, str(e)[:100]))
            return None
        if not isinstance(d, dict):
            uyarilar.append(_k({"t": "The package has a mod.json but it is not in the "
                                     "expected shape; the mod was read from its files "
                                     "instead."}))
            return None
        return d
    return None


def _readme_adi(kok):
    """README'den mod adi. Outfit Workshop export README'sinin ilk satiri:
       'OUTFIT WORKSHOP export -- Captain Morgan's Redingote (U_Edward_Morgan)'"""
    for p in sorted(glob.glob(os.path.join(kok, "**", "README*.txt"), recursive=True))[:4]:
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                ilk = f.readline().strip()
        except OSError:
            continue
        m = re.search(r"export\s*--\s*(.+?)\s*\(", ilk)
        if m:
            return m.group(1)
    return None


def _manifestleri_topla(kok):
    """3D export manifest.json'lari: klasor(normcase) -> manifest sozlugu."""
    out = {}
    for p in glob.glob(os.path.join(kok, "**", "manifest.json"), recursive=True):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception:                                         # noqa: BLE001
            continue
        if isinstance(d, dict) and d.get("anahtar"):
            out[os.path.normcase(os.path.dirname(p))] = d
    return out


# =============================================================== ozet
# Kiyafet ozet satiri: parca sayisina gore AYRI kalip. Neden liste degil de dort
# ayri cerceve: bir dizeyi ", " ile birlestirip tek arguman yapmak, o listeyi
# CEVIRI ICIN TEK PARCA yapardi ("dress, hood, tunic" sozlukte anahtar olamaz).
# Her parca AYRI arguman olunca arayuz her birini tek tek cevirebilir.
# Dort ve ustu icin ad yerine SAYI yazilir (zaten oyle calisiyordu), o da ayri
# kaliptir; 4'ten kucuk olamayacagi icin tekil hali YOKTUR.
_OZET_KIYAFET_KALIP = {
    1: {"t": "Changes {0} ({1})"},
    2: {"t": "Changes {0} ({1}, {2})"},
    3: {"t": "Changes {0} ({1}, {2}, {3})"},
}
_OZET_KIYAFET_SAYI = {"t": "Changes {0} ({1} parts)"}
_OZET_MESH = {"t": "Changes the shape of {0}"}
# TEKIL ve COGUL ayri kalip (Ingilizce'nin "es" eki kaliba GOMULMEZ).
_OZET_FORGE_TEK = {"t": "Installs {0} ready-made game patch"}
_OZET_FORGE_COK = {"t": "Installs {0} ready-made game patches"}
# Birlesik yama: sayi + adlar (' + ' ile birlesik; adlar cevrilmez).
_OZET_FORGE_BIRLESIK = {"t": "Combines {0} ready-made patches into one ({1})"}


def _ozet_kalip(ogeler):
    """Kullaniciya gorunen INSAN CUMLELERI -- KALIP + ARGUMAN olarak.

    Teknik kimlik ICERMEZ; kimlik yalnizca `hedef` icinde durur."""
    kiyafet = {}        # gorunen_ad -> set(parca)
    gemi = {}           # cumle(anahtar) -> kalip
    mesh = []
    forge = 0
    birlesik = []       # [[ad, ad, ...]] birlesik yama basina
    for o in ogeler:
        if not o.get("kurulabilir"):
            continue
        ins = o.get("insan") or {}
        if o["tur"] == "kiyafet_doku" and ins.get("kiyafet"):
            kiyafet.setdefault(ins["kiyafet"], set()).add(ins.get("parca") or "part")
        elif o["tur"] == "gemi_doku" and ins.get("gemi_ozet_kalip"):
            # Anahtar KALIBIN DOLDURULMUS HALI: ayni gemi parcasini iki dosya
            # tasiyorsa satir bir kez cikar. (Anahtar olarak `gemi_parca` dizesini
            # kullanmak, kalibi olmayan bir ogede BOS satir uretirdi -- olculdu.)
            gemi[kalip_metin(ins["gemi_ozet_kalip"])] = ins["gemi_ozet_kalip"]
        elif o["tur"] == "mesh" and ins.get("mesh"):
            mesh.append(ins["mesh"])
        elif o["tur"] == "forge":
            # Birlesik yamaya giren yama AYRICA sayilmaz: "Installs 2 patches" +
            # "Combines 2 patches" yan yana celisik okunurdu.
            if not o.get("birlesik_icinde"):
                forge += 1
        elif o["tur"] == "forge_birlesik" and ins.get("birlesik"):
            birlesik.append(list(ins["birlesik"]))
    satirlar = []
    for ad in sorted(kiyafet):
        parcalar = sorted(kiyafet[ad])
        if len(parcalar) > 3:
            satirlar.append(_k(_OZET_KIYAFET_SAYI, ad, len(parcalar)))
        else:
            satirlar.append(_k(_OZET_KIYAFET_KALIP[len(parcalar)], ad, *parcalar))
    for ifade in sorted(gemi):
        satirlar.append(gemi[ifade])
    for ad in sorted(set(mesh)):
        satirlar.append(_k(_OZET_MESH, ad))
    if forge:
        satirlar.append(_k(_OZET_FORGE_COK if forge > 1 else _OZET_FORGE_TEK, forge))
    for adlar in birlesik:
        satirlar.append(_k(_OZET_FORGE_BIRLESIK, len(adlar), " + ".join(adlar)))
    return satirlar


def _ozet(ogeler):
    """Ayni cumleler, DUZ metin (eski cagiranlar icin -- kaliptan doldurulur)."""
    return kaliplar_metin(_ozet_kalip(ogeler))


def _bos_paket_mesaji(dosyalar, tanimayan):
    """Kurulabilir is cikmayan paket icin CIKISI OLAN cumle (KALIP doner).

    Eski hali "Nothing in this package can be installed by this tool." idi ve orada
    bitiyordu: kullanici yanlis dosyayi mi birakti, arac mi yetersiz, ne yapmali --
    hicbiri yazmiyordu. Uc durum ayrilir cunku yapilacak sey ucunde de FARKLI.
    """
    if not dosyalar:
        return _k({"t": "That folder is empty, so there was nothing to install. If the "
                        "mod is still in a .zip or .rar, drop the archive itself "
                        "instead of unpacking it."})
    if tanimayan and len(tanimayan) >= len(dosyalar):
        return _k({"t": "None of the files in this package are ones this tool can put "
                        "into the game. It installs textures (.png), 3D models (.glb) "
                        "and ready-made patches (.forge). If this mod came with its "
                        "own instructions, it probably has to be installed by hand."})
    return _k({"t": "Nothing in this package can be installed by this tool. Press Show "
                    "details to see what was found and why each file was left out."})


def _tur_karar(ogeler):
    # Birlesik yamanin kaynak ogeleri turu belirlemez: iki yamali paket "karma"
    # degil "forge_birlesik"tir.
    turler = ({o["tur"] for o in ogeler if o.get("kurulabilir") and not o.get("birlesik_icinde")}
              or {o["tur"] for o in ogeler})
    if not turler:
        return "bos"
    if len(turler) > 1:
        return "karma"
    return turler.pop()


# =============================================================== ANA GIRIS
def coz(yol, gecici_kok=None, icerik_esle=True):
    """Kullanicinin biraktigi seyi KURULUM PLANINA cevir.

    yol: dosya yolu, klasor yolu ya da yol listesi (coklu PNG secimi).
    Doner: plan sozlugu (asagidaki bicimde). ASLA istisna firlatmaz; basarisiz
    durum {"ok": False, "mesaj": ...} olarak doner."""
    uyarilar = []
    gecici = None
    ad_ipucu = None

    # --- 1) girisi normalize et: her durumda bir "paket koku" + dosya listesi
    if isinstance(yol, (list, tuple)):
        yollar = [os.path.abspath(p) for p in yol]
        if not yollar:
            return _bos({"t": "nothing was picked"})
        eksik = [p for p in yollar if not os.path.exists(p)]
        if eksik:
            return _bos(_k({"t": "this file is not there any more: {0}"},
                           os.path.basename(eksik[0])))
        if len(yollar) == 1:
            return coz(yollar[0], gecici_kok, icerik_esle)
        try:
            kok = os.path.commonpath([os.path.dirname(p) for p in yollar])
            dosyalar = [(os.path.relpath(p, kok).replace("\\", "/"), p) for p in yollar]
        except ValueError:              # farkli suruculerden secim
            kok = os.path.dirname(yollar[0])
            dosyalar = [(os.path.basename(p), p) for p in yollar]
        ad_ipucu = os.path.basename(kok) or "Picked files"
    else:
        yol = os.path.abspath(str(yol))
        if not os.path.exists(yol):
            return _bos({"t": "that file or folder is not there"})
        if os.path.isdir(yol):
            kok = _tek_kok_duzle(yol)
            dosyalar = _agac(kok)
            ad_ipucu = os.path.basename(os.path.normpath(yol))
        elif _uzanti(yol) in ARSIV_UZANTI:
            gecici = tempfile.mkdtemp(prefix="ModPaket_", dir=gecici_kok)
            ok, sebep = _ac(yol, os.path.join(gecici, "icerik"))
            if not ok:
                shutil.rmtree(gecici, ignore_errors=True)
                return _bos(sebep)
            kok = _tek_kok_duzle(os.path.join(gecici, "icerik"))
            dosyalar = _agac(kok)
            ad_ipucu = _nexus_susu_sil(os.path.splitext(os.path.basename(yol))[0])
        else:
            kok = os.path.dirname(yol)
            dosyalar = [(os.path.basename(yol), yol)]
            ad_ipucu = os.path.splitext(os.path.basename(yol))[0]

    try:
        plan = _plan_kur(kok, dosyalar, uyarilar, ad_ipucu, icerik_esle)
    except Exception as e:                                        # noqa: BLE001
        if gecici:
            shutil.rmtree(gecici, ignore_errors=True)
        return _bos(_k({"t": "the package could not be read ({0})"}, str(e)[:150]))
    plan["gecici_kok"] = gecici
    plan["kok"] = kok
    return plan


def _bos(mesaj):
    """Kurulacak is cikmayan plan.

    `mesaj` KALIP ({"t": ...}) ya da duz dizedir. Duz dize gelen tek yol arsiv
    acma hatalaridir (`_ac` / `_girisleri_denetle` sebepleri); onlar bugun
    cevrilemez ve `mesaj_kalip` None doner -- arayuz o durumda Ingilizce metni
    gosterir (bugunku davranisin AYNISI, sessiz bir gerileme YOK)."""
    return {"ok": False, "kurulabilir_var": False,
            "mesaj": kalip_metin(mesaj),
            "mesaj_kalip": mesaj if isinstance(mesaj, dict) else None,
            "tur": "bos",
            "ad": None, "yazar": None, "notlar": None, "ogeler": [], "ozet": [],
            "ozet_kalip": [], "uyarilar_kalip": [],
            "tanimayan": [], "atlanan": [], "uyarilar": [], "cakisan": [],
            "manifest": None, "gecici_kok": None, "kok": None,
            "sayi": {"toplam": 0, "kurulabilir": 0, "karar_gerekli": 0,
                     "kurulamaz": 0, "tanimayan": 0, "atlanan": 0}}


def _sessiz_sebep(uz):
    """Modun yanindaki 'ek' dosyalar: neden kurulmadigini adiyla soyle (KALIP)."""
    if uz in (".txt", ".md", ".nfo", ".html", ".htm", ".pdf", ".url", ".log"):
        return {"t": "it is the mod's own note or read-me, not a game file"}
    if uz == ".json":
        return {"t": "it is a settings file that came with the mod, not a game file"}
    if uz == ".ini":
        return {"t": "it is a settings file, not a game file"}
    return {"t": "it is a preview picture in a format the game does not use "
                 "(the game reads PNG)"}


def _agac(kok):
    """[(gorece_yol, tam_yol)] -- gizli dosyalar haric, siralanmis.

    Gizli dosyalar (`.orijinal_sha.json` gibi) aracin kendi defteridir; hicbir
    kovaya girmez, bu yuzden `sayi.toplam` da onlari saymaz -- korunum yasasi
    (test kapisi 9) bu SUZULMUS liste uzerinde tutar."""
    out = []
    for dizin, altlar, dosyalar in os.walk(kok):
        altlar[:] = [a for a in altlar if not a.startswith(".")]
        for f in dosyalar:
            if f.startswith("."):
                continue
            tam = os.path.join(dizin, f)
            out.append((os.path.relpath(tam, kok).replace("\\", "/"), tam))
    out.sort()
    return out


def _arac_paketi_mi(dosyalar):
    """Kullanici modu degil, ARACIN KENDI kurulum paketini birakmis olabilir.

    Olculdu: Workshop'un surum zip'i 2.000+ PNG tasiyor ve 16'si gemi hedef
    anahtariyla ADLANDIRILMIS sablon; hicbir kapi bunu yakalamiyordu, arac
    kendi kurulum paketini "mod" diye gostermeye hazirdi."""
    adlar = {os.path.basename(_alt(g)) for g, _t in dosyalar}
    vurus = adlar & set(ARAC_IMZASI)
    return sorted(vurus) if len(vurus) >= 2 else []


def _plan_kur(kok, dosyalar, uyarilar, ad_ipucu, icerik_esle):
    arac = _arac_paketi_mi(dosyalar)
    if arac:
        p = _bos({"t": "This is the Workshop program itself, not a mod. To move to a "
                       "new version use the update button on the Workshop's own "
                       "screen."})
        p["tur"] = "arac_paketi"
        p["ad"] = ad_ipucu
        p["sayi"]["toplam"] = len(dosyalar)
        p["uyarilar_kalip"] = [_k({"t": "Recognised by the files {0}."},
                                  ", ".join(arac))]
        p["uyarilar"] = kaliplar_metin(p["uyarilar_kalip"])
        return p
    ogeler, tanimayan, atlanan = [], [], []
    manifestler = _manifestleri_topla(kok)
    icerik_adaylari = []

    for gorece, tam in dosyalar:
        ad = os.path.basename(gorece)
        uz = _uzanti(ad)

        if _atlanan_yol_mu(gorece):
            atlanan.append(_kayit(gorece,
                                  {"t": "it sits in a folder the designer kept as a "
                                        "backup of the untouched game files"}))
            continue

        if uz in FORGE_UZANTI:
            ogeler.append(_forge_oge(gorece, tam, ad))
            continue

        if uz in MESH_UZANTI:
            ogeler.append(_mesh_oge(gorece, tam, ad, manifestler))
            continue

        if uz in SES_UZANTI:
            o = {"tur": "ses", "yol": "ses", "kaynak": gorece, "dosya": tam,
                 "hedef": None, "guven": 0.0, "karar_gerekli": False,
                 "adaylar": [], "kurulabilir": False}
            _yaz_aciklama(o, {"t": "A sound file"})
            _yaz_sebep(o, {"t": "this tool can swap sounds that are already in the "
                                "game, but it cannot put a sound file from a package "
                                "into the game yet"})
            ogeler.append(o)
            continue

        if uz in DDS_UZANTI:
            ogeler.append(_kiyafet_dds(gorece, tam, ad))
            continue

        if uz in DOKU_UZANTI:
            oge = _kiyafet_png(gorece, tam, ad)
            if oge is not None:
                ogeler.append(oge)
                continue
            oge = _gemi_png(gorece, tam, ad, _png_boyut(tam))
            if oge is not None:
                ogeler.append(oge)
                continue
            icerik_adaylari.append((gorece, tam))
            continue

        if uz in SESSIZ_UZANTI:
            atlanan.append(_kayit(gorece, _sessiz_sebep(uz)))
            continue

        tanimayan.append(_kayit(gorece,
                                {"t": "this tool does not know what a {0} file "
                                      "replaces in the game"},
                                uz.lstrip(".") or "nameless"))

    # --- adi tanidik olmayan PNG'ler: ICERIKTEN esle
    if icerik_adaylari:
        cok_fazla = len(icerik_adaylari) > EN_COK_ICERIK
        if cok_fazla:
            # sayi daima EN_COK_ICERIK'ten (200) buyuktur -> tekil hali YOK.
            uyarilar.append(_k(
                {"t": "This package holds {0} pictures whose names say nothing, which "
                      "is too many to look at one by one; they were left alone."},
                len(icerik_adaylari)))
        if icerik_esle and not cok_fazla:
            eslesmeler = _icerik_esle([t for _g, t in icerik_adaylari], uyarilar)
        else:
            eslesmeler = {}
        for gorece, tam in icerik_adaylari:
            e = eslesmeler.get(os.path.normcase(tam))
            if e is None or e.durum in ("okunamadi", "eslesme_yok"):
                if e is not None and e.durum == "eslesme_yok":
                    sebep = {"t": "the picture does not look like any texture in the "
                                  "game, and its name does not say where it belongs"}
                elif e is not None and e.durum == "okunamadi":
                    sebep = {"t": "the picture could not be read"}
                elif cok_fazla:
                    sebep = {"t": "its name does not say where it belongs, and this "
                                  "package has too many such pictures to compare one "
                                  "by one"}
                else:
                    sebep = {"t": "its name does not say where it belongs"}
                tanimayan.append(_kayit(gorece, sebep))
                continue
            adaylar = _aday_listesi(e)
            if not adaylar:
                tanimayan.append(_kayit(gorece,
                                        {"t": "the picture looks like a part of the "
                                              "game that cannot be painted"}))
                continue
            en_iyi = adaylar[0]
            oto = e.durum == "otomatik" and en_iyi["guven"] >= ESIK_OTOMATIK
            yeni = {
                "tur": "kiyafet_doku", "yol": "outfit", "kaynak": gorece, "dosya": tam,
                "hedef": en_iyi["hedef"] if oto else None,
                # oto ise metin ASAGIDA `_kiyafet_atfet` tarafindan yeniden yazilir
                # (paylasilan doku paketin baskin kiyafetiyle adlandirilmali);
                # oto degilse "buna benziyor" cercevesi kullanilir.
                "aciklama_kalip": en_iyi["metin_kalip"] if oto else
                                  en_iyi["benzer_kalip"],
                "guven": round(float(e.guven), 4),
                "karar_gerekli": not oto,
                "adaylar": adaylar,
                "kurulabilir": True,
                "soru": None, "soru_kalip": None}
            yeni["aciklama"] = kalip_metin(yeni["aciklama_kalip"])
            if not oto:
                _yaz_soru(yeni, {"t": "Which part of the game should this picture "
                                      "replace?"})
            if oto:
                # atif (hangi kiyafet) toplu pasa birakilir: paylasilan doku,
                # paketin baskin kiyafetiyle adlandirilmali
                yeni["_kayitlar"] = _slot_kayitlari(en_iyi["hedef"]["mat_id"],
                                                    en_iyi["hedef"]["slot_idx"])
            ogeler.append(yeni)

    # --- paylasilan dokulari paketin baskin kiyafetine atfet ve metinleri yaz
    _kiyafet_atfet(ogeler)

    # --- birden fazla boot yamasi: TEK birlesik ogede topla (yazmaz; ACMB on-raporu)
    _forge_birlesik_ekle(ogeler, uyarilar,
                         _nexus_susu_sil(ad_ipucu) if ad_ipucu else None)

    # --- ayni hedefe iki dosya: kullanici uyarilmali (sessizce biri kazanmasin)
    cakisan = []
    goruldu = {}
    for o in ogeler:
        if not o.get("kurulabilir") or not o.get("hedef"):
            continue
        anahtar = (o["tur"], json.dumps(o["hedef"], sort_keys=True, default=str))
        if anahtar in goruldu:
            cakisan.append({"a": goruldu[anahtar], "b": o["kaynak"],
                            "aciklama": o.get("aciklama"),
                            "aciklama_kalip": o.get("aciklama_kalip")})
            o["cakisiyor"] = goruldu[anahtar]
        else:
            goruldu[anahtar] = o["kaynak"]
    if cakisan:
        # TEKIL/COGUL AYRI kalip. Yan fayda: eski tek kalip tekilde bozuk
        # Ingilizce uretiyordu ("1 file ... change the same thing").
        if len(cakisan) == 1:
            uyarilar.append(_k({"t": "1 file in this package changes the same thing as "
                                     "another one; only one of them can win."}))
        else:
            uyarilar.append(_k({"t": "{0} files in this package change the same thing; "
                                     "only one of them can win."}, len(cakisan)))

    # --- manifest / ad / yazar
    man = _mod_json_oku(kok, uyarilar)
    ad = None
    yazar = None
    notlar = None
    if man:
        ad = man.get("ad") or man.get("name") or man.get("title")
        yazar = man.get("yazar") or man.get("author") or man.get("by")
        notlar = man.get("notlar") or man.get("notes") or man.get("description")
        for alan, deger in (("ad", ad), ("yazar", yazar), ("notlar", notlar)):
            if deger is not None and not isinstance(deger, str):
                uyarilar.append(_k({"t": "The package's mod.json has an unexpected "
                                         "value for '{0}'; it was ignored."}, alan))
                if alan == "ad":
                    ad = None
                elif alan == "yazar":
                    yazar = None
                else:
                    notlar = None
    # AD SIRASI (2026-09-07'de duzeltildi). Eskiden README ikinci siradaydi ve
    # OLCULDU: "Admiral Edward Kenway.rar" ekranda "Captain Morgan's Redingote"
    # goruntuyordu. Sebep yapisal -- `_readme_adi` bir Outfit Workshop EXPORT
    # README'sinden okur ve o satir MODUN degil, disa aktarilan KIYAFETIN adidir;
    # zaten ozet satiri ("Changes Captain Morgan's Redingote ...") onu soyluyor.
    # Kullanici indirdigi dosyanin adini gormeli, yoksa dogru modu birakip
    # birakmadigindan emin olamaz.
    #   1) mod.json'daki ad  -> mod yapicisinin KENDI beyani
    #   2) arsiv/klasor adi  -> kullanicinin gordugu ad (Nexus suslemesi temizlenir)
    #   3) README ilk satiri -> son care
    ad = ad or ad_ipucu or _readme_adi(kok) or "Mod"

    kurulabilir = [o for o in ogeler if o.get("kurulabilir")]
    kurulamayan = [o for o in ogeler if not o.get("kurulabilir")]
    if kurulamayan:
        # "the list says why for each one" -- ILK EKRANDA oyle bir liste YOK; sebepler
        # "Show details" arkasindaki panelde duruyor. Kullaniciyi oraya YOLLA (denetim
        # bulgusu: mukemmel yazilmis dort sebep kimsenin gormedigi yerde duruyordu).
        if len(kurulamayan) == 1:
            uyarilar.append(_k({"t": "1 file in this package cannot be installed; "
                                     "press Show details to see why."}))
        else:
            uyarilar.append(_k({"t": "{0} files in this package cannot be installed; "
                                     "press Show details to see why for each one."},
                               len(kurulamayan)))
    if tanimayan:
        if len(tanimayan) == 1:
            uyarilar.append(_k({"t": "1 file in this package was not recognised."}))
        else:
            uyarilar.append(_k({"t": "{0} files in this package were not recognised."},
                               len(tanimayan)))

    ozet_kalip = _ozet_kalip(ogeler)
    ozet = kaliplar_metin(ozet_kalip)
    sizan = [c for c in ozet if TEKNIK_RE.search(c)]
    if sizan:
        # kendi kendini denetleme: duz dil sozlugunden kacan bir ad olursa
        # kullaniciya teknik metin GOSTERILMEZ, sorun gorunur olur. Kalip listesi
        # de AYNI satirlari atar; yoksa arayuz elenen cumleyi cevirip gosterirdi.
        tut = [i for i, c in enumerate(ozet) if c not in sizan]
        ozet_kalip = [ozet_kalip[i] for i in tut]
        ozet = [ozet[i] for i in tut]
        uyarilar.append(_k({"t": "Some parts of this mod could not be described in "
                                 "plain words."}))

    # `ok` = paket OKUNDU demektir (kurulabilir is cikmasi ayri bir sorudur;
    # `kurulabilir_var` onu soyler). Ikisini karistirmak arayuze "paket bozuk"
    # dedirtirdi -- oysa paket saglam, sadece bu araca ait degil.
    # Cikissiz cumle birakma: kullanici NE YAPACAGINI bilmeli. Eskiden yalniz
    # "Nothing in this package can be installed by this tool." deniyordu ve orada
    # bitiyordu (denetim bulgusu).
    mesaj_kalip = None if kurulabilir else _bos_paket_mesaji(dosyalar, tanimayan)
    return {"ok": True,
            "kurulabilir_var": bool(kurulabilir),
            "mesaj": kalip_metin(mesaj_kalip) if mesaj_kalip else "",
            "mesaj_kalip": mesaj_kalip,
            "tur": _tur_karar(ogeler), "ad": ad, "yazar": yazar, "notlar": notlar,
            "ogeler": ogeler, "ozet": ozet, "ozet_kalip": ozet_kalip,
            "tanimayan": tanimayan,
            "atlanan": atlanan,
            "uyarilar": kaliplar_metin(uyarilar), "uyarilar_kalip": list(uyarilar),
            "cakisan": cakisan,
            "manifest": man,
            # `kurulabilir` DOSYA sayar: birlesik yama ogesi bir dosya degil, iki
            # dosyanin ustundeki sarmalayicidir; sayilsaydi 2 dosyali paket
            # "3 kurulabilir" derdi.
            "sayi": {"toplam": len(dosyalar),
                     "kurulabilir": len([o for o in kurulabilir
                                         if o.get("tur") != "forge_birlesik"]),
                     "karar_gerekli": sum(1 for o in kurulabilir if o["karar_gerekli"]),
                     "kurulamaz": len(kurulamayan), "tanimayan": len(tanimayan),
                     "atlanan": len(atlanan)}}


# =============================================================== temizlik
def temizle(plan):
    """coz()'un actigi gecici klasoru sil. Plan yoksa/actigimiz klasor yoksa sessiz."""
    if not isinstance(plan, dict):
        return False
    g = plan.get("gecici_kok")
    if not g or not os.path.isdir(g):
        return False
    shutil.rmtree(g, ignore_errors=True)
    plan["gecici_kok"] = None
    return True


@contextlib.contextmanager
def acilmis(yol, **kw):
    """with acilmis(yol) as plan:  ...  -> cikista gecici klasor SILINIR."""
    plan = coz(yol, **kw)
    try:
        yield plan
    finally:
        temizle(plan)


# =============================================================== elle deneme
if __name__ == "__main__":
    hedef = sys.argv[1] if len(sys.argv) > 1 else "."
    with acilmis(hedef) as p:
        print("ok=%s  tur=%s  ad=%s" % (p["ok"], p["tur"], p["ad"]))
        if p.get("mesaj"):
            print("   ", p["mesaj"])
        for c in p["ozet"]:
            print("  *", c)
        print("  sayi:", p["sayi"])
        for o in p["ogeler"][:40]:
            bayrak = "OK " if o["kurulabilir"] else "no "
            if o.get("karar_gerekli"):
                bayrak = "ASK"
            print("   %s %-14s %.2f  %s  <- %s" % (bayrak, o["tur"], o["guven"],
                                                   o["aciklama"], o["kaynak"][:60]))
            if o.get("sebep"):
                print("        %s" % o["sebep"])
        for t in p["tanimayan"][:10]:
            print("   ??  %s  (%s)" % (t["kaynak"][:60], t["sebep"]))
        for u in p["uyarilar"]:
            print("   !   %s" % u)
