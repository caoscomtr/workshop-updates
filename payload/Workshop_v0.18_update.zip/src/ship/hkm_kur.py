# -*- coding: utf-8 -*-
"""HKM kurucu — Strateji A (yeni patch forge dosyasi) icin ORTAK kurulum/kaldirma.

Tasarim kurallari (MOD_ALTYAPISI 3.1'den):
  #1  Yazmadan once dogrula; dogrulama basarisizsa TEK BAYT yazma.
  #5  Kayit oyun/kurulum klasorunde DEGIL, %LOCALAPPDATA%\\ACBFR_Modding\\ altinda.
  #7  Basarisizlikta kaydi SILME.
  #10 README'de "Steam dosya butunlugunu dogrula" ONERME.

Bu strateji hicbir vanilla forge'a dokunmaz: yalnizca YENI bir dosya kopyalar.
Geri alma = o dosyayi silmek. Bu yuzden TOC/kayit kirilganligi (B1/B2/B3 kusur ailesi)
bu yolda YAPISAL OLARAK yoktur.
"""
import os, sys, json, shutil, hashlib, tempfile, time

OYUN_VARSAYILAN = r"C:\Program Files (x86)\Steam\steamapps\common\Assassin's Creed Black Flag Resynced"


def _veri_kok():
    """Kurulum kayitlarinin koku. **ASLA TEMP'e dusmez.**

    🔴 2026-07-31 (Ship Workshop'ta CANLI yasandi, birebir yeniden uretildi):
    burasi eskiden `os.environ.get("LOCALAPPDATA", tempfile.gettempdir())` idi.
    `LOCALAPPDATA` bulunmayan bir baslatma yolunda kayitlar `%TEMP%`e gidiyor;
    Windows Disk Temizleme / Storage Sense TEMP'i silince **geri alma kaydi yok
    olur** ve kullanicinin kurulumu geri donusu olmadan yamali kalir.
    TEMP hicbir zaman bir yedek/kayit deposu icin dogru cevap DEGILDIR.
    ⚠️ Bu dosya ORTAK: Sail / Flag / Outfit / Weapon Workshop da kullaniyor.
    Degisiklik yalnizca yolu DAHA DOGRU yapar (TEMP'i eler), davranisi bozmaz.
    """
    # Acikca ayarlanmis LOCALAPPDATA'ya KOSULSUZ saygi (testler onu gecici bir
    # klasore isaret ettirebiliyor -- mesru). Tehlike, degisken YOKKEN sessizce
    # TEMP'e dusmek; asagidaki GERI DUSUS zincirinde TEMP kabul edilmez.
    if os.environ.get("LOCALAPPDATA"):
        return os.path.join(os.environ["LOCALAPPDATA"], "ACBFR_Modding")
    adaylar = []
    for d in (os.path.join(os.environ.get("USERPROFILE", ""), "AppData", "Local")
              if os.environ.get("USERPROFILE") else None,
              os.path.join(os.path.expanduser("~"), "AppData", "Local"),
              os.path.expanduser("~")):
        if d:
            adaylar.append(d)
    gecici = os.path.normcase(os.path.abspath(tempfile.gettempdir()))
    for a in adaylar:
        try:
            if os.path.isdir(a) and not os.path.normcase(os.path.abspath(a)).startswith(gecici):
                return os.path.join(a, "ACBFR_Modding")
        except OSError:
            continue
    return os.path.join(os.path.expanduser("~") or ".", "ACBFR_Modding")


VERI_KOK = _veri_kok()


def sha256(yol, blok=8 << 20):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        while True:
            b = f.read(blok)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _kayit_yolu(mod_ad):
    return os.path.join(VERI_KOK, "deneme_" + mod_ad + ".json")


def _kayit_yaz(mod_ad, kayit):
    os.makedirs(VERI_KOK, exist_ok=True)
    p = _kayit_yolu(mod_ad)
    fd, gec = tempfile.mkstemp(dir=VERI_KOK, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(kayit, f, indent=2, ensure_ascii=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(gec, p)
    return p


def _kayit_oku(mod_ad):
    p = _kayit_yolu(mod_ad)
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))


def durum(mod_ad, hedef_ad, oyun=OYUN_VARSAYILAN):
    hedef = os.path.join(oyun, hedef_ad)
    k = _kayit_oku(mod_ad)
    var = os.path.exists(hedef)
    print("mod        : %s" % mod_ad)
    print("hedef      : %s" % hedef)
    print("dosya var  : %s%s" % (var, ("  (%d B)" % os.path.getsize(hedef)) if var else ""))
    if var:
        s = sha256(hedef)
        print("sha256     : %s" % s)
        if k:
            print("kayit      : %s" % _kayit_yolu(mod_ad))
            print("kayittaki  : %s" % k.get("sha256"))
            if k.get("sha256") == s:
                print("SONUC      : BU MOD KURULU")
            else:
                print("SONUC      : dosya BASKA bir mod/surum (kaldirma reddedilir)")
        else:
            print("SONUC      : dosya var ama kaydi YOK -> BASKA bir mod olabilir (or. Jack Sparrow)")
    else:
        print("SONUC      : kurulu degil")
    return var, k


def kur(mod_ad, kaynak, hedef_ad, oyun=OYUN_VARSAYILAN, zorla=False):
    hedef = os.path.join(oyun, hedef_ad)
    if not os.path.isdir(oyun):
        print("HATA: oyun klasoru bulunamadi: %s" % oyun); return 2
    if not os.path.exists(kaynak):
        print("HATA: kaynak yok: %s" % kaynak); return 2

    # --- KAPI 1: hedef dolu mu?
    if os.path.exists(hedef):
        mevcut = sha256(hedef)
        k = _kayit_oku(mod_ad)
        if k and k.get("sha256") == mevcut:
            print("Bu mod ZATEN kurulu (sha256 esit). Yapilacak bir sey yok."); return 0
        print("HATA: '%s' zaten var ve bu moda ait DEGIL." % hedef_ad)
        print("      boyut=%d sha256=%s" % (os.path.getsize(hedef), mevcut))
        print("      Bu slotu baska bir mod kullaniyor (or. Jack Sparrow karakter modu).")
        print("      UZERINE YAZILMADI. Once diger modu kaldir, sonra tekrar dene.")
        print("      (Iki mod ayni patch_02 dosyasini PAYLASAMAZ; birlestirilmeleri gerekir.)")
        return 3

    # --- KAPI 2: kaynak gercekten forge mu?
    with open(kaynak, "rb") as f:
        bas = f.read(9)
    if bas != b"scimitar\x00":
        print("HATA: kaynak bir forge dosyasi degil (imza tutmuyor)."); return 4

    # --- KAPI 3: disk alani
    s = sha256(kaynak); boy = os.path.getsize(kaynak)
    bos = shutil.disk_usage(oyun).free
    if bos < boy * 2:
        print("HATA: yetersiz disk alani (%d B gerekli, %d B bos)" % (boy * 2, bos)); return 5

    # --- kaydi ILK BAYTTAN ONCE yaz
    kayit = {"mod": mod_ad, "hedef": hedef, "kaynak": os.path.abspath(kaynak),
             "sha256": s, "boyut": boy, "durum": "in_progress",
             "zaman": time.strftime("%Y-%m-%d %H:%M:%S")}
    _kayit_yaz(mod_ad, kayit)

    shutil.copyfile(kaynak, hedef)
    yeni = sha256(hedef)
    if yeni != s:
        print("HATA: kopyalama dogrulanamadi (sha farkli). Dosya birakildi, kayit SILINMEDI.")
        kayit["durum"] = "dogrulanamadi"; kayit["hedef_sha"] = yeni
        _kayit_yaz(mod_ad, kayit); return 6
    kayit["durum"] = "done"
    _kayit_yaz(mod_ad, kayit)
    print("KURULDU: %s (%d B)" % (hedef, boy))
    print("sha256 : %s" % s)
    print("kayit  : %s" % _kayit_yolu(mod_ad))
    print("Geri almak icin: python kur.py kaldir")
    return 0


def kaldir(mod_ad, hedef_ad, oyun=OYUN_VARSAYILAN):
    hedef = os.path.join(oyun, hedef_ad)
    k = _kayit_oku(mod_ad)
    if not os.path.exists(hedef):
        print("Hedef dosya zaten yok — kaldirilacak bir sey yok."); return 0
    mevcut = sha256(hedef)
    if not k:
        print("HATA: bu moda ait KAYIT YOK, ama '%s' var." % hedef_ad)
        print("      Dosya baska bir moda ait olabilir. SILINMEDI."); return 3
    if k.get("sha256") != mevcut:
        print("HATA: dosyanin sha256'si kayittakiyle tutmuyor.")
        print("      kayit  : %s" % k.get("sha256"))
        print("      diskte : %s" % mevcut)
        print("      Baska bir arac/mod bu dosyayi degistirmis. SILINMEDI, kayit da SILINMEDI.")
        return 3
    os.remove(hedef)
    k["durum"] = "kaldirildi"; k["kaldirma_zamani"] = time.strftime("%Y-%m-%d %H:%M:%S")
    _kayit_yaz(mod_ad, k)
    print("KALDIRILDI: %s" % hedef)
    print("Oyun artik vanilla dosyalari kullanir (hicbir vanilla forge'a dokunulmamisti).")
    return 0


def cli(mod_ad, kaynak, hedef_ad):
    komut = sys.argv[1] if len(sys.argv) > 1 else "durum"
    oyun = sys.argv[2] if len(sys.argv) > 2 else OYUN_VARSAYILAN
    if komut == "kur":
        sys.exit(kur(mod_ad, kaynak, hedef_ad, oyun))
    elif komut in ("kaldir", "geri"):
        sys.exit(kaldir(mod_ad, hedef_ad, oyun))
    else:
        durum(mod_ad, hedef_ad, oyun)
