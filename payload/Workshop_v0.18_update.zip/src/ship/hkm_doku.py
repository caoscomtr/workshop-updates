# -*- coding: utf-8 -*-
"""HKM doku degistirme borusu — PNG -> DDS -> (gomulu havuz + harici ham mip'ler).

Oyun dosyalarina YAZMAZ. Sadece:
  * oyun forge'undan SALT-OKUNUR okur,
  * yeni giris baytlarini ve yeni harici mip baytlarini BELLEKTE uretir,
  * cagiran betik bunlari deneme_modlar\\<mod>\\ altina yazar.
"""
import os, sys, struct, subprocess, tempfile, shutil

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hkm_ortak as H
import numpy as np
from PIL import Image

TEXENCODE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                         "tools", "TexEncode.exe")
DXGI_BEKLENEN = {("BC7", 0): 98, ("BC7", 1): 99, ("BC1", 0): 71, ("BC1", 1): 72,
                 ("BC3", 0): 77, ("BC3", 1): 78}


# ------------------------------------------------------------------ kodlama
def png_to_dds(png, dds, aile="BC7", srgb=0):
    arg = [TEXENCODE, png, dds]
    if srgb:
        arg.append("srgb")
    arg.append(aile.lower())
    r = subprocess.run(arg, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("TexEncode hatasi: %s %s" % (r.stdout[-500:], r.stderr[-500:]))
    return dds


# ------------------------------------------------------------------ okuma
def mip_zinciri_oku(forge, giris_fid, tex_id):
    """Vanilla dokunun TUM mip zincirini (harici + gomulu) sozluk olarak dondur."""
    r = H.doku_bul(forge, giris_fid)          # SUZME YOK: giristeki tum TextureMap'ler kalsin
    d = [x for x in r["dokular"] if x["tex_id"] == tex_id][0]
    t = d["tanim"]
    mipler = {}
    for mid, sev, ext, ln, off in d["harici"]:
        ham, _o, _l = H.mip_ham_oku(forge, mid & 0xFFFFFFFFFFFFFFFF)
        mipler[sev] = {"veri": ham, "w": max(1, t["W"] >> sev), "h": max(1, t["H"] >> sev),
                       "yer": "harici", "fid": mid & 0xFFFFFFFFFFFFFFFF, "len": ln}
    ic = bytes(r["dilim"][d["sira"]][1])
    havuz = ic[d["cipa"][1]: d["cipa"][1] + d["cipa"][2]]
    for lvl, o, pitch, satir, rowbytes in d["gomulu"]:
        buf = bytearray()
        for y in range(satir):
            buf += havuz[o + y * pitch: o + y * pitch + rowbytes]
        mipler[lvl] = {"veri": bytes(buf), "w": max(1, t["W"] >> lvl),
                       "h": max(1, t["H"] >> lvl), "yer": "gomulu", "pitch": pitch}
    return r, d, mipler


def mip_png(m, aile, yol):
    a = H.bc_coz(m["veri"], m["w"], m["h"], aile)
    Image.fromarray(a, "RGBA").save(yol)
    return a


# ------------------------------------------------------------------ yazma (bellekte)
#
# !! OLCULMUS TUZAK (2026-07-29) — TexEncode'un mip zinciri alfa-agirlikli filtre
#    kullaniyor: kaynak goruntunun alfasi 0 ise seviye 1 ve altindaki TUM mip'lerin
#    RGB'si SIFIRLANIYOR (kanit: duz kirmizi 256x256, alfa=0 -> lvl0 RGB=(220,40,30),
#    lvl1+ RGB=(0,0,0); ayni test alfa=255 ile 9/9 seviyede dogru).
#    AC4 silah diffuse'unun alfasi ~0 (max 4), UI ikonunun alfa ortalamasi 15,6.
#    Bu yuzden "tek PNG ver, TexEncode mip'leri uretsin" yolu KULLANILMAZ.
#    Cozum: HER SEVIYE AYRI KODLANIR (vanilla o seviyenin kendi pikselinden turetilir,
#    alfa vanilla'dan aynen korunur).

def doku_degistir(forge, giris_fid, tex_id, donusum, gecici=None, min_kenar=2, gunluk=None):
    """Seviye seviye doku degistirir.

    donusum(rgba_ndarray, lvl, w, h) -> rgba_ndarray  (ayni sekil/dtype)
    -> dict(yeni_giris=bytes, harici=[(mip_fid, ext, bytes)], rapor=[...])
    """
    rap = []
    r, d, mp = mip_zinciri_oku(forge, giris_fid, tex_id)
    t = d["tanim"]
    aile, blok, W, Hh = t["aile"], t["blok"], t["W"], t["H"]
    bek = DXGI_BEKLENEN.get((aile, t["srgb"]))

    gec = gecici or tempfile.mkdtemp()
    os.makedirs(gec, exist_ok=True)

    mip = {}
    korunan = []
    for lvl in range(t["mipcount"]):
        w = max(1, W >> lvl); h = max(1, Hh >> lvl)
        tight = max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * blok
        a = H.bc_coz(mp[lvl]["veri"][:tight], w, h, aile)
        b = donusum(a, lvl, w, h)
        if min(w, h) < min_kenar:
            mip[lvl] = {"veri": mp[lvl]["veri"][:tight]}      # vanilla blok korunur
            korunan.append(lvl)
            continue
        p = os.path.join(gec, "lvl%02d.png" % lvl)
        Image.fromarray(b, "RGBA").save(p)
        dds = os.path.join(gec, "lvl%02d.dds" % lvl)
        png_to_dds(p, dds, aile, t["srgb"])
        mm, dW, dH, dxgi, dblok = H.dds_mipler(dds)
        if dxgi != bek:
            raise ValueError("lvl%d DXGI uyusmuyor: %d != %d" % (lvl, dxgi, bek))
        if (dW, dH) != (w, h) or dblok != blok:
            raise ValueError("lvl%d olcu/blok uyusmuyor" % lvl)
        if len(mm[0]["veri"]) != tight:
            raise ValueError("lvl%d boy uyusmuyor: %d != %d" % (lvl, len(mm[0]["veri"]), tight))
        mip[lvl] = {"veri": mm[0]["veri"]}
        if gunluk:
            gunluk("      lvl%-2d %4dx%-4d kodlandi (%d B)" % (lvl, w, h, tight))
    rap.append("SEVIYE SEVIYE kodlandi: %d seviye TexEncode'dan gecti, %s"
               % (t["mipcount"] - len(korunan),
                  ("lvl %s vanilla blogu korundu (TexEncode 1x1'de calismiyor)" % korunan)
                  if korunan else "hepsi kodlandi"))
    rap.append("her seviyenin ALFA kanali vanilla'dan aynen korundu (donusum yalniz RGB)")

    # --- harici ham mip girisleri
    harici = []
    for mid, sev, ext, ln, off in d["harici"]:
        w = max(1, W >> sev); h = max(1, Hh >> sev)
        bw = max(1, (w + 3) // 4); bh = max(1, (h + 3) // 4)
        rowbytes = bw * blok
        pitch = H.hizala(rowbytes, 256)
        src = mip[sev]["veri"]
        buf = bytearray()
        for y in range(bh):
            satir = src[y * rowbytes:(y + 1) * rowbytes]
            buf += satir + b"\x00" * (pitch - rowbytes)
        if len(buf) != ln:
            raise ValueError("harici mip %d boyu tutmadi: %d != %d" % (sev, len(buf), ln))
        harici.append((mid & 0xFFFFFFFFFFFFFFFF, ext & 0xFFFFFFFF, bytes(buf)))
        rap.append("harici mip%d fid=0x%X %dx%d %d B (pitch=%d rowbytes=%d)"
                   % (sev, mid & 0xFFFFFFFFFFFFFFFF, w, h, ln, pitch, rowbytes))

    # --- gomulu havuz (orijinali temel al, yalniz mip satirlarini ez -> dolgu korunur)
    dilim = r["dilim"]
    ic = bytearray(dilim[d["sira"]][1])
    hb, hl = d["cipa"][1], d["cipa"][2]
    havuz = bytearray(ic[hb:hb + hl])
    for lvl, o, pitch, satir, rowbytes in d["gomulu"]:
        src = mip[lvl]["veri"]
        for y in range(satir):
            havuz[o + y * pitch: o + y * pitch + rowbytes] = src[y * rowbytes:(y + 1) * rowbytes]
    ic[hb:hb + hl] = havuz
    rap.append("gomulu havuz: ofset=%d uzunluk=%d, %d seviye yazildi (lvl %d..%d)"
               % (hb, hl, len(d["gomulu"]), d["gomulu"][0][0], d["gomulu"][-1][0]))

    dilim[d["sira"]][1] = ic
    yeni_govde = b"".join(bytes(x[1]) for x in dilim)
    if len(yeni_govde) != len(r["coz"]["govde"]):
        raise ValueError("govde uzunlugu degisti!")
    yeni_giris = H.giris_kur(r["coz"]["k1"], yeni_govde)
    rap.append("giris yeniden kuruldu: %d B (vanilla %d B, Form T/STORED)"
               % (len(yeni_giris), r["giris_len"]))

    if gecici is None:
        shutil.rmtree(gec, ignore_errors=True)
    return {"yeni_giris": yeni_giris, "harici": harici, "rapor": rap, "detay": d,
            "vanilla": r, "yeni_govde": yeni_govde, "havuz": (hb, hl)}


# ------------------------------------------------------------------ gorsel donusumler
def altin(a, koyu=(58, 38, 8), acik=(255, 226, 138), guc=1.0):
    """RGBA -> altin ramp (parlaklik korunur, renk altina cevrilir)."""
    f = a.astype(np.float32)
    L = (0.2126 * f[:, :, 0] + 0.7152 * f[:, :, 1] + 0.0722 * f[:, :, 2]) / 255.0
    L = np.clip(L * 1.08, 0, 1)[:, :, None]
    ramp = np.array(koyu, np.float32) + (np.array(acik, np.float32) - np.array(koyu, np.float32)) * L
    out = f.copy()
    out[:, :, :3] = f[:, :, :3] * (1 - guc) + ramp * guc
    return np.clip(out, 0, 255).astype(np.uint8)


def paslanmis(a, koyu=(42, 22, 12), acik=(196, 108, 52), guc=1.0, doku_tohum=7):
    """RGBA -> paslanmis demir (kahve/turuncu ramp + ince gurultu benegi)."""
    f = a.astype(np.float32)
    L = (0.2126 * f[:, :, 0] + 0.7152 * f[:, :, 1] + 0.0722 * f[:, :, 2]) / 255.0
    rs = np.random.RandomState(doku_tohum)
    n = rs.rand(*L.shape).astype(np.float32)
    L = np.clip(L * (0.85 + 0.30 * n), 0, 1)[:, :, None]
    ramp = np.array(koyu, np.float32) + (np.array(acik, np.float32) - np.array(koyu, np.float32)) * L
    out = f.copy()
    out[:, :, :3] = f[:, :, :3] * (1 - guc) + ramp * guc
    return np.clip(out, 0, 255).astype(np.uint8)


def cerceve(a, kalinlik, renk=(255, 200, 60, 255)):
    """UI ikonuna ic cerceve ciz (alfasi olan pikselleri bozmadan kenara)."""
    out = a.copy()
    k = kalinlik
    out[:k, :, :] = renk; out[-k:, :, :] = renk
    out[:, :k, :] = renk; out[:, -k:, :] = renk
    return out
