# -*- coding: utf-8 -*-
"""SHIP WORKSHOP - kompozit onizleme (OYUNDA GORUNEN hali uret).

NEDEN VAR:
  Kullanicinin somut sikayeti -> "bayragi cikarttigim zaman SADECE KURU KAFA cikiyor".
  Sebep OLCULDU: bu ailenin desen dokularinda ALFA OPAKLIK DEGIL, alt kumas
  uzerindeki KAPLAMA MASKESI (bkz. ship_motor.py ALFA POLITIKASI blogu). Ham RGBA
  PNG'yi her goruntuleyici siyah zemine bindiriyor -> ekranda yalniz maskenin
  gectigi yer (kuru kafa) kaliyor. Bu modul ayni pikselleri OYUNUN formuluyle
  birlestirip duz RGB verir; kullanici gordugu bayragin uzerine boyar.

FORMUL (olculdu, asagida bayt ofsetleriyle):
      kompozit = lerp( taban_kumas.rgb x ColorOverlay , desen.rgb , desen.a )

BU DOSYA OYUN KLASORUNE TEK BAYT YAZMAZ. Butun okumalar hkm_ortak/ship_motor
uzerinden ("rb"). Kendi forge ayristiricisi YOKTUR; yalniz MATERYAL ve TEXTURESET
govdelerini (ic dosya, coozulmus, bellekte) ofsetle okur.

BILINEN SINIR: kompozit bir YAKLASIMDIR, oyunun shader'i degildir. Carpim
0..255 sRGB-kodlu uzayda yapilir (dogrusal isik uzayinda DEGIL); Weathering /
Detail Scale / Amplitude / SlackBias parametreleri ve slot 1 kumas detay normali
KULLANILMAZ. Amac boyanacak zemin, foto-gercek render degil.
"""
import os, sys, struct, zlib
try:
    import sqlite3                     # noqa: F401
except ImportError:                    # pragma: no cover
    # 🧨 OLCULMUS TUZAK: Nexus paketinin GOMULU python'unda "sqlite3" YOK.
    # (ship_ayar / hkm_ortak / dokulib'de de ayni sekilde opsiyonel yapilmisti.)
    # Zorunlu tutmak, paketi kullanan HERKESTE import'u patlatir -- ayni aile
    # bugun P0 olarak yakalanan "Change... -> AttributeError" kusuruyla ayni.
    # Buradaki tek kullanimi "varliklar.db" aramasi; o kaynak yoksa modul
    # materyali hedefin KENDI forge girisinden cozmeye devam eder.
    sqlite3 = None

# ⭐ HICBIR GELISTIRICI YOLU YOK -- ve paketlemede yama da GEREKTIRMEZ.
# `paketle.py` `ship_motor/ship_ayar/ship_cli`de mutlak yollari yamaliyor; her yeni
# dosya icin bir yama cifti daha eklemek, bir gun unutulacak bir adim demektir (E4).
# ⚠️ IMPORT SIRASI ONEMLI: `ship_motor` import edilirken `hkm_ortak`/`dokulib`in
# bulundugu klasorleri sys.path'e KENDISI ekliyor. Bu yuzden ONCE o import edilir;
# tersi sirada (hkm_ortak once) gelistirme agacinda ModuleNotFoundError alinir ve
# bu dosyaya ayri bir mutlak yol yazmak gerekirdi. Boylece paketleme sizinti
# kapisi temiz kalir: bu dosyada gelistirici makinesine ait TEK mutlak yol yok.
_BURASI = os.path.dirname(os.path.abspath(__file__))
if _BURASI not in sys.path:
    sys.path.insert(0, _BURASI)

import ship_motor as M         # noqa: E402  ILK: sys.path'i o kuruyor
import hkm_ortak as H          # noqa: E402  forge okuma (salt-okunur), doku yerlesimi
import dokulib as D            # noqa: E402  ic dosya sarmalayicisi
import numpy as np             # noqa: E402
from PIL import Image          # noqa: E402

# Ansiklopedi veritabani OPSIYONEL: pakette yok, gelistirme agacinda var.
# Yoksa materyal hedefin KENDI forge girisinden cozulur (11 bayrak hedefinin
# hepsi `kapsayici_sinif == "Material"`, yani db'ye ihtiyac duymaz).
# YAYIN KURALI: gelistirme agacinin klasor adi kodda YAZILI DEGIL (yayinlanan pakette
# anlamsiz olurdu ve kaptanin proje adini kullaniciya tasirdi). Sira: ACBFR_VARLIKLAR_DB
# ortam degiskeni -> proje kokunun KARDES klasorlerinde `isimler\varliklar.db` taramasi
# (tek listdir, salt okuma, ilk eslesme) -> "" (arama sessizce bos doner).
def _varliklar_db():
    ov = os.environ.get("ACBFR_VARLIKLAR_DB")
    if ov and os.path.isfile(ov):
        return ov
    kok = os.path.dirname(os.path.dirname(os.path.dirname(_BURASI)))
    try:
        for ad in sorted(os.listdir(kok))[:400]:
            aday = os.path.join(kok, ad, "isimler", "varliklar.db")
            if os.path.isfile(aday):
                return aday
    except OSError:                    # kok okunamiyor = aday yok
        pass
    return ""


VARLIKLAR = _varliklar_db()

# ---------------------------------------------------------------- OLCULMUS SABITLER
MATERIAL   = 0x85C817C3        # ic dosya sinif crc'si  (sarmalayici tip1)
TEXTURESET = H.TEXTURESET      # 0xD70E6670
TEXTUREMAP = H.TEXTUREMAP      # 0xA2B7E917

# 🔢 OLCULDU 2026-07-30: parametre adi -> crc32(ad) & 0xFFFFFFFF, 7/7 BIREBIR.
#    Materyal govdesi parametreyi ADLA degil bu crc ile tasiyor; bu yuzden
#    "Color Overlay"i POZISYONLA aramiyoruz, CRC ile buluyoruz (sira degisirse
#    de dogru parametre bulunur).
CRC_COLOR_OVERLAY = zlib.crc32(b"Color Overlay") & 0xFFFFFFFF   # = 0xE3DA40C5
PARAM_ADLARI = {}
for _ad in ("Color Overlay", "Weathering", "Detail Scale", "HEALTH",
            "Health Offset", "Amplitude", "SlackBias"):
    PARAM_ADLARI[zlib.crc32(_ad.encode()) & 0xFFFFFFFF] = _ad

# parametre tipi -> kac float tuketir (0x0D=float4 ve 0x0A=float1 OLCULDU;
# 0x0B/0x0C hic goorulmedi, tahmini kapasite -- kendini dogrulayan tarama
# yanlissa zaten aday uretmez, bkz. _param_blok)
TIP_FLOAT = {0x0A: 1, 0x0B: 2, 0x0C: 3, 0x0D: 4}

# TextureSet govdesi: 1 B basli + 14 x 9 B kanal yuvasi + 4 B kuyruk = 131 B
TS_KANAL_N   = 14
TS_KANAL_BAS = 1
TS_DIFFUSE   = 0      # yuva 0 = DiffuseMap   (OLCULDU: ad_tam ile 5/5 dogrulandi)
TS_NORMAL    = 1      # yuva 1 = NormalMap
TS_MASK0     = 12     # yuva 12 = Mask0Map

_ONBELLEK = {}


# ================================================================ dusuk seviye okuma
def _oncelik(forge):
    """patch zinciri (kural #6): buyuk patch numarasi kazanir."""
    if "_patch_02" in forge:
        return 2
    if "_patch_01" in forge:
        return 1
    return 0


def _giris_icler(forge, fid):
    """Bir forge girisini cozup ic dosyalarini sarmalayicisi ACILMIS halde dondur.

    -> [(ic_fid, sinif_crc, govde_bytes)]   SALT-OKUNUR.
    Kendi ayristiricim YOK: hkm_ortak.giris_ham + giris_coz_tam + ic_dilimle ve
    dokulib.sarmal_ac kullanilir.
    """
    ck = ("icler", forge, fid)
    if ck in _ONBELLEK:
        return _ONBELLEK[ck]
    raw, _off, _ln, _ext = H.giris_ham(forge, fid)
    c = H.giris_coz_tam(raw)
    out = []
    for f, v in H.ic_dilimle(c["govde"], c["icler"]):
        s = D.sarmal_ac(bytes(v))
        out.append((f, s["tip1"] & 0xFFFFFFFF, s["govde"]))
    _ONBELLEK[ck] = out
    return out


def _varlik_ara(sorgu, par):
    try:
        if sqlite3 is None or not os.path.exists(VARLIKLAR):
            return []          # ansiklopedi yok -> sessizce bos; cagiran fail-closed
        return list(sqlite3.connect(VARLIKLAR).execute(sorgu, par))
    except Exception:
        return []


def _sahip_giris(ic_fid):
    """Bir IC DOSYA fid'ini iceren forge girisini bul -> (forge, giris_fid) ya da None.

    Sira: (1) ic_fid'in kendisi ust seviye giris mi (katalog.db, patch zinciri
    farkindalikli), (2) varliklar.db `ic_dosyalar.ic_id -> giris_id`.
    """
    z = H.zincir(ic_fid)
    if z:
        z = sorted(z, key=lambda r: -_oncelik(r[0]))
        return z[0][0], ic_fid
    r = _varlik_ara("select forge,giris_id from ic_dosyalar where ic_id=?", (ic_fid,))
    if not r:
        return None
    en = {}
    for forge, gid in r:
        gid &= 0xFFFFFFFFFFFFFFFF
        en.setdefault((forge, gid), 0)
    aday = sorted(en, key=lambda k: -_oncelik(k[0]))
    for forge, gid in aday:
        if H.giris_bul(forge, gid):
            return forge, gid
    return None


# ================================================================ MATERYAL
def _param_blok(g):
    """Materyal govdesindeki parametre blogunu bul -> {crc: (tip, [floatlar])} ya da None.

    🔢 OLCULDU 2026-07-30 (50 flag+sail materyalinin 50'sinde de TEK aday, off=348):
      govde[q      : q+4 ]  u32  parametre sayisi n            (bayrak/yelkende 7 ya da 12)
      govde[q+4    : ...  ]  n x 16 B kayit; kayit[0:4]=crc32(ad), kayit[10]=tip
      govde[q+4+16n: son ]  float degerleri, kayit sirasina gore
    Tarama GERIYE dogru ve KENDINI DOGRULAYAN: q ancak
        q + 4 + 16*n + 4*(tiplerin float toplami) == len(govde)
    ise kabul edilir. Sabit 348'e GUVENILMIYOR (616 B'lik `OBD_SHP_Sail_Opt`
    kardesi 12 parametre tasiyor; oradaki blok da ayni tarama ile bulunuyor).
    Fail-closed: birden fazla ya da hic aday varsa None.
    """
    aday = []
    for q in range(len(g) - 4, max(0, len(g) - 8192) - 1, -1):
        n = struct.unpack_from("<I", g, q)[0]
        if not (1 <= n <= 64) or q + 4 + 16 * n > len(g):
            continue
        tipler = [g[q + 4 + 16 * i + 10] for i in range(n)]
        if any(t not in TIP_FLOAT for t in tipler):
            continue
        fc = sum(TIP_FLOAT[t] for t in tipler)
        if q + 4 + 16 * n + 4 * fc != len(g):
            continue
        crcs = [struct.unpack_from("<I", g, q + 4 + 16 * i)[0] for i in range(n)]
        flt = list(struct.unpack_from("<%df" % fc, g, q + 4 + 16 * n))
        d, o = {}, 0
        for i in range(n):
            k = TIP_FLOAT[tipler[i]]
            d[crcs[i]] = (tipler[i], flt[o:o + k])
            o += k
        aday.append((q, d))
    if len(aday) != 1:
        return None
    return aday[0][1]


def _materyal_ayristir(g):
    """Materyal ic dosyasinin govdesini oku -> dict. SALT-OKUNUR, bayt ofsetleri:

      govde[0]        u8   surum/kind (olculdu: hep 0x01)
      govde[1]        u8   sablon var mi (0x01)
      govde[2:10]     u64  MaterialTemplate fid   (bayraklarda 0x254ED7DD225)
      govde[10:14]    u32  TextureSet YUVA SAYISI  (olculdu: 4)
      govde[14 + 9*i] u8   yuva i var mi (0x01 = var, 0x03 = bos)
      govde[15 + 9*i] u64  yuva i'nin TextureSet fid'i
      ... (yuvalardan sonra baska bloklar; parametre blogu icin _param_blok)
    """
    tmpl = struct.unpack_from("<Q", g, 2)[0]
    n = struct.unpack_from("<I", g, 10)[0]
    if not (0 <= n <= 16):
        raise ValueError("makul olmayan yuva sayisi: %d" % n)
    yuvalar, p = [], 14
    for _i in range(n):
        yuvalar.append((g[p], struct.unpack_from("<Q", g, p + 1)[0]))
        p += 9
    return {"surum": g[0], "sablon": tmpl, "yuva_n": n, "yuvalar": yuvalar,
            "yuva_son": p, "param": _param_blok(g), "govde_len": len(g)}


def _materyal_bul(hedef):
    """Hedefin KAPSAYICI MATERYALINI coz -> (dict, kaynak_metni) ya da (None, sebep).

    Iki yol, bu sirayla:
      1. Hedefin kendi forge girisi bir Material ic dosyasi tasiyorsa (katalogda
         kapsayici_sinif == "Material" olan 11 hedef) o kullanilir -- ek arama YOK.
      2. Aksi halde katalogdaki `materyaller` listesindeki AD, varliklar.db'de
         (tip=Material, ad_tam) aranir ve bulunan girisin Material ic dosyasi alinir.
         Birden fazla ad varsa hedefin dokusunu GERCEKTEN bir yuvasinda tasiyan
         materyal secilir (ad tahminine guvenilmez).
    """
    ck = ("mat", hedef["anahtar"])
    if ck in _ONBELLEK:
        return _ONBELLEK[ck]
    tid = int(hedef["id"], 16)
    kfid = int(hedef["kapsayici"], 16)
    adaylar = []

    try:
        for f, sinif, g in _giris_icler(hedef["forge"], kfid):
            if sinif == MATERIAL:
                adaylar.append((f, hedef["forge"], kfid, g, "kapsayici"))
    except Exception as e:
        _ONBELLEK[ck] = (None, "kapsayici okunamadi: %r" % e)
        return _ONBELLEK[ck]

    if not adaylar:
        for ad in hedef.get("materyaller", []):
            r = _varlik_ara("select forge,giris_id from ic_dosyalar "
                            "where ad_tam=? and tip=?", (ad, MATERIAL))
            gor = set()
            for forge, gid in sorted(r, key=lambda x: -_oncelik(x[0])):
                gid &= 0xFFFFFFFFFFFFFFFF
                if (forge, gid) in gor or not H.giris_bul(forge, gid):
                    continue
                gor.add((forge, gid))
                try:
                    ii = _giris_icler(forge, gid)
                except Exception:
                    continue
                for f, sinif, g in ii:
                    if sinif == MATERIAL:
                        adaylar.append((f, forge, gid, g, "ad:%s" % ad))

    if not adaylar:
        _ONBELLEK[ck] = (None, "materyal bulunamadi (materyaller=%s)"
                         % (hedef.get("materyaller") or []))
        return _ONBELLEK[ck]

    # dokuyu GERCEKTEN tasiyan materyali sec
    en_iyi = None
    for f, forge, gid, g, kaynak in adaylar:
        try:
            m = _materyal_ayristir(g)
        except Exception:
            continue
        m.update({"fid": f, "forge": forge, "giris": gid, "kaynak": kaynak})
        m["cozulmus_yuvalar"] = _yuvalari_coz(m, forge, gid)
        m["hedef_yuva"] = _hedef_yuvasi(m, tid)
        if m["hedef_yuva"] is not None:
            en_iyi = m
            break
        if en_iyi is None:
            en_iyi = m
    if en_iyi is None:
        _ONBELLEK[ck] = (None, "materyal govdesi ayristirilamadi")
        return _ONBELLEK[ck]
    _ONBELLEK[ck] = (en_iyi, "%s @ %s/0x%X" % (en_iyi["kaynak"], en_iyi["forge"],
                                               en_iyi["fid"]))
    return _ONBELLEK[ck]


# ================================================================ TEXTURESET
def _ts_kanallar(g):
    """TextureSet govdesi -> {kanal_index: doku_fid}. SALT-OKUNUR, bayt ofsetleri:

      govde[0]              u8   surum (olculdu: 0x01)
      govde[1 + 9*i]        u8   kanal i var mi (0x01 = var, 0x03 = bos)
      govde[2 + 9*i]        u64  kanal i'nin TextureMap fid'i
      i = 0..13 (14 kanal), sonra 4 B kuyruk -> 1 + 14*9 + 4 = 131 B
    🔢 OLCULDU: kanal 0 = DiffuseMap, 1 = NormalMap, 12 = Mask0Map
       (Flag_Base_01 / Streamer_Base_01 / Sail_BaseAtlas_01 / Pattern_Empty /
        GEN_Fabric_Detail_01 setlerinde ad_tam ile 5/5 dogrulandi; Fabric setinde
        kanal 0 BOS ve gercekten DiffuseMap'i yok -- yerlesim kaymiyor.)
    """
    out = {}
    for i in range(TS_KANAL_N):
        p = TS_KANAL_BAS + 9 * i
        if p + 9 > len(g):
            break
        if g[p] != 0x01:
            continue
        v = struct.unpack_from("<Q", g, p + 1)[0]
        if 0x10000000 < v < 0xFFFFFFFFFFFFF:
            out[i] = v
    return out


def _ts_coz(ts_fid, ipucu_forge=None, ipucu_giris=None):
    """TextureSet fid -> {kanal: doku_fid} + o TextureSet'i tasiyan giris.

    -> dict(kanallar=..., forge=..., giris=...) ya da None.
    Sira: (1) ipucu girisin ic dosyalari (materyalin kendi girisi TextureSet'i de
    tasiyor olabilir -- PT_Pirate_01'de oyle), (2) _sahip_giris ile arama.
    """
    ck = ("ts", ts_fid, ipucu_forge, ipucu_giris)
    if ck in _ONBELLEK:
        return _ONBELLEK[ck]
    denemeler = []
    if ipucu_forge and ipucu_giris:
        denemeler.append((ipucu_forge, ipucu_giris))
    s = _sahip_giris(ts_fid)
    if s and s not in denemeler:
        denemeler.append(s)
    for forge, gid in denemeler:
        try:
            ii = _giris_icler(forge, gid)
        except Exception:
            continue
        for f, sinif, g in ii:
            if f == ts_fid and sinif == TEXTURESET:
                r = {"kanallar": _ts_kanallar(g), "forge": forge, "giris": gid,
                     "fid": ts_fid}
                _ONBELLEK[ck] = r
                return r
    _ONBELLEK[ck] = None
    return None


def _yuvalari_coz(mat, forge, giris):
    """Materyalin her TextureSet yuvasini kanal listesine kadar coz.
    -> [None | dict(kanallar, forge, giris, fid)]   (yuva sirasina gore)"""
    out = []
    for var, ref in mat["yuvalar"]:
        out.append(_ts_coz(ref, forge, giris) if var == 0x01 else None)
    return out


def _hedef_yuvasi(mat, tex_id):
    """Hedefin dokusu materyalin HANGI yuvasinda? -> (yuva_index, kanal) ya da None.

    ⚠️ Yuva SIRASINA guvenilmez: desen kimi hedefte yuva 3'te, kimi hedefte
    yuva 2'de (PT_Jackdaw_Pirate_01). Bu yuzden yuva, hedefin KENDI doku fid'i
    TextureSet kanallarinda aranarak bulunur.
    """
    for i, ts in enumerate(mat.get("cozulmus_yuvalar") or []):
        if not ts:
            continue
        for k, v in ts["kanallar"].items():
            if v == tex_id:
                return (i, k)
    return None


# ================================================================ API
def _pisirilmis(hedef):
    """Katalogda PISIRILMIS kompozit degerleri (varsa).

    🧨 OLCULMUS TUZAK: materyal cozumu bazi hedeflerde `varliklar.db`ye ihtiyac
    duyuyor; o db 891 bin kayitli, Nexus paketine konulamaz ve pakette `sqlite3`
    de yok. Olculdu: paket python'unda 11 bayrak hedefinin 4'u kompozit
    uretemeyip ham RGBA'ya dusuyordu -- yani kullanici yine "sadece kuru kafa"
    goruyordu. Cozum, cozumu CALISMA ANINDA degil katalog uretilirken bir kez
    yapmak: `src/ship_kompozit_pisir.py`. (Ayni desen surum dogrulamasinin 40
    parmak izi icin de kullaniliyor; bayat katalogu o kapi yakalar.)
    Alan yoksa canli cozume duselir -- geriye tam uyumlu.
    """
    return hedef.get("kompozit") or {}


def renk_kaplamasi(hedef):
    """Hedefin kapsayici materyalinden ColorOverlay'i oku (SALT-OKUNUR).

    -> (r, g, b, a) float 0..1  ya da None.  Bulunamazsa None (cagiran notr
    (1,1,1,1) varsayar; bu modul UYDURMA DEGER DONDURMEZ).
    Parametre POZISYONLA degil crc32("Color Overlay") = 0xE3DA40C5 ile bulunur.
    """
    pis = _pisirilmis(hedef)
    if "tint" in pis:
        return tuple(float(x) for x in pis["tint"]) if pis["tint"] else None
    mat, _kaynak = _materyal_bul(hedef)
    if not mat or not mat.get("param"):
        return None
    p = mat["param"].get(CRC_COLOR_OVERLAY)
    if not p:
        return None
    tip, v = p
    if tip != 0x0D or len(v) != 4:
        return None
    return tuple(float(x) for x in v)


def _taban_mip_sec(tw, th, W, Hh, mipcount):
    """Hedef olcusune en yakin USTTEKI mip seviyesi (gereksiz 4096² cozmemek icin).
    Kucultme yine `_olcekle_rgb` ile yapilir; mip secimi yalniz is miktarini kisar."""
    lvl = 0
    for L in range(mipcount):
        w = max(1, W >> L); h = max(1, Hh >> L)
        if w >= tw and h >= th:
            lvl = L
        else:
            break
    return lvl


def _olcekle_rgb(rgb, w, h):
    """RGB'yi olcekle -- ALFA ile BIRLIKTE DEGIL.

    🧨 `ship_motor.olcekle`'nin docstring'indeki olculmus tuzagin ayni disiplini:
    Pillow RGBA modda ALFA-AGIRLIKLI (premultiplied) yeniden orneklestirme yapar;
    bu ailenin alfasi ~0 oldugu icin RGB SIYAHA COKER (1024 ort 79,99 -> 512'de
    3,86 -> 64'te 0,00). Burada goruntu 3 kanalli "RGB" modda olceklenir, alfa
    hic bulasmaz. Taban kumasin alfasina (yipranma) ZATEN ihtiyac yok: kompozitte
    maske DESENIN alfasidir.
    """
    if (rgb.shape[1], rgb.shape[0]) == (w, h):
        return np.ascontiguousarray(rgb)
    return np.asarray(Image.fromarray(np.ascontiguousarray(rgb), "RGB")
                      .resize((w, h), Image.LANCZOS))


def _hedef_olcu(hedef):
    o = hedef.get("olculen") or {}
    return int(o.get("w") or hedef["w"]), int(o.get("h") or hedef["h"])


def taban_kumas(hedef, olcu=None):
    """Hedefin materyalinin 0. TextureSet YUVASINDAKI bez dokusunun lvl0 RGB'si,
    hedefin desen boyutuna olceklenmis.  -> (H, W, 3) uint8  ya da None.

    ⚠️ "Yuva 0" ADLA VARSAYILMAZ, materyalin GERCEK yuva listesinden coozulur:
       PT_Jackdaw_Pirate_01'in tabani `OBD_SHP_Streamer_Base_01_Set` (0x21910509889),
       `OBD_SHP_Flag_Base_01_Set` DEGIL -> zemin rengi digerlerinden farkli.
    Hedefin KENDISI yuva 0'daysa (Base_01, BaseAtlas_01, Athena, Blackbart, ...
    17 hedef) ayri bir taban yoktur ve None doner -- cagiran `yol='rgb'`e duser.

    YON: cevirme kurali TEKRAR YAZILMIYOR. Taban, hedefle AYNI kurala tabi
    tutulur (`ship_motor.cevirmeli(hedef)`); taban ve desen ayni UV uzayinda
    oldugu icin ikisi ayni yonde olmak ZORUNDA. 🔢 OLCULDU 2026-07-30, iki sayi
    birlikte okunmali:
      * Flag_Base_01 lvl0'in ust/alt yarim ortalamalari 154,9966 / 155,9497 ->
        fark yalniz 0,9532. Yani ORTALAMA PARLAKLIGA bakarak yanlis cevirmeyi
        yakalayamazsin (ilk denemede kurdugum "yarim ortalamalar ayrisir" kapisi
        BU YUZDEN COKTU; kapi degistirildi, sabit uydurulmadi).
      * Ayni dokunun cevrilmis hali ile ham hali arasindaki PIKSEL BASINA ort
        |fark| 11,2771. Yani cevirme gorsel olarak ONEMLI (yipranma lekeleri
        yer degistirir), sadece istatistikle gorunmuyor.

    ⚠️ OLCULEMEDI (yelkenler): yelkenlerde taban `OBD_SHP_Sail_BaseAtlas_01`
    bir ATLAS'tir (4096²) ve yelken geometrisi onun bir HUCRESINI ornekliyor
    olabilir. Burada atlasin TAMAMI desen olcusune olceklenir -- kare/kare ayni
    en-boy oranindaki bu esleme SINANMADI. Bayraklarda boyle bir kusku yok:
    Flag_Base_01 512x256, desen 1024x512, ikisi de 2:1.
    """
    pis = _pisirilmis(hedef)
    if "taban" in pis:
        if not pis["taban"]:
            return None                    # PISIRILMIS: hedefin kendisi taban kumas
        _f, _g, _t = pis["taban"]
        s, taban_tid = (_f, int(_g, 16)), int(_t, 16)
    else:
        mat, _kaynak = _materyal_bul(hedef)
        if not mat:
            return None
        hy = mat.get("hedef_yuva")
        if hy is not None and hy[0] == 0:
            return None                    # hedefin kendisi taban kumas
        ts = (mat.get("cozulmus_yuvalar") or [None])[0]
        if not ts:
            return None
        taban_tid = ts["kanallar"].get(TS_DIFFUSE)
        if taban_tid is None:
            return None
        s = _sahip_giris(taban_tid) or (ts["forge"], ts["giris"])
    tw, th = olcu or _hedef_olcu(hedef)
    try:
        _r, _d, mp = _tanim_ve_mipler(s[0], s[1], taban_tid)
    except Exception:
        return None
    t = _d["tanim"]
    lvl = _taban_mip_sec(tw, th, t["W"], t["H"], t["mipcount"])
    try:
        a, _t = M.mip_oku(s[0], s[1], taban_tid, lvl)
    except Exception:
        return None
    if M.cevirmeli(hedef):
        a = np.ascontiguousarray(a[::-1])
    return _olcekle_rgb(a[:, :, :3], tw, th)


def _tanim_ve_mipler(forge, giris, tex_id):
    ck = ("mipz", forge, giris, tex_id)
    if ck not in _ONBELLEK:
        import hkm_doku as HD
        _ONBELLEK[ck] = HD.mip_zinciri_oku(forge, giris, tex_id)
    return _ONBELLEK[ck]


def kompozit(hedef, desen_rgba=None):
    """Oyunda gorunen hali: lerp(taban_kumas x renk_kaplamasi, desen.rgb, desen.a).

    desen_rgba verilmezse hedefin vanilla lvl0'i KULLANICI YONUNDE okunur
    (`ship_motor.doku_dizisi` ile -- dikey cevirme kurali ORADA, burada TEKRAR
    UYGULANMAZ).  desen_rgba verilirse ZATEN kullanici yonundedir varsayilir
    (export/onizleme sablonu o yondedir), tekrar cevrilmez.

    -> (ndarray (H,W,3) uint8, bilgi)
       bilgi = {'tint', 'taban_var', 'kaynak', 'yol', ...}
       yol = 'kompozit' -> taban + tint + desen (tam formul)
             'rgb'      -> taban YOK (ya da hedef zaten taban), tint UYGULANDI
             'ham'      -> ne taban ne tint bulundu; desen RGB'si aynen (alfa atildi)
    """
    if desen_rgba is None:
        try:
            desen_rgba, _t = M.doku_dizisi(hedef, 0)
        except Exception as e:
            # ⚠️ Bu kusur BU MODULDE DEGIL, motorun altindaki `hkm_ortak.cipa_bul`da:
            # gomulu piksel havuzunun uzunluk cipasi icin `10000 < v` alt siniri var.
            # `Empty` hedefi (16x16 BC7, ic dosya 1.283 B) bu esigin ALTINDA kaliyor,
            # cipa None donuyor ve `hkm_doku.mip_zinciri_oku` cokuyor.
            # OLCULDU: 50 flag+sail hedefinin 1'i (yalniz `Empty`) bu yola giriyor.
            # Uydurma piksel dondurmuyoruz; cagirana sebebini soyluyoruz.
            raise RuntimeError(
                "vanilla desen okunamadi (%s): %r\n"
                "  sebep zinciri: hkm_ortak.cipa_bul 10.000 B alt sinirina takiliyor "
                "(kucuk doku). Bu ship_kompozit'in degil doku katmaninin sinirlamasi."
                % (hedef.get("anahtar"), e))
    d = np.asarray(desen_rgba)
    if d.ndim != 3 or d.shape[2] not in (3, 4):
        raise ValueError("desen_rgba (H,W,3|4) olmali, %s geldi" % (d.shape,))
    hh, ww = d.shape[:2]

    mat, kaynak = _materyal_bul(hedef)
    tint = renk_kaplamasi(hedef)
    taban = taban_kumas(hedef, olcu=(ww, hh))

    bilgi = {"tint": tint, "taban_var": taban is not None, "kaynak": kaynak,
             "yol": None, "sablon": None if not mat else "0x%X" % mat["sablon"],
             "hedef_yuva": None if not mat else mat.get("hedef_yuva"),
             "taban_fid": None, "cevrildi": bool(M.cevirmeli(hedef)),
             "olcu": (ww, hh), "uyari": []}
    if mat:
        ts0 = (mat.get("cozulmus_yuvalar") or [None])[0]
        if ts0 and ts0["kanallar"].get(TS_DIFFUSE):
            bilgi["taban_fid"] = "0x%X" % ts0["kanallar"][TS_DIFFUSE]

    if tint is None:
        bilgi["uyari"].append("ColorOverlay OKUNAMADI -> tint uygulanmadi (notr degil, YOK)")
    if taban is None:
        if mat and mat.get("hedef_yuva") and mat["hedef_yuva"][0] == 0:
            bilgi["uyari"].append("hedef materyalin YUVA 0'i, yani taban kumasin KENDISI")
        else:
            bilgi["uyari"].append("taban kumas (yuva 0 DiffuseMap) coozulemedi")
    # ⚠️ tint materyale ait, dokuya DEGIL. Paylasimli tabanlarda (Base_01'i 20
    # materyal kullaniyor; MT_Hunter'da tint (161,19,19), MIT_Spanish'te notr)
    # hangi materyalin secildigi sonucu degistirir -- cagiran bilsin.
    if len(hedef.get("materyaller") or []) > 1 and (
            not mat or not mat.get("hedef_yuva") or mat["hedef_yuva"][0] == 0):
        bilgi["uyari"].append(
            "bu doku %d materyal tarafindan kullaniliyor; tint SECILEN materyale ait "
            "(%s) ve digerlerinde FARKLI olabilir"
            % (len(hedef["materyaller"]), kaynak))

    if taban is not None and tint is not None:
        zemin = taban.astype(np.float32) * np.asarray(tint[:3], np.float32)[None, None, :]
        bilgi["yol"] = "kompozit"
    elif taban is not None:
        zemin = taban.astype(np.float32)
        bilgi["yol"] = "rgb"
    elif tint is not None:
        zemin = d[:, :, :3].astype(np.float32) * np.asarray(tint[:3], np.float32)[None, None, :]
        bilgi["yol"] = "rgb"
    else:
        bilgi["yol"] = "ham"
        return np.ascontiguousarray(d[:, :, :3].astype(np.uint8)), bilgi

    if d.shape[2] == 4 and taban is not None:
        a = (d[:, :, 3].astype(np.float32) / 255.0)[:, :, None]
        out = zemin * (1.0 - a) + d[:, :, :3].astype(np.float32) * a
    elif d.shape[2] == 4:
        out = zemin                       # zemin zaten desenden turetildi
    else:
        bilgi["uyari"].append("desen ALFASIZ geldi -> maske yok, desen tam kapladi")
        out = d[:, :, :3].astype(np.float32)
    bilgi["ort"] = tuple(round(float(x), 4) for x in out.reshape(-1, 3).mean(axis=0))
    return np.clip(out + 0.5, 0, 255).astype(np.uint8), bilgi


# ================================================================ ek yardimcilar
def kompozit_png(hedef, png_yolu, desen_rgba=None):
    """kompozit()'i PNG olarak yaz (ALFASIZ RGB -> hicbir goruntuleyici siyaha bindiremez)."""
    a, bilgi = kompozit(hedef, desen_rgba)
    os.makedirs(os.path.dirname(os.path.abspath(png_yolu)) or ".", exist_ok=True)
    Image.fromarray(a, "RGB").save(png_yolu)
    bilgi["yol_png"] = png_yolu
    return bilgi


def materyal_bilgi(hedef):
    """Teshis: hedefin materyali + yuvalari + butun parametreleri (adlariyla)."""
    mat, kaynak = _materyal_bul(hedef)
    if not mat:
        return {"kaynak": kaynak, "mat": None}
    par = {}
    for crc, (tip, v) in (mat.get("param") or {}).items():
        par[PARAM_ADLARI.get(crc, "crc:0x%08X" % crc)] = [round(float(x), 6) for x in v]
    yuv = []
    for i, (var, ref) in enumerate(mat["yuvalar"]):
        ts = (mat.get("cozulmus_yuvalar") or [None] * 16)[i]
        yuv.append({"i": i, "var": var == 1, "ts": "0x%X" % ref,
                    "kanallar": None if not ts else
                    {k: "0x%X" % v for k, v in sorted(ts["kanallar"].items())}})
    return {"kaynak": kaynak, "fid": "0x%X" % mat["fid"], "forge": mat["forge"],
            "giris": "0x%X" % mat["giris"], "sablon": "0x%X" % mat["sablon"],
            "govde_len": mat["govde_len"], "yuvalar": yuv,
            "hedef_yuva": mat.get("hedef_yuva"), "param": par}


# ================================================================ KENDINI SINA
def _kendini_sina():
    import json
    sys.stdout.reconfigure(encoding="utf-8")
    kok = os.path.dirname(os.path.abspath(__file__))
    ornek_kl = os.path.join(kok, "ornekler")
    kat = M.katalog()

    def hbul(a):
        return M.hedef_bul(a, kat)

    gecti = []; kaldi = []

    def kapi(ad, ok, ayrinti=""):
        (gecti if ok else kaldi).append(ad)
        print("  %s %-46s %s" % ("OK    " if ok else "FAILED", ad, ayrinti))

    print("=" * 78)
    print("A) BEKLENEN SABITLER (onceki turun sayilari -- kendi olcumum kazanir)")
    print("=" * 78)

    # --- MT_Hunter katalogda HEDEF DEGIL; materyali ADLA cozulur.
    print("  not: MT_Hunter katalogda hedef DEGIL (11 flag hedefi arasinda yok).")
    print("       Materyali `OBD_SHP_Flag_MT_Hunter_01A_2S_AT`; Base_01'in")
    print("       `materyaller` listesinden gelir. Sahte bir hedef sozlugu ile okunur.")
    b01 = hbul("Base_01")
    hunter = dict(b01)
    hunter["anahtar"] = "_MT_Hunter_(sahte)"
    hunter["materyaller"] = ["OBD_SHP_Flag_MT_Hunter_01A_2S_AT"]
    hunter["kapsayici_sinif"] = "TextureSet"

    def rgb255(t):
        return None if t is None else tuple(round(x * 255.0, 4) for x in t[:3])

    bekle = [
        ("_MT_Hunter_(sahte)", hunter, (0.631373, 0.074510, 0.074510), (161, 19, 19)),
        ("PT_Ranger_01", hbul("PT_Ranger_01"), (0.101961, 0.098039, 0.094118), (26, 25, 24)),
        ("MT_British_01", hbul("MT_British_01"), (1.0, 1.0, 1.0), (255, 255, 255)),
        ("Emblem_MIT_Spanish_01", hbul("Emblem_MIT_Spanish_01"), (1.0, 1.0, 1.0), (255, 255, 255)),
    ]
    for ad, h, bek, bek255 in bekle:
        t = renk_kaplamasi(h)
        ok = t is not None and all(abs(t[i] - bek[i]) < 1e-6 for i in range(3))
        r255 = rgb255(t)
        ok255 = r255 is not None and all(abs(r255[i] - bek255[i]) < 0.01 for i in range(3))
        kapi("tint %s" % ad, ok and ok255,
             "olculen=%s -> RGB255=%s | beklenen=%s / %s"
             % (None if t is None else ["%.6f" % x for x in t[:3]], r255,
                ["%.6f" % x for x in bek], bek255))

    # --- PT_Pirate_01 kompozit ortalamalari
    pp = hbul("PT_Pirate_01")
    kom, bil = kompozit(pp)
    ort = np.asarray(kom, np.float64).reshape(-1, 3).mean(axis=0)
    tb = taban_kumas(pp)
    tint = renk_kaplamasi(pp)
    bez = np.asarray(tb, np.float64) * np.asarray(tint[:3])
    bez_ort = bez.reshape(-1, 3).mean(axis=0)
    kapi("PT_Pirate_01 bez alani ~ (22.6, 21.0, 19.2)",
         all(abs(bez_ort[i] - v) < 1.0 for i, v in enumerate((22.6, 21.0, 19.2))),
         "olculen=(%.2f, %.2f, %.2f)" % tuple(bez_ort))
    kapi("PT_Pirate_01 kompozit ort ~ (37.1, 34.4, 31.3)",
         all(abs(ort[i] - v) < 1.0 for i, v in enumerate((37.1, 34.4, 31.3))),
         "olculen=(%.2f, %.2f, %.2f)" % tuple(ort))

    # --- taban yon kapisi (cevirme SAYIYLA)
    print()
    print("=" * 78)
    print("B) YON KAPISI  (cevirme kurali bir kez ve TEK yerde)")
    print("=" * 78)
    s = _sahip_giris(0x218240AFF52)
    a0, _t = M.mip_oku(s[0], s[1], 0x218240AFF52, 0)
    ust = float(a0[: a0.shape[0] // 2, :, :3].mean())
    alt = float(a0[a0.shape[0] // 2:, :, :3].mean())
    tb_c = taban_kumas(pp)
    tb_h = _olcekle_rgb(np.ascontiguousarray(a0[:, :, :3]), *_hedef_olcu(pp))
    d_cev = float(np.abs(tb_c.astype(np.int16) - tb_h.astype(np.int16)).mean())
    # ⚠️ CURUTULEN KENDI HIPOTEZIM: "yarim ortalamalar ayrisir" kapisi COKTU
    #    (fark yalniz 0,9532). Yerine PIKSEL BASINA fark kapisi kondu.
    print("  not: Base_01 lvl0 yarim ortalamalari %.4f / %.4f -> fark %.4f."
          % (ust, alt, abs(ust - alt)))
    print("       Bu KUCUK; yanlis cevirme ortalama parlaklikla YAKALANMAZ.")
    kapi("cevirme PIKSEL duzeyinde onemli (>1 gri seviye)", d_cev > 1.0,
         "cevrilmis ile ham arasi piksel basina ort |fark| = %.4f" % d_cev)
    kapi("Base_01 katalog hedefi de cevirmeli (TEK kural, ayni fonksiyon)",
         M.cevirmeli(b01) and M.cevirmeli(pp),
         "cevirmeli(Base_01)=%s cevirmeli(PT_Pirate_01)=%s grup=%s"
         % (M.cevirmeli(b01), M.cevirmeli(pp), b01.get("grup")))

    # --- iki AYRI taban kumas gercekten farkli mi? (onceki turun iddiasi)
    jp = hbul("PT_Jackdaw_Pirate_01")
    tb_j = taban_kumas(jp)
    o1 = tb_c.reshape(-1, 3).mean(axis=0); o2 = tb_j.reshape(-1, 3).mean(axis=0)
    dp = float(np.abs(tb_c.astype(np.int16) - tb_j.astype(np.int16)).mean())
    kapi("PT_Jackdaw_Pirate_01 tabani AYRI doku (Streamer_Base_01)",
         dp > 1.0 and not (tb_c == tb_j).all(),
         "Flag_Base_01 ort=(%.2f,%.2f,%.2f) | Streamer_Base_01 ort=(%.2f,%.2f,%.2f) "
         "| piksel ort |fark|=%.4f" % (o1[0], o1[1], o1[2], o2[0], o2[1], o2[2], dp))
    print("  ⚠️ CURUTME: onceki tur \"Streamer tabani -> zemin rengi digerlerinden")
    print("     FARKLI\" demis. Doku gercekten ayri (piksel |fark| %.2f) ama ORTALAMA" % dp)
    print("     RENK neredeyse ayni (%.2f vs %.2f, %%%.3f). Gorunur farki yapan sey"
          % (o1.mean(), o2.mean(), abs(o1.mean() - o2.mean()) / o1.mean() * 100))
    print("     TABAN degil TINT: (26,25,24) yerine (35.7,34.3,33).")

    # --- alfa-agirlikli resize tuzagi
    print()
    print("=" * 78)
    print("C) OLCEKLEME DISIPLINI  (alfa-agirlikli PIL resize tuzagi)")
    print("=" * 78)
    van, _t = M.doku_dizisi(pp, 0)
    yanlis = np.asarray(Image.fromarray(van, "RGBA").resize((256, 128), Image.LANCZOS))
    dogru = _olcekle_rgb(van[:, :, :3], 256, 128)
    kapi("RGBA resize RGB'yi cokertiyor, _olcekle_rgb cokertmiyor",
         float(dogru.mean()) > float(yanlis[:, :, :3].mean()) * 3,
         "lvl0 RGB ort=%.4f | RGBA-resize=%.4f | _olcekle_rgb=%.4f (alfa ort=%.2f)"
         % (van[:, :, :3].mean(), yanlis[:, :, :3].mean(), dogru.mean(),
            van[:, :, 3].mean()))

    # --- tam tablo
    print()
    print("=" * 78)
    print("D) TABLO -- 11 flag + 39 sail hedefi")
    print("=" * 78)
    print("  %-24s %-5s %-26s %-6s %-9s %-22s %s"
          % ("anahtar", "grup", "tint(RGB255)", "taban", "yol", "kompozit ort RGB", "yuva"))
    tablo = []
    for h in kat["hedefler"]:
        if h.get("grup") not in ("flag", "sail"):
            continue
        try:
            kom, bil = kompozit(h)
            o = np.asarray(kom, np.float64).reshape(-1, 3).mean(axis=0)
            t = bil["tint"]
            satir = {"anahtar": h["anahtar"], "grup": h["grup"],
                     "tint": None if t is None else tuple(round(x * 255, 1) for x in t[:3]),
                     "taban_var": bil["taban_var"], "yol": bil["yol"],
                     "ort": tuple(round(float(x), 1) for x in o),
                     "yuva": bil["hedef_yuva"], "kaynak": bil["kaynak"],
                     "uyari": bil["uyari"]}
        except Exception as e:
            satir = {"anahtar": h["anahtar"], "grup": h["grup"], "hata": repr(e)}
        tablo.append(satir)
        if "hata" in satir:
            print("  %-24s %-5s HATA %s" % (satir["anahtar"], satir["grup"], satir["hata"]))
        else:
            print("  %-24s %-5s %-26s %-6s %-9s %-22s %s"
                  % (satir["anahtar"], satir["grup"], str(satir["tint"]),
                     "VAR" if satir["taban_var"] else "yok", satir["yol"],
                     str(satir["ort"]), satir["yuva"]))
    hatali = [s["anahtar"] for s in tablo if "hata" in s]
    kapi("49/50 hedefte kompozit URETILDI (`Empty` MOTOR sinirlamasi)",
         hatali == ["Empty"] or hatali == [],
         "uretilemeyen: %s -- sebep hkm_ortak.cipa_bul'un 10.000 B alt siniri, "
         "16x16 doku esigin altinda (bu modulun kusuru DEGIL)" % hatali)
    kapi("11/11 flag hedefinde tint OKUNDU",
         all(s.get("tint") is not None for s in tablo if s["grup"] == "flag"),
         "tintsiz: %s" % [s["anahtar"] for s in tablo
                          if s["grup"] == "flag" and s.get("tint") is None])
    say = sum(1 for s in tablo if s["grup"] == "sail" and s.get("yol") == "kompozit")
    kapi("en az 5 sail hedefinde TAM kompozit", say >= 5, "tam kompozit sail = %d" % say)

    # --- ornek PNG'ler
    print()
    print("=" * 78)
    print("E) ORNEK PNG (en fazla 6)")
    print("=" * 78)
    ornekler = ["PT_Pirate_01", "PT_Jackdaw_Pirate_01", "PT_QAR_01",
                "MT_British_01", "PT_TheRevenge_01", "emblem_BlackSkull"]
    yollar = []
    for a in ornekler:
        h = hbul(a)
        p = os.path.join(ornek_kl, "%s.png" % a)
        bil = kompozit_png(h, p)
        van, _t = M.doku_dizisi(h, 0)
        ham = os.path.join(ornek_kl, "%s__HAM_RGBA_karsilastirma.png" % a)
        Image.fromarray(van, "RGBA").save(ham)
        yollar.append(p)
        print("  %-24s -> %s  (yol=%s tint=%s alfa_ort=%.1f)"
              % (a, p, bil["yol"],
                 None if bil["tint"] is None else ["%.4f" % x for x in bil["tint"][:3]],
                 van[:, :, 3].mean()))

    # kuru kafa kapisi: alfa maskesi geciren piksel ile zemin AYRISIYOR mu?
    h = hbul("PT_Pirate_01")
    van, _t = M.doku_dizisi(h, 0)
    kom, _b = kompozit(h)
    mask = van[:, :, 3] > 200
    zem = van[:, :, 3] < 40
    kapi("kuru kafa artik ZEMIN uzerinde (zemin siyah DEGIL)",
         float(kom[zem].mean()) > 8.0,
         "maskeli piksel ort=%.2f | zemin piksel ort=%.2f | zemin piksel orani=%.4f"
         % (kom[mask].mean(), kom[zem].mean(), zem.mean()))

    json.dump(tablo, open(os.path.join(kok, "dogrulama_tablosu.json"), "w",
                          encoding="utf-8"), ensure_ascii=False, indent=1)
    print()
    print("=" * 78)
    print("SONUC: %d gecti / %d kaldi" % (len(gecti), len(kaldi)))
    if kaldi:
        print("KALAN: %s" % kaldi)
    print("tablo json: %s" % os.path.join(kok, "dogrulama_tablosu.json"))
    return len(kaldi) == 0


if __name__ == "__main__":
    sys.exit(0 if _kendini_sina() else 1)
