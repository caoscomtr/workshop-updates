# Ship Workshop motoru (build/ship_vendor.py uretir; elle duzenleme)
