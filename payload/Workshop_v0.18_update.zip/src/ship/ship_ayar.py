# -*- coding: utf-8 -*-
"""SHIP WORKSHOP - settings: where the game is installed.

Not everyone owns the game through Steam. The path is therefore:
  1. read from a saved setting, otherwise
  2. auto-detected (default location + every Steam library folder), otherwise
  3. chosen by the user in the GUI / with `ship_cli.py game <path>`.

A folder is only accepted after it is VERIFIED, not merely found:
  * `DataPC_boot.forge` exists and starts with the `scimitar\\0` magic
  * its own table of contents is readable
  * sampled entries have exactly the lengths recorded in the catalogue

⚠️ ESKI GEREKCE BAYATTI, DUZELTILDI (2026-07-31, olculdu):
Burada eskiden "katalog BAYT OFSETLERI tasir, farkli bir surumde yazma yanlis yere
duser" yaziyordu. `ship_hedefler.json`da **tek bir ofset anahtari YOK** (242 hedef,
36 anahtar, `off` sayisi = 0). Yazma guvenligi parmak izinden GELMIYOR: her yazma
ofsetleri CANLI TOC'tan cozer ve uyusmazlikta hedef bazinda reddeder
(`ship_yerinde.uygula` TOC indeksi + uzunluk kapisi, `yazma_kapisi`, revert sha kapisi).
Parmak izi bu yuzden bir EK guvence; tek basina yazmanin dayanagi degil.
Ayrica parmak izinin 40 girisinin 40'i da aracin KENDI yazdigi kapsayicilar --
yani kullanici yamaladikca sapma NORMALDIR ve affetme kayit deposundan gelir.
Depo okunamazsa suc oyunda degil depodadir; `dogrula` artik bunu ayirt eder.
"""
import os, sys, json, struct, tempfile, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
_HKM = os.path.dirname(os.path.abspath(__file__))
if _HKM not in sys.path:
    sys.path.insert(0, _HKM)
import hkm_ortak as H   # noqa: E402

# UZMAN MODU (bkz. src/uzman.py). src/ bu dosyanin BIR UST klasorunun ustudur.
_SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)
import uzman as UZ      # noqa: E402

def veri_kok():
    """Kayit + ayar deposunun koku. **ASLA TEMP'e dusmez.**

    🔴 KOK SEBEP (2026-07-31, kaptanin ekraninda goruldu, BIREBIR YENIDEN URETILDI):
    Bu satir eskiden soyleydi ve DORT ayri dosyada kopyalanmisti:
        os.environ.get("LOCALAPPDATA", tempfile.gettempdir())
    `LOCALAPPDATA` ortam degiskeni bulunmayan bir baslatma yolunda depo
    `%TEMP%\\ACBFR_Modding`a kayiyor -> orada hicbir kayit YOK -> iki sonuc:

    1. `_kendi_yamalarimiz()` BOS harita donuyor -> kullanicinin KENDI yamalari
       "surum uyusmazligi" sayiliyor -> arac kullanicinin oyununu REDDEDIYOR.
       Yeniden uretildi: `LOCALAPPDATA` kaldirilinca cikan mesaj kaptanin
       ekran goruntusuyle KELIMESI KELIMESINE ayni:
         "4 of 40 sampled entries differ ... first mismatch: 0x20A41D43103
          expected 59703 B, found 103720 B"
    2. ⚠️ COK DAHA AGIRI: `ship_yerinde.VERI_KOK` de ayni satiri kullaniyordu,
       yani ORIJINAL BAYTLARIN YEDEGI de %TEMP%'e yaziliyordu. Windows Disk
       Temizleme / Storage Sense TEMP'i siler -> Revert SONSUZA KADAR imkansiz,
       kullanicinin oyunu geri donusu olmadan yamali kalir. Bu bir VERI KAYBI
       yoludur, sadece bir rahatsizlik degil.

    Cozum: tek cozucu + TEMP YASAK. Cagri aninda cozulur (import aninda degil),
    boylece ortam sonradan duzelirse arac kendini toparlar.
    """
    # ⚠️ ACIKCA AYARLANMIS `LOCALAPPDATA`ya KOSULSUZ saygi duyulur. Tehlike
    # "TEMP'in kendisi" degil, degisken YOKKEN sessizce TEMP'e DUSMEK.
    # (Ilk yazdigim surum TEMP altindaki her yolu eliyordu ve `test_dogrulama`
    #  D6'yi dusurdu: o test sahte kayit deposunu `mkdtemp()` ile kuruyor ve
    #  LOCALAPPDATA'yi oraya isaret ettiriyor -- tamamen mesru. Kapi hakliydi.)
    la = os.environ.get("LOCALAPPDATA")
    if la:
        return os.path.join(la, "ACBFR_Modding")

    # Buradan asagisi GERI DUSUS: burada TEMP kabul EDILMEZ.
    gecici = os.path.normcase(os.path.abspath(tempfile.gettempdir()))
    adaylar = []
    up = os.environ.get("USERPROFILE")
    if up:
        adaylar.append(os.path.join(up, "AppData", "Local"))
    ev = os.path.expanduser("~")
    if ev and ev != "~":
        adaylar.append(os.path.join(ev, "AppData", "Local"))
        adaylar.append(ev)
    for a in adaylar:
        try:
            if not a or not os.path.isdir(a):
                continue
            if os.path.normcase(os.path.abspath(a)).startswith(gecici):
                continue                       # geri dususte TEMP ASLA
            return os.path.join(a, "ACBFR_Modding")
        except OSError:
            continue
    # Hicbiri yoksa bile TEMP'e DUSMEYIZ: ev dizini her zaman vardir.
    return os.path.join(os.path.expanduser("~") or ".", "ACBFR_Modding")


AYAR_KOK = veri_kok()
AYAR_YOLU = os.path.join(AYAR_KOK, "ship_workshop_ayar.json")
ANA_FORGE = "DataPC_boot.forge"
# the game folder must contain all of these
GEREKLI = [ANA_FORGE, "DataPC_boot_patch_01.forge", "DataPC_shared_00.forge"]


# ---------------------------------------------------------------- settings file
def oku():
    try:
        return json.load(open(AYAR_YOLU, encoding="utf-8"))
    except Exception:
        return {}


def yaz(d):
    os.makedirs(AYAR_KOK, exist_ok=True)
    fd, gec = tempfile.mkstemp(dir=AYAR_KOK, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1, ensure_ascii=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(gec, AYAR_YOLU)
    return AYAR_YOLU


KATALOG_JSON = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "katalog", "ship_hedefler.json")
_PI = None


def parmak_izi():
    """(fid, len) ciftleri: bu aracin tanidigi oyun surumunun imzasi.
    Katalog JSON'una gomulu gelir -> 145 MB'lik katalog.db pakete girmez."""
    global _PI
    if _PI is None:
        try:
            d = json.load(open(KATALOG_JSON, encoding="utf-8"))
            _PI = [(int(a, 16), b) for a, b in d["_meta"].get("parmak_izi", [])]
        except Exception:
            _PI = []
    return _PI


# ---------------------------------------------------------------- verification
def _kendi_yamalarimiz():
    """Bizim YERINDE yazmalarimiz: {giris_fid: {(orijinal_len, yeni_len), ...}}

    `ship_yerinde` IMPORT EDILMEZ (dairesel import riski): kayit dosyalari
    dogrudan okunur. Kayit yoksa bos sozluk -> dogrulama eskisi gibi kati davranir.
    Yalniz `uygulandi` / `in_progress` kayitlari sayilir; `geri_alindi` olanlarda
    giris zaten orijinal uzunluguna dondurulmustur.
    """
    kok = veri_kok()          # ⛔ TEMP'e dusen eski satir icin bkz. `veri_kok()`
    out = {}
    _DEPO.update({"kok": kok, "okundu": True, "atlanan": 0, "sebep": None})
    try:
        klasorler = os.listdir(kok)
    except FileNotFoundError:
        # Depo HIC KURULMAMIS -> mesru (ilk kullanici, hic yama yapmamis).
        # Bos harita DOGRU cevap; kimseyi suclamiyoruz.
        _DEPO["sebep"] = "store has never been created"
        return out
    except OSError as e:
        # Depo VAR ama OKUNAMADI (izin, kilit, gecici hata). Bu BOS DEMEK DEGIL.
        # 🔴 Eski kod ikisini ayirmiyordu: okunamayan depo -> bos harita ->
        # kullanicinin KENDI yamalari "surum uyusmazligi" sayiliyor -> arac
        # kullaniciya OYUNUN YANLIS diye YALAN soyluyordu.
        _DEPO.update({"okundu": False, "sebep": repr(e)})
        return dict(_SON_IYI)          # son BASARILI haritaya tutun
    for d in klasorler:
        kd = os.path.join(kok, d)
        # ⚠️ Kok klasorde DOSYALAR da var (`ship_workshop_ayar.json`, kardes
        # araclarin ayarlari). Onlari `os.listdir`e vermek NotADirectoryError
        # firlatir ve "depo okunamadi" YANLIS ALARMI uretir -- ilk yazdigimda
        # tam bunu yaptim ve her tarama "okundu=False" dedi.
        if not os.path.isdir(kd):
            continue
        try:
            adlar = os.listdir(kd)
        except OSError as e:
            _DEPO["atlanan"] += 1
            _DEPO["okundu"] = False
            _DEPO["sebep"] = repr(e)
            continue
        for ad in adlar:
            if not (ad.startswith("ship_") and ad.endswith(".json")):
                continue
            k = None
            for _deneme in range(3):
                try:
                    with open(os.path.join(kd, ad), encoding="utf-8") as f:
                        k = json.load(f)
                    break
                except PermissionError:
                    # Windows paylasim ihlali: kayit `os.replace` ile yazilirken
                    # okumaya calistik. GECICI -> kisa bekleyip yeniden dene.
                    # (Olculdu: 3473 taramada 204 yutulmus PermissionError.)
                    time.sleep(0.03)
                except (OSError, ValueError) as e:
                    _DEPO["atlanan"] += 1
                    _DEPO["okundu"] = False
                    _DEPO["sebep"] = repr(e)
                    break
            if k is None:
                _DEPO["atlanan"] += 1
                _DEPO["okundu"] = False
                _DEPO.setdefault("sebep", "record could not be read")
                continue
            if k.get("durum") not in ("uygulandi", "in_progress"):
                continue
            g = k.get("giris") or {}
            if g.get("len") is None or g.get("yeni_len") is None:
                continue                      # saf yerinde yazma: uzunluk degismez
            try:
                fid = int(str(k.get("kapsayici")), 16)
                out.setdefault(fid, set()).add((int(g["len"]), int(g["yeni_len"])))
            except (TypeError, ValueError):
                continue
    # ⭐ GERILEME KORUMASI: bir tarama daha ONCE gordugumuzden AZ yama buluyorsa,
    # depo kismen okunamamis demektir. Kaybolan girisleri son iyi haritadan
    # tamamla -- yoksa kullanicinin gercekten duran bir yamasi "surum
    # uyusmazligi" sayilir ve arac onu kendi oyunundan kilitler.
    # (Yalnizca EKLER; hicbir zaman uydurma cift URETMEZ -- her cift bir zamanlar
    #  diskte okunmus gercek bir kayittan gelmistir.)
    if _SON_IYI and not _DEPO.get("okundu", True):
        for fid, ciftler in _SON_IYI.items():
            out.setdefault(fid, set()).update(ciftler)
    if _DEPO.get("okundu"):
        _SON_IYI.clear()
        _SON_IYI.update({f: set(v) for f, v in out.items()})
    return out


def dogrula(klasor, ornek=25):
    """-> (ok, message, info).  Never writes; opens the forge read-only."""
    if not klasor or not os.path.isdir(klasor):
        return False, "folder does not exist", {}
    eksik = [f for f in GEREKLI if not os.path.exists(os.path.join(klasor, f))]
    if eksik:
        return False, "missing game file(s): %s" % ", ".join(eksik), {}

    yol = os.path.join(klasor, ANA_FORGE)
    try:
        with open(yol, "rb") as f:
            bas = f.read(64)
            if bas[:9] != b"scimitar\x00":
                return False, "%s is not a forge archive (bad signature)" % ANA_FORGE, {}
            surum = struct.unpack_from("<I", bas, 9)[0]
            hoff = struct.unpack_from("<q", bas, 13)[0]
            f.seek(hoff)
            n, tocpos = struct.unpack("<Iq", f.read(12))
            f.seek(tocpos)
            toc = f.read(n * 24)
        # 🧨 TOC AYRISTIRMASI ESKIDEN try DISINDAYDI (2026-07-31'de yakalandi):
        # kesik ya da bozuk bir arsivde `struct.error` HAM haliyle disari
        # firliyordu -- kullaniciya "unpack_from requires a buffer of at least
        # 24 bytes" gibi anlamsiz bir mesaj. Artik temiz bir RED donuyor.
        if len(toc) < n * 24:
            return False, ("%s is truncated or corrupt: table of contents needs "
                           "%d B, only %d B could be read"
                           % (ANA_FORGE, n * 24, len(toc))), {}
        kendi = {}
        for i in range(n):
            off, fid, ln, ext = struct.unpack_from("<QQII", toc, i * 24)
            kendi[fid] = ln
    except Exception as e:
        return False, "could not read %s: %r" % (ANA_FORGE, e), {}

    # --- does this installation match the catalogue the tool was built from?
    # PARMAK IZI: (fid, len) ciftleri katalog JSON'unda gomulu gelir; boylece
    # 145 MB'lik katalog.db pakete girmez. Yoksa dogrulama atlanir (uyari ile).
    sec = parmak_izi()
    if not sec:
        return True, ("forge signature ok, %d entries (no fingerprint to "
                      "cross-check against)" % n), {"klasor": klasor, "giris": n}
    # 🧨 OLCULMUS TUZAK (2026-07-30, kaptanin makinesinde CANLI yasandi):
    # Parmak izi (fid, UZUNLUK) ciftleri. Gomulu havuz yazmasi girisi yeniden
    # paketleyip dosya sonuna ekliyor -> o girisin UZUNLUGU DEGISIYOR. Ornek 40
    # giristen biri yamaladigimiz bir hedefse dogrulama duser ve arac
    #   "this installation does not match the catalogue (3 of 40 differ)"
    # diyerek KULLANICININ KENDI OYUNUNU REDDEDER. Yani birkac hedef yamalayan
    # herkes araci bir daha acamazdi. (Kaptanda 11 yama sonrasi tam bu oldu.)
    # ⛔ Cozum "farki gormezden gel" DEGIL -- o, gercek surum uyusmazligini da
    # susturur ve yazma yanlis baytlara duser. Yalnizca KENDI KAYDIMIZLA
    # KANITLANABILEN degisim affedilir: kayit hem ORIJINAL hem YENI uzunlugu
    # tutuyor; canli uzunluk 'yeni', katalogdaki 'orijinal' ise bu BIZIM yamamizdir.
    yamalar = _kendi_yamalarimiz()
    uyan = bizim = 0
    sapan = []
    for fid, ln in sec:
        canli = kendi.get(fid)
        if canli == ln:
            uyan += 1
        elif any(o == ln and y == canli for o, y in yamalar.get(fid, ())):
            uyan += 1
            bizim += 1                     # bizim yamamiz, surum uyusmazligi DEGIL
        else:
            sapan.append((fid, ln, canli))
    bilgi = {"klasor": klasor, "surum": surum, "giris": n, "boyut": os.path.getsize(yol),
             "ornek": len(sec), "uyan": uyan, "bizim_yamamiz": bizim,
             "sapan_fid": [f for f, _l, _c in sapan],
             "depo_okundu": _DEPO.get("okundu", True),
             "depo_atlanan": _DEPO.get("atlanan", 0), "depo_kok": _DEPO.get("kok")}
    if uyan < len(sec):
        # ══════════════════════════════════════════════════════════════════
        # 🔴 KAPI YANLIS YERDEYDI (2026-07-31, kaptan dort kez ayni hatayi gordu)
        # ══════════════════════════════════════════════════════════════════
        # Eskiden burada `return False` vardi: parmak izinden TEK bir giris
        # sapsa BUTUN KLASOR reddediliyordu. Uc olculmus gercek bunu curutuyor:
        #
        # 1. Parmak izinin 40 girisinin **40'i da aracin KENDI YAZDIGI**
        #    kapsayicilar. Yani kullanici yamaladikca sapma NORMALDIR; kapinin
        #    olcusu, kapinin korumaya calistigi seyle AYNI degisken kaynaktan
        #    geliyordu. Kaptanda 7 giris yamaliydi ve arac onu kendi oyunundan
        #    kilitledi.
        # 2. **Yazma guvenligi bu kapidan GELMIYOR** (olculdu): katalogda tek bir
        #    bayt ofseti YOK (242 hedef / 36 anahtar / `off` = 0). Her yazma
        #    ofsetleri CANLI TOC'tan cozuyor ve uyusmazlikta hedef bazinda
        #    reddediyor (`ship_yerinde`: TOC indeksi + uzunluk kapisi,
        #    `yazma_kapisi`, revert sha kapisi). Kapiyi kaldirmak guvenligi
        #    AZALTMIYOR.
        # 3. **Kardes araclar boyle bir kapi HIC KULLANMIYOR** (olculdu:
        #    Outfit/Sail/Flag'de parmak izi karsilastirmasi yok) ve onlar Steam
        #    disi platformlarda da calisiyor. Ship bunu sonradan icat etti.
        #
        # Yeni davranis: klasor KABUL EDILIR, sapma UYARI olur, ve yalnizca
        # SAPAN GIRISLERIN hedefleri yazmaya kapatilir (`sapan_fid`).
        # Boylece gercek bir surum uyusmazliginda da o girislere yazilmaz.
        if not _DEPO.get("okundu", True):
            return (True,
                    "WARNING: could not read this tool's own patch records, so "
                    "your own patches look like differences.\n"
                    "  record store: %s  (%d unreadable: %s)\n"
                    "  This is NOT a problem with your game. Writing stays "
                    "enabled; each write re-checks the live archive anyway."
                    % (_DEPO.get("kok"), _DEPO.get("atlanan", 0),
                       _DEPO.get("sebep")), bilgi)
        return (True,
                "WARNING: %d of %d sampled entries differ from the catalogue "
                "(another mod, or a different game build).\n"
                "  Writing stays enabled - every write re-reads the archive's own "
                "table of contents and refuses if anything moved. Targets inside "
                "the differing entries are locked.\n"
                "  first difference: 0x%X expected %s B, found %s B"
                % (len(sec) - uyan, len(sec), sapan[0][0], sapan[0][1],
                   sapan[0][2]), bilgi)
    return True, ("verified: %d entries, %d/%d sampled entries match%s"
                  % (n, uyan, len(sec),
                     "  (%d of them changed by your own patches)" % bizim
                     if bizim else "")), bilgi


# ---------------------------------------------------------------- auto-detect
def _steam_kutuphaneleri():
    kokler = []
    for taban in (os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                  os.environ.get("ProgramFiles", r"C:\Program Files"),
                  r"C:\Steam", os.path.expanduser(r"~\Steam")):
        if taban:
            kokler.append(os.path.join(taban, "Steam"))
    try:                                              # registry, if available
        import winreg
        for kok, yol in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
                         (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam")):
            try:
                with winreg.OpenKey(kok, yol) as k:
                    for ad in ("SteamPath", "InstallPath"):
                        try:
                            kokler.append(winreg.QueryValueEx(k, ad)[0])
                        except OSError:
                            pass
            except OSError:
                pass
    except Exception:
        pass

    kut = []
    for s in kokler:
        if not s or not os.path.isdir(s):
            continue
        kut.append(s)
        vdf = os.path.join(s, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf):
            try:
                metin = open(vdf, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            import re
            for m in re.finditer(r'"path"\s*"([^"]+)"', metin):
                kut.append(m.group(1).replace("\\\\", "\\"))
    return kut


def adaylar():
    """Possible game folders, most likely first, de-duplicated."""
    out, gorulen = [], set()

    def ekle(p):
        if not p:
            return
        p = os.path.normpath(p)
        if p.lower() in gorulen:
            return
        gorulen.add(p.lower())
        if os.path.isdir(p):
            out.append(p)

    ekle(oku().get("oyun"))
    ekle(H.OYUN)
    for k in _steam_kutuphaneleri():
        ekle(os.path.join(k, "steamapps", "common",
                          "Assassin's Creed Black Flag Resynced"))
    for surucu in "CDEFGH":
        for kalip in (r"{0}:\Program Files (x86)\Steam\steamapps\common\Assassin's Creed Black Flag Resynced",
                      r"{0}:\SteamLibrary\steamapps\common\Assassin's Creed Black Flag Resynced",
                      r"{0}:\Games\Assassin's Creed Black Flag Resynced",
                      r"{0}:\Assassin's Creed Black Flag Resynced"):
            ekle(kalip.format(surucu))
    return out


def bul():
    """First candidate that passes verification -> (path, message) or (None, reason)."""
    sebepler = []
    for p in adaylar():
        ok, mesaj, _b = dogrula(p)
        if ok:
            return p, mesaj
        sebepler.append("%s -> %s" % (p, mesaj))
    return None, ("no verified game folder found. Checked:\n  " +
                  "\n  ".join(sebepler) if sebepler else "no candidate folder found")


# ---------------------------------------------------------------- apply
# 🔴 YAYIN ENGELI (2026-07-31, kaptanin makinesinde CANLI yasandi):
# `dogrula` duserse `uygula` istisna atiyordu ve BASKA HICBIR YOL YOKTU --
# ne goz atma, ne onizleme, ne Export. Arac o kullanicida TAMAMEN oluyor,
# ekranda "[NOT VERIFIED]" yazan bos bir pencere kaliyordu.
# Kaptan bunu gecici bir okuma hatasiyla yasadi (ayni kurulum bir dakika sonra
# 8/8 dogrulandi), ama sebep ne olursa olsun -- farkli oyun surumu, baska bir
# aracin yamasi, silinmis kayit deposu -- sonuc ayni: kilitlenme.
#
# ⛔ COZUM "farki gormezden gel" DEGIL. Ayrim SU:
#     OKUMA  ('rb') hicbir seye zarar veremez  -> DOGRULANMASA DA SERBEST
#     YAZMA  ('r+b') yanlis bayta duserse oyunu bozar -> DOGRULAMA SART
# Bu yuzden dogrulanmamis klasor artik SALT-OKUNUR modda baglanir: kullanici
# gezebilir, onizleyebilir, PNG cikarabilir; Apply/Revert REDDEDILIR.
# Durum `ship_ayar.DOGRULAMA` uzerinden okunur (tek dogruluk kaynagi).
DOGRULAMA = {"ok": False, "mesaj": "not checked yet", "klasor": None}

# Kayit deposunun SON okuma durumu + son BASARILI harita.
# `_kendi_yamalarimiz()` bunlari doldurur; `dogrula()` "depo okunamadi" ile
# "gercekten farkli oyun surumu" arasini ayirmak icin okur.
_DEPO = {"kok": None, "okundu": True, "atlanan": 0, "sebep": None}
_SON_IYI = {}


def yazma_serbest():
    """Bu kurulama YAZMAK guvenli mi? (Apply/Revert bunu SORMAK ZORUNDA.)

    C5 POLITIKA (uzman modu): dogrulama DUSTUGUNDE bugun her yazma yolu reddeder.
    Bu bir VERI KAYBI kapisi degil, bir KANIT kapisidir -- yazma zaten canli TOC'tan
    cozer ve hedef bazinda reddeder (bkz. modul basligindaki 2026-07-31 duzeltmesi).
    Uzman modu ACIKKEN yazma serbesttir ve `yazma_uyarisi()` sebebi SOYLER.
    Giris bazli cerrahi kilit (`giris_kilitli`) ve `ship_yerinde`nin kendi TOC/uzunluk
    kapilari DEGISMEZ -- uzman modu onlara HIC dokunmaz."""
    if DOGRULAMA.get("ok"):
        return True
    return bool(UZ.kapi("dogrulanmamis_klasor"))


def yazma_uyarisi():
    """Uzman modu DOGRULANMAMIS bir klasore yazmayi actiysa gosterilecek uyari
    cumlesi; acmadiysa (ya da klasor zaten dogrulandiysa) None.

    Arayuz/cagiran bunu plandaki `uzman_uyarilari` listesine koyar; kaybolmamalidir."""
    if DOGRULAMA.get("ok") or not UZ.kapi("dogrulanmamis_klasor"):
        return None
    sebep = " ".join(str(DOGRULAMA.get("mesaj") or "no reason was recorded").split())
    return UZ.uyari("dogrulanmamis_klasor", sebep=sebep)


def giris_kilitli(giris_fid):
    """Bu ARSIV GIRISI parmak izinden sapiyor mu? -> o hedefe yazma.

    Klasorun tamamini reddetmek yerine CERRAHI kilit: yalnizca gercekten
    farkli olan girislerin hedefleri kapanir, gerisi calisir.
    """
    try:
        return int(giris_fid) in (DOGRULAMA.get("sapan_fid") or ())
    except (TypeError, ValueError):
        return False


def yazma_reddi():
    """Yazma neden reddediliyor -> kullaniciya gosterilecek metin."""
    return ("This game folder has NOT been verified, so writing is disabled.\n\n%s\n\n"
            "You can still browse, preview and export PNGs - reading cannot harm "
            "anything. To enable writing, use 'Change...' and pick a game folder "
            "this release knows, or reinstall/verify the game through Steam."
            % DOGRULAMA.get("mesaj", ""))


def uygula(klasor, kaydet=True, salt_okunur=False):
    """Point every engine at `klasor`.

    salt_okunur=False (default): verification MUST pass, otherwise raise.
    salt_okunur=True: wire the paths up even if verification fails, but mark the
    installation unverified so that every WRITE path refuses (`yazma_serbest`).
    """
    ok, mesaj, bilgi = dogrula(klasor)
    DOGRULAMA.update({"ok": bool(ok), "mesaj": mesaj, "klasor": klasor,
                      # Sapan girislerin hedefleri yazmaya KAPALI kalir.
                      # Klasorun tamamini reddetmek yerine cerrahi kilit.
                      "sapan_fid": set(bilgi.get("sapan_fid") or ())})
    if not ok and not salt_okunur:
        raise RuntimeError(mesaj)
    H.OYUN = os.path.normpath(klasor)
    try:                                   # dokulib is where hkm_ortak took it from
        H.D.GAME = H.OYUN
    except Exception:
        pass
    _TOC.clear()
    # 🧨 OLCULMUS TUZAK (2026-07-30): burada `bagimsizlik_kur()` CAGRILMIYORDU.
    # Yalniz `baslat()` cagiriyordu (:300/:306/:311), ama GUI'nin "Change..."
    # dugmesi ve CLI'nin `game` komutu dogrudan `uygula()`ya gelir. Sonuc: oyunu
    # varsayilan Steam yolunda OLMAYAN her kullanicida `H.giris_bul` yamalanmadan
    # kaliyor -> `hkm_ortak` 145 MB'lik katalog.db'yi ariyor -> pakette `sqlite3`
    # olmadigi icin her onizleme ve her Export
    #   AttributeError: 'NoneType' object has no attribute 'connect'
    # ile patliyor. Arac o kullanicida TAMAMEN calismiyordu.
    # Duzeltme burada, cagiranda degil: boylece hicbir yol atlanamaz.
    bagimsizlik_kur()
    if kaydet:
        d = oku(); d["oyun"] = H.OYUN; yaz(d)
    return mesaj, bilgi


def oyun_yolu():
    return H.OYUN


# ================================================================== katalog.db bagimsizligi
# `hkm_ortak` giris ofsetlerini 145 MB'lik `katalog.db`den okuyor. O dosya
# Nexus paketine konulamaz (ve bayatlayabilir). Asagidaki uc fonksiyon ayni
# bilgiyi FORGE'UN KENDI TOC'undan okur; katalog.db bir daha aranmaz.
_TOC = {}          # forge adi -> {fid: (off, len, ext)}


def toc(forge):
    t = _TOC.get(forge)
    if t is not None:
        return t
    yol = os.path.join(H.OYUN, forge)
    with open(yol, "rb") as f:
        bas = f.read(64)
        if bas[:9] != b"scimitar\x00":
            raise ValueError("not a forge: %s" % forge)
        hoff = struct.unpack_from("<q", bas, 13)[0]
        f.seek(hoff)
        n, tocpos = struct.unpack("<Iq", f.read(12))
        f.seek(tocpos)
        ham = f.read(n * 24)
    t = {}
    for i in range(n):
        off, fid, ln, ext = struct.unpack_from("<QQII", ham, i * 24)
        t[fid] = (off, ln, ext)
    _TOC[forge] = t
    return t


def _giris_bul(forge, fid):
    r = toc(forge).get(fid & 0xFFFFFFFFFFFFFFFF)
    return (r[0], r[1], r[2]) if r else None


def _mipler(forge, ana_fid):
    """Harici ham mip girisleri: fid'ler `mip_fid(tex, seviye)` ile turetilir,
    varliklari forge'un kendi TOC'undan dogrulanir."""
    t = toc(forge)
    out = []
    sev = 0
    while True:
        mid = H.mip_fid(ana_fid, sev)
        r = t.get(mid)
        if not r:
            break
        out.append((mid, sev, r[2], r[1], r[0]))
        sev += 1
    return out


def _mip_ham_oku(forge, mip_id):
    r = toc(forge).get(mip_id & 0xFFFFFFFFFFFFFFFF)
    if not r:
        raise KeyError("mip 0x%X is not in %s" % (mip_id, forge))
    off, ln, _e = r
    with open(os.path.join(H.OYUN, forge), "rb") as f:
        f.seek(off)
        return f.read(ln), off, ln


_ZINCIR_ADAYLAR = None


def _zincir_adaylari():
    """`zincir` taramasi icin ADAY forge listesi -- ONCELIK SIRALI.

    158 forge'un hepsinin TOC'unu taramak gereksiz ve pahali. Katalogdaki
    hedeflerin tamami `boot` ve `shared_00` ailelerinde yasiyor (olculdu:
    boot 155 · boot_patch_01 3 · shared_00 1). Liste elle YAZILMIYOR: bu iki
    aileye ait butun forge'lar diskten toplanip patch onceligine gore siralanir,
    boylece yarin bir `_patch_03` cikarsa kendiliginden dahil olur.
    """
    global _ZINCIR_ADAYLAR
    if _ZINCIR_ADAYLAR is not None:
        return _ZINCIR_ADAYLAR
    try:
        hepsi = [a for a in os.listdir(H.OYUN) if a.lower().endswith(".forge")]
    except OSError:
        return []
    aile = [a for a in hepsi
            if a.startswith("DataPC_boot") or a.startswith("DataPC_shared_00")]

    def oncelik(ad):
        # yuksek olan ONCE gelir: patch_02 > patch_01 > taban
        for n in range(9, 0, -1):
            if "_patch_%02d" % n in ad:
                return n
        return 0
    _ZINCIR_ADAYLAR = sorted(aile, key=lambda a: (-oncelik(a), a))
    return _ZINCIR_ADAYLAR


def _zincir(fid):
    """fid'in kopyalari: [(forge, off, len, ext)], patch onceligi sirali.

    🧨 `hkm_ortak.zincir` katalog.db'ye gidiyor ve pakette `sqlite3` YOK ->
    'NoneType' object has no attribute 'connect'. `bagimsizlik_kur` eskiden
    yalniz `giris_bul/mipler/mip_ham_oku`yu yamaliyordu; `zincir` gozden
    kacmisti ve `ship_kompozit` onu kullaniyor. Ayni P0 ailesi.
    Bulunamazsa BOS liste doner -- cagiran fail-closed davranir, uydurma yok.
    """
    fid &= 0xFFFFFFFFFFFFFFFF
    out = []
    for forge in _zincir_adaylari():
        try:
            r = toc(forge).get(fid)
        except Exception:
            continue
        if r:
            out.append((forge, r[0], r[1], r[2]))
    return out


def bagimsizlik_kur():
    """hkm_ortak'i katalog.db yerine canli TOC'a bagla (paket icin sart)."""
    H.giris_bul = _giris_bul
    H.mipler = _mipler
    H.mip_ham_oku = _mip_ham_oku
    H.zincir = _zincir          # ⭐ 2026-07-30: eksikti, ship_kompozit'i patlatiyordu
    _TOC.clear()
    global _ZINCIR_ADAYLAR
    _ZINCIR_ADAYLAR = None      # oyun klasoru degisebilir
    return True


def baslat(gunluk=None):
    """Called at start-up: apply the saved path, or auto-detect once."""
    kayitli = oku().get("oyun")
    if kayitli:
        ok, mesaj, _b = dogrula(kayitli)
        if ok:
            H.OYUN = os.path.normpath(kayitli)
            try:
                H.D.GAME = H.OYUN
            except Exception:
                pass
            _TOC.clear()
            DOGRULAMA.update({"ok": True, "mesaj": mesaj, "klasor": kayitli,
                              "sapan_fid": set(_b.get("sapan_fid") or ())})
            bagimsizlik_kur()
            return True, H.OYUN, mesaj
        if gunluk:
            gunluk("saved game folder is no longer valid: %s" % mesaj)
    ok, mesaj, _b = dogrula(H.OYUN)
    if ok:
        DOGRULAMA.update({"ok": True, "mesaj": mesaj, "klasor": H.OYUN,
                          "sapan_fid": set(_b.get("sapan_fid") or ())})
        bagimsizlik_kur()
        return True, H.OYUN, mesaj
    yol, mesaj = bul()
    if yol:
        uygula(yol)
        bagimsizlik_kur()
        return True, yol, mesaj
    # ⭐ Hicbiri DOGRULANMADI -- ama kilitlenme YOK. Oyun dosyalari GERCEKTEN
    # duran bir klasor bulduysak SALT-OKUNUR baglan: kullanici gezsin, onizlesin,
    # PNG cikarsin. Yazma `yazma_serbest()` ile kapali kalir.
    for aday in ([kayitli] if kayitli else []) + [H.OYUN]:
        if aday and all(os.path.exists(os.path.join(aday, f)) for f in GEREKLI):
            try:
                uygula(aday, kaydet=False, salt_okunur=True)
            except Exception:
                continue
            if gunluk:
                gunluk("read-only mode: browsing and Export work, writing is disabled.")
            return False, aday, mesaj
    return False, H.OYUN, mesaj


# ⭐ IMPORT ANINDA da kur: `baslat()` basarisiz donerse (:313) hicbir yerden
# cagrilmiyordu, ama kullanici sonra "Change..." ile klasor secebiliyor. Modul
# duzeyinde bir kez kurmak, "yamalanmamis hkm_ortak" durumunu tamamen ortadan
# kaldirir. `toc()` tembel oldugu icin bunun bir maliyeti yok (H.OYUN henuz
# gecerli olmasa bile guvenli).
bagimsizlik_kur()
