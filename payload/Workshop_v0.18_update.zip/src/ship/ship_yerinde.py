# -*- coding: utf-8 -*-
"""SHIP WORKSHOP - YERINDE YAZMA motoru (Outfit / Sail Workshop ile ayni yol).

Oyunun ANA dosyasina yazar. Iki mekanizma, ikisi de bu projede oyunda kanitli:

  1. HARICI ham mip girisleri  -> `r+b` ile YERINDE ezilir.
     Boyut birebir ayni, TOC'a HIC dokunulmaz. En kucuk ve en guvenli yazma.
     Olculdu: gemi dokularinin piksel baytlarinin **%85,9'u** burada;
     142 hedefte oran **%99'un ustunde**.
  2. GOMULU havuz (kapsayicinin icindeki sikisik blok) -> giris, K2 parca duzeni
     KORUNARAK STORED (sikistirmasiz) yeniden paketlenir, dosyanin SONUNA eklenir,
     TOC satirinin ofset+uzunlugu yeniden baglanir.
     (Oodle SIKISTIRICISI elimizde yok; sadece cozucu var. STORED bu yuzden.)

Sekil dogrulamasi (159/159 hedefte olculdu, 2026-07-29): her giriste tam **1** K2
konteyneri var, K1 ve K2 **TOCMode**, algo **8**, kuyruk bayti **0**.
Bu sekle uymayan giris REDDEDILIR (fail-closed).

KAYIT / GERI ALMA
  * Kayit ILK BAYTTAN ONCE, atomik (`tempfile`+`fsync`+`os.replace`) yazilir  [kural #3,#4]
  * Kayit oyun klasorunde DEGIL: %LOCALAPPDATA%\\ACBFR_Modding\\<forge-sha12>\\ [kural #5]
  * Basarisizlikta kayit SILINMEZ [kural #7]
  * Geri alma her yazmadan once **TOC SINIR KAPISINDAN** gecer: hedef aralik TOC'a
    ya da dosya sonunun otesine dusuyorsa yazma REDDEDILIR.
    (2026-07-29'da olculen gercek kacak buydu: dogrulamasiz revert TOC'un ortasina
     yazip iki alakasiz varligi sessizce olduruyordu.)
"""
import os, sys, json, struct, time, hashlib, tempfile, shutil, zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ship_motor as M
import ship_ayar as A          # DOGRULAMA bayragi: dogrulanmamis kuruluma YAZILMAZ
H = M.H

# 🔴 ORIJINAL BAYTLARIN YEDEGI BURAYA YAZILIR -- yani "Revert" in TEK dayanagi.
# Eskiden `os.environ.get("LOCALAPPDATA", tempfile.gettempdir())` idi ve
# `LOCALAPPDATA` olmayan bir baslatmada yedekler **%TEMP%**'e gidiyordu. Windows
# TEMP'i temizleyince Revert sonsuza kadar imkansiz hale gelirdi. Tek cozucu:
# `ship_ayar.veri_kok()` -- TEMP'e ASLA dusmez. (Ayrintili gerekce orada.)
VERI_KOK = A.veri_kok()
BMS = H.BMS


def onbellekleri_gecersiz_kil():
    """Dosyaya YAZDIKTAN sonra butun OKUMA onbelleklerini dusur.

    🧨 OLCULMUS TUZAK (2026-07-30, kullanici yakaladi): gomulu havuz yazmasi girisi
    dosyanin SONUNA ekleyip TOC satirini yeniden bagliyor. Ama `ship_ayar._TOC`
    tabloyu bir kez okuyup onbellekliyor ve yazmadan sonra TEMIZLENMIYORDU.
    Sonuc: ayni oturumda yapilan her okuma ESKI OFSETE gidiyor ve VANILLA baytlari
    donduruyordu.
    🔢 Kanit: PT_Pirate_01'e Ispanya tasarimi uygulandiktan sonra
        oyundaki gercek doku (taze surecte okundu) : RGB ort (150,3  150,8  155,2)
        GUI'nin ayni oturumda urettigi onizleme      : RGB ort ( 37,1   34,4   31,3)
    Yani kullanici tasariminin uygulanmadigini saniyordu; oysa yazma dogruydu,
    yalan soyleyen OKUMAYDI.
    ⚠️ Bu yalniz gorsel bir kusur DEGIL: ayni girise ikinci bir hedef yazilsaydi
    ofsetler bayat TOC'tan okunacakti.
    """
    try:
        import ship_ayar as A
        A._TOC.clear()
    except Exception:
        pass
    try:
        import ship_kompozit as K
        K._ONBELLEK.clear()
    except Exception:
        pass
    # hkm_doku / hkm_ortak tarafinda da onbellek varsa dusur
    for m, ad in ((H, "_ONBELLEK"), (H, "_CACHE")):
        try:
            getattr(m, ad).clear()
        except Exception:
            pass


# ================================================================== forge basligi
def forge_basligi(yol):
    """-> dict(surum, hdr_off, giris_sayisi, toc_off, toc_son, dosya_boy)"""
    with open(yol, "rb") as f:
        bas = f.read(64)
        if bas[:9] != b"scimitar\x00":
            raise ValueError("not a forge: %s" % yol)
        surum = struct.unpack_from("<I", bas, 9)[0]
        hdr = struct.unpack_from("<q", bas, 13)[0]
        f.seek(hdr)
        n, tocpos = struct.unpack("<Iq", f.read(12))
        boy = os.path.getsize(yol)
    return {"surum": surum, "hdr_off": hdr, "giris_sayisi": n,
            "toc_off": tocpos, "toc_son": tocpos + n * 24, "dosya_boy": boy}


def toc_indeksle(yol):
    """Dosyanin KENDI TOC'unu oku -> {fid: (satir_off, off, len, ext)}

    Yazma ofsetleri KATALOGDAN DEGIL buradan alinir. Katalog bayatlayabilir
    (baska bir arac girisi tasimis olabilir); dosyanin kendi tablosu bayatlamaz.
    """
    b = forge_basligi(yol)
    with open(yol, "rb") as f:
        f.seek(b["toc_off"])
        toc = f.read(b["giris_sayisi"] * 24)
    idx = {}
    for i in range(b["giris_sayisi"]):
        off, fid, ln, ext = struct.unpack_from("<QQII", toc, i * 24)
        idx[fid] = (b["toc_off"] + i * 24, off, ln, ext)
    return idx, b


def toc_satiri(yol, fid):
    idx, _b = toc_indeksle(yol)
    if fid not in idx:
        raise KeyError("0x%X is not in the TOC: %s" % (fid, os.path.basename(yol)))
    return idx[fid]


def yazma_kapisi(yol, off, uzunluk):
    """TOC SINIR KAPISI. Yazilacak aralik guvenli mi?  -> (ok, sebep)"""
    try:
        b = forge_basligi(yol)
    except Exception as e:
        return False, "could not read the forge header: %r" % (e,)
    son = off + uzunluk
    if off < 0 or uzunluk <= 0:
        return False, "invalid range"
    if son > b["dosya_boy"]:
        return False, ("range is BEYOND the end of file (%d..%d, file %d)"
                       % (off, son, b["dosya_boy"]))
    if off < b["toc_son"] and son > b["toc_off"]:
        return False, ("range is INSIDE THE TABLE (%d..%d, TOC %d..%d) - writing here "
                       "would kill unrelated assets"
                       % (off, son, b["toc_off"], b["toc_son"]))
    if off < 1070 and son > 0:
        return False, "range is inside the HEADER area"
    return True, ""


# ================================================================== kayit
def _forge_kimlik(yol):
    """Forge'un kimligi: ilk 1 MB + boyut -> sha256[:12]. (25 GB dosyayi hashlemeyiz.)"""
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        h.update(f.read(1 << 20))
    h.update(str(os.path.getsize(yol)).encode())
    return h.hexdigest()[:12]


def kayit_klasoru(forge_yolu):
    d = os.path.join(VERI_KOK, _forge_kimlik(forge_yolu))
    os.makedirs(d, exist_ok=True)
    return d


def _atomik_yaz(yol, veri_bytes):
    d = os.path.dirname(yol)
    fd, gec = tempfile.mkstemp(dir=d, suffix=".tmp")
    with os.fdopen(fd, "wb") as f:
        f.write(veri_bytes)
        f.flush()
        os.fsync(f.fileno())
    os.replace(gec, yol)


def kayit_yaz(forge_yolu, tex_id, kayit):
    p = os.path.join(kayit_klasoru(forge_yolu), "ship_%X.json" % tex_id)
    _atomik_yaz(p, json.dumps(kayit, indent=1, ensure_ascii=False).encode("utf-8"))
    return p


def _dosya_orijinal_mi(kayit, forge_yolu):
    """Bu kayit, dosyanin SU ANKI halini tarif ediyor mu? (yola degil ICERIGE bakar)

    Doner:
      True   -> dosya ORIJINAL baytlari tasiyor, yani kayit BAYAT (yok sayilabilir)
      False  -> dosyada bir degisiklik var, kayit GECERLI (yama canli ya da yarim)
      None   -> karar verilemedi (fail-closed: cagiran geceri sayar)

    Iki cipa var, ikisi de zaten kayitta duruyor:
      * `giris.toc_satiri`  : gomulu havuz hedeflerinde TOC satiri ya yeni girisi
        ya orijinali gosterir -- kesin ve tek satir okumayla belli olur.
      * `ham_sha256`        : `harici` aralıklarındaki ORIJINAL baytlarin hash'i
        (bkz. `orijinaller` -> `_atomik_yaz(ham_dosya, ...)`). Canli baytlarin
        hash'i buna esitse dosya orijinaldir.
    """
    try:
        g = kayit.get("giris")
        if g and g.get("yeni_off") is not None:
            with open(forge_yolu, "rb") as f:
                f.seek(int(g["toc_satiri"]))
                ham = f.read(24)
            if len(ham) < 24:
                return None
            off, _fid, ln, _ext = struct.unpack("<QQII", ham)
            if (off, ln) == (int(g["yeni_off"]), int(g["yeni_len"])):
                return False                      # yama CANLI
            if (off, ln) == (int(g["off"]), int(g["len"])):
                return True                       # orijinali gosteriyor -> bayat
            return None
        parcalar = kayit.get("harici") or []
        beklenen = kayit.get("ham_sha256")
        if not parcalar or not beklenen:
            return None
        boy = os.path.getsize(forge_yolu)
        h = hashlib.sha256()
        with open(forge_yolu, "rb") as f:
            for p in parcalar:
                o, ln = int(p["off"]), int(p["len"])
                if o + ln > boy:
                    return None
                f.seek(o)
                h.update(f.read(ln))
        return h.hexdigest() == beklenen
    except (OSError, KeyError, ValueError, struct.error):
        return None


def _oksuz_kayitlar(forge_yolu, tex_id, hazir_p):
    """Kimlik KAYMASINA dayanikli kayit arama.

    🧨 OLCULMUS TUZAK (2026-07-30): kayit deposu forge'un kimligiyle (ilk 1 MB +
    boyut) anahtarlaniyor, ama YAZMANIN KENDISI o kimligi degistiriyor. Normal
    akista sorun cikmaz -- `uygula` kaydi IKI kez yazar: `in_progress` yazmadan
    ONCE (eski kimlik), `uygulandi` yazmadan SONRA (yeni kimlik). Bu yuzden
    revert kaydi bulur (test_yerinde.py 16/16 bunu kanitliyor).

    Ama iki gercek delik var:
      1. YARIM YAZMA: satir 314-328 arasinda surec olurse (cokme, elektrik,
         taskkill) dosya UCUNCU bir kimlige duser. `in_progress` kaydi eski
         kimlikte kalir -> kalkan hic atesle**me**z -> `uygula` yarim yazilmis
         dosyanin uzerine TEKRAR yazar ve orijinal baytlarin TEK kopyasi
         (`ship_*.bin`) ulasilamaz olur.
      2. UCUNCU TARAF: baska bir arac (Flag/Sail Workshop, mod birlestirici) ya
         da bir oyun guncellemesi forge'u degistirirse kimlik kayar ve kaydimiz
         erisilemez olur -- tasarim oyunda canliyken revert imkansiz hale gelir.

    Bu fonksiyon o iki durumda kaydi BULUR. Belirsizlik varsa (birden fazla aday)
    cagiran FAIL-CLOSED davranir: yazmayi reddeder, karar kullaniciya kalir.
    """
    ad = "ship_%X.json" % tex_id
    hedef = os.path.normcase(os.path.abspath(forge_yolu))
    out = []
    try:
        for d in sorted(os.listdir(VERI_KOK)):
            p = os.path.join(VERI_KOK, d, ad)
            if not os.path.exists(p) or os.path.abspath(p) == os.path.abspath(hazir_p):
                continue
            try:
                k = json.load(open(p, encoding="utf-8"))
            except (OSError, ValueError):
                continue
            # AYNI forge dosyasi mi? (kayit tam yolu saklıyor)
            if os.path.normcase(os.path.abspath(str(k.get("forge_yolu") or ""))) != hedef:
                continue
            if k.get("durum") not in ("uygulandi", "in_progress"):
                continue
            # ⭐ ICERIK KAPISI: yol esitligi YETMEZ. Ayni yolda daha once baska bir
            # dosya bulunmus olabilir (sentetik test forge'lari tam bunu yapiyor).
            # Dosya orijinal baytlari tasiyorsa kayit bayattir -> yok sayilir.
            if _dosya_orijinal_mi(k, forge_yolu) is True:
                continue
            out.append((k, p))
    except OSError:
        pass
    return out


def _ayni_giristeki_yamalar(forge_yolu, giris_fid, haric_tid):
    """Ayni ARSIV GIRISINE bagli, SU AN yamali baska hedeflerin kayitlari.

    Gomulu havuz yazmasi girisin tamamini yeniden paketledigi icin bir giriste
    ayni anda birden fazla yamali doku BULUNAMAZ (bkz. `uygula` icindeki A1 kapisi).
    Burada yalnizca OKUMA yapilir; karar cagirana aittir.
    ⚠️ Kayit klasoru forge kimligiyle anahtarli ve yazma o kimligi degistiriyor;
    o yuzden `_oksuz_kayitlar` gibi TUM depo taranir, yalniz hazir klasor degil.
    """
    hedef_yol = os.path.normcase(os.path.abspath(forge_yolu))
    gid_hex = hex(giris_fid)
    goruldu, out = set(), []
    try:
        klasorler = sorted(os.listdir(VERI_KOK))
    except OSError:
        return out
    for d in klasorler:
        kd = os.path.join(VERI_KOK, d)
        try:
            adlar = [a for a in os.listdir(kd) if a.startswith("ship_") and a.endswith(".json")]
        except OSError:
            continue
        for ad in adlar:
            try:
                k = json.load(open(os.path.join(kd, ad), encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if k.get("durum") not in ("uygulandi", "in_progress"):
                continue
            if os.path.normcase(os.path.abspath(str(k.get("forge_yolu") or ""))) != hedef_yol:
                continue
            # ICERIK KAPISI (2026-09-08): durum alani "uygulandi" dese de dosya
            # ORIJINAL baytlari tasiyorsa kayit BAYATTIR (bkz. bayat_kayitlari_kapat).
            # Olculdu: geri alinmis bir dokunun bayat kaydi, kapsayiciyi paylasan
            # kardesinin (diffuse <-> normal) Apply'ini "patched right now" diye
            # reddediyordu. Belirsizlik (None) yine canli sayilir -- fail-closed.
            if _dosya_orijinal_mi(k, forge_yolu) is True:
                continue
            # ⚠️ Eski kayitlarda `kapsayici` alani vardi (`uygula` hep yaziyor);
            # yoksa bu kayit hakkinda karar VEREMEYIZ -> sessizce atla, cunku
            # yanlis pozitif kullanicinin mesru yamasini engeller.
            if str(k.get("kapsayici") or "").lower() != gid_hex.lower():
                continue
            try:
                if int(str(k.get("doku")), 16) == haric_tid:
                    continue                      # hedefin KENDI (bayat) kaydi
            except (TypeError, ValueError):
                pass
            anahtar = k.get("doku")
            if anahtar in goruldu:
                continue
            goruldu.add(anahtar)
            out.append(k)
    return out


def kayit_oku(forge_yolu, tex_id):
    p = os.path.join(kayit_klasoru(forge_yolu), "ship_%X.json" % tex_id)
    if os.path.exists(p):
        return json.load(open(p, encoding="utf-8")), p
    # Dogrudan bulunamadi -> kimlik kaymis olabilir (yarim yazma / ucuncu taraf).
    adaylar = _oksuz_kayitlar(forge_yolu, tex_id, p)
    if len(adaylar) > 1:
        # 🧨 OLCULDU (2026-07-30, gercek oyun dosyasinda): TEK bir yerinde-yazma
        # NORMALDE IKI kayit birakir -- `in_progress` yazma oncesi kimlikte,
        # `uygulandi` yazma sonrasi kimlikte. (Ornek: Emblem_MIT_Spanish_01 ->
        # 2267d9148f3f/in_progress + c2c2f38332fb/uygulandi.) Bunlari "celiski"
        # saymak, tek bir dogru yazmadan sonra araci KILITLER.
        # Ayirt edici: `ham_sha256` ORIJINAL baytlarin hash'i, yani ayni yazmanin
        # iki kaydinda AYNIDIR. Farkli hash = gercekten farkli iki orijinal = celiski.
        imzalar = {k.get("ham_sha256") for k, _q in adaylar}
        if len(imzalar) == 1:
            # Ayni yazma. 'uygulandi' daha ileri bir durum -> onu tercih et.
            for k, q in adaylar:
                if k.get("durum") == "uygulandi":
                    return k, q
            return adaylar[0]
    if len(adaylar) == 1:
        return adaylar[0]
    if len(adaylar) > 1:
        # FAIL-CLOSED: hangi kaydin gecerli oldugunu bilemeyiz. Yazmayi
        # reddetmek, yanlis orijinali geri yazmaktan iyidir.
        raise RuntimeError(
            "%d conflicting records point at this file for texture 0x%X:\n  %s\n"
            "The archive was changed by something else between apply and revert.\n"
            "Restore the archive with Steam's 'Verify integrity of game files' "
            "before continuing, and do NOT delete these records first."
            % (len(adaylar), tex_id, "\n  ".join(q for _k, q in adaylar)))
    return None, p


def bayat_kayitlari_kapat(forge_yolu, tid, kapatan=None):
    """Ayni forge + ayni doku icin BASKA kimlik klasorlerinde kalmis ve dosyanin
    SU ANKI halini artik tarif etmeyen 'uygulandi'/'in_progress' kayitlarini
    'geri_alindi' yap. Doner: kapatilan kayit yollari. Forge'a DOKUNMAZ.

    🧨 OLCULDU (2026-09-08, kum havuzu, gercek yazici; saha raporu xDXTERx
    "even if u revert changes to a texture it still says the texture is patched"):
      * `uygula` kaydi IKI kimlikte birakir: `in_progress` yazmadan onceki
        kimlikte, `uygulandi` yazmadan sonraki kimlikte (gomulu yazma dosya
        boyutunu degistirir -> kimlik kayar).
      * `geri_al` dosyayi eski boyuna dondurur -> kimlik ESKI degerine doner ->
        `geri_alindi` kaydi `in_progress`in USTUNE yazilir. Yazma-sonrasi
        kimlik klasorundeki `uygulandi` kaydi ise HIC dokunulmadan kalir.
      * Depoyu TARAYARAK okuyan herkes (ship_core._durumlar -> GUI "PATCHED"
        rozeti, mod_tara -> "ALREADY PATCHED", yamali_hedefler, ayni-giris
        kapisi) o bayat kaydi canli sanir. Gercek makinede 40 "PATCHED"
        kaydin 35'i boyle bayatti; dosya bayt bayt orijinaldi.
    Kapi ICERIGE bakar: yalniz `_dosya_orijinal_mi` KESIN True (dosya orijinal)
    dediginde kapatilir. False (yama canli) ya da None (karar verilemedi) ->
    DOKUNULMAZ; belirsiz kaydi kapatmak vanilla'ya donusun tek notunu silmek
    olurdu. Kayit SILINMEZ, durumu degisir; eski hali `kapanis` alaninda durur.
    """
    ad = "ship_%X.json" % tid
    hedef = os.path.normcase(os.path.abspath(forge_yolu))
    kapatan_n = os.path.normcase(os.path.abspath(kapatan)) if kapatan else None
    simdi = time.strftime("%Y-%m-%d %H:%M:%S")
    out = []
    try:
        klasorler = sorted(os.listdir(VERI_KOK))
    except OSError:
        return out
    for d in klasorler:
        p = os.path.join(VERI_KOK, d, ad)
        if not os.path.isfile(p):
            continue
        if kapatan_n and os.path.normcase(os.path.abspath(p)) == kapatan_n:
            continue
        try:
            with open(p, encoding="utf-8") as f:
                k = json.load(f)
        except (OSError, ValueError):
            continue
        if k.get("durum") not in ("uygulandi", "in_progress"):
            continue
        if os.path.normcase(os.path.abspath(str(k.get("forge_yolu") or ""))) != hedef:
            continue
        if _dosya_orijinal_mi(k, forge_yolu) is not True:
            continue                      # canli ya da belirsiz -> dokunma
        k["kapanis"] = {"onceki_durum": k.get("durum"), "zaman": simdi,
                        "sebep": "stale duplicate: the archive holds the original bytes",
                        "kapatan": kapatan}
        k["durum"] = "geri_alindi"
        k["geri_alma_zamani"] = k.get("geri_alma_zamani") or simdi
        try:
            _atomik_yaz(p, json.dumps(k, indent=1, ensure_ascii=False).encode("utf-8"))
        except OSError:
            continue
        out.append(p)
    return out


# ================================================================== giris yeniden paketleme
def giris_yeniden_paketle(raw, yeni_govde):
    """K1'i AYNEN koru; K2'yi PARCA DUZENI KORUNARAK stored yaz.

    Sail Workshop'in `rebuild_entry`'sinin genellestirilmis + sekli dogrulanan hali.
    Kaynak = bloklarin ciktilarinin ardarda eklenmesi; K2 yalniz K1'in ciktisindan
    SONRAKI kismi tarif eder. Bu yuzden 0'dan dilimlemek her seyi kaydirir.
    """
    b0, p1, v0, a0, f0 = H.blok_listesi(raw, 0)
    if (f0 >> 31) != 1:
        raise ValueError("K1 is not in TOCMode - this shape is not supported")
    k1_bayt = raw[:p1]

    if raw[p1:p1 + 8] != BMS:
        raise ValueError("no K2 container")
    b2, p2, v2, a2, f2 = H.blok_listesi(raw, p1)
    if (f2 >> 31) != 1:
        raise ValueError("K2 is not in TOCMode - this shape is not supported")
    if p2 != len(raw):
        raise ValueError("the entry has more than one K2 container / trailing bytes "
                         "(%d != %d)" % (p2, len(raw)))

    parca_u = [u for _dof, u, _cof, _c in b2]
    if sum(parca_u) != len(yeni_govde):
        raise ValueError("chunk size sum mismatch (%d != %d)"
                         % (sum(parca_u), len(yeni_govde)))

    # K2 basligi: 8 magic + 2 ver + 1 algo + 4 bayrak + 4 sayi = 19 bayt
    basl = raw[p1:p1 + 19]
    boy = b"".join(struct.pack("<II", u, u) for u in parca_u)   # ham == siki -> STORED
    govde = bytearray()
    o = 0
    for u in parca_u:
        d = yeni_govde[o:o + u]; o += u
        govde += struct.pack("<I", zlib.adler32(d, 0) & 0xFFFFFFFF) + d
    return k1_bayt + basl + boy + bytes(govde)


# ================================================================== UYGULA
def uygula(hedef, tasarim_png, oyun=None, gunluk=print, alfa="auto", yaz_yolu=None,
           ilerleme=None):
    """Hedefi OYUNUN ANA DOSYASINA yazar. Once dogrular, sonra yazar.

    yaz_yolu: yalniz TEST icin -- okuma yine oyundan (salt-okunur) yapilir, yazma
    bu dosyaya gider. Boylece mekanizma oyuna dokunmadan sinanabilir.
    """
    oyun = oyun or H.OYUN
    forge_ad = hedef["forge"]
    forge_yolu = yaz_yolu or os.path.join(oyun, forge_ad)
    gid = int(hedef["kapsayici"], 16)
    tid = int(hedef["id"], 16)

    if not hedef.get("kullanilabilir", True):
        raise RuntimeError("this target is not usable: %s" % hedef.get("red_sebebi"))

    # ⛔ DOGRULANMAMIS KURULUMA YAZILMAZ. Okuma serbest (bkz. ship_ayar.uygula),
    # ama yazma yanlis bayta duserse oyunu bozar. `yaz_yolu` verilmisse bu bir
    # SINAMA yazmasidir (kendi kopyamiza), oyun dosyasina degil -> kapi gecilir.
    if yaz_yolu is None and not A.yazma_serbest():
        raise RuntimeError(A.yazma_reddi())

    # ⚠️ PARMAK IZINDEN SAPAN GIRIS: UYAR, ENGELLEME.
    #
    # 🔴 2026-08-03, SAHADAN GELDI (ikinci kez ayni ders). v1.0.1'de buraya
    # "cerrahi kilit" koymustum: sapan girise yazmayi REDDEDIYORDU. Bir kullanici
    # `PT_Pirate_01`de takildi -- ve o giris (`0x218240C6D66`) tam da zuynes'in
    # YAYINLADIGI 52 bayrak modunun dokundugu giris. Yani kendi ekosistemimiz
    # kendini kilitliyordu.
    #
    # KILIT GEREKSIZDI, OLCULDU: kapsayici baska bir mod tarafindan degistirilmis
    # olsa bile uygula+geri al turu BAYT BIREBIR calisiyor. Cunku `uygula` zaten
    #   * girisi CANLI baytlardan cozuyor (`doku_bul`) -> canli mip listesi
    #   * harici mip ofsetlerini CANLI TOC'tan aliyor (`toc_indeksle`)
    #   * TOC uzunlugu tutmuyorsa mip bazinda REDDEDIYOR
    #   * `yazma_kapisi` ile TOC/baslik sinirlarini kontrol ediyor
    #   * ilk bayttan ONCE orijinali yedekliyor
    # Yani gercek tehlikelerin hepsi ZATEN hedef bazinda kapali. Parmak izi
    # uyusmazligi "bir sey farkli" ipucudur, "yazmak tehlikeli" KANITI degil.
    #
    # Kullaniciya soylenmesi gereken sey su: burada baska bir modun dokusu var,
    # senin tasarimin onun USTUNE yazilacak. (Revert de dogru davranir: bizim
    # yazmadan ONCEKI baytlari, yani o modun dokusunu geri koyar.)
    if yaz_yolu is None and A.giris_kilitli(gid):
        gunluk("note: archive entry %s differs from this release's catalogue - "
               "another mod has probably changed it. Your design will be written "
               "OVER it; Revert will put that mod's texture back, not vanilla."
               % hedef["kapsayici"])

    eski, kayit_yolu = kayit_oku(forge_yolu, tid)
    if eski and eski.get("durum") == "uygulandi":
        raise RuntimeError(
            "this texture is ALREADY patched (record: %s).\nRevert first, then apply again.\n"
            "(Overwriting would destroy the only note of where the original bytes are.)"
            % kayit_yolu)
    if eski and eski.get("durum") == "in_progress":
        raise RuntimeError(
            "a previous write was LEFT HALF-DONE (record: %s).\nRun revert first." % kayit_yolu)

    # ---- KAPI: AYNI ARSIV GIRISINI PAYLASAN BASKA BIR HEDEF YAMALI MI?
    # 🧨 OLCULDU 2026-07-30 (denetim A1, bagimsiz olarak tekrar dogrulandi).
    # 242 hedefte TAM 1 cift ayni girisi paylasiyor:
    #     pattern_BlackSkull (0x21910551545, havuz 16.777.216) +
    #     emblem_BlackSkull  (0x2191055484E, havuz  4.194.304)
    #     kapsayici 0x21A4674E368, IKISI DE TAM GOMULU (harici mip yok).
    # Gomulu yazma girisin TAMAMINI yeniden paketleyip dosya SONUNA ekler ve TOC
    # satirini oraya baglar. Ikisi de yamaliyken BIRINI geri almak, TOC'u ikinci
    # tasarimin HIC ISLENMEDIGI eski girise geri baglar:
    #   * digerinin tasarimi SESSIZCE yok olur ama kaydi hala "uygulandi" -> GUI PATCHED der
    #   * sonra ikinciyi geri alinca, ilk (geri alinmis) tasarim DIRILIR
    #   * olu kuyruk kirpma yanlis tabana bakip ateslemez -> arsiv 21 MB sisik kalir,
    #     sha256 vanilla ile TUTMAZ ("revert restores byte for byte" garantisi kirilir)
    # Ikisi de grup=sail, risk=SAFE, ayni sekmede yan yana: birlikte boyanmasi
    # en olasi cift. Fail-closed: ikinci Apply'i BASTAN reddet.
    for _k in _ayni_giristeki_yamalar(forge_yolu, gid, tid):
        raise RuntimeError(
            "this texture shares its archive entry with '%s', which is patched right now.\n"
            "Both live inside container %s, so patching them at the same time would\n"
            "corrupt the archive and make Revert unable to restore the original bytes.\n\n"
            "Revert '%s' first, then apply this one."
            % (_k.get("hedef") or _k.get("ad"), hedef["kapsayici"],
               _k.get("hedef") or _k.get("ad")))

    # ---- 1) kodla (oyuna hicbir sey yazilmadan)
    gec = tempfile.mkdtemp(prefix="shipws_y_")
    try:
        # cevir: bayrak/yelken sablonu `cikar` tarafindan cevrilerek verildi ->
        # geri yazarken tersi uygulanir (M.cevirmeli tek dogruluk kaynagi).
        donusum = M.tasarim_donusumu(tasarim_png, alfa=alfa, cevir=M.cevirmeli(hedef),
                                     hedef=hedef)
        gunluk("alpha      : %s%s" % (donusum.alfa_politikasi,
                                      "  (derived from this target's vanilla mask)"
                                      if alfa == "auto" else "  (you chose it)"))
        mip, d, r, rap = M.mip_kodla(forge_ad, gid, tid, donusum, gec, gunluk=None,
                                    ilerleme=ilerleme)
        t = d["tanim"]
        W, Hh, blok = t["W"], t["H"], t["blok"]
        gunluk("encoded    : %d levels, %dx%d %s" % (t["mipcount"], W, Hh, t["aile"]))

        # ---- 2) harici mip yazma plani. ⚠️ Ofsetler HEDEF DOSYANIN KENDI TOC'undan.
        toc_idx, _b0 = toc_indeksle(forge_yolu)
        plan = []
        for mid, sev, ext, ln, _kat_off in d["harici"]:
            mfid = mid & 0xFFFFFFFFFFFFFFFF
            if mfid not in toc_idx:
                raise RuntimeError("external mip 0x%X is not in the target forge TOC" % mfid)
            _sat, off, toc_len, _e = toc_idx[mfid]
            if toc_len != ln:
                raise RuntimeError("mip%d length differs in the TOC (%d != %d) - another "
                                   "tool may have moved this asset"
                                   % (sev, toc_len, ln))
            w = max(1, W >> sev); h = max(1, Hh >> sev)
            bw = max(1, (w + 3) // 4); bh = max(1, (h + 3) // 4)
            rowbytes = bw * blok
            pitch = H.hizala(rowbytes, 256)
            src = mip[sev]
            buf = bytearray()
            for y in range(bh):
                buf += src[y * rowbytes:(y + 1) * rowbytes] + b"\x00" * (pitch - rowbytes)
            if len(buf) != ln:
                raise RuntimeError("external mip%d length %d != %d" % (sev, len(buf), ln))
            plan.append({"seviye": sev, "forge": forge_ad, "off": off, "len": ln,
                         "veri": bytes(buf), "mip_fid": mid & 0xFFFFFFFFFFFFFFFF})

        # ---- 3) gomulu havuz -> giris yeniden paketlenecek mi?
        yeni_giris = None
        if d["gomulu"]:
            dilim = r["dilim"]
            ic = bytearray(dilim[d["sira"]][1])
            hb, hl = d["cipa"][1], d["cipa"][2]
            havuz = bytearray(ic[hb:hb + hl])
            for lvl, o, pitch, satir, rowbytes in d["gomulu"]:
                src = mip[lvl]
                for y in range(satir):
                    havuz[o + y * pitch: o + y * pitch + rowbytes] = \
                        src[y * rowbytes:(y + 1) * rowbytes]
            ic[hb:hb + hl] = havuz
            dilim[d["sira"]][1] = ic
            yeni_govde = b"".join(bytes(x[1]) for x in dilim)
            if len(yeni_govde) != len(r["coz"]["govde"]):
                raise RuntimeError("body length changed")
            yeni_giris = giris_yeniden_paketle(r["raw"], yeni_govde)
    finally:
        shutil.rmtree(gec, ignore_errors=True)

    satir_off, giris_off, giris_len, ext = toc_satiri(forge_yolu, gid)
    if giris_len != r["giris_len"]:
        raise RuntimeError("entry length differs in the TOC (%d != %d) - another tool may "
                           "have moved this entry; revert that one first"
                           % (giris_len, r["giris_len"]))

    gunluk("external    : %d entries, %s B written in place (TOC untouched)"
           % (len(plan), format(sum(p["len"] for p in plan), ",")))
    if yeni_giris:
        gunluk("embedded   : entry repacked to %s B -> appended, TOC relinked"
               % format(len(yeni_giris), ","))
    else:
        gunluk("embedded   : none - PURE IN-PLACE write, the TOC is never touched")

    # ---- 4) TOC SINIR KAPISI: tek bayt yazmadan once her aralik kontrol edilir
    for p in plan:
        ok, sebep = yazma_kapisi(forge_yolu, p["off"], p["len"])
        if not ok:
            raise RuntimeError("WRITE REFUSED (mip%d): %s" % (p["seviye"], sebep))
    ok, sebep = yazma_kapisi(forge_yolu, satir_off, 24)
    if yeni_giris and not ok:
        pass          # TOC satirini yazmak zaten TOC'a yazmaktir; asagida ayrica dogrulanir
    b = forge_basligi(forge_yolu)
    if yeni_giris and not (b["toc_off"] <= satir_off < b["toc_son"]):
        raise RuntimeError("the TOC row was computed outside the table - refused")

    # ---- 5) KAYIT ILK BAYTTAN ONCE
    orijinaller = []
    with open(forge_yolu, "rb") as f:
        for p in plan:
            f.seek(p["off"])
            orijinaller.append(f.read(p["len"]))
    ham_klasor = kayit_klasoru(forge_yolu)
    ham_dosya = os.path.join(ham_klasor, "ship_%X.bin" % tid)
    _atomik_yaz(ham_dosya, b"".join(orijinaller))

    kayit = {
        "surum": 1, "durum": "in_progress", "zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
        "hedef": hedef["anahtar"], "ad": hedef["ad"], "doku": hex(tid),
        "kapsayici": hex(gid), "forge": forge_ad, "forge_yolu": forge_yolu,
        "tasarim": os.path.abspath(tasarim_png),
        # ⭐ `yeni_sha256` = BIZIM YAZDIGIMIZ baytlarin hash'i. `geri_al` yazmadan
        # once o ofseti okuyup bununla karsilastirir; tutmuyorsa REDDEDER.
        # (Denetim A2: revert kayittaki ofsete KORLEMESINE yaziyordu. Ucuncu bir
        #  arac girisi AYNI UZUNLUKTA baska bir ofsete tasirsa `ship_ayar.dogrula`
        #  -- yalniz fid+uzunluk bakiyor -- bunu gecirir ve revert ALAKASIZ canli
        #  veriyi ezer. Yanlis yere yazilabilecek blok medyan 1.376.256 B,
        #  maksimum 22.282.240 B (BaseAtlas_01).)
        "harici": [{"seviye": p["seviye"], "off": p["off"], "len": p["len"],
                    "mip_fid": hex(p["mip_fid"]),
                    "yeni_sha256": hashlib.sha256(p["veri"]).hexdigest()} for p in plan],
        "ham_dosya": ham_dosya,
        "ham_sha256": hashlib.sha256(b"".join(orijinaller)).hexdigest(),
        "giris": ({"toc_satiri": satir_off, "off": giris_off, "len": giris_len,
                   "yeni_len": len(yeni_giris)} if yeni_giris else None),
        "dosya_boy_once": os.path.getsize(forge_yolu),
    }
    kayit_yolu = kayit_yaz(forge_yolu, tid, kayit)
    gunluk("record     : %s" % kayit_yolu)

    # ---- 6) YAZ
    with open(forge_yolu, "r+b") as f:
        for p in plan:
            f.seek(p["off"])
            f.write(p["veri"])
        if yeni_giris:
            f.seek(0, 2)
            yeni_off = f.tell()
            f.write(yeni_giris)
            f.seek(satir_off)
            f.write(struct.pack("<Q", yeni_off))
            f.seek(satir_off + 16)
            f.write(struct.pack("<I", len(yeni_giris)))
            kayit["giris"]["yeni_off"] = yeni_off
        f.flush()
        os.fsync(f.fileno())
    kayit["durum"] = "uygulandi"
    kayit_yaz(forge_yolu, tid, kayit)
    # ⭐ Dosya degisti -> okuma onbellekleri ARTIK YALAN. Kayittan HEMEN SONRA dusur.
    onbellekleri_gecersiz_kil()
    gunluk("WRITTEN    : %s" % forge_ad)
    return kayit


# ================================================================== GERI AL
def geri_al(hedef, oyun=None, gunluk=print):
    # ⛔ Revert de YAZMADIR: dogrulanmamis kuruluma dokunmaz.
    # (`oyun` verilmisse sinama kopyasidir -> kapi gecilir.)
    if oyun is None and not A.yazma_serbest():
        raise RuntimeError(A.yazma_reddi())
    oyun = oyun or H.OYUN
    forge_yolu = os.path.join(oyun, hedef["forge"])
    tid = int(hedef["id"], 16)
    kayit, kayit_yolu = kayit_oku(forge_yolu, tid)
    if not kayit:
        gunluk("no record - nothing to revert (%s)" % kayit_yolu)
        return None
    if not os.path.exists(kayit["ham_dosya"]):
        raise RuntimeError("the original-bytes file is MISSING: %s\nThe record was NOT deleted."
                           % kayit["ham_dosya"])
    ham = open(kayit["ham_dosya"], "rb").read()
    if hashlib.sha256(ham).hexdigest() != kayit["ham_sha256"]:
        raise RuntimeError("sha256 of the original-bytes file does not match. Record NOT deleted.")
    bekl = sum(x["len"] for x in kayit["harici"])
    if len(ham) != bekl:
        raise RuntimeError("original byte length mismatch (%d != %d)" % (len(ham), bekl))

    # --- KAPI: GIRIS HALA AYNI YERDE MI?  (KONUM kontrolu, ICERIK degil)
    #
    # 🔴 2026-08-02, SAHADAN GELDI. Ilk yazdigim kapi ICERIGE bakiyordu:
    # "oradaki baytlar bizim yazdiklarimiz mi?" Yayindan iki gun sonra uc kullanici
    # birden takildi (biri `ICN_Iconic_02` yelken setinde):
    #   "REVERT REFUSED (mip0): the bytes at offset 10,562,551,706 are NOT the ones
    #    this tool wrote ... The record was NOT deleted - your design is still installed."
    # Yani EMNIYET KEMERI kullanicilari kilitledi: geri alamadilar.
    #
    # KAPI YANLIS SEYI OLCUYORDU. Tehlike icerikte DEGIL, KONUMDA:
    #   * Giris hala AYNI TOC satirinda, AYNI ofset ve uzunlukta ise -> orijinal
    #     baytlari oraya yazmak GUVENLIDIR. Icerigin bizim yazdigimizdan farkli
    #     olmasi (kullanici iki kez uyguladi, kayit eskidi, baska bir Ship kopyasi
    #     yazdi...) bir tehlike DEGIL; zaten oraya ait olan baytlari geri koyuyoruz.
    #   * Giris TASINMISSA -> o ofset artik BASKA bir varliga ait; yazmak
    #     alakasiz veriyi ezer. ISTE O ZAMAN reddedilmeli.
    # `uygula` bu ayrimi zaten dogru yapiyor: ofsetleri her seferinde CANLI TOC'tan
    # cozuyor. `geri_al` da ayni kaynagi kullanmali -- asimetri buydu.
    toc_idx, _b0 = toc_indeksle(forge_yolu)
    for x in kayit["harici"]:
        mfid = x.get("mip_fid")
        if mfid is None:
            continue                       # eski kayit: mip_fid yok -> eski yol
        try:
            mfid = int(str(mfid), 16) & 0xFFFFFFFFFFFFFFFF
        except (TypeError, ValueError):
            continue
        satir = toc_idx.get(mfid)
        if satir is None:
            raise RuntimeError(
                "REVERT REFUSED (mip%d): entry 0x%X is no longer in the archive's "
                "table of contents.\nSomething else has rebuilt this archive. The "
                "record was NOT deleted - restore the game with Steam's 'Verify "
                "integrity of game files'." % (x["seviye"], mfid))
        _sat, canli_off, canli_len, _e = satir
        if canli_len != x["len"]:
            raise RuntimeError(
                "REVERT REFUSED (mip%d): entry 0x%X changed length (%s -> %s B).\n"
                "Another tool has rewritten this asset; writing the old bytes back "
                "would corrupt it. The record was NOT deleted."
                % (x["seviye"], mfid, format(x["len"], ","), format(canli_len, ",")))
        if canli_off != x["off"]:
            # Giris TASINMIS ama hala TOC'ta ve ayni boyda -> dogru yer CANLI TOC.
            # Kayittaki bayat ofsete yazmak tam da onlemek istedigimiz seydi.
            gunluk("note: mip%d moved since apply (%s -> %s); using the live TOC"
                   % (x["seviye"], format(x["off"], ","), format(canli_off, ",")))
            x["off"] = canli_off
    # Icerik farki artik REDDETME sebebi DEGIL -- yalniz gunluge dusen bir not.
    with open(forge_yolu, "rb") as _f:
        for x in kayit["harici"]:
            bekl_sha = x.get("yeni_sha256")
            if not bekl_sha:
                continue
            _f.seek(x["off"])
            simdi = _f.read(x["len"])
            if len(simdi) != x["len"] or hashlib.sha256(simdi).hexdigest() != bekl_sha:
                gunluk("note: mip%d does not hold the exact bytes this record wrote "
                       "(re-applied, or written by another copy of the tool). The "
                       "entry is still in its place, so the original bytes are being "
                       "restored." % x["seviye"])
    # --- KAPI: her aralik once dogrulanir; biri bile duserse TEK BAYT yazilmaz
    for x in kayit["harici"]:
        ok, sebep = yazma_kapisi(forge_yolu, x["off"], x["len"])
        if not ok:
            raise RuntimeError("REVERT REFUSED (mip%d): %s" % (x["seviye"], sebep))
    g = kayit.get("giris")
    if g:
        b = forge_basligi(forge_yolu)
        if not (b["toc_off"] <= g["toc_satiri"] < b["toc_son"]):
            raise RuntimeError("REVERT REFUSED: the TOC row is outside the table")
        if g["off"] + g["len"] > b["dosya_boy"]:
            raise RuntimeError("REVERT REFUSED: the old entry range lies outside the file")
        # Gomulu yolda TOC satirinin HALA bizim ekledigimiz girise bakiyor olmasi
        # gerekir. Bakmiyorsa baska biri satiri degistirmis demektir -> dokunma.
        if g.get("yeni_off") is not None:
            with open(forge_yolu, "rb") as _f:
                _f.seek(g["toc_satiri"])
                _canli_off = struct.unpack("<Q", _f.read(8))[0]
            if _canli_off != g["yeni_off"]:
                raise RuntimeError(
                    "REVERT REFUSED: the TOC row no longer points at the entry this tool "
                    "appended (live %s, ours %s).\nSomething else has re-linked this asset; "
                    "reverting now would corrupt it. The record was NOT deleted."
                    % (hex(_canli_off), hex(g["yeni_off"])))

    with open(forge_yolu, "r+b") as f:
        p = 0
        for x in kayit["harici"]:
            f.seek(x["off"])
            f.write(ham[p:p + x["len"]])
            p += x["len"]
        if g:
            f.seek(g["toc_satiri"]);      f.write(struct.pack("<Q", g["off"]))
            f.seek(g["toc_satiri"] + 16); f.write(struct.pack("<I", g["len"]))
        f.flush()
        os.fsync(f.fileno())

    # --- OLU KUYRUGU KIRP (Sail/Outfit bunu yapmaz, forge her dongude buyur)
    # Yalniz ve yalniz bizim ekledigimiz giris dosyanin EN SONUNDAYSA. Baska bir
    # arac bizden sonra bir sey eklediyse boyut tutmaz ve DOKUNULMAZ.
    kirpildi = None
    if g and g.get("yeni_off") is not None and kayit.get("dosya_boy_once"):
        beklenen = g["yeni_off"] + g["yeni_len"]
        simdiki = os.path.getsize(forge_yolu)
        if simdiki == beklenen and beklenen > kayit["dosya_boy_once"]:
            with open(forge_yolu, "r+b") as f:
                f.truncate(kayit["dosya_boy_once"])
            kirpildi = simdiki - kayit["dosya_boy_once"]
            gunluk("dead tail trimmed: %s B -> file back to its original size"
                   % format(kirpildi, ","))
        elif simdiki != beklenen:
            gunluk("note: something was appended after us (%s != %s) - "
                   "the tail was LEFT UNTOUCHED"
                   % (format(simdiki, ","), format(beklenen, ",")))
    kayit["kirpilan"] = kirpildi
    kayit["durum"] = "geri_alindi"
    kayit["geri_alma_zamani"] = time.strftime("%Y-%m-%d %H:%M:%S")
    yeni_kayit_yolu = kayit_yaz(forge_yolu, tid, kayit)
    # Dosya eski boyuna dondu -> kimlik eski degerine dondu -> bu kayit yazma
    # ONCESI kimlik klasorune dustu. Yazma SONRASI kimlik klasorundeki
    # `uygulandi` kopyasi hala orada ve depoyu tarayan her okuyucuya "PATCHED"
    # dedirtir. Kapat (icerik kapisi: dosya gercekten orijinalse).
    kapatilan = bayat_kayitlari_kapat(forge_yolu, tid, kapatan=yeni_kayit_yolu)
    if kapatilan:
        gunluk("stale record(s) closed: %d (same texture, older archive identity)"
               % len(kapatilan))
    # ⭐ Geri alma da dosyayi degistirir (TOC satiri + olu kuyruk kirpma) ->
    # okuma onbellekleri yine bayat. Aksi halde revert sonrasi onizleme, geri
    # alinmis tasarimi gostermeye devam ederdi.
    onbellekleri_gecersiz_kil()
    gunluk("REVERTED   : %s (%d mip%s)" % (hedef["anahtar"], len(kayit["harici"]),
                                            " + entry TOC row" if g else ""))
    return kayit


# ================================================================== DURUM
def durum(hedefler, oyun=None):
    oyun = oyun or H.OYUN
    out = []
    for h in hedefler:
        forge_yolu = os.path.join(oyun, h["forge"])
        if not os.path.exists(forge_yolu):
            continue
        # Durum listelemesi TEK BIR hedefin celiskili kaydi yuzunden komple
        # cokmemeli: 132 hedefin 131'i saglamken liste bos donerse kullanici
        # "hicbir sey yamali degil" sanir. Celiskiyi o hedefe ait bir durum
        # olarak tasiriz; asil red `uygula`/`geri_al` icinde verilir.
        try:
            k, _p = kayit_oku(forge_yolu, int(h["id"], 16))
        except RuntimeError as e:
            out.append((h, {"durum": "conflict", "hata": str(e)}))
            continue
        if k and k.get("durum") in ("uygulandi", "in_progress"):
            out.append((h, k))
    return out
