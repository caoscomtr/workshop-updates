# -*- coding: utf-8 -*-
"""SHIP WORKSHOP - motor (Strateji A: YENI patch_02 uret, oyuna DOKUNMA).

Neden Strateji A:
  MOD_ALTYAPISI 3.1 / [[ac4-mod-guvenlik-kurallari]] -> "yeni araclar icin A".
  Taban forge'a hic dokunulmaz, geri alma = uretilen dosyayi silmek, TOC/kayit
  kirilganligi (Flag/Sail/Outfit'in butun kusur ailesi) bu yolda YAPISAL OLARAK yok.

Bu dosyadaki HICBIR fonksiyon oyun klasorune yazmaz. Oyun forge'lari yalniz "rb"
ile acilir (hkm_ortak uzerinden). Kurulum ayri komuttur (ship_cli.py kur).

Olculmus kurallara uyum:
  #1  yazmadan once dogrula   -> uret() sonunda gidis-donus dogrulamasi zorunlu
  #3  sistem girisleri        -> 0x10/0x91/0xC1/0xFF8/0xFFA olmadan forge yazilmaz
  #6  patch zinciri           -> katalogdaki `forge` alani zincirin EN USTU
  alfa tuzagi                 -> her mip SEVIYE SEVIYE kodlanir, alfa vanilla'dan korunur
"""
import os, sys, json, struct, hashlib, tempfile, shutil, time, subprocess

_HKM = os.path.dirname(os.path.abspath(__file__))
if _HKM not in sys.path:
    sys.path.insert(0, _HKM)
import hkm_ortak as H          # noqa: E402  forge oku/kur, doku yerlesimi (denetimden gecti)
import hkm_doku as HD          # noqa: E402  TexEncode borusu (alfa tuzagi kapali)
import numpy as np             # noqa: E402
from PIL import Image          # noqa: E402

KOK     = os.path.dirname(os.path.abspath(__file__))
KATALOG = os.path.join(KOK, "katalog", "ship_hedefler.json")

SISTEM_IDLER = [0x10, 0x91, 0xC1, 0xFF8, 0xFFA]
# sistem girisi bagiscisi: oyunda CALISTIGI dogrulanmis mod forge'lari
# Pakette sistem girisi GONDERILMIYOR (ucuncu-sahis bayti). Yerinde yazma
# yolu sistem girisi kullanmaz; patch_02 yolu Workshop arayuzunde yok.
SISTEM_ADAYLARI = [
    os.path.join(H.OYUN, "DataPC_boot_patch_02.forge"),
]


# ---------------------------------------------------------------- katalog
def katalog():
    return json.load(open(KATALOG, encoding="utf-8"))


def hedef_bul(anahtar, kat=None):
    """id ('0x...'), kisa_ad ya da tam ad ile hedef bul."""
    kat = kat or katalog()
    a = str(anahtar).lower()
    for h in kat["hedefler"]:
        if a in (h["anahtar"].lower(), h["id"].lower(), h["ad"].lower()):
            return h
    tam = [h for h in kat["hedefler"] if h["anahtar"].lower() == a]
    if len(tam) == 1:
        return tam[0]
    esle = [h for h in kat["hedefler"] if a in h["anahtar"].lower()]
    if len(esle) == 1:
        return esle[0]
    if len(esle) > 1:
        raise KeyError("ambiguous: %s -> %s" % (anahtar, [h["anahtar"] for h in esle[:8]]))
    raise KeyError("no such target: %s" % anahtar)


# ---------------------------------------------------------------- sistem girisleri
def sistem_girisleri(kaynak=None):
    """-> ([(fid, ext, ham)], bilgi).  Kural #3: bu bes giris olmadan oyun ACILMAZ."""
    adaylar = [kaynak] if kaynak else SISTEM_ADAYLARI
    for p in adaylar:
        if not p or not os.path.exists(p):
            continue
        try:
            d, meta = H.forge_oku_hepsi(p)
        except Exception:
            continue
        if not all(s in d for s in SISTEM_IDLER):
            continue
        out = [(s, d[s][1], d[s][0]) for s in SISTEM_IDLER]
        bilgi = {"kaynak": p, "sha256": {hex(s): hashlib.sha256(d[s][0]).hexdigest()[:16]
                                         for s in SISTEM_IDLER}}
        return out, bilgi
    raise RuntimeError(
        "System entries (0x10 0x91 0xC1 0xFF8 0xFFA) not found.\n"
        "These are a fixed bootstrap and are taken from a mod forge that is known\n"
        "to work in game. Paths tried:\n  " + "\n  ".join(str(p) for p in adaylar))


# ---------------------------------------------------------------- doku cikar
def _doku_kaydi(forge, giris_fid, tex_id):
    r = H.doku_bul(forge, giris_fid)
    d = [x for x in r["dokular"] if x["tex_id"] == tex_id]
    if not d:
        raise KeyError("entry 0x%X does not contain texture 0x%X (found: %s)"
                       % (giris_fid, tex_id, [hex(x["tex_id"]) for x in r["dokular"]]))
    return r, d[0]


def mip_oku(forge, giris_fid, tex_id, lvl=0):
    """Tek mip seviyesini RGBA olarak dondur (SALT-OKUNUR)."""
    r, d, mp = HD.mip_zinciri_oku(forge, giris_fid, tex_id)
    t = d["tanim"]
    w = max(1, t["W"] >> lvl); h = max(1, t["H"] >> lvl)
    tight = max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * t["blok"]
    return H.bc_coz(mp[lvl]["veri"][:tight], w, h, t["aile"]), t


# ---------------------------------------------------------------- YON (dikey cevirme)
CEVIRME_GRUPLARI = ("flag", "sail")


def cevirmeli(hedef):
    """Bayrak ve yelken dokulari arsivde DIKEY TERS saklaniyor.

    🔢 OLCULDU (2026-07-30): Flag Workshop'un `decode_flag`i ile bu modulun ham
    dizisi arasindaki tek fark TAM BIR DIKEY CEVIRME (fark 0.0000 / %100 ayni).
    Flag kendi kodunda bunu `return arr[::-1]  # stored upside down -> display
    order` diye belgeliyor (flag_engine.py:507) ve o yon oyunda calisan 52
    yayinlanmis modla dogrulanmis. Yani HAM dizi ters, cevrilmis olan dogru.

    ⛔ GLOBAL YAPILMAZ: crew / figurehead / wheel icin mutlak yon OLCULEMEDI, o
    yuzden onlara dokunulmuyor. Kapsam sizmasinin test kapisi var.
    ⚠️ Bu kural UC yerde AYNI ANDA gecerli olmak zorunda:
         `cikar`/`doku_dizisi`  (export + onizleme)
         `tasarim_donusumu`     (apply - ters yonde)
         `dogrula`nin referansi (yoksa 50 hedefte piksel kapisi patlar)
    Yalniz birini cevirmek kullanicinin dokusunu oyunda BAS ASAGI bindirir.
    """
    return hedef.get("grup") in CEVIRME_GRUPLARI


def doku_dizisi(hedef, lvl=0):
    """Hedefin bir mip seviyesini KULLANICIYA GOSTERILECEK yonde dondur (bellekte).

    export ve onizleme AYNI fonksiyondan beslenir; boylece "onizlemede gordugun
    sey, boyayacagin dosyanin tam kendisi" ilkesi kodla garanti altina alinir.
    (Eskiden onizleme ayri bir `lvl` ile ayri cagri yapiyordu -> 133 hedefin
    115'inde export'tan BASKA seviyeyi gosteriyordu.)
    """
    a, t = mip_oku(hedef["forge"], int(hedef["kapsayici"], 16), int(hedef["id"], 16), lvl)
    if cevirmeli(hedef):
        a = np.ascontiguousarray(a[::-1])
    return a, t


# ---------------------------------------------------------------- KIYAFET TAKIMLARI
# Kaptan (2026-07-30): "Rugged Rags Crew Attire'in butun kiyafet dokularini uygulama
# icinde toplayalim, bir klasor gibi olsun ki adamlar gorsun kafalari karismasin."
# Crew sekmesi 40 satirlik duz bir listeydi (`Torso_S_JackdawPirates_B_EndGame_02`...)
# ve hangi dokunun hangi oyun ici kiyafete ait oldugu anlasilmiyordu.
#
# 🔢 OLCULDU: crew adlari `<Parca>_<S|U>_<Aile>[_<Takim>]` seklinde. Takim jetonu
# ada gomulu; ayni jetonu tasiyan butun parcalar oyunda AYNI kiyafeti olusturuyor.
# ⚠️ OYUN ICI GORUNEN ADLAR ("Rugged Rags", "Black & Gold") COZULEMEDI: onlar LOC
# bloklarinda ve `OBD_ShipVanity_Crew_*` kayitlari yalnizca 1-2 referans tasiyor,
# yuva->doku zinciri kirilmadi. O yuzden takimlar VARLIK ADINDAN turetilen adla
# gosteriliyor; uydurma esleme YAPILMIYOR.
TAKIM_JETONLARI = [
    ("MrBonesB", "Skeleton Crew (B)"),
    ("MrBonesC", "Skeleton Crew (C)"),
    ("EndGame_01", "End Game 1"),
    ("EndGame_02", "End Game 2"),
    ("EndGame_03", "End Game 3"),
    ("MasterAssassin", "Master Assassin"),
    ("Animus", "Animus"),
    ("Ivory", "Ivory"),
]


def gri_tonlamali(rgb, esik=12.0):
    """Bu RGB dizi pratikte GRI TONLAMALI mi? (kanal farkinin ortalamasi)

    🔢 OLCULDU 2026-07-30 -- murettebat diffuse'lari gercekten gri:
        Torso_S_JackdawPirates  doygunluk 3,9/255
        Sash_S_JackdawPirates   3,0
        Bandana_S_JackdawPirates 2,5
    Buna karsilik bir bayrak kompoziti ya da tekerlek dokusu bu esigin cok uzerinde.
    Esik 12: olculen crew degerleri (2,5-6,0) ile renkli dokular arasinda genis bosluk.
    """
    a = np.asarray(rgb)
    if a.ndim != 3 or a.shape[2] < 3:
        return False
    a = a[:, :, :3].astype(np.int16)
    return float((a.max(axis=2) - a.min(axis=2)).mean()) < esik


# Hull sekmesi 31 dokuyu duz listeliyordu ve dis kaplama, guverte, kabin esyasi
# ic ice giriyordu. Kaptan: "geminin disini da koymamiz gerek, orayi boyamak ister
# herkes" -- aslinda ZATEN oradaydi, bulunamiyordu. Bolumler ada gore turetilir.
# ⚠️ SIRA ONEMLI: ilk eslesen kazanir. `PlanksHullPaintedMTX` once "Cosmetic"e
# dusmeli, `PlanksHull` kuralindan ONCE bakilir.
# ⚠️ SIRA ONEMLI: ilk eslesen kazanir (or. `PlanksHullPaintedMTX` once "Cosmetic"e).
# Kurallar hem ANAHTARA hem TAM VARLIK ADINA bakar.
BOLUM_KURALLARI = {
    "hull": ([
        (("MTX", "SeaSerpent", "HellFire", "JadeTiles", "AsianMTX"), "Cosmetic hulls (MTX/DLC)"),
        (("Decal", "Damage"), "Damage marks"),
        (("FloorDeck",), "Deck"),
        (("Mast",), "Masts"),
        (("PlanksHull",), "Exterior planking"),
        (("Trim", "Strakes", "Ornate", "Painted_Metal", "Metal"), "Trim & metal"),
    ], "Other shared surfaces"),
    # Kabin: Jackdaw'a OZEL kaptan kamarasi ile paylasimli esyalar AYRI bolumde --
    # birincisi yalniz senin gemini, ikincisi baska gemileri de etkiler.
    "cabin": ([
        (("BRG_Jackdaw_Cabin", "JackdawCabin"), "Jackdaw's cabin (your ship only)"),
        (("ShipTropies", "Tropies", "Trophy"), "Trophies"),
        (("Globe", "Paintings", "Blueprint", "Mannq"), "Decor"),
    ], "Shared cabin surfaces"),
    # Toplar SILAH TIPINE gore ayrilir. (Ilk denememde `UNQ` jetonuyla ayirmaya
    # calistim: 26'sinin 26'si "Unique" ciktı -- ise yaramaz gruplama, olcum gosterdi.)
    "cannon": ([
        (("SwivelGun",), "Swivel guns"),
        (("LongGun",), "Long guns"),
        (("SiegeMortar",), "Siege mortars"),
        (("LightMortar",), "Light mortars"),
        (("Culverin",), "Culverins"),
    ], "Other guns"),
    "flag": ([
        (("Bulk_Streamer", "Streamer"), "Streamers & pennants"),
        (("Bulk_",), "Bulk flags (distant ships)"),
    ], "Mast flags"),
    # Yelkenlerde `tier` cogunlukla bos (53'un 33'u) -> ad yapisiyla ayrilir.
    "sail": ([
        (("Sail_Emblem", "Sail_Emble"), "Emblems"),
        (("Sail_Pattern",), "Patterns"),
        (("BaseAtlas",), "Base cloth"),
    ], "Sail sets"),
}

# Pruva figuru ve dumende ad yapisi ayirt etmiyor ama `tier` TAM ayiriyor
# (olculdu: figurehead DLC 5 · ICN 5 · MTX 8 · ULC 6 · UPG 6 · UPL 1 -> 31'i kapsiyor).
TIER_BOLUMU = {"figurehead", "wheel"}
TIER_AD = {"ICN": "Iconic (in-game)", "DLC": "DLC", "MTX": "Store (MTX)",
           "ULC": "Uplay", "UPL": "Uplay reward", "UPG": "In-game upgrade",
           "COM": "Common", "LGR": "Legendary", "PT": "Pirate",
           "MT": "Military", "MIT": "Military (Spanish)", "STD": "Shared library"}


def takimlar(hedef):
    """Hedefin gorunecegi BOLUM(LER) -> liste. Bos liste = duz listede gosterilir.

    ⭐ Cogunlukla tek eleman. AMA hull'da bir doku BIRDEN COK gemi govdesinde
    kullanilabilir; kaptan "Obsidian Hull'a ozel klasor acalim, paylasimli olsun
    olmasin o hull'u degistirecekse hepsini isim isim ayri klasorlere koyalim"
    dedi. Bu yuzden hull hedefleri KULLANILDIKLARI HER GOVDENIN altinda gorunur.
    🔢 OLCULDU (zincir 14/14 bagimsiz hakemle dogrulandi):
        ShipVanity_Hull_XX -> `OBD_SHP_Jackdaw_HullGroup_XX` (EntityGroupBuilder,
        KAYIP HALKA buydu) -> EntityGroup -> Mesh -> **Material** -> TextureSet -> doku.
        Mesh doku ID'si TASIMAZ; ayrica girisler Oodle sikistirilmis, `giris_coz`
        cagrilmadan ID'ler baytta gorunmez. Ana oturumun ilk denemesi bu iki
        sebepten 0 vurus almisti.
    Dagilim: 9 doku tek govdeye ozel · 9 doku 14 govdenin hepsinde · gerisi arada.
    """
    # ⚠️ YALNIZ hull sekmesinde govde adiyla gruplanir. Govde sus gruplari birkac
    # DUMEN dokusuna da referans veriyor (WheelBase · MTX_Wheel_FireNaval ·
    # MTX_Wheel_AsianNaval); onlar Wheels sekmesinde `tier` bolumunde kalmali,
    # yoksa dumen listesi govde adlariyla dolardi. (Test T6 bunu yakaladi.)
    hy = hedef.get("hull_yuvalari")
    if hy and hedef.get("grup") == "hull":
        return list(hy)
    t = takim(hedef)
    return [t] if t else []


def takim(hedef):
    """Hedefin ait oldugu BOLUM -> gorunen ad, ya da None (duz liste).

    crew -> kiyafet takimi (ayni jetonu tasiyan parcalar oyunda ayni kiyafet)
    hull -> yuzey bolumu (dis kaplama / guverte / direk / kabin ...)
    digerleri -> None
    """
    grup = hedef.get("grup")
    ad = hedef.get("anahtar") or ""
    if grup == "crew":
        for jeton, gorunen in TAKIM_JETONLARI:
            if jeton in ad:
                return gorunen
        return "Standard"
    if grup in TIER_BOLUMU:
        t = hedef.get("tier") or ""
        return TIER_AD.get(t, "Other") if t else "Other"
    kural = BOLUM_KURALLARI.get(grup)
    if kural:
        kurallar, varsayilan = kural
        tam = hedef.get("ad") or ad      # bolum kurallari TAM ADA da bakar
        for jetonlar, gorunen in kurallar:
            if any(j in ad or j in tam for j in jetonlar):
                return gorunen
        return varsayilan
    return None


def parca(hedef):
    """Takim icindeki PARCA adi (Torso / Pants / Sash / Bandana / Bracer ...).

    Ad hem `Torso_S_JackdawPirates_X` hem `JackdawSkeletonCrew_MrBonesC_Torso`
    bicimlerinde geliyor -- ikisini de tanir.
    """
    ad = hedef.get("anahtar") or ""
    for p in ("InnerShirt", "Shirt", "Torso", "Pants", "Sash", "Bandana", "Bracer"):
        if p in ad:
            # "InnerShirt" once denenir, yoksa "Shirt" onu da yakalardi.
            # ⚠️ VARYANT HARFI: `Torso_S_JackdawPirates_A_EndGame_02` ve `_B_...`
            # ayni takimda ve ayni parca -> ikisi de "Torso" olsaydi klasorde
            # AYNI ADLA iki satir cikardi (tam da kacinilmak istenen karisiklik).
            # Test T2 bunu yakaladi; harf ada katiliyor.
            for v in ("_A_", "_B_", "_C_", "_D_"):
                if v in ad:
                    return "%s (%s)" % (p, v.strip("_"))
            return p
    return ad


def serbest_ad(klasor, kok, uzanti=".png"):
    """Henuz kullanilmayan bir dosya adi (Flag'in `_free_name`i, flag_engine.py:510).

    Ikinci kez export etmek, oyuncunun az once boyadigi tasarimin UZERINE
    yaziyordu. Numaralandirmak yelkenlerde yayinlanmis olan cozum.
    """
    aday = os.path.join(klasor, kok + uzanti)
    if not os.path.exists(aday):
        return aday
    n = 2
    while True:
        aday = os.path.join(klasor, "%s (%d)%s" % (kok, n, uzanti))
        if not os.path.exists(aday):
            return aday
        n += 1


def sablon_dizisi(hedef, lvl=0):
    """Kullaniciya GOSTERILECEK ve BOYATILACAK goruntu -> (RGB dizi, bilgi).

    🧨 KULLANICI SIKAYETI (2026-07-30): "bayragi cikarttigimda sadece kuru kafa
    cikiyor". Sebep: ham RGBA yaziliyordu. Bu dokularda desenin RENGI RGB'de,
    SEKLI ALFA'da. Her goruntuleyici/editor alfayi siyaha bindirdigi icin
    kullanici koyu zeminde tek bir kuru kafa goruyordu -- oysa oyunda gordugu sey
    desen dokusunun kendisi degil, sunun sonucu:
        lerp(taban_bez x ColorOverlay,  desen.rgb,  desen.a)

    Bu fonksiyon ALFASIZ bir RGB goruntu dondurur; iki yol da GIDIS-DONUS TAM:
      * politika 'opak'    -> KOMPOZIT (oyunda gorunen hal). Geri yazarken alfa
        255 olacagi icin oyun `lerp(taban, bizim_rgb, 1) = bizim_rgb` gosterir.
        Yani kullanici sablona hic dokunmazsa gorunum AYNI kalir; boyadigi yer
        aynen gorunur.
      * politika 'vanilla' -> HAM RGB (alfa atilir). Alfa vanilla'dan aynen
        korunacagi icin gorunum yine birebir korunur.
    Iki halde de PNG'de ALFA YOK -> kimse onu siyaha bindiremez.

    Kompozit cozulemezse (or. materyal bulunamadi) HAM RGB'ye duselir ve
    `bilgi["uyari"]` doldurulur -- sessiz gecme yok.
    """
    a, t = doku_dizisi(hedef, lvl)
    pol = alfa_politikasi(hedef, a[:, :, 3])
    bilgi = {"politika": pol, "yol": "rgb", "uyari": "", "cevrildi": cevirmeli(hedef),
             "alfa_ort": float(a[:, :, 3].mean())}
    if pol == "tasarim":
        # AMBLEM KATMANI: yelkenin uzerine biner. Kaptan hakli olarak "sadece
        # amblem olsun, altina yelken koymayalim" dedi -- kompozit burada YANLIS
        # yonlendirir (kullanici yelkeni de boyayabilecegini sanir).
        # Sablon amblemin KENDISI, ve ALFALI: sekil kullanicinin elinde olmali,
        # cunku alfa=255 yazmak amblemi butun yelkene yayardi.
        bilgi["yol"] = "amblem"
        bilgi["uyari"] = ("this is an EMBLEM layer that sits on top of the sail - "
                          "the alpha channel is its SHAPE. Keep the alpha when you "
                          "save, or the emblem will cover the whole sail.")
        return np.ascontiguousarray(a), bilgi
    if pol != "opak":
        return np.ascontiguousarray(a[:, :, :3]), bilgi
    try:
        import ship_kompozit as KOM        # DAIRESEL IMPORT'u onlemek icin tembel
        kom, kb = KOM.kompozit(hedef, a)
        bilgi["yol"] = kb.get("yol", "?")
        bilgi["tint"] = kb.get("tint")
        if kb.get("uyari"):
            bilgi["uyari"] = kb["uyari"]
        if bilgi["yol"] == "kompozit":
            return np.ascontiguousarray(kom), bilgi
        # kompozit uretilemedi: HAM RGB'ye dus ama SESSIZ GECME
        bilgi["uyari"] = (bilgi["uyari"] or
                          "could not build the in-game composite for this target")
    except Exception as e:
        bilgi["yol"] = "rgb"
        bilgi["uyari"] = "composite unavailable (%r)" % (e,)
    return np.ascontiguousarray(a[:, :, :3]), bilgi


def cikar(hedef, png_yolu, lvl=0):
    """Vanilla dokuyu PNG olarak disari yaz (tasarim sablonu).

    Sablon ALFASIZ RGB'dir -- bkz. `sablon_dizisi`. Eskiden ham RGBA yaziliyordu
    ve kullanici her goruntuleyicide "sadece kuru kafa" goruyordu.
    """
    a, t = doku_dizisi(hedef, lvl)
    rgb, sb = sablon_dizisi(hedef, lvl)
    os.makedirs(os.path.dirname(os.path.abspath(png_yolu)) or ".", exist_ok=True)
    # AMBLEM katmani 4 kanalli gelir (sekil alfada) -> RGBA yazilir.
    # Digerleri 3 kanalli -> ALFASIZ RGB (hicbir goruntuleyici siyaha bindiremesin).
    Image.fromarray(rgb, "RGBA" if rgb.shape[2] == 4 else "RGB").save(png_yolu)
    return {"yol": png_yolu, "w": rgb.shape[1], "h": rgb.shape[0], "fmt": t["aile"],
            "srgb": t["srgb"], "mipcount": t["mipcount"],
            "alfa_ort": float(a[:, :, 3].mean()),
            "cevrildi": cevirmeli(hedef),
            "sablon_yolu": sb["yol"], "politika": sb["politika"],
            "uyari": sb["uyari"]}


# ---------------------------------------------------------------- olcekleme (ALFA TUZAGI #2)
def olcekle(im_rgba, w, h):
    """RGBA goruntuyu olcekle -- RGB ve ALFA AYRI AYRI.

    🧨 OLCULMUS TUZAK (2026-07-29, Pillow 12.3): `Image.resize()` RGBA modda
    ALFA-AGIRLIKLI (premultiplied) yeniden orneklemeyi kullanir. AC4 gemi diffuse
    dokularinin alfasi ~0'dir (Wheel_Bronze: ort 0,106 / maks 4) -> tasarim
    kuculturken RGB SIYAHA COKER:
        1024 -> ort 79,99 | LANCZOS 512 -> 3,86 | 256 -> 2,21 | 64 -> 0,00
        (NEAREST etkilenmez: 79,98 -- ortalama almadigi icin)
    RGB kanallarini ALFASIZ olceklemek degeri birebir korur (79,99669 -> 79,99670).

    Bu, hafizadaki TexEncode alfa tuzaginin AYNI AILEDEN ama BASKA ARACTAKI hali.
    TexEncode'un kendisi masum: duz yesil 512x512, alfa=0 -> cozulen RGB 96,67;
    alfa=255 -> 96,67 (birebir ayni). Suclu Pillow'un resize'i.
    """
    if im_rgba.size == (w, h):
        return np.asarray(im_rgba, dtype=np.uint8).copy()
    a = np.asarray(im_rgba, dtype=np.uint8)
    rgb = np.asarray(Image.fromarray(a[:, :, :3], "RGB").resize((w, h), Image.LANCZOS))
    alf = np.asarray(Image.fromarray(a[:, :, 3], "L").resize((w, h), Image.LANCZOS))
    out = np.empty((h, w, 4), np.uint8)
    out[:, :, :3] = rgb
    out[:, :, 3] = alf
    return out


def _bagimsiz_kucult(a, w, h):
    """PIL'e HIC DOKUNMADAN alan-ortalamasiyla kucult (dogrulamanin bagimsiz referansi).
    Dogrulama, test edilen yolun kendi olcekleyicisini KULLANMAZ; yoksa ayni hata
    hem uretimi hem kaniti bozar (bu tam olarak 2026-07-29'da yasandi)."""
    H0, W0 = a.shape[:2]
    if (W0, H0) == (w, h):
        return a[:, :, :3].astype(np.float64)
    fy, fx = H0 // h, W0 // w
    if fy < 1 or fx < 1 or H0 % h or W0 % w:
        yi = (np.arange(h) * H0 // h)[:, None]
        xi = (np.arange(w) * W0 // w)[None, :]
        return a[yi, xi, :3].astype(np.float64)
    return a[:, :, :3].astype(np.float64).reshape(h, fy, w, fx, 3).mean(axis=(1, 3))


# ---------------------------------------------------------------- tasarim donusumu
# ---------------------------------------------------------------- ALFA POLITIKASI
# 🔬 OLCULDU (2026-07-30, uc bagimsiz mercek + hakem turu, oyuna tek bayt yazilmadan):
# Bu yuvalarda ALFA OPAKLIK DEGIL, desen katmaninin alt kumas uzerindeki KAPLAMA
# ORANI (maske). Sonuc yaklasik:
#       lerp(Base_01.rgb x ColorOverlay, Pattern.rgb, Pattern.a)
# Kanit zinciri:
#  1. 11 bayrak hedefinin tamami tek MaterialTemplate kullaniyor: `OBD_SHP_Sail_Opt`
#     (0x254ED7DD225). Template'in KENDI dize tablosundan crc32 ile turetilen
#     parametre seti tam 7 tanedir: Color Overlay (float4 tint), Weathering,
#     Detail Scale, HEALTH, Health Offset, Amplitude, SlackBias.
#     Icinde alfa / opaklik / blend modu / alfa-test esigi / TwoSided diye
#     **BIR TANE BILE** parametre YOK. (Addaki `_2S_AT` bir isim eki.)
#  2. `OBD_SHP_Sail_Pattern_Empty_DiffuseMap` 16x16 dokusunun alfasi HER pikselde 0,
#     RGB'si saf beyaz. Iki VANILLA bayrak (MT_Hunter kirmizi, PT_Jackdaw_Black siyah)
#     bu dokuyu desen yuvalarinin IKISINDE de kullaniyor -- alfa opaklik olsaydi
#     o iki bayrak oyunda TAMAMEN gorunmez olurdu. alfa=0 + RGB=beyaz, bir lerp'in
#     notr elemanidir.
#  3. Alfa kanali goruntu olarak render edilince birebir kuru kafa + capraz kemik
#     cikiyor; RGB'de ayni amblem ~1/6 kontrastla hayalet olarak var
#     (alfa std 67,51 - RGB luma std 11,93). Yani RGB = amblemin RENGI,
#     ALFA = amblemin SEKLI.
#  4. Kardes template `OBD_Tex_Multi_TextureProfile_Opt` bu rolu motorun kendi
#     sozlugunde `L1 Alpha is Mask` / `L2 Alpha is Mask` diye adlandiriyor.
#
# ⛔ SONUC: `alfa="vanilla"` bir bayrakta kullanicinin tasarimini VANILLA KURU KAFA
# SILUETINE HAPSEDER. Olculdu: duz bir tasarim + vanilla alfa ile tasarim renginde
# cikan piksel orani PT_Pirate_01'de **%3,05** (RMS hata 104,5), PT_QAR_01 %0,92,
# MT_Portuguese_01 %14,38. alfa=255 ile sadakat %100,00 / RMS 0,000.
# 🟢 Oyun ici kanit: 52 yayinlanmis bayrak modu (52/52 zip acildi, 156/156 giris
# cozuldu) tam bu ailenin iki yuvasina alfa ort **254,987** / (alfa==0) **%0,0000**
# yaziyor ve oyunda DOGRU gorunuyor.
#
# ⚠️ Kural HEDEF ADINA GOMULMEZ, icerikten turetilir. Olculen bosluk temiz:
# inert alfa std 0,000-2,671  |  sekil tasiyan 6,76-90,34.
ALFA_A0_ESIK = 0.20        # vanilla alfanin tam-sifir orani
ALFA_STD_ESIK = 3.0        # sekil tasiyor mu
ALFA_GRUPLARI = ("flag", "sail")   # SIKI kapsam: baska grup ASLA opak yazilmaz


def alfa_politikasi(hedef, van_a):
    """Bu hedefte alfa nasil yazilmali? van_a: vanilla **lvl0** alfa kanali (uint8).

    'opak'    -> yeni[:,:,3] = 255   (tasarim butun bayragi kaplar)
    'vanilla' -> vanilla alfa AYNEN korunur (maske tasimayan / paylasimli hedefler)

    Yazma yolu ve dogrulama kapisi AYNI fonksiyonu cagirir; boylece kapi urunden
    ayrisamaz (2026-07-29'da tam bu ayrisma bir kusuru gizlemisti).
    11 bayrak hedefinden 8'i atesler. Ateslemeyenler ve NEDEN:
      * Base_01              -- ALT KUMASIN kendisi, arkasinda katman yok; alfasi
                                surekli yipranma alani (%94,76 ara ton, a==0 %0).
                                SHARED: 159 statik kullanici. 52 modun hicbiri dokunmuyor.
      * MT_British_01        -- a==0 yalniz %0,309 (yipranma serpintisi), SHARED (67 geometri)
      * Emblem_MIT_Spanish_01 -- zaten ~opak (alfa 247..255), fark gorunmez
    """
    if not hedef or hedef.get("grup") not in ALFA_GRUPLARI:
        return "vanilla"
    # 🧨 GORUNMEZLIK TUZAGI (olculdu 2026-07-30, cipa alt siniri dusurulunce acildi).
    # Vanilla alfa HER PIKSELDE 0 ise, render formulu
    #     lerp(taban x tint, desen.rgb, desen.a)
    # desen.rgb'yi HIC katmaz. 'vanilla' politikasi bu alfayi aynen korudugu icin
    # kullanici hedefi boyar, uygular, oyunda HICBIR SEY DEGISMEZ -- ve arac ona
    # "basarili" der. Bu bir sessiz basarisizliktir.
    # Bu durumda tek anlamli karar opak yazmak: kullanici bu yuvayi bilerek
    # boyuyorsa "burada desen OLSUN" demek istiyordur.
    # 🔢 KAPSAM: 242 hedefin tam 2'si bu durumda -- `Empty` (yelken deseni kapatma
    #    yuvasi, 16x16 beyaz) ve `Bulk_Sail_Pattern_Empty`. Ikisi de zaten
    #    ATLAS/SHARED uyarisi tasiyor (Empty: 88 materyal, 440 geometri).
    #    Diger 240 hedefte bu dal HIC calismaz -> davranis degismez.
    if int(np.asarray(van_a).max()) == 0:
        return "opak"
    a0 = float((van_a == 0).mean())
    std = float(np.asarray(van_a, dtype=np.float64).std())
    if not (a0 >= ALFA_A0_ESIK and std >= ALFA_STD_ESIK):
        return "vanilla"
    # 🧨 KAPTAN YAKALADI (2026-07-30): "bu amblemlerin altina niye yelkenlerini
    # koyduk, sadece amblemler olsun". Sezgi HAKLIYDI ve altinda gercek bir kusur
    # vardi -- yalniz gorsel degil, YAZMA kusuru.
    # 🔢 OLCULDU: yelken AMBLEMLERI yelkenin USTUNE binen bir katman. Opak yazmak
    # amblemi BUTUN YELKENE yayar ve yelken bezini yok eder. Bayrakta ise yuzeyin
    # tamami zaten senin tasarimin -> opak DOGRU (52 yayinlanmis modla oyunda kanitli).
    #
    # ⚠️ AYIRT EDICI YUVA NUMARASI DEGIL. Ilk denememde "yuva 2 = amblem" dedim ve
    # kapi `PT_Jackdaw_Pirate_01`de dustu: o bir BAYRAK ama o da yuva 2'de.
    # Yuva 0'a bakmak da kirilgan. Dogru ayirt edici oyunun KENDI ADLANDIRMASI:
    #     `OBD_SHP_Sail_Emblem_*` -> alt_tur "emblem"  (15 hedef, hepsi yuva 2)
    #     `OBD_SHP_Flag_Pattern_*` / `Sail_Pattern_*` -> yuzey katmani
    # Amblemde sekil kullanicinin PNG'sinden gelir (`tasarim`), boylece hem rengi
    # hem seklini kendisi belirler.
    if hedef.get("alt_tur") == "emblem":
        return "tasarim"
    return "opak"


def vanilla_alfa_politikasi(hedef):
    """`alfa_politikasi`yi hedefin vanilla lvl0'ini okuyarak uygula (SALT-OKUNUR)."""
    if not hedef or hedef.get("grup") not in ALFA_GRUPLARI:
        return "vanilla"
    van0, _t = mip_oku(hedef["forge"], int(hedef["kapsayici"], 16),
                       int(hedef["id"], 16), 0)
    return alfa_politikasi(hedef, van0[:, :, 3])


def tasarim_donusumu(png_yolu, alfa="auto", cevir=False, hedef=None):
    """PNG tasarimini her mip seviyesine olceklendiren donusum uretir.

    alfa='auto' (VARSAYILAN): politika ICERIKTEN turetilir -> `alfa_politikasi`.
      Karar **lvl0'dan bir kez** verilir ve onbelleklenir; mip'ler arasi salinim
      olmaz. `hedef` verilmezse guvenli tarafa dusulur ('vanilla').
    alfa='opak'    : yeni[:,:,3] = 255  (tasarim butun yuzeyi kaplar)
    alfa='vanilla' : vanilla alfa kanali AYNEN korunur
    alfa='tasarim' : PNG'nin kendi alfasi maske olur (ileri seviye)
      ⚠️ 'tasarim' ve mip zinciri: TexEncode'un mip filtresi alfa-agirlikli, alfayi
      tasarimdan almak lvl1+ RGB'sini karartabilir. Bayraklarin 10'unda mipcount=1
      oldugu icin orada risk yok; cok mip'li hedeflerde sinanmadi.

    cevir=True: tasarim DIKEY CEVRILEREK arsiv yonune geri dondurulur.
      `cikar` bayrak/yelken sablonunu cevirerek verdigi icin (bkz. `cevirmeli`),
      geri yazarken AYNI cevirmenin tersi uygulanmak ZORUNDA. Cagiranlar bunu
      `cevir=M.cevirmeli(h)` diye gecer; iki taraftan biri atlanirsa doku
      oyunda bas asagi biner.
    """
    _acik = Image.open(png_yolu)
    _bantlar = _acik.getbands()
    kaynak = _acik.convert("RGBA")
    if cevir:
        kaynak = kaynak.transpose(Image.FLIP_TOP_BOTTOM)
    pol = vanilla_alfa_politikasi(hedef) if alfa == "auto" else alfa

    # 🧨 DUZLESTIRILMIS PNG KAPISI (olculdu 2026-07-30, denetim A3).
    # 'tasarim' politikasinda SEKIL kullanicinin alfasindan gelir. Kullanici PNG'yi
    # MS Paint'te acip kaydederse / JPEG turundan gecirirse / "flatten" yaparsa alfa
    # kanali kaybolur; `convert("RGBA")` sessizce 255 uydurur ve amblem OPAK yazilir.
    # Olculen sonuc: kaplama emblem_BlackSkull %10,83 -> %100 · British %22,65 -> %100
    # · Assassin %9,93 -> %100. Yani amblem BUTUN YELKENI orter ve yelken bezi yok olur.
    # Fail-closed ve KODLAMADAN ONCE: 13 dakikalik BC7 kodlamasi da bosa gitmez.
    if pol == "tasarim":
        _a = np.asarray(kaynak)[:, :, 3]
        if "A" not in _bantlar or int(_a.min()) == 255:
            raise RuntimeError(
                "this target needs the ALPHA channel of the exported PNG - it is the "
                "emblem's shape mask, not transparency.\n"
                "Your PNG %s.\n"
                "Writing it as-is would stretch the emblem over the WHOLE sail.\n\n"
                "Re-export the template and edit it in an app that keeps 32-bit PNG "
                "alpha (GIMP, Krita, Photoshop, Paint.NET). Windows Paint drops it."
                % ("has no alpha channel" if "A" not in _bantlar
                   else "has an alpha channel but it is fully opaque"))

    def donustur(a, lvl, w, h):
        yeni = olcekle(kaynak, w, h)          # RGB ve alfa AYRI olceklenir (tuzak #2)
        if pol == "vanilla":
            yeni[:, :, 3] = a[:, :, 3]
        elif pol == "opak":
            yeni[:, :, 3] = 255
        # 'tasarim' -> PNG'nin kendi alfasina DOKUNULMAZ
        return yeni

    donustur.kaynak_boyut = kaynak.size
    donustur.alfa_politikasi = pol
    return donustur


# ---------------------------------------------------------------- kodlayici (akitan)
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _kodla_dosya(png, dds, aile, srgb, adim_ilerleme=None):
    """TexEncode'u AKITARAK calistir.

    Neden `subprocess.run` degil:
      1. GUI `pythonw` ile calisiyor; konsolsuz bir surecten konsol uygulamasi
         baslatinca Windows ONA SIYAH BIR PENCERE aciyor. `CREATE_NO_WINDOW`
         bunu kapatir. (Kaptan 'apply'a basinca cikan siyah pencere buydu.)
      2. TexEncode `PROGRESS <yapilan> <toplam>` satirlari basiyor (piksel
         cinsinden, kendi mip zincirini de sayarak). Cikti beklenmeden okunursa
         gercek yuzde ve kalan sure verilebilir.
    """
    cmd = [HD.TEXENCODE, png, dds] + (["srgb"] if srgb else []) + [aile.lower()]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, bufsize=1, creationflags=NO_WINDOW,
                         cwd=os.path.dirname(HD.TEXENCODE))
    sesler = []
    for satir in p.stdout:
        satir = satir.strip()
        if not satir:
            continue
        if satir.startswith("PROGRESS "):
            b = satir.split()
            try:
                yapilan, toplam = int(b[1]), int(b[2])
            except (IndexError, ValueError):
                continue
            if adim_ilerleme and toplam > 0:
                adim_ilerleme(yapilan / float(toplam))
            continue
        if satir.startswith("STAGE "):
            continue
        sesler.append(satir)
    p.stdout.close()
    p.wait()
    if p.returncode != 0 or not os.path.isfile(dds) or os.path.getsize(dds) < 128:
        ayrinti = " ".join(s for s in sesler if s.startswith(("ERROR:", "inner:")))
        raise RuntimeError("texture encoder failed (exit %d): %s"
                           % (p.returncode, ayrinti or (sesler[-1] if sesler else "no output")))
    return dds


def kodlama_agirliklari(W, Hh, mipcount):
    """Her seviyenin GERCEK maliyeti (piksel).  TexEncode bir seviye istendiginde
    bile KENDI mip zincirini uretiyor ('Mip levels: N'), yani bir seviyenin
    maliyeti o seviyeden asagi tum zincir ~ 4/3 katidir. Olculdu:
    512²=26 sn · 1024²=106 sn · 2048²=304 sn (24 cekirdek, TexEncode zaten
    coklu is parcacikli -- seviyeleri PARALEL kodlamak kazanc VERMIYOR, olculdu)."""
    a = []
    for lvl in range(mipcount):
        w = max(1, W >> lvl); h = max(1, Hh >> lvl)
        a.append(w * h * 4.0 / 3.0)
    return a


# saniye / megapiksel - KABA on tahmin icin.
# 🔬 Genis dagilim olculdu: gurultu 2048² -> 75 sn/Mpx, gercek 512² bandana -> ~3,
# gercek 4096 BaseAtlas -> 27+. Icerik karmasikligi BC7 mod aramasini belirliyor.
# Bu yuzden EKRANDAKI kalan sure sabitle DEGIL, gecen sure/ilerleme oraniyla
# CANLI hesaplanir; bu sabit yalniz "bu is uzun surer mi" uyarisi icindir.
SANIYE_MPX = 27.0


def tahmini_sure(W, Hh, mipcount):
    return sum(kodlama_agirliklari(W, Hh, mipcount)) / 1e6 * SANIYE_MPX


# ---------------------------------------------------------------- mip kodlama (ORTAK)
def mip_kodla(forge, giris_fid, tex_id, donusum, gec, gunluk=None, ilerleme=None):
    """Bir dokunun TUM mip seviyelerini kodla -> ({lvl: siki_bayt}, doku_kaydi, rapor)

    Hem `patch_02 uret` (Strateji A) hem `yerinde yaz` (Strateji B/C) yollari BU
    fonksiyonu kullanir; kodlama kurallari tek yerde durur:
      * her seviye AYRI kodlanir (TexEncode'un alfa-agirlikli mip filtresi devre disi)
      * uretilen blok boyu vanilla ile BIREBIR ayni olmali, yoksa hata
      * 1x1 / 1xN seviyelerde TexEncode calismiyor -> vanilla blogu korunur
    """
    r = H.doku_bul(forge, giris_fid)
    d = [x for x in r["dokular"] if x["tex_id"] == tex_id]
    if not d:
        raise KeyError("entry 0x%X does not contain 0x%X" % (giris_fid, tex_id))
    d = d[0]
    t = d["tanim"]
    aile, blok, W, Hh = t["aile"], t["blok"], t["W"], t["H"]
    bek = HD.DXGI_BEKLENEN.get((aile, t["srgb"]))
    if bek is None:
        raise ValueError("unsupported format/srgb: %s/%s" % (aile, t["srgb"]))
    _r2, _d2, mp = HD.mip_zinciri_oku(forge, giris_fid, tex_id)
    mip, korunan = {}, []
    agirlik = kodlama_agirliklari(W, Hh, t["mipcount"])
    toplam_agirlik = sum(agirlik) or 1.0
    biten = 0.0
    for lvl in range(t["mipcount"]):
        w = max(1, W >> lvl); h = max(1, Hh >> lvl)
        tight = max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * blok
        a = H.bc_coz(mp[lvl]["veri"][:tight], w, h, aile)
        b = donusum(a, lvl, w, h)
        if min(w, h) < 2:
            mip[lvl] = mp[lvl]["veri"][:tight]
            korunan.append(lvl)
            biten += agirlik[lvl]
            if ilerleme:
                ilerleme(biten / toplam_agirlik, "level %d" % lvl)
            continue
        p = os.path.join(gec, "t%X_lvl%02d.png" % (tex_id & 0xFFFFF, lvl))
        Image.fromarray(b, "RGBA").save(p)
        dds = p[:-4] + ".dds"

        def adim(f, _lvl=lvl, _b=biten):
            if ilerleme:
                ilerleme((_b + agirlik[_lvl] * f) / toplam_agirlik,
                         "level %d (%dx%d)" % (_lvl, max(1, W >> _lvl), max(1, Hh >> _lvl)))
        _kodla_dosya(p, dds, aile, t["srgb"], adim_ilerleme=adim)
        biten += agirlik[lvl]
        if ilerleme:
            ilerleme(biten / toplam_agirlik, "level %d done" % lvl)
        mm, dW, dH, dxgi, dblok = H.dds_mipler(dds)
        if dxgi != bek:
            raise ValueError("lvl%d DXGI %d != %d" % (lvl, dxgi, bek))
        if (dW, dH) != (w, h) or dblok != blok:
            raise ValueError("lvl%d size/block mismatch" % lvl)
        if len(mm[0]["veri"]) != tight:
            raise ValueError("lvl%d length %d != %d" % (lvl, len(mm[0]["veri"]), tight))
        mip[lvl] = mm[0]["veri"]
        if gunluk:
            gunluk("      lvl%-2d %5dx%-5d encoded" % (lvl, w, h))
    rap = ["0x%X: %d levels encoded%s; alpha preserved from vanilla"
           % (tex_id, t["mipcount"] - len(korunan),
              (", lvl %s kept vanilla block" % korunan) if korunan else "")]
    return mip, d, r, rap


# ---------------------------------------------------------------- coklu doku / tek giris
def giris_uygula(forge, giris_fid, isler, gunluk=None, ilerleme=None):
    """Bir giristeki BIR VEYA DAHA COK dokuyu degistir.

    isler = [(tex_id, donusum)]
    -> dict(yeni_giris, ext, harici=[(fid, ext, bayt)], rapor=[...])

    hkm_doku.doku_degistir'in coklu-doku genellemesi; ayni degismezler:
      * her mip SEVIYE SEVIYE kodlanir (alfa tuzagi)
      * uretilen blok boyu vanilla ile BIREBIR ayni olmali
      * govde uzunlugu degismemeli (yoksa TOC/len bozulur)
    """
    rap = []
    r = H.doku_bul(forge, giris_fid)
    dilim = r["dilim"]
    harici = []
    gec = tempfile.mkdtemp(prefix="shipws_")
    try:
        for tex_id, donusum in isler:
            d = [x for x in r["dokular"] if x["tex_id"] == tex_id]
            if not d:
                raise KeyError("entry 0x%X does not contain 0x%X" % (giris_fid, tex_id))
            d = d[0]
            t = d["tanim"]
            aile, blok, W, Hh = t["aile"], t["blok"], t["W"], t["H"]
            bek = HD.DXGI_BEKLENEN.get((aile, t["srgb"]))
            if bek is None:
                raise ValueError("unsupported format/srgb: %s/%s" % (aile, t["srgb"]))

            # Kodlama TEK YERDE: `mip_kodla`. (Eskiden burada bir KOPYASI vardi;
            # akitan kodlayici/ilerleme oraya eklenince bu kopya geride kaliyordu.)
            mip, _d3, _r3, rap2 = mip_kodla(forge, giris_fid, tex_id, donusum, gec,
                                            gunluk=gunluk, ilerleme=ilerleme)
            rap.extend(rap2)

            # --- harici ham mip girisleri (pitch 256'ya hizali)
            for mid, sev, ext, ln, off in d["harici"]:
                w = max(1, W >> sev); h = max(1, Hh >> sev)
                bw = max(1, (w + 3) // 4); bh = max(1, (h + 3) // 4)
                rowbytes = bw * blok
                pitch = H.hizala(rowbytes, 256)
                src = mip[sev]
                buf = bytearray()
                for y in range(bh):
                    buf += src[y * rowbytes:(y + 1) * rowbytes] + b"\x00" * (pitch - rowbytes)
                if len(buf) != ln:
                    raise ValueError("external mip%d length %d != %d" % (sev, len(buf), ln))
                harici.append((mid & 0xFFFFFFFFFFFFFFFF, ext & 0xFFFFFFFF, bytes(buf)))
                rap.append("  external mip%d 0x%X %dx%d %d B" % (sev, mid & 0xFFFFFFFFFFFFFFFF,
                                                                 w, h, ln))

            # --- gomulu havuz: orijinali temel al, yalniz mip satirlarini ez (dolgu korunur)
            ic = bytearray(dilim[d["sira"]][1])
            hb, hl = d["cipa"][1], d["cipa"][2]
            havuz = bytearray(ic[hb:hb + hl])
            for lvl, o, pitch, satir, rowbytes in d["gomulu"]:
                src = mip[lvl]
                for y in range(satir):
                    havuz[o + y * pitch: o + y * pitch + rowbytes] = \
                        src[y * rowbytes:(y + 1) * rowbytes]
            ic[hb:hb + hl] = havuz
            dilim[d["sira"]][1] = ic
            if d["gomulu"]:
                rap.append("  embedded pool @%d (%d B), lvl %d..%d written"
                           % (hb, hl, d["gomulu"][0][0], d["gomulu"][-1][0]))
    finally:
        shutil.rmtree(gec, ignore_errors=True)

    yeni_govde = b"".join(bytes(x[1]) for x in dilim)
    if len(yeni_govde) != len(r["coz"]["govde"]):
        raise ValueError("body length changed! (%d != %d)"
                         % (len(yeni_govde), len(r["coz"]["govde"])))
    yeni_giris = H.giris_kur(r["coz"]["k1"], yeni_govde)
    rap.append("entry rebuilt: %d B (Form T / STORED)" % len(yeni_giris))
    return {"yeni_giris": yeni_giris, "ext": r["ext"], "harici": harici,
            "rapor": rap, "vanilla": r}


# ---------------------------------------------------------------- forge uret
def uret(secimler, cikti_klasor, mod_ad="ShipWorkshop", sistem_kaynak=None, gunluk=print,
         ilerleme=None, alfa="auto"):
    """secimler = [(hedef_dict, tasarim_png)] -> yeni DataPC_boot_patch_02.forge

    Ayni giriste birden cok hedef varsa TEK girise birlestirilir.
    Farkli forge'lardan hedef secilirse HATA verir (bir mod tek forge'u golgeler).

    alfa: 'auto' (icerikten turet) | 'opak' | 'vanilla' | 'tasarim' -> `alfa_politikasi`.
      ⛔ Eskiden bu parametre HIC YOKTU ve `tasarim_donusumu` varsayilanla ('vanilla')
      cagriliyordu; yani GUI ve CLI kullanicisi vanilla kuru kafa siluetine KILITLIYDI.
    """
    if not secimler:
        raise ValueError("nothing selected")
    forgelar = {h["forge"] for h, _ in secimler}
    if len(forgelar) > 1:
        raise ValueError("One mod can only draw from one source forge. Selected: %s\n"
                         "(Different forges need separate mod files; they can be merged "
                         "afterwards with the Mod Combiner.)" % sorted(forgelar))
    kaynak_forge = forgelar.pop()
    hedef_ad = kaynak_forge.replace(".forge", "_patch_02.forge")
    if "_patch_" in kaynak_forge:                    # zaten patch ise ust slot yine patch_02
        hedef_ad = kaynak_forge.split("_patch_")[0] + "_patch_02.forge"

    gunluk("source forge : %s" % kaynak_forge)
    gunluk("output name  : %s" % hedef_ad)
    if not kaynak_forge.startswith("DataPC_boot"):
        gunluk("!" * 88)
        gunluk("CAUTION: this target lives in %s, so the slot would be '%s'."
               % (kaynak_forge, hedef_ad))
        gunluk("         The only patch slot PROVEN to work in game is DataPC_boot_patch_02.")
        gunluk("         This slot has NEVER been tested -> do not publish without a game test.")
        gunluk("!" * 88)

    # --- girise gore grupla
    gruplar = {}
    for h, png in secimler:
        gruplar.setdefault(int(h["kapsayici"], 16), []).append((h, png))

    kayitlar = []
    rapor = []
    for giris_fid, uyeler in gruplar.items():
        adlar = ", ".join(u[0]["anahtar"] for u in uyeler)
        gunluk("  entry 0x%X  <- %s" % (giris_fid, adlar))
        isler = [(int(h["id"], 16),
                  tasarim_donusumu(png, alfa=alfa, cevir=cevirmeli(h), hedef=h))
                 for h, png in uyeler]
        s = giris_uygula(kaynak_forge, giris_fid, isler, gunluk=gunluk, ilerleme=ilerleme)
        kayitlar.append((giris_fid, s["ext"], s["yeni_giris"]))
        kayitlar.extend((mid, ext, veri) for mid, ext, veri in s["harici"])
        rapor.extend(s["rapor"])

    # --- KURAL #3: sistem girisleri
    sis, sis_bilgi = sistem_girisleri(sistem_kaynak)
    var = {k[0] for k in kayitlar}
    for fid, ext, ham in sis:
        if fid not in var:
            kayitlar.append((fid, ext, ham))
    gunluk("  system entries: %s  <- %s" % ([hex(s) for s in SISTEM_IDLER],
                                            os.path.basename(os.path.dirname(sis_bilgi["kaynak"]))))

    kayitlar.sort(key=lambda k: k[0])
    yol = os.path.join(cikti_klasor, hedef_ad)
    meta = H.forge_kur(yol, kayitlar, sablon_forge=os.path.join(H.OYUN, kaynak_forge))
    gunluk("  written: %s  (%d entries, %d B)" % (yol, meta["giris"], meta["boyut"]))

    bilgi = {
        "mod": mod_ad, "tarih": time.strftime("%Y-%m-%d %H:%M:%S"),
        "kaynak_forge": kaynak_forge, "cikti": yol, "forge": meta,
        "sistem": sis_bilgi,
        "hedefler": [{"id": h["id"], "ad": h["ad"], "anahtar": h["anahtar"],
                      "kisa_ad": h["kisa_ad"],
                      "grup": h["grup"], "kapsayici": h["kapsayici"],
                      "scope_sinif": h["scope_sinif"], "uyari": h["uyari"],
                      # Kullanilan alfa politikasi kayda GECER: dogrulama kapisi
                      # niyeti degil URUNU test etsin, ve kullanici sonradan
                      # mod_bilgi.json'a bakip ne yazildigini gorebilsin.
                      "alfa_politikasi": (alfa if alfa != "auto"
                                          else vanilla_alfa_politikasi(h)),
                      "tasarim": os.path.abspath(png)} for h, png in secimler],
        "rapor": rapor,
    }
    json.dump(bilgi, open(os.path.join(cikti_klasor, "mod_bilgi.json"), "w",
                          encoding="utf-8"), ensure_ascii=False, indent=1)
    return bilgi


# ---------------------------------------------------------------- URETILEN forge'dan geri okuma
def _tm_ic_bul(dilim, tex_id):
    for i, (fid, veri) in enumerate(dilim):
        tms = H.tm_bloklari(bytes(veri))
        if tms and tms[0][1] == tex_id:
            return i, bytes(veri), tms[0][0]
    raise KeyError("the rebuilt entry does not contain texture 0x%X" % tex_id)


def doku_coz_forgeden(yol, giris_fid, tex_id, lvl=0, harici_sayisi=None):
    """URETTIGIMIZ forge dosyasindan dokuyu SIFIRDAN geri coz -> RGBA ndarray.

    Kanit loga degil, COZULMUS PIKSELE bakilarak alinir ([[ac4-mod-guvenlik-kurallari]]).
    Katalog kullanmaz; yalnizca dosyanin kendi TOC'unu okur.
    """
    d, meta = H.forge_oku_hepsi(yol)
    if giris_fid not in d:
        raise KeyError("the produced forge has no entry 0x%X" % giris_fid)
    c = H.giris_coz_tam(d[giris_fid][0])
    dilim = H.ic_dilimle(c["govde"], c["icler"])
    _i, veri, hdr = _tm_ic_bul(dilim, tex_id)
    t = H.tanim_oku(veri, hdr)
    W, Hh, blok, aile = t["W"], t["H"], t["blok"], t["aile"]
    w = max(1, W >> lvl); h = max(1, Hh >> lvl)
    bw = max(1, (w + 3) // 4); bh = max(1, (h + 3) // 4)
    rowbytes = bw * blok
    pitch = H.hizala(rowbytes, 256)

    if harici_sayisi is None:                       # kac seviye harici duruyor?
        harici_sayisi = 0
        while H.mip_fid(tex_id, harici_sayisi) in d:
            harici_sayisi += 1

    if lvl < harici_sayisi:
        ham = d[H.mip_fid(tex_id, lvl)][0]
    else:
        cipa = H.cipa_bul(veri, hdr, len(veri))
        if not cipa:
            raise ValueError("embedded pool anchor not found")
        yer, _tp = H.yerlesim(W, blok, harici_sayisi, cipa[2], Hh)
        havuz = veri[cipa[1]: cipa[1] + cipa[2]]
        kayit = [y for y in yer if y[0] == lvl]
        if not kayit:
            raise KeyError("lvl%d is not in the embedded pool" % lvl)
        _l, o, pitch, satir, rowbytes = kayit[0]
        ham = havuz[o: o + pitch * satir]

    siki = bytearray()
    for y in range(bh):
        siki += ham[y * pitch: y * pitch + rowbytes]
    return H.bc_coz(bytes(siki), w, h, aile), t


def _fark(a, b):
    x = np.abs(a[:, :, :3].astype(np.int16) - b[:, :, :3].astype(np.int16))
    return float(x.mean()), float(np.abs(a[:, :, 3].astype(np.int16) -
                                         b[:, :, 3].astype(np.int16)).mean())


# ---------------------------------------------------------------- gidis-donus dogrulama
def dogrula(bilgi, gunluk=print):
    """URETILEN forge'u SIFIRDAN oku; dokular gercekten degismis mi, dokunulmayanlar
    bayt birebir mi? Kural #1: bu gecmeden hicbir sey kurulmaz."""
    yol = bilgi["cikti"]
    kaynak_forge = bilgi["kaynak_forge"]
    d, meta = H.forge_oku_hepsi(yol)
    sonuc = {"giris": meta["giris"], "kontrol": [], "gecti": True}

    def kaydet(ad, ok, ayrinti=""):
        sonuc["kontrol"].append({"ad": ad, "ok": bool(ok), "ayrinti": ayrinti})
        if not ok:
            sonuc["gecti"] = False
        gunluk("   %s %s %s" % ("OK    " if ok else "FAILED", ad, ayrinti))

    kaydet("system entries (5)", all(s in d for s in SISTEM_IDLER),
           " ".join(hex(s) for s in SISTEM_IDLER))

    for h in bilgi["hedefler"]:
        gid = int(h["kapsayici"], 16); tid = int(h["id"], 16)
        # Uretimde KULLANILAN politika; kayitta yoksa ayni fonksiyonla turetilir.
        alfa_pol = h.get("alfa_politikasi") or vanilla_alfa_politikasi(h)
        if gid not in d:
            kaydet("entry present: %s" % h["anahtar"], False)
            continue
        # 1) uretilen giris kendi basina cozulebiliyor mu
        try:
            c = H.giris_coz_tam(d[gid][0])
            icler = c["icler"]
        except Exception as e:
            kaydet("entry decodes: %s" % h["anahtar"], False, repr(e)[:80])
            continue
        v = H.doku_bul(kaynak_forge, gid)
        kaydet("same internal file count: %s" % h["anahtar"],
               len(icler) == len(v["coz"]["icler"]),
               "%d/%d" % (len(icler), len(v["coz"]["icler"])))
        kaydet("K1 header identical: %s" % h["anahtar"], c["k1"] == v["coz"]["k1"])

        # 2) hedef doku GERCEKTEN degisti mi, digerleri DEGISMEDI mi
        vdilim = H.ic_dilimle(v["coz"]["govde"], v["coz"]["icler"])
        ydilim = H.ic_dilimle(c["govde"], icler)
        hedef_sira = [x["sira"] for x in v["dokular"] if x["tex_id"] == tid]
        degisen = [i for i in range(len(vdilim))
                   if bytes(vdilim[i][1]) != bytes(ydilim[i][1])]
        kaydet("only the target file changed: %s" % h["anahtar"],
               degisen == hedef_sira, "changed=%s target=%s" % (degisen, hedef_sira))

        # 2b) HAVUZ DISINDAKI HER BAYT VANILLA ILE AYNI MI?
        # Bu kapi 2026-07-29'da eksikti ve `cipa_bul`un 57 bayt kaymis cipasini
        # KACIRDI: yazma havuzun disina tasip girisin bir kismini eziyordu, ama
        # okuma da ayni kaymayi kullandigi icin piksel testi "gecti" diyordu.
        for x in v["dokular"]:
            if x["tex_id"] != tid or not x["cipa"]:
                continue
            hb, hl = x["cipa"][1], x["cipa"][2]
            van_ic = bytes(vdilim[x["sira"]][1])
            biz_ic = bytes(ydilim[x["sira"]][1])
            kaydet("ic dosya boyu ayni: %s" % h["anahtar"],
                   len(van_ic) == len(biz_ic), "%d/%d" % (len(biz_ic), len(van_ic)))
            kaydet("havuz DISI baytlar dokunulmadi: %s" % h["anahtar"],
                   van_ic[:hb] == biz_ic[:hb] and van_ic[hb + hl:] == biz_ic[hb + hl:],
                   "havuz %d..%d" % (hb, hb + hl))
            kaydet("havuz ic dosyanin SONUNDA bitiyor: %s" % h["anahtar"],
                   hb + hl == len(van_ic), "%d / %d" % (hb + hl, len(van_ic)))

        # 3) harici mip girisleri boy olarak birebir mi
        for x in v["dokular"]:
            if x["tex_id"] != tid:
                continue
            for mid, sev, ext, ln, off in x["harici"]:
                m = mid & 0xFFFFFFFFFFFFFFFF
                kaydet("external mip%d 0x%X: %s" % (sev, m, h["anahtar"]),
                       m in d and len(d[m][0]) == ln,
                       "%d B" % (len(d[m][0]) if m in d else -1))

        # 4) PIKSEL KANITI - uretilen forge'dan geri coz, tasarimla ve vanilla ile karsilastir
        tanim = [x["tanim"] for x in v["dokular"] if x["tex_id"] == tid][0]
        # Tasarim dosyasi KULLANICI yonunde; forge'dan cozulen `bizim` ARSIV
        # yonunde. Bayrak/yelkende referans da cevrilmek zorunda, yoksa
        # "matches design (RGB)" ve "brightness preserved" kapilari 50 hedefte
        # yanlislikla patlar ve dogru urun HATALI diye reddedilir.
        _tas_im = Image.open(h["tasarim"]).convert("RGBA")
        if cevirmeli(h):
            _tas_im = _tas_im.transpose(Image.FLIP_TOP_BOTTOM)
        tas_ham = np.asarray(_tas_im, dtype=np.uint8)
        mc = tanim["mipcount"]
        seviyeler = sorted({0, 1, mc // 2, mc - 1} & set(range(mc)))
        for lvl in seviyeler:
            try:
                bizim, _t = doku_coz_forgeden(yol, gid, tid, lvl)
                van, _t2 = mip_oku(kaynak_forge, gid, tid, lvl)
            except Exception as e:
                kaydet("pixels lvl%d: %s" % (lvl, h["anahtar"]), False, repr(e)[:90])
                continue
            w, hh = bizim.shape[1], bizim.shape[0]
            # REFERANS PIL'SIZ URETILIR: uretim yolunun olcekleyicisi kullanilirsa
            # ayni hata hem urunu hem kaniti bozar (2026-07-29'da birebir yasandi).
            ref = _bagimsiz_kucult(tas_ham, w, hh)
            biz_f = bizim[:, :, :3].astype(np.float64)
            d_tas_rgb = float(np.abs(biz_f - ref).mean())
            d_van_rgb, d_van_a = _fark(bizim, van)
            if min(w, hh) < 2:
                # TexEncode 1x1/1xN'de calismiyor -> bu seviyede VANILLA blogu bilerek
                # korunur. Beklenen sey "degismis" degil, "birebir ayni".
                kaydet("lvl%d vanilla block kept (expected): %s" % (lvl, h["anahtar"]),
                       d_van_rgb == 0.0, "diff %.2f" % d_van_rgb)
                continue
            kaydet("lvl%d matches design (RGB): %s" % (lvl, h["anahtar"]),
                   d_tas_rgb < 12.0, "mean diff %.2f/255" % d_tas_rgb)
            # KARARMA KAPISI: mip zincirinin parlakligi tasarimla ayni kalmali.
            # Alfa-agirlikli olcekleme hatasi tam burada kendini gosterir.
            kaydet("lvl%d brightness preserved: %s" % (lvl, h["anahtar"]),
                   abs(biz_f.mean() - ref.mean()) < 8.0,
                   "ours %.1f / design %.1f" % (biz_f.mean(), ref.mean()))
            kaydet("lvl%d DIFFERS from vanilla: %s" % (lvl, h["anahtar"]),
                   d_van_rgb > 1.0, "mean diff %.2f/255" % d_van_rgb)
            # ALFA KAPISI politikaya gore. ⚠️ Kapi KALDIRILMADI, yeniden tanimlandi:
            # 'opak' politikada alfa kaymasi tanim geregi 216-241/255 olur ve eski
            # `< 3.0` esigi her seferinde duserdi. Kapiyi gevsetmek yerine POLITIKAYI
            # olcuyoruz -- ve ayni `alfa_politikasi` fonksiyonunu yazma yolu da
            # kullandigi icin kapi urunden ayrisamaz.
            if alfa_pol == "opak":
                # (a) politika gercekten UYGULANDI mi? BC7 sabit-255 alfada bile
                #     kayiplidir: 52 yayinlanmis modun olculen tabani ort 254,987 / min 247.
                biz_a = bizim[:, :, 3]
                kaydet("lvl%d ALPHA opaque by policy: %s" % (lvl, h["anahtar"]),
                       float(biz_a.mean()) >= 250.0 and float((biz_a >= 230).mean()) >= 0.999,
                       "alpha mean %.3f, >=230 %.4f%%"
                       % (biz_a.mean(), 100.0 * (biz_a >= 230).mean()))
                # (b) KAZAYLA vanilla kalmadigi: bu sinifta vanilla ort 14-38,
                #     dolayisiyla kayma 50'nin uzerinde olmak ZORUNDA.
                kaydet("lvl%d ALPHA intentionally differs from vanilla: %s"
                       % (lvl, h["anahtar"]), d_van_a > 50.0,
                       "alpha drift %.3f/255 (vanilla mean %.3f)"
                       % (d_van_a, van[:, :, 3].mean()))
            else:
                kaydet("lvl%d ALPHA preserved: %s" % (lvl, h["anahtar"]),
                       d_van_a < 3.0, "alpha drift %.3f/255" % d_van_a)
    return sonuc
