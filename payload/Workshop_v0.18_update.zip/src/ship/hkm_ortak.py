# -*- coding: utf-8 -*-
"""HKM = Hizli Kazanim Modlari — ortak kutuphane.

Kurallar (F6):
  * Oyun dosyalari YALNIZ "rb" ile acilir. Bu dosyada "r+b"/"wb" ile oyun yolu ACILMAZ.
  * Uretilen her sey deneme_modlar\\ altina yazilir.
  * Her cikti bayt-duzeyi gidis-donus dogrulamasindan gecer.

Icerik:
  Forge okuma (salt-okunur)  -> giris_bul / giris_ham
  Giris cozme               -> giris_coz_tam  (K1 ham baytlari + ic dosya listesi + K2 govde)
  Giris KURMA               -> giris_kur      (Form T / STORED — vanilla uyumlu)
  Forge KURMA               -> forge_kur      (patch_02 tarzi tek dosya)
  Dogrulama                 -> forge_oku_hepsi (uretilen forge'u SIFIRDAN, katalogsuz oku)
                            -> bayt_fark / araliklar (orijinalle bayt bayt diff)
"""
import os, sys, struct, zlib, hashlib
try:
    import sqlite3
except ImportError:                       # gomulu Python'da yok
    sqlite3 = None

_DOK = os.path.dirname(os.path.abspath(__file__))
if _DOK not in sys.path:
    sys.path.insert(0, _DOK)
import dokulib as D  # noqa: E402  (oodle + lz4 + BMS cozucu)

OYUN    = D.GAME
KATALOG = D.KATALOG
BMS     = D.BMS
BLOK    = 0x40000            # 262144 — vanilla blok boyu

# ---------------------------------------------------------------- salt-okunur okuma

def _db():
    return sqlite3.connect(KATALOG)


def giris_bul(forge, fid):
    """-> (off, len, ext) ya da None"""
    r = _db().execute("select off,len,ext from girisler where forge=? and id=?",
                      (forge, fid)).fetchone()
    return r


def zincir(fid):
    """fid'in TUM forge'lardaki kopyalari (MOD_ALTYAPISI kural #6)."""
    return list(_db().execute(
        "select forge,off,len,ext from girisler where id=? order by forge", (fid,)))


def giris_ham(forge, fid):
    """Oyun forge'undan girisin ham baytlari. SALT-OKUNUR."""
    off, ln, ext = giris_bul(forge, fid)
    with open(os.path.join(OYUN, forge), "rb") as f:
        f.seek(off)
        d = f.read(ln)
    assert len(d) == ln
    return d, off, ln, ext & 0xFFFFFFFF


def mipler(forge, ana_fid):
    return list(_db().execute(
        "select id,seviye,ext,len,off from mipler where forge=? and ana_fid=? order by seviye",
        (forge, ana_fid)))


# ---------------------------------------------------------------- giris cozme

def blok_listesi(raw, off):
    """Bir BMS konteynerini ACMADAN haritalar -> (bloklar, sonraki_off, ver, algo, bayrak)
    blok = (dec_off, ham_boy, ham_dosya_off, sikisik_boy)"""
    if raw[off:off + 8] != BMS:
        raise ValueError("BMS yok @%d" % off)
    ver, algo = struct.unpack_from("<HB", raw, off + 8)
    bayrak = struct.unpack_from("<I", raw, off + 11)[0]
    p = off + 15
    bloklar, dec = [], 0
    if bayrak >> 31:
        cnt = struct.unpack_from("<I", raw, p)[0]; p += 4
        boy = []
        for _ in range(cnt):
            u, c = struct.unpack_from("<II", raw, p); p += 8
            boy.append((u, c))
        for u, c in boy:
            p += 4                       # adler
            bloklar.append((dec, u, p, c)); dec += u; p += c
    else:
        while p < len(raw) and raw[p:p + 8] != BMS:
            isc = raw[p]; p += 1
            if isc:
                c, u = struct.unpack_from("<iI", raw, p); p += 8
                p += 4
                bloklar.append((dec, u, p, c)); dec += u; p += c
            else:
                sz = struct.unpack_from("<i", raw, p)[0]; p += 4
                bloklar.append((dec, sz, p, sz)); dec += sz; p += sz
    return bloklar, p, ver, algo, bayrak


def _ac(raw, bloklar, algo):
    out = bytearray()
    for dof, u, cof, c in bloklar:
        v = raw[cof:cof + c]
        out += v if u == c else D.blok_ac(algo, v, u)
    return bytes(out)


def giris_coz_tam(raw):
    """Ham giris -> dict(k1, icler, govde, k1_meta, k2_meta)
    k1        : K1 konteynerinin ACILMIS baytlari (ic dosya tablosu)
    icler     : [(ic_fid, ic_len)]
    govde     : K2 konteyner(ler)inin ACILMIS toplam baytlari
    *_meta    : (ver, algo, bayrak, blok_sayisi, [(u,c)...])
    """
    b0, p1, v0, a0, f0 = blok_listesi(raw, 0)
    k1 = _ac(raw, b0, a0)
    k1_meta = (v0, a0, f0, [(u, c) for _, u, _, c in b0])
    govde = bytearray(); k2_meta = []
    while p1 < len(raw) and raw[p1:p1 + 8] == BMS:
        bb, p1, v, a, fl = blok_listesi(raw, p1)
        govde += _ac(raw, bb, a)
        k2_meta.append((v, a, fl, [(u, c) for _, u, _, c in bb]))
    kuyruk = raw[p1:]
    return {"k1": k1, "icler": D.ic_liste(k1), "govde": bytes(govde),
            "k1_meta": k1_meta, "k2_meta": k2_meta, "kuyruk": kuyruk}


def ic_dilimle(govde, icler):
    out, p = [], 0
    for fid, ln in icler:
        out.append([fid, bytearray(govde[p:p + ln])]); p += ln
    return out


# ---------------------------------------------------------------- giris KURMA (Form T / STORED)

def _formT_stored(veri, ver=3, algo=8):
    """Vanilla'nin kullandigi TEK blok formu: bit31 SET, parca tablosu + adler.
    STORED => hamBoy == sikiBoy, hicbir sikistirici gerekmez."""
    parcalar = [veri[i:i + BLOK] for i in range(0, len(veri), BLOK)] or [b""]
    out = bytearray(BMS)
    out += struct.pack("<HB", ver, algo)
    out += struct.pack("<I", 0x80000000 | BLOK)
    out += struct.pack("<I", len(parcalar))
    for p in parcalar:
        out += struct.pack("<II", len(p), len(p))     # ham == siki  -> STORED
    for p in parcalar:
        out += struct.pack("<I", zlib.adler32(p, 0) & 0xFFFFFFFF)   # DIKKAT: baslangic 0
        out += p
    return bytes(out)


def giris_kur(k1, govde, ver=3, algo=8):
    """K1 + K2 -> ham giris baytlari (her ikisi de Form T / STORED)."""
    return _formT_stored(k1, ver, algo) + _formT_stored(govde, ver, algo)


# ---------------------------------------------------------------- forge KURMA

def forge_kur(yol, kayitlar, sablon_forge=None, hiza=4096):
    """kayitlar = [(fid, ext, ham_giris_baytlari)]  ->  patch_02 tarzi forge dosyasi.

    Basligin ilk 1050 baytini bir sablondan (vanilla forge) aynen aliriz; boylece
    'scimitar\\0' + surum + hdrOff + rezerv alanlari bire bir vanilla ile ayni olur.
    """
    if sablon_forge is None:
        sablon_forge = os.path.join(OYUN, "DataPC_boot_patch_01.forge")
    with open(sablon_forge, "rb") as f:          # SALT-OKUNUR
        bas = f.read(1050)
    assert bas[:9] == b"scimitar\x00", bas[:9]
    assert struct.unpack_from("<I", bas, 9)[0] == 50
    assert struct.unpack_from("<q", bas, 13)[0] == 1050

    govde = bytearray(); toc = []
    off = 1070                                   # hdrOff + 20
    for fid, ext, ham in kayitlar:
        toc.append((off, fid, len(ham), ext)); off += len(ham)
        govde += ham
    tocpos = off

    out = bytearray(bas)
    out += struct.pack("<I", len(kayitlar))
    out += struct.pack("<q", tocpos)
    out += b"\xff" * 8
    assert len(out) == 1070, len(out)
    out += govde
    assert len(out) == tocpos
    for o, fid, ln, ext in toc:
        out += struct.pack("<QQII", o, fid, ln, ext)
    dolgu = (-len(out)) % hiza                   # hesaplanmis hizalama (kopyalanmis sihirli sayi DEGIL)
    out += b"\x00" * dolgu

    os.makedirs(os.path.dirname(yol), exist_ok=True)
    with open(yol, "wb") as f:
        f.write(bytes(out))
    return {"yol": yol, "boyut": len(out), "tocpos": tocpos, "giris": len(kayitlar),
            "dolgu": dolgu, "sha256": hashlib.sha256(bytes(out)).hexdigest()}


def forge_oku_hepsi(yol):
    """Kendi urettigimiz forge'u SIFIRDAN, katalogsuz oku -> {fid: (ham, ext)}"""
    d = open(yol, "rb").read()
    assert d[:9] == b"scimitar\x00"
    hdr = struct.unpack_from("<q", d, 13)[0]
    n = struct.unpack_from("<I", d, hdr)[0]
    tocpos = struct.unpack_from("<q", d, hdr + 4)[0]
    out = {}
    for i in range(n):
        o, fid, ln, ext = struct.unpack_from("<QQII", d, tocpos + 24 * i)
        out[fid] = (d[o:o + ln], ext)
    return out, {"giris": n, "tocpos": tocpos, "boyut": len(d)}


# ---------------------------------------------------------------- dogrulama

def bayt_fark(a, b):
    """-> [(ofset, eski, yeni)] ; uzunluk farkliysa ValueError"""
    if len(a) != len(b):
        raise ValueError("uzunluk farkli: %d != %d" % (len(a), len(b)))
    return [(i, a[i], b[i]) for i in range(len(a)) if a[i] != b[i]]


def araliklar(farklar):
    """bitisik ofsetleri araliklara topla -> [(bas, uzunluk)]"""
    out = []
    for i, _, _ in farklar:
        if out and out[-1][0] + out[-1][1] == i:
            out[-1][1] += 1
        else:
            out.append([i, 1])
    return [tuple(x) for x in out]


# ====================================================================== DOKU KATMANI
# (doku_enjekte2.py'deki OLCULMUS sabitler/yerlesim kurallari — saf fonksiyonlar,
#  hicbiri yazma yapmaz)

TEXTUREMAP     = 0xA2B7E917
TEXTURESET     = 0xD70E6670
TEXTUREMAPSPEC = 0x989DC6B2
MIP_EXT        = 0x4C8BD3BF          # harici ham mip girisinin sinif crc'si

ENUM_AILE = {0x02: "BC1", 0x03: "BC1", 0x05: "BC3", 0x0A: "BC7"}
AILE_BLOK = {"BC1": 8, "BC2": 16, "BC3": 16, "BC4": 8, "BC5": 16, "BC6H": 16, "BC7": 16}
DXGI_AILE = {71: "BC1", 72: "BC1", 74: "BC2", 77: "BC3", 78: "BC3", 98: "BC7", 99: "BC7"}


# Gomulu piksel havuzunun YAPISAL sabitleri (olculdu 2026-07-30, bkz. cipa_bul):
#   HIZA      = her mip toplaminin yuvarlandigi kuantum (`yerlesim` icinde de kullanilir)
#   ALT_SINIR = bir havuzun alabilecegi EN KUCUK gecerli uzunluk (= tek mip, hizali)
HIZA      = 512
ALT_SINIR = 512


def hizala(x, a=256):
    return ((x + a - 1) // a) * a


def tm_bloklari(res):
    """TextureMap tanimlayicilarini sirayla bul -> [(hdr_off, texture_id)]"""
    pat = struct.pack("<I", TEXTUREMAP); out = []
    i = res.find(pat)
    while i >= 0:
        if i >= 9 and i + 5 <= len(res) and res[i + 4] == 0x01:
            g = struct.unpack_from("<Q", res, i - 8)[0]
            if 0x10000000 < g < 0xFFFFFFFFFFFFF:
                out.append((i - 9, g))
        i = res.find(pat, i + 1)
    return sorted(out)


def tanim_oku(res, hdr):
    W  = struct.unpack_from("<I", res, hdr + 14)[0]
    Hh = struct.unpack_from("<I", res, hdr + 18)[0]
    fe = struct.unpack_from("<I", res, hdr + 30)[0]
    sr = struct.unpack_from("<I", res, hdr + 38)[0]
    mc = struct.unpack_from("<I", res, hdr + 42)[0]
    aile = ENUM_AILE.get(fe)
    return {"W": W, "H": Hh, "fmt_enum": fe, "srgb": sr, "mipcount": mc,
            "aile": aile, "blok": AILE_BLOK.get(aile), "hdr": hdr}


def cipa_bul(res, bas, son_limit, tolerans=0):
    """gomulu piksel havuzunun u32 uzunluk cipasi -> (cipa_off, veri_off, uzunluk)

    🔴 DUZELTME 2026-07-29 (Ship Workshop): eskiden cipa, blobun ic dosyanin
       sonuna **64 bayt toleransla** oturmasi yeterliydi ve EN BUYUK aday
       seciliyordu. Bu, tek-mipli dokularda SISTEMATIK OLARAK 57 BAYT ERKEN bir
       aday buluyordu (Jackdaw_03'te 54). 57, 16'nin katı olmadigi icin BC blok
       hizasi kayiyor ve doku SAF GURULTU olarak coozuluyordu.
       Olculmus kanit (emblem_BlackSkull 2048² BC7):
           eski cipa 268 -> ort RGB (62,63,56)   puruzluluk 34,00
           yeni cipa 325 -> ort RGB (190,186,182) puruzluluk  1,42
       ve (190,186,182) ansiklopedinin BAGIMSIZ F4 taramasinin `dokular.db`'ye
       yazdigi degerin BIREBIR aynisi.
       ⚠️ Sadece onizleme degil YAZMA da bozuluyordu: havuza 57 bayt kaymis
       yazilan pikseller girisin bir kismini eziyordu.
       Dogru kural (`dokuoku.py`, 36.501/36.911 = %98,9 dogrulanmis olcum):
       blob ic dosyanin sonunda BITER, yani `off + 4 + uzunluk == ic_len` TAM.
       Fail-closed: tam eslesme yoksa None doner, hedef kullanilamaz sayilir.

    🔴 DUZELTME 2026-07-30 (Ship Workshop): alt sinir 10.000 -> ALT_SINIR (512).
       10.000 SIHIRLI bir sayiydi ve KUCUK dokulari (16x16, 128x32, 128x64)
       tamamen disliyordu: cipa None donuyor, hedef "kullanilamaz" sayiliyordu.
       512 sihirli degil YAPISAL: `yerlesim()` her mipin toplamini 512'ye
       yuvarlar (`hizala(pitch*bh, 512)`), yani GECERLI bir havuz uzunlugu
       her zaman >=512 ve 512'nin KATIDIR.
       OLCUM (242 gemi hedefi, cipa_taban_olcum.py + kat512.py):
         * eski kuralla 237 bulundu / 5 bulunamadi
         * yeni kuralla 242 bulundu / 0 bulunamadi
         * ESKIDEN BULUNAN 237 hedefin cipasi BIREBIR AYNI kaldi (0 sapma)
           -- cunku EN BUYUK v seciliyor, alt siniri dusurmek yalnizca daha
           KUCUK adaylar ekler ve onlar zaten kaybeder.
         * mevcut 237 cipanin 237'si de 512'nin kati (kural ihlali 0).
       Acilan 5 hedef ve dogrulamalari (cipa_gecerlilik.py):
         Empty / Bulk_Sail_Pattern_Empty  16x16 BC7   havuz 1024 (512*2) puruz 0,00
         Bulk_Streamer_Base_01            128x32 BC3  havuz 8192 (512*16) puruz 2,20
         Bulk_Flag_Pattern_MT_Portuguese_01 128x64 BC1 havuz 9728 (512*19) puruz 4,43
         Bulk_Streamer_Pattern_MT_Portuguese_01 128x32 BC3 havuz 8192 puruz 1,98
       Hepsinde `yerlesim()` havuzu TAM dolduruyor ve cozulen piksel GURULTU
       DEGIL (kontrol grubunun puruzlulugu 2,48 / 10,80).
       512-KATI kurali TERCIH olarak uygulanir, ZORUNLULUK olarak degil:
       once 512'nin kati adaylar arasindan en buyugu secilir; hic yoksa eski
       davranisa (herhangi bir aday) dusulur. Boylece bu ortak kutuphaneyi
       kullanan DIGER araclarda (Sail/Flag/Outfit/Weapon) davranis hicbir
       durumda bugunkunden KOTU olamaz."""
    ic_len = son_limit - bas
    en_iyi = None          # 512'nin kati adaylarin en buyugu (TERCIH EDILEN)
    yedek  = None          # kat olmayan adaylarin en buyugu (GERI DUSUS)
    for q in range(bas, max(bas, min(bas + 4096, son_limit - 4))):
        v = struct.unpack_from("<I", res, q)[0]
        if not (ALT_SINIR <= v < ic_len):
            continue
        bitis = q + 4 + v
        if bitis <= son_limit and (son_limit - bitis) <= tolerans:
            if v % HIZA == 0:
                if en_iyi is None or v > en_iyi[2]:
                    en_iyi = (q, q + 4, v)
            elif yedek is None or v > yedek[2]:
                yedek = (q, q + 4, v)
    return en_iyi if en_iyi is not None else yedek


def yerlesim(W, blok, ilk_lvl, uzunluk, Hh=None):
    """gomulu mip yerlesimi -> ([(lvl, goreli_off, pitch, satir, rowbytes)], toplam)
    NOT: satir uzunlugu 256'ya hizalanir (olculmus kural).

    🔴 DUZELTME 2026-07-29 (Ship Workshop): satir sayisi eskiden `bw` idi, yani
       dokunun KARE oldugu varsayiliyordu. Kare olmayan dokularda blok yuksekligi
       (bh) farklidir ve hesap tutmuyordu.
       Olculmus kanit: `OBD_SHP_Flag_Pattern_PT_TheRevenge_01_DiffuseMap`
       1024x512 BC7, gomulu havuz 524.288 B. Eski hesap n = pitch*bw = 4096*256
       = 1.048.576 > 524.288 -> DONGU ILK ADIMDA KIRILIYOR, yerlesim BOS donuyordu
       (ve mip zinciri "lvl0 yok" diye cokuyordu). Yeni hesap n = pitch*bh =
       4096*128 = 524.288 -> havuzun tamamina BIREBIR oturuyor.
       AC4'teki BUTUN bayraklar (1024x512 / 512x256) bu tuzaga giriyordu.
       Hh verilmezse eski davranis (kare) korunur -> geriye donuk uyumlu."""
    if Hh is None:
        Hh = W
    out = []; off = 0; lvl = ilk_lvl
    w = max(1, W >> ilk_lvl); h = max(1, Hh >> ilk_lvl)
    while w >= 1 and h >= 1:
        bw = max(1, (w + 3) // 4)
        bh = max(1, (h + 3) // 4)
        rowbytes = bw * blok
        pitch = hizala(rowbytes, 256)
        # 🔴 DUZELTME 2026-07-29: her mipin TOPLAMI 512 BAYTA yuvarlanir.
        # (`dokuoku.mip_olc`, 36.501/36.911 doku uzerinde olculmus kural.)
        # Eskiden `pitch*bh` ham haliyle kullaniliyordu; kucuk mipler 256 B
        # oldugu icin bir sonraki seviyenin ofseti kayiyordu. Kanit:
        # Wheel_Bronze havuzu 25.600 B; eski hesap 24.832'de bitip 768 bayt
        # aciklik birakiyordu, yeni hesap havuza TAM oturuyor.
        n = hizala(pitch * bh, 512)
        if off + n > uzunluk:
            break
        out.append((lvl, off, pitch, bh, rowbytes))
        off += n
        if w == 1 and h == 1:
            break
        w = max(1, w // 2); h = max(1, h // 2); lvl += 1
    return out, off


def dds_mipler(p):
    """DDS -> ([{lvl,veri,w,h}], W, H, dxgi, blok)  (siki paketli, pitch hizalamasi YOK)"""
    d = open(p, "rb").read()
    if d[:4] != b"DDS ":
        raise ValueError("DDS degil")
    Hh = struct.unpack_from("<I", d, 12)[0]
    W  = struct.unpack_from("<I", d, 16)[0]
    fc = d[84:88]
    if fc == b"DX10":
        dxgi = struct.unpack_from("<I", d, 128)[0]; veri = 148
    else:
        dxgi = {b"DXT1": 71, b"DXT3": 74, b"DXT5": 77}.get(fc, 0); veri = 128
    aile = DXGI_AILE.get(dxgi)
    if aile is None:
        raise ValueError("desteklenmeyen DXGI=%d" % dxgi)
    blok = AILE_BLOK[aile]
    out = []; off = veri; w, h = W, Hh
    while off < len(d):
        n = max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * blok
        if off + n > len(d):
            break
        out.append({"lvl": len(out), "veri": d[off:off + n], "w": w, "h": h})
        if w == 1 and h == 1:
            break
        off += n; w = max(1, w // 2); h = max(1, h // 2)
    return out, W, Hh, dxgi, blok


def doku_bul(forge, giris_fid, tex_id=None):
    """Girisi cozup icindeki TextureMap'leri tam yerlesimiyle dondurur.

    -> dict(coz=..., icler_dilim=[[fid,bytearray]], dokular=[{...}])
    Her doku: sira(ic dosya indeksi), tex_id, tanim, ic_govde_off, havuz_off, havuz_len,
              harici(mip kayitlari), gomulu_yerlesim
    """
    raw, off, ln, ext = giris_ham(forge, giris_fid)
    c = giris_coz_tam(raw)
    dilim = ic_dilimle(c["govde"], c["icler"])
    dokular = []
    for i, (ic_fid, veri) in enumerate(dilim):
        s = D.sarmal_ac(bytes(veri))
        if (s["tip1"] & 0xFFFFFFFF) != TEXTUREMAP:
            continue
        g = s["govde"]
        tms = tm_bloklari(bytes(veri))
        if not tms:
            continue
        hdr, tid = tms[0]
        t = tanim_oku(bytes(veri), hdr)
        if tex_id is not None and tid != tex_id:
            continue
        har = mipler(forge, tid)
        cipa = cipa_bul(bytes(veri), hdr, len(veri))
        yer, toplam = (None, 0)
        if cipa:
            yer, toplam = yerlesim(t["W"], t["blok"], len(har), cipa[2], t["H"])
        dokular.append({"sira": i, "ic_fid": ic_fid, "tex_id": tid, "tanim": t,
                        "cipa": cipa, "harici": har, "gomulu": yer, "gomulu_toplam": toplam,
                        "ic_len": len(veri)})
    return {"raw": raw, "giris_off": off, "giris_len": ln, "ext": ext,
            "coz": c, "dilim": dilim, "dokular": dokular}


def mip_fid(tex_id, sev):
    """harici ham mip girisinin fid'i (olculdu: taban + seviye)"""
    return (0x8000000000000000 | (tex_id << 20)) + sev


def mip_ham_oku(forge, mip_id):
    r = _db().execute("select off,len from mipler where forge=? and id=?",
                      (forge, struct.unpack("<q", struct.pack("<Q", mip_id))[0])).fetchone()
    if r is None:
        r = _db().execute("select off,len from mipler where forge=? and id=?",
                          (forge, mip_id)).fetchone()
    off, ln = r
    with open(os.path.join(OYUN, forge), "rb") as f:
        f.seek(off); return f.read(ln), off, ln


def bc_coz(veri, w, h, aile):
    """BCn -> numpy (h,w,4) RGBA uint8"""
    import numpy as np, texture2ddecoder
    fn = {"BC1": texture2ddecoder.decode_bc1, "BC3": texture2ddecoder.decode_bc3,
          "BC7": texture2ddecoder.decode_bc7}[aile]
    bgra = np.frombuffer(fn(veri, w, h), dtype=np.uint8).reshape(h, w, 4)
    return bgra[:, :, [2, 1, 0, 3]].copy()
