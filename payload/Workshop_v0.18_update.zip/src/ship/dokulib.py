# -*- coding: utf-8 -*-
"""F4 doku envanteri ortak kutuphane.

forge giris okuma + BMS cozme (iki TOCMode) + K1 ic dosya listesi + sarmalayici.
Oyun dosyalarina SADECE 'rb' ile erisilir.
"""
import struct, os, zlib, ctypes
try:
    import sqlite3
except ImportError:                       # gomulu Python'da yok
    sqlite3 = None
try:
    import lz4.block                      # yalniz algo=4 bloklari icin
except ImportError:                       # gemi girisleri algo=8 (Oodle)
    lz4 = None

GAME = ""          # ship_ayar calisma aninda doldurur
KATALOG = ""       # pakette yok: ofsetler forge'un KENDI TOC'undan okunur
BMS = bytes.fromhex("33aafb5799fa0410")
ODLL = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                    "tools", "oo2core_7_win64.dll")

TEXTUREMAP     = 0xA2B7E917
TEXTURESET     = 0xD70E6670
TEXTUREMAPSPEC = 0x989DC6B2

_oo = ctypes.WinDLL(ODLL)
_oo.OodleLZ_Decompress.restype = ctypes.c_longlong
_oo.OodleLZ_Decompress.argtypes = [ctypes.c_char_p, ctypes.c_longlong, ctypes.c_char_p,
                                   ctypes.c_longlong, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                   ctypes.c_void_p, ctypes.c_longlong, ctypes.c_void_p,
                                   ctypes.c_void_p, ctypes.c_void_p, ctypes.c_longlong, ctypes.c_int]

def oodle(data, ulen):
    out = ctypes.create_string_buffer(ulen + 64)
    n = _oo.OodleLZ_Decompress(data, len(data), out, ulen, 1, 0, 0, None, 0, None, None, None, 0, 3)
    return out.raw[:ulen] if n == ulen else None

def blok_ac(algo, comp, ulen):
    if algo == 4:
        if lz4 is None:
            raise RuntimeError("this asset needs the lz4 module, which is not bundled")
        return lz4.block.decompress(comp, uncompressed_size=ulen)
    out = oodle(comp, ulen)
    if out is None:
        raise ValueError("acilamadi algo=%d clen=%d ulen=%d" % (algo, len(comp), ulen))
    return out

def konteyner_oku(d, off):
    if d[off:off+8] != BMS:
        raise ValueError("BMS yok @%d" % off)
    ver, algo = struct.unpack_from("<HB", d, off+8)
    raw = struct.unpack_from("<I", d, off+11)[0]
    tocmode = raw >> 31
    p = off + 15
    icerik = bytearray()
    if tocmode:
        cnt = struct.unpack_from("<I", d, p)[0]; p += 4
        sizes = []
        for _ in range(cnt):
            u, c = struct.unpack_from("<II", d, p); p += 8
            sizes.append((u, c))
        for u, c in sizes:
            p += 4
            v = d[p:p+c]; p += c
            icerik += v if u == c else blok_ac(algo, v, u)
    else:
        while p < len(d) and d[p:p+8] != BMS:
            isc = d[p]; p += 1
            if isc:
                c, u = struct.unpack_from("<iI", d, p); p += 8
                p += 4
                v = d[p:p+c]; p += c
                icerik += blok_ac(algo, v, u) if u != c else v
            else:
                sz = struct.unpack_from("<i", d, p)[0]; p += 4
                icerik += d[p:p+sz]; p += sz
    return bytes(icerik), p

def giris_coz(raw):
    """Ham giris baytlari -> (K1 basligi, K2 govde)."""
    hdr, p1 = konteyner_oku(raw, 0)
    govde = bytearray()
    while p1 < len(raw) and raw[p1:p1+8] == BMS:
        g, p1 = konteyner_oku(raw, p1)
        govde += g
    return hdr, bytes(govde)

def ic_liste(hdr):
    """K1: [count u16][kayitlar: fid u64, len u32, ekstraLen u16, 4B sifir, ekstra]"""
    cnt = struct.unpack_from("<H", hdr, 0)[0]
    icler = []; q = 2
    for _ in range(cnt):
        fid, ln = struct.unpack_from("<QI", hdr, q)
        ekstra = struct.unpack_from("<H", hdr, q+12)[0]
        q += 18 + ekstra
        icler.append((fid, ln))
    return icler

def ic_dosyalar_ham(raw):
    hdr, govde = giris_coz(raw)
    icler = ic_liste(hdr)
    out = []; pos = 0
    for fid, l in icler:
        out.append((fid, govde[pos:pos+l])); pos += l
    return out

def sarmal_ac(data):
    """[tipCrc u32][boyut u32][adLen u32][ad adLen][bayrak u8][nesneID u64][tipCrc u32][govde]"""
    tip1, boyut, adlen = struct.unpack_from("<III", data, 0)
    p = 12
    ad = data[p:p+adlen]; p += adlen
    bayrak = data[p]; p += 1
    nid, tip2 = struct.unpack_from("<QI", data, p); p += 12
    return dict(tip1=tip1, boyut=boyut, ad=ad, bayrak=bayrak, nid=nid, tip2=tip2,
                govde=data[p:], govde_off=p)

# ---------------------------------------------------------------- blok haritasi
def blok_haritasi(d, off):
    """Bir BMS konteynerinin bloklarini ACMADAN haritalar.
    Doner: (bloklar, sonraki_off, toplam_acik) ; blok = (dec_off, u, comp_off, c, algo)"""
    if d[off:off+8] != BMS:
        raise ValueError("BMS yok @%d" % off)
    ver, algo = struct.unpack_from("<HB", d, off+8)
    raw = struct.unpack_from("<I", d, off+11)[0]
    tocmode = raw >> 31
    p = off + 15
    bloklar = []; dec = 0
    if tocmode:
        cnt = struct.unpack_from("<I", d, p)[0]; p += 4
        sizes = []
        for _ in range(cnt):
            u, c = struct.unpack_from("<II", d, p); p += 8
            sizes.append((u, c))
        for u, c in sizes:
            p += 4
            bloklar.append((dec, u, p, c, algo)); dec += u; p += c
    else:
        while p < len(d) and d[p:p+8] != BMS:
            isc = d[p]; p += 1
            if isc:
                c, u = struct.unpack_from("<iI", d, p); p += 8
                p += 4
                bloklar.append((dec, u, p, c, algo)); dec += u; p += c
            else:
                sz = struct.unpack_from("<i", d, p)[0]; p += 4
                bloklar.append((dec, sz, p, sz, algo)); dec += sz; p += sz
    return bloklar, p, dec

def giris_haritasi(raw):
    """Ham giris -> (K1_baytlari, K2_bloklari, K2_toplam_uzunluk)"""
    b0, p1, _ = blok_haritasi(raw, 0)
    hdr = bytearray()
    for dof, u, cof, c, algo in b0:
        v = raw[cof:cof+c]
        hdr += v if u == c else blok_ac(algo, v, u)
    bloklar = []; taban = 0
    while p1 < len(raw) and raw[p1:p1+8] == BMS:
        bb, p1, dec = blok_haritasi(raw, p1)
        for dof, u, cof, c, algo in bb:
            bloklar.append((taban + dof, u, cof, c, algo))
        taban += dec
    return bytes(hdr), bloklar, taban

def parca_al(raw, bloklar, bas, uzunluk):
    """K2 govdesinin [bas, bas+uzunluk) araligini yalniz gerekli bloklari acarak dondur."""
    son = bas + uzunluk
    out = bytearray(); ilk = None
    for dof, u, cof, c, algo in bloklar:
        if dof + u <= bas or dof >= son:
            continue
        v = raw[cof:cof+c]
        blk = v if u == c else blok_ac(algo, v, u)
        if ilk is None:
            ilk = dof
        out += blk
    if ilk is None:
        return b""
    return bytes(out[bas - ilk: bas - ilk + uzunluk])

def db():
    return sqlite3.connect(KATALOG)

def crc(s):
    return zlib.crc32(s.encode()) & 0xFFFFFFFF

def u64(x):
    return x & 0xFFFFFFFFFFFFFFFF
