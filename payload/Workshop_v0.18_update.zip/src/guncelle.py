# -*- coding: utf-8 -*-
"""guncelle -- Workshop'un KENDI KENDINE guncellenmesi (Nexus'a yeni zip yuklemeden).

NEDEN: her duzeltme icin Nexus'a paket yuklemek hem bizi hem kullaniciyi yoruyor. Paketin
YALNIZ veri + python + arayuz katmani degisir; baslatici exe (Workshop.exe, sha kilitli),
tasinabilir python ve tools\\ (TexEncode.exe sha kilitli) DEGISMEZ. Dolayisiyla guncelleme =
"izinli dosyalari yedekleyip ustune yaz, yeniden baslat".

AKIS (hepsi kullanici onayiyla; arka planda hicbir sey kurulmaz):
  1. kontrol(): GUNCELLEME_URL/surum.json indirilir -> {surum, tarih, paket, sha256, boyut,
     notlar}. Yerel surum.json ile karsilastirilir. Ag yoksa sessizce "kontrol edilemedi".
  2. indir(): paket zip'i %LOCALAPPDATA%\\OutfitWorkshop\\guncelleme\\<surum>.zip'e iner,
     sha256 DOGRULANIR (tutmazsa silinir, kurulmaz), icerigi IZIN LISTESIYLE denetlenir:
       izinli kokler : src/  arayuz/  README.txt  surum.json  THIRD-PARTY-NOTICES.txt
       yasak         : *.exe *.dll *.pyd, ".." iceren yol, mutlak yol, izinli kok disindaki her sey
  3. kur(): once mevcut dosyalar yedek\\<eski_surum>\\ altina KOPYALANIR, sonra zip acilir,
     surum.json yenilenir. Uygulama yeniden baslatilinca yeni kod calisir.
  4. geri_al(): son yedegi geri koyar (guncelleme kotu ciktiysa).

GUVENLIK: yalniz https (test icin http://127.0.0.1); sha256 zorunlu; yol allowlist; calisan
python'un kendisi (python\\) ve exe'ler ASLA degismez. Kod yorumlari Turkce, kullaniciya
gorunen mesajlar Ingilizce.
"""
import hashlib
import io
import json
import os
import shutil
import sys
import time
import zipfile

__all__ = ["yerel_surum", "kontrol", "indir", "kur", "geri_al", "durum", "GUNCELLEME_URL",
           "PAKET_KOKU"]

SURUM_DOSYA_ADI = "surum.json"
# Yayin kanali: surum.json + paket zip'i buraya konur. Bos birakilirsa kontrol kapali.
# ayarlar.json'daki "guncelleme_url" bunu ezer (test / kendi sunucusu olan kullanici).
GUNCELLEME_URL = "https://raw.githubusercontent.com/caoscomtr/workshop-updates/main/surum.json"
IZINLI_KOKLER = ("src/", "arayuz/")
IZINLI_DOSYALAR = ("README.txt", "surum.json", "THIRD-PARTY-NOTICES.txt", "LICENSE")
YASAK_UZANTI = (".exe", ".dll", ".pyd", ".bat", ".cmd", ".ps1", ".vbs", ".scr", ".com", ".msi")

BURA = os.path.dirname(os.path.abspath(__file__))
# Pakette: <PAKET>\src\guncelle.py -> PAKET_KOKU = <PAKET>. Gelistirme agacinda KOK.
PAKET_KOKU = os.path.dirname(BURA)
VERI_KOK = os.path.join(os.environ.get("LOCALAPPDATA") or
                        os.path.join(os.path.expanduser("~"), "AppData", "Local"),
                        "OutfitWorkshop", "guncelleme")


def _log(progress, s):
    if progress:
        try:
            progress(s)
        except Exception:                                   # noqa: BLE001
            pass


def _sha(yol):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _surum_sayi(s):
    """'v0.11' / '0.11.2' -> (0, 11, 2). Karsilastirma icin; harf/ek yok sayilir."""
    out = []
    for p in str(s or "").lower().lstrip("v").split("."):
        d = "".join(ch for ch in p if ch.isdigit())
        out.append(int(d) if d else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out[:3])


def yerel_surum():
    """Paketin surum.json'u: {surum, tarih, ...}; gelistirme agacinda {"surum": "dev"}."""
    yol = os.path.join(PAKET_KOKU, SURUM_DOSYA_ADI)
    try:
        with open(yol, encoding="utf-8") as f:
            d = json.load(f) or {}
        d.setdefault("surum", "?")
        d["dosya"] = yol
        return d
    except Exception:                                       # noqa: BLE001
        return {"surum": "dev", "dosya": yol, "gelistirme": True}


def _url(ayar=None):
    ov = (ayar or {}).get("guncelleme_url") if isinstance(ayar, dict) else None
    if ov is None:
        try:                                                 # arayuz ayarlari (varsa)
            import importlib
            su = importlib.import_module("sunucu")
            ov = (su.ayar_oku() or {}).get("guncelleme_url")
        except Exception:                                    # noqa: BLE001
            ov = None
    u = (ov if ov is not None else GUNCELLEME_URL) or ""
    return u.strip()


def _url_guvenli(u):
    return u.startswith("https://") or u.startswith("http://127.0.0.1") or u.startswith("http://localhost")


# --------------------------------------------------------------- HOST + YONLENDIRME
# 2026-09-07 denetimi: bu kanal KOD KURUYOR ama `_url_guvenli` yalnizca semaya bakiyordu
# ("https://evil.tld/Workshop.zip" -> True) ve ciplak urlopen yonlendirmeyi SESSIZCE
# takip ediyordu. sha256 burada kurtarmiyor: paket adresi de ozet de AYNI (yonlendirilebilen)
# surum.json'dan geliyor. mod_kutuphane bugun iki kapiyi da kazandi; asimetri kapatildi.
#
# Beyaz liste, kanalin KENDI adresinden TURETILIR: GUNCELLEME_URL degistirilirse liste
# kendiliginden onu izler, elle guncellenecek ikinci bir yer olmaz.
_VARSAYILAN_HOST = "raw.githubusercontent.com"
_RELEASE_HOSTLAR = frozenset((
    "github.com", "raw.githubusercontent.com", "objects.githubusercontent.com",
    "release-assets.githubusercontent.com", "codeload.github.com",
))
_YEREL_HOSTLAR = frozenset(("127.0.0.1", "localhost"))
AZAMI_YONLENDIRME = 5


class YonlendirmeReddi(Exception):
    """Adres ya da yonlendirme beyaz liste disinda."""


def _kanal_hostlari(ayar=None):
    from urllib.parse import urlsplit
    out = set(_RELEASE_HOSTLAR) | set(_YEREL_HOSTLAR)
    for u in (GUNCELLEME_URL, _url(ayar)):
        h = (urlsplit(str(u or "")).hostname or "").lower()
        if h:
            out.add(h)
    out.add(_VARSAYILAN_HOST)
    return frozenset(out)


def _host_uygun(u, hostlar):
    from urllib.parse import urlsplit
    if not _url_guvenli(u):
        return False
    h = (urlsplit(str(u or "")).hostname or "").lower()
    return bool(h) and h in hostlar


def _kapi_sinifi():
    """Yonlendirme kapisi sinifini URETIR.

    Sinif modul duzeyinde tanimlanamiyor cunku urllib bu modulde TEMBEL import ediliyor
    (uygulama acilisi ag katmanini yuklemeden gecsin diye)."""
    import urllib.request

    class Kapi(urllib.request.HTTPRedirectHandler):
        def __init__(self, hostlar, azami=AZAMI_YONLENDIRME):
            self.hostlar = hostlar
            self.azami = azami
            self.adim = 0

        def redirect_request(self, req, fp, code, msg, headers, newurl):
            # urllib newurl'u buraya gelmeden MUTLAK hale getiriyor; goreli adres de takilir.
            self.adim += 1
            if self.adim > self.azami:
                raise YonlendirmeReddi(
                    "the update address kept sending this Workshop on to another address "
                    "more than %d times, so nothing was downloaded." % self.azami)
            if not _host_uygun(newurl, self.hostlar):
                from urllib.parse import urlsplit
                nereye = (urlsplit(newurl).hostname or str(newurl)[:80]
                          or "an unnamed address")
                raise YonlendirmeReddi(
                    "the update address sent this Workshop on to %s, which is not one of "
                    "the addresses updates are allowed to come from, so nothing was "
                    "downloaded." % nereye)
            return urllib.request.HTTPRedirectHandler.redirect_request(
                self, req, fp, code, msg, headers, newurl)

    return Kapi


def _istek(u, zaman, ayar=None):
    """Adres kapisindan gecmis, HER yonlendirme adimi denetlenen HTTP cevabi."""
    import urllib.request
    hostlar = _kanal_hostlari(ayar)
    if not _host_uygun(u, hostlar):
        raise YonlendirmeReddi(
            "that address is not one of the addresses updates are allowed to come from, "
            "so nothing was downloaded.")
    req = urllib.request.Request(u, headers={"User-Agent": "Workshop-Updater/1.0",
                                             "Cache-Control": "no-cache"})
    # HER istek icin YENI opener: yonlendirme adim sayaci temiz baslasin.
    return urllib.request.build_opener(_kapi_sinifi()(hostlar)).open(req, timeout=zaman)


def _http_oku(u, zaman=15, ayar=None):
    with _istek(u, zaman, ayar) as r:
        return r.read()


# ---------------------------------------------------------------- ilerleme (bar)
# `progress` yalnizca METIN satiri tasiyor; bar icin SAYI gerekiyordu. Yeni callback
# AYRI (`bar`) tutuldu: mevcut cagiranlarin hicbiri degismiyor, veren de sayiyi aliyor.
# bar(d) -> d = {"asama": "download"|"install", "yuzde": 0..100,
#                "yapilan": <bayt|dosya>, "toplam": <bayt|dosya>, "metin": "..."}
_BAR_ADIM = 1.0            # yuzde: bundan az degistiyse bildirme (arayuzu bogmamak icin)


def _bar(bar, asama, yapilan, toplam, metin=""):
    if not bar:
        return
    try:
        y = (100.0 * yapilan / toplam) if toplam else 0.0
        bar({"asama": asama, "yuzde": max(0.0, min(100.0, y)),
             "yapilan": yapilan, "toplam": toplam, "metin": metin})
    except Exception:                                       # noqa: BLE001
        pass


def _mb(n):
    return "%.1f MB" % (n / 1048576.0)


def _http_indir(u, hedef, zaman=120, bar=None, parca=1 << 18, ayar=None):
    """Akiskan indirme: parca parca yazar ve ilerlemeyi bildirir. Doner yazilan bayt.

    Eskiden butun paket (44 MB) tek `r.read()` ile BELLEGE aliniyordu; kullanici
    indirme boyunca hicbir sey gormuyordu. Artik hem disk dostu hem olculebilir.
    Sunucu Content-Length vermezse toplam 0 kalir; o zaman yuzde yerine BAYT bildirilir.
    """
    yazilan = 0
    son = -_BAR_ADIM
    # Ciplak urlopen DEGIL: adres ve HER yonlendirme adimi beyaz listeden gecer.
    with _istek(u, zaman, ayar) as r:
        try:
            toplam = int(r.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            toplam = 0
        with open(hedef, "wb") as f:
            while True:
                b = r.read(parca)
                if not b:
                    break
                f.write(b)
                yazilan += len(b)
                y = (100.0 * yazilan / toplam) if toplam else 0.0
                if not toplam or y - son >= _BAR_ADIM or yazilan == toplam:
                    son = y
                    _bar(bar, "download", yazilan, toplam,
                         "%s of %s" % (_mb(yazilan), _mb(toplam)) if toplam
                         else "%s downloaded" % _mb(yazilan))
    return yazilan


def kontrol(progress=None, ayar=None):
    """Uzak surum.json'u okur. Doner {ok, kapali?, yerel, uzak, yeni_var, mesaj}.

    Delta paketlerde ayrica {tam_paket_gerek, nexus} doner: kullanicinin surumu paketin
    `taban_surum`undan eskiyse kucuk guncelleme YETMEZ -- arayuz bunu afiste gosterip
    kullaniciyi Nexus'taki tam pakete yollar (bkz. arayuz.html guncellemeKontrol)."""
    yerel = yerel_surum()
    u = _url(ayar)
    if not u:
        return {"ok": True, "kapali": True, "yerel": yerel, "uzak": None, "yeni_var": False,
                "mesaj": "automatic updates are switched off (no update address)."}
    if not _url_guvenli(u):
        return {"ok": False, "yerel": yerel, "uzak": None, "yeni_var": False,
                "mesaj": "the update address must start with https://"}
    try:
        uzak = json.loads(_http_oku(u, ayar=ayar).decode("utf-8"))
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "yerel": yerel, "uzak": None, "yeni_var": False,
                "mesaj": "could not check for updates (%s)." % (str(e)[:120] or "no connection")}
    if not isinstance(uzak, dict) or not uzak.get("surum") or not uzak.get("paket") \
            or not uzak.get("sha256"):
        return {"ok": False, "yerel": yerel, "uzak": uzak, "yeni_var": False,
                "mesaj": "the update file on the server is incomplete (needs surum, paket, sha256)."}
    # DELTA BEYAN KAPISI (fail-closed): "delta": true diyen ama `taban_surum` TASIMAYAN bir
    # surum.json'da istemcinin tabani karsilastirmasi imkansizdir -- asagidaki taban kapisi
    # sessizce devre disi kalir ve tabandan eski kullanici EKSIK bir agac kurar (elle yazilmis
    # surum.json'da olculdu). Beyan eksikse guncelleme HIC baslamaz.
    if uzak.get("delta") and not uzak.get("taban_surum"):
        return {"ok": False, "yerel": yerel, "uzak": uzak, "yeni_var": False,
                "tam_paket_gerek": False, "nexus": uzak.get("nexus"),
                "mesaj": ("this update is a partial (delta) package but does not say which version "
                          "it builds on, so installing it could leave files missing. Get the full "
                          "package instead%s."
                          % ((" from " + uzak["nexus"]) if uzak.get("nexus") else ""))}
    # paket adresi GORELI verilmisse (paket_kur yalniz dosya adini yazar) surum.json'un
    # bulundugu klasore gore cozulur: yayinci iki dosyayi yan yana koyar, adres elle yazilmaz.
    if not str(uzak["paket"]).lower().startswith(("http://", "https://")):
        from urllib.parse import urljoin
        uzak["paket"] = urljoin(u, str(uzak["paket"]))
    yeni = _surum_sayi(uzak["surum"]) > _surum_sayi(yerel.get("surum"))
    if yerel.get("gelistirme"):
        yeni = False                                          # gelistirme agaci guncellenmez
    # DELTA TABANI KAPISI: paket yalniz `taban_surum`dan bu yana degisenleri tasir. Kullanicinin
    # kurulumu tabandan ESKIYSE eksik dosya alirdi -- o zaman guncelleme YAPILMAZ, kullanici
    # Nexus'taki tam pakete yollanir (fail-closed).
    taban = uzak.get("taban_surum")
    tam_gerek = bool(yeni and taban and _surum_sayi(yerel.get("surum")) < _surum_sayi(taban))
    if tam_gerek:
        return {"ok": True, "yerel": yerel, "uzak": uzak, "yeni_var": False, "tam_paket_gerek": True,
                "nexus": uzak.get("nexus"),
                "mesaj": ("version %s is available, but your copy (%s) is older than this update's "
                          "base (%s), so the small update would not be enough. Download the full "
                          "package once%s; after that the Workshop updates itself again."
                          % (uzak["surum"], yerel.get("surum"), taban,
                             (" from " + uzak["nexus"]) if uzak.get("nexus") else ""))}
    return {"ok": True, "yerel": yerel, "uzak": uzak, "yeni_var": yeni, "tam_paket_gerek": False,
            "mesaj": ("version %s is available (you have %s)." % (uzak["surum"], yerel.get("surum"))
                      if yeni else "you have the latest version (%s)." % yerel.get("surum"))}


def _zip_denetle(zip_yolu):
    """Zip icerigi izin listesine uyuyor mu? Doner (ok, sebep, dosya_sayisi)."""
    n = 0
    with zipfile.ZipFile(zip_yolu) as z:
        for zi in z.infolist():
            ad = zi.filename.replace("\\", "/")
            if zi.is_dir():
                continue
            n += 1
            if ad.startswith("/") or ".." in ad.split("/") or ":" in ad:
                return False, "unsafe path in package: %s" % ad, n
            if ad.lower().endswith(YASAK_UZANTI):
                return (False, ("the package carries a program file (%s); updates may only change "
                                "data, scripts and the interface" % ad), n)
            if not (ad.startswith(IZINLI_KOKLER) or ad in IZINLI_DOSYALAR):
                return False, "the package touches a folder updates may not change: %s" % ad, n
    return (n > 0), ("" if n else "the package is empty"), n


def indir(uzak, progress=None, bar=None):
    """Paketi indirir + sha256 dogrular + icerigi denetler. Doner {ok, zip, mesaj, dosya_sayisi}."""
    u = str(uzak.get("paket") or "")
    if not _url_guvenli(u):
        return {"ok": False, "mesaj": "the package address must start with https://"}
    os.makedirs(VERI_KOK, exist_ok=True)
    hedef = os.path.join(VERI_KOK, "Workshop_%s.zip" % str(uzak.get("surum")).replace("/", "_"))
    beklenen = str(uzak.get("sha256") or "").lower()
    if os.path.isfile(hedef) and _sha(hedef) == beklenen:
        _log(progress, "- package already downloaded and verified")
        _bar(bar, "download", 1, 1, "already downloaded")
    else:
        _log(progress, "- downloading %s ..." % u)
        gecici = hedef + ".part"
        try:
            inen = _http_indir(u, gecici, zaman=120, bar=bar)
        except YonlendirmeReddi as e:
            # Bu mesaj ZATEN kullanici cumlesi; "download failed (...)" icine gomulmez.
            try:
                os.remove(gecici)
            except OSError:
                pass
            return {"ok": False, "mesaj": str(e)}
        except Exception as e:                               # noqa: BLE001
            try:
                os.remove(gecici)
            except OSError:
                pass
            return {"ok": False, "mesaj": "download failed (%s)." % str(e)[:120]}
        boyut = int(uzak.get("boyut") or 0)
        if boyut and inen != boyut:
            os.remove(gecici)
            return {"ok": False, "mesaj": "download is %d bytes, the server promised %d - not installed."
                    % (inen, boyut)}
        _bar(bar, "verify", 0, 1, "checking the download")
        if _sha(gecici) != beklenen:
            os.remove(gecici)
            return {"ok": False, "mesaj": "the downloaded package does not match its checksum - "
                                          "not installed."}
        _bar(bar, "verify", 1, 1, "checksum matches")
        os.replace(gecici, hedef)
    try:
        ok, sebep, n = _zip_denetle(hedef)
    except zipfile.BadZipFile:
        return {"ok": False, "mesaj": "the download is not a zip file - not installed."}
    if not ok:
        return {"ok": False, "mesaj": sebep}
    return {"ok": True, "zip": hedef, "dosya_sayisi": n, "mesaj": "package verified (%d files)." % n}


def kur(zip_yolu, uzak, progress=None, bar=None):
    """Yedekle + ustune yaz + surum.json yenile. Doner {ok, yedek, yazilan, mesaj}."""
    yerel = yerel_surum()
    if yerel.get("gelistirme"):
        return {"ok": False, "mesaj": "this is a development tree, not an installed package."}
    ok, sebep, _n = _zip_denetle(zip_yolu)
    if not ok:
        return {"ok": False, "mesaj": sebep}
    yedek = os.path.join(VERI_KOK, "yedek", "%s_%s" % (str(yerel.get("surum")).replace("/", "_"),
                                                       time.strftime("%Y%m%d_%H%M%S")))
    os.makedirs(yedek, exist_ok=True)
    yazilan = 0
    try:
        with zipfile.ZipFile(zip_yolu) as z:
            uyeler = [zi for zi in z.infolist() if not zi.is_dir()]
            eklenen = []
            # 1) yedek: degisecek her dosyanin mevcut hali (+ EKLENEN dosyalarin listesi)
            for zi in uyeler:
                rel = zi.filename.replace("\\", "/")
                mevcut = os.path.join(PAKET_KOKU, *rel.split("/"))
                if os.path.isfile(mevcut):
                    h = os.path.join(yedek, *rel.split("/"))
                    os.makedirs(os.path.dirname(h), exist_ok=True)
                    shutil.copy2(mevcut, h)
                else:
                    # kurulumda YOK -> guncellemenin EKLEDIGI dosya. Yedeklenecek bir hali
                    # olmadigi icin geri alma onu goremiyordu ve yerinde birakiyordu
                    # (2026-09-06 olcumu: v0.11 -> v0.12'de 2 dosya boyle kaldi).
                    eklenen.append(rel)
            with open(os.path.join(yedek, "YEDEK_BILGI.json"), "w", encoding="utf-8") as f:
                json.dump({"eski_surum": yerel.get("surum"), "yeni_surum": uzak.get("surum"),
                           "zaman": time.strftime("%Y-%m-%d %H:%M:%S"), "zip": zip_yolu,
                           "dosyalar": [zi.filename for zi in uyeler],
                           "eklenen": eklenen}, f, indent=1)
            # 2) yaz (gecici ada, sonra yer degistir: yarim dosya kalmasin)
            n_uye = len(uyeler)
            for zi in uyeler:
                rel = zi.filename.replace("\\", "/")
                hedef = os.path.join(PAKET_KOKU, *rel.split("/"))
                os.makedirs(os.path.dirname(hedef), exist_ok=True)
                with z.open(zi) as kaynak, open(hedef + ".yeni", "wb") as f:
                    shutil.copyfileobj(kaynak, f)
                os.replace(hedef + ".yeni", hedef)
                yazilan += 1
                _log(progress, "  updated %s" % rel)
                _bar(bar, "install", yazilan, n_uye,
                     "%d of %d files" % (yazilan, n_uye))
        # 3) surum.json (paket icinde yoksa uzak kayittan)
        sy = os.path.join(PAKET_KOKU, SURUM_DOSYA_ADI)
        if not any(zi.filename.replace("\\", "/") == SURUM_DOSYA_ADI
                   for zi in zipfile.ZipFile(zip_yolu).infolist()):
            with open(sy, "w", encoding="utf-8") as f:
                json.dump({"surum": uzak.get("surum"), "tarih": uzak.get("tarih"),
                           "notlar": uzak.get("notlar"), "kaynak": "update"}, f, indent=1)
    except Exception as e:                                   # noqa: BLE001
        # yarim kaldiysa yedekten geri koy
        try:
            geri_al(yedek)
        except Exception:                                    # noqa: BLE001
            pass
        return {"ok": False, "yedek": yedek, "yazilan": yazilan,
                "mesaj": "the update stopped half way (%s); the previous files were put back." % str(e)[:120]}
    return {"ok": True, "yedek": yedek, "yazilan": yazilan,
            "mesaj": "updated %d file(s) to version %s. Restart the Workshop to use it." % (yazilan, uzak.get("surum"))}


TERS_BOLU = chr(92)


def _eklenenleri_sil(yedek):
    """Guncellemenin EKLEDIGI dosyalari kaldir + bosalan klasorleri temizle.

    Yalniz YEDEK_BILGI.json'daki `eklenen` listesindekiler silinir ve her yol PAKET_KOKU
    icinde olmak ZORUNDA (disari cikan atlanir). Eski yedeklerde bu alan yok -> hicbir sey
    silinmez, yani geriye donuk uyumlu."""
    try:
        with open(os.path.join(yedek, "YEDEK_BILGI.json"), encoding="utf-8") as f:
            bilgi = json.load(f)
    except Exception:                                        # noqa: BLE001
        return 0
    kok = os.path.abspath(PAKET_KOKU)
    silinen, klasorler = 0, set()
    for rel in (bilgi.get("eklenen") or []):
        rel = str(rel).replace(TERS_BOLU, "/")
        if rel == SURUM_DOSYA_ADI:
            continue
        yol = os.path.abspath(os.path.join(kok, *rel.split("/")))
        if not yol.startswith(kok + os.sep):
            continue
        try:
            if os.path.isfile(yol):
                os.remove(yol)
                silinen += 1
                klasorler.add(os.path.dirname(yol))
        except OSError:
            pass
    for d in sorted(klasorler, key=len, reverse=True):
        try:
            while d.startswith(kok + os.sep) and not os.listdir(d):
                os.rmdir(d)
                d = os.path.dirname(d)
        except OSError:
            pass
    return silinen


KULLANILMIS_YEDEK_KLASORU = "yedek_kullanildi"


def _yedek_adaylari(kok):
    """Geri alinabilir yedekler (ad sirasi, eski -> yeni). YEDEK_BILGI.json'unda
    `kullanildi` olanlar YOK sayilir (tasima basaramadiysa geride kalan durum).

    2026-09-08 zincir olcumu (v0.13 -> v0.14 -> v0.15 -> geri -> geri): birinci geri alma
    v0.14 yedegini acti ama klasoru yerinde birakti; ikinci "roll back" sorted()[-1] ile
    AYNI v0.14 yedegini yeniden secti, "restored 486 file(s)" dedi ve kurulumu v0.14'te
    birakti -- kullanici v0.13'e dondugunu sanirdi. Yedekler surum+zaman adli ayri
    klasorler oldugu icin dogru yedek zaten diskte duruyordu; eksik olan, kullanilanin
    aday listesinden dusmesiydi."""
    if not os.path.isdir(kok):
        return []
    adaylar = []
    for a in sorted(os.listdir(kok)):
        d = os.path.join(kok, a)
        if not os.path.isdir(d):
            continue
        try:
            with open(os.path.join(d, "YEDEK_BILGI.json"), encoding="utf-8") as f:
                if json.load(f).get("kullanildi"):
                    continue
        except Exception:                                    # noqa: BLE001
            pass
        adaylar.append(a)
    return adaylar


def _yedegi_emekliye_ayir(yedek, bilgi):
    """Kullanilan yedegi `yedek/` altindan `yedek_kullanildi/` altina TASIR.

    Tasima sart, isaret yetmez: geri alma ESKI surumun guncelleyicisini de geri getirir
    ve o kod isareti bilmez -- 2026-09-08 ikinci zincir olcumu: v0.15'in damgasi v0.14'un
    `sorted()[-1]`ini durdurmadi, ikinci geri alma yine v0.14 yedegini acti (ustune damga
    dosyasini da pakete kopyaladi). Klasor `yedek/` disina cikinca HER surumun
    guncelleyicisi dogru yedegi gorur. Yedek silinmez, baytlar `yedek_kullanildi/`
    altinda durur. Isaret YEDEK_BILGI.json icinde tutulur: eski kod o dosyayi
    kopyalamaz, yani pakete yabanci dosya sizmaz. Doner: yeni yol ya da None."""
    try:
        bilgi = dict(bilgi or {})
        bilgi["kullanildi"] = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(os.path.join(yedek, "YEDEK_BILGI.json"), "w", encoding="utf-8") as f:
            json.dump(bilgi, f, indent=1)
    except Exception:                                        # noqa: BLE001
        pass
    try:
        kok = os.path.join(VERI_KOK, KULLANILMIS_YEDEK_KLASORU)
        os.makedirs(kok, exist_ok=True)
        hedef = os.path.join(kok, os.path.basename(os.path.normpath(yedek)))
        if os.path.exists(hedef):
            hedef += "_" + time.strftime("%Y%m%d_%H%M%S")
        os.rename(yedek, hedef)
        return hedef
    except OSError:
        return None


def geri_al(yedek=None):
    """Son (ya da verilen) yedegi geri koyar. Doner {ok, mesaj, geri_konan, surum, emekli}.

    Basariyla geri konan yedek `yedek_kullanildi/` altina tasinir (bkz.
    _yedegi_emekliye_ayir): silinmez, ama bir sonraki geri alma -- hangi surumun
    guncelleyicisi kosarsa kossun -- onu degil, ondan oncekini secer; yedek kalmayinca
    durustce "there is no update backup to restore." doner."""
    kok = os.path.join(VERI_KOK, "yedek")
    if yedek is None:
        adaylar = _yedek_adaylari(kok)
        if not adaylar:
            return {"ok": False, "mesaj": "there is no update backup to restore."}
        yedek = os.path.join(kok, adaylar[-1])
    n = 0
    for dp, _dn, fn in os.walk(yedek):
        for f in fn:
            if f == "YEDEK_BILGI.json":
                continue
            src = os.path.join(dp, f)
            rel = os.path.relpath(src, yedek)
            hedef = os.path.join(PAKET_KOKU, rel)
            os.makedirs(os.path.dirname(hedef), exist_ok=True)
            shutil.copy2(src, hedef + ".yeni")
            os.replace(hedef + ".yeni", hedef)
            n += 1
    _eklenenleri_sil(yedek)
    eski, bilgi = None, {}
    try:
        with open(os.path.join(yedek, "YEDEK_BILGI.json"), encoding="utf-8") as f:
            bilgi = json.load(f)
        eski = bilgi.get("eski_surum")
        with open(os.path.join(PAKET_KOKU, SURUM_DOSYA_ADI), "w", encoding="utf-8") as f:
            json.dump({"surum": eski, "kaynak": "rollback",
                       "tarih": time.strftime("%Y-%m-%d")}, f, indent=1)
    except Exception:                                        # noqa: BLE001
        pass
    emekli = _yedegi_emekliye_ayir(yedek, bilgi)
    return {"ok": True, "geri_konan": n, "surum": eski, "emekli": emekli,
            "mesaj": "restored %d file(s) from the update backup%s. Restart the Workshop."
                     % (n, (" (back to %s)" % eski) if eski else "")}


def durum():
    """Arayuz icin ozet: yerel surum + son yedek."""
    kok = os.path.join(VERI_KOK, "yedek")
    yedekler = _yedek_adaylari(kok)
    return {"yerel": yerel_surum(), "url": _url(), "son_yedek": (yedekler[-1] if yedekler else None)}


def _paket_dosyalari(kaynak_kok):
    """Guncellemeye girebilecek TUM dosyalar: [(mutlak_yol, arsiv_yolu)] (izinli kokler + dosyalar)."""
    out = []
    for kok in IZINLI_KOKLER:
        kd = os.path.join(kaynak_kok, kok.rstrip("/"))
        for dp, _dn, fn in os.walk(kd):
            if "__pycache__" in dp:
                continue
            for f in fn:
                if f.lower().endswith(YASAK_UZANTI) or f.endswith(".pyc"):
                    continue
                p = os.path.join(dp, f)
                out.append((p, os.path.relpath(p, kaynak_kok).replace(os.sep, "/")))
    for f in IZINLI_DOSYALAR:
        p = os.path.join(kaynak_kok, f)
        if os.path.isfile(p) and f != SURUM_DOSYA_ADI:
            out.append((p, f))
    return sorted(out, key=lambda x: x[1])


def manifest_uret(kaynak_kok):
    """{arsiv_yolu: sha256} -- paketin guncellenebilir dosyalarinin parmak izi.
    TAM paket kurulunca kaydedilir ve sonraki DELTA'lar buna gore hesaplanir."""
    return {rel: _sha(p) for p, rel in _paket_dosyalari(kaynak_kok)}


def paket_kur(kaynak_kok, cikti_zip, surum, notlar="", tarih=None, taban=None,
              taban_surum=None, nexus=None):
    """YAYINCI TARAFI: guncelleme zip'i + surum.json + TAM manifest uretir.

    taban: {arsiv_yolu: sha256} -- Nexus'a yuklenen son TAM paketin manifesti. Verilirse zip
      YALNIZ sha'si degisen ya da YENI olan dosyalari tasir (DELTA). Verilmezse her sey girer.
      Taban DAIMA son tam paket olmalidir, bir onceki delta DEGIL: yoksa araya giren surumu
      atlayan kullanici eksik dosya alir.
    taban_surum / nexus: istemci "senin surumun bu tabandan eski" durumunu anlayip kullaniciyi
      Nexus'taki tam pakete yollayabilsin diye surum.json'a yazilir.

    Doner {zip, sha256, boyut, dosya_sayisi, atlanan, silinen, manifest, surum_json}."""
    tarih = tarih or time.strftime("%Y-%m-%d")
    os.makedirs(os.path.dirname(os.path.abspath(cikti_zip)), exist_ok=True)
    hepsi = _paket_dosyalari(kaynak_kok)
    tam_manifest = {}
    n = 0
    atlanan = 0
    with zipfile.ZipFile(cikti_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p, rel in hepsi:
            h = _sha(p)
            tam_manifest[rel] = h
            if taban is not None and taban.get(rel) == h:
                atlanan += 1
                continue                       # tabanda AYNI: kullanicida zaten var
            z.write(p, rel)
            n += 1
        z.writestr(SURUM_DOSYA_ADI, json.dumps({"surum": surum, "tarih": tarih, "notlar": notlar},
                                               indent=1))
    # tabanda olup artik olmayan dosyalar: BILGI olarak yazilir, istemci SILMEZ (fail-safe)
    silinen = sorted(set(taban or {}) - set(tam_manifest))
    sha = _sha(cikti_zip)
    boyut = os.path.getsize(cikti_zip)
    sj = {"surum": surum, "tarih": tarih, "paket": os.path.basename(cikti_zip), "sha256": sha,
          "boyut": boyut, "notlar": notlar, "dosya_sayisi": n,
          "delta": bool(taban is not None), "atlanan_dosya": atlanan,
          "taban_surum": taban_surum, "nexus": nexus,
          "artik_kullanilmayan": silinen[:50]}
    kok_ad = os.path.splitext(cikti_zip)[0]
    with io.open(kok_ad + "_surum.json", "w", encoding="utf-8") as f:
        json.dump(sj, f, indent=1, ensure_ascii=False)
    with io.open(kok_ad + "_manifest.json", "w", encoding="utf-8") as f:
        json.dump(tam_manifest, f, indent=1, ensure_ascii=False, sort_keys=True)
    return {"zip": cikti_zip, "sha256": sha, "boyut": boyut, "dosya_sayisi": n,
            "atlanan": atlanan, "silinen": silinen, "manifest": tam_manifest, "surum_json": sj}


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "kontrol":
        print(json.dumps(kontrol(print), indent=1, ensure_ascii=False))
    elif a and a[0] == "durum":
        print(json.dumps(durum(), indent=1, ensure_ascii=False))
    else:
        print("usage: guncelle.py kontrol | durum")
