# -*- coding: utf-8 -*-
r"""AC4 Black Flag Resynced - MOD BIRLESTIRICI MOTORU

Motor sadece DataPC_boot_patch_02.forge yuvasini okur. Bu yuzden Nexus'tan
indirilen her mod ayni dosya adini kullanir ve ayni anda tek mod kurulabilir.
Bu motor birden fazla modun TOC girislerini TEK forge'da birlestirir.

OYUN DOSYALARINA ASLA YAZILMAZ - her acilis 'rb'.

Olculmus forge yapisi (5 gercek mod uzerinde dogrulandi):
    [0..8]    magic  b"scimitar\\x00"
    [9..12]   surum u32 = 50
    [13..20]  basligOff i64 = 1050
    [21..1049] kalip (uc modda da BAYT BIREBIR ayni)
    [1050]    girisSayisi u32
    [1054]    tocOff i64
    [1062]    8 x 0xFF
    [1070..]  giris govdeleri, bitisik
    [tocOff]  girisSayisi x 24B satir: off u64, id u64, len u32, ext u32
    [son]     sifir dolgu (4096 hizalama)

Sistem girisleri 0x10, 0x91, 0xC1, 0xFF8, 0xFFA:
    Jack v30 / Blowpipe / Kamzik CJ modlarinda BES'i de BAYT BIREBIR ayni
    (sha256 ile olculdu). Yani mod icerigine bagli degiller; sabit onyuktur.
    Eksikse OYUN ACILMAZ (patch_03 denemesinde yasandi: 0xFF8 zinciri eksik
    oldugu icin motor forge'u reddetti).
"""
import os
import re
import json
import time
import struct
import sqlite3
import hashlib
import zlib

# ---------------------------------------------------------------- SABITLER
ARAC_ADI = "ACMB"                   # AC4 Mod Birlestirici
ARAC_SURUM = "1.3.1"        # K1/K2 kapanis turu (v7) - kok ici koruma tam

MAGIC = b"scimitar\x00"
SURUM = 50
BASLIK_OFF = 1050          # [13..20]'de yazan deger
GIRIS_BASI = 1070          # 1050 + 4 (sayi) + 8 (tocOff) + 8 (FF)
TOC_SATIR = 24
HIZALAMA = 4096
BMS = bytes.fromhex("33aafb5799fa0410")

# K2 - koruma taramalarinin "makul boyut" tavani. Bir AC4 forge'u bu boyutun
# altindadir (olculen en buyugu 34 MB'lik JackSparrow_v30); tavan yalnizca
# koruma taramasinin devasa bir dosyayi bosuna hash'lemesini engeller.
KORUMA_BOYUT_TAVANI = 1 << 30      # 1 GiB

# Sistem girisleri. SIRA ONEMLI: gercek modlarda TOC'ta tam bu sirayla duruyorlar.
SISTEM_IDLER = (0x0000000000C1, 0x000000000FFA, 0x000000000FF8,
                0x000000000091, 0x000000000010)
SISTEM_KUME = frozenset(SISTEM_IDLER)

# Bilinen ext (crc32(SinifAdi)) degerleri - sadece raporu okunur kilmak icin
EXT_ADLARI = {
    0x22ECBE63: "BuildTable",
    0x989DC6B2: "TextureMapSpec",   # bkz. TEXTURE_MAP_SPEC asagida
    0x4C8BD3BF: "HamMip",
    0xA2B7E917: "TextureMap",
    0xD70E6670: "TextureSet",
    0x415D9568: "Mesh",
    0x00000000: "-",
}

# OLCULDU (UI_ikon_altin modu uzerinde):
#     TextureMapSpec  0x02140220D369   "..._MapDesc"
#     TextureMap      0x02140220D368   "..._Map"        <- spec_id - 1
#     mipler          0xA140220D36800000 / ...00001
# yani  mip id = 0xA<<60 | ((spec_id - 1) << 20) | seviye
# Spec ile Map AYNI varliktir; ayri sayilirsa "yalniz spec" + "yalniz mip"
# gonderen iki mod cakismiyor gorunur (sessiz gorsel bozulma).
TEXTURE_MAP_SPEC = 0x989DC6B2

VARLIK_DB = ""  # packaged build: the 145 MB name database is not shipped; name lookup stays silently off (IsimCozucu checks os.path.isfile)

# Kanitli sistem girisi bagisci sablonu (oyunda calistigi dogrulanmis mod)
SABLON_JACK = ""  # packaged build: the donor template forge is not shipped; the game's own DataPC_boot_patch_01.forge is the first reference and the embedded sha256 the last (ACMB handles a missing file as (None, None))

MOD_DOSYA_ADI = "DataPC_boot_patch_02.forge"

# Aracin kendi cikti klasoru. Taramada ATLANIR. DIKKAT: bu YALNIZCA ucuz bir
# 4. katmandir; asil koruma AD'A DEGIL KIMLIGE dayanir (bkz. KIMLIK bolumu).
# Y5 (olculdu): eskiden ONEK eslemesi yapiliyordu ve `_BIRLESIKMODUM` gibi
# GERCEK kullanici modlari da "aracin kendi ciktisi" diye yutuluyordu.
# Artik TAM AD esitligi: "_BIRLESIK" ya da "_BIRLESIK<sayi>".
CIKTI_KLASOR_ONEKI = "_BIRLESIK"
_CIKTI_KLASOR_DESENI = re.compile(r"^_BIRLESIK\d*$", re.IGNORECASE)

# Cikti yolu KURULU BIR OYUNU hedefliyor mu. Arac hicbir kosulda oyuna yazmaz;
# kullanici once deneme klasorune uretir, dogrular, sonra ELLE kurar.
# (1) AD'A bakan kara liste - klasor henuz yoksa bile calisir, ama tasinmis
#     kurulumlari (D:\Oyunlar\AC4, C:\PROGRA~2\..., C:\Epic Games\...) kacirir.
OYUN_YOLU_DESENLERI = ("steamapps", "program files", "assassin's creed",
                       "assassins creed")
# (2) ICERIGE bakan kontrol - B4'un kalan acigini kapatir. Ad ne olursa olsun,
#     hedef klasorde oyunun exe'si ya da 3+ .forge varsa orasi bir OYUN kurulumu.
OYUN_EXELERI = ("acblackflag.exe", "ac4bfsp.exe", "ac4bfmp.exe",
                "assassinscreedivblackflag.exe", "ac4bf.exe")
# Z7 (OLCULDU): esik 3 idi ve Z4 duzeltmesinden sonra TUM ust klasorlere
# uygulaniyordu. Ciktilarini/yedeklerini tek klasorde tutan bir modcunun
# 3. `.forge`'undan sonra o klasor VE TUM ALT AGACI yazilamaz oluyordu
# (rc=6, kacis yolu yok, ustelik mesaj "kurulu bir oyunu hedefliyor" diyordu).
# Artik salt sayi yetmez; GUCLU IMZA gerekir (bkz. oyun_klasoru_mu).
OYUN_FORGE_ESIGI = 10
# Vanilla kurulumda HER ZAMAN yan yana duran iki dosya. Ikisi birden varsa
# klasor kesinlikle bir oyun veri klasorudur (kullanicinin cikti klasorunde
# ikisi birden bulunmaz - arac yalnizca patch_02 uretir).
OYUN_IMZA_CIFTI = ("datapc_boot.forge", "datapc_boot_patch_01.forge")
# Sayim yalnizca oyunun kendi ad desenine uyan forge'lari sayar.
_OYUN_FORGE_DESENI = re.compile(r"^datapc_.*\.forge$", re.IGNORECASE)

# --------------------------------------------------------------- KIMLIK
# B1'in KOK COZUMU. Ad tabanli ("_BIRLESIK" oneki) ve tek-kosum tabanli
# (atla=[cikti_dizin]) koruma OLCULDU ve YETMEDI: cikti klasoru turler arasi
# degisince (cikti1 -> cikti2 -> BIRLESIK_YENI -> kok altinda duz dosya) arac
# kendi eski ciktisini 6./7./8. mod sanip geri yedi; --kati ise yaramadi.
#
# Cozum AD'A DEGIL KIMLIGE bakar. Uc katman (hepsi ad-bagimsiz):
#   1) DEFTER  - urettigimiz her forge'un sha256 + parmak izi kalici bir
#                deftere yazilir; taramada deftere kayitli her dosya atlanir.
#                Yeniden adlandirmaya, tasimaya, kopyalamaya dayaniklidir.
#   2) YAN DOSYA (.acmb) - ciktinin yanina JSON kimlik karti birakilir; klasor
#                oldugu gibi baska makineye tasinsa da taninir (defter yoksa).
#   3) SUPERSET SEZGISI - deftere de yan dosyaya da sahip olmayan bir aday,
#                baska IKI adayin giris kumesini birden kapsiyorsa bu neredeyse
#                kesin onceki bir birlesimdir.
# Damga NEDEN forge'un kuyruguna yazilmadi: bkz. KOK_COZUM_RAPORU.md §1.
# Ozet olcum: 158 oyun forge'unun 157'sinde TOC sonrasi kuyruk tamamen sifir,
# AMA vanilla DataPC_boot.forge'un kuyrugunda 16 konteynerlik GECERLI bir BMS
# zinciri var ve TAM DOSYA SONUNDA bitiyor. Yani "TOC sonrasi bolge motorun
# okumadigi olu alandir" iddiasi OLCUMLE CURUTULDU; oraya bayt yazmak
# kanitlanmamis risktir. Kimlik dosya DISINDA tutuluyor.
YAN_DOSYA_UZANTI = ".acmb"
DEFTER_ENV = "ACMB_DEFTER"
DEFTER_SINIR = 500                  # defterde tutulacak en fazla kayit

# --------------------------------------------------------------- Y1b REFERANS
# Kalip (ilk 1050 B) normalde "alfabetik ilk + sistem girisi tam" bagisci
# modundan alinir. BAGISCININ KENDI kalibi kirliyse o kirli kalip ciktiya gecer
# ve geri_dogrula kendisiyle karsilastirdigi icin "0 hata" der (OLCULDU:
# cikti kalibi temiz referanstan 2 bayt farkli [400, 800], rc=0).
# Bu yuzden kalip AYRICA dosya disi, BAGIMSIZ bir referansa karsi olculur.
# Olculdu (2026-07-29): oyunun vanilla DataPC_boot_patch_01.forge dosyasinin
# ILK 1050 BAYTI, JackSparrow_v30'un kalibiyla [0..1049] BIREBIR ayni.
REFERANS_KALIP_SHA256 = \
    "ecfeba18606e685c903966fb0309d032aa530dfc41320a4c726dd85cd76b833c"
# Referans kalip kaynaklari - SIRAYLA denenir, hepsi SALT OKUNUR ("rb").
# Oyun dosyasina ASLA yazilmaz; yalnizca ilk 1050 bayti okunur.
REFERANS_KALIP_YOLLARI = (
    r"C:\Program Files (x86)\Steam\steamapps\common"
    r"\Assassin's Creed Black Flag Resynced\DataPC_boot_patch_01.forge",
    SABLON_JACK,
)


# ------------------------------------------------------ YOL COZUMLEME (Z1)
# Z1 (OLCULDU, VERI KAYBI): cikti/kaynak yol karsilastirmasi
# os.path.normcase(os.path.abspath(...)) ile, yani METIN olarak yapiliyordu.
# abspath Windows'ta 8.3 kisa adlari, junction/symlink'leri, `\\?\` onekini ve
# UNC yazimlarini COZMEZ. Dort ayri yazimla (8.3 · \\?\ · junction · UNC) hem
# rc=8 (kaynak mod uzerine yazma) hem rc=9 (kok ici cikti) korumasi devre disi
# kaldi ve 34.056.513 B'lik kaynak mod uzerine yazildi; arac rc=0 "basarili"
# dedi. 8.3 senaryosunda dosya adi DATAPC~1.FOR olup mod tamamen kayboldu.
# Junction vektoru gercekcidir: Vortex/MO2 mod kutuphanelerini junction'la kurar.
_UZUN_ONEK = "\\\\?\\"
_UZUN_UNC_ONEK = "\\\\?\\UNC\\"
_UZUN_YOL_SINIRI = 250            # bu uzunlugun ustunde \\?\ oneki KORUNUR


def onek_soy(yol):
    r"""`\\?\` ve `\\?\UNC\` uzun-yol oneklerini soy (Z1-b)."""
    if not yol:
        return yol
    y = str(yol).replace("/", os.sep) if os.sep == "\\" else str(yol)
    if y[:8].upper() == _UZUN_UNC_ONEK:
        return "\\\\" + y[8:]
    if y[:4] == _UZUN_ONEK:
        return y[4:]
    return y


def _uzun_ad(yol):
    """8.3 kisa adlari uzun adlara cevir (GetLongPathNameW) (Z1-a).

    Yalnizca VAR OLAN yollarda calisir; basarisizsa yol aynen doner.
    Windows disinda ya da API yoksa sessizce yol doner.
    """
    if os.name != "nt":
        return yol
    try:
        import ctypes
        from ctypes import wintypes
        f = ctypes.windll.kernel32.GetLongPathNameW
        f.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
        f.restype = wintypes.DWORD
        buf = ctypes.create_unicode_buffer(32768)
        n = f(yol, buf, 32768)
        if n and n < 32768 and buf.value:
            return buf.value
    except Exception:
        pass
    return yol


def kanonik_yol(yol):
    r"""Yolu KANONIK hale getir - buyuk/kucuk harf KORUNUR (yazmak icin).

    Katmanlar (Z1 duzeltmesi):
      (b) `\\?\` / `\\?\UNC\` oneki soyulur,
      (a) os.path.realpath ile symlink/junction cozulur,
      (a) var olan en derin ata GetLongPathNameW ile uzun ada cevrilir
          (8.3 kisa adlar cozulur), henuz var olmayan son parcalar korunur.
    Cok uzun sonuclarda `\\?\` oneki geri konur (uzun yol destegi bozulmasin).
    Karsilastirma icin gercek_yol() kullanin (o ayrica normcase uygular).
    """
    if not yol:
        return ""
    y = onek_soy(yol)
    try:
        y = os.path.realpath(os.path.abspath(y))
    except (OSError, ValueError):
        y = os.path.abspath(y)
    y = onek_soy(y)                      # realpath `\\?\` uretebilir
    kuyruk = []
    aday = y
    while not os.path.exists(aday):
        ust, son = os.path.split(aday)
        if not son or ust == aday:
            break
        kuyruk.append(son)
        aday = ust
    if os.path.exists(aday):
        aday = onek_soy(_uzun_ad(aday))
    for parca in reversed(kuyruk):
        aday = os.path.join(aday, parca)
    if len(aday) >= _UZUN_YOL_SINIRI and not aday.startswith("\\\\"):
        aday = _UZUN_ONEK + aday
    return aday


def gercek_yol(yol):
    """Karsilastirma icin kanonik yol (kanonik_yol + normcase)."""
    return os.path.normcase(kanonik_yol(yol))


def ayni_dosya_mi(a, b):
    """Iki yol AYNI dosyayi mi gosteriyor (Z1 - dosya KIMLIGI tabanli).

    (c) Ikisi de VARSA os.path.samefile: st_dev + st_ino, yani dosya kimligi.
        Windows'ta da calisir ve UNC / farkli surucu yazimlarini cozer.
    (a,b) Aksi halde gercek_yol() ile kanonik metin karsilastirmasi.
    """
    try:
        if os.path.exists(onek_soy(a)) and os.path.exists(onek_soy(b)):
            return os.path.samefile(onek_soy(a), onek_soy(b))
    except (OSError, ValueError):
        pass
    return gercek_yol(a) == gercek_yol(b)


def _kapsama_yolu(yol):
    r"""Kapsama testi icin normal form: onek HER ZAMAN soyulur + normcase.

    Z6 (OLCULDU): `kanonik_yol()` 250 karakteri asan sonuclara `\\?\` onekini
    GERI KOYUYOR. Kisa kokte onek yok; `ic_yol_mu()` metin karsilastirmasi
    oldugu icin `\\?\C:\...` ile `C:\...` eslesmiyordu ve rc=9 korumasi
    atlaniyordu (cikti kokun ICINE yazildi). Artik karsilastirmanin IKI TARAFI
    da ayni normalizasyondan gecer: onek soy -> realpath -> onek soy -> normcase.
    """
    if not yol:
        return ""
    return os.path.normcase(onek_soy(kanonik_yol(yol)))


def ic_yol_mu(dis, ic):
    r"""`ic` yolu `dis` klasorunun ICINDE mi (ya da tam kendisi mi).

    UC katman - hepsi ayni normal form uzerinde calisir:
      (1) esitlik,
      (2) `os.path.commonpath` ile kapsama (metin, ama onek soyulmus halde),
      (3) ATA ZINCIRI + DOSYA KIMLIGI: `ic`in atalarindan biri `dis` ile
          `os.path.samefile` esitse ICERIDEDIR. Bu katman metin
          karsilastirmasinin cozemedigi yazimlari kapatir:
            - UNC yazimi (`\\localhost\C$\...`) ile surucu harfi (`C:\...`),
              `realpath` bunlari BIRBIRINE CEVIRMEZ (Z6-B),
            - farkli mount/subst yazimlari.
    Var olmayan son parcalar icin zincir var olan ilk ataya kadar tirmanir.
    """
    d = _kapsama_yolu(dis)
    i = _kapsama_yolu(ic)
    if not d or not i:
        return False
    if i == d:
        return True
    if i.startswith(d.rstrip(os.sep) + os.sep):
        return True
    try:
        if os.path.commonpath([d, i]).rstrip(os.sep) == d.rstrip(os.sep):
            return True
    except (ValueError, OSError):
        pass
    # (3) ata zincirinde DOSYA KIMLIGI ile kapsama (Z6-B: UNC <-> surucu harfi)
    try:
        if not os.path.isdir(onek_soy(kanonik_yol(dis))):
            return False
    except (OSError, ValueError):
        return False
    aday = onek_soy(kanonik_yol(ic))
    gorulen = set()
    while aday and aday not in gorulen:
        gorulen.add(aday)
        try:
            if os.path.isdir(aday) and ayni_dosya_mi(aday, dis):
                return True
        except (OSError, ValueError):
            pass
        ust = os.path.dirname(aday)
        if ust == aday:
            break
        aday = ust
    return False


# ---------------------------------------------------------------- HATA TIPLERI
OLUMCUL = "OLUMCUL"        # yapisal bozukluk - mod hicbir sekilde kullanilamaz
YALNIZ = "YALNIZ_OLUMCUL"  # tek basina kurulursa oyun acilmaz (sistem girisi yok)
UYARI = "UYARI"            # kusurlu ama calisir


class Hata(object):
    def __init__(self, seviye, kod, mesaj):
        self.seviye = seviye
        self.kod = kod
        self.mesaj = mesaj

    def __repr__(self):
        return "[%s] %s: %s" % (self.seviye, self.kod, self.mesaj)


class Giris(object):
    """Tek bir TOC girisi + ham baytlari."""
    __slots__ = ("off", "fid", "ln", "ext", "ham", "sira")

    def __init__(self, off, fid, ln, ext, ham, sira):
        self.off, self.fid, self.ln, self.ext = off, fid, ln, ext
        self.ham = ham
        self.sira = sira

    @property
    def sistem(self):
        return self.fid in SISTEM_KUME

    @property
    def mip(self):
        return (self.fid >> 63) == 1

    @property
    def taban_fid(self):
        """Girisin ait oldugu MANTIKSAL varlik id'si.

        mip           -> 0xA<<60 | (taban<<20) | seviye  ise taban
        TextureMapSpec-> spec_id - 1 (= TextureMap id, olculdu)
        digerleri     -> kendi id'si
        """
        if self.mip:
            return (self.fid & ~(1 << 63)) >> 20
        if self.ext == TEXTURE_MAP_SPEC:
            return self.fid - 1
        return self.fid

    @property
    def mip_seviye(self):
        return (self.fid & 0xFFFFF) if self.mip else None

    def ext_ad(self):
        return EXT_ADLARI.get(self.ext, "0x%08X" % self.ext)


class Mod(object):
    """Tek bir modun raporu."""

    def __init__(self, ad, yol):
        self.ad = ad
        self.yol = yol
        self.boyut = 0
        self.kalip = b""          # ilk 1050 bayt
        self.girisler = []        # [Giris]
        self.hatalar = []
        self.toc_off = 0
        self.kuyruk_dolgu = 0
        self.sha256 = ""

    # --- turetilmis
    @property
    def sistem_girisleri(self):
        return [g for g in self.girisler if g.sistem]

    @property
    def varlik_girisleri(self):
        return [g for g in self.girisler if not g.sistem]

    @property
    def sistem_tam(self):
        return set(g.fid for g in self.sistem_girisleri) == set(SISTEM_IDLER)

    @property
    def eksik_sistem(self):
        return [s for s in SISTEM_IDLER if s not in set(g.fid for g in self.girisler)]

    @property
    def dokunulan_varliklar(self):
        """Mod'un etkiledigi mantiksal varlik id kumesi (mip'ler tabanina sayilir)."""
        return set(g.taban_fid for g in self.varlik_girisleri)

    @property
    def olumcul_mu(self):
        return any(h.seviye == OLUMCUL for h in self.hatalar)

    @property
    def yalniz_olumcul_mu(self):
        return any(h.seviye == YALNIZ for h in self.hatalar)

    @property
    def kullanilabilir(self):
        """Birlestirmeye katilabilir mi (yapisal olarak saglam mi)."""
        return not self.olumcul_mu and len(self.varlik_girisleri) > 0


# ---------------------------------------------------------------- OKUMA
def _u32(d, o):
    return struct.unpack_from("<I", d, o)[0]


def _i64(d, o):
    return struct.unpack_from("<q", d, o)[0]


def mod_oku(yol, ad=None):
    """Forge dosyasini ac, TOC + girisleri cikar, MOD RAPORU dondur.

    Yapisal olarak okunamayacak kadar bozuksa Mod dondurulur ama
    hatalar listesinde OLUMCUL kayit olur ve girisler bos kalir.
    """
    ad = ad or os.path.basename(os.path.dirname(os.path.abspath(yol)))
    m = Mod(ad, os.path.abspath(yol))

    if not os.path.isfile(yol):
        m.hatalar.append(Hata(OLUMCUL, "DOSYA_YOK", "dosya bulunamadi: %s" % yol))
        return m

    with open(yol, "rb") as f:          # SADECE OKUMA
        d = f.read()
    m.boyut = len(d)
    m.sha256 = hashlib.sha256(d).hexdigest()

    if len(d) < GIRIS_BASI:
        m.hatalar.append(Hata(OLUMCUL, "COK_KISA",
                              "dosya %d B - en az %d B olmali" % (len(d), GIRIS_BASI)))
        return m

    if d[:9] != MAGIC:
        m.hatalar.append(Hata(OLUMCUL, "MAGIC",
                              "magic 'scimitar\\0' degil: %r" % d[:9]))
        return m

    ver = _u32(d, 9)
    if ver != SURUM:
        m.hatalar.append(Hata(UYARI, "SURUM", "surum %d (beklenen %d)" % (ver, SURUM)))

    hoff = _i64(d, 13)
    if hoff != BASLIK_OFF:
        m.hatalar.append(Hata(OLUMCUL, "BASLIK_OFF",
                              "basligOff %d (beklenen %d)" % (hoff, BASLIK_OFF)))
        return m

    m.kalip = d[:BASLIK_OFF]
    cnt = _u32(d, hoff)
    toc = _i64(d, hoff + 4)
    m.toc_off = toc
    ff = d[hoff + 12:hoff + 20]
    if ff != b"\xff" * 8:
        m.hatalar.append(Hata(UYARI, "FF_DOLGU", "8xFF dolgusu bozuk: %s" % ff.hex()))

    if cnt <= 0 or cnt > 100000:
        m.hatalar.append(Hata(OLUMCUL, "GIRIS_SAYISI", "girisSayisi=%d anlamsiz" % cnt))
        return m
    if not (0 < toc <= len(d)) or toc + cnt * TOC_SATIR > len(d):
        m.hatalar.append(Hata(OLUMCUL, "TOC_TASMA",
                              "TOC dosya disinda: tocOff=%d + %dx24 > boyut=%d"
                              % (toc, cnt, len(d))))
        return m

    for i in range(cnt):
        off, fid, ln, ext = struct.unpack_from("<QQII", d, toc + i * TOC_SATIR)
        if off < GIRIS_BASI or off + ln > toc:
            m.hatalar.append(Hata(OLUMCUL, "GIRIS_TASMA",
                                  "giris 0x%012X: off=%d len=%d TOC alanina tasiyor (toc=%d)"
                                  % (fid, off, ln, toc)))
            continue
        m.girisler.append(Giris(off, fid, ln, ext, d[off:off + ln], i))

    m.kuyruk_dolgu = len(d) - (toc + cnt * TOC_SATIR)
    if set(d[toc + cnt * TOC_SATIR:]) - {0}:
        m.hatalar.append(Hata(UYARI, "KUYRUK", "TOC sonrasi dolgu tamamen sifir degil"))
    return m


# ---------------------------------------------------------------- BMS TARAYICI
def bms_tara(veri):
    """BMS konteynerlerini ACMADAN yapisal olarak yuru.

    Sikistirma acilmaz (Oodle DLL gerekmez) - sadece blok basliklarinin
    tutarli olup olmadigi ve verinin tam bittigi olculur.
    Doner: (bitis_offseti, konteyner_sayisi). Bozuksa ValueError.
    """
    p = 0
    n = len(veri)
    kon = 0
    while p < n and veri[p:p + 8] == BMS:
        p = _konteyner_atla(veri, p)
        kon += 1
    return p, kon


def _konteyner_atla(d, off):
    n = len(d)
    if off + 15 > n:
        raise ValueError("BMS basligi kesik @%d" % off)
    ver, algo = struct.unpack_from("<HB", d, off + 8)
    raw = _u32(d, off + 11)
    tocmode = raw >> 31
    p = off + 15
    if tocmode:
        if p + 4 > n:
            raise ValueError("TOCmode sayaci kesik @%d" % p)
        cnt = _u32(d, p)
        p += 4
        if cnt > 100000 or p + cnt * 8 > n:
            raise ValueError("TOCmode blok sayisi anlamsiz (%d) @%d" % (cnt, p))
        boy = []
        for _ in range(cnt):
            u, c = struct.unpack_from("<II", d, p)
            p += 8
            boy.append((u, c))
        for u, c in boy:
            p += 4                      # adler32
            if p + c > n:
                raise ValueError("blok verisi dosya disinda (c=%d) @%d" % (c, p))
            p += c
    else:
        while p < n and d[p:p + 8] != BMS:
            isc = d[p]
            p += 1
            if isc:
                if p + 12 > n:
                    raise ValueError("sikistirilmis blok basligi kesik @%d" % p)
                c, u = struct.unpack_from("<iI", d, p)
                p += 8 + 4
                if c < 0 or p + c > n:
                    raise ValueError("sikistirilmis blok tasiyor (c=%d) @%d" % (c, p))
                p += c
            else:
                if p + 4 > n:
                    raise ValueError("ham blok basligi kesik @%d" % p)
                sz = struct.unpack_from("<i", d, p)[0]
                p += 4
                if sz < 0 or p + sz > n:
                    raise ValueError("ham blok tasiyor (sz=%d) @%d" % (sz, p))
                p += sz
    return p


# ---------------------------------------------------------------- DOGRULAMA
def dogrula(mod):
    """Modu dogrula, hata listesini (mod.hatalar'a eklenmis halde) dondur.

    mod_oku zaten yapisal hatalari toplamis olur; burada iceriksel
    kontroller yapilir.
    """
    if mod.olumcul_mu:
        return mod.hatalar

    # --- 1) girisler bitisik mi, ortusme var mi
    sirali = sorted(mod.girisler, key=lambda g: g.off)
    beklenen = GIRIS_BASI
    bosluk = 0
    for g in sirali:
        if g.off < beklenen:
            mod.hatalar.append(Hata(OLUMCUL, "ORTUSME",
                                    "giris 0x%012X off=%d onceki girisle ortusuyor "
                                    "(beklenen >= %d)" % (g.fid, g.off, beklenen)))
        elif g.off > beklenen:
            bosluk += 1
        beklenen = g.off + g.ln
    if bosluk:
        mod.hatalar.append(Hata(UYARI, "BOSLUK",
                                "%d girisin onunde bosluk var (motor okur ama israf)" % bosluk))
    if beklenen != mod.toc_off:
        mod.hatalar.append(Hata(UYARI, "VERI_SONU",
                                "veri sonu %d != tocOff %d" % (beklenen, mod.toc_off)))

    # --- 2) ayni id iki kez mi
    gorulen = {}
    for g in mod.girisler:
        if g.fid in gorulen:
            mod.hatalar.append(Hata(OLUMCUL, "TEKRAR_ID",
                                    "0x%012X TOC'ta iki kez var (sira %d ve %d)"
                                    % (g.fid, gorulen[g.fid], g.sira)))
        gorulen[g.fid] = g.sira

    # --- 3) BMS yapisi
    for g in mod.girisler:
        if g.ham[:8] != BMS:
            continue                     # ham mip / duz veri - BMS beklenmiyor
        try:
            son, kon = bms_tara(g.ham)
        except ValueError as e:
            mod.hatalar.append(Hata(OLUMCUL, "BMS_BOZUK",
                                    "0x%012X: %s" % (g.fid, e)))
            continue
        if son != g.ln:
            mod.hatalar.append(Hata(UYARI, "BMS_ARTIK",
                                    "0x%012X: BMS %d B'de bitti ama giris %d B "
                                    "(%d B artik)" % (g.fid, son, g.ln, g.ln - son)))

    # --- 4) sistem girisi seti
    eksik = mod.eksik_sistem
    if eksik and len(eksik) < len(SISTEM_IDLER):
        mod.hatalar.append(Hata(YALNIZ, "SISTEM_EKSIK",
                                "sistem girisi KISMEN var, eksik: %s -> tek basina "
                                "kurulursa OYUN ACILMAZ"
                                % ", ".join("0x%X" % s for s in eksik)))
    elif eksik:
        mod.hatalar.append(Hata(YALNIZ, "SISTEM_YOK",
                                "hicbir sistem girisi yok (0x10 0x91 0xC1 0xFF8 0xFFA) "
                                "-> tek basina kurulursa OYUN ACILMAZ"))

    # --- 5) icerik var mi
    if not mod.varlik_girisleri:
        mod.hatalar.append(Hata(OLUMCUL, "BOS_MOD",
                                "modda hic varlik girisi yok, sadece sistem girisleri"))

    # --- 6) kalip
    if len(mod.kalip) == BASLIK_OFF and mod.kalip[:9] != MAGIC:
        mod.hatalar.append(Hata(OLUMCUL, "KALIP", "1050B kalip bozuk"))
    return mod.hatalar


# ---------------------------------------------------------------- ISIM COZME
class IsimCozucu(object):
    """varliklar.db uzerinden fid -> ad. DB yoksa sessizce devre disi kalir."""

    def __init__(self, db=VARLIK_DB):
        self.c = None
        self.onbellek = {}
        if os.path.isfile(db):
            try:
                self.c = sqlite3.connect("file:" + db + "?mode=ro", uri=True)
            except sqlite3.Error:
                self.c = None

    def ad(self, fid):
        if fid in self.onbellek:
            return self.onbellek[fid]
        s = None
        if self.c is not None:
            try:
                r = self.c.execute(
                    "select ad from ic_dosyalar where ic_id=? and ad is not null limit 1",
                    (fid,)).fetchone()
                if r:
                    s = r[0]
            except sqlite3.Error:
                s = None
        self.onbellek[fid] = s
        return s

    def etiket(self, giris):
        """Rapor icin okunur etiket."""
        if giris.sistem:
            return "SISTEM"
        a = self.ad(giris.taban_fid)
        if giris.mip:
            return ("%s [mip %d]" % (a, giris.mip_seviye)) if a \
                else "0x%012X [mip %d]" % (giris.taban_fid, giris.mip_seviye)
        # TextureMapSpec taban olarak fid-1 sayilir ama ADI kendi id'sinde durur
        return self.ad(giris.fid) or a or "(adi bilinmiyor)"

    def kapat(self):
        if self.c is not None:
            self.c.close()


# ---------------------------------------------------------------- CAKISMA
class Cakisma(object):
    """Ayni varliga dokunan birden fazla mod."""

    def __init__(self, taban_fid, ad, modlar, girisler):
        self.taban_fid = taban_fid
        self.ad = ad
        self.modlar = modlar            # [mod adi]
        self.girisler = girisler        # {mod adi: [Giris]}
        self.tam = False                # ayni TOC id'sini paylasiyorlar mi
        self.gercek = True              # baytlar farkli mi (False = sahte cakisma)

    def __repr__(self):
        return "<Cakisma 0x%012X %s %s gercek=%s>" % (
            self.taban_fid, self.ad, self.modlar, self.gercek)


def cakisma_bul(modlar, cozucu=None):
    """Ayni varlik id'sine dokunan modlari bul. Doner: [Cakisma] (adlariyla).

    SAHTE CAKISMA: iki mod ayni id'yi tasiyor ama govdeler BAYT BIREBIR ayni.
    Olculdu: Jack v30 ile Kamzik CJ modunun 4 ortak girisinden 3'u birebir ayni
    (pantolon/ayakkabi BuildTable'lari her iki modda da vanilla kopyasi).
    Boyle bir cakismada secilecek bir sey yoktur - kullaniciya SORULMAZ.
    """
    cozucu = cozucu or IsimCozucu()
    taban = {}
    sert = {}
    for m in modlar:
        for g in m.varlik_girisleri:
            taban.setdefault(g.taban_fid, {}).setdefault(m.ad, []).append(g)
            sert.setdefault(g.fid, set()).add(m.ad)

    out = []
    for fid, mp in sorted(taban.items()):
        if len(mp) < 2:
            continue
        c = Cakisma(fid, cozucu.ad(fid) or "(adi bilinmiyor)", sorted(mp), mp)
        for g_list in mp.values():
            for g in g_list:
                if len(sert.get(g.fid, ())) > 1:
                    c.tam = True
        # baytlar gercekten farkli mi
        imza = set()
        for mad in c.modlar:
            imza.add(tuple(sorted((g.fid, hashlib.sha256(g.ham).hexdigest())
                                  for g in mp[mad])))
        c.gercek = len(imza) > 1
        out.append(c)
    return out


# ---------------------------------------------------------------- BIRLESTIRME
class Sonuc(object):
    def __init__(self):
        self.girisler = []          # [(fid, ham, ext)] yazim sirasinda
        self.kalip = b""
        self.sistem_kaynak = None   # sistem girislerini veren mod adi
        self.kullanilan = []        # [mod adi]
        self.atlanan = []           # [(mod adi, sebep)]
        self.cozulen = []           # [(taban_fid, ad, kazanan, kaybedenler)]
        self.sahte_cakisma = []     # [(taban_fid, ad, modlar)] baytlar zaten ayni
        self.notlar = []
        self.kalip_kaynak = None    # 1050B kalibi veren mod adi (Y1)
        # Y2: cozulen cakismada kaybedende olup ciktida OLMAYAN girisler
        self.eksik_girisler = []    # [(taban_fid, ad, kazanan, kaybeden, [fid])]


def birlestir(modlar, cozumler=None, sistem_sablonu=None, cozucu=None):
    """Modlarin girislerini tek forge icerigi haline getir.

    modlar        : [Mod]  (dogrulanmis, yapisal olarak saglam olanlar)
    cozumler      : {taban_fid: kazanan_mod_adi}  cakisan varlik icin secim
    sistem_sablonu: hicbir modda sistem girisi yoksa kullanilacak forge yolu
    Doner: Sonuc
    """
    cozumler = cozumler or {}
    cozucu = cozucu or IsimCozucu()
    s = Sonuc()
    if not modlar:
        raise ValueError("birlestirilecek mod yok")

    # --- 1) sistem girisleri: TAM setine sahip modlardan
    bagiscilar = [m for m in modlar if m.sistem_tam]

    # --- 1b) kalip: KANITLI BAGISCIDAN (Y1 duzeltmesi)
    # Eskiden kalip modlar[0]'dan, yani ALFABETIK ILK moddan aliniyordu; sistem
    # girisleri ise bagiscilar[0]'dan. Iki AYRI kaynak. Olculdu: sistem girisi
    # olmayan, kalibi kirletilmis bir mod (AAA_kalipfark) alfabetik ilk sirada
    # oldugu icin kalibini birlesime dayatti, cikti yine "16/16 OK" dedi.
    # Artik kalip da sistem girislerini veren modtan gelir - TEK kaynak.
    kalip_kaynagi = bagiscilar[0] if bagiscilar else modlar[0]
    s.kalip = kalip_kaynagi.kalip
    s.kalip_kaynak = kalip_kaynagi.ad
    for m in modlar:
        if m.ad != kalip_kaynagi.ad and m.kalip != s.kalip:
            s.notlar.append("UYARI: %s modunun 1050B kalibi bagiscininkinden farkli; "
                            "%s'in kalibi kullanildi (kanitli bagisci)"
                            % (m.ad, kalip_kaynagi.ad))

    # --- 2) sistem girisi govdeleri
    sistem = None
    if bagiscilar:
        sistem = {g.fid: g for g in bagiscilar[0].sistem_girisleri}
        s.sistem_kaynak = bagiscilar[0].ad
        # birden fazla bagisci varsa bayt birebir mi olc
        for b in bagiscilar[1:]:
            bm = {g.fid: g for g in b.sistem_girisleri}
            fark = [k for k in SISTEM_IDLER if bm[k].ham != sistem[k].ham]
            if fark:
                s.notlar.append("UYARI: %s ile %s sistem girisleri farkli (%s); "
                                "%s kullanildi" % (bagiscilar[0].ad, b.ad,
                                                   ", ".join("0x%X" % f for f in fark),
                                                   bagiscilar[0].ad))
            else:
                s.notlar.append("%s sistem girisleri %s ile BAYT BIREBIR ayni (dogrulandi)"
                                % (b.ad, bagiscilar[0].ad))
    elif sistem_sablonu:
        sm = mod_oku(sistem_sablonu, ad="SABLON")
        dogrula(sm)
        if not sm.sistem_tam:
            raise ValueError("sistem sablonunda tam sistem seti yok: %s" % sistem_sablonu)
        sistem = {g.fid: g for g in sm.sistem_girisleri}
        s.sistem_kaynak = "sablon:" + os.path.basename(os.path.dirname(sistem_sablonu))
        # Y1: kalip da sistem girisleriyle AYNI kaynaktan gelmeli
        s.kalip = sm.kalip
        s.kalip_kaynak = s.sistem_kaynak
        for m in modlar:
            if m.kalip != s.kalip:
                s.notlar.append("UYARI: %s modunun 1050B kalibi sablonunkinden farkli; "
                                "sablonun kalibi kullanildi" % m.ad)
        s.notlar.append("DIKKAT: hicbir modda sistem girisi yoktu, disaridan sablon "
                        "kullanildi (%s). Bu bir TAHMINDIR - oyunda test edin."
                        % sistem_sablonu)
    else:
        raise ValueError(
            "hicbir modda tam sistem girisi seti (0x10 0x91 0xC1 0xFF8 0xFFA) yok. "
            "Boyle bir forge yazilirsa OYUN ACILMAZ. Sistem girisi olan bir mod "
            "ekleyin ya da --sistem-sablon ile kanitli bir forge gosterin.")

    # --- 3) varlik girisleri: cakisanlarda kazanan
    cakismalar = {c.taban_fid: c for c in cakisma_bul(modlar, cozucu)}
    yazilan_id = {}
    for m in modlar:
        s.kullanilan.append(m.ad)
        for g in m.varlik_girisleri:
            c = cakismalar.get(g.taban_fid)
            if c is not None:
                kazanan = cozumler.get(g.taban_fid)
                if kazanan is None:
                    kazanan = c.modlar[0]      # varsayilan: ilk mod (deterministik)
                if m.ad != kazanan:
                    continue                   # kaybeden modun girisi atlanir
            if g.fid in yazilan_id:
                # ayni id iki kez: kazanan zaten yazdi
                continue
            yazilan_id[g.fid] = m.ad
            s.girisler.append((g.fid, g.ham, g.ext))

    for fid, c in sorted(cakismalar.items()):
        kazanan = cozumler.get(fid, c.modlar[0])
        kayb = [x for x in c.modlar if x != kazanan]
        if c.gercek:
            s.cozulen.append((fid, c.ad, kazanan, kayb))
        else:
            s.sahte_cakisma.append((fid, c.ad, c.modlar))

    # --- 3b) Y2: kazanan EKSIK SET getirdi mi (dangling referans riski)
    # Cakisma cozumu taban bazinda "kazanan her seyi alir, kaybeden tamamen
    # duser". Kazanan o tabanda kaybedenden AZ giris gonderiyorsa birlesim
    # hicbir kaynak modda olmayan EKSIK bir set uretir. Olculdu: yalniz-spec
    # gonderen mod, spec+2mip gonderen modu yenince ciktida MIPSIZ bir
    # TextureMapSpec kaldi ve arac "16 kontrol, 0 hata" dedi.
    yazilan_kume = set(f for f, _, _ in s.girisler)
    for fid, c in sorted(cakismalar.items()):
        if not c.gercek:
            continue
        kazanan = cozumler.get(fid, c.modlar[0])
        for kayb in [x for x in c.modlar if x != kazanan]:
            eksik = sorted(set(g.fid for g in c.girisler[kayb]) - yazilan_kume)
            if eksik:
                s.eksik_girisler.append((fid, c.ad, kazanan, kayb, eksik))
                s.notlar.append(
                    "UYARI (EKSIK SET): 0x%012X %s -> kazanan %s, kaybeden %s'in "
                    "%d girisini GETIRMIYOR (%s). Birlesimde bu varlik EKSIK "
                    "kalabilir (dangling referans / sessiz gorsel bozulma)."
                    % (fid, c.ad, kazanan, kayb, len(eksik),
                       ", ".join("0x%012X" % f for f in eksik[:4])))

    # --- 4) sistem girisleri en sona, gercek modlardaki sirayla
    for sid in SISTEM_IDLER:
        g = sistem[sid]
        s.girisler.append((g.fid, g.ham, g.ext))

    # --- 5) Y1b: kalibi BAGISCIDAN BAGIMSIZ referansa karsi olc (reddetme, bildir)
    ref_uyari = kalip_referans_kontrolu(s.kalip)
    if ref_uyari:
        s.notlar.append(ref_uyari)

    # --- son kontrol: 5 sistem girisi MUTLAKA
    var = set(f for f, _, _ in s.girisler) & SISTEM_KUME
    if var != set(SISTEM_IDLER):
        raise AssertionError("ic hata: sistem girisi seti tam degil: %s" % var)
    return s


# ---------------------------------------------------------------- YAZMA
def oyun_yolu_mu(yol):
    """AD'a bakan kara liste. Doner: eslesen desen ya da None.

    Klasor henuz yoksa bile calisir; ama tasinmis kurulumlari kacirir - bu
    yuzden TEK BASINA yeterli DEGILDIR, oyun_klasoru_mu() ile birlikte kullanin.
    """
    # Z1: kanonik yol - `C:\\PROGRA~2\\...` gibi 8.3 yazimlar da cozulur,
    # yoksa "program files" deseni kacardi.
    n = gercek_yol(yol)
    for d in OYUN_YOLU_DESENLERI:
        if os.path.normcase(d) in n:
            return d
    return None


def oyun_imzasi(icerik):
    """Bir klasorun icerik listesi OYUN KURULUMU imzasi tasiyor mu (Z7).

    Salt sayiya degil GUCLU IMZALARA bakar. Doner: gerekce parcasi ya da None.

      A) Vanilla ikili: `DataPC_boot.forge` VE `DataPC_boot_patch_01.forge`
         ikisi birden. Bu arac yalnizca patch_02 uretir; kullanicinin cikti ya
         da yedek klasorunde bu ikisi BIRLIKTE bulunmaz.
      B) Oyunun kendi calistirilabiliri (`ACBlackFlag.exe` gibi). Ad AC4'e
         ozgudur; bir modcunun cikti/yedek klasorunde tesadufen bulunmaz -
         bu yuzden TEK BASINA yeterlidir (Z7 yanlis pozitifinin kaynagi bu
         degildi, `.forge` SAYIMIYDI).
      C) 10+ adet `DataPC_*.forge` (eski esik 3'tu; Z7 yanlis pozitifi).

    Z7 (OLCULDU): eski kural "3 adet .forge" idi ve Z4 duzeltmesiyle birlikte
    TUM ust klasorlere uygulaniyordu; 3 yedek biriktiren bir kullanici klasoru
    ve BUTUN ALT AGACI yazilamaz hale geliyordu.
    """
    kucuk = set(x.lower() for x in icerik)
    forge = sorted(x for x in icerik if _OYUN_FORGE_DESENI.match(x))
    if all(x in kucuk for x in OYUN_IMZA_CIFTI):
        return ("vanilla oyun imzasi: DataPC_boot.forge ve "
                "DataPC_boot_patch_01.forge yan yana duruyor")
    for exe in OYUN_EXELERI:
        if exe in kucuk:
            return ("oyunun calistirilabiliri var: %s%s"
                    % (exe, (" (+%d adet DataPC_*.forge)" % len(forge))
                       if forge else ""))
    if len(forge) >= OYUN_FORGE_ESIGI:
        return ("%d adet DataPC_*.forge var (>=%d): %s ..."
                % (len(forge), OYUN_FORGE_ESIGI, ", ".join(forge[:4])))
    return None


def oyun_klasoru_mu(dizin):
    r"""ICERIGE bakan oyun kurulumu kontrolu (B4'un kalan acigi).

    Ad ne olursa olsun (D:\\Oyunlar\\AC4, C:\\PROGRA~2\\Ubisoft\\ACIV,
    C:\\Epic Games\\..., E:\\ACBFR\\...) klasor `oyun_imzasi()` tasiyorsa
    orasi bir OYUN kurulumudur.

    Z4 (OLCULDU): eskiden yalnizca hedef klasor + BIR ust klasor taraniyordu;
    `<oyun>\\mods\\birlesik\\` (iki kademe) ve `<oyun>\\yeni\\alt\\` (henuz
    olmayan iki kademe) rc=0 ile GECTI ve dosya oraya yazildi. Artik hedefin
    TUM ust klasorleri surucu kokune kadar taranir.

    Z7 (OLCULDU): ama olcut GUCLU IMZAYA baglandi - yoksa `.forge` biriktiren
    her kullanici klasoru ve butun alt agaci yazilamaz oluyordu.

    Kanonik yol kullanilir (junction / 8.3 / `\\?\` / UNC yazimlari da yakalanir).
    Doner: gerekce metni ya da None.
    """
    dizin = onek_soy(kanonik_yol(dizin))
    aday = dizin
    gorulen = set()
    while aday and aday not in gorulen:
        gorulen.add(aday)
        if os.path.isdir(aday):
            try:
                icerik = os.listdir(aday)
            except OSError:
                icerik = []
            imza = oyun_imzasi(icerik)
            if imza:
                etiket = ("hedef klasor" if aday == dizin
                          else "ust klasor (%s)" % aday)
                return "%s KURULU BIR OYUN KLASORU: %s" % (etiket, imza)
        ust = os.path.dirname(aday)
        if ust == aday:
            break
        aday = ust
    return None


# ------------------------------------------------------- Y1b REFERANS KALIP
_REFERANS_KALIP_ONBELLEK = []


def referans_kalip(yollar=None):
    """Y1b - BAGISCIDAN BAGIMSIZ 1050B referans kalip. Doner: (baytlar, kaynak).

    Kaynaklar SIRAYLA denenir ve hepsi SALT OKUNUR acilir ("rb"); oyun
    dosyasina hicbir kosulda YAZILMAZ, yalnizca ilk 1050 bayti okunur:
      1) oyunun vanilla DataPC_boot_patch_01.forge dosyasi,
      2) kanitli bagisci sablonu (SABLON_JACK),
      3) hicbiri yoksa (None, None) - o zaman yalnizca gomulu
         REFERANS_KALIP_SHA256 ile karsilastirilir.
    Bulunan kalip ayrica gomulu sha256 ile dogrulanir; tutmuyorsa
    "REFERANSIN KENDISI SUPHELI" durumu ayrica bildirilir.
    """
    if _REFERANS_KALIP_ONBELLEK and yollar is None:
        return _REFERANS_KALIP_ONBELLEK[0]
    sonuc = (None, None)
    for y in (yollar or REFERANS_KALIP_YOLLARI):
        try:
            if not os.path.isfile(y):
                continue
            with open(y, "rb") as f:          # SADECE OKUMA
                d = f.read(BASLIK_OFF)
            if len(d) == BASLIK_OFF:
                sonuc = (d, y)
                break
        except OSError:
            continue
    if yollar is None:
        _REFERANS_KALIP_ONBELLEK.append(sonuc)
    return sonuc


def kalip_referans_kontrolu(kalip):
    """Verilen 1050B kalibi BAGIMSIZ referansa karsi olc (Y1b).

    REDDETMEZ - bazi modlar mesru sekilde farkli olabilir; yalnizca RAPORLAR.
    Doner: None (fark yok / olculemedi) ya da uyari metni.
    """
    if not kalip or len(kalip) < BASLIK_OFF:
        return None
    k = bytes(kalip[:BASLIK_OFF])
    h = hashlib.sha256(k).hexdigest()
    if h == REFERANS_KALIP_SHA256:
        return None
    ref, kaynak = referans_kalip()
    if ref is None:
        return ("UYARI (REFERANS KALIP): birlesimin 1050B kalibi gomulu kanitli "
                "referanstan FARKLI (sha256 %s... != %s...). Referans dosya "
                "bulunamadigi icin hangi baytlarin farkli oldugu olculemedi. "
                "Bu bir RED degildir - bazi modlar mesru sekilde farkli kalip "
                "tasiyabilir - ama oyunda test edin."
                % (h[:12], REFERANS_KALIP_SHA256[:12]))
    fark = [i for i in range(BASLIK_OFF) if k[i] != ref[i]]
    ref_h = hashlib.sha256(ref).hexdigest()
    ek = ""
    if ref_h != REFERANS_KALIP_SHA256:
        ek = (" [DIKKAT: referans dosyanin kendisi de gomulu sha256'dan farkli "
              "(%s...) - referans kaynagi supheli]" % ref_h[:12])
    return ("UYARI (REFERANS KALIP): birlesimin 1050B kalibi BAGIMSIZ referanstan "
            "%d bayt farkli (ilk: %s). Referans: %s. Kalip bagisci moddan gelir; "
            "bagiscinin KENDI kalibi kirliyse geri_dogrula bunu goremez (kendisiyle "
            "karsilastirir). Bu bir RED degildir - ama oyunda test edin.%s"
            % (len(fark), ", ".join(str(x) for x in fark[:6]), kaynak, ek))


# ------------------------------------------------- Z8: `-o` GIRDI DOGRULAMASI
# Z8 (OLCULDU): 14 kotu `-o` girdisinin 6'si HAM PYTHON TRACEBACK ile bitiyordu
# (`-o NUL`, `-o CON`, `-o C:`, gecersiz karakter, VAR OLAN KLASOR, olmayan UNC).
# Traceback kullaniciya "arac bozuk" dedirtiyor. Artik yol YAZILMADAN ONCE
# dogrulanir ve net bir mesajla reddedilir.
_AYRILMIS_ADLAR = frozenset(
    ["con", "prn", "aux", "nul", "conin$", "conout$"]
    + ["com%d" % i for i in range(1, 10)]
    + ["lpt%d" % i for i in range(1, 10)])
_GECERSIZ_KARAKTERLER = '<>"|?*'


def cikti_yolu_gecerli_mi(ham, cikti=None):
    """`-o` yolunu YAZMADAN ONCE dogrula (Z8). Doner: hata metni ya da None.

    `ham`   : kullanicinin verdigi metin (kanoniklestirilmeden onceki hali)
    `cikti` : kanonik_yol() sonucu (verilmezse hesaplanir)
    """
    if ham is None or not str(ham).strip():
        return "-o bos verilemez: bir dosya yolu gerekiyor."
    ham = str(ham)
    if cikti is None:
        cikti = kanonik_yol(ham)
    duz = onek_soy(cikti)

    # (1) ciplak surucu harfi:  -o C:   /  -o C:\   /  -o \\srv\pay
    kok, kalan = os.path.splitdrive(onek_soy(ham))
    if not kalan.strip("\\/"):
        return ("-o yalnizca bir SURUCU/PAY kokunu gosteriyor (%r): dosya adi yok. "
                "Ornek: -o %s%sBirlesik%s%s"
                % (ham, kok or "C:", os.sep, os.sep, MOD_DOSYA_ADI))

    # (2) ayrilmis aygit adlari (NUL, CON, COM1 ...) - Windows bunlari dosya
    #     saymaz; `open()` ya da `os.replace()` icinde patlarlar.
    taban = os.path.basename(duz.rstrip("\\/"))
    if taban.split(".")[0].lower() in _AYRILMIS_ADLAR:
        return ("-o Windows'un AYRILMIS AYGIT ADINI gosteriyor (%r). Bunlar dosya "
                "degildir, uzerine yazilamaz. Baska bir dosya adi verin." % taban)
    if duz.startswith("\\\\.\\") or duz.startswith("\\\\?\\GLOBALROOT"):
        return ("-o bir AYGIT yolunu gosteriyor (%s). Bu arac yalnizca dosya "
                "yazar." % duz)

    # (3) Windows'ta dosya adinda bulunamayacak karakterler
    _, ad_kismi = os.path.splitdrive(onek_soy(ham))
    kotu = sorted(set(c for c in ad_kismi if c in _GECERSIZ_KARAKTERLER
                      or ord(c) < 32))
    if kotu:
        return ("-o yolunda Windows'ta gecersiz karakter(ler) var: %s"
                % " ".join(repr(c) for c in kotu))

    # (4) hedef VAR OLAN BIR KLASOR - os.replace burada PermissionError atardi
    try:
        if os.path.isdir(duz):
            return ("-o VAR OLAN BIR KLASORU gosteriyor (%s). Klasorun uzerine "
                    "dosya yazilamaz; yolun sonuna dosya adini ekleyin "
                    "(or. %s%s%s)." % (duz, duz, os.sep, MOD_DOSYA_ADI))
    except (OSError, ValueError):
        pass

    # (5) ust klasorun kok'u erisilebilir mi (olmayan UNC pay / olmayan surucu)
    ust = os.path.dirname(duz)
    surucu, _ = os.path.splitdrive(ust)
    if surucu and not os.path.exists(surucu + os.sep):
        return ("-o erisilemeyen bir konumu gosteriyor: %s bulunamadi "
                "(olmayan surucu ya da ag payi)." % surucu)
    return None


def cikti_yolu_reddi(cikti):
    """Cikti yolu bir OYUN kurulumunu hedefliyor mu. Doner: gerekce ya da None.

    Iki olcut birlikte: (1) ad kara listesi, (2) ICERIK kontrolu.
    """
    desen = oyun_yolu_mu(cikti)
    if desen:
        return "yol adinda %r geciyor" % desen
    return oyun_klasoru_mu(os.path.dirname(os.path.abspath(cikti)))


def son_kapi_ihlali(cikti, kaynak_shalari):
    r"""Z1 (d) SON KAPI: hedefte duran dosya bir KAYNAK MODUN ta kendisi mi.

    Yol yazimindan (8.3 / `\\?\` / junction / UNC) TAMAMEN bagimsiz calisir:
    yalnizca hedefteki baytlara bakar. Doner: eslesen sha256 ya da None.
    """
    if not kaynak_shalari:
        return None
    c = onek_soy(cikti)
    if not os.path.isfile(c):
        return None
    try:
        h = dosya_sha256(c)
    except OSError:
        return None
    return h if h in set(kaynak_shalari) else None


def yaz(sonuc, cikti, oyun_korumasi=True, defter=None, yan_dosya=True,
        kaynaklar=None, kaynak_shalari=None):
    """Sonuc'u forge dosyasi olarak yaz, sonra KENDI YAZDIGINI geri okuyup dogrula.

    ONCE <cikti>.tmp'ye yazilir, geri okunup dogrulanir, ancak BASARILIYSA
    os.replace ile yerine konur. Dogrulama kalirsa .tmp SILINIR - diskte bozuk
    dosya birakilmaz (eski surum once cikti'yi yazip sonra reddediyordu).

    oyun_korumasi=True iken kurulu oyunu hedefleyen yollar REDDEDILIR (ValueError).
    Kontrol hem AD kara listesine hem KLASOR ICERIGINE bakar (B4).

    Yazim basariliysa KIMLIK kaydedilir: <cikti>.acmb yan dosyasi + kalici
    defter. Taramada bu kimlik tasiyan dosyalar atlanir (B1 kok cozumu).

    Doner: dict(boyut, sha256, giris, dolgu, dogrulama=[(ok, mesaj)], yazildi,
                kaldi, kimlik, defter_yolu)
    """
    if oyun_korumasi:
        gerekce = cikti_yolu_reddi(cikti)
        if gerekce:
            raise ValueError(
                "cikti yolu kurulu bir oyunu hedefliyor gorunuyor (%s; yol: %s). "
                "Bu arac oyun dosyasi YAZMAZ. Once bir DENEME klasorune uretin, "
                "dogrulandiktan sonra ELLE kopyalayin."
                % (gerekce, os.path.abspath(cikti)))

    # --- Z1 (d) SON KAPI - yazmadan ONCE (yol yazimindan bagimsiz)
    carpan = son_kapi_ihlali(cikti, kaynak_shalari)
    if carpan:
        raise ValueError(
            "SON KAPI: cikti yolunda ZATEN DURAN dosya taranan kaynak "
            "modlardan birinin TA KENDISI (sha256 %s...). Yazilsaydi o mod "
            "geri donusu olmadan yok olurdu. yol: %s"
            % (carpan[:16], os.path.abspath(onek_soy(cikti))))

    gv = bytearray()
    kayit = []
    pos = GIRIS_BASI
    for fid, ham, ext in sonuc.girisler:
        kayit.append((pos, fid, len(ham), ext))
        gv += ham
        pos += len(ham)

    f = bytearray(sonuc.kalip)
    f += struct.pack("<I", len(kayit)) + struct.pack("<q", pos) + b"\xff" * 8
    f += gv
    for off, fid, ln, ext in kayit:
        f += struct.pack("<QQII", off, fid, ln, ext)
    dolgu = (-len(f)) % HIZALAMA
    f += b"\x00" * dolgu

    d = os.path.dirname(os.path.abspath(cikti))
    if d:
        os.makedirs(d, exist_ok=True)

    # --- Z9 (OLCULDU): `.tmp` temizligi eskiden yalnizca DOGRULAMA kolundaydi;
    # `os.replace` ya da `open` KENDISI patlarsa 41 MB'lik oksuz bir `.tmp`
    # diskte kaliyordu (olculdu: `-o C:` -> `...\MOD_BIRLESTIRICI.tmp`
    # 41.467.904 B). Artik butun blok try/finally icinde: `yerine_kondu`
    # isaretlenmedikce `.tmp` HER KOSULDA silinir.
    gecici = cikti + ".tmp"
    yerine_kondu = False
    kimlik = None
    dyol = defter_yolu(defter)
    try:
        # --- 1) GECICI dosyaya yaz (hedef dosyaya HENUZ dokunulmadi)
        with open(gecici, "wb") as fh:
            fh.write(f)
            fh.flush()
            os.fsync(fh.fileno())

        # --- 2) GERI OKU VE DOGRULA (bagimsiz yol: dosyadan yeniden parse)
        kontrol = geri_dogrula(gecici,
                               beklenen={fid: ham for fid, ham, _ in sonuc.girisler},
                               kalip=sonuc.kalip)
        kaldi = sum(0 if ok else 1 for ok, _ in kontrol)

        # --- 3) ancak TEMIZSE yerine koy
        if kaldi:
            yazildi = False
        else:
            # --- Z1 (d) SON KAPI - os.replace'in HEMEN oncesinde bir kez daha
            carpan = son_kapi_ihlali(cikti, kaynak_shalari)
            if carpan:
                raise ValueError(
                    "SON KAPI (yazim aninda): hedefte duran dosya bir kaynak modun "
                    "kendisi (sha256 %s...). Yazim IPTAL edildi, .tmp silindi."
                    % carpan[:16])
            os.replace(gecici, cikti)
            yerine_kondu = True
            yazildi = True
            # --- 4) KIMLIK: yan dosya + kalici defter (B1 kok cozumu)
            kimlik = kimlik_kaydi(
                os.path.abspath(cikti),
                sha256=hashlib.sha256(bytes(f)).hexdigest(),
                boyut=len(f),
                parmak=parmak_izi([(fid, len(ham))
                                   for fid, ham, _ in sonuc.girisler]),
                giris=len(kayit),
                kaynaklar=list(kaynaklar or sonuc.kullanilan))
            if yan_dosya:
                yan_dosya_yaz(cikti, kimlik)
            defter_ekle(kimlik, dyol)
    finally:
        if not yerine_kondu:
            try:
                if os.path.isfile(onek_soy(gecici)):
                    os.remove(onek_soy(gecici))   # SADECE kendi yazdigimiz .tmp
            except OSError:
                pass

    return dict(boyut=len(f), dolgu=dolgu, giris=len(kayit),
                sha256=hashlib.sha256(bytes(f)).hexdigest(), dogrulama=kontrol,
                yazildi=yazildi, kaldi=kaldi, kimlik=kimlik, defter_yolu=dyol)


def geri_dogrula(yol, beklenen=None, kalip=None):
    """Yazilan forge'u SIFIRDAN parse et. Doner: [(basarili_mi, mesaj)]."""
    out = []

    def ck(ad, kosul, ek=""):
        out.append((bool(kosul), "%s %s" % (ad, ek)))

    m = mod_oku(yol, ad="CIKTI")
    dogrula(m)
    ck("dosya parse edildi", not m.olumcul_mu,
       "" if not m.olumcul_mu else "(%s)" % [h.kod for h in m.hatalar if h.seviye == OLUMCUL])
    if m.olumcul_mu:
        return out

    with open(yol, "rb") as f:
        d = f.read()
    ck("magic scimitar", d[:9] == MAGIC)
    ck("surum 50", _u32(d, 9) == SURUM)
    ck("basligOff 1050", _i64(d, 13) == BASLIK_OFF)
    ck("8xFF dolgu", d[1062:1070] == b"\xff" * 8)
    # Y1 (olculdu): eskiden kalibin yalnizca [0..20] araligi ile 1062'deki FF
    # dolgusu olculuyordu; [21..1049] HIC kontrol edilmiyordu. Kalibi bozuk bir
    # mod (surum bayti disinda) sessizce gecip cikti "16/16 OK" diyordu.
    if kalip is not None and len(kalip) >= BASLIK_OFF:
        fark = [i for i in range(21, BASLIK_OFF) if d[i] != kalip[i]]
        ck("1050B kalip [21..1049] kaynagiyla BIREBIR", not fark,
           "" if not fark else "(%d bayt farkli, ilk: %s)" % (len(fark), fark[:6]))

    sirali = sorted(m.girisler, key=lambda g: g.off)
    artan = all(sirali[i].off < sirali[i + 1].off for i in range(len(sirali) - 1))
    ck("ofsetler artan", artan)
    bitisik = True
    bek = GIRIS_BASI
    for g in sirali:
        if g.off != bek:
            bitisik = False
        bek = g.off + g.ln
    ck("girisler bitisik (bosluk/ortusme yok)", bitisik)
    ck("veri sonu == tocOff", bek == m.toc_off, "(%d / %d)" % (bek, m.toc_off))
    ck("TOC dosyaya sigiyor", m.toc_off + len(m.girisler) * TOC_SATIR <= len(d))
    ck("kuyruk dolgusu sifir", set(d[m.toc_off + len(m.girisler) * TOC_SATIR:]) <= {0},
       "(%d B)" % m.kuyruk_dolgu)
    ck("4096 hizali", len(d) % HIZALAMA == 0, "(%d)" % len(d))

    idler = [g.fid for g in m.girisler]
    ck("TOC'ta tekrar eden id yok", len(idler) == len(set(idler)))
    ck("5 sistem girisi tam", set(idler) & SISTEM_KUME == set(SISTEM_IDLER),
       "(%s)" % ", ".join("0x%X" % x for x in sorted(set(idler) & SISTEM_KUME)))

    bms_ok = 0
    bms_hata = []
    for g in m.girisler:
        if g.ham[:8] != BMS:
            continue
        try:
            son, _ = bms_tara(g.ham)
            if son == g.ln:
                bms_ok += 1
            else:
                bms_hata.append("0x%012X artik %d B" % (g.fid, g.ln - son))
        except ValueError as e:
            bms_hata.append("0x%012X %s" % (g.fid, e))
    ck("BMS konteynerleri saglam", not bms_hata, "(%d giris tarandi)" % bms_ok)

    if beklenen:
        kayip = [f for f in beklenen if f not in set(idler)]
        ck("beklenen tum girisler ciktida", not kayip,
           "" if not kayip else "(kayip: %s)" % ["0x%012X" % f for f in kayip])
        bozuk = [f for f in beklenen
                 if f in set(idler) and
                 next(g for g in m.girisler if g.fid == f).ham != beklenen[f]]
        ck("giris govdeleri BAYT BIREBIR korundu", not bozuk,
           "" if not bozuk else "(bozuk: %s)" % ["0x%012X" % f for f in bozuk])
    return out


# ---------------------------------------------------------------- KIMLIK
def parmak_izi(fid_len_ciftleri):
    """Icerik parmak izi: (fid, uzunluk) ciftlerinin sirali sha256'si.

    sha256'dan farki: dosya yeniden dolgulansa / hizalansa da AYNI kalir.
    Defterdeki kayitla eslesirse dosya bizim eski ciktimizdir.
    """
    h = hashlib.sha256()
    for fid, ln in sorted(fid_len_ciftleri):
        h.update(b"%016x:%d;" % (fid, ln))
    return h.hexdigest()


def dosya_parmak_izi(yol):
    """Forge'un TOC'unu SEEK ile okuyup parmak izini cikar (govde okunmaz).

    34 MB'lik modda bile birkac KB okur. Parse edilemezse None.
    """
    try:
        boy = os.path.getsize(yol)
        with open(yol, "rb") as f:                  # SADECE OKUMA
            bas = f.read(GIRIS_BASI)
            if len(bas) < GIRIS_BASI or bas[:9] != MAGIC:
                return None
            if _i64(bas, 13) != BASLIK_OFF:
                return None
            cnt = _u32(bas, BASLIK_OFF)
            toc = _i64(bas, BASLIK_OFF + 4)
            if cnt <= 0 or cnt > 100000 or not (0 < toc <= boy) \
                    or toc + cnt * TOC_SATIR > boy:
                return None
            f.seek(toc)
            ham = f.read(cnt * TOC_SATIR)
        ciftler = []
        for i in range(cnt):
            _off, fid, ln, _ext = struct.unpack_from("<QQII", ham, i * TOC_SATIR)
            ciftler.append((fid, ln))
        return parmak_izi(ciftler)
    except (OSError, struct.error):
        return None


def dosya_sha256(yol, blok=1 << 20):
    h = hashlib.sha256()
    with open(yol, "rb") as f:                      # SADECE OKUMA
        for p in iter(lambda: f.read(blok), b""):
            h.update(p)
    return h.hexdigest()


def kimlik_kaydi(cikti, sha256, boyut, parmak, giris, kaynaklar):
    return {
        "arac": ARAC_ADI,
        "surum": ARAC_SURUM,
        "tarih": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "cikti": cikti,
        "sha256": sha256,
        "boyut": boyut,
        "parmak": parmak,
        "giris": giris,
        "kaynak_mod_sayisi": len(kaynaklar),
        "kaynaklar": list(kaynaklar),
    }


def yan_dosya_yolu(forge):
    return os.path.abspath(forge) + YAN_DOSYA_UZANTI


def yan_dosya_yaz(forge, kimlik):
    """Ciktinin yanina JSON kimlik karti birak. Basarisiz olursa sessiz gecer."""
    try:
        with open(yan_dosya_yolu(forge), "w", encoding="utf-8") as f:
            json.dump(kimlik, f, ensure_ascii=False, indent=1)
        return True
    except OSError:
        return False


def yan_dosya_oku(forge):
    y = yan_dosya_yolu(forge)
    if not os.path.isfile(y):
        return None
    try:
        with open(y, "r", encoding="utf-8") as f:
            k = json.load(f)
        return k if isinstance(k, dict) and k.get("arac") == ARAC_ADI else None
    except (OSError, ValueError):
        return None


def defter_yolu(ozel=None):
    """Kalici defterin yolu. Oncelik: parametre > ACMB_DEFTER > LOCALAPPDATA."""
    if ozel:
        return os.path.abspath(ozel)
    env = os.environ.get(DEFTER_ENV)
    if env:
        return os.path.abspath(env)
    kok = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(kok, ARAC_ADI, "uretilenler.json")


def defter_oku(yol=None):
    y = defter_yolu(yol)
    if not os.path.isfile(y):
        return []
    try:
        with open(y, "r", encoding="utf-8") as f:
            d = json.load(f)
        k = d.get("kayitlar") if isinstance(d, dict) else d
        return [x for x in (k or []) if isinstance(x, dict)]
    except (OSError, ValueError):
        return []


def defter_ekle(kimlik, yol=None):
    """Deftere kayit ekle. Yazilamazsa sessizce gecer (yan dosya yedek kalir)."""
    y = defter_yolu(yol)
    kayitlar = defter_oku(y)
    kayitlar = [k for k in kayitlar if k.get("sha256") != kimlik["sha256"]]
    kayitlar.append(kimlik)
    kayitlar = kayitlar[-DEFTER_SINIR:]
    try:
        d = os.path.dirname(y)
        if d:
            os.makedirs(d, exist_ok=True)
        gec = y + ".tmp"
        with open(gec, "w", encoding="utf-8") as f:
            json.dump({"arac": ARAC_ADI, "surum": ARAC_SURUM, "kayitlar": kayitlar},
                      f, ensure_ascii=False, indent=1)
        os.replace(gec, y)
        return True
    except OSError:
        return False


class KimlikSuzgeci(object):
    """Bir dosya BIZIM eski ciktimiz mi? (ad'dan TAMAMEN bagimsiz)

    OLCUM NOTU - parmak izi neden ATLAMA olcutu DEGIL:
    Jack v30 + Kamzik_CJ birlestirildiginde Kamzik cakismalarin hepsini
    kaybediyor ve ciktinin (fid, uzunluk) kumesi Jack v30'unkiyle BIREBIR ayni
    cikiyor. Parmak izi atlama olcutu yapilinca arac, bir sonraki kosumda
    GERCEK Jack v30 modunu "kendi ciktim" sanip eledi (T8/B4'te olculdu, rc=2).
    Bu yuzden atlama yalnizca sha256 (bayt birebir) ve .acmb yan dosyasi ile
    yapilir; parmak izi kayitta tutulur ve yalnizca SUPHE olarak raporlanir.
    """

    def __init__(self, defter=None):
        self.kayitlar = defter_oku(defter)
        self.shalar = set(k.get("sha256") for k in self.kayitlar if k.get("sha256"))
        self.parmaklar = set(k.get("parmak") for k in self.kayitlar if k.get("parmak"))
        self.boyutlar = set(k.get("boyut") for k in self.kayitlar if k.get("boyut"))

    def sebep(self, yol):
        """Doner: atlama sebebi metni ya da None."""
        k = yan_dosya_oku(yol)
        if k:
            try:
                boy = os.path.getsize(yol)
            except OSError:
                boy = None
            if k.get("boyut") == boy and k.get("sha256") == dosya_sha256(yol):
                return ("aracin KENDI CIKTISI - yanindaki %s kimlik karti dosyayla "
                        "eslesti (%s, %d kaynak mod)"
                        % (os.path.basename(yan_dosya_yolu(yol)),
                           k.get("tarih", "?"), k.get("kaynak_mod_sayisi", 0)))
        try:
            boy = os.path.getsize(yol)
        except OSError:
            return None
        if boy in self.boyutlar and dosya_sha256(yol) in self.shalar:
            return "aracin KENDI CIKTISI - sha256 kalici defterde kayitli"
        return None

    def suphe(self, yol):
        """Atlatmaz, yalnizca raporlanir: icerik parmak izi deftere uyuyor mu."""
        p = dosya_parmak_izi(yol)
        if p and p in self.parmaklar:
            return ("icerik parmak izi (giris kimlikleri + uzunluklari) daha once "
                    "urettigimiz bir ciktiyla ayni - baytlar farkli oldugu icin "
                    "birlesime ALINDI")
        return None


def onceki_birlesim_sez(modlar):
    """SUPERSET SEZGISI - defter ve yan dosya yoksa devreye giren 3. katman.

    Bir aday ancak SU UCU BIRDEN saglanirsa onceki birlesim sayilir:
      1) varlik giris kumesi baska EN AZ IKI adayin kumesini TAM KAPSIYOR
         (ve her birinden genis),
      2) kapsadigi modlardan EN AZ IKISI birbiriyle HIC KESISMIYOR
         (birlesim farkli modlari toplar; tek modun buyuk surumu degil),
      3) BES SISTEM GIRISININ HEPSI var (bizim ciktimizda her zaman vardir).
    Uc kosul, "buyuk bir mod kendi kucuk varyantlarini kapsiyor" turu yanlis
    alarmlari eler. Yine de sezgidir: --sezgiyi-kapat ile devre disi birakilir.
    Doner: [(mod, sebep)]
    """
    kume = {m.ad: set(g.fid for g in m.varlik_girisleri) for m in modlar}
    out = []
    for m in modlar:
        if not m.sistem_tam:
            continue                                  # 3) kosul
        benim = kume[m.ad]
        kapsanan = sorted(o.ad for o in modlar
                          if o.ad != m.ad and kume[o.ad] and kume[o.ad] < benim)
        if len(kapsanan) < 2:                         # 1) kosul
            continue
        ayrik = None
        for i in range(len(kapsanan)):
            for j in range(i + 1, len(kapsanan)):
                if not (kume[kapsanan[i]] & kume[kapsanan[j]]):
                    ayrik = (kapsanan[i], kapsanan[j])
                    break
            if ayrik:
                break
        if not ayrik:                                 # 2) kosul
            continue
        out.append((m, "girisleri %d ayri modun girislerini birden kapsiyor (%s); "
                       "bunlardan %s ile %s hic kesismiyor ve 5 sistem girisi de "
                       "var -> onceki bir BIRLESIM olabilir"
                    % (len(kapsanan), ", ".join(kapsanan[:4]), ayrik[0], ayrik[1])))
    return out


def kapsama_uyarilari(modlar, elenen_adlar=()):
    """Z2 - superset sezgisi SUSTUGUNDA bile yuksek sesle uyar.

    Sezgi "en az IKI mod kapsanmali" kosuluna bagli. Kapsanan modlardan biri
    kokte yoksa sezgi susuyor ve --kati YALAN soyluyordu: OLCULDU - "atlandi"
    denen Silah_skin_kilic'in 5/5 girisi ciktida BAYT BIREBIR duruyordu.
    Bu fonksiyon KAPSANAN >= 1 durumunda (eleme yapmadan) uyari uretir.
    Doner: [(mod, [kapsanan_adlar])]
    """
    kume = {m.ad: set(g.fid for g in m.varlik_girisleri) for m in modlar}
    elenen = set(elenen_adlar or ())
    out = []
    for m in modlar:
        if m.ad in elenen or not m.sistem_tam:
            continue
        benim = kume[m.ad]
        kapsanan = sorted(o.ad for o in modlar
                          if o.ad != m.ad and o.ad not in elenen
                          and kume[o.ad] and kume[o.ad] < benim)
        if kapsanan:
            out.append((m, kapsanan))
    return out


def kati_sizinti_olc(cikti_yolu, atlanan_modlar):
    """Z2 - `--kati` ile "atlandi" denen modlarin girisleri CIKTIDA MI.

    Sezgiden bagimsiz, tamamen OLCUME dayali emniyet: fid kumesi kesisimi +
    govde BAYT karsilastirmasi. Doner: [(mod_adi, [fid], toplam_giris)]
    """
    if not atlanan_modlar or not os.path.isfile(onek_soy(cikti_yolu)):
        return []
    c = mod_oku(onek_soy(cikti_yolu), ad="CIKTI")
    if c.olumcul_mu:
        return []
    cm = {g.fid: g.ham for g in c.girisler}
    out = []
    for m in atlanan_modlar:
        var = [g.fid for g in m.varlik_girisleri if cm.get(g.fid) == g.ham]
        if var:
            out.append((m.ad, var, len(m.varlik_girisleri)))
    return out


# ---------------------------------------------------------------- TARAMA
def cikti_klasoru_mu(ad):
    """Klasor adi aracin varsayilan cikti klasoru mu.

    Y5 (olculdu): ONEK eslemesi `_BIRLESIKMODUM` / `_Birlesik_Jack_modu` gibi
    GERCEK kullanici modlarini da yutuyordu. Artik TAM AD esitligi.
    Bu yalnizca ucuz bir yardimci filtredir; asil koruma KimlikSuzgeci'dir.
    """
    return bool(_CIKTI_KLASOR_DESENI.match(ad or ""))


def _atla_kumesi(yollar):
    r"""Z1: normcase(abspath) yerine gercek_yol - junction/8.3/`\\?\` dayanikli."""
    out = set()
    for y in (yollar or ()):
        if y:
            out.add(gercek_yol(y))
    return out


def klasor_tara(kok, dosya_adi=MOD_DOSYA_ADI, atla=None, atlananlar=None,
                suzgec=None):
    """Kok altindaki her alt klasorde <dosya_adi> ara. Doner: [(ad, yol)].

    GERI-BESLEME KORUMASI - B1 KOK COZUMU. Ad tabanli koruma OLCULDU ve
    YETMEDI (cikti1 -> cikti2 -> BIRLESIK_YENI ard arda kosumlarinda arac kendi
    ciktisini 6./7./8. mod sandi, --kati ise yaramadi, rapor yalan soyledi).
    Artik asil olcut KIMLIK: `suzgec` verilirse her aday dosya defter ve
    yan-dosya kimligine karsi sinanir; kimlik tasiyan dosya ADI NE OLURSA OLSUN
    atlanir.

    atla       : atlanacak klasor yollari (or. bu kosumun cikti klasoru)
    atlananlar : verilirse atlanan (ad, sebep) ciftleri buraya eklenir
    suzgec     : KimlikSuzgeci (None ise yalnizca ad/atla filtresi calisir)
    """
    bulunan = []
    kok = os.path.abspath(kok)
    atla_n = _atla_kumesi(atla)

    def _kaydet(ad, sebep):
        if atlananlar is not None:
            atlananlar.append((ad, sebep))

    def _klasor_atla(tam_yol, ad):
        if cikti_klasoru_mu(ad):
            return "adi aracin varsayilan cikti klasoru (%s)" % ad
        if gercek_yol(tam_yol) in atla_n:
            return "bu kosumun cikti klasoru - tarama disi"
        return None

    def _dosya_atla(yol):
        return suzgec.sebep(yol) if suzgec is not None else None

    dogrudan = os.path.join(kok, dosya_adi)
    if os.path.isfile(dogrudan):
        sebep = _klasor_atla(kok, os.path.basename(kok)) or _dosya_atla(dogrudan)
        if sebep:
            _kaydet(".", sebep)
        else:
            bulunan.append((os.path.basename(kok), dogrudan))

    for kokdiz, dizinler, dosyalar in os.walk(kok):
        dizinler.sort()
        kalan = []
        for d in dizinler:
            tam = os.path.join(kokdiz, d)
            sebep = _klasor_atla(tam, d)
            if sebep:
                if os.path.isfile(os.path.join(tam, dosya_adi)):
                    _kaydet(os.path.relpath(tam, kok).replace("\\", "/"), sebep)
                continue
            kalan.append(d)
        dizinler[:] = kalan                     # alt agaca hic inilmez
        if kokdiz == kok:
            continue
        if dosya_adi in dosyalar:
            rel = os.path.relpath(kokdiz, kok).replace("\\", "/")
            yol = os.path.join(kokdiz, dosya_adi)
            sebep = _dosya_atla(yol)
            if sebep:
                _kaydet(rel, sebep)
            else:
                bulunan.append((rel, yol))
    return bulunan


def cikti_ic_mi(kok, cikti):
    r"""Cikti dosyasi taranan kokun ICINDE mi (geri-besleme riski, rc=9).

    Z1: eskiden normcase(abspath(...)) METIN karsilastirmasiydi ve `\\?\`
    oneki bu korumayi da devre disi birakiyordu (olculdu: rc=9 beklenirken
    rc=0 ve kaynak mod uzerine yazildi). Artik ic_yol_mu() -> gercek_yol().
    """
    return ic_yol_mu(kok, cikti)


def kaynak_sha_kumesi(mod_yollari, boyut=None):
    """Taranan kaynak modlarin sha256 kumesi (SON KAPI icin).

    `boyut` verilirse yalnizca o boyuttaki dosyalar hash'lenir - 5 x 34 MB
    okumak yerine yalnizca aday olanlar okunur (sha esitligi boyut esitligini
    zaten gerektirir).
    """
    out = {}
    for yol in mod_yollari or ():
        y = onek_soy(yol)
        try:
            if boyut is not None and os.path.getsize(y) != boyut:
                continue
            out[dosya_sha256(y)] = yol
        except OSError:
            continue
    return out


def forge_imzali_mi(yol, en_az=GIRIS_BASI, en_cok=KORUMA_BOYUT_TAVANI):
    r"""K2 - dosya UZANTISINDAN BAGIMSIZ olarak forge yapisi tasiyor mu.

    K2 (OLCULDU, VERI KAYBI, rc=0, TEK BIR UYARI BILE YOK): kok icinde
    `hava_yedek.bin` adiyla duran GERCEK bir mod (4.096 B, sha e7133e2c...)
    41.467.904 B'a ezildi. Iki koruma da uzantiya bakiyordu:
    `korunacak_forge_tara()` yalnizca `.forge` topluyordu, `hedef_forge`
    uyarisi da `cikti.lower().endswith(".forge")` kosuluna bagliydi.
    Uzanti `.bin` / `.bak` / `.forge_yedek` olunca IKISI DE susuyordu.

    Burada dosyanin ilk 33 bayti okunur (tam okuma YOK):
      * `scimitar\0` magic,
      * basligOff == 1050 (TOC yapisinin sabit capasi),
      * girisSayisi ve tocOff dosya sinirlari icinde tutarli.
    Doner: True/False. Karar SADECE ICERIGE dayanir.
    """
    try:
        boy = os.path.getsize(onek_soy(yol))
    except OSError:
        return False
    if boy < en_az or (en_cok is not None and boy > en_cok):
        return False
    try:
        with open(onek_soy(yol), "rb") as f:
            bas = f.read(BASLIK_OFF + 20)
    except OSError:
        return False
    if len(bas) < BASLIK_OFF + 20 or bas[:9] != MAGIC:
        return False
    try:
        if _i64(bas, 13) != BASLIK_OFF:
            return False
        cnt = _u32(bas, BASLIK_OFF)
        toc = _i64(bas, BASLIK_OFF + 4)
    except struct.error:
        return False
    if cnt <= 0 or cnt > 100000:
        return False
    return 0 < toc <= boy and toc + cnt * TOC_SATIR <= boy


def korunacak_forge_tara(kok, dosya_adi=MOD_DOSYA_ADI, suzgec=None,
                         taranan=None, imza_ile=True):
    r"""Z10 / K1 / K2 - KOKTEKI HER MOD DOSYASI, adi ne olursa olsun, KORUMA'da.

    Z10 (OLCULDU, VERI KAYBI, rc=0): `mod_yollari` yalnizca taranan
    `DataPC_boot_patch_02.forge` dosyalarini iceriyordu. Kokte BASKA bir
    konteyneri hedefleyen bir mod (`DataPC_shared_00_patch_02.forge` = hava
    modu) `baska_forge_tara()` tarafindan BULUNUYOR ve raporda ADIYLA
    yaziliyordu, ama `ayni_dosya_mi` / SON KAPI sha kumesi onu KAPSAMIYORDU.

    K1 (OLCULDU, VERI KAYBI, rc=0 - 5. tur kabul denetimi): bu fonksiyon
    `dosya_adi` adli dosyalari "onlar zaten `mod_yollari`na giriyor" GEREKCESIYLE
    atliyordu. GIRMIYORLARDI: `klasor_tara()` `^_BIRLESIK\d*$` desenli
    klasorleri (ve tum alt agacini) ADINA bakip eliyor. Sonuc:
    `<kok>\_BIRLESIK\DataPC_boot_patch_02.forge` hicbir koruma katmaninda
    degildi -> 1.507.328 B (sha f2a3b2b7...) 41.467.904 B'a ezildi, rc=0.
    ARTIK VARSAYIM YOK: atlanacak dosyalar `klasor_tara()`nin GERCEK ciktisindan
    (`taranan`) DOSYA KIMLIGIYLE belirlenir. `taranan` verilmezse burada
    yeniden hesaplanir - yani bu fonksiyon tek basina da guvenlidir.
    ELEME (klasor adi / desen) yalnizca BIRLESIME girmeyi engeller, KORUMAYI DEGIL.

    K2: uzanti artik tek olcut degil. `.forge` uzantililar + `forge_imzali_mi()`
    dogrulayan HER dosya (uzantisi ne olursa olsun) korunur.

    Disarida kalan TEK sinif: ARACIN KENDI CIKTISI (`.acmb` yan dosyasi ya da
    kalici defter kimligi) - yoksa kullanici kendi onceki ciktisinin uzerine
    `--uzerine-yaz` ile yazamazdi (normal is akisi).

    taranan  : klasor_tara()nin dondurdugu [(ad, yol)] ya da [yol] listesi
    imza_ile : False ise yalnizca `.forge` uzantisina bakilir (birim testi icin)
    Doner: [tam_yol]
    """
    kok = os.path.abspath(kok)
    if taranan is None:
        taranan = klasor_tara(kok, dosya_adi, suzgec=suzgec)
    taranan_n = _atla_kumesi(
        [(y[1] if isinstance(y, (tuple, list)) else y) for y in (taranan or ())])
    # `gercek_yol()` dosya basina realpath cagirir; binlerce dosyali bir kokte
    # tek basina saniyeler suruyor (olculdu). Ad on-elemesi bunu kucuk `taranan`
    # kumesine indirger. Dosyanin KENDISI bir sembolik bag olup adi cozulunce
    # degisiyorsa eleme yapilmaz - o zaman dosya KORUNAN listeye de girer,
    # yani hata yonu her zaman FAZLA KORUMA tarafinadir.
    taranan_adlar = set(os.path.basename(y).lower() for y in taranan_n)
    out = []
    for kokdiz, dizinler, dosyalar in os.walk(kok):
        dizinler.sort()                        # ELEME YOK - koruma her yere bakar
        for d in sorted(dosyalar):
            yol = os.path.join(kokdiz, d)
            if d.lower().endswith(YAN_DOSYA_UZANTI):
                continue                       # kimlik karti, mod degil
            if not d.lower().endswith(".forge"):
                if not (imza_ile and forge_imzali_mi(yol)):
                    continue
            if d.lower() in taranan_adlar and gercek_yol(yol) in taranan_n:
                continue                       # zaten mod_yollari'nda (OLCULDU)
            if suzgec is not None and suzgec.sebep(yol):
                continue                       # aracin kendi eski ciktisi
            out.append(yol)
    return out


def korunacak_tum_tara(kok, taranan=None, suzgec=None,
                       en_az=1, en_cok=KORUMA_BOYUT_TAVANI):
    r"""K2 - SON KAPI (sha) icin: kokteki TUM dosyalar, uzanti farketmeksizin.

    `korunacak_forge_tara()` bir dosyayi ancak `.forge` uzantiliysa ya da
    forge IMZASI tasiyorsa alir. Bu liste ise makul boyut sinirindaki HER
    dosyayi alir ve YALNIZCA sha karsilastirma katmanina beslenir
    (`cikti_kaynak_catismasi(..., sha_ek_yollar=...)`): hedefte duran dosya
    kokteki herhangi bir dosyanin BAYT BIREBIR kopyasiysa yazim reddedilir.
    Yol kimligi katmanina bilerek girmez - kokteki her dosya adini yasakli
    hedef yapmak yanlis pozitif uretirdi.

    Hash maliyeti `kaynak_sha_kumesi(..., boyut=hedef_boyutu)` ile zaten
    hedefle AYNI BOYUTTAKI dosyalara iniyor; burada ek olarak boyut tavani var.
    """
    kok = os.path.abspath(kok)
    taranan_n = _atla_kumesi(
        [(y[1] if isinstance(y, (tuple, list)) else y) for y in (taranan or ())])
    taranan_adlar = set(os.path.basename(y).lower() for y in taranan_n)
    out = []
    for kokdiz, dizinler, dosyalar in os.walk(kok):
        dizinler.sort()
        # `suzgec.sebep()` dosya basina bir `.acmb` acma denemesi + sha256
        # yapiyor; kokte binlerce dosya varsa bu tek basina saniyeler suruyordu
        # (olculdu: 3000 dosyada 1,3 sn). `sebep()` yalnizca IKI durumda
        # None'dan farkli doner: (a) yaninda eslesen bir `.acmb` kimlik karti
        # var, (b) boyutu deftere kayitli bir ciktinin boyutuna esit. Ikisi de
        # burada SYSCALL'SIZ on-elenebilir; sonuc birebir ayni kalir.
        yanlar = set(x.lower() for x in dosyalar
                     if x.lower().endswith(YAN_DOSYA_UZANTI))
        boyutlar = getattr(suzgec, "boyutlar", None) or ()
        for d in sorted(dosyalar):
            yol = os.path.join(kokdiz, d)
            if d.lower().endswith(YAN_DOSYA_UZANTI):
                continue
            try:
                boy = os.path.getsize(onek_soy(yol))
            except OSError:
                continue
            if boy < en_az or (en_cok is not None and boy > en_cok):
                continue
            if d.lower() in taranan_adlar and gercek_yol(yol) in taranan_n:
                continue
            if suzgec is not None and (boy in boyutlar
                                       or (d + YAN_DOSYA_UZANTI).lower() in yanlar):
                if suzgec.sebep(yol):
                    continue                   # aracin kendi eski ciktisi
            out.append(yol)
    return out


def cikti_kaynak_catismasi(cikti, mod_yollari, sha_kapisi=True, ek_yollar=None,
                           sha_ek_yollar=None):
    r"""Y3 / Z1 - VERI KAYBI KORUMASI (bes katman).

    Cikti yolu taranan mod dosyalarindan BIRINE esitse ya da bir kaynak modun
    KLASORUNUN icindeyse, yazim o modu YOK EDER (olculdu: Jack v30 34.056.513 B
    -> 41.467.904 B / 1.482.752 B, EXIT=0 "basarili").

    Katmanlar:
      (a) realpath  -> junction / symlink / 8.3 cozulur
      (b) `\\?\` ve `\\?\UNC\` onekleri soyulur
      (c) VAR OLAN dosyalar icin os.path.samefile (dosya kimligi: st_dev+st_ino)
      (d) SON KAPI: hedef dosya zaten VARSA ve sha256'si taranan kaynak
          modlardan BIRINE ESITSE kosulsuz reddet - yol yazimindan TAMAMEN
          bagimsiz kesin kapi (UNC / farkli surucu gibi (c)'nin yetmedigi
          durumlari da kapatir)
    `ek_yollar` (Z10 / K1 / K2): kokte bulunan ama BIRLESIME GIRMEYEN mod
    dosyalari (bkz. korunacak_forge_tara) - baska konteyner yuvalari, elenen
    `_BIRLESIK*` klasorlerindeki dosyalar, uzantisi `.forge` olmayan ama forge
    imzasi tasiyanlar. Bunlar birlestirilmez ama KORUNUR: (c) dosya kimligi ve
    (d) SON KAPI sha katmanlarina girerler. `mod_klasoru` katmanina bilerek
    girmezler - bir yan konteyner modunun klasorune yazmak veri kaybi degildir,
    dosyanin UZERINE yazmak veri kaybidir.

    `sha_ek_yollar` (K2): YALNIZCA (d) SON KAPI'ya giren, uzantidan tamamen
    bagimsiz kok dosyalari (bkz. korunacak_tum_tara). Hedefte duran dosya
    bunlardan birinin bayt birebir kopyasiysa yazim reddedilir.

    Doner: (tur, mod_yolu) ya da (None, None).
       tur = "ayni_dosya"  -> cikti dogrudan kaynak modun dosyasi
       tur = "mod_klasoru" -> cikti kaynak modun klasorunun icinde
       tur = "ayni_icerik" -> hedefte duran dosya bir kaynak modun TA KENDISI
       tur = "baska_konteyner" -> cikti kokteki BASKA bir mod dosyasi
       tur = "kok_ici_dosya"   -> cikti taranan kokun icinde VAR OLAN, aracin
                                  kendi ciktisi olmayan herhangi bir dosya
    """
    for yol in mod_yollari:
        if ayni_dosya_mi(cikti, yol):
            return "ayni_dosya", yol
    for yol in (ek_yollar or ()):
        if ayni_dosya_mi(cikti, yol):
            return "baska_konteyner", yol
    for yol in (sha_ek_yollar or ()):
        if ayni_dosya_mi(cikti, yol):
            return "kok_ici_dosya", yol
    for yol in mod_yollari:
        if ic_yol_mu(os.path.dirname(onek_soy(os.path.abspath(yol))), cikti):
            return "mod_klasoru", yol
    if sha_kapisi:
        c = onek_soy(cikti)
        try:
            boy = os.path.getsize(c) if os.path.isfile(c) else None
        except OSError:
            boy = None
        if boy is not None:
            adaylar = kaynak_sha_kumesi(mod_yollari, boyut=boy)
            ek_adaylar = kaynak_sha_kumesi(ek_yollar, boyut=boy)
            # K2: uzantidan bagimsiz kok dosyalari - yalnizca bu katmanda
            sha_adaylar = kaynak_sha_kumesi(sha_ek_yollar, boyut=boy)
            if adaylar or ek_adaylar or sha_adaylar:
                h = dosya_sha256(c)
                if h in adaylar:
                    return "ayni_icerik", adaylar[h]
                if h in ek_adaylar:
                    return "baska_konteyner", ek_adaylar[h]
                if h in sha_adaylar:
                    return "kok_ici_dosya", sha_adaylar[h]
    return None, None


def baska_forge_tara(kok, dosya_adi=MOD_DOSYA_ADI, atla=None):
    """Kok altinda BASKA patch forge'lari var mi (or. DataPC_shared_00_patch_02).

    Bu arac yalnizca <dosya_adi> yuvasini birlestirir. Baska bir konteyneri
    hedefleyen mod (olculdu: 01_hava_surekli_firtina ->
    DataPC_shared_00_patch_02.forge) sessizce gozden kacmasin diye raporlanir.
    """
    out = []
    kok = os.path.abspath(kok)
    atla_n = _atla_kumesi(atla)
    for kokdiz, dizinler, dosyalar in os.walk(kok):
        dizinler.sort()
        dizinler[:] = [d for d in dizinler
                       if not cikti_klasoru_mu(d)
                       and gercek_yol(os.path.join(kokdiz, d)) not in atla_n]
        for d in sorted(dosyalar):
            if not d.lower().endswith(".forge"):
                continue
            if d == dosya_adi:
                continue
            if "_patch_" in d.lower():
                out.append((os.path.relpath(kokdiz, kok).replace("\\", "/"), d))
    return out


def adler(b):
    return zlib.adler32(b, 0) & 0xFFFFFFFF
