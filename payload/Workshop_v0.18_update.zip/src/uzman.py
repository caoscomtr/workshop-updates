# -*- coding: utf-8 -*-
"""uzman — EXPERT MODE anahtarinin TEK KAYNAGI.

NE ISE YARAR
------------
Workshop'un reddetme kapilari UC AYRI TURDENDIR; bu modul yalnizca UCUNCUSUNU acar:

  KAPASITE  Fiziksel olarak imkansiz. Arsivde ayrilmis yer sabittir, indeks tamponu
            16 bittir, bir primitifin materyal yuvasi tektir... Anahtar bunlari ACMAZ,
            acamaz: acsa uretilen baytlar zaten gecersiz olurdu.
  GUVENLIK  Veri kaybi / kurtarilamaz durum. Oyun acikken yazma, yedek butunlugu,
            ayni girise iki yazici, yazma sonrasi dogrulama, YAZMA_KILIDI. Anahtar
            bunlari ACMAZ (bkz. KAPALI_KALAN).
  POLITIKA  Teknik olarak yazilabilir ama OYUN ICI kanitlanmamis ya da sonucu
            surpriz olabilir. Bugun reddediliyor. Anahtar ACIKKEN bunlar YAZILIR ve
            her biri planda/raporda bir UYARI birakir.

KAPTANIN HEDEFI: "her seyi acalim ve sunalim... 'ben yaptim ama reddedildi' diye
gelmemeliler." Uzman modu bu cumlenin POLITIKA yarisidir. Kuratorlu sekmelerin
varsayilan davranisi DEGISMEZ: anahtar VARSAYILAN OLARAK KAPALIDIR.

DURUSTLUK
---------
Uyari kaybolmaz. Her acilan kapi `uyari()` ile bir cumle uretir; cumle UC parcadir:
    "Expert mode: <ne yapildi>. <en kotu senaryo>. Revert puts it back."
Cagiran modul bu cumleyi plan sozlugundeki `uzman_uyarilari` listesine koyar (ve
gorunurlugu bugunden garanti altina almak icin `notlar`a da). Sessiz gecen kapi YOK.

AYAR DOSYASI
------------
sunucu.py'nin kullandigi AYNI dosya: %LOCALAPPDATA%\\OutfitWorkshop\\ayarlar.json
(o dosyanin kendi okuma/yazma kodu var; bu modul KENDI okuma/yazmasini yapar ve
diger anahtarlari -- dil, guncelleme_url -- oku-degistir-yaz ile KORUR).
Sema:  {"uzman": false, "uzman_surum": "0.13", "uzman_zaman": "2026-09-07T..."}

Onbellek: dosyanin (mtime_ns, boyut) imzasi degismedikce JSON yeniden ayristirilmaz.
Imzaya bakildigi icin BASKA BIR SUREC (arayuz) anahtari cevirdiginde bu surec de
gorur -- "acik() bir kez okur ve donar" hatasi yok.

CAGRI SOZLESMESI (arayuz bunu cagirir)
--------------------------------------
    uzman.acik()              -> bool          anahtar acik mi
    uzman.ayarla(True/False)  -> dict          ayarlari yazar, YENI ayar sozlugunu doner
    uzman.kapi("join")        -> bool          O KAPI acik mi (bilinmeyen ad -> False)
    uzman.uyari("join", ...)  -> str           kullaniciya gidecek uyari (SECILI DILDE)
    uzman.dil()               -> str           arayuzde secili dil kodu ("en"/"es"/...)
    uzman.metin("ui.acik")    -> str           tek bir sabit metnin secili dildeki hali
    uzman.KAPILAR             -> tuple         acilabilen 12 politika kapisi
    uzman.KAPASITE            -> tuple         anahtarin ACMADIGI kapasite kapilari
    uzman.KAPALI_KALAN        -> tuple         anahtar acikken bile REDDEDEN guvenlik kapilari
    uzman.SABIT_METINLER      -> dict          TANIMLAYICI -> Ingilizce cumle (ceviri
                                               envanteri ANAHTARLARI toplar; nedeni
                                               "CEVIRI" bolumunun basindaki notta)
"""
import json
import os
import re
import tempfile
import time

__all__ = ["acik", "ayarla", "kapi", "uyari", "oku", "onbellegi_bosalt",
           "dil", "metin", "DIL_KODLARI",
           "KAPILAR", "KAPASITE", "KAPALI_KALAN", "SABIT_METINLER", "SURUM", "AYAR_DOSYA"]

SURUM = "0.13"


def _varsayilan_ayar_dosyasi():
    """sunucu.py'nin AYAR_DOSYA'siyla AYNI yol (o modulu ice aktarmadan)."""
    kok = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    return os.path.join(kok, "OutfitWorkshop", "ayarlar.json")


# Testler bu modul degiskenini dogrudan degistirebilir; alt surecler icin env de var.
AYAR_DOSYA = _varsayilan_ayar_dosyasi()
ENV_ANAHTAR = "OW_AYAR_DOSYA"


def _yol():
    return os.environ.get(ENV_ANAHTAR) or AYAR_DOSYA


# ------------------------------------------------------------------ KAPI KIMLIKLERI
# Acilabilen POLITIKA kapilari. Sira = envanterdeki C-numarasi.
KAPILAR = (
    "olcek_bandi",           # C1   mesh_yaz     skinned konum bandi asildi
    "olcek_yukselt",         # C2   mesh_yaz     rigid konum olcegi (w) buyutulecek
    "topoloji_hizalama",     # C3   mesh_ithal   ayni vertex sayisi, birebir hizalanamadi
    "join",                  # C4   mesh_ithal   Blender'da parca birlestirilmis
    "dogrulanmamis_klasor",  # C5   ship_ayar    oyun klasoru dogrulanmadi
    "materyal_eslesme",      # C6   mesh_ithal   materyal grubu eslesmedi
    "materyal_sayisi",       # C7   mesh_ithal   materyal grup SAYISI farkli
    "lod_bandi",             # C8   mesh_ithal   bir LOD bandi yazilamadi (tumu-ya-da-hic)
    "hedef_yok",             # C9   mesh_ithal   hedefte bu turden parca yok
    "dejenere_ucgen",        # C10  mesh_yaz     dejenere ucgen
    "bos_primitif",          # C11  mesh_yaz     primitif bosaltilamaz
    "sha_yama",              # C13  mesh_ithal   girise ZATEN bizim yamamiz kurulu
    "uzunluk_degisimi",      # C14  nesne_yaz/explorer_core  bayt uzunlugu degistiren duzenleme
)

# ANAHTARIN ACMADIGI kapasite kapilari. Burada olmak "unutuldu" demek DEGILDIR:
# yanindaki cumle NEDEN acilamayacaginin olculmus gerekcesidir.
KAPASITE = {
    "doku_boyutu": (                                                    # C12
        "doku_ithal G6: the archive reserves a FIXED byte length per mip. doku_enjekte2 "
        "writes mips in place and its own gate demands forge_len == len(dds_mip) exactly; "
        "a different image size produces a different encoded length, so the bytes do not "
        "fit at all. This is capacity, not policy - expert mode does not touch it."),
}

# UZMAN MODUNDA BILE ACIK KALAN GUVENLIK KAPILARI (bu modul bunlara HIC bakmaz).
KAPALI_KALAN = (
    "oyun_acikken_yazma",        # ACBlackFlag.exe calisiyor -> yazma yok
    "yedek_wal_butunlugu",       # geri-alma deposu / WAL bozuksa yazma yok
    "ayni_girise_iki_yazici",    # mesh + doku ayni arsiv girisini paylasamaz
    "zaten_susturulmus",         # "already muted"
    "yazma_sonrasi_dogrulama",   # kurulan baytlar geri okunup dogrulanir
    "yazma_kilidi",              # %LOCALAPPDATA%\ACBFR_Modding\YAZMA_KILIDI
)


# ------------------------------------------------------------------ UYARI METINLERI
# Cumle kalibi: "Expert mode: <ne yapildi>. <en kotu senaryo>. Revert puts it back."
# Duz Ingilizce, tam cumle. ANAHTAR = tanimlayici, DEGER = kullanicinin gordugu
# cumle. Ceviri envanteri buradan ANAHTARLARI toplar ve sozlukler de tanimlayiciyla
# anahtarlanir (gerekce: asagidaki "CEVIRI" bolumunun basindaki not).
GOVDE = "Expert mode: %s. %s. Revert puts it back."
GERI_AL = "Revert puts it back."

SABIT_METINLER = {
    "govde": GOVDE,
    "geri_al": GERI_AL,

    "ui.baslik": "Expert mode",
    "ui.aciklama": (
        "Expert mode lets the Workshop write in cases it normally refuses because the "
        "result has not been proven in the game. Nothing is skipped silently: every case "
        "it lets through is listed as a warning on the confirmation screen. Safety gates "
        "(game running, backup integrity, two writers on one archive entry, the write "
        "lock, post-write verification) stay closed either way."),
    "ui.kapali": "Expert mode is off. The Workshop refuses anything it cannot prove.",
    "ui.acik": "Expert mode is ON. Read the warnings on the confirmation screen before you apply.",

    "olcek_bandi.ne": (
        "the edited shape left this mesh's position band, so the position scale was raised "
        "from %(eski)g to %(yeni)g m instead of refusing the part"),
    "olcek_bandi.en_kotu": (
        "All 755 vanilla meshes store 'scale = ceil(max header box)', but no in-game test "
        "has ever confirmed that the engine reads the scale back from there, so this part "
        "can come out the wrong size, inside-out or invisible"),

    "olcek_yukselt.ne": (
        "this rigid mesh's position scale was raised from w=%(eski)d to w=%(yeni)d so the "
        "enlarged shape fits"),
    "olcek_yukselt.en_kotu": (
        "The scale really is stored per vertex in the file and our own reader reads it back, "
        "but the game has never been asked to draw a raised one, so this part can come out "
        "the wrong size or misplaced"),

    "topoloji_hizalama.ne": (
        "the edited part has the same vertex count as the export but the Workshop could not "
        "line the vertices up one-for-one (%(sebep)s), so the whole mesh was rebuilt instead "
        "of refusing it"),
    "topoloji_hizalama.en_kotu": (
        "A rebuilt mesh takes its bone weights, vertex colours and hand-rule bits from the "
        "nearest original vertex, so if the vertices really were re-ordered this part can be "
        "skinned to the wrong bones and tear apart when the character moves"),

    "join.ne": (
        "%(n)d exported part(s) were joined into this object in Blender (%(adlar)s) and the "
        "object was written anyway"),
    "join.en_kotu": (
        "The game keeps every part as its own mesh and the Workshop cannot split them apart "
        "again: the joined geometry is written into this one part with this part's material "
        "and bone weights, and the parts it came from stay in the game as they are, so you "
        "can end up seeing both copies"),

    "dogrulanmamis_klasor.ne": (
        "writing was enabled for a game folder this release has not verified (%(sebep)s)"),
    "dogrulanmamis_klasor.en_kotu": (
        "The Workshop's addresses come from a build it knows; on a different build they can "
        "point at other data, so a write can corrupt the archive and the game may refuse to "
        "start until you verify the files through Steam"),

    "materyal_eslesme.ne": (
        "%(eksik)d of %(toplam)d material group(s) in the edited model could not be matched "
        "to the original (missing: %(liste)s) and the part was written with those groups left "
        "at their original shape"),
    "materyal_eslesme.en_kotu": (
        "The groups that were not matched keep the shape they have in the game, so this part "
        "can come out as a mix of your edit and the original - and if you deleted or merged "
        "material slots in Blender, the wrong geometry can end up wearing the wrong material"),

    "materyal_sayisi.ne": (
        "the export holds %(export)d material group(s) for this part but the game mesh has "
        "%(oyun)d, and the part was written on the groups that could be matched"),
    "materyal_sayisi.en_kotu": (
        "A game mesh cannot gain or lose material slots, so the groups with no counterpart "
        "keep their original shape and your geometry can be drawn with another group's "
        "material"),

    "lod_bandi.ne": (
        "LOD band %(bant)d (drawn from %(mesafe)s) could not be rewritten (%(sebep)s) and the "
        "other band(s) were written anyway"),
    "lod_bandi.en_kotu": (
        "A part is normally written into every LOD band or none: with only the close-up band "
        "written, the original shape stays on screen from %(mesafe)s away and the item visibly "
        "changes shape as the camera pulls back"),

    "hedef_yok.ne": (
        "the target item has no part of the same kind as '%(kaynak)s', so it was written onto "
        "'%(hedef)s' - the closest unused target part by file size"),
    "hedef_yok.en_kotu": (
        "Pairing by size is a guess, not a match: the shape can land on the wrong slot "
        "entirely (a sheath copy in the hand, a hat on the boots), and the part it displaces "
        "is gone from the item until you revert"),

    "dejenere_ucgen.ne": (
        "material group %(grup)d holds %(sayi)d degenerate triangle(s) (two or more corners on "
        "the same point) and they were written as they are"),
    "dejenere_ucgen.en_kotu": (
        "A degenerate triangle draws nothing, which is exactly how the game hides geometry, so "
        "the affected surface is simply missing in game - and if there are many of them the "
        "part can be mostly holes"),

    "bos_primitif.ne": (
        "material group %(grup)d came back empty (%(nv)d vertices, %(nt)d triangles) and was "
        "written as a hidden group instead of refusing the part"),
    "bos_primitif.en_kotu": (
        "The group is padded to one zero-area triangle at %(yer)s, so that material's surface "
        "disappears from the item in game; the padding point also joins the mesh bounding box, "
        "which can make the game cull the part at the wrong distance"),

    "sha_yama.ne": (
        "this archive entry already carries a Workshop patch (%(yama)s) so it no longer matches "
        "your export, and your edit was written on top of the patched bytes"),
    "sha_yama.en_kotu": (
        "Your edit was measured against the ORIGINAL export, so writing it over a different "
        "shape can move the wrong vertices and produce a torn or scrambled part%(ortak)s"),

    "uzunluk_degisimi.ne": (
        "this edit changes the byte length of inner file %(icid)s from %(eski)d to %(yeni)d "
        "bytes (%(fark)+d) and it was written anyway; the wrapper size, the entry file table, "
        "the block tables and the table of contents were rebuilt%(sayac)s"),
    "uzunluk_degisimi.en_kotu": (
        "Count fields and object ordinals that live inside the object payload are positional "
        "and unnamed, so any parent count this tool could not identify still holds the old "
        "value and the game can refuse the entry, drop the object, or misread everything "
        "after it - the counts inside the object are yours to keep right"),
}


# ------------------------------------------------------------------ AYAR OKUMA/YAZMA
_ONBELLEK = {"imza": None, "ayar": None}


def _imza(yol):
    """Dosya kimligi: (yol, mtime_ns, boyut). Dosya yoksa (yol, None, None)."""
    try:
        st = os.stat(yol)
        return (yol, st.st_mtime_ns, st.st_size)
    except OSError:
        return (yol, None, None)


def onbellegi_bosalt():
    """Onbellegi dusur (test ve `ayarla` icin)."""
    _ONBELLEK["imza"] = None
    _ONBELLEK["ayar"] = None
    _DIL_ONBELLEK["imza"] = None
    _DIL_ONBELLEK["sozluk"] = None


def oku():
    """ayarlar.json'un TAMAMI (sozluk). Dosya yoksa/bozuksa bos sozluk.

    ONBELLEKLI: (mtime_ns, boyut) degismedikce JSON yeniden ayristirilmaz. Dosya
    baska bir surecte degisirse imza degisir ve yeniden okunur."""
    yol = _yol()
    im = _imza(yol)
    if _ONBELLEK["imza"] == im and _ONBELLEK["ayar"] is not None:
        return _ONBELLEK["ayar"]
    try:
        with open(yol, encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict):
            d = {}
    except Exception:                                           # noqa: BLE001
        d = {}
    _ONBELLEK["imza"] = im
    _ONBELLEK["ayar"] = d
    return d


def acik():
    """Uzman modu acik mi? VARSAYILAN KAPALI (dosya yok / anahtar yok / bozuk -> False)."""
    return oku().get("uzman") is True


def ayarla(deger):
    """Anahtari yaz. Diger ayarlar KORUNUR (oku-degistir-yaz). Doner: yeni ayar sozlugu.

    Yazma ATOMIKTIR (ayni klasorde gecici dosya + fsync + os.replace) -- sunucu.py'nin
    `ayar_yaz` deseninin aynisi, ama bu modulun KENDI kodu (o dosyaya dokunulmadi)."""
    yol = _yol()
    d = dict(oku())
    d["uzman"] = bool(deger)
    d["uzman_surum"] = SURUM
    d["uzman_zaman"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    klasor = os.path.dirname(yol) or "."
    os.makedirs(klasor, exist_ok=True)
    fd, gec = tempfile.mkstemp(dir=klasor, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(gec, yol)
    except BaseException:
        try:
            os.unlink(gec)
        except OSError:
            pass
        raise
    onbellegi_bosalt()
    return d


def kapi(ad):
    """`ad` kapisi ACIK mi? FAIL-CLOSED: bilinmeyen / kapasite kapisi -> daima False.

    Bugun butun politika kapilari TEK anahtara baglidir; imza kapi-bazli ayara
    gecebilmek icin bastan ad alir (arayuz `kapi(...)` cagirmaya devam eder)."""
    if ad not in KAPILAR:
        return False
    return acik()


# ------------------------------------------------------------------ CEVIRI
# NEDEN CEVIRI BURADA, KIMLIK ANAHTARIYLA YAPILIYOR (2026-09-07'de olculdu)
# --------------------------------------------------------------------------
# Arayuzun cevirmeni (arayuz.html `_cevirKok`) DOM'daki metin dugumunu sozlukte
# ARAR; sozlugun anahtari ekrandaki INGILIZCE cumledir ("gettext mantigi",
# bkz. diller.js basligi). Uzman uyarisi ise bu kalibin DISINDA kalir, cunku
# cumleyi Python kurar ve %-alanlarini BURADA doldurur:
#     sozlukteki kalip : "...raised from %(eski)g to %(yeni)g m..."
#     ekrandaki cumle  : "...raised from 0.5 to 1 m..."
# Iki dize hicbir zaman esitlenemez -> cumleyi INGILIZCE anahtarla sozluge
# koymak OLU kayit uretir (kapi yesil yanar, kullanici Ingilizce cumleyi gorur).
# Bu yuzden SABIT_METINLER'in anahtarlari BILEREK tanimlayicidir ve ceviri
# doldurmadan ONCE, tanimlayiciyla, burada aranir.
#
# Dil, sunucu.py'nin `dil_kaydet`i ile AYNI ayarlar.json'a yazilir -- bu modul
# o dosyayi zaten okuyor, yani dili ogrenmenin ek maliyeti yok.
DIL_KODLARI = ("en", "es", "ru", "zh", "tr")

_DIL_ONBELLEK = {"imza": None, "sozluk": None}
# diller.js yalnizca "anahtar": "deger" ciftlerinden olusur (build/diller_uret.py
# URETIR); ceviri_envanter.sozlukler() ile AYNI ayristirma.
_DIL_BLOK = re.compile(r'^\s*(en|es|ru|zh|tr):\s*\{', re.M)
_DIL_CIFT = re.compile(r'"((?:[^"\\]|\\.)*)"\s*:\s*"((?:[^"\\]|\\.)*)"')


def _diller_dosyasi():
    """diller.js'in yolu: gelistirme agacinda `v09_arayuz/`, PAKETTE `arayuz/`
    (build/kur.py klasoru yeniden adlandirir). Bulunamazsa None."""
    kok = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for ad in ("arayuz", "v09_arayuz"):
        yol = os.path.join(kok, ad, "varlik", "diller.js")
        if os.path.isfile(yol):
            return yol
    return None


def _diller():
    """{dil: {anahtar: ceviri}}. ONBELLEKLI (ayar dosyasiyla ayni imza deseni).

    FAIL-OPEN: dosya yoksa/bozuksa BOS sozluk doner ve cumle Ingilizce cikar.
    Ceviri suslemedir; uyarinin KENDISI hicbir kosulda kaybolmamalidir."""
    yol = _diller_dosyasi()
    if not yol:
        return {}
    im = _imza(yol)
    if _DIL_ONBELLEK["imza"] == im and _DIL_ONBELLEK["sozluk"] is not None:
        return _DIL_ONBELLEK["sozluk"]
    out = {}
    try:
        with open(yol, encoding="utf-8") as f:
            js = f.read()
        bloklar = list(_DIL_BLOK.finditer(js))
        for i, b in enumerate(bloklar):
            son = bloklar[i + 1].start() if i + 1 < len(bloklar) else len(js)
            d = {}
            for m in _DIL_CIFT.finditer(js[b.end():son]):
                try:
                    d[json.loads('"' + m.group(1) + '"')] = json.loads('"' + m.group(2) + '"')
                except ValueError:
                    pass
            out[b.group(1)] = d
    except Exception:                                           # noqa: BLE001
        out = {}
    _DIL_ONBELLEK["imza"] = im
    _DIL_ONBELLEK["sozluk"] = out
    return out


def dil():
    """Arayuzde secili dil kodu (ayarlar.json'daki "dil"; sunucu.py yazar).
    Eksik / taninmayan deger -> "en"."""
    d = oku().get("dil")
    return d if d in DIL_KODLARI else "en"


def metin(anahtar, dil_kodu=None):
    """SABIT_METINLER[anahtar]'in SECILI DILDEKI karsiligi; ceviri yoksa Ingilizcesi.

    Sozlukteki anahtar TANIMLAYICIDIR ("olcek_bandi.en_kotu"), Ingilizce cumle
    degil -- gerekcesi icin yukaridaki bloga bak."""
    ing = SABIT_METINLER.get(anahtar)
    kod = dil_kodu if dil_kodu is not None else dil()
    if ing is None or kod == "en":
        return ing
    try:
        return _diller().get(kod, {}).get(anahtar) or ing
    except Exception:                                           # noqa: BLE001
        return ing


def _doldur(kalip, ing, kw):
    """`kalip`i `kw` ile doldur; kalip bozuksa INGILIZCESINE don.

    Ceviriler yer tutuculari (%(eski)g ...) korumak ZORUNDADIR. Koruyamamis bir
    ceviri yuzunden cumle yarim kalmasin diye once cevrilmis kalip, sonra
    Ingilizce kalip denenir; ikisi de doldurulamazsa HAM kalip basilir."""
    for aday in (kalip, ing):
        if aday is None:
            continue
        if not kw:
            return aday
        try:
            return aday % kw
        except (KeyError, TypeError, ValueError):
            continue
    return ing if ing is not None else ""


def uyari(ad, **kw):
    """Kullaniciya gidecek uyari cumlesi (SECILI DILDE).

    "Expert mode: <ne yapildi>. <en kotu senaryo>. Revert puts it back."
    `kw` hem 'ne' hem 'en_kotu' kalibina uygulanir (lod_bandi'nin en kotu senaryosu
    mesafeyi tekrarlar). Eksik alan olursa cumle KAYBOLMAZ: ham kalip basilir.
    Ceviri de kaybettirmez: bozuk/eksik ceviri Ingilizceye doner."""
    ne_ing = SABIT_METINLER.get("%s.ne" % ad)
    kotu_ing = SABIT_METINLER.get("%s.en_kotu" % ad)
    if ne_ing is None or kotu_ing is None:
        raise KeyError("no expert-mode warning text for gate %r" % (ad,))
    kod = dil()
    ne = _doldur(metin("%s.ne" % ad, kod), ne_ing, kw)
    kotu = _doldur(metin("%s.en_kotu" % ad, kod), kotu_ing, kw)
    govde = metin("govde", kod) or GOVDE
    try:
        return govde % (ne, kotu)
    except (KeyError, TypeError, ValueError):
        return GOVDE % (ne, kotu)
