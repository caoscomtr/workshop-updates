# -*- coding: utf-8 -*-
"""SILAH STAT — weapon stats (damage / draw speed / range / max takedown) + perks.

Nerede duruyorlar (2026-09-05 ALAN B arastirmasi, bayt kanitli):
  DataPC_boot.forge > "OBD WeaponStatsSettings - Player - Sword"  (0x0237D69C13E0)
      > WeaponStats_Sword_TotalAttack   (hasar)
      > WeaponStats_Sword_ChainAttack   (maks. zincirli indirme)
  DataPC_boot.forge > "OBD WeaponStatsSettings - Player - Pistol" (0x0247367FD711)
      > WeaponStats_Pistol_TotalAttack  (hasar)
      > WeaponStats_Pistol_DrawSpeed    (cekis hizi)
      > WeaponStats_Pistol_Range        (atis mesafesi)

Bicim (olculdu, ezber ofset YOK — her sey CANLI govdeden turetilir):
  alan nesnesi   [u16 semaIdx][D0 92 26 8A FA A4][u32 alanCrc] ...
        0xAF7B4C2A / 0x87899C76 -> 01 + 5B + [u32 len][ASCII tasarimci etiketi]
        0x3B2E8FB4              -> 01 + i32     (tamsayi stat)
        0x0CAB069A              -> 01 + f32     (ondalik stat)
        0xE0EE0EB5              -> 5B  + u32    (uye sayisi)
  cocuk nesnesi  [u16 sirano][F8 FB 00 00 00 00][u32 sinifCrc] ...
        0xB178F45E -> kural grubu · 0x12E3DFEF -> grup uyesi (+2B, u64 item id, +1B)
  cocuk sirano'lari govdede 0..N-1 SIRALIDIR (olculdu) -> ekleme/silmede yeniden numaralanir.

Ne yapabiliriz
  * kademe degerini degistir  (i32/f32 yerinde; govde uzunlugu degismez)
  * bir silahi baska kademeye tasi / varsayilana dondur (23 B uye kaydi tasinir)
  * perk atamasi: silahin item govdesindeki u64 perk referansini degistir

Guvenlik: yazma yalniz kur_mesh uzerinden (yedek + jurnal + TOC geri alma + "oyun acik"
kapisi + YAZMA_KILIDI oradan gelir). Yazmadan once yeni govde AYNI cozucuyle geri okunur
ve beklenen degisiklik disinda tek bayt oynamadigi dogrulanir.
Kullanici metinleri INGILIZCE.
"""
import json
import os
import re
import struct

BURA = os.path.dirname(os.path.abspath(__file__))

# ---- IC SINIF kimlikleri (olculdu; 2026-09-07'de ADLARI duzeltildi)
#
# DIKKAT — bu u32'ler "alan" kimligi DEGIL, IC SINIF kimligidir: crc32(SinifAdi),
# ust-duzey tipCrc ile AYNI kural. Bicim alan adi da tip bayragi da TASIMIYOR;
# her sinifin yuku KONUMSAL sabit bir yapidir (or. A_INT = [u8 01][i32][u8 00]).
# Bu yuzden `01` bir "tip bayragi" degil, o siniflarin surum/var bayti.
# Alan sinirlari icin SINIF BASINA sema gerekir -> build/alan_adlari.json.
A_ETIKET1 = 0xAF7B4C2A
A_ETIKET2 = 0x87899C76
A_INT = 0x3B2E8FB4
A_FLOAT = 0x0CAB069A
A_SAYI = 0xE0EE0EB5          # uye sayisi
T_GRUP = 0xB178F45E
T_UYE = 0x12E3DFEF

# Govdedeki her kayit [u64 nesne_kimligi][u32 sinifCrc][yuk] seklinde. Kimligin ust
# 6 bayti bir "damga" gibi gorunur ama SABIT DEGIL, TURETILIR:
#   yerel nesne     : kimlik = 0x00000000FBF80000 | i          -> COCUK_MARK
#   turetilmis nesne: kimlik = 0x8000000000000000 | (icid<<20) | i
# Eskiden burada `ALAN_MARK = b"\xd0\x92\x26\x8a\xfa\xa4"` yaziyordu ve yorumu
# "damga sinifa gore degisir" diyordu. IKISI DE YANLISTI: o dizi yalnizca
# icid 0x024FA8A2692D'nin turetilmis onegi, yani IC DOSYAYA gore degisiyor
# (bayt kaniti: pack("<Q", 0x8000000000000000 | (0x024FA8A2692D << 20))[2:8]).
# Sabit olu koddu -- `_alanlar()` damgayi aramaz, crc'yi tarayip bicimle dogrular;
# bu yuzden yanlislik davranisa yansimadi. Ihtiyac olursa turetici asagida.
COCUK_MARK = b"\xf8\xfb\x00\x00\x00\x00"
UYE_BOY = 23                 # [u16][6B][u32 crc][2B][u64 id][1B]


def kimlik_onek(icid, i=0):
    """Bir ic dosyanin TURETILMIS nesne kimliginin ust 6 bayti (eski ALAN_MARK)."""
    return struct.pack("<Q", (0x8000000000000000 | (int(icid) << 20) | int(i))
                       & 0xFFFFFFFFFFFFFFFF)[2:8]

SETLER = [
    {"anahtar": "sword_dmg", "ad": "Sword — damage", "kart": "Damage", "kisa": "DMG",
     "gid": 0x0237D69C13E0, "icid": 0x023B14A9C085, "tur": "sword"},
    {"anahtar": "sword_chain", "ad": "Sword — max chain takedown",
     "kart": "Max chain takedown", "kisa": "chain",
     "gid": 0x0237D69C13E0, "icid": 0x024FA8A2692D, "tur": "sword"},
    {"anahtar": "pistol_dmg", "ad": "Pistol — damage", "kart": "Damage", "kisa": "DMG",
     "gid": 0x0247367FD711, "icid": 0x0247367FE234, "tur": "pistol"},
    {"anahtar": "pistol_draw", "ad": "Pistol — draw speed", "kart": "Draw speed",
     "kisa": "draw",
     "gid": 0x0247367FD711, "icid": 0x0250D5100D57, "tur": "pistol"},
    {"anahtar": "pistol_range", "ad": "Pistol — shot distance", "kart": "Shot distance",
     "kisa": "m",
     "gid": 0x0247367FD711, "icid": 0x0250D5100D69, "tur": "pistol"},
]
SET_HARITA = dict((s["anahtar"], s) for s in SETLER)

# arayuze giden sabit metinler (ceviri envanteri bunlari toplar)
SABIT_METINLER = [s["ad"] for s in SETLER] + [s["kart"] for s in SETLER] + [
    "Base value", "Applies to every weapon of this type",
    "Not in any tier (uses the base value)", "weapons", "weapon",
    "Weapon stats", "Tier", "Effective", "unknown weapon",
    # --- silah odakli kart / plan metinleri
    "This item has no editable stats.",
    "This weapon shares its item entries with copies that are not all on the same "
    "value right now; applying a change puts every copy on the value you pick.",
    "Nothing to change - this weapon already uses the values you asked for.",
    "Every pistol reads the same base damage, so changing it changes the damage of "
    "every pistol in the game.",
    "The plan is ready.",
    "Unknown weapon.",
    "This weapon does not have that stat.",
    "No weapon-stat patch is installed.",
]

KATALOG_YOL = os.path.join(BURA, "silah_stat_katalog.json")
KART_KATALOG_YOL = os.path.join(BURA, "silah_katalog.json")
_KATALOG = None
_KART_KATALOG = None
_AD_KALIP = re.compile(r"^Weapon_(Sword|Pistol)_(\d+)$")


def katalog():
    """item id -> {"ad": varlik adi, "gorunen": oyundaki ad}. Yoksa bos (adlar hex gosterilir)."""
    global _KATALOG
    if _KATALOG is None:
        try:
            with open(KATALOG_YOL, "r", encoding="utf-8") as f:
                ham = json.load(f)
            _KATALOG = dict((int(k, 16), v) for k, v in (ham.get("silahlar") or {}).items())
        except Exception:
            _KATALOG = {}
    return _KATALOG


def kart_katalog():
    """Weapons sekmesinin katalogu -> [{"anahtar","gorunen","tur","no"}].

    "anahtar" = silah_katalog.json'daki "ad" alani; Weapons sekmesi bu anahtarla
    calisiyor (export3d/cozum.py:coz_silah). Yalniz Weapon_Sword_NN / Weapon_Pistol_NN
    kaliplari stat sistemine baglanabilir; Trinket_* girisleri baglanmaz (olculdu:
    silah_stat_katalog.json'da tek bir trinket item kimligi yok).
    """
    global _KART_KATALOG
    if _KART_KATALOG is None:
        out = []
        try:
            with open(KART_KATALOG_YOL, "r", encoding="utf-8") as f:
                ham = json.load(f)
            for w in ham.get("silahlar") or []:
                ad = w.get("ad") or ""
                m = _AD_KALIP.match(ad)
                out.append({"anahtar": ad,
                            "gorunen": w.get("gorunen_ad") or ad,
                            "tur": m.group(1).lower() if m else None,
                            "no": int(m.group(2)) if m else None})
        except Exception:
            out = []
        _KART_KATALOG = out
    return _KART_KATALOG


def _item_haritasi():
    """(tur, no) -> [item kimligi, ...] — stat katalogundan, sirali."""
    out = {}
    for iid, v in katalog().items():
        t = v.get("tur")
        n = v.get("no")
        if t in ("sword", "pistol") and n is not None:
            out.setdefault((t, int(n)), []).append(iid)
    for k in out:
        out[k].sort()
    return out


# ------------------------------------------------------------------ forge erisimi
def _cekirdek():
    import outfit_core as C
    return C


def _forge_yolu(forge=None):
    return forge or _cekirdek().FORGE


def _ic_govde(gid, icid, forge=None):
    """(tam ic dosya baytlari, govde_off) — CANLI forge'dan."""
    from export3d import forge_giris as FG
    C = _cekirdek()
    lf = C._forge()
    for cid, g in FG.ic_dosyalar(lf, gid):
        if cid == icid:
            w = FG.sarmalayici_coz(g)
            return g, w["govde_off"]
    raise KeyError("Inner file 0x%012X is not in entry 0x%012X." % (icid, gid))


def _ic_dosya_kur(ham, govde_off, yeni_govde):
    """Yeni govdeyi ic dosya SARMALAYICISIYLA birlestir ve baslikaki BOYUT alanini duzelt.

    2026-09-05, OYUN ICI TEST: kademe tasima govdeyi 23 B buyutuyor; sarmalayicinin
    [u32 tip][u32 boyut][u32 adLen] basligindaki `boyut` ESKI degerde kaliyordu ve oyun
    (bizim okuyucumuz da) girisi reddediyordu: "wrapper size mismatch: header 2067 vs
    body 2090". Uzunlugu DEGISTIRMEYEN duzenlemelerde gorunmuyordu, o yuzden 15 kapi da
    yesildi -- kapilarin hicbiri uzunluk degistiren bir yazmayi sarmalayicidan gecirmiyordu.
    Bicim (forge_giris.sarmalayici_coz): boyut == len(ic_dosya) - 13 - adLen.
    """
    from export3d import forge_giris as FG
    # ORIJINALIN KUYRUGU: bazi girislerde (or. Animation) `boyut`a dahil OLMAYAN
    # 55-199 baytlik bir kuyruk var (2026-09-07 olcumu); kurucu onu KORUR.
    # TEK KURUCU (v0.17): govde forge_giris.sarmalayici_kur'da, nesne_yaz ile AYNI
    # baytlar (test K6(i) esitligi olcer). Boyut alanini struct.pack_into yazar --
    # test_silah_stat'in `struct.pack_into` sabotaji hala kapiyi dusurur.
    return FG.sarmalayici_kur(ham, govde_off, yeni_govde)


# ------------------------------------------------------------------ cozucu
def _alanlar(gv):
    """govdedeki ALAN kayitlari: [(crc_off, crc, tur, deger, deger_off, uzunluk)].

    Alan tanimlayicisinin ONUNDEKI 6 baytlik damga sinifa gore degisiyor (olculdu:
    WeaponStats_Sword_ChainAttack'ta D0 92 26 8A FA A4, digerlerinde baska), bu yuzden
    ARANAN sey alan CRC'sinin KENDISI; bicim kontrolu dogrulamayi yapar.
    """
    out = []
    n = len(gv)
    for q in range(max(0, n - 8)):
        crc = struct.unpack_from("<I", gv, q)[0]
        if crc in (A_ETIKET1, A_ETIKET2):
            if q + 14 <= n and gv[q + 4] == 1:
                ln = struct.unpack_from("<I", gv, q + 10)[0]
                if 0 < ln < 4096 and q + 14 + ln <= n:
                    t = gv[q + 14:q + 14 + ln].rstrip(b"\x00")
                    try:
                        out.append((q, crc, "etiket", t.decode("ascii"), q + 14, ln))
                    except UnicodeDecodeError:
                        pass
        elif crc == A_INT:
            if q + 9 <= n and gv[q + 4] == 1:
                out.append((q, crc, "int", struct.unpack_from("<i", gv, q + 5)[0], q + 5, 4))
        elif crc == A_FLOAT:
            if q + 9 <= n and gv[q + 4] == 1:
                out.append((q, crc, "float", struct.unpack_from("<f", gv, q + 5)[0], q + 5, 4))
    return out


def _cocuklar(gv):
    """govdedeki COCUK nesneleri: [(kayit_off, sirano, crc)] — kayit_off = u16 sirano'nun yeri."""
    out = []
    n = len(gv)
    q = gv.find(COCUK_MARK)
    while q >= 0:
        if q >= 2 and q + 10 <= n:
            out.append((q - 2, struct.unpack_from("<H", gv, q - 2)[0],
                        struct.unpack_from("<I", gv, q + 6)[0]))
        q = gv.find(COCUK_MARK, q + 1)
    return out


def _uye_id(gv, kayit_off):
    return struct.unpack_from("<Q", gv, kayit_off + 14)[0]


def coz(gv):
    """Govdeyi kademe/uye yapisina cevir. Salt okuma; hicbir sey degistirmez."""
    alan = _alanlar(gv)
    cocuk = _cocuklar(gv)

    # cocuk sirano'lari sirali mi? (yeniden numaralamanin on kosulu)
    sirali = [c[1] for c in cocuk] == list(range(len(cocuk)))

    # gruplar: her T_GRUP bir kural blogu; ardindan A_SAYI ve T_UYE kayitlari gelir
    gruplar = []
    for off, _sn, crc in cocuk:
        if crc == T_GRUP:
            gruplar.append({"off": off, "sayi_off": None, "sayi": 0, "uyeler": []})
        elif crc == A_SAYI and gruplar and gruplar[-1]["sayi_off"] is None:
            gruplar[-1]["sayi_off"] = off + 17
            gruplar[-1]["sayi"] = struct.unpack_from("<I", gv, off + 17)[0]
        elif crc == T_UYE and gruplar:
            gruplar[-1]["uyeler"].append({"off": off, "id": _uye_id(gv, off)})

    # bloklar: etiket koslari + sayisal degerler; her blok en fazla bir gruba baglanir
    olaylar = sorted([(a[0], a[2], a[3], a[4], a[1]) for a in alan
                      if a[2] in ("etiket", "int", "float")] +
                     [(g["off"], "grup", i, None, None) for i, g in enumerate(gruplar)])
    bloklar, cur = [], None
    for off, tur, deger, doff, crc in olaylar:
        if tur == "etiket":
            if cur is None or cur["grup"] is not None or cur["degerler"]:
                cur = {"etiketler": [], "degerler": [], "grup": None}
                bloklar.append(cur)
            cur["etiketler"].append(deger)
        else:
            if cur is None:
                cur = {"etiketler": [], "degerler": [], "grup": None}
                bloklar.append(cur)
            if tur == "grup":
                cur["grup"] = deger
            else:
                cur["degerler"].append({"tur": tur, "deger": deger, "off": doff})
    return {"bloklar": bloklar, "gruplar": gruplar, "sirali": sirali,
            "cocuk_sayisi": len(cocuk)}


def _yuvarla(t, v):
    return int(v) if t == "int" else round(float(v), 4)


def set_oku(s, forge=None):
    """Tek stat setini oku -> {"taban":…, "kademeler":[…], "diger":[…]}"""
    ham, goff = _ic_govde(s["gid"], s["icid"], forge)
    gv = ham[goff:]
    y = coz(gv)
    if not y["sirali"]:
        raise RuntimeError("This game build stores the stat rules in an order we do not "
                           "recognise - refusing to touch it.")
    kat = katalog()
    taban, kademeler, diger = None, [], []
    for b in y["bloklar"]:
        etiket = " | ".join(b["etiketler"])
        if not b["degerler"]:
            continue
        son = b["degerler"][-1]
        for d in b["degerler"][:-1]:
            if taban is None:
                taban = {"tur": d["tur"], "deger": _yuvarla(d["tur"], d["deger"]),
                         "off": d["off"], "etiket": etiket}
            else:
                diger.append({"tur": d["tur"], "deger": _yuvarla(d["tur"], d["deger"]),
                              "off": d["off"], "etiket": etiket})
        if b["grup"] is None:
            if taban is None:
                taban = {"tur": son["tur"], "deger": _yuvarla(son["tur"], son["deger"]),
                         "off": son["off"], "etiket": etiket}
            else:
                diger.append({"tur": son["tur"], "deger": _yuvarla(son["tur"], son["deger"]),
                              "off": son["off"], "etiket": etiket})
            continue
        g = y["gruplar"][b["grup"]]
        silahlar = []
        for u in g["uyeler"][:g["sayi"]]:
            k = kat.get(u["id"]) or {}
            silahlar.append({"id": "0x%012X" % u["id"],
                             "ad": k.get("ad") or "",
                             "gorunen": k.get("gorunen") or ("0x%012X" % u["id"])})
        kademeler.append({"i": len(kademeler), "etiket": etiket, "tur": son["tur"],
                          "deger": _yuvarla(son["tur"], son["deger"]), "off": son["off"],
                          "grup": b["grup"], "silahlar": silahlar})
    if taban is None:
        raise RuntimeError("No base value found in this stat object.")
    for k in kademeler:
        k["etkin"] = _yuvarla(k["tur"], taban["deger"] + k["deger"])
    return {"taban": taban, "kademeler": kademeler, "diger": diger,
            "govde": gv, "ham": ham, "govde_off": goff, "yapi": y}


def oku(forge=None):
    """Butun stat setleri + hangi silah hangi kademede + canli yama durumu."""
    forge = _forge_yolu(forge)
    d = durum(forge)
    out, hata = [], []
    for s in SETLER:
        try:
            r = set_oku(s, forge)
        except Exception as e:
            hata.append({"set": s["anahtar"], "mesaj": str(e)})
            continue
        out.append({"anahtar": s["anahtar"], "ad": s["ad"], "kart": s["kart"],
                    "kisa": s["kisa"],
                    "tur": s["tur"], "gid": "0x%012X" % s["gid"],
                    "icid": "0x%012X" % s["icid"],
                    "taban": {k: v for k, v in r["taban"].items() if k != "off"},
                    "kademeler": [{k: v for k, v in kd.items() if k not in ("off", "grup")}
                                  for kd in r["kademeler"]],
                    "diger": [{k: v for k, v in x.items() if k != "off"}
                              for x in r["diger"]]})
    return {"ok": bool(out), "setler": out, "hatalar": hata, "forge": forge,
            "yamali": bool(d.get("yamali")), "kayitlar": d.get("kayitlar") or []}


def silah_listesi(forge=None):
    """tur -> [{"id","gorunen","kademeler":{set: kademe indeksi|None}}] — silah odakli gorunum."""
    r = oku(forge)
    if not r.get("ok"):
        return r
    kat = katalog()
    tablo = {}
    for s in r["setler"]:
        for kd in s["kademeler"]:
            for w in kd["silahlar"]:
                t = tablo.setdefault(w["id"], {"id": w["id"], "gorunen": w["gorunen"],
                                               "tur": s["tur"], "kademe": {}, "deger": {}})
                t["kademe"][s["anahtar"]] = kd["i"]
                t["deger"][s["anahtar"]] = kd["etkin"]
    # hicbir kademede olmayan silahlar: katalogdan tamamla (varsayilan deger)
    for iid, k in kat.items():
        a = "0x%012X" % iid
        if a not in tablo and k.get("tur") in ("sword", "pistol"):
            tablo[a] = {"id": a, "gorunen": k.get("gorunen") or a, "tur": k["tur"],
                        "kademe": {}, "deger": {}}
    for s in r["setler"]:
        for t in tablo.values():
            if t["tur"] == s["tur"] and s["anahtar"] not in t["kademe"]:
                t["kademe"][s["anahtar"]] = None
                t["deger"][s["anahtar"]] = s["taban"]["deger"]
    return {"ok": True, "silahlar": sorted(tablo.values(), key=lambda x: x["gorunen"].lower()),
            "setler": [{"anahtar": s["anahtar"], "ad": s["ad"], "kisa": s["kisa"],
                        "tur": s["tur"]} for s in r["setler"]]}


# ------------------------------------------------------------------ yazma
def _sirano_yaz(gv):
    """Cocuk sirano'larini 0..N-1 yeniden numaralandir (ekleme/silmeden sonra)."""
    b = bytearray(gv)
    for i, (off, _sn, _crc) in enumerate(_cocuklar(bytes(b))):
        struct.pack_into("<H", b, off, i)
    return bytes(b)


def _deger_yaz(gv, off, tur, deger):
    b = bytearray(gv)
    if tur == "int":
        v = int(round(float(deger)))
        if not (-2147483648 <= v <= 2147483647):
            raise ValueError("Value out of range for a whole number field.")
        struct.pack_into("<i", b, off, v)
    else:
        v = float(deger)
        if v != v or abs(v) > 1e30:
            raise ValueError("Value out of range for a decimal field.")
        struct.pack_into("<f", b, off, v)
    return bytes(b)


def _uye_sil(gv, grup, uye_off):
    b = bytearray(gv)
    struct.pack_into("<I", b, grup["sayi_off"], max(0, grup["sayi"] - 1))
    del b[uye_off:uye_off + UYE_BOY]
    return _sirano_yaz(bytes(b))


def _uye_ekle(gv, grup, item_id, sablon_off):
    """Grubun uye listesinin SONUNA yeni bir uye kaydi koy (sablon: mevcut bir uye kaydi)."""
    b = bytearray(gv)
    kayit = bytearray(gv[sablon_off:sablon_off + UYE_BOY])
    struct.pack_into("<Q", kayit, 14, item_id)
    if grup["uyeler"]:
        yer = grup["uyeler"][-1]["off"] + UYE_BOY
    else:
        yer = grup["sayi_off"] + 4
    b[yer:yer] = kayit
    struct.pack_into("<I", b, grup["sayi_off"], grup["sayi"] + 1)
    return _sirano_yaz(bytes(b))


def _dogrula(eski_gv, yeni_gv, beklenen):
    """Yeni govdeyi AYNI cozucuyle geri oku; beklenen degisiklik disinda sapma varsa reddet."""
    a, b = coz(eski_gv), coz(yeni_gv)
    if not b["sirali"]:
        raise RuntimeError("The rebuilt rules are not in sequence - nothing was written.")
    if len(b["gruplar"]) != len(a["gruplar"]):
        raise RuntimeError("The rebuilt rules lost or gained a tier - nothing was written.")
    for g in b["gruplar"]:
        if g["sayi"] != len(g["uyeler"]):
            raise RuntimeError("A tier's weapon count no longer matches its list - "
                               "nothing was written.")
    uyeler = {}
    for i, g in enumerate(b["gruplar"]):
        for u in g["uyeler"]:
            if u["id"] in uyeler:
                raise RuntimeError("A weapon ended up in two tiers at once - nothing was written.")
            uyeler[u["id"]] = i
    eski_uye = {}
    for i, g in enumerate(a["gruplar"]):
        for u in g["uyeler"][:g["sayi"]]:
            eski_uye[u["id"]] = i
    hedefler = beklenen.get("tasima") or {}
    for iid, hedef in hedefler.items():
        if uyeler.get(iid) != hedef:      # hedef None ise: hicbir kademede olmamali
            raise RuntimeError("A weapon did not land where we asked for - "
                               "nothing was written.")
        eski_uye.pop(iid, None)
    for iid, i in eski_uye.items():
        if uyeler.get(iid) != i:
            raise RuntimeError("An untouched weapon changed tier - nothing was written.")
    for iid in uyeler:
        if iid not in eski_uye and iid not in hedefler:
            raise RuntimeError("A weapon appeared out of nowhere - nothing was written.")
    ea = [(blk["etiketler"], [d["tur"] for d in blk["degerler"]]) for blk in a["bloklar"]]
    eb = [(blk["etiketler"], [d["tur"] for d in blk["degerler"]]) for blk in b["bloklar"]]
    if ea != eb:
        raise RuntimeError("The rule labels changed unexpectedly - nothing was written.")
    return True


def hazirla(istekler, forge=None):
    """Istekleri set set yeni govdelere cevir. HICBIR SEY YAZMAZ; kuru kosu icin de kullanilir.

    istek bicimleri:
      {"set": "sword_dmg", "taban": 15}                 -> taban degeri
      {"set": "sword_dmg", "kademe": 5, "etkin": 50}    -> kademenin etkin degeri
      {"set": "sword_dmg", "kademe": 5, "deger": 25}    -> kademenin ham (delta) degeri
      {"set": "sword_dmg", "silah": "0x0211…", "kademe": 2}     -> silahi kademeye tasi
      {"set": "sword_dmg", "silah": "0x0211…", "kademe": None}  -> varsayilana dondur
    """
    forge = _forge_yolu(forge)
    grup_istek = {}
    for it in istekler:
        a = it.get("set")
        if a not in SET_HARITA:
            raise ValueError("Unknown stat set: %s" % a)
        grup_istek.setdefault(a, []).append(it)

    isler = []
    for a, liste in grup_istek.items():
        s = SET_HARITA[a]
        r = set_oku(s, forge)
        gv = r["govde"]
        eski = gv
        degisim = []
        # 1) once sayisal degerler (ofsetler tasima ile kaymadan)
        for it in liste:
            if "silah" in it:
                continue
            if "taban" in it:
                t = r["taban"]
                gv = _deger_yaz(gv, t["off"], t["tur"], it["taban"])
                degisim.append("base %s -> %s" % (t["deger"], _yuvarla(t["tur"], it["taban"])))
            elif "kademe" in it:
                k = r["kademeler"][int(it["kademe"])]
                if "etkin" in it:
                    yeni = float(it["etkin"]) - float(r["taban"]["deger"])
                else:
                    yeni = float(it["deger"])
                gv = _deger_yaz(gv, k["off"], k["tur"], yeni)
                degisim.append("tier %d: %s -> %s" % (
                    k["i"], k["etkin"], _yuvarla(k["tur"], float(r["taban"]["deger"]) + yeni)))
        # 2) sonra tasima (govde uzunlugu degisir -> her adimda yeniden coz)
        tasima = {}
        for it in liste:
            if "silah" not in it:
                continue
            iid = it["silah"]
            iid = int(iid, 16) if isinstance(iid, str) else int(iid)
            hedef = it.get("kademe")
            y = coz(gv)
            sablon = None
            for g in y["gruplar"]:
                for u in g["uyeler"]:
                    sablon = sablon if sablon is not None else u["off"]
            if sablon is None:
                raise RuntimeError("This stat object has no weapon list to copy from.")
            # mevcut yerinden cikar
            for gi, g in enumerate(y["gruplar"]):
                for u in g["uyeler"][:g["sayi"]]:
                    if u["id"] == iid:
                        gv = _uye_sil(gv, g, u["off"])
                        y = coz(gv)
                        break
                else:
                    continue
                break
            if hedef is not None:
                gi = r["kademeler"][int(hedef)]["grup"]
                y = coz(gv)
                sablon = None
                for g in y["gruplar"]:
                    for u in g["uyeler"]:
                        sablon = u["off"] if sablon is None else sablon
                gv = _uye_ekle(gv, y["gruplar"][gi], iid, sablon)
                tasima[iid] = gi
                degisim.append("0x%012X -> tier %d" % (iid, int(hedef)))
            else:
                tasima[iid] = None
                degisim.append("0x%012X -> base value" % iid)
        if gv == eski:
            continue
        _dogrula(eski, gv, {"tasima": tasima})
        yeni_ic = _ic_dosya_kur(r["ham"], r["govde_off"], gv)
        isler.append({"set": a, "gid": s["gid"], "icid": s["icid"], "yeni_ic": yeni_ic,
                      "eski_bayt": len(r["ham"]), "yeni_bayt": len(yeni_ic),
                      "degisim": degisim})
    return isler


def uygula(istekler, forge=None, etiket="weapon stats", ilerleme=None):
    """Istekleri arsive kur (kur_mesh: yedek + jurnal + geri alma + oyun-acik kapisi)."""
    from export3d import kur_mesh as KM
    forge = _forge_yolu(forge)
    try:
        isler = hazirla(istekler, forge)
    except Exception as e:
        return {"ok": False, "mesaj": str(e)}
    if not isler:
        return {"ok": False, "mesaj": "Nothing to change."}
    sonuc, kurulan = [], []
    for i, is_ in enumerate(isler):
        if ilerleme:
            ilerleme({"i": i, "n": len(isler), "set": is_["set"]})
        ustune = any(k["gid"] == is_["gid"] for k in kurulan)
        r = KM.kur(forge, is_["gid"], is_["icid"], is_["yeni_ic"],
                   etiket="%s (%s)" % (etiket, is_["set"]), ustune=ustune)
        if not r.get("ok") and not ustune:
            # ayni giriste zaten bir yama varsa ustune yaz (stat setleri girisi paylasiyor)
            if r.get("mevcut_yama"):
                r = KM.kur(forge, is_["gid"], is_["icid"], is_["yeni_ic"],
                           etiket="%s (%s)" % (etiket, is_["set"]), ustune=True)
        sonuc.append({"set": is_["set"], "ok": bool(r.get("ok")),
                      "mesaj": r.get("mesaj") or "", "kayit": r.get("id"),
                      "degisim": is_["degisim"]})
        if r.get("ok"):
            kurulan.append(is_)
        else:
            return {"ok": False, "mesaj": r.get("mesaj") or "Install failed.",
                    "sonuc": sonuc}
    return {"ok": True, "sonuc": sonuc,
            "mesaj": "Applied %d change set(s)." % len(sonuc)}


def durum(forge=None):
    """Stat setlerine ait CANLI yama durumu (salt okuma).

    kur_mesh.durum() zaten yalniz AKTIF girisleri ("uygulandi"/"yarim"/"yaziliyor")
    "yamalar" anahtarinda dondurur; burada yalnizca bizim iki giris kimligimize
    ait olanlar suzulur.
    """
    from export3d import kur_mesh as KM
    forge = _forge_yolu(forge)
    gidler = set("0x%012X" % s["gid"] for s in SETLER)
    icidler = set("0x%012X" % s["icid"] for s in SETLER)
    try:
        d = KM.durum(forge) or {}
    except Exception as e:
        return {"ok": False, "yamali": False, "kayitlar": [], "mesaj": str(e),
                "forge": forge}
    kayitlar = [k for k in (d.get("yamalar") or [])
                if k.get("gid") in gidler and k.get("icid") in icidler]
    return {"ok": True, "yamali": bool(kayitlar), "kayitlar": kayitlar, "forge": forge}


def geri_al(kayit_id=None, forge=None):
    """Stat yamalarini geri al. kayit_id verilmezse stat setlerine ait TUM aktif yamalar."""
    from export3d import kur_mesh as KM
    forge = _forge_yolu(forge)
    if kayit_id:
        return KM.geri_al(kayit_id)
    hedef = [k["id"] for k in durum(forge).get("kayitlar") or []]
    if not hedef:
        return {"ok": False, "mesaj": "No weapon-stat patch is installed."}
    out = []
    for kid in reversed(hedef):
        out.append(KM.geri_al(kid))
    return {"ok": all(o.get("ok") for o in out), "sonuc": out,
            "mesaj": "Reverted %d patch(es)." % len(out)}


# ================================================================ SILAH ODAKLI API
# Weapons sekmesi "Weapon_Sword_19" gibi bir ANAHTAR ile calisiyor; stat sistemi ise
# u64 ITEM kimlikleriyle. Kopru = (tur, no) ikilisi (olculdu: 56 gercek silahin
# tamami eslesiyor, 32 Trinket eslesmiyor cunku stat katalogunda hic trinket yok).
# Bir silahin BIRDEN COK item kimligi vardir (sag/sol el, vitrin kopyasi, Rift surumu);
# bir degisiklik uygulandiginda hepsi AYNI degere tasinir.

def _gost(tur, v):
    """Degeri gosterim bicimine cevir (tam sayi / gereksiz sifirsiz ondalik)."""
    if tur == "int":
        return "%d" % int(round(float(v)))
    t = ("%.4f" % float(v)).rstrip("0").rstrip(".")
    return t or "0"


def _esit(tur, a, b):
    """Iki stat degeri ayni mi (int tam, float 1e-4 toleransli)."""
    try:
        if tur == "int":
            return int(round(float(a))) == int(round(float(b)))
        return abs(float(a) - float(b)) <= 1e-4
    except (TypeError, ValueError):
        return False


def _kural3_gecerli_mi(tekil):
    """COZUM KURALI 3'un KAPISI.

    Istenen deger mevcut hicbir kademede/tabanda yoksa, deger ancak silah o kademede
    YALNIZSA degistirilebilir; yoksa ayni kademedeki baska silahlari da degistirirdik.
    Ayri fonksiyon olmasinin sebebi: test 15 bu kapiyi kaldirip AYNI cagrinin gectigini
    gostererek kapinin gercekten is yaptigini kanitlar.
    """
    return bool(tekil)


def _kart_verisi(forge=None):
    """Silah kartlari + uyelik/paylasim tablolari (salt okuma, tek forge turu)."""
    r = oku(forge)
    kat = katalog()
    imap = _item_haritasi()
    setler = dict((s["anahtar"], s) for s in r["setler"])
    sirali_set = list(r["setler"])

    # --- kartlar ve item -> silah anahtari haritasi
    kartlar, indeks, sahip, ad_of = [], {}, {}, {}
    for w in kart_katalog():
        item = imap.get((w["tur"], w["no"])) if w["tur"] else None
        k = {"anahtar": w["anahtar"], "gorunen": w["gorunen"], "tur": w["tur"],
             "no": w["no"], "item": ["0x%012X" % i for i in (item or [])],
             "satirlar": [], "duzenlenebilir": bool(item)}
        if not item:
            k["not"] = "This item has no editable stats."
        for i in (item or []):
            sahip[i] = w["anahtar"]
        ad_of[w["anahtar"]] = w["gorunen"]
        kartlar.append(k)
        indeks[k["anahtar"]] = k

    # --- her set icin: item -> kademe, kademe -> o kademeyi kullanan SILAH anahtarlari
    uyelik, paylasim = {}, {}
    for s in sirali_set:
        a = s["anahtar"]
        u, p = {}, {}
        for kd in s["kademeler"]:
            grup = p.setdefault(kd["i"], set())
            for x in kd["silahlar"]:
                iid = int(x["id"], 16)
                u[iid] = kd["i"]
                key = sahip.get(iid) or x["id"]     # katalog disi uye = kendi basina silah
                grup.add(key)
                ad_of.setdefault(key, x["gorunen"] or x["id"])
        uyelik[a] = u
        paylasim[a] = p

    # --- 1. gecis: her silah her sette hangi kademede (temsilci = Rift OLMAYAN kopya)
    taban_kullanan = dict((s["anahtar"], set()) for s in sirali_set)
    for k in kartlar:
        k["_yer"] = {}
        if not k["duzenlenebilir"]:
            continue
        ids = [int(x, 16) for x in k["item"]]
        for s in sirali_set:
            if s["tur"] != k["tur"]:
                continue
            a = s["anahtar"]
            uy = [(i, uyelik[a][i]) for i in ids if i in uyelik[a]]
            hepsi = sorted(set(t for _i, t in uy))
            nr = sorted(set(t for i, t in uy if not (kat.get(i) or {}).get("rift")))
            kademe = nr[0] if nr else None
            karisik = len(hepsi) > 1 or (bool(hepsi) and not nr)
            k["_yer"][a] = (kademe, karisik)
            if kademe is None:
                taban_kullanan[a].add(k["anahtar"])

    # --- 2. gecis: satirlar (paylasan sayilari 1. gecisin sonucuna dayanir)
    for k in kartlar:
        if not k["duzenlenebilir"]:
            continue
        for s in sirali_set:
            if s["tur"] != k["tur"]:
                continue
            a = s["anahtar"]
            kademe, karisik = k["_yer"][a]
            tv = s["taban"]["tur"]
            sec = [{"kademe": None, "deger": s["taban"]["deger"],
                    "paylasan": len(taban_kullanan[a] - {k["anahtar"]})}]
            for kd in s["kademeler"]:
                sec.append({"kademe": kd["i"], "deger": kd["etkin"],
                            "paylasan": len(paylasim[a].get(kd["i"], set())
                                            - {k["anahtar"]})})
            satir = {"set": a, "ad": s["kart"], "kisa": s["kisa"], "tur_deger": tv,
                     "deger": (s["taban"]["deger"] if kademe is None
                               else s["kademeler"][kademe]["etkin"]),
                     "varsayilan": s["taban"]["deger"],
                     "kademe": kademe, "secenekler": sec, "karisik": bool(karisik),
                     "kademeler_item": dict((x, uyelik[a].get(int(x, 16)))
                                            for x in k["item"])}
            if karisik:
                satir["karisik_metin"] = (
                    "This weapon shares its item entries with copies that are not all "
                    "on the same value right now; applying a change puts every copy on "
                    "the value you pick.")
            k["satirlar"].append(satir)

    kartlar.sort(key=lambda x: (not x["duzenlenebilir"], x["tur"] or "",
                                x["no"] if x["no"] is not None else 0,
                                x["gorunen"].lower()))
    return {"silahlar": kartlar, "indeks": indeks, "setler": setler,
            "sirali_set": sirali_set, "uyelik": uyelik, "paylasim": paylasim,
            "taban_kullanan": taban_kullanan, "ad_of": ad_of,
            "hatalar": r.get("hatalar") or [], "yamali": bool(r.get("yamali")),
            "forge": r.get("forge")}


def silah_kartlari(forge=None):
    """Weapons sekmesindeki HER silah icin duzenlenebilir stat satirlari.

    Kart: {"anahtar","gorunen","tur","item":[...],"satirlar":[...]}
    Stat sistemine baglanamayan girisler (Trinket'ler) "duzenlenebilir": False ve
    "not": "This item has no editable stats." ile isaretlenir.
    """
    try:
        v = _kart_verisi(forge)
    except Exception as e:
        return {"ok": False, "silahlar": [], "hatalar": [{"set": "*", "mesaj": str(e)}],
                "mesaj": str(e)}
    silahlar = []
    for k in v["silahlar"]:
        k = dict(k)
        k.pop("_yer", None)
        silahlar.append(k)
    return {"ok": True, "silahlar": silahlar, "hatalar": v["hatalar"],
            "eslesen": sum(1 for k in silahlar if k["duzenlenebilir"]),
            "eslesmeyen": sum(1 for k in silahlar if not k["duzenlenebilir"]),
            "yamali": v["yamali"], "forge": v["forge"],
            "setler": [{"anahtar": s["anahtar"], "ad": s["ad"], "kart": s["kart"],
                        "kisa": s["kisa"], "tur": s["tur"]}
                       for s in SETLER if s["anahtar"] in v["setler"]]}


def _red(bilgi):
    """Reddedilen plan iskeleti. bilgi = {"mesaj": ...}.

    Sabit mesajlar cagri yerinde DIZE SABITI olarak duruyor ({"mesaj": "..."}) —
    ceviri envanteri Python dosyalarindan tam bu kalibi topluyor.
    """
    out = {"ok": False, "mesaj": "", "adimlar": [], "etkilenen": [],
           "yazilacak": 0, "ham_istekler": [], "uyari": []}
    out.update(bilgi)
    return out


def silah_plani(anahtar, istekler, forge=None):
    """Tek silah icin istenen ETKIN degerleri plana cevir. HICBIR SEY YAZMAZ.

    istekler ornegi: {"sword_dmg": 25, "sword_chain": 4}

    COZUM KURALI:
      1) Istenen deger zaten bir kademede (ya da tabanda) varsa -> silahin TUM item
         kimlikleri oraya tasinir; baska hicbir silah etkilenmez.
      2) Degilse ve silah su anki kademesinde YALNIZSA -> o kademenin degeri degisir.
      3) Degilse REDDEDILIR; mesaj ulasilabilir degerleri sayar.
      (pistol_dmg'de hic kademe yok: yalniz taban degistirilebilir ve bu TUM
       tabancalari etkiler -> "etkilenen" listesinde acikca bildirilir.)
    """
    try:
        v = _kart_verisi(forge)
    except Exception as e:
        return _red({"mesaj": str(e)})
    k = v["indeks"].get(anahtar)
    if k is None:
        return _red({"mesaj": "Unknown weapon."})
    if not k["duzenlenebilir"]:
        return _red({"mesaj": "This item has no editable stats."})
    satir_of = dict((x["set"], x) for x in k["satirlar"])
    ham, adimlar, etkilenen, uyari = [], [], [], []

    for s in SETLER:                       # kararli sira
        a = s["anahtar"]
        if a not in (istekler or {}):
            continue
        satir = satir_of.get(a)
        if satir is None:
            return _red({"mesaj": "This weapon does not have that stat."})
        canli = v["setler"][a]
        tv = satir["tur_deger"]
        try:
            V = float(istekler[a])
        except (TypeError, ValueError):
            return _red({"mesaj": "%s cannot be set: %r is not a number."
                                  % (satir["ad"], istekler[a])})
        if _esit(tv, V, satir["deger"]) and not satir["karisik"]:
            continue                       # zaten bu degerde, dokunmaya gerek yok

        # --- KURAL 1: istenen deger zaten bir kademede/tabanda var mi
        hedef = None
        for sc in satir["secenekler"]:
            if _esit(tv, sc["deger"], V):
                hedef = sc
                break
        if hedef is not None:
            t = hedef["kademe"]
            # item kimlikleri HEX DIZE olarak tasinir: u64 degerler JSON/JS'te
            # 2^53 sinirini asabilir, sayi olarak gecerlerse sessizce yuvarlanirlar.
            for iid_s in k["item"]:
                cur = v["uyelik"][a].get(int(iid_s, 16))
                if t is None:
                    if cur is not None:
                        ham.append({"set": a, "silah": iid_s, "kademe": None})
                elif cur != t:
                    ham.append({"set": a, "silah": iid_s, "kademe": t})
            if satir["karisik"]:
                uyari.append(satir["karisik_metin"])
            adimlar.append(
                "%s: %s becomes %s. All %d item entries of this weapon move onto a "
                "value the game already has, so no other weapon changes."
                % (satir["ad"], _gost(tv, satir["deger"]), _gost(tv, V),
                   len(k["item"])))
            continue

        # --- KURAL 2 / 3: degeri degistirmek gerekiyor
        cur_t = satir["kademe"]
        if cur_t is None:
            tekil = not canli["kademeler"]      # pistol_dmg: kademe yok, yalniz taban
        else:
            tekil = not (v["paylasim"][a].get(cur_t, set()) - {anahtar})
        if not _kural3_gecerli_mi(tekil):
            secilebilir = ", ".join(_gost(tv, sc["deger"])
                                    for sc in satir["secenekler"])
            if cur_t is None:
                neden = ("this weapon uses the shared base value, and changing that "
                         "would change every other weapon of the same type")
            else:
                ortak = sorted(v["paylasim"][a].get(cur_t, set()) - {anahtar})
                neden = ("the value it uses is shared with %d other weapon(s), and "
                         "changing it would change them too" % len(ortak))
            return _red({"mesaj": "%s cannot be set to %s on this weapon because "
                                  "%s. Available values: %s."
                                  % (satir["ad"], _gost(tv, V), neden, secilebilir)})

        if cur_t is None:
            ham.append({"set": a, "taban": V})
            digerleri = [w["gorunen"] for w in v["silahlar"]
                         if w["duzenlenebilir"] and w["tur"] == canli["tur"]
                         and w["anahtar"] != anahtar]
            if digerleri:
                etkilenen.append({"set": a, "silahlar": digerleri})
            if a == "pistol_dmg":
                uyari.append("Every pistol reads the same base damage, so changing it "
                             "changes the damage of every pistol in the game.")
            adimlar.append(
                "%s: base value %s becomes %s. This is the shared base, so it applies "
                "to every %s in the game."
                % (satir["ad"], _gost(tv, satir["deger"]), _gost(tv, V), canli["tur"]))
        else:
            ham.append({"set": a, "kademe": cur_t, "etkin": V})
            ortak = sorted(v["paylasim"][a].get(cur_t, set()) - {anahtar})
            if ortak:
                etkilenen.append({"set": a,
                                  "silahlar": [v["ad_of"].get(x, x) for x in ortak]})
                adimlar.append(
                    "%s: %s becomes %s. WARNING: %d other weapon(s) share that value "
                    "and change with it."
                    % (satir["ad"], _gost(tv, satir["deger"]), _gost(tv, V),
                       len(ortak)))
            else:
                adimlar.append(
                    "%s: %s becomes %s. This weapon is the only one on that value, so "
                    "no other weapon changes."
                    % (satir["ad"], _gost(tv, satir["deger"]), _gost(tv, V)))

    if not ham:
        return {"ok": True, "adimlar": [], "etkilenen": [], "yazilacak": 0,
                "ham_istekler": [], "uyari": [], "anahtar": anahtar,
                "silah": k["gorunen"],
                "mesaj": "Nothing to change - this weapon already uses the values "
                         "you asked for."}
    try:
        isler = hazirla(ham, forge)
    except Exception as e:
        return {"ok": False, "mesaj": str(e), "adimlar": adimlar,
                "etkilenen": etkilenen, "yazilacak": 0, "ham_istekler": ham,
                "uyari": uyari, "anahtar": anahtar, "silah": k["gorunen"]}
    return {"ok": True, "mesaj": "The plan is ready.", "adimlar": adimlar,
            "etkilenen": etkilenen, "yazilacak": len(isler), "ham_istekler": ham,
            "uyari": uyari, "anahtar": anahtar, "silah": k["gorunen"],
            "degisim": [{"set": i["set"], "adimlar": i["degisim"],
                         "eski_bayt": i["eski_bayt"], "yeni_bayt": i["yeni_bayt"]}
                        for i in isler]}


def silah_uygula(anahtar, istekler, forge=None, etiket="", ilerleme=None):
    """Tek silahin stat isteklerini arsive kur (plan -> uygula). uygula() sozlesmesi."""
    p = silah_plani(anahtar, istekler, forge)
    if not p.get("ok"):
        return {"ok": False, "mesaj": p.get("mesaj") or "", "plan": p}
    if not p.get("ham_istekler"):
        return {"ok": False, "mesaj": p.get("mesaj") or "Nothing to change.", "plan": p}
    r = uygula(p["ham_istekler"], forge=forge,
               etiket=etiket or ("weapon stats: %s" % (p.get("silah") or anahtar)),
               ilerleme=ilerleme)
    r["plan"] = p
    return r
