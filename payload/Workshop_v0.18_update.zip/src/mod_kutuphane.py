# -*- coding: utf-8 -*-
"""mod_kutuphane -- uygulamadan cikmadan mod BUL + INDIR + DOGRULA.

NEDEN: Anvil bir YARATICI araci; mod KURUCUSU yok. Kullanicinin modu bulmak icin tarayici
acmasi, zip'i elle indirmesi, elle acmasi ve dogru klasoru bulmasi gerekiyor. Bu modul o
zinciri tek dugmeye indirir.

YENI PROTOKOL YOK: guncelle.py'nin GitHub release kanali zaten calisiyor (surum.json + zip +
sha256 + izin listesi). Burada AYNI desen kullanilir, yalniz dosya adi farkli:
    surum kanali : <repo>/main/surum.json        -> guncelle.py  (uygulamanin kendisi)
    mod kanali   : <repo>/main/mod_katalog.json  -> bu modul     (kullanici modlari)
Ortak parcalar guncelle.py'den CAGRILIR (_sha, _http_oku, _url_guvenli), kopyalanmaz.

BU MODULUN SINIRI: "bul + indir + dogrula". KURULUM BU MODULUN ISI DEGIL -- indirilen ve
acilan klasor M2'nin kurucusuna verilir (outfit icin sunucu.py'deki standart apply kapisi,
gemi icin ship_core.mod_kur, .forge icin sunucu.py patch_02 kurulumu). Burada oyun
arsivine TEK BAYT yazilmaz; hicbir dosya oyun klasorune dokunmaz.

AKIS
  katalog(progress) -> GitHub'daki mod_katalog.json indirilir, sema DOGRULANIR, cevrimdisi
                       kullanim icin %LOCALAPPDATA%'ya onbelleklenir. Ag yoksa ya da sunucudaki
                       JSON bozuksa ONBELLEK gosterilir ve durum "offline" olur (COKMEZ).
  indir(mod_id)     -> zip akisla iner, boyut siniri uygulanir, sha256 DOGRULANIR (tutmazsa
                       dosya silinir ve is orada biter), zip icerigi denetlenir (yol kacisi,
                       program dosyasi, zip bombasi), sonra gecici klasore acilir.

GUVENLIK KAPILARI (hepsi fail-closed)
  1. Adres kapisi : yalniz https + BEYAZ LISTEDEKI host. "https://raw.githubusercontent.com
     @evil.com/x" gibi kullanici-bilgisi hilesi de duser (hostname'e bakilir, dizeye degil).
     Kapi ILK adrese degil HER YONLENDIRME ADIMINA uygulanir (bkz. _YonlendirmeKapisi:
     ciplak urlopen 302'yi sessizce izleyip listede olmayan bir hosttan indiriyordu) ve
     adim sayisi AZAMI_YONLENDIRME ile sinirlidir. Reddedilen yonlendirme kullaniciya
     NEREYE gidilmek istendigi soylenerek bildirilir.
  2. sha256       : beyan edilen ozet tutmazsa indirme REDDEDILIR, sessizce devam edilmez.
  3. Boyut        : indirme ve acilmis boyut tavani; beyan edilen boyut tutmazsa red.
     Katalog govdesi de sinirli okunur (sunucu sinirsiz govde yollayamaz).
  4. Zip icerigi  : mutlak yol / ".." / surucu harfi / ":" (NTFS gizli akisi) / kisayol
     (symlink) / kuyrukta nokta-bosluk / aygit adi -> red. Bu ad kurallari BU MODULDE
     DEGIL, mod_paket.arsiv_uye_denetle'de tek nusha durur; kullanicinin surukleyip
     biraktigi paket de ayni kapidan gecer. Bu kanalin KENDI politikasi (program dosyasi
     ve dar uzanti beyaz listesi) o kapiya parametre olarak verilir. Acilirken ad kapisi
     IKINCI kez sorulur ve gercekten yazilan bayt sayilir (file_size yalan soyleyebilir).
  5. Katalog metni: kontrol karakterleri temizlenir, alanlar kirpilir; bozuk giris tum katalogu
     dusurmez, YALNIZ o giris atlanir ve sebebi raporlanir.

NEXUS KAZIMA (scraping) YOK. Katalog elle doldurulur; her girisin `nexus_url` alani ozgun mod sayfasina
bakar (kaynaga saygi). Sema ornegi: build/mod_katalog_ornek.json.

Kod yorumlari Turkce (ASCII), kullaniciya gorunen her metin Ingilizce tam cumledir.
"""
import io
import json
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.request
import zipfile
from urllib.parse import urlsplit

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)
import guncelle as _G                                    # noqa: E402  (ayni yayin kanali)
import mod_paket as _MP                                  # noqa: E402  (TEK arsiv uye kapisi)

__all__ = ["katalog", "indir", "mod_bul", "durum", "onbellek_temizle",
           "KATALOG_URL", "VERI_KOK", "SEMA_ALANLARI", "YonlendirmeReddi",
           "AZAMI_YONLENDIRME"]

# --------------------------------------------------------------------------- kanal
# Surum kanaliyla AYNI repo, ayri dosya. ayarlar.json'daki "mod_katalog_url" bunu ezer
# (test / kendi listesini barindiran kullanici). Bos birakilirsa kutuphane kapali.
KATALOG_URL = "https://raw.githubusercontent.com/caoscomtr/workshop-updates/main/mod_katalog.json"

# Indirme yalniz bu hostlardan yapilir. Katalogu kaptan doldursa bile adres bu listenin
# disindaysa dosya indirilmez -- katalog ele gecse dahi rastgele bir sunucuya gidilmez.
INDIRME_HOSTLAR = frozenset((
    "github.com",
    "raw.githubusercontent.com",
    "objects.githubusercontent.com",
    "release-assets.githubusercontent.com",
    "codeload.github.com",
))
# Kapak gorseli tarayici tarafindan cekilir -> kullanicinin IP'si oraya gider. Bu yuzden
# gorsel adresi de beyaz listeye tabi; disaridaysa gorsel BOSALTILIR (giris atilmaz).
GORSEL_HOSTLAR = INDIRME_HOSTLAR | frozenset(("staticdelivery.nexusmods.com",))
# Kaynak linki: yalniz gercek Nexus mod sayfasi.
NEXUS_HOSTLAR = frozenset(("nexusmods.com", "www.nexusmods.com"))
YEREL_HOSTLAR = frozenset(("127.0.0.1", "localhost"))

VERI_KOK = os.path.join(os.environ.get("LOCALAPPDATA") or
                        os.path.join(os.path.expanduser("~"), "AppData", "Local"),
                        "OutfitWorkshop", "mod_kutuphane")

# --------------------------------------------------------------------------- sinirlar
AZAMI_KATALOG_BAYT = 4 * 1024 * 1024          # katalog JSON'u
AZAMI_INDIRME = 1024 * 1024 * 1024            # tek mod zip'i (sikisik)
AZAMI_ACIK_BOYUT = 512 * 1024 * 1024          # acilmis toplam
AZAMI_UYE = 5000                              # zip icindeki dosya sayisi
AZAMI_ORAN = 200                              # acilmis / sikisik oran tavani (zip bombasi)
ORAN_TABANI = 8 * 1024 * 1024                 # oran kapisi bu boyutun UZERINDE devreye girer
KATALOG_ZAMAN_ASIMI = 20
INDIRME_ZAMAN_ASIMI = 180
# Yonlendirme (302) adim tavani. GitHub surum dosyalari normalde TEK adim atlar
# (github.com -> objects.githubusercontent.com); 5 fazlasiyla yeterli.
AZAMI_YONLENDIRME = 5

# Mod arsivinde bulunmasina IZIN VERILEN dosya turleri (beyaz liste = fail-closed).
IZINLI_UZANTI = frozenset((
    ".png", ".dds", ".tga", ".jpg", ".jpeg", ".bmp", ".webp",     # doku / gorsel
    ".forge", ".bin", ".dat",                                     # oyun verisi / hazir yama
    ".glb", ".gltf", ".fbx", ".obj", ".mtl",                      # 3B model
    ".wav", ".ogg", ".wem",                                       # ses
    ".json", ".txt", ".md", ".ini", ".cfg", ".csv", ".xml",       # aciklama / ayar
))
# Beyaz listeye ragmen ayrica ADI KONAN yasak: mesaj kullaniciya "program dosyasi" desin.
YASAK_UZANTI = frozenset((
    ".exe", ".dll", ".pyd", ".bat", ".cmd", ".ps1", ".vbs", ".scr", ".com", ".msi",
    ".js", ".jar", ".lnk", ".reg", ".sh", ".py", ".pyw", ".hta", ".cpl", ".sys",
))

SEMA_ALANLARI = ("id", "ad", "yazar", "aciklama", "gorsel_url", "boyut", "sha256",
                 "indirme_url", "etiketler", "surum", "tarih", "nexus_url")
ZORUNLU_ALANLAR = ("id", "ad", "sha256", "indirme_url")

_ID_DESEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
_SHA_DESEN = re.compile(r"[0-9a-f]{64}\Z")


def _log(progress, s):
    if progress:
        try:
            progress(s)
        except Exception:                                   # noqa: BLE001
            pass


def _metin(v, azami=400):
    """Katalogdan gelen metni guvenli hale getirir: kontrol karakteri yok, kirpilmis."""
    s = "" if v is None else str(v)
    s = "".join(ch for ch in s if (ch >= " " and ch != "\x7f") or ch == "\n")
    return s.replace("\n", " ").strip()[:azami]


def _guvenli_ad(s, azami=64):
    """Dosya/klasor adi olarak kullanilabilir hale getirir (kullanici verisi -> disk yolu)."""
    out = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in str(s or ""))
    return (out.strip("._-") or "mod")[:azami]


def _url_guvenli(u, hostlar=None):
    """guncelle.py'nin sema kapisi + HOST beyaz listesi.

    guncelle._url_guvenli yalniz "https:// ile basliyor mu" der; mod indirmesi ucuncu-sahis
    icerik oldugu icin bize host da lazim. urlsplit kullanilir: "https://raw.github
    usercontent.com@evil.com/x" gibi kullanici-bilgisi hilesinde hostname 'evil.com' cikar."""
    u = str(u or "").strip()
    if not u or not _G._url_guvenli(u):
        return False
    p = urlsplit(u)
    h = (p.hostname or "").lower()
    if not h:
        return False
    if h in YEREL_HOSTLAR:                       # yalniz test / kendi sunucusu
        return p.scheme in ("http", "https")
    if p.scheme != "https":
        return False
    return h in (INDIRME_HOSTLAR if hostlar is None else hostlar)


# --------------------------------------------------------------- yonlendirme kapisi
class YonlendirmeReddi(Exception):
    """Beyaz liste disina yonlendirme (ya da cok fazla adim).

    Mesaji DOGRUDAN kullaniciya gider: ne oldugunu ve NEREYE gidilmek istendigini
    soyler. 'Baglanti kurulamadi' demek yanlis olurdu -- sunucu cevap verdi,
    reddeden BIZ'iz."""


class _YonlendirmeKapisi(urllib.request.HTTPRedirectHandler):
    """Her 302/301/303/307/308 adimini beyaz listeden gecirir.

    NEDEN VAR (2026-09-07 olculdu): ciplak urllib.request.urlopen yonlendirmeyi
    SESSIZCE takip ediyordu. `_url_guvenli("http://127.0.0.2/gercek.zip")` False
    dedigi halde, beyaz listedeki 127.0.0.1'in verdigi 302 izlenip dosya
    127.0.0.2'den indi ve indir() ok=True dondu. Yani kapi yalniz ILK adrese
    bakiyordu; modulun 'katalog ele gecse dahi rastgele bir sunucuya gidilmez'
    sozu tutmuyordu. Adres kapisi artik HER adimda calisir."""

    def __init__(self, hostlar, azami=AZAMI_YONLENDIRME):
        self.hostlar = hostlar
        self.azami = azami
        self.adim = 0

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # urllib newurl'u BURAYA gelmeden once mutlak hale getiriyor
        # (http_error_302 icinde urljoin) -- goreli adres de host kapisina takilir.
        self.adim += 1
        if self.adim > self.azami:
            raise YonlendirmeReddi(
                "the download address kept sending this Workshop on to another address "
                "more than %d times, so nothing was downloaded." % self.azami)
        if not _url_guvenli(newurl, self.hostlar):
            nereye = (urlsplit(newurl).hostname or str(newurl)[:80] or "an unnamed address")
            raise YonlendirmeReddi(
                "the download address sent this Workshop on to %s, which is not one of the "
                "addresses mods are allowed to come from, so nothing was downloaded."
                % nereye)
        return urllib.request.HTTPRedirectHandler.redirect_request(
            self, req, fp, code, msg, headers, newurl)


def _acici(hostlar):
    """Yonlendirmeyi denetleyen opener. HER istek icin YENI (adim sayaci temiz)."""
    return urllib.request.build_opener(_YonlendirmeKapisi(hostlar))


def _istek(u, hostlar, zaman):
    """Adres kapisindan gecmis, yonlendirmesi denetlenen HTTP cevabi dondurur."""
    if not _url_guvenli(u, hostlar):
        raise YonlendirmeReddi("that address is not one of the addresses mods are allowed "
                               "to come from, so nothing was downloaded.")
    req = urllib.request.Request(u, headers={"User-Agent": "Workshop-ModLibrary/1.0",
                                             "Cache-Control": "no-cache"})
    return _acici(hostlar).open(req, timeout=zaman)


def _http_oku(u, hostlar, zaman, azami):
    """Katalog govdesini okur. guncelle._http_oku KULLANILMAZ, cunku o (a) host
    kapisi tanimiyor, (b) yonlendirmeyi denetlemiyor, (c) govdeyi SINIRSIZ
    okuyor. Ortak kalan parcalar hala guncelle'den geliyor (_sha, _url_guvenli)."""
    with _istek(u, hostlar, zaman) as r:
        return r.read(azami)


def _url(ayar=None):
    """Katalog adresi: ayar sozlugu -> sunucu ayarlari -> gomulu varsayilan."""
    ov = (ayar or {}).get("mod_katalog_url") if isinstance(ayar, dict) else None
    if ov is None:
        try:
            import importlib
            su = importlib.import_module("sunucu")
            ov = (su.ayar_oku() or {}).get("mod_katalog_url")
        except Exception:                                   # noqa: BLE001
            ov = None
    return (ov if ov is not None else KATALOG_URL or "").strip()


# --------------------------------------------------------------------------- sema
def _kayit_dogrula(ham):
    """Tek katalog girisini semaya gore dogrular. Doner (kayit, sebep).

    kayit None ise giris ATLANIR (sebep raporlanir); tek bozuk giris tum katalogu dusurmez."""
    if not isinstance(ham, dict):
        return None, "the entry is not a record"
    mid = _metin(ham.get("id"), 64)
    if not mid or not _ID_DESEN.match(mid):
        return None, ("the id is missing or has characters that cannot be used in a file name "
                      "(letters, digits, dot, dash and underscore only)")
    # BAGLANTI GIRISI (tur="baglanti"): mod BIZDE BARINMAZ, yalniz Nexus sayfasina goturur.
    # Neden var: indirme beyaz listesi yalniz GitHub oldugu icin, barindirilan her giris
    # baskasinin modunu YENIDEN YAYINLAMAK demek -- yazar izni olmadan yapilamaz ve mod 197'yi
    # telif sikayetine acar. Baglanti girisi izin gerektirmez: kullanici Nexus'tan indirir,
    # zip'i birakma alanina surukler, gerisi ayni akis. Bu tur icin sha256/indirme_url ARANMAZ,
    # nexus_url ZORUNLUDUR (yoksa giris bir yere goturmez).
    tur = _metin(ham.get("tur"), 20).lower() or "barindirilan"
    if tur not in ("barindirilan", "baglanti"):
        return None, "the entry type must be either a hosted download or a link"
    if tur == "baglanti":
        nexus = _metin(ham.get("nexus_url"), 600)
        if not nexus or not _url_guvenli(nexus, NEXUS_HOSTLAR):
            return None, ("a link entry must carry the address of its Nexus Mods page, "
                          "because that is where the file is downloaded from")
        zorunlu = ("id", "ad")
    else:
        zorunlu = ZORUNLU_ALANLAR
    eksik = [a for a in zorunlu if not _metin(ham.get(a), 200)]
    if eksik:
        return None, "these required fields are empty: %s" % ", ".join(eksik)
    sha = _metin(ham.get("sha256"), 80).lower()
    ind = _metin(ham.get("indirme_url"), 600)
    if tur == "baglanti":
        sha, ind = "", ""                    # barindirilmiyor: dogrulanacak dosya YOK
    else:
        if not _SHA_DESEN.match(sha):
            return None, "the checksum is not a 64 character sha256 value"
        if not _url_guvenli(ind, INDIRME_HOSTLAR):
            return None, ("the download address is not on the allowed list (mods are served from "
                          "the project's own release page)")
    try:
        boyut = int(ham.get("boyut") or 0)
    except (TypeError, ValueError):
        return None, "the size is not a number"
    if boyut < 0 or boyut > AZAMI_INDIRME:
        return None, ("the size is outside the allowed range (up to %d MB)"
                      % (AZAMI_INDIRME // (1 << 20)))
    etiketler = ham.get("etiketler")
    if not isinstance(etiketler, (list, tuple)):
        etiketler = []
    # Gorsel ve kaynak linki KOZMETIK: adres beyaz liste disindaysa girisi atmayiz, yalniz o
    # alani bosaltip kullaniciya sebebini soyleriz (mod yine de listelenir ve kurulabilir).
    uyari = []
    gorsel = _metin(ham.get("gorsel_url"), 600)
    if gorsel and not _url_guvenli(gorsel, GORSEL_HOSTLAR):
        gorsel = ""
        uyari.append("The preview image comes from an address that is not on the allowed list, "
                     "so no image is shown for this mod.")
    nexus = _metin(ham.get("nexus_url"), 600)
    if nexus and not _url_guvenli(nexus, NEXUS_HOSTLAR):
        nexus = ""
        uyari.append("The source link is not a Nexus Mods page, so it was left out.")
    if tur == "baglanti" and not nexus:
        return None, "a link entry must carry the address of its Nexus Mods page"
    return ({"id": mid,
             "tur": tur,
             "ad": _metin(ham.get("ad"), 120),
             "yazar": _metin(ham.get("yazar"), 80),
             "aciklama": _metin(ham.get("aciklama"), 1200),
             "gorsel_url": gorsel,
             "boyut": boyut,
             "sha256": sha,
             "indirme_url": ind,
             "etiketler": [_metin(e, 40) for e in etiketler[:20] if _metin(e, 40)],
             "surum": _metin(ham.get("surum"), 40),
             "tarih": _metin(ham.get("tarih"), 40),
             "nexus_url": nexus,
             "uyari": uyari}, "")


def _ayikla(veri):
    """Katalog govdesinden gecerli mod listesi cikarir. Doner (modlar, atlanan)."""
    if isinstance(veri, dict):
        ham = veri.get("modlar")
    elif isinstance(veri, list):
        ham = veri
    else:
        ham = None
    if not isinstance(ham, list):
        return None, [{"id": "", "sebep": "the mod list is missing from the catalogue file"}]
    modlar, atlanan, gorulen = [], [], set()
    for g in ham:
        kayit, sebep = _kayit_dogrula(g)
        if kayit is None:
            kimlik = _metin((g or {}).get("id"), 64) if isinstance(g, dict) else ""
            atlanan.append({"id": kimlik, "sebep": sebep})
            continue
        if kayit["id"] in gorulen:
            atlanan.append({"id": kayit["id"], "sebep": "another entry already uses this id"})
            continue
        gorulen.add(kayit["id"])
        modlar.append(kayit)
    return modlar, atlanan


# --------------------------------------------------------------------------- onbellek
def _onbellek_yolu():
    return os.path.join(VERI_KOK, "katalog.json")


def _onbellek_yaz(ham):
    """Yalniz AYRISTIRILMIS ve semadan gecmis katalog onbellege yazilir."""
    try:
        os.makedirs(VERI_KOK, exist_ok=True)
        y = _onbellek_yolu()
        with open(y + ".yeni", "wb") as f:
            f.write(ham)
        os.replace(y + ".yeni", y)
        with io.open(y + ".meta", "w", encoding="utf-8") as f:
            json.dump({"zaman": time.strftime("%Y-%m-%d %H:%M:%S"),
                       "sha256": _G._sha(y), "boyut": len(ham)}, f, indent=1)
        return True
    except Exception:                                       # noqa: BLE001
        return False


def _onbellek_oku():
    """Doner (veri, zaman) -- yoksa (None, None)."""
    y = _onbellek_yolu()
    try:
        with io.open(y, encoding="utf-8") as f:
            veri = json.load(f)
    except Exception:                                       # noqa: BLE001
        return None, None
    zaman = None
    try:
        with io.open(y + ".meta", encoding="utf-8") as f:
            zaman = (json.load(f) or {}).get("zaman")
    except Exception:                                       # noqa: BLE001
        pass
    return veri, zaman


def onbellek_temizle():
    """Onbellegi ve indirilmis dosyalari siler (kullanici 'clear cache' derse)."""
    n = 0
    for alt in ("katalog.json", "katalog.json.meta"):
        p = os.path.join(VERI_KOK, alt)
        if os.path.isfile(p):
            os.remove(p)
            n += 1
    for alt in ("indirilen", "acik"):
        p = os.path.join(VERI_KOK, alt)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            n += 1
    return {"ok": True, "silinen": n,
            "mesaj": "The downloaded mod list and files were removed."}


# --------------------------------------------------------------------------- katalog
def katalog(progress=None, ayar=None, yenile=True):
    """Mod listesini getirir. Ag yoksa ya da sunucudaki dosya bozuksa ONBELLEGE duser.

    Doner {ok, kaynak, cevrimdisi, modlar, atlanan, sayi, url, onbellek_zamani, mesaj}
      kaynak: "network" | "onbellek" | "yok"
    ok=False YALNIZ hicbir liste gosterilemiyorsa (ne ag ne onbellek)."""
    u = _url(ayar)
    ham, hata = None, ""
    # ag_hatasi: "internet yok / sunucuya ulasilamadi" mi, yoksa "adres kapali/reddedildi" mi?
    # Ikisine ayni mesaji vermek yanlis olur -- kapali adres icin "offline" demeyiz.
    ag_hatasi = False
    if not u:
        hata = "The mod library is switched off because no list address is set."
    elif not _url_guvenli(u, INDIRME_HOSTLAR):
        hata = "The mod list address is not on the allowed list, so it was not opened."
    elif yenile:
        _log(progress, "- checking the mod list ...")
        try:
            ham = _http_oku(u, INDIRME_HOSTLAR, KATALOG_ZAMAN_ASIMI, AZAMI_KATALOG_BAYT + 1)
            if len(ham) > AZAMI_KATALOG_BAYT:
                ham, hata = None, ("The mod list on the server is unusually large, so it was "
                                   "not used.")
        except YonlendirmeReddi as e:
            # Adres kapisi devrede: sunucu cevap verdi ama bizi listede olmayan bir
            # yere yolladi. Bu CEVRIMDISI DEGILDIR, o yuzden "offline" demiyoruz.
            ham = None
            hata = str(e).replace("nothing was downloaded", "the list was not read")
        except urllib.error.HTTPError as e:
            # Sunucu CEVAP VERDI, dosya yok/hata verdi -> kullanici CEVRIMDISI DEGIL.
            # (404 bugunku normal durum: mod_katalog.json henuz yayinlanmadi.)
            ham = None
            hata = ("No mod list has been published at this address yet."
                    if e.code == 404 else
                    "The server could not send the mod list (error %s)." % e.code)
        except Exception as e:                              # noqa: BLE001
            ham, ag_hatasi = None, True
            hata = ("The mod list could not be downloaded (%s)."
                    % (str(e)[:120] or "no connection"))
    # sunucudan gelen govde: once AYRISTIR, sonra SEMA, ancak ondan sonra onbellege yaz.
    veri, kaynak, zaman = None, "yok", None
    modlar, atlanan = None, None
    if ham is not None:
        try:
            veri = json.loads(ham.decode("utf-8"))
        except Exception as e:                              # noqa: BLE001
            veri, hata = None, ("the mod list on the server is damaged (%s), so the last good "
                                "copy is being shown." % str(e)[:80])
        if veri is not None:
            deneme, atl = _ayikla(veri)
            if deneme is None:
                veri, hata = None, ("The mod list on the server does not have the expected "
                                    "layout, so the last saved copy is being shown.")
            else:
                kaynak, modlar, atlanan = "network", deneme, atl
                _onbellek_yaz(ham)                    # yalniz SEMADAN GECEN govde onbellege
    if veri is None:
        veri, zaman = _onbellek_oku()
        if veri is not None:
            kaynak = "onbellek"
            modlar, atlanan = _ayikla(veri)
    if veri is None:
        return {"ok": False, "kaynak": "yok", "cevrimdisi": True,
                "durum": ("offline" if ag_hatasi else "bos"),
                "modlar": [], "atlanan": [], "sayi": 0, "url": u, "onbellek_zamani": None,
                "mesaj": (("No mod list has been downloaded yet, so there is nothing to show "
                           "while you are offline. %s" % hata) if ag_hatasi else
                          ("There are no mods to show yet. %s" % hata)).strip()}
    modlar = modlar or []
    atlanan = atlanan or []
    cevrimdisi = (kaynak != "network")
    if not cevrimdisi:
        mesaj = "The mod list was updated. %d mod(s) are available." % len(modlar)
    elif ag_hatasi:
        mesaj = ("You are offline, so this is the mod list saved on %s. %d mod(s) are listed. %s"
                 % (zaman or "an earlier visit", len(modlar), hata))
    else:
        mesaj = ("This is the mod list saved on %s. %d mod(s) are listed. %s"
                 % (zaman or "an earlier visit", len(modlar), hata))
    if atlanan:
        mesaj += (" %d entry could not be read and was left out." % len(atlanan)
                  if len(atlanan) == 1 else
                  " %d entries could not be read and were left out." % len(atlanan))
    return {"ok": True, "kaynak": kaynak, "cevrimdisi": cevrimdisi,
            "durum": ("offline" if (cevrimdisi and ag_hatasi) else
                      ("cached" if cevrimdisi else "online")),
            "modlar": modlar, "atlanan": atlanan, "sayi": len(modlar), "url": u,
            "onbellek_zamani": zaman, "mesaj": mesaj.strip()}


def mod_bul(mod_id, ayar=None, yenile=False):
    """Tek mod kaydini dondurur (varsayilan: agi yormadan onbellekten)."""
    k = katalog(ayar=ayar, yenile=yenile)
    for m in k.get("modlar") or []:
        if m["id"] == str(mod_id):
            return m
    return None


# --------------------------------------------------------------------------- zip kapisi
def _uye_mesaji(kod, sebep, ad):
    """Kanonik kapinin KODUNU bu kanalin kullanici cumlesine cevirir.

    Kural TEK yerde (mod_paket.arsiv_uye_denetle); burada yalniz SUNUM var."""
    if kod == "baglanti":
        return ("the mod archive contains a shortcut (symbolic link): %s. It was not "
                "opened." % ad)
    if kod == "program":
        return ("the mod archive contains a program file (%s). Mods may only contain "
                "artwork, models and game data." % ad)
    if kod == "uzanti":
        return ("the mod archive contains a file this Workshop does not know how to "
                "install (%s). It was not opened." % ad)
    if kod in ("bos", "mutlak", "surucu", "akis", "ust"):
        return ("the mod archive tries to write outside its own folder (%s). It was not "
                "opened." % ad)
    return ("the mod archive has a file name Windows cannot store as it is written (%s): "
            "%s. It was not opened." % (sebep, ad))


def _zip_denetle(zip_yolu):
    """Mod arsivi guvenli mi? Doner (ok, sebep, bilgi).

    AD/YOL KURALLARI BURADA DEGIL: mod_paket.arsiv_uye_denetle KANONIK kapidir ve
    kullanicinin surukleyip biraktigi paket de ayni kapidan gecer (bkz. o fonksiyonun
    basindaki gerekce ve olcumler). Burada yalniz BU KANALIN politikasi (dar uzanti
    beyaz listesi) ve BOYUT kapilari var.

    guncelle._zip_denetle uygulamanin KENDI paketi icindir (src/ arayuz/ izinli kokleri);
    mod arsivi doku/model/yama tasir, o yuzden uzanti politikasi ondan da ayridir."""
    acik = sikisik = 0
    n = 0
    with zipfile.ZipFile(zip_yolu) as z:
        uyeler = z.infolist()
        if len(uyeler) > AZAMI_UYE:
            return False, ("the mod archive holds %d files, which is more than this Workshop "
                           "will open (%d)." % (len(uyeler), AZAMI_UYE)), {}
        for zi in uyeler:
            ad = zi.filename.replace("\\", "/")
            if zi.is_dir():
                continue
            n += 1
            ok, kod, sebep = _MP.arsiv_uye_denetle(
                ad, baglanti=_MP.zip_uye_baglanti_mi(zi),
                yasak_uzanti=YASAK_UZANTI, izinli_uzanti=IZINLI_UZANTI)
            if not ok:
                return False, _uye_mesaji(kod, sebep, ad), {}
            acik += zi.file_size
            sikisik += zi.compress_size
            if acik > AZAMI_ACIK_BOYUT:
                return False, ("the mod archive unpacks to more than %d MB, which is larger than "
                               "this Workshop will accept."
                               % (AZAMI_ACIK_BOYUT // (1 << 20))), {}
    if not n:
        return False, "the mod archive is empty.", {}
    if acik > ORAN_TABANI and sikisik > 0 and (acik / float(sikisik)) > AZAMI_ORAN:
        return False, ("the mod archive expands to %d times its download size, which is a sign "
                       "of a damaged or unsafe file. It was not opened."
                       % int(acik / float(sikisik))), {}
    return True, "", {"dosya_sayisi": n, "acik_boyut": acik, "sikisik_boyut": sikisik}


def _ac(zip_yolu, hedef):
    """Arsivi hedef klasore acar. Yol IKINCI kez dogrulanir ve GERCEK bayt sayilir
    (zip basligindaki file_size yalan soyleyebilir). Doner yazilan goreli yollar."""
    if os.path.isdir(hedef):
        shutil.rmtree(hedef)
    os.makedirs(hedef)
    kok = os.path.abspath(hedef)
    yazilan, toplam = [], 0
    with zipfile.ZipFile(zip_yolu) as z:
        for zi in z.infolist():
            if zi.is_dir():
                continue
            rel = zi.filename.replace("\\", "/")
            # Ad kapisi acma aninda TEKRAR sorulur. Yalniz abspath karsilastirmasi
            # YETMIYOR: olculdu (2026-09-07) "resim.png:gizli.exe" hedefin ICINDE
            # kaliyor ama diske NTFS gizli akisi olarak iniyor.
            ok, kod, sebep = _MP.arsiv_uye_denetle(rel,
                                                   baglanti=_MP.zip_uye_baglanti_mi(zi))
            if not ok:
                raise ValueError(_uye_mesaji(kod, sebep, rel))
            p = os.path.abspath(os.path.join(kok, *[x for x in rel.split("/") if x]))
            if p != kok and not p.startswith(kok + os.sep):
                raise ValueError("the mod archive tries to write outside its own folder (%s)."
                                 % rel)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with z.open(zi) as kaynak, open(p, "wb") as f:
                while True:
                    b = kaynak.read(1 << 20)
                    if not b:
                        break
                    toplam += len(b)
                    if toplam > AZAMI_ACIK_BOYUT:
                        raise ValueError("the mod archive unpacks to more than %d MB."
                                         % (AZAMI_ACIK_BOYUT // (1 << 20)))
                    f.write(b)
            yazilan.append(rel)
    return yazilan


def _icerik_ozeti(dosyalar):
    """Kurucuya ve arayuze 'bu pakette ne var' ozeti (duz dille anlatmak icin)."""
    o = {"doku": 0, "yama": 0, "model": 0, "ses": 0, "metin": 0, "diger": 0}
    for d in dosyalar:
        uz = os.path.splitext(d)[1].lower()
        if uz in (".png", ".dds", ".tga", ".jpg", ".jpeg", ".bmp", ".webp"):
            o["doku"] += 1
        elif uz == ".forge":
            o["yama"] += 1
        elif uz in (".glb", ".gltf", ".fbx", ".obj", ".mtl"):
            o["model"] += 1
        elif uz in (".wav", ".ogg", ".wem"):
            o["ses"] += 1
        elif uz in (".txt", ".md", ".json", ".ini", ".cfg", ".csv", ".xml"):
            o["metin"] += 1
        else:
            o["diger"] += 1
    return o


# --------------------------------------------------------------------------- indirme
def _indir_akis(u, hedef, azami, progress=None, beklenen=0, hostlar=None):
    """Akisla indirir (buyuk mod dosyasi bellege sigmayabilir) + tavani asarsa keser.

    Adres kapisi ILK adreste de HER yonlendirme adiminda da calisir (_istek)."""
    n, son = 0, 0
    with _istek(u, hostlar or INDIRME_HOSTLAR, INDIRME_ZAMAN_ASIMI) as r, \
            open(hedef, "wb") as f:
        while True:
            b = r.read(1 << 18)
            if not b:
                break
            n += len(b)
            if n > azami:
                raise ValueError("the file is larger than the %d MB limit."
                                 % (azami // (1 << 20)))
            f.write(b)
            if n - son >= (4 << 20):
                son = n
                if beklenen:
                    _log(progress, "  downloaded %d%% (%.1f MB)"
                         % (min(100, int(n * 100 / beklenen)), n / 1048576.0))
                else:
                    _log(progress, "  downloaded %.1f MB" % (n / 1048576.0))
    return n


def indir(mod_id, progress=None, ayar=None, mod=None):
    """Modu indirir, sha256 DOGRULAR, denetler ve gecici klasore acar.

    Kurmaz -- kurulum M2'nin isi. Doner
    {ok, mod, zip, klasor, dosyalar, icerik, boyut, mesaj}."""
    kayit = mod
    if kayit is None:
        kayit = mod_bul(mod_id, ayar=ayar, yenile=False) or mod_bul(mod_id, ayar=ayar, yenile=True)
    if kayit is None:
        return {"ok": False, "mesaj": ("that mod is not in the list any more. Refresh the mod "
                                       "library and try again.")}
    # Elle verilen kayit da (M2 arayuzden gecirirse) ayni semadan gecer: adres kapisi atlanmaz.
    kayit, sebep = _kayit_dogrula(kayit)
    if kayit is None:
        return {"ok": False, "mesaj": "this mod entry cannot be used: %s." % sebep}
    # BAGLANTI GIRISI: dosya bizde YOK. Indirmeye calismak yerine kullaniciya nereye
    # gidecegini soyleriz; arayuz `ac_adres` alanini tarayicida acar ve indirilen zip
    # normal birakma akisindan kurulur. Bu tur, yazar izni gerektirmeyen tek yoldur.
    if kayit.get("tur") == "baglanti":
        return {"ok": False, "baglanti": True, "mod": kayit,
                "ac_adres": kayit.get("nexus_url"),
                "mesaj": ("This mod is hosted on its own Nexus Mods page, so it is downloaded "
                          "from there. Open the page, download the file, then drop it here and "
                          "it installs the same way.")}

    ad = "%s__%s" % (_guvenli_ad(kayit["id"]), _guvenli_ad(kayit["surum"] or "0"))
    ind_kok = os.path.join(VERI_KOK, "indirilen")
    os.makedirs(ind_kok, exist_ok=True)
    zip_yolu = os.path.join(ind_kok, ad + ".zip")

    # 1) indir (zaten dogru ozete sahip kopya varsa tekrar inme)
    if os.path.isfile(zip_yolu) and _G._sha(zip_yolu) == kayit["sha256"]:
        _log(progress, "- this mod was already downloaded and checked")
        boyut = os.path.getsize(zip_yolu)
    else:
        _log(progress, "- downloading %s ..." % (kayit["ad"] or kayit["id"]))
        gecici = zip_yolu + ".part"
        try:
            boyut = _indir_akis(kayit["indirme_url"], gecici, AZAMI_INDIRME, progress,
                                kayit["boyut"])
        except YonlendirmeReddi as e:
            # "Baglanti kurulamadi" DEMEYIZ: sunucu cevap verdi, reddeden biziz.
            # Kullanici NEREYE gidilmek istendigini ve neden gidilmedigini okur.
            if os.path.isfile(gecici):
                os.remove(gecici)
            return {"ok": False, "mod": kayit, "yonlendirme_reddi": True,
                    "mesaj": str(e)}
        except Exception as e:                              # noqa: BLE001
            if os.path.isfile(gecici):
                os.remove(gecici)
            return {"ok": False, "mod": kayit,
                    "mesaj": "the download did not finish (%s)." % str(e)[:140]}
        # 2) beyan edilen boyut
        if kayit["boyut"] and boyut != kayit["boyut"]:
            os.remove(gecici)
            return {"ok": False, "mod": kayit,
                    "mesaj": ("the download is %d bytes but the list says it should be %d, so it "
                              "was not used." % (boyut, kayit["boyut"]))}
        # 3) sha256 -- TUTMAZSA DOSYA SILINIR, sessizce devam edilmez
        gercek = _G._sha(gecici)
        if gercek != kayit["sha256"]:
            os.remove(gecici)
            return {"ok": False, "mod": kayit, "sha256_beklenen": kayit["sha256"],
                    "sha256_gercek": gercek,
                    "mesaj": ("the downloaded file does not match its checksum, so it was "
                              "deleted and nothing was installed. The file may be damaged or it "
                              "is not the mod the list describes.")}
        os.replace(gecici, zip_yolu)
        _log(progress, "- checksum matches")

    # 4) icerik denetimi
    try:
        ok, sebep, bilgi = _zip_denetle(zip_yolu)
    except zipfile.BadZipFile:
        os.remove(zip_yolu)
        return {"ok": False, "mod": kayit,
                "mesaj": "the download is not a zip file, so it was deleted."}
    if not ok:
        os.remove(zip_yolu)
        return {"ok": False, "mod": kayit, "mesaj": sebep}

    # 5) ac
    klasor = os.path.join(VERI_KOK, "acik", ad)
    try:
        dosyalar = _ac(zip_yolu, klasor)
    except Exception as e:                                  # noqa: BLE001
        shutil.rmtree(klasor, ignore_errors=True)
        return {"ok": False, "mod": kayit, "mesaj": "the mod could not be opened (%s)"
                % str(e)[:160]}
    icerik = _icerik_ozeti(dosyalar)
    return {"ok": True, "mod": kayit, "zip": zip_yolu, "klasor": klasor, "dosyalar": dosyalar,
            "icerik": icerik, "boyut": boyut, "denetim": bilgi,
            "mesaj": ("%s is downloaded and checked: %d file(s) ready to install."
                      % (kayit["ad"] or kayit["id"], len(dosyalar)))}


def durum():
    """Arayuz icin ozet: adres, onbellek zamani, indirilmis mod sayisi."""
    _v, zaman = _onbellek_oku()
    ind = os.path.join(VERI_KOK, "indirilen")
    n = len([f for f in os.listdir(ind) if f.lower().endswith(".zip")]) \
        if os.path.isdir(ind) else 0
    return {"url": _url(), "veri_kok": VERI_KOK, "onbellek_zamani": zaman, "indirilen": n,
            "onbellek_var": _onbellek_oku()[0] is not None}


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "katalog":
        k = katalog(print)
        print(json.dumps({x: k[x] for x in k if x != "modlar"}, indent=1, ensure_ascii=False))
        for m in k["modlar"]:
            print("  %-24s %-30s %8.2f MB  %s" % (m["id"], m["ad"], m["boyut"] / 1048576.0,
                                                  ",".join(m["etiketler"])))
    elif len(a) > 1 and a[0] == "indir":
        print(json.dumps({x: y for x, y in indir(a[1], print).items() if x != "dosyalar"},
                         indent=1, ensure_ascii=False))
    elif a and a[0] == "durum":
        print(json.dumps(durum(), indent=1, ensure_ascii=False))
    else:
        print("usage: mod_kutuphane.py katalog | indir <mod_id> | durum")
