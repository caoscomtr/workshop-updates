# -*- coding: utf-8 -*-
"""SHIP CORE — Workshop'un Ships sekmesi ile Ship Workshop motoru arasindaki kopru.

Motor (src/ship/: ship_ayar · ship_motor · ship_yerinde · ship_kompozit + hkm_*)
build/ship_vendor.py ile Ship Workshop'tan tasinir; burada yalniz CAGRILIR
(kural kopyasi yok: kapilar motorda kalir). Kullanici metinleri INGILIZCE.

Ne yapar
  * baslat(oyun): oyun klasorunu motora baglar (dogrulama dusse bile SALT-OKUMA
    modda calisir; yazma yalniz motorun DOGRULAMA["ok"] dedigi yerde)
  * hedefler(): katalog + canli PATCHED durumu + gruplar/bolumler + "rakip gemi"
    etiketi (gemi_siniflari: BRG/FRG/MOW/SCH...) + kanal (diffuse/normal)
  * onizleme(): motorun sablon_dizisi()'nden kucuk PNG (data URI), once/sonra
  * disa_aktar(): boyanabilir PNG sablonu (Documents\\ShipWorkshop\\tasarimlar)
  * uygula(): ship_yerinde.uygula (ilerleme + gunluk geri cagrilariyla)
  * geri_al(): ship_yerinde.geri_al
  * mod_tara()/mod_kur()/mod_kaldir(): bir klasor dolusu <anahtar>.png -> toplu
    uygula / toplu geri al ("mod indir/kur" akisi)

Guvenlik: oyun acikken yazma reddi (motorda YOK, burada eklendi) · motorun butun
kapilari (canli TOC, yazma_kapisi, ayni-giris cifti, alfa, kilitli giris) aynen.
"""
import base64
import io
import json
import os
import re
import subprocess
import sys
import threading
import time

BURA = os.path.dirname(os.path.abspath(__file__))
SHIP_DIR = os.path.join(BURA, "ship")
if SHIP_DIR not in sys.path:
    sys.path.insert(0, SHIP_DIR)

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
TASARIM = os.path.join(os.path.expanduser("~"), "Documents", "ShipWorkshop", "tasarimlar")
_D = {"A": None, "M": None, "Y": None, "hata": None, "oyun": None, "kat": None,
      "durum_zaman": 0.0, "durum": {}}
_KILIT = threading.Lock()

# arayuze giden sabit etiketler (ceviri envanteri bunlari toplar)
GRUP_AD = {
    "hull": "Hulls", "sail": "Sails", "flag": "Flags & streamers", "figurehead": "Figureheads",
    "wheel": "Wheels", "cabin": "Cabin", "cannon": "Cannons", "crew": "Crew",
    "enemy": "Enemy ships", "banner": "Fort banners", "lut": "Paint ramps (LUT)",
}
GRUP_SIRA = ["hull", "sail", "flag", "figurehead", "wheel", "cabin", "cannon", "crew",
             "enemy", "banner", "lut"]
RISK_AD = {"SAFE": "SAFE", "CAUTION": "CAUTION", "SHARED": "SHARED"}
GEMI_SINIF_AD = {"BRG": "Brig", "FRG": "Frigate", "MOW": "Man o' War", "SCH": "Schooner",
                 "GNB": "Gunboat", "CTR": "Cutter", "QAR": "Queen Anne's Revenge",
                 "JKD": "Jackdaw"}
SABIT_METINLER = list(GRUP_AD.values()) + list(RISK_AD.values()) + list(GEMI_SINIF_AD.values()) + [
    "Jackdaw only", "Enemy & civilian ships", "Also on enemy ships", "Standard", "Other",
    "Distant view only (LOD proxy)", "colour ramp, not a picture",
    "PATCHED", "PARTIAL", "NORMAL MAP", "diffuse", "normal",
    "Enemy ships", "Paint ramps", "Fort banners", "Fire crew (MTX)", "Asian crew (MTX)",
    "Naval crew (enemy)", "Generic pirate sailors (enemy & civilian)", "Skeleton crew",
    "normal map: keep the alpha channel (gloss)",
    "normal map: RGB shown, alpha (gloss) kept in the PNG",
]


def oyun_acik_mi():
    try:
        c = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ACBlackFlag.exe"],
                           capture_output=True, timeout=10, creationflags=NO_WINDOW)
        return b"ACBlackFlag.exe" in (c.stdout or b"")
    except Exception:
        return False


# ------------------------------------------------------------------ motor
def _motor():
    """Motoru tembel yukle (Oodle DLL import aninda gerekir)."""
    if _D["M"] is not None:
        return _D["A"], _D["M"], _D["Y"]
    if _D["hata"]:
        raise RuntimeError(_D["hata"])
    try:
        import ship_ayar as A          # bagimsizlik_kur() import aninda calisir
        import ship_motor as M
        import ship_yerinde as Y
        _D["A"], _D["M"], _D["Y"] = A, M, Y
        return A, M, Y
    except Exception as e:
        _D["hata"] = "Ship engine could not be loaded: %s" % str(e)[:200]
        raise RuntimeError(_D["hata"])


def baslat(oyun_kok):
    """Oyun klasorune bagla. Doner: {ok, yazma, mesaj, sapan, salt_okunur}."""
    A, M, Y = _motor()
    with _KILIT:
        salt = False
        try:
            mesaj, bilgi = A.uygula(oyun_kok, kaydet=False)
        except RuntimeError as e:
            try:
                mesaj, bilgi = A.uygula(oyun_kok, kaydet=False, salt_okunur=True)
                salt = True
            except Exception as e2:
                return {"ok": False, "mesaj": str(e2)[:300]}
        _D["oyun"] = oyun_kok
        _D["kat"] = None
        _D["durum_zaman"] = 0.0
        try:
            Y.onbellekleri_gecersiz_kil()
        except Exception:
            pass
        return {"ok": True, "yazma": bool(A.yazma_serbest()), "salt_okunur": salt,
                "mesaj": str(mesaj)[:400],
                "sapan": len((A.DOGRULAMA or {}).get("sapan_fid") or [])}


def bagli_mi():
    return _D["oyun"] is not None


# ------------------------------------------------------------------ katalog
def _katalog():
    A, M, Y = _motor()
    if _D["kat"] is None:
        kat = M.katalog()
        _D["kat"] = kat
    return _D["kat"]


def _kayit_canli_mi(k):
    """Bu kayit dosyanin SU ANKI halini tarif ediyor mu? (ICERIK kapisi)

    🧨 OLCULDU (2026-09-08, kum havuzu + gercek depo): geri alinmis bir dokunun
    yazma-sonrasi kimlik klasorunde `uygulandi` kaydi kaliyor (bkz.
    ship_yerinde.bayat_kayitlari_kapat). Durum alanina guvenen tarama o dokuyu
    PATCHED gosteriyordu; gercek makinede 40 kaydin 35'i boyleydi, dosya
    bayt bayt orijinaldi. Yalniz KESIN "dosya orijinal" (True) elenir;
    False (canli) ve None (karar verilemedi) canli sayilir -- fail-closed:
    belirsiz bir yamayi "temiz" gostermek, bayat rozetten daha kotudur.
    """
    A, M, Y = _motor()
    fy = k.get("forge_yolu")
    try:
        if not fy or not os.path.isfile(fy):
            return True
        return Y._dosya_orijinal_mi(k, fy) is not True
    except Exception:
        return True


def _durumlar(taze=False):
    """id -> 'uygulandi' | 'in_progress' (GOSTERIM icin hizli tarama).

    Y.durum() her hedef icin tum kimlik klasorlerini geziyor (229 x N klasor)
    ve saniyeler suruyordu; liste bos gorunuyordu (probe ekran goruntusuyle
    olculdu). Burada kayit deposu BIR kez taranir: bu oyunun forge yollarina
    ait `ship_*.json` kayitlarindan durum haritasi cikar. Yazma/geri alma
    yolu yine Y.kayit_oku'nun TAM kontrollerinden (celiski = fail-closed) gecer.
    Durum alani TEK BASINA yetmez: her aday `_kayit_canli_mi` icerik kapisindan
    gecer (bayat `uygulandi` kopyalari -> PATCHED yalani, 2026-09-08).
    """
    A, M, Y = _motor()
    if not taze and time.time() - _D["durum_zaman"] < 3.0:
        return _D["durum"]
    out = {}
    try:
        kok = Y.VERI_KOK
        oyun = os.path.normcase(os.path.abspath(_D["oyun"] or ""))
        adaylar = {}
        for d in os.listdir(kok):
            kl = os.path.join(kok, d)
            if not os.path.isdir(kl):
                continue
            for f in os.listdir(kl):
                if not (f.startswith("ship_") and f.endswith(".json")):
                    continue
                try:
                    k = json.load(io.open(os.path.join(kl, f), encoding="utf-8"))
                except Exception:
                    continue
                if k.get("durum") not in ("uygulandi", "in_progress"):
                    continue
                fy = os.path.normcase(os.path.abspath(k.get("forge_yolu") or ""))
                if oyun and not fy.startswith(oyun):
                    continue
                tid = str(k.get("doku") or "").lower()
                if not tid:
                    continue
                adaylar.setdefault(tid, []).append(k)
        for tid, liste in adaylar.items():
            # ayni doku icin birden fazla kayit: once ICERIK kapisi, sonra
            # uygulandi > in_progress
            canli = [k for k in liste if _kayit_canli_mi(k)]
            if not canli:
                continue
            out[tid] = ("uygulandi" if any(k.get("durum") == "uygulandi" for k in canli)
                        else "in_progress")
    except Exception:
        pass
    _D["durum"], _D["durum_zaman"] = out, time.time()
    return out


def _rakip(h):
    """Gemi siniflari (katalogdaki gemi_siniflari anahtarlari). Jackdaw da bir
    BRG'dir; "rakip" = BRG disinda bir sinif da kullaniyorsa (FRG/MOW/SCH/...)."""
    s = h.get("gemi_siniflari") or {}
    return sorted(k for k in s.keys() if k in GEMI_SINIF_AD)


def _bolumler(h, M, diffuse_bolum):
    """Bolum (klasor) adlari. Motorun takimlar()'i v1 gruplarini bilir; v2'nin
    enemy/lut/banner gruplari, yeni murettebat aileleri ve normal map'ler
    (diffuse'unun bolumune) burada eslenir."""
    kanal = h.get("kanal", "diffuse")
    if kanal == "normal" and h.get("diffuse_anahtar") in diffuse_bolum:
        return diffuse_bolum[h["diffuse_anahtar"]]
    g = h.get("grup")
    ad = (h.get("anahtar") or "") + " " + (h.get("ad") or "")
    if g == "enemy":
        for kod, etiket in GEMI_SINIF_AD.items():
            if ("_%s_" % kod) in h.get("ad", "") or ad.startswith(kod + "_"):
                return [etiket]
        return ["Enemy ships"]
    if g == "lut":
        return ["Paint ramps"]
    if g == "banner":
        return ["Fort banners"]
    if g == "crew":
        for jeton, etiket in (("FireCrew", "Fire crew (MTX)"), ("AsianCrew", "Asian crew (MTX)"),
                              ("NavalCrew", "Naval crew (enemy)"),
                              ("Generic_Pirate_Sailor", "Generic pirate sailors (enemy & civilian)"),
                              ("MrBones", "Skeleton crew")):
            if jeton.lower() in ad.lower():
                if jeton == "MrBones":
                    break                       # motorun kendi MrBones bolumu var
                return [etiket]
    try:
        b = M.takimlar(h) or []
    except Exception:
        b = []
    return b or ["Other"]


def hedefler(taze=False):
    """Arayuz icin duz hedef listesi + gruplar."""
    A, M, Y = _motor()
    kat = _katalog()
    dur = _durumlar(taze)
    out = []
    # diffuse bolumleri once (normal map'ler diffuse'unu izler)
    diffuse_bolum = {}
    for h in kat["hedefler"]:
        if h.get("kanal", "diffuse") == "diffuse" and h.get("kullanilabilir", True):
            diffuse_bolum[h["anahtar"]] = _bolumler(h, M, {})
    # ayni kapsayiciyi paylasan kardesler (diffuse <-> normal, BlackSkull cifti)
    kap = {}
    for h in kat["hedefler"]:
        if h.get("kullanilabilir", True):
            kap.setdefault((h.get("forge"), h.get("kapsayici")), []).append(h["anahtar"])
    for h in kat["hedefler"]:
        if not h.get("kullanilabilir", True):
            continue
        bolumler = _bolumler(h, M, diffuse_bolum)
        kardesler = [a for a in kap.get((h.get("forge"), h.get("kapsayici")), []) if a != h["anahtar"]]
        sinif = _rakip(h)
        w, hh = h.get("w"), h.get("h")
        out.append({
            "anahtar": h["anahtar"], "id": h["id"], "ad": h["ad"], "kisa_ad": h.get("kisa_ad"),
            "grup": h.get("grup"), "alt_tur": h.get("alt_tur"), "tier": h.get("tier"),
            "kanal": h.get("kanal", "diffuse"), "diffuse_anahtar": h.get("diffuse_anahtar"),
            "w": w, "h": hh, "fmt": h.get("fmt"), "mip": h.get("mip"),
            "boyut": ("%d²" % w) if w == hh else "%dx%d" % (w, hh),
            "risk": h.get("risk", "SAFE"), "uyari": h.get("uyari") or "",
            "kapsam": h.get("kapsam_kaniti") or "",
            "forge": h.get("forge"), "kapsayici": h.get("kapsayici"),
            "kapsayici_sinif": h.get("kapsayici_sinif"),
            "bolumler": bolumler, "gemi_siniflari": sinif,
            "gemi_adlari": [GEMI_SINIF_AD[k] for k in sinif],
            "jackdaw": "BRG" in (h.get("gemi_siniflari") or {}) or not sinif,
            "rakip": any(k != "BRG" for k in sinif) or h.get("grup") == "enemy",
            "durum": dur.get(str(h["id"]).lower()),
            "materyaller": (h.get("materyaller") or [])[:6],
            "geometri": h.get("geometri_kullanici"),
            "kardesler": kardesler,            # ayni arsiv girisini paylasanlar
            "olculmemis": h.get("scope_sinif") == "UNMEASURED",
        })
    # kardesi yamali olanlar: yazma reddedilir (motorun ayni-giris kapisi)
    idx = {x["anahtar"]: x for x in out}
    for x in out:
        x["kardes_yamali"] = [a for a in x["kardesler"] if idx.get(a, {}).get("durum")]
    gruplar = []
    for g in GRUP_SIRA:
        n = sum(1 for x in out if x["grup"] == g and x["kanal"] == "diffuse")
        nn = sum(1 for x in out if x["grup"] == g and x["kanal"] == "normal")
        if n or nn:
            gruplar.append({"kod": g, "ad": GRUP_AD.get(g, g), "ses": n, "normal": nn,
                            "yamali": sum(1 for x in out if x["grup"] == g and x["durum"])})
    meta = kat.get("_meta", {})
    return {"hedefler": out, "gruplar": gruplar,
            "meta": {"surum": meta.get("surum"), "hedef_sayisi": len(out),
                     "kanal": meta.get("kanal")}}


def hedef_bul(anahtar):
    A, M, Y = _motor()
    return M.hedef_bul(anahtar, _katalog())


# ------------------------------------------------------------------ onizleme
def _onizleme_dir():
    A, M, Y = _motor()
    d = os.path.join(A.AYAR_KOK, "ship_onizleme")
    os.makedirs(d, exist_ok=True)
    return d


ONIZLEME_SURUM = 4


def _kucult(arr, en_buyuk):
    """RGB(A) numpy -> PIL, en uzun kenar en_buyuk (alfa ayri olceklenir)."""
    from PIL import Image
    import numpy as np
    im = Image.fromarray(arr, "RGBA" if arr.shape[2] == 4 else "RGB")
    if max(im.size) > en_buyuk:
        oran = en_buyuk / float(max(im.size))
        boy = (max(1, int(im.size[0] * oran)), max(1, int(im.size[1] * oran)))
        if im.mode == "RGBA":
            rgb = im.convert("RGB").resize(boy, Image.LANCZOS)
            a = im.getchannel("A").resize(boy, Image.LANCZOS)
            rgb.putalpha(a); im = rgb
        else:
            im = im.resize(boy, Image.LANCZOS)
    return im


def onizleme(anahtar, en_buyuk=512):
    """Sablon onizlemesi (data URI). Yamali hedefte vanilla anlik goruntusu de doner."""
    A, M, Y = _motor()
    h = hedef_bul(anahtar)
    d = _onizleme_dir()
    dur = _durumlar().get(str(h["id"]).lower())
    yol = os.path.join(d, "ws%d_%s_%s.png" % (ONIZLEME_SURUM, anahtar, "y" if dur else "v"))
    vanilla = os.path.join(d, "ws%d_%s.vanilla.png" % (ONIZLEME_SURUM, anahtar))
    bilgi = {}
    if not os.path.isfile(yol):
        if _normal_mi(h):
            arr, _tanim = M.doku_dizisi(h, 0)
            bilgi = {"politika": "tasarim", "yol": "normal", "cevrildi": bool(M.cevirmeli(h)),
                     "uyari": "normal map: RGB shown, alpha (gloss) kept in the PNG"}
            arr = arr[:, :, :3]
        else:
            arr, bilgi = M.sablon_dizisi(h, 0)
        if bilgi.get("yol") == "amblem" and arr.shape[2] == 4:
            # amblem: notr gri uzerine bindir (kanal bilgisi kaybolmasin diye ayri)
            import numpy as np
            a = arr[:, :, 3:4].astype("float32") / 255.0
            rgb = (arr[:, :, :3].astype("float32") * a + 128.0 * (1 - a)).astype("uint8")
            arr = rgb
        im = _kucult(arr, en_buyuk)
        im.save(yol)
        try:
            with io.open(yol + ".json", "w", encoding="utf-8") as f:
                json.dump({k: (v if isinstance(v, (str, int, float, bool)) else str(v))
                           for k, v in bilgi.items()}, f)
        except Exception:
            pass
    else:
        try:
            bilgi = json.load(io.open(yol + ".json", encoding="utf-8"))
        except Exception:
            bilgi = {}
    out = {"ok": True, "uri": _uri(yol), "politika": bilgi.get("politika"),
           "sablon_yolu": bilgi.get("yol"), "uyari": bilgi.get("uyari") or "",
           "cevrildi": bilgi.get("cevrildi"), "yamali": bool(dur)}
    if dur and os.path.isfile(vanilla):
        out["vanilla_uri"] = _uri(vanilla)
    return out


def _uri(yol):
    with open(yol, "rb") as f:
        return "data:image/png;base64," + base64.b64encode(f.read()).decode()


def _onizleme_sil(anahtar):
    d = _onizleme_dir()
    for f in os.listdir(d):
        if f.startswith("ws%d_%s" % (ONIZLEME_SURUM, anahtar)) and not f.endswith(".vanilla.png"):
            try:
                os.remove(os.path.join(d, f))
            except OSError:
                pass


def _vanilla_anlik(anahtar):
    """Yazmadan ONCE vanilla onizlemesini sakla (once/sonra)."""
    d = _onizleme_dir()
    v = os.path.join(d, "ws%d_%s.vanilla.png" % (ONIZLEME_SURUM, anahtar))
    if os.path.isfile(v):
        return
    A, M, Y = _motor()
    h = hedef_bul(anahtar)
    try:
        arr, _b = M.sablon_dizisi(h, 0)
        if arr.shape[2] == 4:
            arr = arr[:, :, :3]
        _kucult(arr, 512).save(v)
    except Exception:
        pass


# ------------------------------------------------------------------ export
def _normal_mi(h):
    return h.get("kanal", "diffuse") == "normal"


def disa_aktar(anahtar):
    A, M, Y = _motor()
    h = hedef_bul(anahtar)
    os.makedirs(TASARIM, exist_ok=True)
    yol = M.serbest_ad(TASARIM, h["anahtar"])
    if _normal_mi(h):
        # NORMAL MAP: resim degil VERI. Alfa = gloss maskesi -> HER ZAMAN RGBA
        # (motorun sablon_dizisi grup'a bakar ve alfayi atardi; olculdu).
        from PIL import Image
        arr, tanim = M.doku_dizisi(h, 0)
        Image.fromarray(arr, "RGBA").save(yol)
        return {"ok": True, "yol": yol, "klasor": TASARIM, "w": int(arr.shape[1]),
                "h": int(arr.shape[0]), "politika": "tasarim", "sablon_yolu": "normal",
                "uyari": "normal map: keep the alpha channel (gloss)"}
    r = M.cikar(h, yol)
    return {"ok": True, "yol": yol, "klasor": TASARIM, "w": r.get("w"), "h": r.get("h"),
            "politika": r.get("politika"), "sablon_yolu": r.get("sablon_yolu"),
            "uyari": r.get("uyari") or ""}


# ------------------------------------------------------------------ yazma
def uygula(anahtar, png, alfa="auto", gunluk=None, ilerleme=None):
    """Tek hedefe uygula. Doner: {ok, mesaj, kayit}. Kapilar motorda."""
    A, M, Y = _motor()
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    if not A.yazma_serbest():
        return {"ok": False, "mesaj": A.yazma_reddi()}
    h = hedef_bul(anahtar)
    if not os.path.isfile(png):
        return {"ok": False, "mesaj": "The design file was not found."}
    _vanilla_anlik(anahtar)
    if _normal_mi(h):
        alfa = "tasarim"                    # gloss PNG'nin alfasindan, kosulsuz
    try:
        k = Y.uygula(h, png, gunluk=gunluk or (lambda s: None), alfa=alfa,
                     ilerleme=ilerleme)
    except Exception as e:
        return {"ok": False, "mesaj": str(e)[:400]}
    _onizleme_sil(anahtar)
    _D["durum_zaman"] = 0.0
    return {"ok": True, "kayit": {"hedef": k.get("hedef"), "forge": k.get("forge"),
                                  "harici": len(k.get("harici") or []),
                                  "gomulu": bool(k.get("giris"))}}


def geri_al(anahtar, gunluk=None):
    A, M, Y = _motor()
    if oyun_acik_mi():
        return {"ok": False, "mesaj": "Close the game first."}
    if not A.yazma_serbest():
        return {"ok": False, "mesaj": A.yazma_reddi()}
    h = hedef_bul(anahtar)
    try:
        k = Y.geri_al(h, gunluk=gunluk or (lambda s: None))
    except Exception as e:
        return {"ok": False, "mesaj": str(e)[:400]}
    _onizleme_sil(anahtar)
    d = _onizleme_dir()
    v = os.path.join(d, "ws%d_%s.vanilla.png" % (ONIZLEME_SURUM, anahtar))
    try:
        os.remove(v)
    except OSError:
        pass
    _D["durum_zaman"] = 0.0
    if k is None:
        return {"ok": True, "hic": True, "mesaj": "Nothing to revert for this target."}
    return {"ok": True}


def tahmini_sure(anahtar):
    A, M, Y = _motor()
    h = hedef_bul(anahtar)
    try:
        return float(M.tahmini_sure(h["w"], h["h"], h.get("mip") or 1))
    except Exception:
        return 0.0


# ------------------------------------------------------------------ mod klasoru
def mod_tara(klasor):
    """Klasordeki PNG'leri hedef anahtarlariyla esle. Tahmin YOK: eslesmeyen raporlanir."""
    A, M, Y = _motor()
    kat = {h["anahtar"].lower(): h for h in _katalog()["hedefler"] if h.get("kullanilabilir", True)}
    dur = _durumlar(True)
    eslesen, eslesmeyen = [], []
    try:
        dosyalar = sorted(f for f in os.listdir(klasor) if f.lower().endswith(".png"))
    except OSError as e:
        return {"ok": False, "mesaj": str(e)[:200]}
    for f in dosyalar:
        kok = os.path.splitext(f)[0]
        aday = kok.lower()
        h = kat.get(aday)
        if not h:
            aday2 = re.sub(r" \(\d+\)$", "", aday)      # serbest_ad numaralandirmasi
            aday2 = re.sub(r"_\d+$", "", aday2) if not kat.get(aday2) else aday2
            h = kat.get(aday2)
        if not h:
            eslesmeyen.append(f); continue
        boy = None
        try:
            from PIL import Image
            with Image.open(os.path.join(klasor, f)) as im:
                boy = im.size
        except Exception:
            pass
        eslesen.append({"dosya": f, "anahtar": h["anahtar"], "ad": h["ad"], "grup": h.get("grup"),
                        "risk": h.get("risk"), "w": h["w"], "h": h["h"],
                        "olcu_uyuyor": boy == (h["w"], h["h"]) if boy else None,
                        "png_boy": boy, "yamali": bool(dur.get(str(h["id"]).lower())),
                        "kanal": h.get("kanal", "diffuse")})
    manifest = None
    mj = os.path.join(klasor, "mod.json")
    if os.path.isfile(mj):
        try:
            manifest = json.load(io.open(mj, encoding="utf-8"))
        except Exception:
            manifest = {"hata": "mod.json could not be read"}
    return {"ok": True, "eslesen": eslesen, "eslesmeyen": eslesmeyen, "manifest": manifest,
            "paylasimli": sum(1 for e in eslesen if e["risk"] in ("SHARED", "CAUTION"))}


def yamali_hedefler():
    """Su an yamali hedeflerin anahtarlari (toplu geri alma icin)."""
    dur = _durumlar(True)
    return [h["anahtar"] for h in _katalog()["hedefler"] if dur.get(str(h["id"]).lower())]
