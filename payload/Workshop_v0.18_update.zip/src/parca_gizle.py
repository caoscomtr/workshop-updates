# -*- coding: utf-8 -*-
"""parca_gizle -- TEK TIK PARCA GIZLEME (Blender'siz).

Kullanici bir ogenin (kiyafet / karakter / silah) parca listesinden kutucuk isaretler,
"Hide" der; secilen parcanin OYUNUN CIZDIGI BUTUN LOD bant mesh'leri gorunmez yapilir.
Blender, GLB, export klasoru GEREKMEZ: parca listesi 3D indeksten (sahne.kayit_bul /
silah_indeks) kurulur, gizleme bellekte uretilir (export3d.gizle), arsive TEK YAZICI
kur_mesh.kur ile kurulur, geri alma kur_mesh.geri_al ile olur.

NEDEN (topluluk, 2026-09-08): Maxx Edward'in cubbesini etek ("Dress") olmadan istiyor;
Nexus #88 "Hide Blowpipe" 1.159 indirme; 6+ kullanici kilic/tabanca/gizli bicak/halat
gizlemek istiyor; "holster kiyafet dokusuna yapisik, kaldirilamaz" (ReShade yolu kirilgan).
Motor VARDI ve oyun-ici kanitli (Ferraro Diplomat, 4 parca) ama yalniz "Blender'da sil ->
IMPORT 3D -> eksikleri gizle" yolundan erisiliyordu. Bu modul ayni sonucu GLB'siz uretir.

YONTEM (export3d/gizle.py, degismedi): hedef mesh'in her ucgeni (a,b,c) -> (a,a,a).
Ic dosya UZUNLUGU SABIT, degisen baytlar yalniz IndexBuffer'da; oyunun kendi paketleyicisi
dolgu ucgenlerini tam bu bicimde yazar (vanilla Boots_Edward_Assassin_LOD0 6322/6322
ucgeni zaten boyle -- olculdu 2026-09-08). Konum/UV/deri/tablo tek bayt degismez.

LOD BANTLARI: bir parca 1..5 mesh girisidir (Edward_Assassin'de 29 grup / 119 giris).
Yalniz LOD0 gizlenirse onizleme gizli gosterir, oyun 4 m'nin otesinde vanilla'yi cizer
(Maxx'in "onizlemede var oyunda yok" hatasi). Bu modul bant tablosunu mesh_ithal'den alir
(`_kiyafet_bant_tablosu` / `_silah_bant_tablosu`, `_bant_yazilir`) -- kiyafette HER bant,
silahta ANA bantlar (proxy karari mesh_ithal'de olculdu ve degismedi; rapor bunu SOYLER).
Tablo kurulamazsa yalniz birincil giris yazilir ve plan bunu ACIKCA yazar (sessiz yok).

ARSIV BOYUTU (olculdu 2026-09-08, Dress 5 giris): yeniden paketlenen giris orijinalden
%2-4 BUYUK (bizim Oodle seviyesi oyununkinden zayif) -> "yerinde" yazma sigmaz; tek yol
kur_mesh "ek" yontemi: giris arsivin SONUNA eklenir, TOC yonlendirilir, orijinal baytlar
yerinde durur (cokme guvenli). Arsiv giris basina ~13-76 KB buyur; "Show again" kuyrugu
kirpar ve arsiv vanilla boyuna / sha256'sina doner (test K5/K6).

KAYIT ETIKETI: "hide:<oge>:<parca>[ LOD band n][ | kullanici etiketi]". Health Check
(kur_mesh.saglik / explorer_core.durum) bu kayitlari 'Imported 3D models' altinda gorur;
`goster`/`durum` YALNIZ 'hide:' onekli ve bu ogenin girislerine ait kayitlara bakar.

ZINCIR KURALI (kur_mesh): ayni arsiv girisine (gid) ust uste yazilan kayitlar zincirdir;
EN YENISI geri alininca giris VANILLA'ya doner ve eski halkalar olu sayilir. Bu yuzden
  * bir parcanin 5 LOD'u tek gid'deyse (TunicBottom) tek geri alma hepsini dondurur;
  * baska bir aracin yamasi (IMPORT 3D) uzerine gizlenen parca "Show again" ile
    ORIJINAL oyun mesh'ine doner, ithal edilen sekle DEGIL -- plan bunu uyarir;
  * iki AYRI parca ayni gid'i paylasiyorsa (NPC Head_X / Head_X#1) biri tek basina
    gosterilemez; `goster` reddeder ve ikisini birlikte gostermeyi soyler.

DIS ARAYUZ (silah_stat / gemi_stat kalibi -- panel ajani kopyalayabilsin):
  parcalar(ad, tur)                       -> {ok, oge, gorunen_ad, parcalar:[...], mesaj}
  plan(ad, secilen_anahtarlar, tur)       -> {ok, isler, red, atlanan, ozet, ozet_kalip}  YAZMAZ
  uygula(ad, secilen_anahtarlar, tur, etiket, progress) -> {ok, yazilan, yazilan_sayi, mesaj}
  goster(ad, anahtarlar=None, tur)        -> {ok, geri_alinan, mesaj}
  durum(ad, tur)                          -> {gizli_parcalar, kayit_sayisi, ...}
`tur`: "out" (kiyafet, anahtar = ad), "chr" (karakter, "CHR_" oneki eklenir), "wpn" (silah).
Sayili mesajlar {"t": sablon, "a": [degerler]} kalibiyla da doner (arayuz T() cevirir).

OYUNDA DENENMEDI: bu modulun kendi yazdigi hicbir sey oyunda henuz gorulmedi. Kanit
bayt duzeyinde (gizle.gizli_mi, kum havuzu, test_parca_gizle.py); gizleme biciminin
kendisi oyun-ici kanitli (PARCA_SILME_REHBERI.md, Ferraro Diplomat).
"""
import functools
import re

import outfit_core as C

try:
    from export3d import cok_forge as CF
    from export3d import forge_giris as FG
    from export3d import gizle as GZ
    from export3d import kur_mesh as KM
    from export3d import mesh_ithal as MI
    from export3d import sahne as S3
except ImportError:                                   # src/export3d dogrudan yolda
    import cok_forge as CF
    import forge_giris as FG
    import gizle as GZ
    import kur_mesh as KM
    import mesh_ithal as MI
    import sahne as S3

__all__ = ["parcalar", "plan", "uygula", "goster", "durum", "ETIKET_ONEK", "SURUM"]

SURUM = "1.0"
ETIKET_ONEK = "hide:"

_TUR = {"out": "out", "outfit": "out", "chr": "chr", "character": "chr",
        "wpn": "wpn", "weapon": "wpn"}


# ----------------------------------------------------------------- kucuk yardimcilar
def _kalip(t, a):
    return {"t": t, "a": list(a)}


def _hx(v):
    return "0x%012X" % int(v)


def _forge():
    """Yazilacak/okunacak arsiv: outfit_core.FORGE CAGRI ANINDA okunur (kum havuzu
    onu tasir; import aninda kopyalanirsa test gercek oyuna bakar)."""
    return C.FORGE


def _zincirli(fn):
    """YAMA ZINCIRI (2026-10-12): bu modulun her kapisi, arsivi oyunun gordugu zincirden
    okur (CF.okuma_gorunumu: boot_patch_01 > boot) ve kur_mesh.kur ayni halkaya yazar
    (`etkin_arsiv`). Eskiden okuma TEK forge'du: Altair/Connor gibi Patch_01'de guncellenen
    kiyafetlerde orijinal boot'tan okunur, yazma boot'a gider, oyun patch'i gosterirdi
    (sessiz kusur); yazma sonrasi olcum de boot'u okuyup "NOT hidden" diye geri sarardi."""
    @functools.wraps(fn)
    def sar(*a, **k):
        with CF.okuma_gorunumu(C, _forge()):
            return fn(*a, **k)
    return sar


def _tur(tur):
    t = _TUR.get(str(tur or "out").lower())
    if t is None:
        raise ValueError("unknown item kind %r (use 'out', 'chr' or 'wpn')" % (tur,))
    return t


def _anahtar(ad, tur):
    """Arayuz adi -> indeks anahtari (sunucu._3d_anahtar ile AYNI CHR_ kurali)."""
    a = str(ad or "").strip()
    if tur == "chr" and a and not a.startswith("CHR_"):
        a = "CHR_" + a
    return a


def _gorunen(taban):
    """Kullaniciya gosterilen parca adi: taban ad, K1 kirpma '?' isaretleri atilmis.
    Teknik kimlik (gid/icid, _LOD eki, IC_) tasimaz."""
    s = re.sub(r"\?+", "", str(taban or "")).rstrip("_")
    return s or str(taban or "?")


def _log(progress, s):
    C._log(progress, s)


# ----------------------------------------------------------------- indeks -> parcalar
def _kayit(anahtar, silah):
    """Ogenin indeks kaydi ({gorunen_ad, gruplar:[{taban, lodlar, zincir}]}); yoksa KeyError."""
    if silah:
        idx, _y = S3.silah_indeks_yukle()
        if anahtar not in idx:
            raise KeyError("'%s' not in weapon 3D index" % anahtar)
        return idx[anahtar]
    return S3.kayit_bul(anahtar)


def _bant_tablosu(anahtar, silah):
    """mesh_ithal'in bant tablosu (TEK KAYNAK: IMPORT 3D ile ayni tablo). Kurulamazsa bos
    sozluk = bilgi yok; o zaman yalniz birincil yazilir ve plan bunu soyler."""
    try:
        return MI._silah_bant_tablosu(anahtar) if silah else MI._kiyafet_bant_tablosu(anahtar)
    except Exception:                                           # noqa: BLE001
        return {}


def _parca_kayitlari(anahtar, silah):
    """Ogenin parcalari (sirali liste). Her parca:
       {anahtar, gorunen_ad, taban, aile, govde, bant_sayisi, bant_bilgisi,
        girisler:[{gid, icid, gid_hex, icid_hex, ad, bant, mesafe, rol, birincil, boyut}],
        atlanan_bant:[(bant, mesafe)], sebep}
    `girisler` = YAZILACAK mesh girisleri (kiyafette her bant, silahta birincil + ana
    bantlar; mesh_ithal._eksik_bant_girdileri ile ayni kural)."""
    kayit = _kayit(anahtar, silah)
    tablo = _bant_tablosu(anahtar, silah)
    out, gorulen_ad = [], {}
    for g in kayit.get("gruplar") or []:
        taban = str(g.get("taban") or "?")
        lodlar = [l for l in (g.get("lodlar") or []) if l and l[1] is not None and l[2] is not None]
        # anahtar = taban (indekste tekil olculdu: 523 ogede 0 cift); yine de kapat
        key = taban
        n = gorulen_ad.get(taban, 0) + 1
        gorulen_ad[taban] = n
        if n > 1:
            key = "%s (%d)" % (taban, n)
        p = {"anahtar": key, "gorunen_ad": _gorunen(taban), "taban": taban,
             "aile": MI._aile_anahtari(taban, (lodlar[0][3] if lodlar else None)),
             "govde": False, "bant_sayisi": len(lodlar), "bant_bilgisi": False,
             "girisler": [], "atlanan_bant": [], "sebep": None}
        p["govde"] = MI._govde_mi({"aile": p["aile"], "taban": taban,
                                  "ad": (lodlar[0][3] if lodlar else None)})
        if not lodlar:
            p["sebep"] = "the 3D index holds no mesh entry for this part"
            out.append(p)
            continue
        boyut0, gid0, icid0, ad0 = lodlar[0]
        birincil = {"gid": int(gid0), "icid": int(icid0), "gid_hex": _hx(gid0),
                    "icid_hex": _hx(icid0), "ad": str(ad0), "bant": None, "mesafe": None,
                    "rol": None, "birincil": True, "boyut": int(boyut0 or 0)}
        bantlar = tablo.get((int(gid0), int(icid0))) if tablo else None
        girisler = [birincil]
        if bantlar:
            p["bant_bilgisi"] = True
            p["bant_sayisi"] = len(bantlar)
            for b in bantlar:
                if b.get("birincil"):
                    birincil.update(bant=b.get("bant"), mesafe=b.get("mesafe"), rol=b.get("rol"))
                    continue
                if not MI._bant_yazilir(b):
                    p["atlanan_bant"].append((b.get("bant"), b.get("mesafe")))
                    continue
                girisler.append({"gid": int(str(b["gid"]), 16), "icid": int(str(b["icid"]), 16),
                                 "gid_hex": _hx(int(str(b["gid"]), 16)),
                                 "icid_hex": _hx(int(str(b["icid"]), 16)),
                                 "ad": str(b.get("ad")), "bant": b.get("bant"),
                                 "mesafe": b.get("mesafe"), "rol": b.get("rol"),
                                 "birincil": False, "boyut": int(b.get("boyut") or 0)})
        gor, tekil = set(), []
        for e in girisler:
            k = (e["gid"], e["icid"])
            if k in gor:
                continue
            gor.add(k)
            tekil.append(e)
        p["girisler"] = tekil
        out.append(p)
    return kayit, out


def _giris_haritasi(parcalar):
    """(gid, icid) -> parca anahtari."""
    m = {}
    for p in parcalar:
        for e in p["girisler"]:
            m[(e["gid"], e["icid"])] = p["anahtar"]
    return m


def _hide_kayitlari(forge, harita):
    """kur_mesh'in ETKIN kayitlarindan 'hide:' onekli ve bu ogenin girislerine ait olanlar
    (kayit sirasi = kronolojik). Her kayit: {id, parca, gid, icid, zaman, etiket, durum}."""
    d = KM.durum(forge)
    out = []
    for y in d.get("yamalar") or []:
        et = str(y.get("etiket") or "")
        if not et.startswith(ETIKET_ONEK):
            continue
        try:
            k = (int(str(y["gid"]), 16), int(str(y["icid"]), 16))
        except (KeyError, TypeError, ValueError):
            continue
        if k not in harita:
            continue
        out.append({"id": y.get("id"), "parca": harita[k], "gid": y.get("gid"),
                    "icid": y.get("icid"), "zaman": y.get("zaman"), "etiket": et,
                    "durum": y.get("durum")})
    return out, d


def _aktif_gidler(d):
    s = set()
    for y in d.get("yamalar") or []:
        try:
            s.add(int(str(y["gid"]), 16))
        except (KeyError, TypeError, ValueError):
            pass
    return s


def _olc(parcalar):
    """Her parcanin girislerini ARSIVDEN okuyup gizli mi diye OLCER (bayrak dosyasina degil
    baytlara bakar). Parca anahtari -> {gizli_giris, giris_sayisi, gizli, okunamadi}."""
    out = {}
    lf = C._forge()
    try:
        for p in parcalar:
            n, gz, hata = 0, 0, 0
            for e in p["girisler"]:
                n += 1
                try:
                    r = GZ.gizli_mi(FG.ic_dosya(lf, e["gid"], e["icid"]))
                    gz += 1 if r["hepsi_gizli"] else 0
                except Exception:                               # noqa: BLE001
                    hata += 1
            out[p["anahtar"]] = {"gizli_giris": gz, "giris_sayisi": n, "okunamadi": hata,
                                 "gizli": bool(n and gz == n)}
    finally:
        C.release_forge(onbellek=False)
    return out


# ----------------------------------------------------------------- 1) LISTE
@_zincirli
def parcalar(ad, tur="out"):
    """Bir ogenin parca listesi (SALT OKUMA; arsiv yalniz okunur).

    -> {ok, oge, gorunen_ad, tur, silah, parcalar:[{anahtar, gorunen_ad, aile, govde,
        bant_sayisi, giris_sayisi, bant_bilgisi, gizli, gizli_giris, kayit_sayisi, paylasan,
        gizlenebilir, sebep}], gizli_sayisi, mesaj, mesaj_kalip}
    `gizli` BAYTLARDAN olculur (her yazilacak giris dejenere mi); `kayit_sayisi` bu parcanin
    etkin 'hide:' kayit sayisi. Ikisi ayrilir: vanilla'da zaten dejenere giris var
    (Boots_Edward_Assassin_LOD0) ve baska aracin gizlemesi de baytlarda gorunur."""
    try:
        t = _tur(tur)
    except ValueError as e:
        return {"ok": False, "mesaj": str(e), "parcalar": []}
    anahtar = _anahtar(ad, t)
    silah = (t == "wpn")
    if not anahtar:
        return {"ok": False, "mesaj": "Pick an item first.", "parcalar": []}
    try:
        kayit, liste = _parca_kayitlari(anahtar, silah)
    except (KeyError, FileNotFoundError) as e:
        return {"ok": False, "oge": anahtar, "parcalar": [],
                "mesaj": "This item is not in the 3D index (%s)." % e}
    forge = _forge()
    olcum, olcum_hatasi = {}, None
    try:
        olcum = _olc(liste)
    except Exception as e:                                      # noqa: BLE001
        olcum_hatasi = str(e)[:200]
    try:
        kayitlar, _d = _hide_kayitlari(forge, _giris_haritasi(liste))
    except Exception:                                           # noqa: BLE001
        kayitlar = []
    kayit_say = {}
    for k in kayitlar:
        kayit_say[k["parca"]] = kayit_say.get(k["parca"], 0) + 1
    out = []
    for p in liste:
        o = olcum.get(p["anahtar"]) or {}
        try:
            paylasan = (MI._paylasan_oge_sayisi(p["girisler"][0]["gid_hex"], haric=anahtar,
                                                silah_dahil=True)
                        if p["girisler"] else None)
        except Exception:                                       # noqa: BLE001
            paylasan = None
        out.append({"anahtar": p["anahtar"], "gorunen_ad": p["gorunen_ad"], "aile": p["aile"],
                    "govde": bool(p["govde"]), "bant_sayisi": int(p["bant_sayisi"]),
                    "giris_sayisi": len(p["girisler"]), "bant_bilgisi": bool(p["bant_bilgisi"]),
                    "gizli": (None if olcum_hatasi else bool(o.get("gizli"))),
                    "gizli_giris": int(o.get("gizli_giris") or 0),
                    "okunamadi": int(o.get("okunamadi") or 0),
                    "kayit_sayisi": int(kayit_say.get(p["anahtar"], 0)),
                    "paylasan": paylasan,
                    "gizlenebilir": bool(p["girisler"]) and not p["sebep"],
                    "sebep": p["sebep"]})
    gizli_n = sum(1 for p in out if p["gizli"])
    r = {"ok": True, "oge": anahtar, "gorunen_ad": kayit.get("gorunen_ad") or anahtar,
         "tur": t, "silah": silah, "parcalar": out, "gizli_sayisi": gizli_n,
         "giris_sayisi": sum(p["giris_sayisi"] for p in out),
         "mesaj": "%d part(s), %d hidden." % (len(out), gizli_n),
         "mesaj_kalip": _kalip("{0} part(s), {1} hidden.", [len(out), gizli_n])}
    if olcum_hatasi:
        r["olcum_hatasi"] = olcum_hatasi
        r["mesaj"] = "%d part(s); the archive could not be read to tell which are hidden (%s)." % (
            len(out), olcum_hatasi)
    return r


# ----------------------------------------------------------------- 2) PLAN (yazmaz)
def _secim(secilen):
    out, gor = [], set()
    if isinstance(secilen, (str, bytes)):
        secilen = [secilen]
    for s in (secilen or []):
        s = str(s or "").strip()
        if s and s not in gor:
            gor.add(s)
            out.append(s)
    return out


def _plan_ic(ad, secilen, tur):
    """Tam plan; her isin `_is` alani yazilacak baytlari tasir (JSON'a GIRMEZ)."""
    t = _tur(tur)
    anahtar = _anahtar(ad, t)
    silah = (t == "wpn")
    forge = _forge()
    p = {"ok": False, "oge": anahtar, "tur": t, "isler": [], "red": [], "atlanan": [],
         "uyari": [], "yazilacak": 0, "buyume_tahmini": 0, "ozet": "", "ozet_kalip": None}
    if not anahtar:
        p["ozet"] = "Pick an item first."
        p["ozet_kalip"] = _kalip("Pick an item first.", [])
        return p
    sec = _secim(secilen)
    if not sec:
        p["ozet"] = "Nothing selected - tick at least one part."
        p["ozet_kalip"] = _kalip("Nothing selected - tick at least one part.", [])
        return p
    try:
        kayit, liste = _parca_kayitlari(anahtar, silah)
    except (KeyError, FileNotFoundError) as e:
        p["ozet"] = "This item is not in the 3D index (%s)." % e
        p["ozet_kalip"] = _kalip("This item is not in the 3D index ({0}).", [str(e)])
        return p
    p["gorunen_ad"] = kayit.get("gorunen_ad") or anahtar
    parca = dict((x["anahtar"], x) for x in liste)
    try:
        _k, d = _hide_kayitlari(forge, _giris_haritasi(liste))
        mevcut = {}
        for y in d.get("yamalar") or []:
            try:
                mevcut[(int(str(y["gid"]), 16), int(str(y["icid"]), 16))] = y
            except (KeyError, TypeError, ValueError):
                pass
    except Exception:                                           # noqa: BLE001
        mevcut = {}
    lf = C._forge()
    try:
        for key in sec:
            x = parca.get(key)
            if x is None:
                p["red"].append({"anahtar": key,
                                 "sebep": "there is no part called '%s' on this item" % key})
                continue
            if not x["girisler"]:
                p["red"].append({"anahtar": key, "gorunen_ad": x["gorunen_ad"],
                                 "sebep": x["sebep"] or "this part has no mesh entry"})
                continue
            girisler, isler, red, notlar = [], [], None, []
            for e in x["girisler"]:
                bant_m = ("LOD band %s" % e["bant"]) if e["bant"] is not None else "closest mesh"
                cat = KM._catisma(forge, e["gid"])
                if cat:
                    red = ("its %s is held by the texture tool; revert the painted textures "
                           "first (%s)" % (bant_m, cat))
                    break
                try:
                    data = FG.ic_dosya(lf, e["gid"], e["icid"])
                except Exception as ex:                         # noqa: BLE001
                    red = ("the game archive does not hold its %s any more (%s); the 3D index "
                           "may be out of date" % (bant_m, str(ex)[:120]))
                    break
                try:
                    yeni, rap = GZ.gizle(data)
                except Exception as ex:                         # noqa: BLE001
                    red = "its %s cannot be hidden: %s" % (bant_m, ex)
                    break
                zaten = bool(rap.get("zaten_gizliydi"))
                try:
                    ham_boy = len(lf.read_raw(e["gid"]))
                except Exception:                               # noqa: BLE001
                    ham_boy = 0
                m = mevcut.get((e["gid"], e["icid"]))
                girisler.append({"gid": e["gid_hex"], "icid": e["icid_hex"], "ad": e["ad"],
                                 "bant": e["bant"], "mesafe": e["mesafe"], "rol": e["rol"],
                                 "birincil": bool(e["birincil"]), "ic_bayt": len(data),
                                 "zaten_gizli": zaten, "ucgen": int(rap.get("NT") or 0),
                                 "mevcut_yama": ((m or {}).get("id")),
                                 "mevcut_etiket": ((m or {}).get("etiket"))})
                if not zaten:
                    isler.append({"gid": e["gid"], "icid": e["icid"], "yeni_ic": yeni,
                                  "eski_bayt": len(data), "ad": e["ad"], "bant": e["bant"],
                                  "birincil": bool(e["birincil"]), "giris_bayt": ham_boy})
            if red:
                # TUMU-YA-DA-HIC: bir bandi yazilamayan parca HIC yazilmaz (yalniz yakin bant
                # yazilsa oyun ilk bant sinirinin otesinde parcayi geri getirir).
                p["red"].append({"anahtar": key, "gorunen_ad": x["gorunen_ad"],
                                 "sebep": ("%s A part is hidden in every LOD band the game "
                                           "draws it from, or not at all - so nothing is "
                                           "written for it." % red)})
                continue
            if not isler:
                p["atlanan"].append({"anahtar": key, "gorunen_ad": x["gorunen_ad"],
                                     "sebep": "already hidden - nothing to do (Show again "
                                              "brings it back)"})
                continue
            try:
                paylasan = MI._paylasan_oge_sayisi(x["girisler"][0]["gid_hex"], haric=anahtar,
                                                   silah_dahil=True)
            except Exception:                                   # noqa: BLE001
                paylasan = None
            if not x["bant_bilgisi"] and x["bant_sayisi"] > 1:
                notlar.append("the 3D index holds no LOD layout for this part, so only its "
                              "closest mesh is hidden; from farther away it may still show")
            if x["atlanan_bant"]:
                notlar.append("%d shadow/far-distance mesh(es) keep the original outline "
                              "(from %s away)"
                              % (len(x["atlanan_bant"]),
                                 ", ".join(MI._m_metni(m_) for _b, m_ in x["atlanan_bant"])))
            if paylasan:
                notlar.append("SHARED: %d other item(s) draw this same mesh and lose it too"
                              % paylasan)
            if x["govde"]:
                notlar.append("this is the character's own body or face; hiding it leaves "
                              "a hole, not bare skin")
            yamali = [g for g in girisler if g["mevcut_yama"] and not g["zaten_gizli"]]
            if yamali:
                notlar.append("this part already carries a patch (%s); hiding stacks on top "
                              "of it, and Show again brings back the ORIGINAL game mesh, not "
                              "the patched one" % ", ".join(sorted({g["mevcut_yama"]
                                                                    for g in yamali})))
            for n_ in notlar:
                p["uyari"].append({"anahtar": key, "not": n_})
            p["isler"].append({"anahtar": key, "gorunen_ad": x["gorunen_ad"],
                               "aile": x["aile"], "girisler": girisler,
                               "bant_sayisi": int(x["bant_sayisi"]),
                               "giris_sayisi": len(girisler), "yazilacak": len(isler),
                               "zaten_gizli": sum(1 for g in girisler if g["zaten_gizli"]),
                               "paylasan": paylasan, "govde": bool(x["govde"]),
                               "bant_bilgisi": bool(x["bant_bilgisi"]),
                               "buyume_tahmini": sum(i["giris_bayt"] for i in isler),
                               "notlar": notlar, "_is": isler})
    finally:
        C.release_forge(onbellek=False)
    p["yazilacak"] = sum(i["yazilacak"] for i in p["isler"])
    p["buyume_tahmini"] = sum(i["buyume_tahmini"] for i in p["isler"])
    n_p, n_g = len(p["isler"]), p["yazilacak"]
    if n_p:
        p["ok"] = True
        kb = int(round(p["buyume_tahmini"] / 1024.0))
        p["ozet"] = ("%d part(s) will be hidden - %d mesh entries across all their LOD bands. "
                     "The archive grows by about %d KB (the original bytes stay in place); "
                     "Show again puts everything back." % (n_p, n_g, kb))
        p["ozet_kalip"] = _kalip("{0} part(s) will be hidden - {1} mesh entries across all "
                                 "their LOD bands. The archive grows by about {2} KB (the "
                                 "original bytes stay in place); Show again puts everything "
                                 "back.", [n_p, n_g, kb])
        ek = []
        if p["atlanan"]:
            ek.append("%d already hidden" % len(p["atlanan"]))
        if p["red"]:
            ek.append("%d refused" % len(p["red"]))
        if ek:
            p["ozet"] += " (%s)" % ", ".join(ek)
    elif p["atlanan"] and not p["red"]:
        p["ozet"] = "Nothing to do - the selected part(s) are already hidden."
        p["ozet_kalip"] = _kalip("Nothing to do - the selected part(s) are already hidden.", [])
    else:
        ilk = (p["red"][0]["sebep"] if p["red"] else "nothing selected")
        p["ozet"] = "Nothing can be hidden: %s" % ilk
        p["ozet_kalip"] = _kalip("Nothing can be hidden: {0}", [ilk])
    return p


def _json_plan(p):
    """`_is` (baytlar) atilmis kopya -- pywebview/JSON icin."""
    q = dict(p)
    q["isler"] = [dict((k, v) for k, v in i.items() if k != "_is") for i in p.get("isler") or []]
    return q


@_zincirli
def plan(ad, secilen_anahtarlar, tur="out"):
    """Secilen parcalar icin NE YAZILACAGINI hesaplar. HICBIR SEY YAZMAZ (arsiv 'rb').

    -> {ok, oge, gorunen_ad, isler:[{anahtar, gorunen_ad, girisler:[{gid, icid, ad, bant,
        mesafe, rol, birincil, ic_bayt, zaten_gizli, mevcut_yama}], bant_sayisi, giris_sayisi,
        yazilacak, paylasan, govde, notlar}], red:[{anahtar, sebep}], atlanan:[...],
        uyari:[{anahtar, not}], yazilacak, buyume_tahmini, ozet, ozet_kalip:{t, a}}
    Gizleme baytlari burada uretilir ve yazicinin KENDI kapilari (gizle.gizle: uzunluk,
    IndexBuffer disina tasma, geri okuma, sifir alan) onay ekraninda gorunur; `uygula`
    ayni plani yeniden uretir (0,1-0,2 s) ve kurar."""
    try:
        return _json_plan(_plan_ic(ad, secilen_anahtarlar, tur))
    except ValueError as e:
        return {"ok": False, "isler": [], "red": [], "atlanan": [], "ozet": str(e),
                "ozet_kalip": _kalip(str(e), [])}


# ----------------------------------------------------------------- 3) UYGULA (yazar)
def _geri_sar(kayit_ids, progress):
    """Bu cagrida yazilanlari EN YENIDEN ESKIYE geri al. Zincir kurali: ayni gid'in en yeni
    halkasi geri alininca eskileri kur_mesh olu isaretler -> onlar 'not active' doner, hata
    sayilmaz. Doner (geri_alinan, hatalar)."""
    n, hata = 0, []
    for kid in reversed(kayit_ids):
        aktif = {y.get("id") for y in (KM.durum(_forge()).get("yamalar") or [])}
        if kid not in aktif:
            continue
        try:
            g = KM.geri_al(kid)
        except Exception as e:                                  # noqa: BLE001
            g = {"ok": False, "mesaj": str(e)}
        if g.get("ok"):
            n += 1
            _log(progress, "    rolled back: %s" % kid)
        else:
            hata.append("%s (%s)" % (kid, g.get("mesaj") or "no reason given"))
            _log(progress, "    ROLLBACK FAILED: %s - %s" % (kid, g.get("mesaj")))
    return n, hata


@_zincirli
def uygula(ad, secilen_anahtarlar, tur="out", etiket="", progress=None):
    """Secilen parcalari GIZLE (plan -> kur_mesh.kur). TEK YAZICI: kur_mesh.kur.

    Her giris: WAL kaydi ilk bayttan once, yazim sonrasi diskten geri okuma (kur_mesh),
    sonra bu modulun kendi olcumu (gizle.gizli_mi). ILK DUSEN -> bu cagrida yazilan HER SEY
    geri sarilir (en yeniden eskiye); yarim gizlenmis parca birakilmaz.
    -> {ok, yazilan:[{anahtar, gorunen_ad, gid, icid, ad, bant, kayit_id, ic_bayt, buyume}],
        yazilan_sayi, parcalar:[anahtar], kayit:[id], buyume, geri_alinan, red, atlanan,
        mesaj, mesaj_kalip}"""
    try:
        p = _plan_ic(ad, secilen_anahtarlar, tur)
    except ValueError as e:
        return {"ok": False, "yazilan": [], "yazilan_sayi": 0, "mesaj": str(e),
                "mesaj_kalip": _kalip(str(e), [])}
    r = {"ok": False, "oge": p.get("oge"), "yazilan": [], "yazilan_sayi": 0, "parcalar": [],
         "kayit": [], "buyume": 0, "geri_alinan": 0, "red": list(p.get("red") or []),
         "atlanan": list(p.get("atlanan") or []), "uyari": list(p.get("uyari") or []),
         "mesaj": "", "mesaj_kalip": None, "plan": _json_plan(p)}
    if not p.get("ok"):
        r["mesaj"], r["mesaj_kalip"] = p["ozet"], p["ozet_kalip"]
        return r
    k = KM.yazma_kilidi()
    if k:
        r["mesaj"] = KM._kilit_mesaji(k)
        r["mesaj_kalip"] = _kalip(r["mesaj"], [])
        return r
    if KM.oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        r["mesaj_kalip"] = _kalip("Close the game first.", [])
        return r
    forge = _forge()
    C.release_forge(onbellek=False)                 # okuma tanitici kapali, sonra yaz
    aktif_gid = _aktif_gidler(KM.durum(forge))
    gorulen, kayit_ids = set(), []
    n_top = p["yazilacak"]
    i = 0
    for is_ in p["isler"]:
        for w in is_["_is"]:
            i += 1
            bant_ek = (w["bant"] is not None and not w["birincil"])
            et = "%s%s:%s%s%s" % (ETIKET_ONEK, p["oge"], is_["anahtar"],
                                  (" [LOD band %s]" % w["bant"]) if bant_ek else "",
                                  (" | %s" % etiket) if etiket else "")
            _log(progress, "  hide %d of %d: %s%s" % (i, n_top, is_["gorunen_ad"],
                                                      (" (LOD band %s)" % w["bant"]) if bant_ek else ""))
            ustune = (w["gid"] in gorulen) or (w["gid"] in aktif_gid)
            try:
                kr = KM.kur(forge, w["gid"], w["icid"], w["yeni_ic"], etiket=et, ustune=ustune)
            except Exception as e:                              # noqa: BLE001
                kr = {"ok": False, "mesaj": "the installer failed (%s)" % e}
            if not kr.get("ok"):
                sebep = kr.get("mesaj") or "the install refused."
                _log(progress, "    REFUSED: %s" % sebep)
                n_geri, hata = _geri_sar(kayit_ids, progress)
                C._invalidate_cache()
                r["geri_alinan"] = n_geri
                r["red"].append({"anahtar": is_["anahtar"], "gorunen_ad": is_["gorunen_ad"],
                                 "sebep": sebep})
                r["mesaj"] = ("Nothing was hidden: %s%s refused (%s). %d entr%s written before "
                              "it %s rolled back%s."
                              % (is_["gorunen_ad"], (" LOD band %s" % w["bant"]) if bant_ek else "",
                                 sebep, len(kayit_ids), "y" if len(kayit_ids) == 1 else "ies",
                                 "was" if len(kayit_ids) == 1 else "were",
                                 "" if not hata else
                                 (" - %d COULD NOT be rolled back (%s); use Revert all"
                                  % (len(hata), "; ".join(hata)))))
                r["mesaj_kalip"] = _kalip("Nothing was hidden: {0} refused ({1}). {2} entries "
                                          "written before it were rolled back.",
                                          [is_["gorunen_ad"], sebep, len(kayit_ids)])
                r["gerial_hatasi"] = hata
                return r
            gorulen.add(w["gid"])
            kayit_ids.append(kr.get("kayit_id"))
            r["yazilan"].append({"anahtar": is_["anahtar"], "gorunen_ad": is_["gorunen_ad"],
                                 "gid": _hx(w["gid"]), "icid": _hx(w["icid"]), "ad": w["ad"],
                                 "bant": w["bant"], "kayit_id": kr.get("kayit_id"),
                                 "ic_bayt": w["eski_bayt"], "buyume": int(kr.get("buyume") or 0)})
            r["buyume"] += int(kr.get("buyume") or 0)
            _log(progress, "    written: %d B inner file, same size (%s)"
                 % (w["eski_bayt"], kr.get("kayit_id")))
        r["parcalar"].append(is_["anahtar"])
    C._invalidate_cache()
    # OLCUM: yazilan her giris diskten geri okununca GERCEKTEN gizli mi? (kod varligi kanit
    # degil.) Degilse yazilanlar geri sarilir ve is basarisiz sayilir.
    eksik = []
    lf = C._forge()
    try:
        for w in r["yazilan"]:
            try:
                g = GZ.gizli_mi(FG.ic_dosya(lf, int(w["gid"], 16), int(w["icid"], 16)))
                if not g["hepsi_gizli"]:
                    eksik.append(w["ad"])
            except Exception as e:                              # noqa: BLE001
                eksik.append("%s (%s)" % (w["ad"], e))
    finally:
        C.release_forge(onbellek=False)
    if eksik:
        n_geri, hata = _geri_sar(kayit_ids, progress)
        C._invalidate_cache()
        r["geri_alinan"] = n_geri
        r["yazilan"], r["parcalar"] = [], []
        r["mesaj"] = ("Nothing was hidden: after writing, %d mesh entr%s read back NOT hidden "
                      "(%s); everything written was rolled back%s."
                      % (len(eksik), "y" if len(eksik) == 1 else "ies", ", ".join(eksik[:3]),
                         "" if not hata else " - %d could not be (%s)" % (len(hata), "; ".join(hata))))
        r["mesaj_kalip"] = _kalip("Nothing was hidden: after writing, {0} mesh entries read "
                                  "back NOT hidden; everything written was rolled back.",
                                  [len(eksik)])
        return r
    r["ok"] = True
    r["kayit"] = kayit_ids
    r["yazilan_sayi"] = len(r["yazilan"])
    r["dogrulama"] = {"olculen_gizli": len(r["yazilan"]), "beklenen": len(r["yazilan"])}
    n_p = len(r["parcalar"])
    r["mesaj"] = ("%d part(s) hidden (%d mesh entries, every LOD band) - start the game to "
                  "see it. Show again brings them back." % (n_p, r["yazilan_sayi"]))
    r["mesaj_kalip"] = _kalip("{0} part(s) hidden ({1} mesh entries, every LOD band) - start "
                              "the game to see it. Show again brings them back.",
                              [n_p, r["yazilan_sayi"]])
    if r["atlanan"]:
        r["mesaj"] += " %d already hidden." % len(r["atlanan"])
    if r["red"]:
        r["mesaj"] += " %d refused - see the list." % len(r["red"])
    _log(progress, "SUCCESS: %s" % r["mesaj"])
    return r


# ----------------------------------------------------------------- 4) GOSTER (geri al)
@_zincirli
def goster(ad, anahtarlar=None, tur="out", progress=None):
    """Gizli parcalari GERI GETIR: yalniz bu ogenin 'hide:' etiketli kur_mesh kayitlari,
    en yeniden eskiye. anahtarlar=None -> bu ogenin gizli parcalarinin HEPSI.
    -> {ok, oge, geri_alinan, parcalar:[anahtar], sonuclar:[{id, parca, ok, mesaj}],
        red:[{anahtar, sebep}], kuyruk_bayt, mesaj, mesaj_kalip}"""
    try:
        t = _tur(tur)
    except ValueError as e:
        return {"ok": False, "geri_alinan": 0, "mesaj": str(e), "mesaj_kalip": _kalip(str(e), [])}
    anahtar = _anahtar(ad, t)
    silah = (t == "wpn")
    r = {"ok": False, "oge": anahtar, "geri_alinan": 0, "parcalar": [], "sonuclar": [],
         "red": [], "kuyruk_bayt": None, "mesaj": "", "mesaj_kalip": None}
    try:
        _kayit_, liste = _parca_kayitlari(anahtar, silah)
    except (KeyError, FileNotFoundError) as e:
        r["mesaj"] = "This item is not in the 3D index (%s)." % e
        r["mesaj_kalip"] = _kalip("This item is not in the 3D index ({0}).", [str(e)])
        return r
    forge = _forge()
    harita = _giris_haritasi(liste)
    kayitlar, d = _hide_kayitlari(forge, harita)
    parca_ad = dict((x["anahtar"], x["gorunen_ad"]) for x in liste)
    gizli = []
    for k in kayitlar:
        if k["parca"] not in gizli:
            gizli.append(k["parca"])
    if anahtarlar is None:
        sec = list(gizli)
    else:
        sec = _secim(anahtarlar)
        for s in sec:
            if s not in parca_ad:
                r["red"].append({"anahtar": s, "sebep": "there is no part called '%s' on this item" % s})
            elif s not in gizli:
                r["red"].append({"anahtar": s, "sebep": "this part has no hide record to revert"})
        sec = [s for s in sec if s in gizli]
    if not sec:
        r["mesaj"] = ("Nothing to show again - no hidden parts are recorded for this item."
                      if not gizli else "None of the selected parts is hidden.")
        r["mesaj_kalip"] = _kalip(r["mesaj"], [])
        return r
    # ZINCIR KAPISI: secilen parcanin gid'inde SECILMEYEN bir parcanin hide kaydi varsa
    # (NPC Head_X / Head_X#1 ayni girisi paylasir) tek basina geri alinamaz -- kur_mesh en
    # yeni halkayi geri alinca giris vanilla'ya doner ve oteki parca da gorunur olurdu.
    gid_parca = {}
    for k in kayitlar:
        gid_parca.setdefault(k["gid"], set()).add(k["parca"])
    engel = []
    for s in list(sec):
        ort = set()
        for k in kayitlar:
            if k["parca"] == s:
                ort |= (gid_parca.get(k["gid"], set()) - set(sec))
        if ort:
            engel.append(s)
            r["red"].append({"anahtar": s,
                             "sebep": ("it shares an archive entry with hidden part(s) %s - "
                                       "show them together" % ", ".join(sorted(parca_ad.get(o, o)
                                                                                for o in ort)))})
    sec = [s for s in sec if s not in engel]
    if not sec:
        r["mesaj"] = "Nothing was reverted: %s" % r["red"][0]["sebep"]
        r["mesaj_kalip"] = _kalip("Nothing was reverted: {0}", [r["red"][0]["sebep"]])
        return r
    k_ = KM.yazma_kilidi()
    if k_:
        r["mesaj"] = KM._kilit_mesaji(k_)
        r["mesaj_kalip"] = _kalip(r["mesaj"], [])
        return r
    if KM.oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        r["mesaj_kalip"] = _kalip("Close the game first.", [])
        return r
    C.release_forge(onbellek=False)
    hedef = [k for k in kayitlar if k["parca"] in sec]
    n_ok, n_hata = 0, 0
    for k in reversed(hedef):                                   # en yeniden eskiye
        aktif = {y.get("id") for y in (KM.durum(forge).get("yamalar") or [])}
        if k["id"] not in aktif:
            r["sonuclar"].append({"id": k["id"], "parca": k["parca"], "ok": True,
                                  "mesaj": "already reverted with a newer record on the same entry"})
            continue
        _log(progress, "  show again: %s (%s)" % (parca_ad.get(k["parca"], k["parca"]), k["id"]))
        try:
            g = KM.geri_al(k["id"])
        except Exception as e:                                  # noqa: BLE001
            g = {"ok": False, "mesaj": str(e)}
        r["sonuclar"].append({"id": k["id"], "parca": k["parca"], "ok": bool(g.get("ok")),
                              "mesaj": g.get("mesaj"), "kuyruk_bayt": g.get("kuyruk_bayt")})
        if g.get("ok"):
            n_ok += 1
        else:
            n_hata += 1
            _log(progress, "    FAILED: %s" % g.get("mesaj"))
    C._invalidate_cache()
    r["geri_alinan"] = n_ok
    try:
        r["kuyruk_bayt"] = KM.kuyruk_bayt(forge)
    except Exception:                                           # noqa: BLE001
        r["kuyruk_bayt"] = None
    # hangi parcalar gercekten geri geldi? (kayit kalmadi)
    kalan, _d2 = _hide_kayitlari(forge, harita)
    kalan_p = {k["parca"] for k in kalan}
    r["parcalar"] = [s for s in sec if s not in kalan_p]
    r["ok"] = (n_hata == 0 and bool(r["parcalar"]))
    n_p = len(r["parcalar"])
    if r["ok"]:
        r["mesaj"] = "%d part(s) shown again - the original meshes are back." % n_p
        r["mesaj_kalip"] = _kalip("{0} part(s) shown again - the original meshes are back.", [n_p])
        if r["red"]:
            r["mesaj"] += " %d skipped - see the list." % len(r["red"])
    else:
        ilk = next((s["mesaj"] for s in r["sonuclar"] if not s["ok"]), None) or "no record reverted"
        r["mesaj"] = ("%d of %d part(s) shown again; %d record(s) could not be reverted (%s)."
                      % (n_p, len(sec), n_hata, ilk))
        r["mesaj_kalip"] = _kalip("{0} of {1} part(s) shown again; {2} record(s) could not be "
                                  "reverted ({3}).", [n_p, len(sec), n_hata, ilk])
    return r


# ----------------------------------------------------------------- 5) DURUM
@_zincirli
def durum(ad, tur="out"):
    """Bu ogenin gizleme durumu (salt okuma).
    -> {ok, oge, gizli_parcalar:[anahtar] (etkin 'hide:' kaydi olanlar = Show again'in geri
        getirebilecekleri), olculen_gizli:[anahtar] (BAYTLARDA butun girisleri dejenere
        olanlar), kayit_sayisi, kayitlar:[{id, parca, gid, icid, zaman, etiket, durum}],
        toplam_yama (bu arsivdeki TUM etkin mesh yamalari), kuyruk_bayt, mesaj}"""
    try:
        t = _tur(tur)
    except ValueError as e:
        return {"ok": False, "gizli_parcalar": [], "kayit_sayisi": 0, "mesaj": str(e)}
    anahtar = _anahtar(ad, t)
    silah = (t == "wpn")
    try:
        _kayit_, liste = _parca_kayitlari(anahtar, silah)
    except (KeyError, FileNotFoundError) as e:
        return {"ok": False, "oge": anahtar, "gizli_parcalar": [], "kayit_sayisi": 0,
                "mesaj": "This item is not in the 3D index (%s)." % e}
    forge = _forge()
    kayitlar, d = _hide_kayitlari(forge, _giris_haritasi(liste))
    gizli = []
    for k in kayitlar:
        if k["parca"] not in gizli:
            gizli.append(k["parca"])
    olculen = []
    try:
        o = _olc(liste)
        olculen = [p["anahtar"] for p in liste if (o.get(p["anahtar"]) or {}).get("gizli")]
    except Exception:                                           # noqa: BLE001
        olculen = None
    return {"ok": True, "oge": anahtar, "tur": t, "gizli_parcalar": gizli,
            "olculen_gizli": olculen, "kayit_sayisi": len(kayitlar), "kayitlar": kayitlar,
            "toplam_yama": int(d.get("aktif") or 0), "kuyruk_bayt": d.get("kuyruk_bayt"),
            "kayit_dosyasi": d.get("kayit"),
            "mesaj": "%d hidden part(s), %d record(s)." % (len(gizli), len(kayitlar)),
            "mesaj_kalip": _kalip("{0} hidden part(s), {1} record(s).", [len(gizli), len(kayitlar)])}


if __name__ == "__main__":                                      # elle yoklama (salt okuma)
    import pprint
    import sys
    _ad = sys.argv[1] if len(sys.argv) > 1 else "Edward_Assassin"
    _t = sys.argv[2] if len(sys.argv) > 2 else "out"
    pprint.pprint(parcalar(_ad, _t))
    pprint.pprint(durum(_ad, _t))
