# -*- coding: utf-8 -*-
"""
parmak_izi.py — icerik-temelli doku parmak izi (Outfit Workshop v0.7 "Add a Mod").

TEK gorev: RGBA goruntuden kucuk, karsilastirabilir bir parmak izi cikarmak.
Hem indeks ureticisi (indeks_uret.py) hem esleyici (eslestir.py) BU modulu
kullanir — iki taraf ayni koddan gecmezse olcumler anlamsizlasir.

Parmak izi bilesenleri (doku basina ~1,3 KB):
  * W, H, oran            : boyut + en/boy orani (aday filtresi)
  * dhash_h, dhash_v      : 64+64 bit fark-hash (luminans; gradyan tabanli,
                            tekduze renk degisimine buyuk olcude dayanikli)
  * dhash_g_h             : 64 bit fark-hash (G kanali; normal haritalarda
                            luminans neredeyse sabit oldugu icin ayri kanal)
  * thumb (5x16x16 uint8) : L,R,G,B,A kucuk resimleri (ZNCC skoru icin)

Karsilastirma: skor() -> 0..1 arasi benzerlik. Karar esikleri eslestir.py'de.
"""
import numpy as np

THUMB = 16          # kucuk resim kenari
HASH_N = 8          # dhash izgarasi (8x8 -> 64 bit)


# ------------------------------------------------------------------ yardimcilar
def _area_resize(gri, w, h):
    """float2d -> (h,w) alan-ortalamali kucultme (PIL'siz, deterministik)."""
    H, W = gri.shape
    ys = (np.arange(h + 1) * H // h).astype(np.int64)
    xs = (np.arange(w + 1) * W // w).astype(np.int64)
    # kumulatif toplam (integral goruntu) ile hizli blok ortalamasi
    c = np.zeros((H + 1, W + 1), dtype=np.float64)
    c[1:, 1:] = np.cumsum(np.cumsum(gri, axis=0), axis=1)
    out = np.empty((h, w), dtype=np.float64)
    for i in range(h):
        y0, y1 = ys[i], max(ys[i + 1], ys[i] + 1)
        for j in range(w):
            x0, x1 = xs[j], max(xs[j + 1], xs[j] + 1)
            s = c[y1, x1] - c[y0, x1] - c[y1, x0] + c[y0, x0]
            out[i, j] = s / ((y1 - y0) * (x1 - x0))
    return out


def _dhash_bits(kucuk_h1):
    """(N, N+1) izgaradan yatay fark-hash -> int (N*N bit)."""
    d = kucuk_h1[:, 1:] > kucuk_h1[:, :-1]
    v = 0
    for b in d.flatten():
        v = (v << 1) | int(b)
    return v


def hamming(a, b, bits=64):
    return bin(a ^ b).count("1")


# ------------------------------------------------------------------ parmak izi
def parmak_izi(rgba):
    """rgba: (H,W,4) uint8 -> dict parmak izi."""
    rgba = np.asarray(rgba)
    H, W = rgba.shape[:2]
    f = rgba.astype(np.float64)
    R, G, B, A = f[..., 0], f[..., 1], f[..., 2], f[..., 3]
    L = 0.299 * R + 0.587 * G + 0.114 * B

    # dhash: yatay (8x9) + dikey (9x8) luminans, yatay G kanali
    lh = _area_resize(L, HASH_N + 1, HASH_N)          # (8,9)
    lv = _area_resize(L, HASH_N, HASH_N + 1)          # (9,8)
    gh = _area_resize(G, HASH_N + 1, HASH_N)

    thumb = np.stack([
        _area_resize(L, THUMB, THUMB),
        _area_resize(R, THUMB, THUMB),
        _area_resize(G, THUMB, THUMB),
        _area_resize(B, THUMB, THUMB),
        _area_resize(A, THUMB, THUMB),
    ]).astype(np.float32)

    return {
        "W": int(W), "H": int(H), "oran": W / float(H),
        "dhash_h": _dhash_bits(lh),
        "dhash_v": _dhash_bits(lv.T),
        "dhash_g_h": _dhash_bits(gh),
        "thumb": np.round(thumb).astype(np.uint8),
    }


def png_parmak_izi(yol):
    """PNG dosyasindan parmak izi (RGBA'ya cevirir)."""
    from PIL import Image
    im = Image.open(yol)
    im = im.convert("RGBA")
    return parmak_izi(np.asarray(im))


# ------------------------------------------------------------------ skorlama
def _zncc(a, b):
    """sifir-ortalamali normalize capraz korelasyon; sabit kanalda 0 dondurur."""
    a = a.astype(np.float64).ravel()
    b = b.astype(np.float64).ravel()
    a -= a.mean(); b -= b.mean()
    na, nb = np.sqrt((a * a).sum()), np.sqrt((b * b).sum())
    if na < 1e-6 or nb < 1e-6:
        # ikisi de sabitse ve ortalamalari yakinsa "benzer" say (duz maskeler)
        return 0.0
    return float((a * b).sum() / (na * nb))


def _zncc_trim(a, b, tut=0.75):
    """budanmis ZNCC: en kotu (1-tut) piksel atilir — desen bindirme / bolgesel
    boyama gibi YEREL mudahalelere dayaniklilik. (Alakasiz ciftlerde de skoru
    sisirir; esik olcumleri BU fonksiyon dahilken yapildi.)"""
    a = a.astype(np.float64).ravel()
    b = b.astype(np.float64).ravel()
    az = a - a.mean(); bz = b - b.mean()
    sa, sb = az.std(), bz.std()
    if sa < 1e-6 or sb < 1e-6:
        return 0.0
    az /= sa; bz /= sb
    d = (az - bz) ** 2
    k = max(8, int(len(d) * tut))
    idx = np.argsort(d)[:k]
    return _zncc(a[idx], b[idx])


def _duz_mu(thumb):
    """kucuk resim (5,16,16): L+RGB kanallari neredeyse sabit mi (duz doku)."""
    return all(float(thumb[c].astype(np.float64).std()) < 2.5 for c in range(4))


def skor(fp_giris, fp_indeks):
    """iki parmak izi arasinda 0..1 benzerlik + bilesen dokumu."""
    tg, ti = fp_giris["thumb"], fp_indeks["thumb"]

    # DUZ DOKU YOLU: yapi yoksa dhash/ZNCC anlamsiz (bitler gurultuden gelir,
    # T1'de duz bir dokunun BIREBIR kopyasi 0.50 aliyordu). Iki taraf da duzse
    # ortalama renk uzakligi konusur; tek taraf duzse benzerlik dusuktur.
    dg, di = _duz_mu(tg), _duz_mu(ti)
    if dg and di:
        fark = float(np.mean(np.abs(tg[1:4].astype(np.float64) -
                                    ti[1:4].astype(np.float64))))
        # TAVAN 0.84 (< ESIK_OTOMATIK): duz bir goruntu icerikle ASLA tekil
        # kanitlanamaz (katalogda birden cok duz doku var; alakasiz duz siyah
        # da tam isabet verir). Duz girdi en fazla ADAY olabilir, otomatik olamaz.
        s = min(0.84, max(0.0, 1.0 - fark / 80.0))
        return s, {"duz": True, "renk_farki": fark}
    if dg != di:
        return 0.15, {"duz_tek": True}

    hd_l = (hamming(fp_giris["dhash_h"], fp_indeks["dhash_h"]) +
            hamming(fp_giris["dhash_v"], fp_indeks["dhash_v"])) / 128.0
    hd_g = hamming(fp_giris["dhash_g_h"], fp_indeks["dhash_g_h"]) / 64.0
    z_l = _zncc(tg[0], ti[0])
    z_lt = _zncc_trim(tg[0], ti[0])
    z_rgb = (_zncc(tg[1], ti[1]) + _zncc(tg[2], ti[2]) + _zncc(tg[3], ti[3])) / 3.0
    z_a = _zncc(tg[4], ti[4])

    # bilesim: gradyan-hash (renk degisimine dayanikli) + yapi korelasyonu
    # (tam + budanmis). alfa yalnizca iki tarafta da bilgi tasiyorsa katilir.
    a_var_g = float(np.var(tg[4].astype(np.float64))) > 4.0
    a_var_i = float(np.var(ti[4].astype(np.float64))) > 4.0
    s = (0.35 * (1.0 - hd_l) +
         0.10 * (1.0 - hd_g) +
         0.20 * max(0.0, z_l) +
         0.20 * max(0.0, z_lt) +
         0.15 * max(0.0, z_rgb))
    if a_var_g and a_var_i:
        s = 0.9 * s + 0.1 * max(0.0, z_a)
    return s, {"hd_l": hd_l, "hd_g": hd_g, "z_l": z_l, "z_lt": z_lt,
               "z_rgb": z_rgb, "z_a": z_a}


def oran_uyumlu(o1, o2, tol=1.30):
    """en/boy orani ayni sinifta mi (tol kat farka kadar)."""
    r = o1 / o2 if o1 > o2 else o2 / o1
    return r <= tol
