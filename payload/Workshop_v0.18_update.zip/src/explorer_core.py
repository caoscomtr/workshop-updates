# -*- coding: utf-8 -*-
"""explorer_core -- ALAN E: her TOC girisini disa aktar / geri koy.

Kuratorlu sekmeler (Outfits / Weapons / Sounds / Ships) bir SECKIDIR: elle olculmus,
oyun icinde denenmis hedefler. Bu modul o seckinin DISINDA kalan her sey icindir --
"bu girisi goremezsin" cumlesini kaldirir. Kullanicinin "ben yaptim ama reddedildi"
diye gelmemesi icin her red bir SEBEP tasir ve ham yol DAIMA aciktir.

BU MODUL YENI BIR MOTOR DEGILDIR. Olculmus hatlarin uzerine tek bir adres katmani
koyar; her isi ZATEN VAR OLAN modul yapar:

    tani/listeleme  forge_giris (K1/K2 ic dosya tablosu) + doku_png.ad_coz (K1 ad sifresi)
    mesh -> GLB     export3d.sahne.kur          (mesh_yapisal + iskelet + doku_png + glb_yaz)
    doku -> PNG     export3d.doku_png           (materyal / TextureSet / TextureMap)
    ses  -> WAV     ses_core.wav_uret           (vgmstream)
    her sey -> .bin forge_giris.ic_dosyalar / LeanForge.read_raw
    GLB  -> oyun    export3d.mesh_ithal.plan + uygula   (icinde kur_mesh.kur)
    PNG  -> oyun    export3d.doku_ithal.tara/hazirla/uygula (icinde doku_enjekte2)
    .bin -> oyun    export3d.kur_mesh.giris_kur + kur_mesh.kur
    geri alma       kur_mesh.geri_al (WAL kaydi + yedek + yazma sonrasi dogrulama)

TEK YAZICI KURALI: bu dosyada forge'a yazan TEK BIR satir yoktur. `open(..., "r+b")`
gecmez; yazma daima kur_mesh / doku_enjekte2 uzerinden gider, boylece Health Check,
"Revert all" ve catisma korumalari Explorer yazmalarini da gorur.

--- HAM YOL NEDEN ZORUNLU (tasarim karari) --------------------------------------------
Bir sinifi COZEMEMEK, kullaniciya VEREMEMEK demek degildir. Olculdu (DataPC_WhiteRoom.forge,
495 giris): 37 giris BMS kabi bile degil (harici mip RawAsset 0x4C8BD3BF gibi) ve hicbir
yapisal okuyucumuz onlari acmiyor -- ama baytlari cikarilabilir ve sha256'si arsivdekiyle
birebir tutar. Anvil tarzi arac tam olarak bunu yapar. Bu yuzden `yapabilecekler` listesinde
"ham" HER ZAMAN vardir ve hicbir kapiya bagli degildir.

--- ADRESLEME: gid + icid --------------------------------------------------------------
TOC girisi (gid) bir KAPTIR; icinde K1 tablosunun saydigi ic dosyalar (icid) durur. Cogu
giriste icid == gid'dir (tek ic dosya), ama olculdu: WhiteRoom'da 0x0250BC068CC3 girisi 5,
0x020759A8FE99 girisi 10 ic dosya tasir. `icid=None` verilirse:
  * tani  -> girisin TAMAMINI anlatir, yapabilecekleri ic dosyalarin BIRLESIMIdir
  * ham   -> ic dosyalarin HEPSI ayri .bin olarak cikar (kullanici hangisi oldugunu bilmeden
             de calisabilsin; bilgi.json her birinin gid/icid/sha256'sini tasir)
  * mesh  -> ilk OKUNABILIR mesh ic dosyasi secilir ve bu KAYDA GECER (sessiz secim yok)

--- ARSIV BAGLAMA (neden gecici) --------------------------------------------------------
Motorlarin hepsi okuma hedefini `outfit_core.FORGE` uzerinden bulur (doku_png, sahne,
mesh_ithal, kur_mesh ayni globali okur). Explorer 100+ forge'da gezdigi icin `_baglam`
secilen arsivi CAGRI SURESINCE baglar ve cikista eski degeri GERI KOYAR -- yoksa Outfits
sekmesi Explorer'dan sonra yanlis arsive bakardi. Ikinci bir dosya taniticisi ACILMAZ:
baglam icinde daima `outfit_core._forge()` kullanilir (Steam "Content file locked" dersi).

--- YAZMA KILIDI ------------------------------------------------------------------------
`kur_mesh.yazma_kilidi()` mesh yolunu zaten kilitler. Explorer DOKU yolunu da ayni kilide
bagliyor (doku_enjekte2'nin kendi kilidi yok): kilit dosyasi varsa `geri_yukle` HICBIR
bicimde yazmaz. Kilit yalnizca olcum yapan otomatik ajanlar icindir; son kullanicida olusmaz.
"""
import contextlib
import hashlib
import json
import os
import re
import shutil
import struct
import sys
import time

BURA = os.path.dirname(os.path.abspath(__file__))
if BURA not in sys.path:
    sys.path.insert(0, BURA)

import outfit_core as C                                        # noqa: E402
import doku_enjekte2 as DE                                     # noqa: E402  (TEK doku yazicisi)

from export3d import forge_giris as FG                         # noqa: E402
from export3d import mesh_yapisal as MY                        # noqa: E402
from export3d import doku_png as DP                            # noqa: E402
from export3d import doku_dds as DD                            # noqa: E402
from export3d import sahne as SA                               # noqa: E402
from export3d import kur_mesh as KM                            # noqa: E402
from export3d import cok_forge as CF                           # noqa: E402  (yama zinciri kurali)
import toc_ekle as TE                                          # noqa: E402  (TEK yeni-satir yolu)
import nesne as N                                              # noqa: E402  (sinif ad tablosu)

__all__ = ["tani", "disa_aktar", "geri_yukle", "cogalt", "durum", "geri_al",
           "arsiv_ayarla", "arsiv_yolu", "arsivler", "bicimler",
           "tur_ad", "agac", "cocuklar", "tur_ara", "ham_girisler", "ham_kuyruk",
           "SURUM", "BICIMLER", "BILGI_AD", "ETIKET_ONEK", "TURLER", "TUR_KURALI"]

SURUM = "1.0"
BILGI_AD = "bilgi.json"
MANIFEST_AD = "manifest.json"
TEX_KLASOR = "textures"

# kur_mesh kaydinda Explorer yazmalarini isaretleyen onek. kur_mesh'in `etiket` alani
# serbest metindir; `durum()`/`geri_al()` bu onekle suzer. kur_mesh.py'ye DOKUNULMADI.
ETIKET_ONEK = "explorer:"

BICIM_HAM = "ham"
BICIM_MESH = "mesh_glb"
BICIM_DOKU = "doku_png"
# DDS: oyunun BC bloklarini OLDUGU GIBI verir (kod cozme yok, tum mip'ler dahil).
# Ayni kapiya baglidir (`_doku_karari`); PNG ile arasindaki tek fark yazilan DOSYADIR.
BICIM_DOKU_DDS = "doku_dds"
BICIM_SES = "ses_wav"
# Otomatik secim sirasi: en anlamli bicim once, ham EN SONDA (daima calisan yedek).
# PNG once gelir: varsayilan cikti duzenlenebilir olmali; DDS uzman yoludur.
BICIMLER = (BICIM_MESH, BICIM_DOKU, BICIM_DOKU_DDS, BICIM_SES, BICIM_HAM)

# --- sinif crc'leri (proje genelinde ayni sabitler; kaynak: ansiklopedi siniflar tablosu)
TIP_MESH = 0x415D9568
TIP_TEXTUREMAP = 0xA2B7E917
TIP_TEXTURESET = 0xD70E6670
TIP_MATERIAL = 0x85C817C3
TIP_MATERIALTPL = 0xBCFB3C7A
TIP_RAWASSET = 0x4C8BD3BF
TIP_LODSELECTOR = 0x51DC6B80
# Yedek ad tablosu: `varlik_indeks` yoksa (ya da girisi tanimiyorsa) en azindan motorlarin
# ZATEN adlandirdigi siniflar okunur cikar. Genis katalog OYUNUN KENDI sinif sozlugunun
# (nesne.oyun_sinif_adlari -> build/sinif_adlari_oyun.json, 10.051 ad) ve indeksin isidir.
SINIF_ADI = {TIP_MESH: "Mesh", TIP_TEXTUREMAP: "TextureMap", TIP_TEXTURESET: "TextureSet",
             TIP_MATERIAL: "Material", TIP_MATERIALTPL: "MaterialTemplate",
             TIP_RAWASSET: "RawAsset", TIP_LODSELECTOR: "LODSelector"}

# --- TUR (Explorer agaci / tur cipleri): sinif adi -> kaba tur. Bu bir GOSTERIM
# kovasidir, motor karari degil (mesh_glb cikar mi sorusunu `tani` cevaplar).
# YENIDEN KALIBRE EDILDI (2026-09-09, v0.18: oyunun KENDI sinif sozlugu okundu).
# Indeksin sozlugu (2.436 etiket) artik 2.319 adli: mesh 17, texture 8, material 8,
# sound 228, raw 1, data 2.057. Oyunun 10.051 adinin tamaminda: mesh 42, texture 35,
# material 33, sound 452, raw 1, data 9.488. Onceki kalibrasyon 1.504 ad uzerindeydi
# (mesh 13, texture 7, material 7, sound 186, raw 2, data 1.289).
# Sira BILINCLI: once sabit tablo, sonra ses (genis, kaptanin kurali: *Sound*,
# *Audio*, *Wwise*), sonra AYAR/YONETICI kuyruklari ("NavMeshManager",
# "TextureStreamingSettings" bir mesh/doku DEGIL, veri kaydidir), en son joker.
TURLER = ("mesh", "texture", "material", "sound", "data", "raw")
TUR_KURALI = {
    "sabit": {
        "mesh": ("Mesh", "ProceduralMesh", "MeshShape", "ConvexMeshShape", "LODSelector",
                 "BulkMesh", "CbtMesh", "WaterMesh", "FakeWaterMesh", "OcclusionMesh",
                 "MotionCloth", "Skeleton", "RagdollSkeleton"),
        "texture": ("TextureMap", "TextureMapSpec", "TextureSet", "LocalCubeMap",
                    "AnimatedTexture", "VideoTexture", "TextureMapSelector"),
        "material": ("Material", "MaterialTemplate", "CompiledMaterialTemplateContainer",
                     "HairStrandsMaterial", "GlobalShaderDataTable"),
        "sound": ("SoundBankFile", "SoundBanksContainer"),
        "raw": ("RawAsset", "RawFile"),
    },
    "ses": re.compile(r"(Sound|Audio|Wwise|Music|Voice)", re.I),
    "veri": re.compile(r"(NavMesh|Info$|Settings?$|Manager$|Component$|Filter(Data)?$|"
                       r"Definition$|Repository$|Options$|Constructor$|Modifier$|"
                       r"Profile$|Context$|Reaction$|Pack$|Range$|Data$|Config$|"
                       r"Loader$|Table$|Params$|Rules?$)", re.I),
    "joker": (("mesh", re.compile(r"Mesh", re.I)),
              ("texture", re.compile(r"(Texture|CubeMap)", re.I)),
              ("material", re.compile(r"(Material|^Shader)", re.I))),
}
_TUR_SABIT = {ad.lower(): tur for tur, adlar in TUR_KURALI["sabit"].items() for ad in adlar}


def tur_ad(sinif_ad, crc=None, kap=None):
    """Sinif adi (+ istege bagli crc / kap) -> 'mesh'|'texture'|'material'|'sound'|'data'|'raw'.

    Ad '0xXXXXXXXX' ise (cozulmemis sinif) yalniz yerlesik 7 crc taninir, gerisi
    'data'. BMS kabi olmayan giris (`kap == "raw"`) ne olursa olsun 'raw'."""
    if kap == "raw":
        return "raw"
    ad = str(sinif_ad or "").strip()
    if ad.lower().startswith("0x") or not ad:
        try:
            crc = int(ad, 16) if ad else crc
        except ValueError:
            crc = None
        ad = SINIF_ADI.get(crc, "") if crc is not None else ""
        if not ad:
            return "data"
    t = _TUR_SABIT.get(ad.lower())
    if t:
        return t
    if TUR_KURALI["ses"].search(ad):
        return "sound"
    if TUR_KURALI["veri"].search(ad):
        return "data"
    for t, desen in TUR_KURALI["joker"]:
        if desen.search(ad):
            return t
    return "data"

# Doku yoklamasi girisin TAMAMINI cozer; cok buyuk girislerde bu saniyeler surer ve
# `tani` bir LISTE ekraninin altinda calisir. Sinirin ustunde doku yolu "olculmedi"
# der (yalan soylemez, "yok" demez).
DOKU_YOKLAMA_SINIRI = 96 * 1024 * 1024
# Tek girise bagli ses sayisi bir bankada binlerce olabilir; hepsini WAV'a cevirmek
# dakikalar surer. Sinir asilirsa kac tanesinin disarida kaldigi SOYLENIR.
SES_LIMIT = 64


# =====================================================================================
#  yardimcilar
# =====================================================================================
def _int(x):
    """int | '0x1FDD...' | '1FDD...' -> int (kimlikler daima ONALTILIK yazilir)."""
    if x is None:
        return None
    if isinstance(x, bool):
        raise TypeError("id must be an integer or a hex string")
    if isinstance(x, int):
        return int(x)
    s = str(x).strip()
    if not s:
        return None
    return int(s, 16)


def _hex(x, genislik=12):
    return None if x is None else ("0x%0*X" % (genislik, int(x)))


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _dosya_sha(yol):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for blok in iter(lambda: f.read(1 << 22), b""):
            h.update(blok)
    return h.hexdigest()


_AD_TEMIZ = re.compile(r"[^A-Za-z0-9_.-]+")


def _dosya_adi(ad, yedek):
    """Varlik adini dosya sistemi icin guvenli hale getir; bos kalirsa `yedek`."""
    t = _AD_TEMIZ.sub("_", str(ad or "")).strip("._")
    return (t[:80] or yedek)


def _log(progress, s):
    C._log(progress, s)


# =====================================================================================
#  GOLGELENEN GIRIS (oyunun forge yama zinciri)
# =====================================================================================
# Oyun forge'lari bir ZINCIR: `DataPC_boot.forge` -> `DataPC_boot_patch_01.forge`.
# Ayni gid iki halkada birden bulunabilir ve oyun ZINCIRIN SONUNDAKINI okur. Kullanici
# alt halkadaki kopyayi duzenlerse yazma BASARILI olur ama OYUNDA HICBIR SEY DEGISMEZ.
# Reddedilmekten beter: insan yaptigini sanir.
#
# OLCUM (2026-09-07, canli 157 forge): 34.533 giris golgede.
#   DataPC_boot        94.113 girisin  4.274'u  (%4,54)
#   DataPC_shared_00   23.255 girisin  1.003'u  (%4,31)
#   DataPC_OBD_Rift_Drop_003_nav ... %13,03 ile en yuksek oran
_GOLGE_ONBELLEK = {}


def _zincir_grubu(ad):
    """'DataPC_boot_patch_01.forge' -> ('datapc_boot', 1) · 'DataPC_boot.forge' -> (..., 0)."""
    t = ad[:-6] if ad.lower().endswith(".forge") else ad
    n = 0
    while True:
        i = t.lower().rfind("_patch_")
        if i < 0:
            break
        kuyruk = t[i + 7:]
        if not kuyruk.isdigit():
            break
        n = max(n, int(kuyruk))
        t = t[:i]
    return t.lower(), n


def _forge_gidleri(yol):
    """Bir forge'un gid kumesi (CANLI TOC'tan; boyut+mtime degisince yeniden okunur)."""
    try:
        st = os.stat(yol)
    except OSError:
        return set()
    anahtar = (os.path.normcase(yol), st.st_size, int(st.st_mtime))
    hit = _GOLGE_ONBELLEK.get(anahtar)
    if hit is not None:
        return hit
    _GOLGE_ONBELLEK.clear()                 # tek arsivlik onbellek yeter, bellegi sisirme
    # TEK arsivin TOC'u (kur_mesh ile ayni okuyucu): outfit_core'un okuma gorunumu bir zincir
    # tasiyor olsa bile (CF.okuma_gorunumu) buraya sizmaz -- yoksa boot'un her kimligi
    # "patch'te de var" gorunurdu.
    gidler = set(KM._arsiv_gidleri(yol))
    _GOLGE_ONBELLEK[anahtar] = gidler
    return gidler


def golgeleyen(gid, forge=None):
    """`gid` bu forge'da duruyor ama UST bir zincir halkasinda da var mi?

    Doner {"golgede": bool, "forge": <golgeleyen dosya adi>, "yol": <tam yol>,
           "seviye": n} -- golgede degilse {"golgede": False}.
    Ezberlenmis liste YOK: klasordeki dosyalara ve CANLI TOC'a bakar.
    """
    gid = _int(gid)
    yol = os.path.abspath(forge or arsiv_yolu())
    kok = os.path.dirname(yol)
    taban, seviye = _zincir_grubu(os.path.basename(yol))
    try:
        komsular = os.listdir(kok)
    except OSError:
        return {"golgede": False}
    adaylar = []
    for ad in komsular:
        if not ad.lower().endswith(".forge"):
            continue
        t, n = _zincir_grubu(ad)
        if t == taban and n > seviye:
            adaylar.append((n, ad))
    for n, ad in sorted(adaylar):                            # en yakin halkadan basla
        p = os.path.join(kok, ad)
        if gid in _forge_gidleri(p):
            return {"golgede": True, "forge": ad, "yol": p, "seviye": n}
    return {"golgede": False}


def _golge_mesaji(g):
    return ("This entry is also in %s, which the game loads after this archive. Editing it "
            "here would be written correctly but the game would still show the other copy. "
            "Open %s and edit it there instead." % (g.get("forge"), g.get("forge")))


def _yonlendirme_mesaji(g):
    return ("This entry is also in %s, which the game loads after this archive, so the change "
            "is written to %s (the copy the game actually uses)." % (g.get("forge"), g.get("forge")))


# =====================================================================================
#  arsiv secimi + baglam
# =====================================================================================
_ARSIV = {"yol": None}


def arsiv_yolu():
    """Explorer'in su an baktigi forge (secilmemisse Outfits'in hedefi)."""
    return os.path.abspath(_ARSIV["yol"] or C.FORGE)


def arsiv_ayarla(yol=None):
    """Explorer'in bakacagi arsivi sec (None -> outfit_core.FORGE'a don).

    Bu YALNIZ Explorer'in varsayilanidir; `outfit_core.FORGE` degismez (Outfits sekmesi
    etkilenmez). Gercek baglama her cagrida `_baglam` icinde gecici olarak yapilir."""
    if yol is None:
        _ARSIV["yol"] = None
    else:
        yol = os.path.abspath(yol)
        if not os.path.isfile(yol):
            raise FileNotFoundError("Game archive not found: %s" % yol)
        _ARSIV["yol"] = yol
    return arsiv_yolu()


def arsivler():
    """Gezilebilir forge listesi: [{ad, yol, var_mi, boyut}].

    Once `varlik_indeks.forgeler()` (indekste ADI GECEN her forge), yoksa oyun klasorundeki
    *.forge taramasi. Ikisi de yoksa yalniz aktif arsiv."""
    kok = os.path.dirname(arsiv_yolu())
    vi = _indeks_modulu()
    out, gorulen = [], set()
    if vi is not None:
        try:
            for f in (vi.forgeler() or []):
                ad = str(f.get("ad") or "")
                if not ad or ad.lower() in gorulen:
                    continue
                yol = f.get("yol") or os.path.join(kok, ad)
                gorulen.add(ad.lower())
                out.append({"ad": ad, "yol": yol, "var_mi": bool(os.path.isfile(yol)),
                            "boyut": (os.path.getsize(yol) if os.path.isfile(yol) else None),
                            "giris": f.get("sayi")})
        except Exception:                                       # noqa: BLE001 -- indeks zorunlu degil
            out = []
            gorulen = set()
    if not out and os.path.isdir(kok):
        for ad in sorted(os.listdir(kok)):
            if not ad.lower().endswith(".forge"):
                continue
            yol = os.path.join(kok, ad)
            out.append({"ad": ad, "yol": yol, "var_mi": True,
                        "boyut": os.path.getsize(yol), "giris": None})
    if not out:
        y = arsiv_yolu()
        out = [{"ad": os.path.basename(y), "yol": y, "var_mi": os.path.isfile(y),
                "boyut": (os.path.getsize(y) if os.path.isfile(y) else None), "giris": None}]
    return out


@contextlib.contextmanager
def _baglam(forge=None):
    """Secilen arsivi motorlara GECICI olarak bagla, cikista eskisini geri koy.

    `outfit_core.FORGE` (okuma) ve `doku_enjekte2.FORGE` (yazma) tek bir hedefi gosterir;
    ikisi ayrisirsa okuma dogru, yazma sabit yanlis forge'a gider (outfit_core'un kendi
    notu). Bu yuzden ikisi BIRLIKTE tasinir ve BIRLIKTE geri konur.

    Ikinci dosya taniticisi acilmaz: baglam icindeki her okuma `outfit_core._forge()`
    uzerindendir. Hedef degistiginde onbellekler bosaltilir -- `_RES_CACHE`,
    doku_png'nin materyal/TextureSet/ad onbellekleri ve K2 sinir onbellegi arsive
    OZELDIR; tasinmadan birakilirsa bir arsivin baytlari otekinin adi altinda okunur.
    """
    hedef = os.path.abspath(forge or arsiv_yolu())
    eski_c = C.FORGE
    eski_de = getattr(DE, "FORGE", None)
    degisti = (eski_c is None or
               os.path.normcase(os.path.abspath(eski_c)) != os.path.normcase(hedef))
    if degisti:
        _onbellekleri_bosalt()
        C.FORGE = hedef
        DE.FORGE = hedef
    try:
        yield hedef
    finally:
        if degisti:
            _onbellekleri_bosalt()
            C.FORGE = eski_c
            DE.FORGE = eski_de


def _onbellekleri_bosalt():
    C.release_forge(onbellek=True)
    DP.onbellek_temizle()
    for ad in ("_IC_SINIR_ONBELLEK",):
        d = getattr(DP, ad, None)
        if isinstance(d, dict):
            d.clear()


# mesh_glb icin COK-FORGE okuma gorunumu (export3d.cok_forge). Kapatma anahtari: testlerin
# ayirt edicilik kapisi ("zincir kapaliyken ayni mesh dokusuz cikmali") ve kaptanin acil durum
# dugmesi -- False ise eski tek-forge davranisi, tek satir.
COK_FORGE = True


@contextlib.contextmanager
def _cok_forge_baglami(yol, gid):
    """mesh_glb: mesh secilen arsivde dururken materyali / TextureSet'i / TextureMap'i BASKA bir
    arsivde olabilir (OLCULDU 2026-09-12, 71 kamara propu: tek forge -> 58 dokusuz GLB, "material
    not in forge"; zincirle -> 0). `_baglam` icinde ve yalniz mesh yazimi suresince okuma gorunumu
    `cok_forge.zincir_kur(yol)` sirasina gore birlesik yapilir:
        secilen arsivin yama grubu (patch_NN > taban) -> DataPC_boot grubu -> DataPC_shared_00 grubu
    GOLGE KURALI: ayni kimlik iki halkada varsa oyunun okudugu UST halka (patch) kazanir. Tek
    istisna secilen giris (gid): kullanici o kopyayi ACIKCA istedi ve `tani` golgeyi zaten soyledi;
    o kimlik kendi arsivine sabitlenir. Cikista tek forge'a donulur ve BUTUN onbellekler bosaltilir
    (baska halkanin cozulmus govdesi / PNG yolu oturumda kalmasin). Yalniz okuma: yazicilar kendi
    taniticilarini acar. Doner (yollar, zincir_sozlugu|None)."""
    if not COK_FORGE:
        yield [os.path.abspath(yol)], None
        return
    from export3d import cok_forge as CF
    yollar = CF.zincir_kur(yol)
    _onbellekleri_bosalt()
    z = C.forge_zinciri_ayarla(yollar, sabit={int(gid): os.path.abspath(yol)},
                               birincil=os.path.abspath(yol))
    try:
        yield yollar, z
    finally:
        C.forge_zinciri_ayarla(None)
        _onbellekleri_bosalt()


# =====================================================================================
#  varlik indeksi koprusu (I ajaninin modulu -- es zamanli yazildi, ZORUNLU DEGIL)
# =====================================================================================
def _indeks_modulu():
    try:
        import varlik_indeks                                    # noqa: F401
    except Exception:                                           # noqa: BLE001
        return None
    return sys.modules.get("varlik_indeks")


def _indeks_kaydi(gid, icid=None):
    """varlik_indeks.kayit(gid, icid) -> dict ya da None (modul yoksa/hata verirse)."""
    vi = _indeks_modulu()
    if vi is None or not hasattr(vi, "kayit"):
        return None
    for arg in ((gid, icid), (gid,)):
        try:
            k = vi.kayit(*arg)
        except Exception:                                       # noqa: BLE001
            continue
        if isinstance(k, dict) and k:
            return k
    return None


def _sinif_adi(crc, gid=None, icid=None):
    """Sinif adi: yerlesik tablo -> OYUNUN KENDI sozlugu -> varlik_indeks -> ham crc.

    SIRA BILINCLI. `tani` bir LISTE ekraninin altinda satir satir cagrilir; yerlesik
    tablodaki 7 sinif zaten girislerin buyuk cogunlugudur ve onlar icin indeksi (18,3 MB,
    tembel yukleme) hic uyandirmamak gerekir.

    IKINCI HALKA (v0.18): oyunun kendi meta tablosu. DataPC_boot_patch_01.forge
    icindeki GlobalMetaFile girisi her sinif adini KENDI crc32'siyle birlikte tasir;
    build/sinif_adlari_oyun.json o tablodur (10.051 ad, hepsi crc32 kanitli).
    Indeksten ONCE gelir cunku (a) forge acmaz ve indeksi uyandirmaz, (b) indeksin
    sozlugu bizim eski tablomuzdan derlenmisti ve 12 adi crc32 CARPISMASIYDI.
    Ucuncu taraf sozluk OKUNMAZ: kaynak oyunun kendi verisidir."""
    if crc in SINIF_ADI:
        return SINIF_ADI[crc], "builtin"
    ad = N.oyun_sinif_adlari().get(int(crc or 0) & 0xFFFFFFFF)
    if ad:
        return str(ad), "oyun"
    ad = ((_indeks_kaydi(gid, icid) or {}).get("sinif") if gid is not None else None)
    if ad:
        return str(ad), "index"
    return "0x%08X" % (crc or 0), "crc"


# =====================================================================================
#  E1 -- TANI
# =====================================================================================
def _ic_dosya_listesi(lf, gid):
    """[(icid, govde, tip|None, ad|None)] + kap hatasi (BMS degilse sebep metni)."""
    try:
        ham = FG.ic_dosyalar(lf, gid)
    except (KeyError, ValueError, AssertionError, struct.error) as e:
        return [], str(e)
    try:
        adlar = DP._giris_ic_adlari(gid)                         # K1 ad sifresi (canli)
    except Exception:                                           # noqa: BLE001 -- ad zorunlu degil
        adlar = {}
    out = []
    for icid, govde in ham:
        try:
            tip = FG.sarmalayici_coz(govde)["tip"]
        except Exception:                                       # noqa: BLE001
            tip = None
        out.append((icid, govde, tip, adlar.get(icid)))
    return out, None


def _mesh_karari(govde):
    """(uygun, rigid, sebep) -- mesh ic dosyasi bu okuyucunun kapsaminda mi?"""
    ok, sebep = MY.desteklenen_mi(govde, rigid=False)
    if ok:
        return True, False, ""
    ok2, sebep2 = MY.desteklenen_mi(govde, rigid=True)
    if ok2:
        return True, True, ""
    return False, False, sebep2 or sebep


def _doku_karari(gid, ln, sinif_crc):
    """(uygun, kaynak, sebep) -- bu giris doku_png ile PNG'ye cozulebilir mi?"""
    if ln > DOKU_YOKLAMA_SINIRI:
        return False, None, ("entry is %.1f MB - too large to probe for textures here; "
                             "export it as raw bytes instead" % (ln / 1048576.0))
    try:
        res = C._material_res(gid)
    except Exception as e:                                      # noqa: BLE001
        return False, None, "entry body could not be decompressed (%s)" % str(e)[:100]
    try:
        n = len(DE.tm_bloklari(res))
    except Exception as e:                                      # noqa: BLE001
        return False, None, "texture descriptor scan failed (%s)" % str(e)[:100]
    if n:
        return True, "material", ""
    if sinif_crc == TIP_TEXTURESET:
        return True, "textureset", ""
    try:
        ts = DP.texture_set_bul(res)
    except Exception:                                           # noqa: BLE001
        ts = None
    if ts:
        return True, "textureset", ""
    return False, None, "no TextureMap block and no TextureSet reference in this entry"


def _ses_kayitlari(gid, forge_ad):
    """Bu TOC girisine bagli ses katalogu kayitlari (bos liste = ses degil)."""
    try:
        import ses_core as SC
    except Exception:                                           # noqa: BLE001
        return [], "the sound catalogue is not available in this build"
    try:
        kat = SC.katalog()
    except Exception as e:                                      # noqa: BLE001
        return [], "the sound catalogue could not be read (%s)" % str(e)[:100]
    hedef = (forge_ad or "").lower()
    out = [s for s in kat if int(s.get("fid") or 0) == int(gid)
           and str(s.get("forge") or "").lower() == hedef]
    return out, ("" if out else "this entry is not a sound bank in the sound catalogue")


def tani(gid, icid=None, forge=None):
    """E1 -- bu giris NE? Ne yapabiliriz, yapamiyorsak NEDEN?

    Doner:
      {ok, gid, icid, forge, forge_ad, sinif, sinif_crc, sinif_kaynagi, ad, boyut,
       kap, ic_dosyalar:[{icid, sinif, sinif_crc, ad, boyut, mesh:{...}}],
       yapabilecekler:[...], sebepler:{bicim: sebep}, not, mesaj}
    `yapabilecekler` ASLA bos donmez: "ham" hicbir kapiya bagli degildir.
    """
    gid = _int(gid)
    icid = _int(icid)
    r = {"ok": False, "gid": _hex(gid), "icid": _hex(icid), "gid_sayi": gid,
         "icid_sayi": icid, "forge": None, "forge_ad": None, "sinif": None,
         "sinif_crc": None, "sinif_kaynagi": None, "ad": None, "boyut": 0, "kap": None,
         "ic_dosyalar": [], "yapabilecekler": [], "sebepler": {}, "not": "", "mesaj": None,
         "surum": SURUM}
    with _baglam(forge) as yol:
        r["forge"], r["forge_ad"] = yol, os.path.basename(yol)
        lf = C._forge()
        if gid not in lf.by_id:
            r["mesaj"] = ("Entry %s is not in %s. Pick another archive, or check the id."
                          % (_hex(gid), r["forge_ad"]))
            return r
        off, ln, ext = lf.by_id[gid]
        r["boyut"] = int(ln)
        r["sinif_crc"] = "0x%08X" % ext
        r["sinif"], r["sinif_kaynagi"] = _sinif_adi(ext, gid, icid)

        icler, kap_hatasi = _ic_dosya_listesi(lf, gid)
        r["kap"] = "raw" if kap_hatasi else "bms"
        if kap_hatasi:
            r["kap_sebep"] = kap_hatasi
        adlar = {}
        for cid, govde, tip, ad in icler:
            k = {"icid": _hex(cid), "icid_sayi": cid, "boyut": len(govde), "ad": ad,
                 "sinif_crc": ("0x%08X" % tip) if tip is not None else None}
            k["sinif"] = (_sinif_adi(tip, cid)[0] if tip is not None else "unknown")
            if tip == TIP_MESH:
                uygun, rigid, sebep = _mesh_karari(govde)
                k["mesh"] = {"okunur": uygun, "rigid": rigid, "sebep": sebep}
            r["ic_dosyalar"].append(k)
            if ad:
                adlar[cid] = ad
        r["ad"] = adlar.get(gid) or (icler[0][3] if icler else None) \
            or (_indeks_kaydi(gid, icid) or {}).get("ad")

        if icid is not None and icler and not any(c == icid for c, _g, _t, _a in icler):
            r["mesaj"] = ("Inner file %s is not in entry %s (this entry has %d: %s)."
                          % (_hex(icid), _hex(gid), len(icler),
                             ", ".join(_hex(c) for c, _g, _t, _a in icler[:6])))
            return r

        # ---------------------------------------------------------------- HAM (kosulsuz)
        yapabilir = [BICIM_HAM]
        r["sebepler"][BICIM_HAM] = ""

        # ---------------------------------------------------------------- MESH
        adaylar = [(c, g) for c, g, t, _a in icler if t == TIP_MESH
                   and (icid is None or c == icid)]
        if not adaylar:
            r["sebepler"][BICIM_MESH] = (
                "no Mesh (0x415D9568) inner file here" if not kap_hatasi else
                "this entry is not a container we can open (%s)" % kap_hatasi)
        else:
            secilen = sebep = None
            for cid, govde in adaylar:
                uygun, rigid, s = _mesh_karari(govde)
                if uygun:
                    secilen = {"icid": _hex(cid), "icid_sayi": cid, "rigid": rigid}
                    break
                sebep = sebep or s
            if secilen:
                yapabilir.append(BICIM_MESH)
                r["mesh_hedefi"] = secilen
                r["sebepler"][BICIM_MESH] = ""
            else:
                r["sebepler"][BICIM_MESH] = "mesh not readable by this reader: %s" % sebep

        # ---------------------------------------------------------------- DOKU
        d_ok, d_kaynak, d_sebep = _doku_karari(gid, ln, ext)
        if d_ok:
            yapabilir.append(BICIM_DOKU)
            yapabilir.append(BICIM_DOKU_DDS)
            r["doku_kaynagi"] = d_kaynak
            r["sebepler"][BICIM_DOKU] = ""
            r["sebepler"][BICIM_DOKU_DDS] = ""
        else:
            r["sebepler"][BICIM_DOKU] = d_sebep
            r["sebepler"][BICIM_DOKU_DDS] = d_sebep

        # ---------------------------------------------------------------- SES
        sesler, s_sebep = _ses_kayitlari(gid, r["forge_ad"])
        if sesler:
            yapabilir.append(BICIM_SES)
            r["ses_sayisi"] = len(sesler)
            r["sebepler"][BICIM_SES] = ""
        else:
            r["sebepler"][BICIM_SES] = s_sebep

        # Sira EKLEME sirasi degil BICIMLER sirasidir: `disa_aktar(bicim=None)` daima
        # en anlamli bicimi secer ve "ham" en sonda kalir (yedek yol).
        r["yapabilecekler"] = [b for b in BICIMLER if b in yapabilir]
        # Golge kontrolu: bu giris UST bir zincir halkasinda da varsa buradaki duzenleme
        # yazilir ama oyunda GORUNMEZ. Kullanici bunu YAZMADAN ONCE bilmeli.
        g = golgeleyen(gid, yol)
        r["golge"] = g if g.get("golgede") else None
        if g.get("golgede"):
            r["sebepler"]["golge"] = _golge_mesaji(g)
        r["not"] = _tani_notu(r)
        r["ok"] = True
        return r


def _tani_notu(r):
    """Kullaniciya tek cumlede: ne cikar, ne cikmaz, NEDEN cikmaz."""
    olmayan = [(b, r["sebepler"].get(b)) for b in BICIMLER
               if b not in r["yapabilecekler"] and r["sebepler"].get(b)]
    bas = "Raw bytes can always be exported."
    if not olmayan:
        return bas
    return bas + " " + " ".join("%s: %s." % (b.replace("_", " -> "), s.rstrip("."))
                                for b, s in olmayan)


def bicimler(gid, icid=None, forge=None):
    """Kisayol: yalniz `yapabilecekler` listesi."""
    return tani(gid, icid, forge)["yapabilecekler"]


# =====================================================================================
#  E1b -- AGAC / COCUKLAR / TUR SUZGECI (Explorer agaci, SALT OKUMA, forge ACMAZ)
# =====================================================================================
# Indeksin kolonlari uzerinde calisir (varlik_indeks.Indeks: _f_idx u8, _s_idx u16,
# _blob/_bas ad blobu). Kamu sozlesmesine (ara/siniflar/forgeler/kayit/istatistik)
# DOKUNULMAZ; burasi yalniz OKUR. Kolonlar yoksa (baska bir indeks surumu) agac
# bos, tur suzgeci ise ACIK bir mesajla reddedilir -- sessizce "hepsi" donmez.
# OLCULDU (2.165.452 satir): tablo kurulumu 0,25 sn (oturumda BIR kez), agac <5 ms.
_TUR_TABLO = {}


def _tur_tablosu(ix):
    """{'kod': {tur: bayt}, 'sinif_tur': [tur], 'maske': bytes(n), 'matris': Counter}"""
    import collections
    anahtar = (id(ix), getattr(ix, "n", -1))
    t = _TUR_TABLO.get(anahtar)
    if t is not None:
        return t
    sinif_ad = getattr(ix, "_sinif_ad", None)
    s_idx = getattr(ix, "_s_idx", None)
    f_idx = getattr(ix, "_f_idx", None)
    if sinif_ad is None or s_idx is None or f_idx is None:
        return None
    kod = {tur: i for i, tur in enumerate(TURLER)}
    sinif_tur = [tur_ad(a) for a in sinif_ad]
    sinif_kod = bytes(kod[t] for t in sinif_tur)
    t = {"kod": kod, "sinif_tur": sinif_tur,
         "maske": bytes(map(sinif_kod.__getitem__, s_idx)),
         "matris": collections.Counter(zip(f_idx, s_idx))}
    _TUR_TABLO.clear()                          # tek indeks yasar; eski nesne tutulmaz
    _TUR_TABLO[anahtar] = t
    return t


# =====================================================================================
#  HAM TOC GIRISLERI (indekste OLMAYAN girisler)
# =====================================================================================
# Indeks ureticisi BMS kabi OLMAYAN TOC girisini ATLAR. O girisler bugune kadar
# listede HIC gorunmedi -- oysa baytlari cikarilabiliyor (Anvil tarzi arac tam olarak
# bunu yapar) ve `tani` onlari zaten aciyor (kap="raw").
# OLCULDU (2026-09-09, canli TOC + indeks 2.165.452 satir):
#   DataPC_WhiteRoom.forge      495 TOC ·    465 indekste ·     30 ham   (0,004 sn)
#   DataPC_boot.forge       126.249 TOC · 94.113 indekste · 32.136 ham   (0,15 sn)
#   ham girislerin ext'i: RawAsset 0x4C8BD3BF (harici mip / MPH kume sayfasi)
#   + arsiv basina 2 giris ext 0x00000000 (gid 0x10 ve 0x91).
# AD YOKTUR ve UYDURULMAZ: 200 orneklem indekste ne ad ne etiket buldu (0/200); K1 ad
# tablosu KABIN ICINDE yasar, kap yoksa ad da yok. Ebeveyn tahmini de olculdu
# (gid >> 16): 32.134 girisin 0'i indeksteki bir gid'e denk geldi. Satir bu yuzden
# kimligin kendisini gosterir ("raw 0x...") ve arayuz onu ad gibi sunmaz.
_HAM_ONBELLEK = {}


def _forge_yolu(forge=None):
    """'DataPC_boot.forge' | tam yol -> tam yol (bulunamazsa None)."""
    s = str(forge or "").strip()
    if not s:
        return arsiv_yolu()
    if os.path.isfile(s):
        return os.path.abspath(s)
    p = os.path.join(os.path.dirname(arsiv_yolu()), os.path.basename(s))
    return p if os.path.isfile(p) else None


def _indeks_gidleri(ix, forge_ad):
    """Indekste `forge_ad` icin gecen gid KUMESI (kolonlardan; olculdu 0,03 sn).

    forge_idx u8 bir kolondur: bayta cevrilip `bytes.find` ile gezilir (C hizinda
    atlama), boylece 2,16 milyon satirin tamami Python dongusune girmez."""
    fi = ix._f_dizin.get(str(forge_ad).strip().lower())
    if fi is None:
        return set()
    gid = ix._gid
    try:
        fb, igne = bytes(ix._f_idx), bytes((fi,))
    except (TypeError, ValueError):             # kolon u8 degilse (baska indeks surumu)
        return set(g for g, f in zip(gid, ix._f_idx) if f == fi)
    out = set()
    p = fb.find(igne)
    while p >= 0:
        out.add(gid[p])
        p = fb.find(igne, p + 1)
    return out


def ham_girisler(forge=None, ix=None):
    """Canli TOC'ta olan ama indekste OLMAYAN girisler -> [satir] (gid'e gore sirali).

    Satirin alanlari `varlik_indeks._satir` ile AYNIDIR (arayuz tek sablonla basar);
    ustune `ham: True`, `off` ve `tur: "raw"` gelir. Indeks yuklenemezse [] doner --
    neyin ham oldugunu ancak indeksle karsilastirarak biliriz, TAHMIN edilmez.

    Onbellek anahtari (yol, boyut, mtime) + indeks kimligi: oyun guncellenince ya da
    indeks degisince liste kendiliginden yenilenir (ezberlenmis liste YOK).
    Dosya taniticisi HEMEN kapatilir (`with LeanForge`) -- forge acik kalirsa Steam
    "dosyalari dogrula" adimi "Content file locked" ile duser. Paylasilan
    `C._forge()` bilerek KULLANILMAZ."""
    yol = _forge_yolu(forge)
    if not yol:
        return []
    if ix is None:
        vi = _indeks_modulu()
        try:
            ix = vi.yukle() if vi is not None else None
        except Exception:                                       # noqa: BLE001
            ix = None
    if ix is None:
        return []
    try:
        st = os.stat(yol)
    except OSError:
        return []
    anahtar = (os.path.normcase(yol), st.st_size, int(st.st_mtime),
               id(ix), getattr(ix, "n", -1))
    hit = _HAM_ONBELLEK.get(anahtar)
    if hit is not None:
        return hit
    ad = os.path.basename(yol)
    try:
        with C.LeanForge(yol) as lf:
            toc = [(int(fid), int(off), int(ln), int(ext))
                   for off, fid, ln, ext in lf.entries]
    except Exception:                                           # noqa: BLE001
        return []
    indekste = _indeks_gidleri(ix, ad)
    sinif_memo, satirlar = {}, []
    for gid, off, ln, ext in sorted(toc):
        if gid in indekste:
            continue
        sinif = sinif_memo.get(ext)
        if sinif is None:
            sinif = sinif_memo[ext] = _sinif_adi(ext)[0]
        satirlar.append({
            "forge": ad, "sinif": sinif, "sinif_crc": "0x%08X" % ext,
            "gid": "0x%X" % gid, "icid": "0x%X" % gid, "ad": "",
            "etiket": "raw 0x%012X" % gid, "etiket_turu": "raw",
            "ebeveyn_gid": None, "sayfa": None, "boyut": int(ln), "tam_mi": 1,
            "tur": "raw", "ham": True, "off": int(off)})
    _HAM_ONBELLEK.clear()               # tek arsivlik onbellek yeter (boot 32.136 satir)
    _HAM_ONBELLEK[anahtar] = satirlar
    return satirlar


def _ham_suzgec(hamlar, metin=None, sinif=None):
    """Ham satirlari metin/sinif suzgecinden gecir (indeks aramasiyla ayni ruh:
    kucuk harf, alt dize). Aranabilir metin: etiket + gid + sinif adi."""
    if sinif:
        s = str(sinif).strip().lower()
        hamlar = [h for h in hamlar if str(h["sinif"]).lower() == s]
    d = str(metin or "").strip().lower()
    if d:
        hamlar = [h for h in hamlar
                  if d in h["etiket"].lower() or d in h["gid"].lower()
                  or d in str(h["sinif"]).lower()]
    return hamlar


def ham_kuyruk(r, metin=None, tur=None, sinif=None, forge=None, limit=200, offset=0, ix=None):
    """Indeks sonucunun ({toplam, satirlar}) SONUNA ham TOC satirlarini ekle.

    SOZLESME BOZULMAZ: satir alanlari ayni, ham satirda ek olarak `ham: True`.
    Sayfalama korunur -- ham satirlar indeks satirlarindan SONRA gelir, `toplam`
    ikisinin toplamidir ve `offset` ikisi boyunca kesintisiz akar.

    Ham satirlar yalniz TEK BIR ARSIV secildiginde eklenir: "butun arsivler" modunda
    157 forge'un TOC'unu okumak gerekirdi (olculdu: forge basina 0,15 sn'ye kadar) ve
    arama kutusu her tus vurusunda takilirdi. Tur suzgeci 'raw' disinda bir seyse ham
    satir zaten eslesmez, onbellek de bosuna doldurulmaz."""
    if not forge:
        return r
    t = str(tur or "").strip().lower()
    if t and t != "raw":
        return r
    hamlar = _ham_suzgec(ham_girisler(forge, ix), metin, sinif)
    if not hamlar:
        return r
    n_idx = int(r.get("toplam") or 0)
    satirlar = list(r.get("satirlar") or [])
    offset = max(0, int(offset or 0))
    bas = max(0, offset - n_idx)
    if limit is None:
        satirlar.extend(hamlar[bas:])
    else:
        kalan = max(0, int(limit or 0) - len(satirlar))
        if kalan:
            satirlar.extend(hamlar[bas:bas + kalan])
    y = dict(r)
    y["toplam"] = n_idx + len(hamlar)
    y["satirlar"] = satirlar
    y["ham_sayi"] = len(hamlar)
    return y


def _agac_ham_kat(dallar, forge, ix=None):
    """Secili arsivin ham TOC girislerini agac dalina kat -> eklenen satir sayisi.

    Yalniz TEK ARSIV secilince cagrilir (butun agac icin 157 TOC okumak gerekirdi).
    Sinif satirlari ham girisin ext'inden gelir; kullanici o sinifa tikladiginda
    `ham_kuyruk` AYNI satirlari geri verir, boylece agactaki sayi ile listedeki
    sayi tutar."""
    import collections
    hamlar = ham_girisler(forge, ix)
    if not hamlar:
        return 0
    ad = os.path.basename(_forge_yolu(forge) or str(forge))
    dal = None
    for d in dallar:
        if str(d.get("forge", "")).lower() == ad.lower():
            dal = d
            break
    if dal is None:                             # indekste hic satiri olmayan arsiv
        dal = {"forge": ad, "sayi": 0, "turler": []}
        dallar.append(dal)
    ham_tur = None
    for t in dal["turler"]:
        if t.get("tur") == "raw":
            ham_tur = t
            break
    if ham_tur is None:
        ham_tur = {"tur": "raw", "sayi": 0, "siniflar": []}
        dal["turler"].append(ham_tur)
    mevcut = dict((c["sinif"], c) for c in ham_tur["siniflar"])
    for sinif, n in collections.Counter(h["sinif"] for h in hamlar).items():
        c = mevcut.get(sinif)
        if c is None:
            c = {"sinif": sinif, "sayi": 0}
            ham_tur["siniflar"].append(c)
        c["sayi"] += n
    ham_tur["siniflar"].sort(key=lambda c: (-c["sayi"], c["sinif"]))
    ham_tur["sayi"] += len(hamlar)
    dal["sayi"] += len(hamlar)
    dal["turler"].sort(key=lambda t: TURLER.index(t["tur"]) if t["tur"] in TURLER else 9)
    return len(hamlar)


def agac(ix, forge=None):
    """Arsiv > tur > sinif agaci, sayilarla. `forge` verilirse yalniz o dal.

    Doner: {ok, dallar:[{forge, sayi, turler:[{tur, sayi, siniflar:[{sinif, sayi}]}]}],
            turler:[{tur, sayi}] (butun arsivlerin toplami)}"""
    t = _tur_tablosu(ix)
    if t is None:
        return {"ok": False, "dallar": [], "turler": [],
                "mesaj": "This asset index build has no class columns; the tree is unavailable."}
    forge_ad, sinif_ad = ix._forge_ad, ix._sinif_ad
    sinif_tur = t["sinif_tur"]
    istenen = None
    if forge:
        istenen = ix._f_dizin.get(str(forge).strip().lower())
        if istenen is None:             # indekste hic satiri yok: ham girisleri yine de goster
            dallar = []
            n_ham = _agac_ham_kat(dallar, forge, ix)
            return {"ok": True, "dallar": dallar,
                    "turler": ([{"tur": "raw", "sayi": n_ham}] if n_ham else [])}
    dal = {}
    for (fi, si), n in t["matris"].items():
        if istenen is not None and fi != istenen:
            continue
        dal.setdefault(fi, {}).setdefault(sinif_tur[si], {})[si] = n
    dallar = []
    toplam_tur = dict((tur, 0) for tur in TURLER)
    for fi, turler in dal.items():
        tl = []
        for tur in TURLER:
            sl = turler.get(tur)
            if not sl:
                continue
            sinifler = sorted(sl.items(), key=lambda x: (-x[1], sinif_ad[x[0]]))
            n = sum(sl.values())
            toplam_tur[tur] += n
            tl.append({"tur": tur, "sayi": n,
                       "siniflar": [{"sinif": sinif_ad[si], "sayi": k} for si, k in sinifler]})
        dallar.append({"forge": forge_ad[fi], "sayi": sum(x["sayi"] for x in tl), "turler": tl})
    if forge:                       # TEK ARSIV: indekste olmayan ham TOC girisleri de dalda
        toplam_tur["raw"] += _agac_ham_kat(dallar, forge, ix)
    dallar.sort(key=lambda d: (-d["sayi"], d["forge"]))
    return {"ok": True, "dallar": dallar,
            "turler": [{"tur": tur, "sayi": toplam_tur[tur]} for tur in TURLER if toplam_tur[tur]]}


def tur_ara(ix, metin, tur, forge=None, limit=200, offset=0):
    """`Indeks.ara` ile AYNI sozlesme ({toplam, satirlar}) ama sinif yerine TUR suzer.

    Metinli arama Indeks._ara_metin ile ayni algoritmadir (blob uzerinde tek regex
    gecisi, satir = bisect); tek fark satirin sinif indisi yerine tur maskesine
    bakilmasidir. Metinsiz arama maskede bytes.find ile C hizinda gezer; toplam
    matristen okunur, satir taramasi yalniz sayfaya kadar surer."""
    import bisect
    t = _tur_tablosu(ix)
    if t is None:
        return {"toplam": 0, "satirlar": [],
                "hata": "This asset index build cannot filter by type."}
    if tur not in t["kod"]:
        return {"toplam": 0, "satirlar": [], "hata": "Unknown type filter: %s" % tur}
    kodb = bytes((t["kod"][tur],))
    maske = t["maske"]
    fi = None
    if forge:
        fi = ix._f_dizin.get(str(forge).strip().lower(), -1)
        if fi == -1:                    # indekste yok: ham girisler yine de dondurulur
            return ham_kuyruk({"toplam": 0, "satirlar": []},
                              metin, tur, None, forge, limit, offset, ix)
    offset = max(0, int(offset or 0))
    limit = max(0, int(limit or 0))
    ust = offset + limit
    f_idx = ix._f_idx
    secilen = []
    desen = (metin or "").strip()
    if desen:
        try:
            igne = desen.encode("utf-8").lower()
        except UnicodeEncodeError:
            return {"toplam": 0, "satirlar": []}
        bas, toplam, ipucu = ix._bas, 0, 0
        for m in ix._desen(igne).finditer(ix._blob):
            satir = bisect.bisect_right(bas, m.start(), ipucu) - 1
            ipucu = satir
            if maske[satir] != kodb[0]:
                continue
            if fi is not None and f_idx[satir] != fi:
                continue
            if offset <= toplam < ust:
                secilen.append(satir)
            toplam += 1
        return ham_kuyruk({"toplam": toplam, "satirlar": [ix._satir(r) for r in secilen]},
                          metin, tur, None, forge, limit, offset, ix)
    # metinsiz: toplam matristen (kesin), satirlar maskeden sayfaya kadar
    sinif_tur = t["sinif_tur"]
    if fi is None:
        toplam = maske.count(kodb)
    else:
        toplam = sum(n for (f, s), n in t["matris"].items() if f == fi and sinif_tur[s] == tur)
    if limit and offset < toplam:
        k, pos, find = 0, 0, maske.find
        while len(secilen) < limit:
            i = find(kodb, pos)
            if i < 0:
                break
            pos = i + 1
            if fi is not None and f_idx[i] != fi:
                continue
            if k >= offset:
                secilen.append(i)
            k += 1
    return ham_kuyruk({"toplam": toplam, "satirlar": [ix._satir(r) for r in secilen]},
                      metin, tur, None, forge, limit, offset, ix)


def cocuklar(gid, forge=None):
    """Girisin ic dosyalari: [{icid, ad, sinif, tip(tur), boyut, xml_acilir}] -- `tani` sarilir.

    xml_acilir: giris BMS kabi ise (raw degil) ve ic dosya bos degilse. XML
    okuyucu (nesne.oku) tam olarak bu iki kapiyi arar; burada yeniden tanimlanmaz."""
    t = tani(gid, None, forge)
    r = {"ok": bool(t.get("ok")), "gid": t.get("gid"), "forge": t.get("forge_ad"),
         "kap": t.get("kap"), "sinif": t.get("sinif"), "mesaj": t.get("mesaj"),
         "cocuklar": []}
    if not t.get("ok"):
        return r
    bms = t.get("kap") == "bms"
    if not bms:                     # BMS kabi degil -> ic dosya YOK (bos liste + sebep)
        r["ham"] = True
        r["mesaj"] = r.get("mesaj") or ("This is a raw TOC entry, not a container: "
                                        "it has no inner files. Its bytes can still be "
                                        "exported with Raw bytes (.bin).")
    for k in t.get("ic_dosyalar") or []:
        r["cocuklar"].append({
            "icid": k.get("icid"), "ad": k.get("ad") or "", "sinif": k.get("sinif"),
            "tip": tur_ad(k.get("sinif"), kap=None if bms else "raw"),
            "boyut": int(k.get("boyut") or 0),
            "xml_acilir": bool(bms and int(k.get("boyut") or 0) > 0)})
    return r


# =====================================================================================
#  E2 -- DISA AKTAR
# =====================================================================================
def _bilgi_yaz(klasor, t, bicim, dosyalar, parcalar, ek=None):
    """bilgi.json -- geri koyarken hedefi ve butunlugu dogrulayan kimlik kagidi."""
    b = {"arac": "explorer_core", "surum": SURUM,
         "zaman": time.strftime("%Y-%m-%d %H:%M:%S"), "bicim": bicim,
         "forge": t["forge"], "forge_ad": t["forge_ad"],
         "gid": t["gid"], "gid_sayi": t["gid_sayi"],
         "icid": t["icid"], "icid_sayi": t["icid_sayi"],
         "sinif": t["sinif"], "sinif_crc": t["sinif_crc"], "ad": t["ad"],
         "boyut": t["boyut"], "giris_sha256": t.get("giris_sha256"),
         "parcalar": parcalar,
         "dosyalar": [os.path.basename(x) for x in dosyalar]}
    if ek:
        b.update(ek)
    yol = os.path.join(klasor, BILGI_AD)
    with open(yol, "w", encoding="utf-8") as f:
        json.dump(b, f, indent=1, ensure_ascii=False)
    return yol


def _hedef_klasor(klasor, t, onek=""):
    """Var olan bir klasoru ASLA ezme: <ad>, <ad>_2, <ad>_3 ... (sahne.serbest_ad kalibi)."""
    ad = _dosya_adi(t.get("ad"), "Entry_%s" % (t["gid"] or "0x0"))
    return SA.serbest_ad(os.path.abspath(klasor), onek + ad)


def _ham_yaz(t, klasor, lf, progress):
    """Her sinif icin calisan yol: ic dosya govdeleri (ya da BMS degilse giris baytlari)."""
    gid, icid = t["gid_sayi"], t["icid_sayi"]
    os.makedirs(klasor, exist_ok=True)
    dosyalar, parcalar = [], []
    if t["kap"] == "bms":
        icler, _h = _ic_dosya_listesi(lf, gid)
        secim = [x for x in icler if icid is None or x[0] == icid]
        for cid, govde, tip, ad in secim:
            adi = "%s_%012X.bin" % (_dosya_adi(ad, "inner"), cid)
            yol = os.path.join(klasor, adi)
            with open(yol, "wb") as f:
                f.write(govde)
            dosyalar.append(yol)
            parcalar.append({"icid": _hex(cid), "icid_sayi": cid, "ad": ad,
                             "sinif_crc": ("0x%08X" % tip) if tip is not None else None,
                             "boyut": len(govde), "sha256": _sha(govde),
                             "dosya": adi, "yazilabilir": True})
            _log(progress, "  raw inner file %s -> %s (%d B)" % (_hex(cid), adi, len(govde)))
    else:
        # BMS kabi degil (harici mip RawAsset gibi): girisin HAM baytlari cikar.
        # Bu bicim GERI YAZILAMAZ -- kur_mesh ic dosya yamalar, giris govdesini degil.
        ham = lf.read_raw(gid)
        adi = "%s_%012X.bin" % (_dosya_adi(t.get("ad"), "entry"), gid)
        yol = os.path.join(klasor, adi)
        with open(yol, "wb") as f:
            f.write(ham)
        dosyalar.append(yol)
        parcalar.append({"icid": None, "icid_sayi": None, "ad": t.get("ad"),
                         "sinif_crc": t["sinif_crc"], "boyut": len(ham),
                         "sha256": _sha(ham), "dosya": adi, "yazilabilir": False,
                         "sebep": "this entry is not a container, so there is no inner file "
                                  "to write back into"})
        _log(progress, "  raw entry %s -> %s (%d B)" % (t["gid"], adi, len(ham)))
    return dosyalar, parcalar


def _mesh_yaz(t, klasor, progress):
    """sahne.kur'u indekste OLMAYAN bir mesh icin cagir (gecici kayit enjeksiyonu).

    sahne.kur hedefini `onizleme3d` indeksinden ya da parca envanterinden alir; Explorer'in
    girisi ikisinde de yoktur. Yeni bir export yolu YAZMAK yerine ayni motora tek kayitlik
    bir indeks verilir ve cikista GERI ALINIR. Iki hat vardir cunku sahne.kur ikisini
    ayri okur: skinli parca envanter yolundan, RIGID parca (fmt 3/4 -- WhiteRoom'un
    15 mesh'inin hepsi boyle olculdu) silah yolundan gider.
    """
    hedef = t.get("mesh_hedefi") or {}
    gid, icid = t["gid_sayi"], hedef.get("icid_sayi")
    rigid = bool(hedef.get("rigid"))
    boyut = next((k["boyut"] for k in t["ic_dosyalar"] if k["icid_sayi"] == icid), 0)
    ad = _dosya_adi(t.get("ad"), "Entry_%012X" % gid)
    anahtar = "%s_%012X_%012X" % (ad, gid, icid)
    parca_ad = _dosya_adi(t.get("ad"), "part")

    if rigid:
        sentetik = {anahtar: {"gruplar": [{"taban": parca_ad, "lod_secilen": 0,
                                           "lodlar": [[boyut, gid, icid, parca_ad]]}],
                              "katalog_materyal": []}}
        try:
            gercek, _yol = SA.silah_indeks_yukle()
        except Exception:                                       # noqa: BLE001
            gercek = {}
        birlesik = dict(gercek)
        birlesik.update(sentetik)
        orij = SA.silah_indeks_yukle
        SA.silah_indeks_yukle = lambda: (birlesik, "<explorer>")
        try:
            r = SA.kur(anahtar, out_dir=klasor, lod=0, progress=progress, silah=True)
        finally:
            SA.silah_indeks_yukle = orij
    else:
        env, _yol = SA.envanter_yukle()                         # modul onbellegi (dict)
        env[anahtar] = {"gorunen_ad": t.get("ad") or anahtar, "kategori": "explorer",
                        "parcalar": [{"taban": parca_ad, "okunur": True, "materyaller": [],
                                      "lodlar": [[boyut, gid, icid, parca_ad]]}]}
        try:
            r = SA.kur(anahtar, out_dir=klasor, lod=0, progress=progress, silah=False)
        finally:
            env.pop(anahtar, None)
    return r, anahtar


def _dds_yaz(s, tex, progress):
    """Her slotun TUM mip zincirini .dds olarak yazar (kod cozme YOK, bayt-birebir).

    PNG'ler DE yazilir ve manifest'te kalir: onlar duzenlenebilir ondeyistir ve
    ithalat kapisinin piksel referansidir. DDS ayri bir sha ile kaydedilir, boylece
    `doku_ithal.tara` kullanicinin HANGISINI duzenledigini soyleyebilir.
    Level 0'i olmayan slot ATLANIR (uydurulmaz), sebebi `atlanan`a yazilir."""
    yazilan = []
    for k in (s.get("slotlar") or []):
        if k.get("hata") or not k.get("kap") or k.get("kap_tm") is None:
            continue
        try:
            z = DD.mip_zinciri(k["kap"], int(k["kap_tm"]))
            ad = os.path.splitext(os.path.basename(k.get("dosya") or ""))[0] + ".dds"
            yol = os.path.join(tex, ad)
            DD.dds_yaz(yol, z)
        except Exception as e:                                  # noqa: BLE001
            s.setdefault("atlanan", []).append(
                {"slot": k.get("slot"), "sebep": "no .dds written: %s" % e})
            continue
        k["dds_dosya"] = yol
        k["dds_dosya_ad"] = ad
        k["dds_sha256"] = _dosya_sha(yol)
        k["dds_dxgi"] = DD.AILE_DXGI.get((z["aile"], z["srgb"]))
        k["mip_sayisi"] = len(z["seviyeler"])
        k["harici_mip"] = [x["lvl"] for x in z["seviyeler"] if x["kaynak"] == "external"]
        k["gomulu_mip"] = [x["lvl"] for x in z["seviyeler"] if x["kaynak"] == "embedded"]
        k["eksik_mip"] = [x["lvl"] for x in (z.get("eksik") or [])]
        # Yazicinin gomulu yerlesimi bizimkinden AYRISIYORSA sessiz kalma (bkz.
        # doku_dds.yazilmayan_seviyeler): o seviyeler geri yazilamaz.
        k["yazilmayan_mip"] = [x["lvl"] for x in DD.yazilmayan_seviyeler(z)]
        yazilan.append(yol)
        _log(progress, "  texture %s tm%d -> %s (%d mip levels)"
             % (k["kap"], int(k["kap_tm"]), ad, len(z["seviyeler"])))
    return yazilan


def _doku_yaz(t, klasor, progress, dds=False):
    """doku_png ile PNG'leri yaz + doku_ithal'in okudugu manifest.json'u kur.

    PNG'ler `textures\\` altina konur ve manifest ayni bicimde yazilir; boylece geri
    koyma yolu (doku_ithal.tara/hazirla/uygula) Explorer klasorunu de tanir. Manifest'in
    tasidigi (kap, kap_tm) alanlarini doku_png'nin KENDISI doldurur -- burada uydurulmaz.
    `dds=True` ise ayni slotlarin HAM BC bloklari da .dds olarak yazilir.
    """
    gid = t["gid_sayi"]
    tex = os.path.join(klasor, TEX_KLASOR)
    os.makedirs(tex, exist_ok=True)
    if t.get("doku_kaynagi") == "textureset" and int(t["sinif_crc"], 16) == TIP_TEXTURESET:
        s = DP.texture_set_dokulari(gid, tex, progress)
    else:
        s = DP.materyal_dokulari(gid, tex, progress)
    dosyalar = [s[k] for k in ("diffuse", "normal", "gloss", "emissive", "mask") if s.get(k)]
    dosyalar += list(s.get("diger") or [])
    if dds:
        dosyalar += _dds_yaz(s, tex, progress)
    ad = _dosya_adi(t.get("ad"), "Entry_%012X" % gid)
    man = {"arac": "explorer_core", "surum": SURUM, "anahtar": ad,
           "kategori": "explorer", "gorunen_ad": t.get("ad") or ad, "glb": None,
           "gid": t["gid"], "materyaller": {t["gid"]: {"slotlar": s.get("slotlar") or [],
                                                      "kaynak": s.get("kaynak"),
                                                      "ts_id": s.get("ts_id"),
                                                      "ton": s.get("ton")}},
           "parcalar": []}
    with open(os.path.join(klasor, MANIFEST_AD), "w", encoding="utf-8") as f:
        json.dump(SA._json_uygun(man), f, indent=1, ensure_ascii=False)
    return s, dosyalar


def _ses_yaz(t, klasor, progress):
    """ses_core.wav_uret ile WAV'a cevir (vgmstream). Sinir asilirsa SOYLE."""
    import ses_core as SC
    sesler, _s = _ses_kayitlari(t["gid_sayi"], t["forge_ad"])
    os.makedirs(klasor, exist_ok=True)
    dosyalar, parcalar, hata = [], [], None
    for i, s in enumerate(sesler[:SES_LIMIT]):
        wav, e = SC.wav_uret(s["anahtar"])
        if not wav:
            hata = hata or e
            parcalar.append({"anahtar": s["anahtar"], "sid": s.get("sid"),
                             "sebep": e, "dosya": None})
            continue
        adi = "%03d_%s_%s.wav" % (i + 1, _dosya_adi(s.get("banka"), "bank"), s.get("sid"))
        yol = os.path.join(klasor, adi)
        shutil.copyfile(wav, yol)
        dosyalar.append(yol)
        parcalar.append({"anahtar": s["anahtar"], "sid": s.get("sid"),
                         "sure": s.get("sure"), "kanal": s.get("kanal"),
                         "hz": s.get("hz"), "dosya": adi, "sha256": _dosya_sha(yol),
                         "yazilabilir": False})
        _log(progress, "  sound %d of %d -> %s" % (i + 1, min(len(sesler), SES_LIMIT), adi))
    artan = max(0, len(sesler) - SES_LIMIT)
    return dosyalar, parcalar, hata, artan


def disa_aktar(gid, icid=None, klasor=None, bicim=None, forge=None, progress=None):
    """E2 -- girisi diske cikar. HAM her sinifta calisir; yaninda bilgi.json yazilir.

    bicim: None -> `tani`nin ilk (en anlamli) onerisi. Acikca istenen bir bicim
    yapilamiyorsa SEBEBIYLE reddedilir; sessizce baska bicime DUSULMEZ.
    Doner: {ok, bicim, klasor, dosyalar, bilgi, tani, mesaj, sure, ...}
    """
    t0 = time.time()
    if not klasor:
        raise ValueError("an output folder is required")
    gid = _int(gid)
    icid = _int(icid)
    r = {"ok": False, "bicim": bicim, "klasor": None, "dosyalar": [], "bilgi": None,
         "mesaj": None, "sure": 0.0, "surum": SURUM}
    with _baglam(forge) as yol:
        t = tani(gid, icid, yol)
        r["tani"] = t
        if not t["ok"]:
            r["mesaj"] = t["mesaj"]
            return r
        # Golgeli girisi CIKARMAK serbest (bakmak zararsiz) ama kullanici oyunun
        # KULLANMADIGI kopyaya baktigini bilmeli -- yoksa duzenler, geri koyamaz ve
        # sebebini ancak yazma aninda ogrenir.
        r["golge"] = t.get("golge")
        if t.get("golge"):
            r["uyari"] = _golge_mesaji(t["golge"])
        secilen = bicim or (t["yapabilecekler"][0] if t["yapabilecekler"] else BICIM_HAM)
        if secilen not in BICIMLER:
            r["mesaj"] = "Unknown export format %r (use one of: %s)." % (
                secilen, ", ".join(BICIMLER))
            return r
        if secilen not in t["yapabilecekler"]:
            r["mesaj"] = ("This entry cannot be exported as %s: %s. Raw bytes always work."
                          % (secilen, t["sebepler"].get(secilen) or "not supported here"))
            return r
        r["bicim"] = secilen
        lf = C._forge()
        try:
            t["giris_sha256"] = _sha(lf.read_raw(gid))
        except Exception:                                       # noqa: BLE001
            t["giris_sha256"] = None

        ek = {}
        if secilen == BICIM_HAM:
            hedef = _hedef_klasor(klasor, t)
            dosyalar, parcalar = _ham_yaz(t, hedef, lf, progress)
        elif secilen == BICIM_MESH:
            with _cok_forge_baglami(yol, gid) as (zincir, z):
                s, anahtar = _mesh_yaz(t, klasor, progress)
                ist = (z or {}).get("istatistik") or {}
                r["forge_zinciri"] = [os.path.basename(p) for p in zincir]
                r["forge_halkalari"] = list(ist.get("halkalar") or [])
                r["forge_okumalari"] = {k: dict(v) for k, v in (ist.get("okuma") or {}).items()}
            if not s.get("ok"):
                r["mesaj"] = ("The mesh could not be exported: %s"
                              % (s.get("atlanan") or s.get("mesaj") or "unknown reason"))
                r["export"] = s
                return r
            hedef = s["klasor"]
            dosyalar = [s["glb"]]
            parcalar = [{"icid": (t.get("mesh_hedefi") or {}).get("icid"),
                         "icid_sayi": (t.get("mesh_hedefi") or {}).get("icid_sayi"),
                         "ad": t.get("ad"), "dosya": os.path.basename(s["glb"]),
                         "sha256": _dosya_sha(s["glb"]), "boyut": os.path.getsize(s["glb"]),
                         "yazilabilir": True}]
            ek = {"anahtar": anahtar, "glb": os.path.basename(s["glb"]),
                  "manifest": MANIFEST_AD, "export": {k: s.get(k) for k in
                                                      ("parca_sayisi", "cikan", "atlanan")},
                  # materyal/doku hangi arsivlerden okundu (cok-forge gorunumu; bkz. _cok_forge_baglami)
                  "forge_zinciri": r.get("forge_zinciri"),
                  "forge_okumalari": r.get("forge_okumalari")}
            r["export"] = s
        elif secilen in (BICIM_DOKU, BICIM_DOKU_DDS):
            _dds = (secilen == BICIM_DOKU_DDS)
            hedef = _hedef_klasor(klasor, t)
            s, dosyalar = _doku_yaz(t, hedef, progress, dds=_dds)
            if not dosyalar:
                sebep = "; ".join(str(a.get("sebep")) for a in (s.get("atlanan") or [])) \
                    or "no readable texture slot"
                r["mesaj"] = "No texture could be decoded from this entry: %s" % sebep
                r["export"] = s
                return r
            if _dds and not any(k.get("dds_dosya") for k in (s.get("slotlar") or [])):
                sebep = "; ".join(str(a.get("sebep")) for a in (s.get("atlanan") or [])) \
                    or "no slot has a readable level 0"
                r["mesaj"] = "No .dds could be written from this entry: %s" % sebep
                r["export"] = s
                return r
            parcalar = [{"dosya": os.path.basename((k.get("dds_dosya") if _dds
                                                    else k.get("dosya")) or ""),
                         "rol": k.get("rol"), "W": k.get("W"), "H": k.get("H"),
                         "aile": k.get("aile"), "kap": k.get("kap"), "kap_tm": k.get("kap_tm"),
                         "sha256": (k.get("dds_sha256") if _dds else k.get("sha256")),
                         "mip_sayisi": k.get("mip_sayisi"),
                         "yazilabilir": True}
                        for k in (s.get("slotlar") or [])
                        if (k.get("dds_dosya") if _dds else k.get("dosya"))]
            ek = {"manifest": MANIFEST_AD, "textures": TEX_KLASOR,
                  "atlanan": s.get("atlanan") or []}
            if _dds:
                # Sessiz kalinmayacak: yazicinin gomulu yerlesimi bu seviyelerde
                # bizimkiyle ayrisiyor, yani geri koyarken onlar YAZILMAZ.
                _yz = sorted({lvl for k in (s.get("slotlar") or [])
                              for lvl in (k.get("yazilmayan_mip") or [])})
                if _yz:
                    r["uyari"] = ("The smallest mip levels (%s) are exported but cannot be "
                                  "written back by this version: the texture writer places "
                                  "them differently from where the game reads them. "
                                  "Everything larger comes back byte for byte."
                                  % ", ".join(str(x) for x in _yz))
            r["export"] = s
        else:                                                   # BICIM_SES
            hedef = _hedef_klasor(klasor, t)
            dosyalar, parcalar, hata, artan = _ses_yaz(t, hedef, progress)
            if not dosyalar:
                r["mesaj"] = hata or "No sound could be decoded from this entry."
                return r
            ek = {"artan_ses": artan}
            if artan:
                r["uyari"] = ("This bank holds %d sounds; the first %d were written. "
                              "Use the Sounds tab to reach the rest." % (artan + SES_LIMIT,
                                                                        SES_LIMIT))
        r["klasor"] = hedef
        r["dosyalar"] = dosyalar
        r["bilgi"] = _bilgi_yaz(hedef, t, secilen, dosyalar, parcalar, ek)
        r["parcalar"] = parcalar
        r["ok"] = True
        r["sure"] = round(time.time() - t0, 3)
        return r


# =====================================================================================
#  E3 -- GERI AL (import)
# =====================================================================================
# .dds ayni DOKU yoluna gider (doku_ithal.tara manifestten hangi dosyanin degistigini
# okur); ayri bir "geri koyma bicimi" degildir, cunku yazici de aynidir.
UZANTI_BICIM = {".bin": BICIM_HAM, ".glb": BICIM_MESH, ".png": BICIM_DOKU,
                ".dds": BICIM_DOKU, ".wav": BICIM_SES}


def bilgi_oku(kaynak):
    """(bilgi_dict|None, klasor). `kaynak` klasor ya da dosya olabilir."""
    kaynak = os.path.abspath(kaynak)
    klasor = kaynak if os.path.isdir(kaynak) else os.path.dirname(kaynak)
    yol = os.path.join(klasor, BILGI_AD)
    if not os.path.isfile(yol):
        return None, klasor
    try:
        with open(yol, encoding="utf-8") as f:
            return json.load(f), klasor
    except Exception:                                           # noqa: BLE001
        return None, klasor


def _hedef_coz(kaynak, gid, icid):
    """bilgi.json + cagiranin verdigi kimlik -> (gid, icid, bicim, bilgi, klasor, hata).

    KURAL: bilgi.json bir KIMLIK KAGIDIDIR. Cagiran BASKA bir hedef soylerse bu bir
    kullanici hatasidir (yanlis klasor secildi / dosya baska bir isin yanina kopyalandi)
    ve YAZMA REDDEDILIR -- ayni baytlari yanlis girise yazmak arsivi bozar ve geri
    alma kaydi da yanlis yeri gosterir."""
    bilgi, klasor = bilgi_oku(kaynak)
    gid = _int(gid)
    icid = _int(icid)
    if bilgi is None:
        if gid is None:
            return None, None, None, None, klasor, (
                "%s is missing next to this file, so there is no record of where these bytes "
                "belong. Export the entry again with the Explorer, or pass the entry id "
                "explicitly." % BILGI_AD)
        return gid, icid, None, None, klasor, None
    b_gid = _int(bilgi.get("gid_sayi") if bilgi.get("gid_sayi") is not None else bilgi.get("gid"))
    b_icid = _int(bilgi.get("icid_sayi") if bilgi.get("icid_sayi") is not None
                  else bilgi.get("icid"))
    if gid is not None and b_gid is not None and gid != b_gid:
        return None, None, None, bilgi, klasor, (
            "%s says these bytes belong to entry %s, but %s was asked for - refused. "
            "Nothing was written." % (BILGI_AD, _hex(b_gid), _hex(gid)))
    if icid is not None and b_icid is not None and icid != b_icid:
        return None, None, None, bilgi, klasor, (
            "%s says these bytes belong to inner file %s, but %s was asked for - refused. "
            "Nothing was written." % (BILGI_AD, _hex(b_icid), _hex(icid)))
    return (b_gid if gid is None else gid), (b_icid if icid is None else icid), \
        bilgi.get("bicim"), bilgi, klasor, None


def _ham_dosyalar(kaynak, bilgi, klasor):
    """Geri yazilacak (.bin -> icid) esleme listesi."""
    parcalar = list((bilgi or {}).get("parcalar") or [])
    ad2icid = {str(p.get("dosya")): p for p in parcalar if p.get("dosya")}
    if os.path.isfile(kaynak):
        adaylar = [kaynak]
    else:
        adaylar = sorted(os.path.join(klasor, a) for a in os.listdir(klasor)
                         if a.lower().endswith(".bin"))
    out = []
    for yol in adaylar:
        p = ad2icid.get(os.path.basename(yol)) or {}
        out.append({"dosya": yol, "icid_sayi": _int(p.get("icid_sayi")
                                                    if p.get("icid_sayi") is not None
                                                    else p.get("icid")),
                    "yazilabilir": p.get("yazilabilir", True),
                    "sebep": p.get("sebep"), "kaynak_sha": p.get("sha256")})
    return out


def geri_yukle(kaynak, gid=None, icid=None, forge=None, etiket="", progress=None,
               ustune=False, golge_yoksay=False):
    """E3 -- diskteki dosyayi/klasoru oyuna geri koy. TEK YAZICI: kendi yazicimiz YOK.

    * bilgi.json varsa hedef ORADAN okunur (kullanici elle kimlik girmez); cagiran baska
      bir hedef soylerse yazma REDDEDILIR.
    * .bin  -> kur_mesh.giris_kur + kur_mesh.kur (sinifa BAKMAZ; olculdu 2026-09-05)
    * .glb  -> mesh_ithal.plan + uygula   (icinde kur_mesh)
    * .png / .dds -> doku_ithal.tara/hazirla/uygula (icinde doku_enjekte2). .dds ayni
      bicimdeyse HIC yeniden kodlanmaz, baytlar oldugu gibi yazilir.
    * .wav  -> reddedilir: hicbir motorumuz WAV'i Wwise sesine KODLAMAZ (Sounds sekmesi
      oyun icindeki iki sesi TAKAS eder). "Yapabiliyoruz" demek yalan olurdu.
    """
    t0 = time.time()
    r = {"ok": False, "kaynak": os.path.abspath(kaynak), "bicim": None, "yazilan": [],
         "kayit": [], "mesaj": None, "sure": 0.0, "surum": SURUM}
    kilit = KM.yazma_kilidi()
    if kilit:
        # kur_mesh mesh yolunu kilitliyor; doku yolunun (doku_enjekte2) kendi kilidi yok.
        # Explorer ikisini de ayni kilide baglar, yoksa "kilitli" yalnizca yarim dogru olurdu.
        r["mesaj"] = KM._kilit_mesaji(kilit)
        return r
    if KM.oyun_acik_mi():
        r["mesaj"] = "Close the game first."
        return r
    g, ic, bicim, bilgi, klasor, hata = _hedef_coz(kaynak, gid, icid)
    r["bilgi"] = bilgi
    r["klasor"] = klasor
    if hata:
        r["mesaj"] = hata
        return r
    if not bicim:
        bicim = UZANTI_BICIM.get(os.path.splitext(kaynak)[1].lower())
        if not bicim and os.path.isdir(kaynak):
            for uz, b in UZANTI_BICIM.items():
                if any(a.lower().endswith(uz) for a in os.listdir(kaynak)):
                    bicim = b
                    break
    r["bicim"] = bicim
    if bicim is None:
        r["mesaj"] = "Nothing importable found here (.bin, .glb, .png or .dds expected)."
        return r
    if bicim == BICIM_SES:
        r["mesaj"] = ("Sounds cannot be written back from a .wav file: nothing in this tool "
                      "encodes WAV into the game's Wwise format. The Sounds tab swaps one "
                      "in-game sound for another instead.")
        return r

    hedef_forge = forge or (bilgi or {}).get("forge") or arsiv_yolu()
    if not os.path.isfile(hedef_forge):
        r["mesaj"] = "Game archive not found: %s" % hedef_forge
        return r
    # GOLGE KAPISI: hedef gid ust bir zincir halkasinda da varsa yazma BASARILI olur ama
    # oyun oteki kopyayi gostermeye devam eder. Sessiz basarisizlik reddedilmekten beter --
    # bu yuzden ONCEDEN durdurulur ve DOGRU hedef adiyla soylenir.
    #
    # Kapinin anahtari `ustune` DEGIL, AYRI bir bayraktir. Ikisi FARKLI soru:
    #   ustune       = "bu giriste zaten bizim yamamiz var, uzerine yaz"
    #   golge_yoksay = "bu girisi oyun okumuyor olsa da yine de yaz"
    # Onceki surumde ikisi ayni bayraga baglanmisti ve toplu.py ayni girisin ikinci
    # dosyasi icin `ustune=True` gecerek kapiyi FARKINDA OLMADAN dusuruyordu.
    gol = golgeleyen(g, hedef_forge)
    r["golge"] = gol if gol.get("golgede") else None
    r["golge_yoksay"] = bool(golge_yoksay)
    if gol.get("golgede") and not golge_yoksay:
        # YONLENDIRME (2026-10-12). Eskiden burada REDDEDILIRDI ("open X and edit it there");
        # Patch_01'de guncellenen kiyafetler (Connor, Altair; Nexus LordOfThe9) boylece HIC
        # duzenlenemiyordu. Simdi kur_mesh.kur her kimligi, oyunun GERCEKTEN okudugu halkaya
        # (kimligi iceren en yuksek yama) yonlendirir ve `yonlendi_arsiv` ile soyler; orijinal
        # de ayni zincirden OKUNUR (CF.okuma_gorunumu, patch kazanir). `golge_yoksay=True`
        # eski anlamini korur: verilen arsive yazilir, yonlendirme KAPALI (yonlendir=False).
        r["yonlendi_arsiv"] = gol.get("forge")
        r["golge_notu"] = _yonlendirme_mesaji(gol)
    with _baglam(hedef_forge) as yol:
        r["forge"] = yol
        if bicim not in (BICIM_HAM, BICIM_MESH):
            return _geri_doku(r, klasor, progress, t0)   # doku yazicisi tek forge okur/yazar
        with CF.okuma_gorunumu(C, yol):                  # oyunun okudugu zincir (patch kazanir)
            if bicim == BICIM_HAM:
                return _geri_ham(r, kaynak, bilgi, klasor, g, ic, yol, etiket, progress, ustune,
                                 t0, yonlendir=(not golge_yoksay))
            return _geri_mesh(r, klasor, bilgi, etiket, progress, t0)


def _geri_ham(r, kaynak, bilgi, klasor, gid, icid, forge, etiket, progress, ustune, t0,
              yonlendir=None):
    """HAM .bin -> kur_mesh. Sinif bakilmaz; kap (K1/K2) kur_mesh.giris_kur ile dizilir."""
    if gid is None:
        r["mesaj"] = "No target entry id for these bytes."
        return r
    isler = _ham_dosyalar(kaynak, bilgi, klasor)
    if not isler:
        r["mesaj"] = "No .bin file found here."
        return r
    lf = C._forge()
    icler, kap_hatasi = _ic_dosya_listesi(lf, gid)
    if kap_hatasi:
        r["mesaj"] = ("Entry %s is not a container we can rebuild (%s), so raw bytes cannot "
                      "be written back into it." % (_hex(gid), kap_hatasi))
        return r
    var_olan = {c for c, _g, _t, _a in icler}
    if len(isler) == 1 and isler[0]["icid_sayi"] is None:
        isler[0]["icid_sayi"] = icid if icid is not None else (
            gid if gid in var_olan else (sorted(var_olan)[0] if len(var_olan) == 1 else None))
    eksik = [i for i in isler if i["icid_sayi"] is None]
    if eksik:
        r["mesaj"] = ("Could not tell which inner file %s belongs to (entry %s holds %d). "
                      "Export it again with the Explorer so %s records the target."
                      % (os.path.basename(eksik[0]["dosya"]), _hex(gid), len(var_olan), BILGI_AD))
        return r
    yabanci = [i for i in isler if i["icid_sayi"] not in var_olan]
    if yabanci:
        r["mesaj"] = ("Inner file %s is not in entry %s - refused. Nothing was written."
                      % (_hex(yabanci[0]["icid_sayi"]), _hex(gid)))
        return r
    reddedilen = [i for i in isler if not i.get("yazilabilir", True)]
    if reddedilen:
        r["mesaj"] = (reddedilen[0].get("sebep") or
                      "these bytes were exported from an entry that cannot be written back")
        return r

    orij = {c: g for c, g, _t, _a in icler}
    gorulen = set()
    for i in isler:
        with open(i["dosya"], "rb") as f:
            yeni = f.read()
        # UZUNLUK DEGISIMI (2026-09-09): kur_mesh K1 uzunlugunu, K2'yi ve TOC'u zaten yeniden
        # diziyor; eksik olan ic dosyanin KENDI sarmalayici boyut alaniydi (silah_stat dersi).
        # Orijinalin kuyrugu korunur, kullanicinin baytlari govdeye sayilir; bozuk baslik
        # (tip uyusmazligi / boyut tasmasi) yazmadan once reddedilir.
        eski = orij.get(i["icid_sayi"])
        uzunluk = None
        if eski is not None and len(yeni) != len(eski):
            try:
                kuyruk = FG.sarmalayici_coz(eski)["kuyruk"]
                yeni, b_eski, b_yeni = FG.sarmalayici_boyut_duzelt(yeni, kuyruk)
                FG.sarmalayici_coz(yeni)
            except (ValueError, struct.error) as e:
                r["mesaj"] = ("%s changes the length of inner file %s (%d -> %d B) but its "
                              "wrapper header is not intact: %s. Nothing was written."
                              % (os.path.basename(i["dosya"]), _hex(i["icid_sayi"]),
                                 len(eski), len(yeni), e))
                if r["kayit"]:
                    r["geri_alinan"] = [KM.geri_al(k).get("ok") for k in reversed(r["kayit"])]
                return r
            uzunluk = {"eski": len(eski), "yeni": len(yeni), "fark": len(yeni) - len(eski),
                       "sarmalayici_eski": b_eski, "sarmalayici_yeni": b_yeni, "kuyruk": kuyruk}
            _log(progress, "  %s: length %d -> %d B (%+d); wrapper size %d -> %d"
                 % (os.path.basename(i["dosya"]), len(eski), len(yeni),
                    len(yeni) - len(eski), b_eski, b_yeni))
        et = "%s%s" % (ETIKET_ONEK, etiket or "raw %s/%s" % (_hex(gid), _hex(i["icid_sayi"])))
        kr = KM.kur(forge, gid, i["icid_sayi"], yeni, etiket=et, yontem="ek",
                    ustune=ustune or (gid in gorulen), yonlendir=yonlendir)
        gorulen.add(gid)
        if kr.get("yonlendi_arsiv"):
            r["yonlendi_arsiv"] = kr["yonlendi_arsiv"]
        if not kr.get("ok"):
            r["mesaj"] = kr.get("mesaj") or "The archive could not be written."
            r["basarisiz"] = kr
            if r["kayit"]:
                # Yarim kurulum birakma: bu turda yazilanlari geri al (tumu-ya-da-hic).
                r["geri_alinan"] = [KM.geri_al(k).get("ok") for k in reversed(r["kayit"])]
            return r
        r["kayit"].append(kr["kayit_id"])
        r["yazilan"].append({"gid": _hex(gid), "icid": _hex(i["icid_sayi"]),
                             "dosya": os.path.basename(i["dosya"]),
                             "bayt": len(yeni), "kayit_id": kr["kayit_id"],
                             "uzunluk": uzunluk,
                             "arsiv": kr.get("yonlendi_arsiv") or os.path.basename(forge)})
        _log(progress, "  wrote %s into %s (%d B)"
             % (os.path.basename(i["dosya"]), _hex(gid), len(yeni)))
    r["ok"] = True
    r["sure"] = round(time.time() - t0, 3)
    degisen = [y for y in r["yazilan"] if y.get("uzunluk")]
    r["mesaj"] = "%d inner file(s) written." % len(r["yazilan"])
    if degisen:
        r["mesaj"] += (" %d of them changed length; the wrapper size field was rewritten "
                       "(%s). Counts inside the object, if any, are yours to keep right; "
                       "Revert restores the original bytes." % (
                           len(degisen), ", ".join("%+d B" % y["uzunluk"]["fark"] for y in degisen)))
    return r


def _geri_mesh(r, klasor, bilgi, etiket, progress, t0):
    """GLB -> mesh_ithal (icinde kur_mesh). Duzenlenmis dosya: <anahtar>_edit.glb."""
    from export3d import mesh_ithal as MI
    try:
        man, _y = _manifest_oku(klasor)
    except FileNotFoundError as e:
        r["mesaj"] = str(e)
        return r
    p = MI.plan(klasor, man, progress=progress)
    r["plan"] = {k: p.get(k) for k in ("durum", "sebep", "yazilacak", "atlanan", "red")}
    if not p.get("yazilabilir"):
        r["mesaj"] = p.get("sebep") or "There is nothing to import from this folder."
        return r
    s = MI.uygula(p, progress=progress, etiket="%s%s" % (ETIKET_ONEK, etiket or "mesh"))
    r["ok"] = bool(s.get("ok")) and bool(s.get("yazilan_sayi"))
    r["yazilan"] = list(s.get("yazilan") or [])
    r["kayit"] = list(s.get("kayit") or [])
    r["mesaj"] = s.get("mesaj") or ("%d mesh part(s) written." % (s.get("yazilan_sayi") or 0))
    r["sure"] = round(time.time() - t0, 3)
    return r


def _geri_doku(r, klasor, progress, t0):
    """PNG -> doku_ithal (icinde TEK doku yazicisi doku_enjekte2; Revert All bunu gorur)."""
    from export3d import doku_ithal as DI
    try:
        rapor = DI.tara(klasor, progress=progress, glb=False)
    except FileNotFoundError as e:
        r["mesaj"] = str(e)
        return r
    r["tarama"] = {"yazilacak": len(rapor.get("yazilacak") or []),
                   "degismeyen": rapor.get("degismeyen"), "red": rapor.get("red") or []}
    if not rapor.get("ok") or not rapor.get("yazilacak"):
        r["mesaj"] = (("; ".join(str(x.get("sebep")) for x in (rapor.get("red") or []))
                       or "No changed texture in this folder - nothing to write."))
        return r
    hz = DI.hazirla(rapor, progress=progress)
    s = DI.uygula(klasor, progress=progress, rapor=hz if isinstance(hz, dict) else rapor,
                  mesh=False)
    r["ok"] = bool(s.get("ok"))
    r["yazilan"] = list(s.get("yazilan") or [])
    r["mesaj"] = s.get("mesaj") or ""
    r["sure"] = round(time.time() - t0, 3)
    return r


def _manifest_oku(klasor):
    yol = os.path.join(klasor, MANIFEST_AD)
    if not os.path.isfile(yol):
        raise FileNotFoundError(
            "%s is missing in this folder, so there is nothing to compare the edited model "
            "against. Export the entry again with the Explorer." % MANIFEST_AD)
    with open(yol, encoding="utf-8") as f:
        return json.load(f), yol


# =====================================================================================
#  E4 -- DURUM / GERI ALMA
# =====================================================================================
KULLANILMAZ_NOTU = (
    "The copy is in the archive and the tool can read it back, but the game will not "
    "use it until something points at it (an outfit/weapon table entry, for example). "
    "Revert removes the row again and the archive returns to its original bytes.")


def cogalt(gid, yeni_ad, forge=None, etiket="", progress=None):
    """E5 -- bu girisi YENI bir giris olarak arsive EKLE (kaynak dokunulmadan).

    Bugune kadar butun yazma yollari VAR OLAN bir satiri yonlendiriyordu; bu, TOC'a
    YENI bir satir ekleyen tek yoldur. Baytlar arsivin sonuna, satir TOC'un ardindaki
    bos alana yazilir (TOC TASINMAZ), kimlik ve ad yeniden yazilir.

    DURUSTLUK: yeni giris arsivde durur ve okunur ama OYUN ONU KULLANMAZ -- kullanmasi
    icin ona isaret eden bir veri kaydi (kiyafet/silah tablosu vb.) gerekir. Bu yol o
    kayitlari YAZMAZ; kullaniciya da boyle soylenir.
    """
    gid = _int(gid)
    r = {"ok": False, "gid": _hex(gid), "yeni_ad": yeni_ad}
    kilit = KM.yazma_kilidi()
    if kilit:
        r["mesaj"] = KM._kilit_mesaji(kilit)
        return r
    sebep = TE.ad_gecerli(yeni_ad)
    if sebep:
        r["mesaj"] = sebep
        return r
    with _baglam(forge) as yol:
        _log(progress, "reading entry %s" % _hex(gid))
        t = tani(gid, forge=yol)
        if t.get("kap") != "bms":
            r["mesaj"] = (t.get("mesaj") or t.get("kap_sebep")
                          or "This entry is not a container we can copy.")
            return r
        r["kaynak_ad"] = t.get("ad")
        et = etiket or ("%sduplicate %s as %s" % (ETIKET_ONEK, _hex(gid), yeni_ad))
        if not et.startswith(ETIKET_ONEK):
            et = ETIKET_ONEK + et
        _log(progress, "adding a new entry named %s" % yeni_ad)
        s = TE.cogalt(yol, gid, yeni_ad, etiket=et)
        # TOC degisti: acik tanitici ve onbellekler artik BAYAT (nesne_yaz dersi).
        _onbellekleri_bosalt()
    s.setdefault("ok", False)
    s["kaynak_gid"] = _hex(gid)
    s["kaynak_ad"] = t.get("ad")
    s["forge"] = yol
    s["forge_ad"] = os.path.basename(yol)
    s["sinif"] = t.get("sinif")
    s["sinif_crc"] = t.get("sinif_crc")
    if s.get("ok"):
        s["not"] = KULLANILMAZ_NOTU
    return s


def _explorer_mi(y):
    return str((y or {}).get("etiket") or "").startswith(ETIKET_ONEK)


def durum(forge=None):
    """Explorer'dan yazilmis her sey (kur_mesh kaydindan SUZULUR) + doku deposu ozeti.

    Doner: {kayit, yamalar:[...], toplam, kuyruk_bayt, doku, hepsi, not}
    `yamalar` yalniz Explorer'in yazdiklaridir; `hepsi` ayni arsivdeki TUM mesh
    yamalarini sayar -- kullanici "temiz sandim" tuzagina dusmesin diye ikisi de gosterilir.
    """
    f = os.path.abspath(forge or arsiv_yolu())
    d = KM.durum(f)
    benim = [y for y in (d.get("yamalar") or []) if _explorer_mi(y)]
    for y in benim:
        y["aciklama"] = str(y.get("etiket"))[len(ETIKET_ONEK):]
    sag = KM.saglik(f)
    return {"forge": f, "kayit": d.get("kayit"), "yamalar": benim, "toplam": len(benim),
            "hepsi": d.get("aktif"), "kuyruk_bayt": d.get("kuyruk_bayt"),
            "bayat": d.get("bayat"), "bayat_yamalar": d.get("bayat_yamalar") or [],
            "doku": sag.get("doku"),
            "not": ("Texture writes go through the shared texture record, so they are reverted "
                    "with Revert All (Outfits) rather than from this list.")}


def geri_al(kayit_id=None, forge=None):
    """Explorer yazmasini geri al. kayit_id=None -> Explorer'in HEPSI (yeniden eskiye).

    Baska bir aracin (Outfits / Ships / mesh ithalati) yamasi ASLA geri alinmaz: kimlik
    Explorer etiketi tasimiyorsa reddedilir. Yoksa "Explorer'i temizle" dedigi zaman
    kullanicinin kiyafet yamasi da giderdi."""
    f = os.path.abspath(forge or arsiv_yolu())
    kilit = KM.yazma_kilidi()
    if kilit:
        return {"ok": False, "mesaj": KM._kilit_mesaji(kilit)}
    d = KM.durum(f)
    benim = [y for y in (d.get("yamalar") or []) if _explorer_mi(y)]
    if kayit_id:
        if not any(y.get("id") == kayit_id for y in benim):
            return {"ok": False, "mesaj": ("Patch %r was not written by the Explorer - refused."
                                           % kayit_id)}
        hedefler = [kayit_id]
    else:
        hedefler = [y["id"] for y in benim][::-1]               # yeniden eskiye
    if not hedefler:
        return {"ok": True, "geri_alinan": 0, "sonuclar": [],
                "mesaj": "The Explorer has nothing to revert in %s." % os.path.basename(f)}
    sonuc, kac = [], 0
    for kid in hedefler:
        s = KM.geri_al(kid)
        sonuc.append({"id": kid, "ok": bool(s.get("ok")), "mesaj": s.get("mesaj"),
                      "kuyruk_bayt": s.get("kuyruk_bayt")})
        kac += 1 if s.get("ok") else 0
    return {"ok": kac == len(hedefler), "geri_alinan": kac, "istenen": len(hedefler),
            "sonuclar": sonuc, "kuyruk_bayt": KM.kuyruk_bayt(f),
            "mesaj": "%d of %d reverted." % (kac, len(hedefler))}


if __name__ == "__main__":                                      # elle yoklama
    import pprint
    if len(sys.argv) > 1:
        pprint.pprint(tani(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None))
    else:
        pprint.pprint(durum())
