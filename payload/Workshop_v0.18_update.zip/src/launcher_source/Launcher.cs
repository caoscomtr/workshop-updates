// Outfit Workshop launcher.
//
// The single file the end user double-clicks. It locates the folder it was
// extracted into, then starts the bundled Python interpreter on the Tk GUI and
// exits. No console window is ever shown (OutputType WinExe).
//
// Built with the ordinary .NET SDK (dotnet publish), so the executable is the
// stock apphost shell that ships with the SDK - the same shell as
// tools\TexEncode.exe, which scans clean. The runtime it needs is NOT expected
// on the user's machine: the apphost is stamped with
// AppHostDotNetSearch=AppRelative and AppHostRelativeDotNet=tools\dotnet, so it
// loads the copy of .NET that travels inside this package under tools\dotnet.
//
// Error reporting uses user32!MessageBoxW rather than System.Windows.Forms so
// that the package only has to carry Microsoft.NETCore.App and not the extra
// Windows Desktop framework.

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

internal static class Launcher
{
    private const string APP = "Outfit Workshop";

    private const string MSG_MISSING =
        "Outfit Workshop files are missing. Extract the whole folder from the zip and run this again.";

    // Relative to the folder this executable sits in.
    private const string REL_PYTHON = @"python\pythonw.exe";
    private const string REL_SCRIPT = @"src\OutfitWorkshop.pyw";

    private const uint MB_OK = 0x00000000;
    private const uint MB_ICONERROR = 0x00000010;
    private const uint MB_SETFOREGROUND = 0x00010000;

    [DllImport("user32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern int MessageBoxW(IntPtr hWnd, string text, string caption, uint type);

    private static int Main()
    {
        string home;
        try
        {
            home = FindHome();
        }
        catch (Exception ex)
        {
            Fail("Outfit Workshop could not work out where it is installed.\r\n\r\n" + ex.Message);
            return 2;
        }

        if (string.IsNullOrEmpty(home))
        {
            Fail(MSG_MISSING);
            return 2;
        }

        string python = Path.Combine(home, REL_PYTHON);
        string script = Path.Combine(home, REL_SCRIPT);

        // Both halves of the release have to be present. Never die silently.
        if (!File.Exists(python) || !File.Exists(script))
        {
            string detail = MSG_MISSING + "\r\n\r\nLooked in:\r\n" + home;
            if (!File.Exists(python))
                detail += "\r\n\r\nNot found:  " + REL_PYTHON;
            if (!File.Exists(script))
                detail += "\r\n\r\nNot found:  " + REL_SCRIPT;
            Fail(detail);
            return 3;
        }

        try
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = python;
            psi.ArgumentList.Add(script);
            psi.WorkingDirectory = home;   // never trust the caller's current directory
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;

            Process p = Process.Start(psi);
            if (p == null)
            {
                Fail("Outfit Workshop could not start its Python runtime.\r\n\r\n" + python);
                return 4;
            }

            // Wait briefly and check the interpreter is still alive. pythonw.exe
            // has no console, so a Python-side startup failure used to leave the
            // user with nothing at all - three people reported "I double click
            // and nothing happens, no error, nothing". A healthy start takes well
            // under half a second, so this delay is never visible; if the process
            // is already gone with a non-zero code, say so and point at the log.
            if (p.WaitForExit(4000) && p.ExitCode != 0)
            {
                string log = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "OutfitWorkshop", "logs");
                Fail("Outfit Workshop started but closed immediately (exit code "
                     + p.ExitCode + ").\r\n\r\n"
                     + "The reason was written to:\r\n" + log + "\r\n\r\n"
                     + "Open the newest session-*.log there. If it mentions "
                     + "oo2core_7_win64.dll, your antivirus has most likely "
                     + "quarantined that file from the tools folder.");
                return 5;
            }
        }
        catch (Exception ex)
        {
            Fail("Outfit Workshop could not start its Python runtime.\r\n\r\n"
                 + python + "\r\n\r\n" + ex.Message);
            return 4;
        }

        // The GUI is on its own now.
        return 0;
    }

    // The folder holding this exe. The working directory is deliberately not
    // consulted: the user may well launch us from a shortcut, the Start menu,
    // or a "Run" box, any of which sets a completely unrelated cwd.
    private static string FindHome()
    {
        string exe = Environment.ProcessPath;

        if (string.IsNullOrEmpty(exe))
        {
            try
            {
                using (Process self = Process.GetCurrentProcess())
                {
                    ProcessModule mm = self.MainModule;
                    if (mm != null)
                        exe = mm.FileName;
                }
            }
            catch (Exception)
            {
                exe = null;
            }
        }

        if (!string.IsNullOrEmpty(exe))
        {
            string dir = Path.GetDirectoryName(Path.GetFullPath(exe));
            if (!string.IsNullOrEmpty(dir))
                return dir;
        }

        // Last resort - the directory the assembly was loaded from.
        string basedir = AppContext.BaseDirectory;
        if (!string.IsNullOrEmpty(basedir))
            return basedir.TrimEnd(Path.DirectorySeparatorChar);

        return null;
    }

    private static void Fail(string text)
    {
        MessageBoxW(IntPtr.Zero, text, APP, MB_OK | MB_ICONERROR | MB_SETFOREGROUND);
    }
}
