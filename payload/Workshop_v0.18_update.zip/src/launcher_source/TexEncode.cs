using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using DirectXTexNet;

// PNG -> BC1/BC3/BC7 DDS (full mip chain).
// Usage: TexEncode <in.png> <out.dds> [srgb] [bc1|bc3|bc7] [whole]
//
// PORTABLE BUILD: helper DLLs are looked up in this program's OWN folder
// (AppContext.BaseDirectory), never at a fixed path, so it runs on any machine.
//
// PROGRESS: block compression is where all the time goes - two minutes for a
// 4096 sail - so it is done one horizontal strip at a time and a line is
// printed after each. BC blocks are 4x4 and are encoded independently of one
// another, so cutting the image into strips whose height is a multiple of 4
// produces byte for byte the same DDS as compressing it in one call. "whole"
// forces the old single-call path and exists to prove exactly that.
internal class Program
{
    // NOTE: under PublishSingleFile, AppContext.BaseDirectory can point at the
    // temporary extraction folder. Use ProcessPath for the executable's real folder.
    private static readonly string LibDir =
        Path.GetDirectoryName(Environment.ProcessPath) ?? AppContext.BaseDirectory;

    private static int Main(string[] args)
    {
        AppDomain.CurrentDomain.AssemblyResolve += (s, e) =>
        {
            string name = new AssemblyName(e.Name).Name;
            string p = Path.Combine(LibDir, name + ".dll");
            return File.Exists(p) ? Assembly.LoadFrom(p) : null;
        };
        try
        {
            return Run(args);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("ERROR: " + ex.GetType().Name + ": " + ex.Message);
            if (ex.InnerException != null)
                Console.Error.WriteLine("  inner: " + ex.InnerException.Message);
            Console.Error.WriteLine("  LibDir: " + LibDir);
            return 1;
        }
    }

    private static int Run(string[] args)
    {
        if (args.Length < 2)
        {
            Console.Error.WriteLine("Usage: TexEncode <in.png> <out.dds> [srgb] [bc1|bc3|bc7] [whole]");
            Console.Error.WriteLine("  Defaults to bc7. Order of the optional words does not matter.");
            return 2;
        }
        string inPng = args[0];
        string outDds = args[1];

        // Optional words in any order: "srgb", a block format, and "whole".
        bool srgb = false;
        bool whole = false;
        string want = "bc7";
        for (int i = 2; i < args.Length; i++)
        {
            string a = args[i].Trim().ToLowerInvariant();
            if (a == "srgb") srgb = true;
            else if (a == "whole") whole = true;
            else if (a == "bc1" || a == "bc3" || a == "bc7") want = a;
            else
            {
                Console.Error.WriteLine("Unknown option: " + args[i]);
                return 2;
            }
        }

        string impl = Path.Combine(LibDir, "DirectXTexNetImpl.dll");
        if (!File.Exists(impl))
        {
            Console.Error.WriteLine("DirectXTexNetImpl.dll not found: " + impl);
            return 3;
        }
        TexHelper.LoadInstanceFrom(impl);

        // IGNORE_SRGB: take the file's 8-bit values literally. Without it, an
        // sRGB/gAMA chunk written by an image editor makes DirectXTex convert
        // the image to linear space and the texture comes out dark in game.
        Console.WriteLine("STAGE load");
        ScratchImage src = TexHelper.Instance.LoadFromWICFile(inPng, WIC_FLAGS.IGNORE_SRGB);
        var meta = src.GetMetadata();
        Console.WriteLine($"Loaded: {meta.Width}x{meta.Height}");

        Console.WriteLine("STAGE mips");
        // SEPARATE_ALPHA: FANT varsayilani premultiply/8-bit yuvarla/un-premultiply
        // yapiyor; alfa~0 bolgelerde alt miplerin RGB'si ~127,5/A hatasiyla
        // KARARIYORDU (olculdu: %72 kararma). Silah diffuse'lari (alfa ort 0,094)
        // ve vanilla-alfali kiyafet dokulari icin RGB ile alfa AYRI filtrelenir.
        ScratchImage mips = src.GenerateMipMaps(TEX_FILTER_FLAGS.FANT | TEX_FILTER_FLAGS.SEPARATE_ALPHA, 0);
        Console.WriteLine($"Mip levels: {mips.GetMetadata().MipLevels}");

        // The game uses BC1 for opaque cloth diffuse, BC3 where an alpha channel
        // matters, and BC7 for normals and the higher quality sheets. The slot's
        // format has to be matched exactly - the injector rejects a mismatch.
        DXGI_FORMAT fmt;
        if (want == "bc1")      fmt = srgb ? DXGI_FORMAT.BC1_UNORM_SRGB : DXGI_FORMAT.BC1_UNORM;
        else if (want == "bc3") fmt = srgb ? DXGI_FORMAT.BC3_UNORM_SRGB : DXGI_FORMAT.BC3_UNORM;
        else                    fmt = srgb ? DXGI_FORMAT.BC7_UNORM_SRGB : DXGI_FORMAT.BC7_UNORM;

        // SRGB_IN: the PNG bytes are ALREADY sRGB encoded - that is what the game
        // stores and what the exporter wrote out. Asking for an _SRGB target format
        // alone makes DirectXTex treat the input as linear and gamma-encode it on
        // the way in, which lifts every dark tone: 40,40,40 came back as 110,110,110
        // and a black outfit rendered grey. With this flag the values are stored
        // literally, so re-encoding an untouched export reproduces the original.
        TEX_COMPRESS_FLAGS cflags = TEX_COMPRESS_FLAGS.PARALLEL;
        if (srgb) cflags |= TEX_COMPRESS_FLAGS.SRGB_IN;

        Console.WriteLine("Encoding " + want.ToUpperInvariant() + (srgb ? " (sRGB)..." : "..."));
        Console.WriteLine("STAGE compress");
        ScratchImage comp = whole
            ? mips.Compress(fmt, cflags, 0.5f)
            : CompressInStrips(mips, fmt, cflags, 0.5f);

        Console.WriteLine("STAGE save");
        comp.SaveToDDSFile(DDS_FLAGS.NONE, outDds);
        Console.WriteLine("SAVED: " + outDds);

        src.Dispose(); mips.Dispose(); comp.Dispose();
        return 0;
    }

    // ---------------------------------------------------------------- progress
    // Work is counted in source pixels across the whole mip chain, so the
    // caller gets a figure that maps onto time spent rather than onto levels
    // finished - mip 0 alone is three quarters of the job.
    private static ScratchImage CompressInStrips(ScratchImage mips, DXGI_FORMAT fmt,
                                                 TEX_COMPRESS_FLAGS flags, float threshold)
    {
        var meta = mips.GetMetadata();
        int levels = meta.MipLevels;
        long total = 0;
        for (int L = 0; L < levels; L++)
        {
            Image im = mips.GetImage(L, 0, 0);
            total += (long)im.Width * im.Height;
        }
        Console.WriteLine("PROGRESS 0 " + total);

        ScratchImage dst = TexHelper.Instance.Initialize2D(
            fmt, meta.Width, meta.Height, 1, levels, CP_FLAGS.NONE);
        long done = 0;
        for (int L = 0; L < levels; L++)
        {
            Image source = mips.GetImage(L, 0, 0);
            Image target = dst.GetImage(L, 0, 0);
            int w = source.Width, h = source.Height;
            int rows = StripRows(h, (long)w * h, total);
            for (int y = 0; y < h; y += rows)
            {
                int sh = Math.Min(rows, h - y);
                using (ScratchImage strip = TexHelper.Instance.Initialize2D(
                           source.Format, w, sh, 1, 1, CP_FLAGS.NONE))
                {
                    TexHelper.Instance.CopyRectangle(source, 0, y, w, sh,
                        strip.GetImage(0, 0, 0), TEX_FILTER_FLAGS.DEFAULT, 0, 0);
                    using (ScratchImage packed = strip.Compress(0, fmt, flags, threshold))
                    {
                        Image block = packed.GetImage(0, 0, 0);
                        // y is always a multiple of 4 here, so this lands on a
                        // whole row of blocks.
                        long offset = (long)(y / 4) * target.RowPitch;
                        Copy(block.Pixels, Shift(target.Pixels, offset), block.SlicePitch);
                    }
                }
                done += (long)w * sh;
                Console.WriteLine("PROGRESS " + done + " " + total);
            }
        }
        return dst;
    }

    // A strip is the unit of progress, and two things decide how tall one is.
    // Aim for roughly this many over the whole chain, so every step of the bar
    // stands for the same slice of the work rather than for a mip level - mip 0
    // alone is three quarters of it.
    private const int TICKS = 64;
    // And never cut a level so finely that setting a strip up costs more than
    // compressing it. Measured: slicing every level into 32 regardless of size
    // added 1% to a 4096 sail but 45% to a 512 texture, which is over in three
    // seconds and has no use for a bar in the first place. At this figure a
    // 2048 sail - seven of the nine slots - still gets 32 steps out of its
    // largest level, one every couple of seconds.
    private const long MIN_STRIP_PIXELS = 128 * 1024;

    private static int StripRows(int h, long pixels, long total)
    {
        int byShare = (int)Math.Round(TICKS * (pixels / (double)total));
        int byCost = (int)(pixels / MIN_STRIP_PIXELS);
        int ticks = Math.Max(1, Math.Min(byShare, byCost));
        int rows = (h + ticks - 1) / ticks;
        rows = (rows + 3) / 4 * 4;          // strips must land on the block grid
        if (rows < 4) rows = 4;
        return Math.Min(rows, h);
    }

    private static IntPtr Shift(IntPtr p, long by)
    {
        return new IntPtr(p.ToInt64() + by);
    }

    private static void Copy(IntPtr from, IntPtr to, long bytes)
    {
        byte[] buf = new byte[(int)Math.Min(bytes, 1 << 20)];
        long moved = 0;
        while (moved < bytes)
        {
            int n = (int)Math.Min(buf.Length, bytes - moved);
            Marshal.Copy(Shift(from, moved), buf, 0, n);
            Marshal.Copy(buf, 0, Shift(to, moved), n);
            moved += n;
        }
    }
}
