# -*- coding: utf-8 -*-
"""
ALFA POLITIKASI  (v0.7 SERIT 4)  --  "hep islak" + vanilla alfa kaybi duzeltmesi
================================================================================
SORUN (2026-08-13 olculdu):
  outfit_core._prepare_png, BC3/BC7 slotlarda alfasiz kullanici PNG'sine
  PIL convert("RGBA") ile DUZ 255 alfa basiyor.
    * s3 (Surface/normal) alfasi GLOSS'tur -> 255 = "hep islak" (Nexus:
      Princehama "outfits never dry").
    * s0 BC3 diffuse'larda vanilla alfa da 255'e eziliyor (19 kiyafette
      41 anlamli slot -- olc_d ciktisina bak).

POLITIKA (bu modul):
  girdi:  kullanici PNG + (mat_id, slot)          cikti: DOGRU alfali temiz PNG
  1) BC1 slot            -> RGB, alfasiz. ESKI DAVRANIS AYNEN (geriye uyum).
  2) BC3/BC7 slot:
     a) kullanici alfasinda GERCEK varyasyon varsa (min < max)  -> KULLANICININ
        alfasi korunur (bilincli tasarim).
     b) alfa duz ama 255 DEGIL (or. hepsi 128)                  -> yine KULLANICI
        (255-disi sabit alfa kazayla olusmaz; eski yol da koruyordu).
     c) alfa yok YA DA duz 255 (kazanin tek imzasi: PIL/editor
        "opak katman" basmis)                                   -> VANILLA alfa
        forge'dan cekilir ve geri konur (slot_mip0_bc + _bc_decode_rgba,
        SALT-OKUNUR). Vanilla cekilemezse 255'e duser (eski davranis).
  3) Zorlama: politika_hazirla(..., zorla="kullanici"|"vanilla") karari ezer
     (GUI'ye "alfa kaynagi" secenegi koymak istersek hazir).

  NOT: 2c guvenlidir cunku TexEncode SEPARATE_ALPHA duzeltmesi kurulu
  (TexEncode.dll sha256 c8b703f9..., 2026-08-13): alfa~0 bolgeler alt
  miplerde artik KARARMIYOR (olc_c_mip.py bu baglamda kaniti tekrarlar).

ENTEGRASYON (kaptan yapar; bu modul mevcut koda DOKUNMAZ):
  outfit_core._encode_design_dir icinde
      clean = _prepare_png(png, cs["W"], cs["H"], cs["aile"], progress)
  yerine
      clean, karar = alfa_politika.politika_hazirla(
          png, mat_id, slot, cs["W"], cs["H"], cs["aile"], progress)
  (karar["karar"] loglanabilir; donen dosya birebir ayni sozlesme: temp'te
   temiz, WxH, profilsiz PNG.)

DIL (2026-09-05 olculdu, tur2 doku matrisi):
  Bu modulun `gerekce` dizeleri KULLANICIYA GORUNUR: 3D IMPORT hattinda
  doku_ithal.hazirla ":468  alpha: %s" ile, 2B Outfit APPLY hattinda
  politika_hazirla kendi log satiriyla basar; ikisi de sunucu._log -> arayuz
  log paneline dusuyor ve arayuzun T() sozlugu bu dizeleri TANIMIYOR (varlik\\
  diller.js icinde 0 eslesme) -- yani metin EKRANA AYNEN gidiyor. Kusur:
  `python testler/tur2_doku_matrisi.py 02 07 07b --hazirla` logunda
  "alpha: PNG'de alfa kanali yok -> vanilla geri konur." gibi TURKCE satirlar,
  ayni logdaki doku_ithal gerekceleri ("BC1 slot has no alpha band.", "R kept,
  G re-inverted ...") Ingilizce iken. Duzeltme: TUM gerekceler + resize satiri
  + politika_hazirla log'u Ingilizce'ye cevrildi (2026-09-05).
  KARAR KODLARI ("kullanici"/"vanilla"/"bc1_opak"/"kullanici_sabit"/
  "vanilla_yok") SOZLESMEDIR -- doku_ithal._ALFA_KULLANICI ve testler onlara
  bakar; Turkce KALIRLAR, log'a `_KARAR_ETIKET` ile Ingilizce yazilirlar.

Forge'a TEK BAYT YAZMAZ. GUI acmaz.
"""
import os
import sys
import tempfile

# Bu modul outfit_core ile AYNI klasorde yasar (hem gelistirmede hem pakette);
# mutlak yol gomulmez -- tasinabilirlik kapisi (kur.py adim 9) bunu denetler.
_SRC = os.path.dirname(os.path.abspath(__file__))
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

import outfit_core as oc                    # SALT-OKUNUR kullanilir

# ----------------------------------------------------------------- yardimcilar
_VANILLA_CACHE = {}          # (matid_hex, slot) -> np.uint8 (H,W) | None


def _alfa_ist(a):
    """alfa kanalinin ozet istatistigi (rapor/log icin)."""
    import numpy as np
    a = np.asarray(a)
    return {"min": int(a.min()), "max": int(a.max()),
            "ort": round(float(a.mean()), 2),
            "p255": round(float((a == 255).mean() * 100.0), 2)}


def _mat_key(mat_id):
    return "0x%X" % (mat_id if isinstance(mat_id, int) else int(mat_id, 16))


# ----------------------------------------------------------------- 16-bit GRI (I;16) kapisi
# Pillow 16-bit RENKLI PNG'yi (RGB / RGBA / LA) ACILISTA yuksek bayta indirip 8-bit acar;
# 16-bit GRI PNG'yi ise ham "I;16" birakir ve convert("L") / convert("RGBA") 255'ten
# buyuk HER degeri 255'e KIRPAR. Olculdu (Pillow 12.3.0, 2026-09-05, tur2 15b/15c):
# 0..255 x257 rampasi convert("L") ile [0,255,255,...]; gloss %100 beyaz (alfa ort 255,
# vanilla 188,3 -> "hep islak" bu kapidan geri geliyordu), diffuse bembeyaz (RGB ort
# 254,98) ve hicbir kapi (tara / NOTE / DE.plan) yakalamiyordu. Burada Pillow'un renkli
# icin yaptiginin aynisi (yuksek bayt = >>8) griye de uygulanir: x257 kaydedilmis 8-bit
# kaynakla BAYT-BIREBIR (np.array_equal True olculdu). 32-bit tamsayi/float gri (I, F)
# icin deger araligi bilinemez -> kirpmak yerine acik red (fail-closed).
_GRI16_MODLAR = ("I;16", "I;16B", "I;16L", "I;16N")


def gri16_8bit(im):
    """Tek kanalli 16-bit PIL goruntusunu 8-bit 'L'ye OLCEKLEYEREK (>>8) indirir; diger
    modlar oldugu gibi doner. PNG'den gelen 'I' (eski Pillow'un 16-bit gri acisi, 0..65535)
    yine >>8; baska kaynakli 'I' / 'F' ValueError (Ingilizce, kullaniciya gosterilir)."""
    import numpy as np
    from PIL import Image
    mod = im.mode
    if mod in _GRI16_MODLAR:
        a = np.asarray(im).astype(np.uint32)
    elif mod == "I" and (im.format or "").upper() == "PNG":
        a = np.clip(np.asarray(im).astype(np.int64), 0, 65535).astype(np.uint32)
    elif mod in ("I", "F"):
        raise ValueError("the file is a 32-bit greyscale image (mode %s); save it as an 8-bit "
                         "greyscale PNG and import again" % mod)
    else:
        return im
    return Image.fromarray((a >> 8).astype(np.uint8))        # uint8 2B -> "L"


def vanilla_alfa(mat_id, slot, W=None, H=None, aile=None):
    """Slotun VANILLA (forge'daki) mip0 alfa kanali, (H,W) uint8; yoksa None.
       Kaynak: oc.slot_mip0_bc + oc._bc_decode_rgba (salt-okunur). ONBELLEKLI.
       W/H verilirse (katalogdan) o boyut dogrulanir/kullanilir.
       `aile` verilirse KATALOGDAN once o kullanilir: 3D ithalat hattinda kap bir
       TextureSet olabiliyor ve TextureSet kiyafet katalogunda YOKTUR -- oradaki
       'BC3 varsayimi' bir BC7 slotunu yanlis cozerdi. Cagiran aileyi canli
       TextureMap tanimindan OLCUP gecirir."""
    import numpy as np
    key = (_mat_key(mat_id), int(slot), aile)
    if key in _VANILLA_CACHE:
        a = _VANILLA_CACHE[key]
        return None if a is None else a.copy()
    a = None
    try:
        cs = None if aile else oc._catalog_slot(_mat_key(mat_id), slot)
        if cs is not None:
            W, H, aile = cs["W"], cs["H"], cs["aile"]
        elif not aile:
            aile = "BC3"                  # katalog disi slot: en yaygin varsayim
        if W is None or H is None:
            raise ValueError("width/height unknown and not found in the catalogue")
        fmt_enum = oc._AILE_ENUM[aile]
        data, _tanim = oc.slot_mip0_bc(_mat_key(mat_id), slot)
        if data is not None:
            gerek = ((W + 3) // 4) * ((H + 3) // 4) * oc.DE.AILE_BLOK[aile]
            if len(data) >= gerek:
                arr = oc._bc_decode_rgba(data[:gerek], W, H, fmt_enum)
                a = np.ascontiguousarray(arr[..., 3])
    except Exception:
        a = None
    _VANILLA_CACHE[key] = a
    return None if a is None else a.copy()


# ----------------------------------------------------------------- karar
# Karar KODU sozlesme (doku_ithal, testler ona bakar) -> degismez; kullaniciya
# gosterilen ETIKET Ingilizce. Bilinmeyen kod oldugu gibi basilir (fail-open log).
_KARAR_ETIKET = {
    "bc1_opak":        "opaque (BC1)",
    "kullanici":       "user alpha",
    "kullanici_sabit": "user alpha (flat)",
    "vanilla":         "game alpha",
    "vanilla_yok":     "game alpha unavailable",
}


def alfa_karari(user_alfa, aile, zorla=None):
    """Kullanici alfa dizisine (None olabilir) bakip karar dondurur.
       -> ("bc1_opak"|"kullanici"|"kullanici_sabit"|"vanilla", gerekce)

       KARAR KODU sozlesmedir (doku_ithal._ALFA_KULLANICI, testler) -> TURKCE KALIR.
       GEREKCE kullaniciya gosterilir (doku_ithal.hazirla "alpha: ..." satiri +
       politika_hazirla log'u) -> INGILIZCE."""
    if aile == "BC1":
        return "bc1_opak", "BC1 slots carry no alpha band; legacy behaviour is kept."
    if zorla in ("kullanici", "vanilla"):
        # `zorla` PARAMETRE DEGERI de sozlesme ("kullanici"/"vanilla") -> ham
        # basilirsa Turkce kelime ekrana dusuyor; etikete cevrilir.
        return zorla, ("overridden by the alpha source setting (%s)."
                       % _KARAR_ETIKET.get(zorla, zorla))
    if user_alfa is None:
        return "vanilla", ("the file has no alpha channel, so the game's own alpha "
                           "is restored.")
    import numpy as np
    a = np.asarray(user_alfa)
    amin, amax = int(a.min()), int(a.max())
    if amin < amax:
        return "kullanici", ("the alpha channel really varies (min %d < max %d), so it is "
                             "kept as deliberate design." % (amin, amax))
    if amin != 255:
        return "kullanici_sabit", ("a flat but non-255 alpha (%d) does not happen by "
                                   "accident, so it is kept." % amin)
    return "vanilla", ("a flat 255 alpha is an editor 'opaque layer' signature, so the "
                       "game's own alpha is restored.")


# ----------------------------------------------------------------- ana giris
def dogru_alfali_rgba(png, mat_id, slot, W, H, aile, zorla=None, progress=None, aile_olculdu=None):
    """Kullanici PNG'sini (mat_id, slot) icin DOGRU alfali diziye cevirir.

    Doner: (arr, karar_dict)
      arr: BC1 -> (H,W,3) uint8;  BC3/BC7 -> (H,W,4) uint8
      karar_dict: {"karar", "gerekce", "kullanici_alfa", "vanilla_alfa",
                   "cikti_alfa"}  (istatistikler; alfa yoksa None)
    """
    import numpy as np
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = None

    with Image.open(png) as im:
        w, h = im.size
        # kaynakta alfa bilgisi var mi? (band ya da tRNS)
        alfa_var = ("A" in im.getbands()) or ("transparency" in im.info)
        # 16-bit gri once OLCEKLI 8-bit L'ye (Pillow convert kirpiyor; ustteki kapi notu)
        kaynak = gri16_8bit(im)
        if aile == "BC1":
            work = kaynak.convert("RGB")
        else:
            work = kaynak.convert("RGBA")
        if (w, h) != (W, H):
            if progress:
                try:
                    progress("  resized %dx%d -> %dx%d" % (w, h, W, H))
                except Exception:
                    pass
            if work.mode == "RGBA":
                # RGBA'yi tek parca kucultmek alfa=0 bolgelerin RGB'sini karartiyor
                # (dogrulayici olctu). RGB ile alfa AYRI kucultulur; renk, saydam
                # bolgede de korunur -- SEPARATE_ALPHA duzeltmesiyle ayni ilke.
                rgb = work.convert("RGB").resize((W, H), Image.LANCZOS)
                a = work.getchannel("A").resize((W, H), Image.LANCZOS)
                work = Image.merge("RGBA", (*rgb.split(), a))
            else:
                work = work.resize((W, H), Image.LANCZOS)
        arr = np.asarray(work).copy()

    if aile == "BC1":
        # alfa_karari'nin BC1 dali ile AYNI metin (iki yerde ayrisamasin)
        karar, gerekce = alfa_karari(None, "BC1")
        return arr, {"karar": karar, "gerekce": gerekce,
                     "kullanici_alfa": None, "vanilla_alfa": None,
                     "cikti_alfa": None}

    user_alfa = arr[..., 3] if alfa_var else None
    karar, gerekce = alfa_karari(user_alfa, aile, zorla)
    van_ist = None
    if karar == "vanilla":
        va = vanilla_alfa(mat_id, slot, W, H, aile_olculdu)
        if va is None:
            karar, gerekce = "vanilla_yok", (gerekce +
                " However the game's own alpha could not be read, so 255 was used"
                " (legacy behaviour).")
            arr[..., 3] = 255
        else:
            if va.shape != (H, W):        # katalog W/H ile forge farkliysa
                va = np.asarray(Image.fromarray(va).resize((W, H), Image.LANCZOS))
            arr[..., 3] = va
            van_ist = _alfa_ist(va)
    return arr, {"karar": karar, "gerekce": gerekce,
                 "kullanici_alfa": None if user_alfa is None else _alfa_ist(user_alfa),
                 "vanilla_alfa": van_ist,
                 "cikti_alfa": _alfa_ist(arr[..., 3])}


def politika_hazirla(png, mat_id, slot, W, H, aile, progress=None, zorla=None, aile_olculdu=None):
    """_prepare_png'in politika-bilincli birebir karsiligi.
       Doner: (temiz_png_yolu, karar_dict) -- yol _tex_encode'a verilir.
       Temiz PNG profil tasimaz (fromarray), boyut W x H."""
    from PIL import Image
    arr, karar = dogru_alfali_rgba(png, mat_id, slot, W, H, aile, zorla, progress, aile_olculdu)
    clean = os.path.join(tempfile.gettempdir(),
                         "OutfitWorkshop_input_%s.png" % os.getpid())
    Image.fromarray(arr).save(clean)
    if progress:
        try:
            progress("  alpha policy: %s (%s)"
                     % (_KARAR_ETIKET.get(karar["karar"], karar["karar"]),
                        karar["gerekce"]))
        except Exception:
            pass
    return clean, karar


def onbellek_temizle():
    _VANILLA_CACHE.clear()
