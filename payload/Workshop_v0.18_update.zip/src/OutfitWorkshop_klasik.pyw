#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OUTFIT WORKSHOP
Outfit texture design tool for Assassin's Creed IV Black Flag Resynced.

Export -> Paint -> Apply.  Folder based: one outfit exports a whole folder of
PNGs (many materials x many slots); you paint the EDIT ("edit") sub-folder,
then point the tool back at that folder to apply it.

Design rules (inherited from Sail Workshop + the outfit feasibility work):
  * The forge is only ever read.  The single writer is doku_enjekte2, wrapped by
    outfit_core.apply_outfit / status_outfit / revert_outfit.  This GUI never
    touches the forge itself.
  * No flip.  Exports are never overwritten.  All text is English.
  * Before applying, status_outfit runs a read-only base-shift proof; if it is
    not "safe" the apply is refused.
"""
import os
import sys
import glob
import time
import queue
import tempfile
import threading
import traceback
import shutil
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

APP_NAME = "Outfit Workshop"


# ======================================================== TASINABILIR PYTHON'U YALIT
def _tcl_yalit():
    """Kullanicinin makinesindeki Tcl/Tk kutuphanesini bu pakete BULASTIRMA.

    Kendi Python'u kurulu olan bir kullanicida `TCL_LIBRARY` ortam degiskeni onun
    kurulumunu gosterir; bizim tasinabilir python bunu miras alir ve KENDI Tcl
    DLL'iyle ONUN init.tcl'ini yuklemeye calisir. Surumler tutmayinca pencere hic
    acilmadan oluyor (kullanici raporu, 2026-07-28):
        version conflict for package "Tcl": have 8.6.15, need exactly 8.6.14
        (bizim DLL 8.6.15, onun Python 3.13'unun kutuphanesi 8.6.14)
    Paketin kendi tcl klasoru varsa oraya SABITLIYORUZ; yoksa miras alinan degeri
    SILIYORUZ (Tcl o zaman kendi varsayilanini buluyor -- ikisi de olculdu).
    PYTHONPATH/PYTHONHOME icin bir sey yapmiyoruz: `python312._pth` onlari zaten
    etkisiz kiliyor (olculdu)."""
    ayar = {}
    kok = os.path.join(sys.prefix, "tcl")
    for degisken, altklasor in (("TCL_LIBRARY", "tcl8.6"), ("TK_LIBRARY", "tk8.6")):
        yol = os.path.join(kok, altklasor)
        if os.path.isdir(yol):
            if os.path.normcase(os.environ.get(degisken, "")) != os.path.normcase(yol):
                ayar[degisken] = (os.environ.get(degisken), yol)
            os.environ[degisken] = yol
        elif os.environ.get(degisken):
            ayar[degisken] = (os.environ[degisken], None)
            del os.environ[degisken]
    # Tcl'in paket arama yolu da disaridan gelebiliyor; bizim paketimizde ek Tcl
    # paketi yok, mirasi tasimanin faydasi da yok.
    for degisken in ("TCLLIBPATH", "TIX_LIBRARY"):
        if os.environ.get(degisken):
            ayar[degisken] = (os.environ[degisken], None)
            del os.environ[degisken]
    return ayar


_TCL_AYAR = _tcl_yalit()

# ============================================================== LOG + CRASH REPORT
# The packaged app runs under pythonw.exe, where sys.stdout and sys.stderr are
# None: every print() and every traceback simply disappears.  Three users
# reported "I double click and nothing happens, no error, nothing" and there was
# no way to tell them what failed.  Everything below runs BEFORE the first
# import that can fail, so even a broken import lands in the log and a dialog.
LOG_DIR = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
                       APP_NAME.replace(" ", ""), "logs")


class _Tee(object):
    """Sends everything written to stdout/stderr to the log file, and (once the
    window exists) to the on-screen console as well."""

    def __init__(self, handle):
        self.handle = handle
        self.gui = None                 # App binds itself here when it is ready
        # Iki thread ayni dosyaya yaziyor: ana thread print/dialog, isci thread
        # ilerleme satirlari. Kilitsizken satirlar birbirine giriyordu
        # (olculdu: 8000 satirda 638-1136 bozuk), yani gonderilen log yaniltici.
        self.lock = threading.RLock()

    def write(self, s):
        try:
            with self.lock:
                self.handle.write(s)
                self.handle.flush()
        except Exception:
            pass
        if self.gui is not None and str(s).strip():
            try:
                self.gui(str(s).rstrip("\n"))
            except Exception:
                pass
        return len(s)

    def flush(self):
        try:
            self.handle.flush()
        except Exception:
            pass

    def to_file(self, s):
        """Sadece log dosyasina yaz (ekrana DEGIL).

        Motorun ilerleme mesajlari (`outfit_core._log`) ekrandaki panele gidiyor
        ama log dosyasina HIC ULASMIYORDU: kullanicidan istedigimiz log yalnizca
        acilis satirlarini iceriyor, apply'in neden hicbir sey yazmadigi orada
        gorunmuyordu. Ekran tarafi ayri gittigi icin burada cift yazim olmaz."""
        try:
            with self.lock:
                self.handle.write(str(s).rstrip("\n") + "\n")
                self.handle.flush()
        except Exception:
            pass

    def isatty(self):
        return False


def _open_log():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        for old in sorted(glob.glob(os.path.join(LOG_DIR, "session-*.log")))[:-4]:
            try:
                os.remove(old)
            except OSError:
                pass
        path = os.path.join(LOG_DIR, time.strftime("session-%Y%m%d-%H%M%S.log"))
        return open(path, "w", encoding="utf-8", buffering=1), path
    except Exception:
        path = os.path.join(tempfile.gettempdir(), "OutfitWorkshop.log")
        return open(path, "a", encoding="utf-8", buffering=1), path


_LOG_HANDLE, LOG_PATH = _open_log()
sys.stdout = sys.stderr = _TEE = _Tee(_LOG_HANDLE)
print("%s starting  %s" % (APP_NAME, time.strftime("%Y-%m-%d %H:%M:%S")))
print("python  : %s" % sys.executable)
print("folder  : %s" % HERE)
print("log     : %s" % LOG_PATH)
# Bir kullanicinin makinesindeki Tcl/Tk bu pakete bulasirsa pencere HIC acilmiyor.
# Ne bulduk / ne yaptik LOGA yazilir: bir daha ayni rapor gelirse tek bakista belli olsun.
for _d, (_eski, _yeni) in sorted(_TCL_AYAR.items()):
    print("tcl     : %s makineden geliyordu (%s) -> %s"
          % (_d, _eski, ("paketinki: %s" % _yeni) if _yeni else "temizlendi"))


def _message_box(title, text):
    """Works under pythonw with no dependencies (tkinter may be the thing that failed)."""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)
    except Exception:
        pass


def _fatal(where, exc):
    print("FATAL while %s:\n%s" % (where, traceback.format_exc()))
    _message_box(
        APP_NAME + " - could not start",
        "%s failed while %s.\n\n%s: %s\n\nFull details were written to:\n%s"
        % (APP_NAME, where, type(exc).__name__, exc, LOG_PATH))


try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
except Exception as _e:                                     # noqa: BLE001
    _fatal("loading tkinter", _e)
    raise SystemExit(1)

try:
    import outfit_core as C
except Exception as _e:                                     # noqa: BLE001
    _fatal("loading the engine (outfit_core)", _e)
    raise SystemExit(1)

OUTPUT = os.path.join(os.path.expanduser("~"), "Documents", "OutfitWorkshop")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ---- theme (matches Sail Workshop) -----------------------------------------
BG = "#1e2229"
PANEL = "#272c35"
TEXT = "#e6e9ef"
MUTED = "#98a0ae"
ACCENT = "#4da3ff"
GOOD = "#57c98b"
WARN = "#e8b44a"
BAD = "#e0685f"

# Turkish safety code -> (English word, colour)
SAFETY = {
    "YESIL": ("SAFE", GOOD),
    "SARI": ("CAUTION", WARN),
    "KIRMIZI": ("RISK", BAD),
}


def safety_en(code):
    return SAFETY.get(code, (code, MUTED))


def scope_en(mat):
    """English one-line 'Affects' summary for a material, built from catalog data
    (the raw core strings are Turkish; we author our own English here)."""
    sh = mat.get("paylasim") or {}
    code = sh.get("renk", "YESIL")
    n = len(sh.get("etkilenen_kiyafetler") or [])
    if sh.get("gardirop_disi"):
        return "Leaks OUTSIDE this wardrobe (%d)" % n
    if code == "YESIL" or n == 0:
        return "Only this outfit"
    return "Shares with %d other outfit%s" % (n, "" if n == 1 else "s")


def affected_names_en(mat):
    """Second line: the actual outfit names this material also changes, English.
    sharing_label already returns English, so this just passes it through."""
    _renk, _s1, s2 = C.sharing_label(mat)
    return s2


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME + " - AC IV Black Flag Resynced")
        self.geometry("1100x800")
        self.minsize(1000, 700)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.busy = False
        self.queue = queue.Queue()
        self.preview_ref = None
        self.started = None
        self.cur_outfit = None          # selected outfit dict
        self.cur_mat = None             # selected material dict
        self._prev_cache = {}           # mat_id -> PhotoImage
        # 3D onizleme durumu: onbellek + acisal konum + "bayat sonucu at" sayaci
        self._3d_cache = {}             # (kiyafet, aci, boya_imzasi) -> PhotoImage
        self._3d_aci = 0
        self._3d_nesil = 0
        self.v3d_ref = None
        self.cur_3d = None              # 3D hattinin kimligi: kiyafet YA DA karakter
        self._buyuk = None              # tam ekran 3D penceresi
        self._buyuk_nesil = 0
        self._buyuk_kareler = {}
        self._buyuk_surukle = None
        self._lc_cache = {}             # mat_id -> leather/cloth text

        self._style()
        self._build()
        self.after(80, self._pump)
        self._setup()

    # -------------------------------------------------------------- style
    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except Exception:
            pass
        s.configure(".", background=BG, foreground=TEXT,
                    fieldbackground=PANEL, borderwidth=0)
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=TEXT)
        s.configure("Muted.TLabel", background=BG, foreground=MUTED)
        s.configure("Title.TLabel", background=BG, foreground=TEXT,
                    font=("Segoe UI", 15, "bold"))
        s.configure("PanelText.TLabel", background=PANEL, foreground=TEXT)
        s.configure("TButton", background="#39414f", foreground=TEXT,
                    padding=(12, 8), font=("Segoe UI", 10))
        s.map("TButton", background=[("active", "#485365"), ("disabled", "#2c313a")],
              foreground=[("disabled", "#6a7280")])
        s.configure("Primary.TButton", background=ACCENT, foreground="#0d1420",
                    font=("Segoe UI", 10, "bold"))
        s.map("Primary.TButton", background=[("active", "#69b3ff"), ("disabled", "#2c313a")])
        s.configure("OW.Horizontal.TProgressbar", troughcolor=PANEL,
                    background=ACCENT, lightcolor=ACCENT, darkcolor=ACCENT,
                    bordercolor=PANEL, borderwidth=0, thickness=12)
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL,
                    foreground=TEXT, rowheight=28, borderwidth=0)
        s.configure("Treeview.Heading", background="#333a45", foreground=MUTED,
                    font=("Segoe UI", 9, "bold"))
        s.map("Treeview", background=[("selected", "#2f5d8f")])
        # portreli liste: satir yuksekligi portreye gore (52px goruntu + nefes)
        s.configure("Liste.Treeview", background=PANEL, fieldbackground=PANEL,
                    foreground=TEXT, rowheight=58, borderwidth=0)
        s.map("Liste.Treeview", background=[("selected", "#2f5d8f")])

    # -------------------------------------------------------------- layout
    def _build(self):
        top = ttk.Frame(self, padding=(16, 14, 16, 6))
        top.pack(fill="x")
        ttk.Label(top, text=APP_NAME, style="Title.TLabel").pack(side="left")
        self.lbl_game = ttk.Label(top, text="checking game...", style="Muted.TLabel")
        self.lbl_game.pack(side="left", padx=14)
        # Referansi SAKLA: bu dugme is sirasinda kapatilmak ZORUNDA. set_game()
        # yalniz okuma yolunu degil, YAZICININ forge/kayit/yedek yollarini da
        # yeniden baglar ve uygula() bunlari her materyalde yeniden okur; yazma
        # suruyorken tiklanirsa yazimlar is ortasinda BASKA kuruluma yonelir,
        # ilki yarim yamali kalir, digerinin geri-alma kaydi ezilir.
        self.b_game = ttk.Button(top, text="Select game folder",
                                 command=self._pick_game)
        self.b_game.pack(side="right")

        mid = ttk.Frame(self, padding=(16, 4, 16, 4))
        mid.pack(fill="both", expand=True)

        # --- left column: outfit list (top) + part list (bottom)
        left = ttk.Frame(mid)
        left.pack(side="left", fill="both", expand=True)

        _bas = ttk.Frame(left, style="Panel.TFrame")
        _bas.pack(fill="x")
        self.lbl_pick = ttk.Label(_bas, text="1.  Pick an outfit",
                                  style="Muted.TLabel")
        self.lbl_pick.pack(side="left")
        # Kategori: kiyafetler / silahlar (beta). Silahlar ayni sema + ayni
        # yazici; "beta" cunku gercek arsivde silah yazimi henuz oyunda
        # dogrulanmadi (okuma + base-shift 99/99 SAFE olculdu).
        self.kategori = tk.StringVar(value="Outfits")
        # Acilir kutu yerine YAN YANA iki dugme (kullanici istegi): hangi
        # kategoride oldugun tek bakista belli, tek tikla gecis.
        for _ad in ("Outfits", "Weapons (beta)", "Characters (beta)"):
            _b = ttk.Radiobutton(_bas, text=_ad, value=_ad,
                                 variable=self.kategori, style="Toolbutton",
                                 command=self._fill_outfits)
            _b.pack(side="right", padx=(4, 0))
        self.tree = ttk.Treeview(left, columns=("safety", "mats", "slots"),
                                 show="tree headings", height=7)
        self.tree.heading("#0", text="Outfit")
        self.tree.heading("safety", text="Safety")
        self.tree.heading("mats", text="Materials")
        self.tree.heading("slots", text="Paintable")
        self.tree.column("#0", width=240)
        self.tree.column("safety", width=120, anchor="center")
        self.tree.column("mats", width=80, anchor="center")
        self.tree.column("slots", width=80, anchor="center")
        self.tree.pack(fill="x")
        self.tree.tag_configure("YESIL", foreground=GOOD)
        self.tree.tag_configure("SARI", foreground=WARN)
        self.tree.tag_configure("KIRMIZI", foreground=BAD)
        self.tree.bind("<<TreeviewSelect>>", self._outfit_changed)

        ttk.Label(left, text="Parts of this outfit (materials)",
                  style="Muted.TLabel").pack(anchor="w", pady=(10, 0))
        self.parts = ttk.Treeview(left, columns=("share", "slots", "affects"),
                                   show="tree headings", height=8)
        self.parts.heading("#0", text="Part")
        self.parts.heading("share", text="Share")
        self.parts.heading("slots", text="Slots")
        self.parts.heading("affects", text="Affects")
        self.parts.column("#0", width=190)
        self.parts.column("share", width=90, anchor="center")
        self.parts.column("slots", width=130, anchor="center")
        self.parts.column("affects", width=190)
        self.parts.pack(fill="both", expand=True)
        self.parts.tag_configure("YESIL", foreground=GOOD)
        self.parts.tag_configure("SARI", foreground=WARN)
        self.parts.tag_configure("KIRMIZI", foreground=BAD)
        self.parts.tag_configure("muted", foreground=MUTED)
        self.parts.bind("<<TreeviewSelect>>", self._part_changed)

        # --- right column: 3D preview + part preview + note
        right = ttk.Frame(mid, style="Panel.TFrame", padding=12)
        right.pack(side="left", fill="y", padx=(14, 0))

        # 3D: kiyafeti karakterin UZERINDE gosterir. Doku onizlemesi "bu PNG neye
        # benziyor" sorusunu yanitliyor; asil soru "bu boya karakterde nasil duruyor".
        ttk.Label(right, text="3D preview", style="PanelText.TLabel").pack(anchor="w")
        # SABIT KUTU: goruntu gelince etiket buyuyor ve sag sutun 268 -> 405 px'e
        # ziplayarak tum pencereyi yeniden akitiyordu (olculdu). `pack_propagate(False)`
        # cerceveyi sabitler; icerideki etiket ne olursa olsun sutun genisligi degismez.
        _kutu = tk.Frame(right, bg=PANEL, width=248, height=248)
        _kutu.pack(pady=(6, 2))
        _kutu.pack_propagate(False)
        self.v3d = tk.Label(_kutu, bg=PANEL, text="pick an outfit", fg=MUTED)
        self.v3d.pack(fill="both", expand=True)
        # Dondurme dugmeleri KALDIRILDI: buyuk gorunumde fareyle surukleniyor.
        self.v3d.configure(cursor="hand2")
        self.v3d.bind("<Button-1>", lambda _e: self._3d_buyut())
        d3 = ttk.Frame(right, style="Panel.TFrame")
        d3.pack(fill="x", pady=(0, 10))
        self.lbl_3d = tk.Label(d3, bg=PANEL, fg=MUTED, font=("Segoe UI", 8), text="")
        self.lbl_3d.pack(side="left")
        ttk.Separator(right, orient="horizontal").pack(fill="x", pady=(0, 10))

        ttk.Label(right, text="Selected part - diffuse (s0)",
                  style="PanelText.TLabel").pack(anchor="w")
        self.preview = tk.Label(right, bg=PANEL, width=34, height=11,
                                text="pick a part", fg=MUTED)
        self.preview.pack(pady=(6, 8))
        self.lbl_lc = tk.Message(right, width=280, bg=PANEL, fg=TEXT,
                                 font=("Segoe UI", 9), text="")
        self.lbl_lc.pack(anchor="w")
        self.lbl_note = tk.Message(right, width=280, bg=PANEL, fg=WARN,
                                   font=("Segoe UI", 9, "bold"), text="")
        self.lbl_note.pack(anchor="w", pady=(8, 0))

        # --- buttons
        bar = ttk.Frame(self, padding=(16, 8, 16, 4))
        bar.pack(fill="x")
        self.b_export = ttk.Button(bar, text="2.  Export outfit as PNGs",
                                   command=self._export, style="Primary.TButton")
        self.b_export.pack(side="left")
        # TEK DUGME. Bir sure "Apply my design" + "Apply a shared design..." diye
        # ikiye ayrilmisti; iki dugme "hangisine basayim" sorusunu dogurdu. Simdi
        # tek is, tek davranis: bas, klasorunu sec. Kendi export'un da baskasinin
        # paylastigi tasarim da AYNI kapidan giriyor -- arac zaten ikisini de taniyor.
        self.b_apply = ttk.Button(bar, text="3.  Apply design",
                                  command=self._apply)
        self.b_apply.pack(side="left", padx=8)
        self.b_modek = ttk.Button(bar, text="Add a mod...",
                                  command=self._mod_ekle)
        self.b_modek.pack(side="left", padx=(0, 10))
        self.b_revert = ttk.Button(bar, text="Revert everything", command=self._revert)
        self.b_revert.pack(side="left", padx=8)
        ttk.Button(bar, text="Output folder", command=self._open_output).pack(side="right")

        # --- progress
        prog = ttk.Frame(self, padding=(16, 8, 16, 2))
        prog.pack(fill="x")
        self.pbar = ttk.Progressbar(prog, orient="horizontal", mode="determinate",
                                    maximum=100.0, style="OW.Horizontal.TProgressbar")
        self.pbar.pack(side="left", fill="x", expand=True)
        self.lbl_bar = ttk.Label(prog, text="", style="Muted.TLabel",
                                 width=40, anchor="w")
        self.lbl_bar.pack(side="left", padx=(12, 0))

        # --- log + status
        bottom = ttk.Frame(self, padding=(16, 4, 16, 12))
        bottom.pack(fill="both")
        self.log = tk.Text(bottom, height=6, bg=PANEL, fg=MUTED, bd=0,
                           font=("Consolas", 9), wrap="word", state="disabled",
                           padx=10, pady=8)
        self.log.pack(fill="both", expand=True)
        self.status = ttk.Label(self, text="ready", style="Muted.TLabel",
                                padding=(16, 0, 16, 8))
        self.status.pack(fill="x")

    # -------------------------------------------------------------- plumbing
    def write(self, text):
        """Ekrana VE log dosyasina. Tee'nin ekran ucu `write_gui`ye bagli oldugu
        icin print() ile gelenler burada tekrar dosyaya yazilmaz."""
        _TEE.to_file(text)
        self.queue.put(("log", str(text)))

    def write_gui(self, text):
        """Yalnizca ekran. Tee bunu kullanir: dosyaya zaten kendisi yaziyor."""
        self.queue.put(("log", str(text)))

    def _progress(self):
        """Callback handed to outfit_core: it takes plain text. We log it and,
        when the text carries an 'x/y' count (encode 3/12, export 40/60...), turn
        that into a real bar figure."""
        import re
        rx = re.compile(r"\b(\d+)\s*/\s*(\d+)\b")

        def cb(text):
            self.write(text)          # ekran + LOG DOSYASI
            m = rx.search(str(text))
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                if b:
                    self.queue.put(("bar", (100.0 * a / b, text)))
        return cb

    def _pump(self):
        try:
            while True:
                kind, data = self.queue.get_nowait()
                if kind == "log":
                    self.log.configure(state="normal")
                    self.log.insert("end", data + "\n")
                    self.log.see("end")
                    self.log.configure(state="disabled")
                    self.status.configure(text=data[:120])
                elif kind == "bar":
                    self._show(data[0], data[1])
                elif kind == "done":
                    self.busy = False
                    self.started = None
                    self._buttons(True)
                    self._refresh_patch_state()
                    self._show(100.0 if data else self.pbar["value"],
                               "done" if data else "stopped")
                elif kind == "preview":
                    mat_id, pil = data
                    from PIL import ImageTk
                    img = ImageTk.PhotoImage(pil)
                    self._prev_cache[mat_id] = img
                    if self.cur_mat and self.cur_mat["mat_id"] == mat_id:
                        self.preview_ref = img
                        self.preview.configure(image=img, text="",
                                               width=0, height=0)
                elif kind == "3d":
                    # PhotoImage UI thread'inde uretilir; isci thread PIL nesnesi
                    # gonderir. Bayat sonuc (kullanici hizli tikladi) ATILIR.
                    nesil, anahtar, pil, ozet = data
                    if nesil == self._3d_nesil:
                        if pil is None:
                            self._3d_metin(ozet or "no 3D preview for this outfit")
                            self.lbl_3d.configure(text="")
                        else:
                            from PIL import ImageTk
                            img = ImageTk.PhotoImage(pil)
                            self._3d_cache[anahtar] = img
                            if len(self._3d_cache) > 24:      # ~24 x 300px, kucuk
                                self._3d_cache.pop(next(iter(self._3d_cache)))
                            self._3d_goster(img, self.cur_3d["gorunen_ad"]
                                            if self.cur_3d else "", anahtar[1])
                            self.lbl_3d.configure(
                                text="%s  ·  %d°  ·  %s"
                                     % (self.cur_3d["gorunen_ad"] if self.cur_3d
                                        else "", anahtar[1], ozet))
                elif kind == "3dbuyuk":
                    # turntable karesi geldi (buyuk gorunum)
                    nesil, aci, pil, i, n = data
                    if nesil == getattr(self, "_buyuk_nesil", -1) and self._buyuk:
                        if pil is None:
                            self._buyuk_bilgi.configure(
                                text="3D preview unavailable  ·  Esc to close")
                        else:
                            from PIL import ImageTk
                            self._buyuk_kareler[aci] = ImageTk.PhotoImage(pil)
                            if len(self._buyuk_kareler) == 1 or aci == self._buyuk_aci:
                                self._3d_ciz_kare(self._buyuk_aci)
                            self._buyuk_bilgi.configure(
                                text=("drag to rotate  ·  Esc to close"
                                      if i >= n else
                                      "drag to rotate  ·  Esc to close  ·  "
                                      "preparing rotation %d/%d" % (i, n)))
                elif kind == "3dnet":
                    # fare birakildi, tam kalite kare
                    nesil, aci, pil = data
                    if (nesil == getattr(self, "_buyuk_nesil", -1) and self._buyuk
                            and pil is not None and aci == self._buyuk_aci
                            and not self._buyuk_surukle):
                        from PIL import ImageTk
                        img = ImageTk.PhotoImage(pil)
                        self._buyuk_lbl.configure(image=img)
                        self._buyuk_lbl.image = img
                elif kind == "modek":
                    nesil, sonuc, hata = data
                    if nesil == getattr(self, "_modek_nesil", -1):
                        if hata is not None:
                            messagebox.showerror("Add a mod",
                                "Matching failed:\n\n%s" % hata)
                        elif not sonuc:
                            messagebox.showinfo("Add a mod",
                                                "No files to match.")
                        else:
                            self._modek_panel(sonuc)
                elif kind == "lc":
                    mat_id, txt = data
                    if self.cur_mat and self.cur_mat["mat_id"] == mat_id:
                        self.lbl_lc.configure(text=txt)
                elif kind == "chryenile":
                    # karakter kur/kaldir bitti: KURULU rozeti tazelensin
                    if "Characters" in self.kategori.get():
                        self._fill_outfits()
                elif kind == "error":
                    # Diyaloglar "logu gonder" diyor ama iceriklerini loga hic
                    # yazmiyordu; gonderilen logda sebep bulunmuyordu.
                    _TEE.to_file("DIALOG(error): " + str(data))
                    messagebox.showerror("Error", data)
        except queue.Empty:
            pass
        except Exception:                                   # noqa: BLE001
            # The re-arm below used to sit outside this handler: one unexpected
            # exception here stopped the pump for good, so the window froze while
            # the worker thread carried on writing to the game archive - exactly
            # the state that makes a user force-quit mid-write.
            print("UI pump error (recovered):\n%s" % traceback.format_exc())
        finally:
            self.after(80, self._pump)

    def _show(self, value, label):
        self.pbar["value"] = value
        bits = ["%d%%" % int(value)]
        if label:
            bits.append(str(label)[:40])
        left = self._eta(value)
        if left:
            bits.append(left)
        self.lbl_bar.configure(text="   ".join(bits))

    def _eta(self, value):
        if not self.started or value < 10 or value >= 99.5:
            return ""
        spent = time.time() - self.started
        if spent < 5:
            return ""
        rem = int(spent * (100.0 - value) / value + 0.5)
        if rem < 5:
            return ""
        m, s = divmod(rem, 60)
        return "~%d:%02d left" % (m, s) if m else "~%d s left" % s

    def _buttons(self, enabled):
        state = "normal" if enabled else "disabled"
        for b in (self.b_export, self.b_apply, self.b_modek,
                  self.b_revert, self.b_game):
            b.configure(state=state)

    def _on_close(self):
        """Release the game archive on the way out, so Steam can update or verify
        the game the moment this window is gone."""
        # Yazma suruyorken kapatma. Isci thread daemon oldugu icin pencere yok
        # olunca yazici NEREDEYSE ORTASINDA olduruluyor; forge yamali kaliyor ve
        # kaydin anlatmadigi baytlar olusabiliyor.
        if self.busy:
            messagebox.showwarning(
                "Still working",
                "A job is still running and it is writing to the game archive.\n\n"
                "Closing now can leave the archive half-written. Please wait for it "
                "to finish - the log at the bottom shows where it is.")
            return
        try:
            C.release_forge()
        except Exception:
            traceback.print_exc()
        print("closing")
        self.destroy()

    def _run(self, fn):
        if self.busy:
            return
        self.busy = True
        self._buttons(False)
        self.started = time.time()
        self._show(0.0, "starting")

        def wrapper():
            ok = True
            try:
                fn()
            except Exception as e:
                ok = False
                self.write("ERROR: " + str(e))
                self.queue.put(("error", str(e)))
                traceback.print_exc()
            finally:
                # Let go of the game archive between jobs. Holding it open makes
                # Steam's "verify integrity of game files" and every game update
                # fail with "Content file locked", which reads to the user as a
                # Steam problem rather than as this tool still having the file.
                try:
                    C.release_forge()
                except Exception:
                    traceback.print_exc()
                # Onizleme/deri-kumas onbellekleri hicbir yerde bosaltilmiyordu:
                # Revert'ten sonra pencerede hala eski tasarim goruntuleniyordu.
                self._prev_cache.clear()
                self._lc_cache.clear()
                self.queue.put(("done", ok))

        threading.Thread(target=wrapper, daemon=True).start()

    # -------------------------------------------------------------- setup
    def _setup(self):
        os.makedirs(OUTPUT, exist_ok=True)
        if not os.path.isfile(os.path.join(C.TOOLS_DIR, "TexEncode.exe")):
            self.write("WARNING: TexEncode.exe not found in " + C.TOOLS_DIR +
                       " - export works, apply will not.")
        self._update_game_ui()
        self._refresh_patch_state()

    def _update_game_ui(self):
        """Reflect the current game/forge state in the top label and outfit list.
        If the game is not found the list stays empty and nothing reads the forge,
        so the app never crashes - the user just clicks 'Select game folder'."""
        if C.game_found():
            self.lbl_game.configure(text="forge OK: " + C.FORGE)
            self.write("Forge found (read-only): " + C.FORGE)
            self._fill_outfits()
        else:
            self.lbl_game.configure(
                text="Game NOT found - click 'Select game folder'")
            self.write("Game not found automatically. "
                       "Click 'Select game folder' (the folder with "
                       "DataPC_boot.forge).")
            for i in self.tree.get_children():
                self.tree.delete(i)

    def _pick_game(self):
        d = filedialog.askdirectory(
            title="Select the game folder (the one containing DataPC_boot.forge)")
        if not d:
            return
        # check_game, NOT find_game: what you picked is what you get. find_game used
        # to fall through to its own search when the pick was wrong, so this warning
        # could never appear and a second install could be bound behind your back.
        found = C.check_game(d) if hasattr(C, "check_game") else C.find_game(d)
        if not found:
            self.lbl_game.configure(
                text="No DataPC_boot.forge there - pick the game folder")
            self.write("That folder has no DataPC_boot.forge. "
                       "Pick the game folder that contains it.")
            messagebox.showwarning(
                "Game not found",
                "The selected folder does not contain DataPC_boot.forge.\n\n"
                "Pick the game's install folder, e.g. the one under\n"
                "Steam\\steamapps\\common or the Ubisoft games folder.")
            return
        try:
            C.set_game(found)
        except RuntimeError as e:                               # yazma suruyor
            messagebox.showwarning("Busy", str(e))
            return
        # Baska bir kuruluma gectik: onizlemeler artik eski oyunun pikselleri.
        self._prev_cache.clear()
        self._lc_cache.clear()
        self.write("Game folder set: " + found)
        self._update_game_ui()
        self._refresh_patch_state()

    def _portre(self, ad):
        """Liste portresi (52x52 PNG, paketle gelir). Yoksa bos string —
        Treeview bos gorseli sessizce yok sayar."""
        if not hasattr(self, "_portreler"):
            self._portreler = {}
        if ad in self._portreler:
            return self._portreler[ad]
        img = ""
        for kok in (os.path.join(HERE, "portreler"),
                    os.path.join(HERE, "..", "portreler")):
            yol = os.path.join(kok, ad + ".png")
            if os.path.isfile(yol):
                try:
                    img = tk.PhotoImage(file=yol)
                except Exception:                               # noqa: BLE001
                    img = ""
                break
        self._portreler[ad] = img
        return img

    def _liste_basliklari(self, kat):
        """Kolon basliklari kategoriye gore: profesyonel gorunumun yarisi
        dogru etiket."""
        if "Characters" in kat:
            b = ("Character", "Status", "Parts", "Costumes")
            self.lbl_pick.configure(text="1.  Pick a character")
        elif "Weapons" in kat:
            b = ("Weapon", "Safety", "Materials", "Paintable")
            self.lbl_pick.configure(text="1.  Pick a weapon")
        else:
            b = ("Outfit", "Safety", "Materials", "Paintable")
            self.lbl_pick.configure(text="1.  Pick an outfit")
        self.tree.heading("#0", text=b[0])
        self.tree.heading("safety", text=b[1])
        self.tree.heading("mats", text=b[2])
        self.tree.heading("slots", text=b[3])

    def _fill_outfits(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        kat = self.kategori.get() if hasattr(self, "kategori") else "Outfits"
        self._kategori_dugmeleri(kat)
        self._liste_basliklari(kat)
        # portresi olan kategoriler genis satir kullanir; silah listesi kompakt
        if "Weapons" in kat:
            self.tree.configure(style="Treeview", height=7)
        else:
            self.tree.configure(style="Liste.Treeview", height=5)
        if "Characters" in kat:
            # KARAKTER TAKASI: Kamzik mekanigi (kostum tablosu, tek girislik
            # patch_02). Liste roster'dan; "Install" oyun klasorune patch_02
            # yazar (onayli), "Remove" geri alir. Kiyafet boyamayla ILGISIZ,
            # o yuzden Export/Apply dugmeleri bu kategoride gizli.
            atamalar = self._chr_atamalar()
            slotu = {v["ad"]: s for s, v in atamalar.items()}
            try:
                import karakter_takas as KT
                for r in KT.roster():
                    s = slotu.get(r["ad"])
                    self.tree.insert(
                        "", "end", iid="chr:" + r["ad"],
                        text="  " + r.get("gorunen_ad", r["ad"]),
                        image=self._portre("CHR_" + r["ad"]),
                        values=(("INSTALLED · %s" % s.upper()) if s else "",
                                r.get("parca_sayisi", "-"),
                                len(r.get("kiyafetler", []) or []) or "-"),
                        tags=("KURULU" if s else "normal",))
                self.tree.tag_configure("KURULU", foreground=GOOD)
            except Exception as e:                              # noqa: BLE001
                print("character roster unavailable: %s" % e)
                self.tree.insert("", "end", iid="chr:yok",
                                 text="  character data missing", values=("-", "-", "-"),
                                 tags=("muted",))
            return
        silah = "Weapons" in kat
        for o in C.list_outfits():
            if (o.get("sinif") == "weapon") != silah:
                continue
            word, _col = safety_en(o["guvenlik_etiketi"])
            score = o["guvenlik_puani"]
            safety_txt = ("%s %.1f" % (word, score)) if score else word
            self.tree.insert(
                "", "end", iid=o["ad"], text="  " + o["gorunen_ad"],
                image="" if silah else self._portre(o["ad"]),
                values=(safety_txt,
                        o["materyal_sayisi"], o["boyanabilir_slot"]),
                tags=(o["guvenlik_etiketi"],))

    def _chr_atamalar(self):
        """Kurulu atamalar {slot: {"ad", "gorunen"}} (patch + sidecar birlikte
        varsa). Eski tek-karakter kaydi Whaler atamasi olarak okunur."""
        try:
            import json as _json
            if not os.path.exists(self._chr_patch_yolu()):
                return {}
            with open(self._chr_durum_dosyasi(), encoding="utf-8") as f:
                d = _json.load(f)
            if "atamalar" in d:
                return d["atamalar"]
            if d.get("karakter"):                    # v0.7 tek-karakter kaydi
                return {"Whaler": {"ad": d["karakter"],
                                   "gorunen": d.get("gorunen", d["karakter"])}}
        except Exception:                                       # noqa: BLE001
            pass
        return {}

    def _chr_kurulu_ad(self):
        """Geriye donuk: kurulu karakter adlarinin kumesi."""
        return {v["ad"] for v in self._chr_atamalar().values()}

    def _refresh_patch_state(self):
        patched = os.path.exists(C.DE.KAYIT)
        if patched:
            self.b_revert.configure(text="Revert everything  (active)")
        else:
            self.b_revert.configure(text="Revert everything")

    # -------------------------------------------------------------- selection
    # ------------------------------------------------------------------ 3D onizleme
    # BUYUK GORUNUM: kucuk onizlemeye tiklayinca tam ekran acilir ve karakter
    # FAREYLE SURUKLENEREK dondurulur.
    #
    # ⚠️ Neden "donen kareler" ve canli render DEGIL: render maliyeti OLCULDU --
    #    512 px ssaa=1 -> 0,21 sn · ssaa=2 -> 0,55 sn · 256 px -> 0,10 sn.
    #    Yani surukleme sirasinda kare basina render IMKANSIZ (5 fps bile degil).
    #    Cozum: 24 karelik turntable (15 derecelik adimlar) ARKA PLANDA hazirlanir
    #    (24 x 0,21 = ~5 sn), surukleme hazir kareler arasinda gezinir (anlik),
    #    fare BIRAKILINCA o aci TAM KALITEDE (ssaa=2) yeniden cizilir.
    _3D_ADIM = 15                    # derece / kare  -> 24 kare
    _3D_KARE_BOYUT = 512             # turntable kare boyu (surukleme kalitesi)

    def _3d_buyut(self, _e=None):
        o = getattr(self, "cur_3d", None)
        if not o or self.v3d_ref is None:
            return                                   # daha render olmadi
        if getattr(self, "_buyuk", None) is not None:
            try:
                self._buyuk.destroy()
            except Exception:                        # noqa: BLE001
                pass
        ust = tk.Toplevel(self)
        self._buyuk = ust
        ust.title("%s - 3D preview" % o["gorunen_ad"])
        ust.configure(bg=BG)
        ust.attributes("-fullscreen", True)
        ust.bind("<Escape>", lambda _e: self._3d_kapat())
        ust.protocol("WM_DELETE_WINDOW", self._3d_kapat)

        eh = ust.winfo_screenheight()
        self._buyuk_olcu = max(360, min(eh - 150, 900))
        self._buyuk_lbl = tk.Label(ust, bg=BG)
        self._buyuk_lbl.pack(expand=True)
        self._buyuk_bilgi = tk.Label(
            ust, bg=BG, fg=MUTED, font=("Segoe UI", 10),
            text="drag to rotate  ·  Esc to close  ·  preparing rotation...")
        self._buyuk_bilgi.pack(side="bottom", pady=14)

        self._buyuk_kareler = {}                     # aci -> PhotoImage
        self._buyuk_aci = getattr(self, "_3d_aci", 0)
        self._buyuk_nesil = getattr(self, "_buyuk_nesil", 0) + 1
        self._buyuk_surukle = None
        for olay, islev in (("<Button-1>", self._3d_surukle_bas),
                            ("<B1-Motion>", self._3d_surukle),
                            ("<ButtonRelease-1>", self._3d_surukle_birak)):
            self._buyuk_lbl.bind(olay, islev)
        self._buyuk_lbl.configure(cursor="fleur")
        # elde ne varsa HEMEN goster (kucuk onizleme karesi buyutulur), sonra
        # turntable arka planda dolar
        self._buyuk_ciz(self._buyuk_aci)
        self._3d_turntable_baslat()

    def _3d_kapat(self):
        self._buyuk_nesil = getattr(self, "_buyuk_nesil", 0) + 1   # gelen kareleri at
        try:
            if self._buyuk is not None:
                self._buyuk.destroy()
        except Exception:                                          # noqa: BLE001
            pass
        self._buyuk = None
        self._buyuk_kareler = {}

    def _3d_turntable_baslat(self):
        o = self.cur_3d
        nesil = self._buyuk_nesil
        ad, aci0 = o["ad"], self._buyuk_aci
        ust_yazim_imza = self._3d_boya_imzasi(ad)

        def is_():
            try:
                import onizleme3d as O3
                from PIL import Image
                ust = {}
                try:
                    kaynak = C._design_kaynak(os.path.join(OUTPUT, ad))
                    adaylar, _t = C._design_adaylari(kaynak)
                    for png, mat_id, slot, _cs in adaylar:
                        if slot == 0:
                            ust[mat_id] = Image.open(png).convert("RGB")
                except Exception:                                  # noqa: BLE001
                    ust = {}
                # once BULUNULAN aciyi, sonra oradan iki yone dogru yay: kullanici
                # hangi yone cevirirse cevirsin ilk kareler hazir olsun
                acilar = sorted(range(0, 360, self._3D_ADIM),
                                key=lambda a: min((a - aci0) % 360, (aci0 - a) % 360))
                # `Oturum` mesh/doku onbellegini kareler arasinda SICAK tutuyor:
                # olculdu, kare basina 0,62 -> 0,32 sn (1,9x). Bedeli forge
                # taniticisinin bu patlama boyunca acik kalmasi; `finally` ile
                # GARANTILI kapatiyoruz (Steam "Content file locked" dersi).
                otr = O3.Oturum()
                try:
                    for i, a in enumerate(acilar):
                        if nesil != self._buyuk_nesil:
                            return                                 # pencere kapandi
                        pil = otr.render(ad, doku_ust_yazim=ust or None, aci=a,
                                         boyut=self._3D_KARE_BOYUT, ssaa=1)
                        self.queue.put(("3dbuyuk", (nesil, a, pil, i + 1, len(acilar))))
                finally:
                    try:
                        otr.kapat()
                    except Exception:                              # noqa: BLE001
                        pass
            except Exception as e:                                 # noqa: BLE001
                print("3D turntable failed: %s" % e)
                self.queue.put(("3dbuyuk", (nesil, None, None, 0, 0)))
        _ = ust_yazim_imza
        threading.Thread(target=is_, daemon=True).start()

    def _3d_en_yakin(self, aci):
        if not self._buyuk_kareler:
            return None
        return min(self._buyuk_kareler,
                   key=lambda a: min((a - aci) % 360, (aci - a) % 360))

    def _3d_ciz_kare(self, aci):
        k = self._3d_en_yakin(aci)
        if k is None:
            return
        self._buyuk_lbl.configure(image=self._buyuk_kareler[k])
        self._buyuk_lbl.image = self._buyuk_kareler[k]

    def _3d_surukle_bas(self, e):
        self._buyuk_surukle = (e.x_root, self._buyuk_aci)

    def _3d_surukle(self, e):
        if not self._buyuk_surukle:
            return
        x0, a0 = self._buyuk_surukle
        # 2 piksel = 1 derece -> 720 px'lik surukleme tam tur
        self._buyuk_aci = int(a0 + (e.x_root - x0) * 0.5) % 360
        self._3d_ciz_kare(self._buyuk_aci)
        self._buyuk_bilgi.configure(
            text="%d°  ·  drag to rotate  ·  Esc to close" % self._buyuk_aci)

    def _3d_surukle_birak(self, _e=None):
        """Fare birakildi: O ACIYI tam kalitede (ssaa=2) yeniden ciz."""
        self._buyuk_surukle = None
        if self._buyuk is None:
            return
        o, nesil, aci = self.cur_3d, self._buyuk_nesil, self._buyuk_aci
        olcu = self._buyuk_olcu

        def is_():
            try:
                import onizleme3d as O3
                from PIL import Image
                ust = {}
                try:
                    kaynak = C._design_kaynak(os.path.join(OUTPUT, o["ad"]))
                    adaylar, _t = C._design_adaylari(kaynak)
                    for png, mat_id, slot, _cs in adaylar:
                        if slot == 0:
                            ust[mat_id] = Image.open(png).convert("RGB")
                except Exception:                                  # noqa: BLE001
                    ust = {}
                pil = O3.kiyafet_render(o["ad"], doku_ust_yazim=ust or None,
                                        aci=aci, boyut=olcu, ssaa=2)
                try:
                    O3._kapat()
                except Exception:                                  # noqa: BLE001
                    pass
                self.queue.put(("3dnet", (nesil, aci, pil)))
            except Exception as e:                                 # noqa: BLE001
                print("3D sharpen failed: %s" % e)
        threading.Thread(target=is_, daemon=True).start()

    def _buyuk_ciz(self, aci):
        """Buyuk pencere ilk acilirken: kucuk onizleme karesini buyuterek goster."""
        try:
            from PIL import ImageTk
            k = self._3d_cache.get((self.cur_3d["ad"], aci,
                                    self._3d_boya_imzasi(self.cur_3d["ad"])))
            if k is not None:
                self._buyuk_lbl.configure(image=k)
                self._buyuk_lbl.image = k
            _ = ImageTk
        except Exception:                                          # noqa: BLE001
            pass

    def _3d_boya_imzasi(self, ad):
        """Kullanicinin BOYADIGI dosyalarin ucuz parmak izi (yol+mtime+boy).
        Onbellek anahtarina girer: boyayip geri gelince onizleme TAZELENIR."""
        klasor = os.path.join(OUTPUT, ad)
        if not os.path.isdir(klasor):
            return ()
        try:
            imza = []
            for png in sorted(glob.glob(os.path.join(klasor, "**", "*.png"),
                                        recursive=True)):
                st = os.stat(png)
                imza.append((os.path.basename(png), int(st.st_mtime), st.st_size))
            return tuple(imza)
        except OSError:
            return ()

    def _3d_yenile(self):
        """Secili kiyafeti/karakteri arka planda render eder. Arsive YAZMAZ, bu
        yuzden `busy`/dugme kilidi KULLANMAZ -- kullanici calismaya devam eder."""
        o = getattr(self, "cur_3d", None)
        if not o:
            return
        aci = getattr(self, "_3d_aci", 0)
        anahtar = (o["ad"], aci, self._3d_boya_imzasi(o["ad"]))
        if anahtar in self._3d_cache:
            img = self._3d_cache[anahtar]
            self._3d_goster(img, o["gorunen_ad"], aci)
            return
        self._3d_nesil += 1
        nesil = self._3d_nesil
        self._3d_metin("rendering...")
        self.lbl_3d.configure(text="")

        def is_():
            pil, ozet = None, ""
            try:
                from PIL import Image
                # Ic aktarim: modul yoksa/bozuksa 3D paneli sessizce devre disi
                # kalir, ARAC ACILIR. (D3 dersi: import aninda olen arac.)
                import onizleme3d as O3
                ust = {}
                try:
                    kaynak = C._design_kaynak(os.path.join(OUTPUT, o["ad"]))
                    adaylar, _t = C._design_adaylari(kaynak)
                    for png, mat_id, slot, _cs in adaylar:
                        if slot == 0:
                            ust[mat_id] = Image.open(png).convert("RGB")
                except Exception:                            # noqa: BLE001
                    ust = {}                                 # boya yoksa vanilla
                olcum = {}
                pil = O3.kiyafet_render(o["ad"], doku_ust_yazim=ust or None,
                                        aci=aci, boyut=240, olcum=olcum)
                if pil is not None:
                    ozet = "%d parts%s" % (olcum.get("parca", 0),
                                           "  ·  %d painted" % len(ust) if ust else "")
                try:
                    O3._kapat()          # forge taniticisini birakma disiplini
                except Exception:        # noqa: BLE001
                    pass
            except Exception as e:                           # noqa: BLE001
                print("3D preview failed: %s" % e)
                ozet = "3D preview unavailable"
            self.queue.put(("3d", (nesil, anahtar, pil, ozet)))

        threading.Thread(target=is_, daemon=True).start()

    def _3d_goster(self, img, ad, aci):
        # ⚠️ Tk tuzagi: bir Label'da `width`/`height` METIN varken KARAKTER,
        # GORUNTU varken PIKSEL olarak yorumlanir. Kurulumdaki "width=34,
        # height=10" (karakter) goruntu konunca 34x10 PIKSEL'e donusuyor ve
        # render minicik bir serit halinde kirpiliyordu (ekran goruntusuyle
        # goruldu). Goruntu koyarken olcuyu SIFIRLA -> etiket goruntuye uyar.
        self.v3d_ref = img
        self.v3d.configure(image=img, text="", width=0, height=0)
        self.lbl_3d.configure(text="%s  ·  click to enlarge" % ad)

    def _3d_metin(self, metin):
        """Goruntu yerine metin gosterirken KARAKTER olcusunu geri koy."""
        self.v3d_ref = None
        self.v3d.configure(image="", text=metin)

    def _outfit_changed(self, _e=None):
        sel = self.tree.selection()
        if not sel:
            return
        if sel[0].startswith("chr:"):
            # karakter: boyama akisi yok; panelde kiyafet aileleri gosterilir
            self.cur_outfit = None
            self.cur_mat = None
            self.cur_3d = None
            for i in self.parts.get_children():
                self.parts.delete(i)
            try:
                import karakter_takas as KT
                r = next(x for x in KT.roster() if x["ad"] == sel[0][4:])
                for kiy in (r.get("kiyafetler") or ["BASE"]):
                    self.parts.insert("", "end", iid="chrk:" + str(kiy),
                                      text="  costume: %s" % kiy,
                                      values=("-", "-", "-"), tags=("muted",))
                # 3D onizleme: pisirilmis CHR_ indeks girisi kiyafetlerle ayni
                # hattan cizilir (indekste yoksa panel zarifce metne duser)
                self.cur_3d = {"ad": "CHR_" + r["ad"],
                               "gorunen_ad": r["gorunen_ad"]}
            except Exception:                                   # noqa: BLE001
                pass
            self._3d_aci = 0
            if self.cur_3d is not None:
                self._3d_yenile()
            else:
                self._3d_metin("no 3D preview for this character")
                self.lbl_3d.configure(text="")
            self.preview.configure(image="", text="character swap",
                                   width=34, height=11)
            self.preview_ref = None
            secili_ad = sel[0][4:]
            atama = {v["ad"]: s for s, v in self._chr_atamalar().items()}
            if secili_ad in atama:
                self.lbl_lc.configure(
                    text="Installed - equip the %s outfit in game to become "
                         "this character." % atama[secili_ad].upper())
            else:
                self.lbl_lc.configure(
                    text="Click 'Install character...' and pick which outfit "
                         "becomes this character.")
            self.lbl_note.configure(text="")
            return
        o = C.get_outfit(sel[0])
        self.cur_outfit = o
        self.cur_3d = o
        self.cur_mat = None
        self._3d_aci = 0
        self._3d_yenile()
        self.preview.configure(image="", text="pick a part", width=34, height=11)
        self.preview_ref = None
        self.lbl_lc.configure(text="")
        self.lbl_note.configure(text="")
        for i in self.parts.get_children():
            self.parts.delete(i)
        for m in C.outfit_materials(o):
            if m.get("dokusuz"):
                self.parts.insert("", "end", iid=m["mat_id"],
                                  text="  " + m.get("parca_adi", m["mat_id"]),
                                  values=("-", "no texture", "-"),
                                  tags=("muted",))
                continue
            paint = sum(1 for s in m["slotlar"] if s["duzenlenebilir"])
            share = m.get("paylasim", {}).get("renk", "YESIL")
            word, _c = safety_en(share)
            self.parts.insert(
                "", "end", iid=m["mat_id"],
                text="  " + m.get("parca_adi", m["mat_id"]),
                values=(word, "%d slots (%d paint)" % (len(m["slotlar"]), paint),
                        scope_en(m)),
                tags=(share,))

    def _part_changed(self, _e=None):
        sel = self.parts.selection()
        if not sel or not self.cur_outfit:
            return
        mat_id = sel[0]
        m = next((x for x in C.outfit_materials(self.cur_outfit)
                  if x["mat_id"] == mat_id), None)
        if m is None:
            return
        self.cur_mat = m
        self.lbl_note.configure(text=affected_names_en(m))
        if m.get("dokusuz"):
            self.preview.configure(image="", text="no texture", width=34, height=11)
            self.preview_ref = None
            self.lbl_lc.configure(text="This part has no texture to paint.")
            return
        # cached?
        if mat_id in self._prev_cache:
            self.preview_ref = self._prev_cache[mat_id]
            self.preview.configure(image=self.preview_ref, text="",
                                   width=0, height=0)
        else:
            self.preview.configure(image="", text="loading...", width=34, height=11)
            self.preview_ref = None
        self.lbl_lc.configure(text=self._lc_cache.get(mat_id, "reading surface..."))
        # decode in the background (read-only forge access)
        threading.Thread(target=self._decode_preview, args=(m,), daemon=True).start()

    def _decode_preview(self, m):
        mat_id = m["mat_id"]
        try:
            from PIL import Image, ImageTk
            Image.MAX_IMAGE_PIXELS = None
            if mat_id not in self._prev_cache:
                s0 = next((s for s in m["slotlar"] if s["idx"] == 0), None)
                if s0 is not None:
                    data, _tanim = C.slot_mip0_bc(mat_id, 0)
                    if data is not None:
                        W, H, aile = s0["W"], s0["H"], s0["aile"]
                        arr = C._bc_decode_rgba(data, W, H, C._AILE_ENUM[aile])
                        im = Image.fromarray(arr[..., :3])
                        im.thumbnail((280, 280))
                        # ⚠️ PhotoImage BURADA URETILMEZ: Tk nesneleri isci
                        # thread'inde guvenilir degil ("main thread is not in
                        # main loop" istisnasi yutulup onizleme sonsuza kadar
                        # "loading..." kaliyordu — buyuk turda olculdu).
                        # PIL nesnesi gonderilir; PhotoImage _pump'ta (UI) dogar.
                        self.queue.put(("preview", (mat_id, im)))
            if mat_id not in self._lc_cache:
                s3 = next((s for s in m["slotlar"] if s["idx"] == 3), None)
                if s3 is not None:
                    data, _t = C.slot_mip0_bc(mat_id, 3)
                    if data is not None:
                        arr = C._bc_decode_rgba(data, s3["W"], s3["H"],
                                                C._AILE_ENUM[s3["aile"]])
                        lc = C._leather_or_cloth(arr[..., 3])
                        txt = "Surface (s3 normal): %s  -  leather %d%%, cloth %d%%" % (
                            lc["tur"], lc["deri_yuzde"], lc["kumas_yuzde"])
                        self._lc_cache[mat_id] = txt
                        self.queue.put(("lc", (mat_id, txt)))
                else:
                    self._lc_cache[mat_id] = "No normal slot (s3) on this part."
                    self.queue.put(("lc", (mat_id, self._lc_cache[mat_id])))
        except Exception as e:
            self.queue.put(("lc", (mat_id, "preview failed: %s" % e)))

    # -------------------------------------------------------------- actions
    def _selected_outfit(self):
        if not self.cur_outfit:
            messagebox.showinfo("Pick an outfit", "Select an outfit from the list first.")
            return None
        return self.cur_outfit

    def _export(self):
        o = self._selected_outfit()
        if not o:
            return

        def job():
            rep = self._progress()
            self.write("- exporting %s ..." % o["gorunen_ad"])
            # 🩹 SAHA (ViviiD7, 2026-08-05): "error because its not creating the
            # folder when extracting png". Kodda her klasor makedirs ile kuruluyor;
            # bunun bilinen sebebi Windows'un 'Denetimli klasor erisimi' (ransomware
            # korumasi) ya da OneDrive'in Documents'i kilitlemesi -- taninmayan exe
            # Documents'a YAZAMIYOR. Genel hata "[WinError 5]" gibi cikiyordu;
            # simdi sebebi ve cozumu ADIYLA soyluyoruz.
            try:
                os.makedirs(OUTPUT, exist_ok=True)
                _probe = os.path.join(OUTPUT, ".yazma_testi.tmp")
                open(_probe, "w").close()
                os.remove(_probe)
            except (PermissionError, OSError) as e:
                self.write("EXPORT BLOCKED: cannot write to %s (%s)" % (OUTPUT, e))
                self.queue.put(("error",
                    "Windows is blocking this app from writing to your Documents "
                    "folder:\n\n%s\n\nThis is usually 'Controlled folder access' "
                    "(Windows Security > Virus & threat protection > Ransomware "
                    "protection) or OneDrive. Either allow OutfitWorkshop there, "
                    "or turn the setting off, then export again.\n\n"
                    "Nothing was exported." % OUTPUT))
                return
            res = C.export_outfit(o, OUTPUT, progress=rep)
            self.write("DONE -> " + res["klasor"])
            self.write("%d PNGs written, %d skipped." %
                       (len(res["yazilan"]), len(res["atlanan"])))
            self.write("Paint the PNGs inside the EDIT folder (s0 colour, s3 surface).")
            self.write("Do NOT touch _reference_do_not_edit. Keep sizes exactly as they are.")
            self.write("Then use '3. Apply design' and pick this outfit folder.")
            try:
                os.startfile(res["klasor"])
            except Exception:
                pass

        self._run(job)



    # ------------------------------------------------- CHARACTERS (beta)
    def _kategori_dugmeleri(self, kat):
        """Kategoriye uymayan dugmeleri gizle: karakter takasinda Export/Apply
        anlamsiz (boyama yok); kiyafet/silahta Install/Remove anlamsiz."""
        karakter = "Characters" in kat
        if karakter:
            for b in (self.b_export, self.b_apply, self.b_modek):
                b.pack_forget()
        else:
            # ozgun sira: export, apply, modek — sabit capa b_revert'in ONUNE,
            # her seferinde ayni sirayla (Tk 'before' sabit widget ister; kosullu
            # None gecirmek TclError uretir, o yuzden hepsi topluca yeniden).
            for b in (self.b_export, self.b_apply, self.b_modek):
                b.pack_forget()
            for b in (self.b_export, self.b_apply, self.b_modek):
                b.pack(side="left", padx=(0, 10), before=self.b_revert)
        if not hasattr(self, "b_chr_install"):
            self.b_chr_install = ttk.Button(self.b_export.master,
                                            text="Install character...",
                                            command=self._chr_install)
            self.b_chr_remove = ttk.Button(self.b_export.master,
                                           text="Remove installed character",
                                           command=self._chr_remove)
        if karakter:
            self.b_chr_install.pack(side="left", padx=(0, 10))
            self.b_chr_remove.pack(side="left", padx=(0, 10))
        else:
            self.b_chr_install.pack_forget()
            self.b_chr_remove.pack_forget()

    def _chr_patch_yolu(self):
        import os as _os
        return _os.path.join(_os.path.dirname(C.DE.FORGE),
                             "DataPC_boot_patch_02.forge")

    def _chr_durum_dosyasi(self):
        return os.path.join(LOG_DIR, "..", "charswap.json")

    def _chr_slot_sec(self, gorunen):
        """Slot secim diyalogu: bu karakter HANGI kiyafeti giyince gelsin?
        Doner: slot adi ya da None (vazgecildi). Testler bu metodu monkeypatch
        eder (diyalogsuz surus)."""
        import karakter_takas as KT
        slotlar = KT.hedef_slotlar()
        atamalar = self._chr_atamalar()

        d = tk.Toplevel(self)
        d.title("Install character")
        d.configure(bg=BG)
        d.transient(self); d.grab_set(); d.resizable(False, False)
        ttk.Label(d, text="Play as %s" % gorunen,
                  font=("Segoe UI", 12, "bold")).pack(padx=18, pady=(16, 4))
        ttk.Label(d, style="Muted.TLabel", wraplength=380, justify="left",
                  text="Pick which outfit becomes this character. In game, "
                       "equip that outfit to transform. You can install a "
                       "different character on each outfit slot.").pack(
            padx=18, pady=(0, 10))
        sec = tk.StringVar(value=slotlar[0])
        kutu = ttk.Combobox(d, textvariable=sec, state="readonly",
                            values=slotlar, width=30)
        kutu.pack(padx=18)
        durum = ttk.Label(d, style="Muted.TLabel", text="")
        durum.pack(padx=18, pady=(6, 0))

        def _g(*_a):
            v = atamalar.get(sec.get())
            durum.configure(text=("currently: %s  (will be replaced)"
                                  % v["gorunen"]) if v else "slot is free")
        kutu.bind("<<ComboboxSelected>>", _g); _g()
        sonuc = [None]
        alt = ttk.Frame(d); alt.pack(pady=14)

        def tamam():
            sonuc[0] = sec.get(); d.destroy()
        ttk.Button(alt, text="Install", style="Primary.TButton",
                   command=tamam).pack(side="left", padx=6)
        ttk.Button(alt, text="Cancel", command=d.destroy).pack(side="left")
        d.bind("<Return>", lambda _e: tamam())
        d.bind("<Escape>", lambda _e: d.destroy())
        d.wait_window()
        return sonuc[0]

    def _chr_install(self):
        sel = self.tree.selection()
        if not sel or not sel[0].startswith("chr:"):
            messagebox.showinfo("Install character",
                                "Pick a character from the list first.")
            return
        ad = sel[0][4:]
        gorunen = self.tree.item(sel[0])["text"].strip()
        slot = self._chr_slot_sec(gorunen)
        if not slot:
            return
        if not self._game_closed():
            return
        atamalar = dict(self._chr_atamalar())
        atamalar[slot] = {"ad": ad, "gorunen": gorunen}

        def job():
            import karakter_takas as KT
            import tempfile as _tf
            self.write("- generating character swap: %s -> %s ..." % (slot, gorunen))
            tmp = os.path.join(_tf.gettempdir(),
                               "OutfitWorkshop_chr_%d.forge" % os.getpid())
            if len(atamalar) == 1:
                rapor = KT.uret(ad, os.path.dirname(C.DE.FORGE), tmp,
                                slotlar=(slot,))
            else:
                rapor = KT.uret_coklu({s: v["ad"] for s, v in atamalar.items()},
                                      os.path.dirname(C.DE.FORGE), tmp)
            if not rapor.get("ok", True):
                self.queue.put(("error", "Character generation failed:\n%s"
                                % rapor.get("sebep", "unknown")))
                return
            hedef2 = self._chr_patch_yolu()
            bizim = bool(self._chr_atamalar())      # sidecar'li patch = bizim
            if os.path.exists(hedef2) and not bizim \
                    and not os.path.exists(hedef2 + ".charswap_bak"):
                shutil.move(hedef2, hedef2 + ".charswap_bak")
                self.write("  existing patch_02 backed up (.charswap_bak)")
            shutil.copy2(tmp, hedef2)
            try:
                import json as _json
                with open(self._chr_durum_dosyasi(), "w", encoding="utf-8") as f:
                    _json.dump({"atamalar": atamalar}, f)
            except Exception:                                   # noqa: BLE001
                pass
            self.write("SUCCESS: %s installed on the %s outfit." % (gorunen, slot))
            for s, v in sorted(atamalar.items()):
                self.write("  equip %s in game  ->  play as %s" % (s.upper(), v["gorunen"]))
            self.write("Use 'Remove installed character' to undo.")
            self.queue.put(("chryenile", None))

        self._run(job)

    def _chr_remove(self):
        hedef = self._chr_patch_yolu()
        if not os.path.exists(hedef):
            messagebox.showinfo("Remove character",
                                "No character swap is installed (no patch_02).")
            return
        atamalar = self._chr_atamalar()
        liste = "\n".join("  %s  ->  %s" % (s.upper(), v["gorunen"])
                          for s, v in sorted(atamalar.items())) or "  (unknown)"
        if not messagebox.askyesno(
                "Remove characters",
                "Remove ALL installed characters?\n\n%s\n\nIf another mod's "
                "patch_02 was backed up, it will be restored." % liste):
            return
        if not self._game_closed():
            return

        def job():
            os.remove(hedef)
            if os.path.exists(hedef + ".charswap_bak"):
                shutil.move(hedef + ".charswap_bak", hedef)
                self.write("Removed; previous patch_02 restored from backup.")
            else:
                self.write("Removed; game is back to no patch_02.")
            try:
                os.remove(self._chr_durum_dosyasi())
            except OSError:
                pass
            self.queue.put(("chryenile", None))

        self._run(job)

    # ------------------------------------------------------------ ADD A MOD
    # Topluluk tasarimlari cogu kez ADI BOZUK PNG yiginlari olarak dolasiyor
    # (tarayici "(1)" ekleri, elle yeniden adlandirma). Eslestirme ICERIKTEN:
    # vanilla parmak izi indeksi (dHash + boyut) ile dosyanin hangi kiyafetin
    # hangi slotu oldugu, OLCULMUS esiklerle bulunur (dogruluk_raporu.md).
    # GUVENLIK: dusuk guvende OTOMATIK UYGULAMA YOK -- aday listesi gosterilir;
    # alakasiz goruntu reddedilir (yanlis kiyafete yazmak en kotu sonuc).
    def _mod_ekle(self):
        dosyalar = filedialog.askopenfilenames(
            title="Pick the mod's PNG files (names may be broken)",
            filetypes=[("PNG textures", "*.png"), ("All files", "*.*")])
        if not dosyalar:
            return
        self.write("- matching %d file(s) by CONTENT..." % len(dosyalar))
        nesil = getattr(self, "_modek_nesil", 0) + 1
        self._modek_nesil = nesil

        def is_():
            try:
                import eslestir as ES
                sonuc = ES.eslestir(list(dosyalar))
                self.queue.put(("modek", (nesil, sonuc, None)))
            except Exception as e:                              # noqa: BLE001
                print("mod matching failed:")
                print(traceback.format_exc())
                self.queue.put(("modek", (nesil, None, str(e))))
        threading.Thread(target=is_, daemon=True).start()

    def _modek_panel(self, sonuc):
        """Eslestirme sonuclari ONAY ekraninda; onaylaninca dosyalar dogru slot
        adlariyla gecici klasore kopyalanip STANDART apply kapisindan
        (_apply_klasoru) gecer -- kural kopyasi yok."""
        ust = tk.Toplevel(self)
        ust.title("Add a mod - review matches")
        ust.configure(bg=BG)
        ust.geometry("860x480")
        ust.transient(self)
        tk.Label(ust, bg=BG, fg=TEXT, font=("Segoe UI", 10, "bold"),
                 text="Matched by content. Check each row; nothing is applied "
                      "until you press Apply.").pack(anchor="w", padx=12, pady=(10, 4))
        cols = ("hedef", "guven", "durum")
        tv = ttk.Treeview(ust, columns=cols, show="tree headings", height=12)
        tv.heading("#0", text="File"); tv.column("#0", width=250)
        tv.heading("hedef", text="Detected outfit / part / slot")
        tv.column("hedef", width=330)
        tv.heading("guven", text="Confidence"); tv.column("guven", width=90, anchor="center")
        tv.heading("durum", text="Status"); tv.column("durum", width=120)
        tv.pack(fill="both", expand=True, padx=12)

        secimler = {}

        def hedef_metni(y):
            return "%s  -  %s  -  s%d" % (y.get("gorunen_ad", y["kiyafet"]),
                                          y.get("parca_adi", y["mat_id"]),
                                          y["slot_idx"])

        for e in sonuc:
            ad = os.path.basename(e.png)
            if e.durum == "otomatik":
                y = None
                for g in e.aday_listesi:
                    for s_ in g["slotlar"]:
                        if s_["mat_id"] == e.mat_id and s_["slot_idx"] == e.slot:
                            y = s_
                            break
                    if y:
                        break
                iid = tv.insert("", "end", text="  " + ad,
                                values=(hedef_metni(y) if y else
                                        "%s s%d" % (e.mat_id, e.slot),
                                        "%.0f%%" % (e.guven * 100), "auto"))
                secimler[iid] = (e, y or {"mat_id": e.mat_id, "slot_idx": e.slot})
            elif e.durum == "aday":
                iid = tv.insert("", "end", text="  " + ad,
                                values=("double-click to choose (%d candidates)"
                                        % len(e.aday_listesi),
                                        "%.0f%%" % (e.guven * 100), "pick one"))
                secimler[iid] = (e, None)
            else:
                iid = tv.insert("", "end", text="  " + ad,
                                values=("-", "%.0f%%" % (e.guven * 100),
                                        "no match" if e.durum == "eslesme_yok"
                                        else "unreadable"))
                secimler[iid] = (e, None)

        def sec(_ev=None):
            iid = tv.focus()
            if not iid:
                return
            e, _y = secimler.get(iid, (None, None))
            if not e or e.durum not in ("aday", "otomatik"):
                return
            alt = tk.Toplevel(ust); alt.title("Choose the target slot")
            alt.configure(bg=BG); alt.transient(ust)
            lb = tk.Listbox(alt, width=64, height=14, bg=PANEL, fg=TEXT)
            lb.pack(padx=10, pady=10)
            duz = []
            for g in e.aday_listesi:
                for s_ in g["slotlar"]:
                    if s_["duzenlenebilir"]:
                        duz.append((g["skor"], s_))
                        lb.insert("end", "%.0f%%  %s"
                                  % (g["skor"] * 100, hedef_metni(s_)))

            def onay(_e2=None):
                i = lb.curselection()
                if i:
                    secimler[iid] = (e, duz[i[0]][1])
                    tv.set(iid, "hedef", hedef_metni(duz[i[0]][1]))
                    tv.set(iid, "durum", "picked")
                alt.destroy()
            lb.bind("<Double-Button-1>", onay)
            ttk.Button(alt, text="Use this slot", command=onay).pack(pady=(0, 10))
        tv.bind("<Double-Button-1>", sec)

        altbar = ttk.Frame(ust, padding=(12, 8))
        altbar.pack(fill="x")

        def uygula():
            hazir = [(e, y) for e, y in secimler.values() if y]
            if not hazir:
                messagebox.showinfo("Add a mod",
                                    "No file has a confirmed target yet.",
                                    parent=ust)
                return
            sahne = os.path.join(tempfile.gettempdir(),
                                 "OutfitWorkshop_mod_%d" % os.getpid())
            if os.path.isdir(sahne):
                shutil.rmtree(sahne, ignore_errors=True)
            os.makedirs(sahne)
            kopyalanan = 0
            for e, y in hazir:
                cs = C._catalog_slot(y["mat_id"], y["slot_idx"])
                if not cs:
                    self.write("  skipped (not in catalogue): %s"
                               % os.path.basename(e.png))
                    continue
                fn = C._slot_filename(y["mat_id"], y["slot_idx"],
                                      cs["W"], cs["H"], cs["aile"])
                shutil.copy2(e.png, os.path.join(sahne, fn))
                kopyalanan += 1
            if not kopyalanan:
                messagebox.showerror("Add a mod",
                                     "None of the confirmed files exist in the "
                                     "catalogue.", parent=ust)
                return
            ust.destroy()
            self.write("- staged %d matched file(s); applying through the normal "
                       "safety gates..." % kopyalanan)
            self._apply_klasoru(sahne,
                                etiket="imported mod (%d files)" % kopyalanan)
        ttk.Button(altbar, text="Apply confirmed files",
                   command=uygula).pack(side="right")
        ttk.Button(altbar, text="Cancel",
                   command=ust.destroy).pack(side="right", padx=8)

    def _apply(self):
        o = self._selected_outfit()
        if not o:
            return
        # TEK KAPI: bas, klasorunu sec. Kendi export'un da, birinin paylastigi
        # tasarim da ayni yerden giriyor -- arac ikisini de taniyor.
        # Diyalog SECILI KIYAFETIN kendi klasorunde acilir. "Wrong folder"
        # sikayetlerinin sebebi diyalogun UST klasorde acilmasiydi: kullanici
        # dogrudan Sec'e basinca kiyafetleri TUTAN klasoru seciyordu. Simdi
        # dogrudan Sec'e basmak DOGRU cevap.
        baslangic = os.path.join(OUTPUT, o["ad"])
        if not os.path.isdir(baslangic):
            baslangic = OUTPUT if os.path.isdir(OUTPUT) else os.path.expanduser("~")
        design = filedialog.askdirectory(
            title="Pick the folder with the painted PNGs",
            initialdir=baslangic, mustexist=True)
        if not design:
            return
        self._apply_klasoru(
            design,
            etiket=o["gorunen_ad"]
            if os.path.basename(os.path.normpath(design)) == o["ad"] else None)

    def _apply_klasoru(self, design, etiket=None):
        """Tanınan doku adlariyla dolu BIR klasoru uygular. Hem "3. Apply
        design" hem "Add a mod" ayni kapidan gecer: kural kopyasi yok.
        `etiket` SUCCESS satirinda gorunen ad (yoksa klasor adi)."""
        design = os.path.normpath(design)
        self.write("- design folder: %s" % design)
        # A folder is usable when it CONTAINS texture files we recognise - it does
        # not have to be one of our own exports. Designs get shared as a zip full
        # of PNGs, and refusing those outright ("no EDIT sub-folder") turned a
        # perfectly good shared design into a dead end.
        try:
            scan = C.scan_design_dir(design)
        except Exception as e:                                  # noqa: BLE001
            print("scan_design_dir failed:\n%s" % traceback.format_exc())
            messagebox.showerror("Error", "Could not read that folder:\n\n%s" % e)
            return
        if scan["sayi"] == 0:
            if scan["alt_tasarimlar"]:
                messagebox.showwarning(
                    "Pick one outfit",
                    "That folder holds several designs rather than being one "
                    "itself.\n\nOpen it and pick one of these:\n\n  %s"
                    % "\n  ".join(scan["alt_tasarimlar"][:12]))
            else:
                t = scan["tani"]
                detay = ""
                if t["taninmayan"]:
                    detay = ("\n\nFound %d file(s) whose names are not texture names, e.g.\n  %s"
                             % (len(t["taninmayan"]), t["taninmayan"][0]))
                elif t["kilitli"]:
                    detay = ("\n\nThe only textures in there are reference/locked ones "
                             "(the region masks), which are never written.")
                messagebox.showwarning(
                    "Nothing to apply",
                    "No usable textures were found in:\n%s\n\nThe tool needs the PNG "
                    "files Export produced, with their original names "
                    "(IC_<id>_tm<id>_<slot>_<size>_<size>_<format>.png). They can sit "
                    "directly in the folder or in an EDIT sub-folder.%s" % (design, detay))
            return
        if scan["tani"]["cakisan"]:
            messagebox.showerror(
                "Duplicate files",
                "Two files map to the same texture slot, so the tool cannot tell "
                "which one you meant:\n\n  %s\n\nKeep one of each and move spare "
                "copies out of this folder."
                % "\n  ".join(scan["tani"]["cakisan"][:8]))
            return
        self.write("- found %d texture(s) across %d material(s) in %s"
                   % (scan["sayi"], len(scan["materyaller"]), scan["kaynak"]))
        # Sekil kurali disinda kalan ama adi gecerli dosyalar: sessizce atilirsa
        # yari uygulanmis kiyafet cikiyor ve log "basarili" diyor.
        atilan = (scan.get("tani") or {}).get("gormezden_gelinen") or []
        if atilan:
            self.write("  NOTE: %d texture file(s) were NOT used because of where they "
                       "sit. Move them next to the others (or into a 0x<material> "
                       "folder) if they are part of the design:" % len(atilan))
            for a in atilan[:8]:
                self.write("     not used: %s" % a)
        if not self._game_closed():
            return

        def job():
            rep = self._progress()
            # ⏱️ ONCE UCUZ KAPILAR, SONRA PAHALI KODLAMA.
            # Sahadan gelen ekran goruntusu: cubuk %99, "encoding 99/100", ardindan
            # "Nothing was applied - a previous apply was interrupted". Kullanici
            # dakikalarca BC7 kodlamasi bekleyip hicbir sey yazilmayacagini EN SONDA
            # ogreniyordu. Yazicinin kendi kapilarini (tek uygulama) simdi ONCE
            # soruyoruz; kural kopyasi YOK.
            erken = C.DE.uygula_kontrol() if hasattr(C.DE, "uygula_kontrol") else None
            if erken:
                self.write("REFUSED before encoding: %s" % erken)
                self.queue.put(("error",
                                "Nothing was applied.\n\n%s\n\nThe game archive was not "
                                "touched, and no time was spent encoding." % erken))
                return
            self.write("- checking design is safe (read-only, no forge write yet)...")
            st = C.status_outfit(design, progress=rep)
            if st.get("kabul", 0) == 0:
                # The old text always blamed a missing EDIT folder. There are three
                # different reasons to land here and only one of them is that.
                red = st.get("reddedilen") or []
                if red:
                    detay = ("Every texture was rejected before writing:\n\n  %s"
                             % "\n  ".join("%s\n     %s" % (a, s) for a, s in red[:6]))
                elif st.get("atlanan") and st.get("atlanan") == st.get("toplam"):
                    detay = ("All %d painted files are byte-identical to the export, so "
                             "there is nothing new to write.\n\nDid you save your edits "
                             "over the exported PNGs, keeping the same file name and "
                             "size?" % st["toplam"])
                else:
                    detay = ("No texture files were found in:\n%s\n\nThe app needs the "
                             "PNGs Export produced, with their original names." % design)
                self.write("Nothing to apply.")
                self.queue.put(("error", detay))
                return
            if st.get("safe") is False:
                self.write("REFUSED: base-shift check is NOT safe. Apply cancelled.")
                self.queue.put(("error",
                                "Safety check failed (base-shift not safe).\n"
                                "The design was NOT applied. The forge is untouched."))
                return
            # A PARTIAL apply used to be invisible: rejected files were printed to a
            # stream nobody could see, so painting 12 slots and writing 9 looked like
            # a clean success. Now it stops and names them.
            red = st.get("reddedilen") or []
            if red:
                self.write("REFUSED: %d file(s) did not pass the safety gates." % len(red))
                for ad, sebep in red[:8]:
                    self.write("   [REJECTED] %s -> %s" % (ad, sebep))
                self.queue.put(("error",
                                "%d of your files were rejected and %d would be written, "
                                "so the design would only be applied in part. Nothing was "
                                "written.\n\n  %s\n\nFix or remove those files and try "
                                "again."
                                % (len(red), st["kabul"],
                                   "\n  ".join("%s\n     %s" % (a, s) for a, s in red[:6]))))
                return
            self.write("Safety check passed (%d slots, base-shift safe)." % st["kabul"])
            self.write("- writing via doku_enjekte2 (single writer)...")
            # Reuse the DDS the status pass just encoded - same single writer,
            # no redundant second encode.
            #
            # The return value used to be thrown away and SUCCESS was printed
            # unconditionally on the next line, so a writer that refused still
            # looked like a win.  Now nothing is claimed unless bytes moved.
            r = C.DE.uygula(st["dds_dir"]) or {}
            if r.get("red_sebep"):
                self.write("REFUSED by the writer: %s" % r["red_sebep"])
                self.queue.put(("error",
                                "Nothing was applied.\n\n%s\n\n"
                                "The game archive was not touched." % r["red_sebep"]))
                return
            written = r.get("harici", 0) + r.get("gomulu", 0)
            if written == 0:
                self.write("REFUSED: the writer accepted no slots.")
                self.queue.put(("error",
                                "Nothing was written to the game archive.\n\n"
                                "See the log for the per-file reason:\n%s" % LOG_PATH))
                return
            # Name what was ACTUALLY written. The folder can belong to a different
            # outfit than the one highlighted in the list (a shared design, or a
            # folder picked by hand), and naming the highlighted one was simply
            # wrong. The folder name is the honest answer when they disagree.
            uygulanan = os.path.basename(os.path.normpath(design))
            etiket_son = etiket if etiket else uygulanan
            self.write("SUCCESS: %d entries written for %s (%d mips, %d materials)."
                       % (written, etiket_son, r.get("harici", 0), r.get("gomulu", 0)))
            self.write("Start the game to see it. Use 'Revert everything' to undo.")

        self._run(job)

    def _revert(self):
        if not os.path.exists(C.DE.KAYIT):
            messagebox.showinfo("Revert", "Nothing to revert - the forge is original.")
            return
        if not self._game_closed():
            return
        # Pre-flight: read-only, writes nothing.  If the game was updated, the
        # files were verified, or the tool folder was moved, the undo record no
        # longer matches the archive - the user needs to hear that BEFORE the
        # confirmation dialog, not after a half-finished revert.
        try:
            chk = C.revert_check()
        except Exception as e:                              # noqa: BLE001
            print("revert_check failed:\n%s" % traceback.format_exc())
            chk = {"sorunlar": ["could not verify the undo record: %s" % e]}
        if chk.get("sorunlar"):
            # Diyalog "ayrinti icin loga bak" diyordu ama sebebi loga hic
            # yazmiyorduk -- kullanicinin gonderdigi log bomboş cikiyordu.
            self.write("REFUSED: revert pre-flight failed, nothing was written:")
            for s in chk["sorunlar"][:12]:
                self.write("   - " + str(s))
            # 🩹 OYUN GUNCELLEMESI KURTARMASI (saha, 2026-08-05): oyun guncellenince
            # Steam arsivi yeniliyor; tasarim zaten gitmis ama BAYAT kayit hem
            # revert'i hem sonraki apply'lari kilitliyordu. Tek cikis %LOCALAPPDATA%
            # klasorunu elle silmekti ("cant use it" raporlarinin koku). Artik
            # kullanici ONAYLARSA kayit + yedekler tarihli adla KENARA ALINIYOR
            # (hicbir sey silinmiyor) ve arac yeniden kullanilabilir oluyor.
            if messagebox.askyesno(
                    "Undo record no longer matches",
                    "The undo record no longer matches this game archive, so nothing "
                    "was reverted:\n\n  - %s\n\nThis usually means the game was UPDATED "
                    "or its files were verified - in that case the archive is already "
                    "back to original and your applied design is gone.\n\n"
                    "Discard the stale undo record so you can apply designs again?\n"
                    "(Nothing is deleted - the record and backups are moved aside "
                    "with a dated name.)\n\nDetails: %s"
                    % ("\n  - ".join(str(s) for s in chk["sorunlar"][:6]), LOG_PATH)):
                r = C.DE.kayit_sifirla() if hasattr(C.DE, "kayit_sifirla") else {}
                self.write("Stale undo record set aside: %s" % (r or "nothing to move"))
                self._refresh_patch_state()
            return
        n = chk.get("geri_alinacak", 0)
        if not messagebox.askyesno(
                "Revert",
                "Revert ALL applied outfit textures back to original?\n\n"
                "%d entries will be restored." % n):
            return

        def job():
            self.write("- reverting all patches...")
            r = C.revert_outfit(progress=self._progress())
            # Ikinci savunma: yazici reddini `revert_outfit` yukseltiyor, ama basari
            # satirini KAYITTAN da dogrula. Kayit hala duruyorsa geri alma
            # tamamlanmamistir ve "back to original" yalan olur.
            if r.get("kayit_var"):
                raise RuntimeError(
                    "The undo record is still in place, so the revert did not "
                    "complete. The archive may still be patched - see %s" % LOG_PATH)
            n = r.get("geri_alindi", 0)
            if n:
                self.write("Reverted %d entries. The forge is back to original." % n)
            else:
                self.write("Nothing needed restoring - the forge was already original.")

        self._run(job)

    def _game_closed(self):
        try:
            r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ACBlackFlag.exe"],
                               capture_output=True, text=True,
                               creationflags=NO_WINDOW)
            if "ACBlackFlag" in (r.stdout or ""):
                messagebox.showwarning(
                    "Game is running",
                    "The game is running right now. Close it and try again.")
                return False
        except Exception:
            pass
        return True

    def _open_output(self):
        os.makedirs(OUTPUT, exist_ok=True)
        try:
            os.startfile(OUTPUT)
        except Exception:
            pass


if __name__ == "__main__":
    try:
        _app = App()
        # From here on, everything printed by the engine and by the writer also
        # lands in the on-screen console, not just the log file.
        _TEE.gui = _app.write_gui
        print("window created, entering main loop")
        _app.mainloop()
    except SystemExit:
        raise
    except BaseException as _e:                             # noqa: BLE001
        _fatal("starting the window", _e)
        raise SystemExit(1)
