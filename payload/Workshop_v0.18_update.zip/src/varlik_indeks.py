#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
varlik_indeks.py -- oyunun TUM varliklarinin salt-okunur indeksi.

Workshop'un kuratorlu sekmeleri (Outfits/Weapons/Sounds/Ships) elle secilmis
hedefleri gosterir. Bu modul onlarin ALTINDAKI katmandir: oyunun 157 forge
arsivindeki ic dosyalarin TAMAMI, sinif ve forge sozlukleriyle birlikte.
"Sunu goremezsin" cumlesi kalmasin diye dunya/nav verisi de indeks ICINDEDIR;
onu varsayilan suzgecte kapatmak ARAYUZUN isidir, bu modul hicbir sey gizlemez.

Indeks artik ANSIKLOPEDI VERI TABANINDAN DEGIL, CANLI ARSIVLERDEN uretiliyor
(build/varlik_indeks_uret.py). Iki sonucu var:
  * Hicbir ad EKSIK DEGIL -- K1 ad sifresinin kuyrugu 2026-09-07'de cozuldu,
    bu yuzden hicbir ad '?' ile bitmiyor. `satir["tam_mi"]` daima 1.
  * Adi OLMAYAN ic dosyalar da indekste. Onlarin adi bos kalir ve yerine
    TURETILMIS bir etiket gosterilir (`satir["etiket"]`): akis sayfalari
    ebeveyninin adiyla, giris parcalari kokun adiyla anilir.

BU MODUL YALNIZCA OKUR.  Tek girdisi yanindaki varlik_indeks.bin dosyasidir.
Oyun arsivi (forge) ACILMAZ, okunmaz, yazilmaz -- forgeler()'in "var_mi" alani
bile yalnizca os.path.isfile cagirir. Oyun yolu outfit_core'dan alinir.

Dosya bicimi: build/varlik_indeks_uret.py basindaki "WSVI surum 2" semasi
(tek dogruluk kaynagi orasidir; bu okuyucu o semayi uygular).

Sozlesme (arayuz ve diger araclar bunlari cagirir; DEGISMEDI):
    yukle()                                        -> Indeks | None
    ara(metin, sinif=None, forge=None, limit=200, offset=0)
                                                   -> {"toplam": N, "satirlar": [...]}
    siniflar()                                     -> [{"ad", "sayi"}, ...]
    forgeler()                                     -> [{"ad", "sayi", "yol", "var_mi"}]
    kayit(gid, icid=None)                          -> satir | None
    istatistik()                                   -> {"satir","forge","sinif","bayt"}
satir = {"forge","sinif","gid","icid","ad","boyut",     <- eski alanlar, ayni anlam
         "etiket","ebeveyn_gid","tam_mi"}               <- surum 2'de eklendi
    ad          : varligin GERCEK adi; adsiz ic dosyalarda "" (bos)
    etiket      : ad bossa gosterilecek turetilmis metin; adlilarda "" (bos)
    ebeveyn_gid : etiketli satirin turetilen ebeveyninin TOC kimligi ("0x..") ya da None
    tam_mi      : 1 -- ad kuyrugu cozuldugu icin artik daima tam (geriye donuk alan)
Arama HEM adlarda HEM etiketlerde calisir (ikisi de ayni bloba yazilir).

Indeks dosyasi yoksa HICBIR sey coker: yukle() None doner, hata() sebebi
soyler, ara() bos sonuc + "hata" anahtari dondurur.

OLCULEN DEGERLER (bu makine, 2026-09-07 -- testler/test_varlik_indeks.py
her kosuda yeniden olcup basar; asagidakiler o kosunun ciktisidir):
    varlik_indeks.bin   23,82 MB    yukle 0,40 sn (temiz surecte 0,36 sn)
    satir               2.165.452   (1.906.124 adli + 259.328 etiketli)
    forge / sinif       157 / 2.436 (1.502 sinif adi cozulmus)
    bellek artisi       200 MB      (107 MB ad blobu + 13,4 MB bit haritasi +
                                     ~71 MB kolonlar + 8,7 MB satir baslari)
    ara                 29-95 ms tipik sorgu ('jackdaw' 8.638 eslesme -> 30 ms)
                        278-304 ms EN KOTU: tek harf 'e', 2,11M eslesme
    ara (metinsiz suzgec)  1-2 ms -- sayaclar dosyada hazir
Onceki (DB kaynakli) surum 1 ile kiyas: 1.669.993 -> 2.165.452 satir
(+%29,7), 100 -> 157 forge, 17,04 -> 23,82 MB, 143 -> 200 MB bellek.
Eski indeksteki adlarin 932.376'si '?' ile kirpikti; simdi SIFIR.
"""

import array
import bisect
import itertools
import json
import os
import re
import sys
import threading
import zlib

MAGIC = b"WSVI"
SURUM = 2
VARSAYILAN_BIN = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "varlik_indeks.bin")

# Blok sirasi ve eleman genisligi -- ureticinin yazdigi sirayla AYNI olmali.
# (ad, tip_kodu) ; tip_kodu None = ham bayt
_BLOK_SEMA = [
    ("forge_sozluk", None), ("sinif_sozluk", None),
    ("forge_sayi", 'I'), ("sinif_sayi", 'I'),
    ("forge_idx", 'B'), ("sinif_idx", 'H'),
    ("gid", 'Q'), ("icid", 'Q'), ("boyut", 'I'), ("ad_uzunluk", 'H'),
    ("ad_blob", None), ("buyuk_harf", None),
    ("etiket_satir", 'I'), ("etiket_tur", 'B'),
    ("etiket_ebeveyn", 'Q'), ("etiket_sayfa", 'I'),
]

# Etiket turleri (uretici ile ortak sabitler; ekrana giden metin blobun icinde).
ETIKET_TUR = {1: "page", 2: "part", 3: "entry", 4: "unresolved"}

# Sinif sozlugundeki "adsiz" etiket bicimi (uretici boyle yazar).
_HEX_ETIKET = re.compile(r"^0x[0-9A-Fa-f]{8}$")


def sozluk_oyunlastir(adlar):
    """Indeksin sinif sozlugunu OYUNUN KENDI adlariyla tazele -> (liste, olcum).

    NEDEN CALISMA ANINDA? .bin'in sinif sozlugu derleme aninda
    build/sinif_adlari.json'dan dolduruluyor. IKI SECENEK OLCULDU (2026-09-09):
      * .bin'i yeniden uret : 157 arsiv, 77,38 GB okuma, 150,8 sn -- ve sonuc
        YINE "1.502 sinif adi cozuldu" cikti, cunku uretici oyunun tablosunu
        degil bizim JSON'umuzu okuyor. Yani 151 sn + 23,8 MB'lik ikili degisimi
        SIFIR yeni ad getiriyordu.
      * bu ceviri          : 2.436 etiket, 1,1 ms (+ tablonun JSON yuklemesi
        10 ms, oturumda bir kez) -- 817 adsiz sinif ADLANDI, 12 yanlis ad
        DUZELDI.
    Ustelik ceviri her acilista TAZE tabloyu kullanir: oyun guncellenince .bin'i
    yeniden uretmek gerekmez.

    Iki yon:
      * "0xXXXXXXXX" etiketi -> tablodaki gercek ad (adsiz sinif ADLANIR)
      * adli etiket -> crc32(etiket) tabloda BASKA bir ad veriyorsa oyunun adi
        kazanir. Olculdu: eski tablodaki 12 ad crc32 CARPISMASIYDI (or.
        "Cell 6307_MainGrid_DataBlock" -> gercekte SoundVoiceNPCType).

    Cakisma korumasi: ceviri sonucu ZATEN kullanilan bir ada esitse etiket
    OLDUGU GIBI kalir -- `_s_dizin` bir adi tek indise baglar, iki satir ayni
    adi tasirsa sinif suzgeci sessizce yarim sonuc verirdi.

    Tablo yoksa (nesne modulu ya da JSON eksik) liste AYNEN doner: indeks
    eskisi gibi calisir, adlar yalniz daha az okunakli olur.
    """
    bos = {"tablo": 0, "adlanan": 0, "duzeltilen": 0, "cakisma": 0}
    try:
        import nesne as _N
        tablo = _N.oyun_sinif_adlari()
        crc_ad = _N.crc_ad
    except Exception:                       # noqa: BLE001 -- tablo ZORUNLU DEGIL
        return list(adlar), bos
    if not tablo:
        return list(adlar), bos
    onerilen = {}
    for i, a in enumerate(adlar):
        if _HEX_ETIKET.match(a):
            yeni = tablo.get(int(a, 16))
        else:
            try:
                yeni = tablo.get(crc_ad(a))
            except (UnicodeEncodeError, AttributeError, TypeError):
                yeni = None
        if yeni and yeni != a:
            onerilen[i] = yeni
    out = list(adlar)
    kullanilan = set(a.lower() for i, a in enumerate(adlar) if i not in onerilen)
    olcum = {"tablo": len(tablo), "adlanan": 0, "duzeltilen": 0, "cakisma": 0}
    for i in sorted(onerilen):
        yeni = onerilen[i]
        if yeni.lower() in kullanilan:
            olcum["cakisma"] += 1
            continue
        kullanilan.add(yeni.lower())
        olcum["adlanan" if _HEX_ETIKET.match(out[i]) else "duzeltilen"] += 1
        out[i] = yeni
    return out, olcum

# ad_blob ayraci. Gecerli UTF-8'de 0xFF ASLA gecmez, bu yuzden hicbir ad onu
# icermez ve arama iki komsu adin sinirini asip yanlis eslesme uretemez.
# (Ansiklopedide 370 ascii-disi, 133 satir sonlu, 131 NUL'lu bozuk ad var --
#  '\n' ayrac secilseydi bu adlar bozularak saklanacakti.)
_AYRAC_B = bytes([0xFF])


class IndeksHatasi(Exception):
    """Indeks dosyasi yok ya da bozuk. Cagiran KENDI yakalamak zorunda degil:
    modul duzeyindeki yukle()/ara() bunu yakalar ve sakin bir sonuc dondurur."""


class Indeks(object):
    """Tek bir .bin dosyasinin bellege alinmis hali. Tamamen salt-okunur."""

    def __init__(self, yol=None):
        self.yol = yol or VARSAYILAN_BIN
        self._oyun_kok = False          # False = henuz cozulmedi, None = bulunamadi
        self._desen_onbellek = {}       # igne -> derlenmis re deseni
        self._yukle()

    # ------------------------------------------------------------------ yukleme
    def _yukle(self):
        if not os.path.isfile(self.yol):
            raise IndeksHatasi(
                "Asset index not found: %s\n"
                "The full asset browser is unavailable. Reinstall Workshop, or "
                "rebuild the index with build/varlik_indeks_uret.py." % self.yol)
        with open(self.yol, "rb") as f:
            bas = f.read(10)
            if len(bas) < 10 or bas[:4] != MAGIC:
                raise IndeksHatasi("Asset index is corrupt (bad magic): %s" % self.yol)
            surum = int.from_bytes(bas[4:6], "little")
            if surum != SURUM:
                raise IndeksHatasi(
                    "Asset index version %d is not supported by this build "
                    "(expected %d): %s" % (surum, SURUM, self.yol))
            mlen = int.from_bytes(bas[6:10], "little")
            meta_ham = f.read(mlen)
            zlen_ham = f.read(4)
            if len(meta_ham) != mlen or len(zlen_ham) != 4:
                raise IndeksHatasi("Asset index is truncated: %s" % self.yol)
            zlen = int.from_bytes(zlen_ham, "little")
            z = f.read(zlen)
            if len(z) != zlen:
                raise IndeksHatasi("Asset index is truncated: %s" % self.yol)
        try:
            self.meta = json.loads(meta_ham.decode("utf-8"))
        except Exception as e:
            raise IndeksHatasi("Asset index header is unreadable: %s" % e)

        bloklar = self.meta.get("bloklar") or []
        beklenen = [b[0] for b in _BLOK_SEMA]
        if [b[0] for b in bloklar] != beklenen:
            raise IndeksHatasi("Asset index block layout does not match this build.")

        # Bloklari AKARAK ac: 129,8 MB'lik yigin hicbir an tek parca halinde
        # bellekte durmaz (olculdu: tepe bellek ~2 kat dusuyor).
        d = zlib.decompressobj()
        kalan = z
        veri = {}
        for (ad, tipk), (_, uzunluk) in zip(_BLOK_SEMA, bloklar):
            parcalar = []
            alinan = 0
            while alinan < uzunluk:
                out = d.decompress(kalan, uzunluk - alinan)
                kalan = d.unconsumed_tail
                if not out:
                    raise IndeksHatasi("Asset index payload is truncated "
                                       "(block '%s')." % ad)
                parcalar.append(out)
                alinan += len(out)
            ham = parcalar[0] if len(parcalar) == 1 else b"".join(parcalar)
            if tipk is None:
                veri[ad] = ham
            else:
                a = array.array(tipk)
                a.frombytes(ham)
                if sys.byteorder != "little":
                    a.byteswap()        # dosya bicimi sabit little-endian
                veri[ad] = a
            del parcalar, ham

        self.n = int(self.meta.get("satir", 0))
        self._forge_ad = veri["forge_sozluk"].decode("ascii").split("\n") if veri["forge_sozluk"] else []
        self._sinif_ad = veri["sinif_sozluk"].decode("ascii").split("\n") if veri["sinif_sozluk"] else []
        # Sozluk OYUNUN KENDI tablosuyla tazelenir (bkz. sozluk_oyunlastir).
        # Buradan sonra `_satir`, `siniflar()`, `_s_dizin` ve Explorer agacinin
        # tur tablosu AYNI adi gorur -- kullanicinin gordugu her yerde tek ad.
        self._sinif_ad, self.sinif_oyun = sozluk_oyunlastir(self._sinif_ad)
        self._forge_say = veri["forge_sayi"]
        self._sinif_say = veri["sinif_sayi"]
        self._f_idx = veri["forge_idx"]
        self._s_idx = veri["sinif_idx"]
        self._gid = veri["gid"]
        self._icid = veri["icid"]
        self._boyut = veri["boyut"]
        self._alen = veri["ad_uzunluk"]
        self._blob = veri["ad_blob"]          # UTF-8, kucuk harf, 0xFF ayracli
        self._ust = veri["buyuk_harf"]        # bit haritasi
        # Etiketli (adsiz) satirlar: ARTAN satir numarasi listesi + yan kolonlar.
        # N boyunda kolon TUTULMAZ; "bu satirin adi mi etiketi mi?" sorusu bisect
        # ile cevaplanir ve yalniz EKRANA GIDEN satirlar icin sorulur.
        self._et_satir = veri["etiket_satir"]
        self._et_tur = veri["etiket_tur"]
        self._et_eb = veri["etiket_ebeveyn"]
        self._et_sayfa = veri["etiket_sayfa"]
        m = len(self._et_satir)
        for ad, a in (("etiket_tur", self._et_tur), ("etiket_ebeveyn", self._et_eb),
                      ("etiket_sayfa", self._et_sayfa)):
            if len(a) != m:
                raise IndeksHatasi("Asset index label column '%s' has %d rows, "
                                   "expected %d." % (ad, len(a), m))
        # Kolonlarin ham bayt goruntusu: suzgec taramasi bytes.find ile C hizinda
        # yapilir (saf python dongusu 1,67M satirda ~0,3 sn suruyordu).
        self._f_bayt = self._f_idx.tobytes()
        self._s_bayt = self._s_idx.tobytes()

        for ad, a in (("forge_idx", self._f_idx), ("sinif_idx", self._s_idx),
                      ("gid", self._gid), ("icid", self._icid),
                      ("boyut", self._boyut), ("ad_uzunluk", self._alen)):
            if len(a) != self.n:
                raise IndeksHatasi("Asset index column '%s' has %d rows, header "
                                   "says %d." % (ad, len(a), self.n))

        # satir baslangiclari: starts[i] = ad_blob icinde i. adin ilk bayti,
        # starts[n] = son sinir. accumulate C hizindadir (olculdu ~0,15 sn).
        self._bas = array.array('I', itertools.accumulate(
            (l + 1 for l in self._alen), initial=0))
        if self._bas[self.n] - 1 != len(self._blob):
            raise IndeksHatasi("Asset index name blob length mismatch.")
        self._f_dizin = {a.lower(): i for i, a in enumerate(self._forge_ad)}
        self._s_dizin = {a.lower(): i for i, a in enumerate(self._sinif_ad)}

    # -------------------------------------------------------------- yardimcilar
    def _ad(self, i):
        """i. satirin adini ORIJINAL yazimiyla dondur (kucuk harf + bit haritasi).
        Yalnizca ekrana giden satirlar icin cagrilir (<=limit), o yuzden
        karakter dongusu maliyeti onemsiz."""
        s = self._bas[i]
        e = s + self._alen[i]
        b = bytearray(self._blob[s:e])
        ust = self._ust
        for k in range(e - s):
            p = s + k
            if ust[p >> 3] >> (p & 7) & 1:
                b[k] -= 32
        return b.decode("utf-8", "replace")

    def _etiket_k(self, i):
        """i. satir ETIKETLI ise etiket kolonlarindaki sirasi, degilse -1."""
        et = self._et_satir
        k = bisect.bisect_left(et, i)
        return k if k < len(et) and et[k] == i else -1

    def _satir(self, i):
        metin = self._ad(i)
        k = self._etiket_k(i)
        etiketli = k >= 0
        return {
            "forge": self._forge_ad[self._f_idx[i]],
            "sinif": self._sinif_ad[self._s_idx[i]],
            "gid": "0x%X" % self._gid[i],
            "icid": "0x%X" % self._icid[i],
            # Etiket bir AD DEGILDIR: adi olmayan satirda "ad" bos kalir.
            "ad": "" if etiketli else metin,
            "etiket": metin if etiketli else "",
            "etiket_turu": ETIKET_TUR.get(self._et_tur[k]) if etiketli else None,
            "ebeveyn_gid": ("0x%X" % self._et_eb[k]) if etiketli else None,
            "sayfa": int(self._et_sayfa[k]) if etiketli else None,
            "boyut": self._boyut[i],
            # Ad sifresinin kuyrugu cozuldu: hicbir ad kirpik degil (geriye donuk alan).
            "tam_mi": 1,
        }

    def _suzgec_indisi(self, sinif, forge):
        """Etiketleri sozluk indislerine cevir. Bilinmeyen etiket -> -1
        (eslesme yok demektir, hata degil)."""
        si = fi = None
        if sinif:
            si = self._s_dizin.get(str(sinif).strip().lower(), -1)
        if forge:
            fi = self._f_dizin.get(str(forge).strip().lower(), -1)
        return si, fi

    # ------------------------------------------------------------------- arama
    def ara(self, metin, sinif=None, forge=None, limit=200, offset=0):
        offset = max(0, int(offset or 0))
        limit = None if limit is None else max(0, int(limit))
        ust_sinir = None if limit is None else offset + limit
        si, fi = self._suzgec_indisi(sinif, forge)
        if si == -1 or fi == -1:
            return {"toplam": 0, "satirlar": []}

        desen = (metin or "").strip()
        if desen:
            # Kucuk harfe cevirme BAYT duzeyinde: blob da bytes.lower() ile
            # uretildi (yalnizca ASCII A-Z cevrilir). str.lower() kullanilsaydi
            # Unicode kurallari blob ile ayrisirdi (or. 'I' -> 'i' vs 0xC4 0xB0).
            try:
                igne = desen.encode("utf-8").lower()
            except UnicodeEncodeError:      # yalniz vekil (surrogate) karakterler
                return {"toplam": 0, "satirlar": []}
            return self._ara_metin(igne, si, fi, offset, ust_sinir)
        return self._ara_suzgec(si, fi, offset, ust_sinir)

    def _desen(self, igne):
        """igne + satir kalanini yutan derlenmis desen.

        `[^\\xff]*` kuyrugu, eslesmeden sonra imleci satir sonuna tasir: bir ad
        igneyi iki kez icerse bile TEK kez sayilir. Iki ayri bytes.find cagrisi
        (biri igne, biri ayrac) ayni sonucu veriyordu ama iki kat yavasti
        (olculdu: tek harflik en kotu sorgu 343 ms -> 167 ms)."""
        d = self._desen_onbellek.get(igne)
        if d is None:
            d = re.compile(re.escape(igne) + b"[^" + _AYRAC_B + b"]*")
            if len(self._desen_onbellek) > 64:
                self._desen_onbellek.clear()
            self._desen_onbellek[igne] = d
        return d

    def _ara_metin(self, igne, si, fi, offset, ust_sinir):
        bas = self._bas
        s_idx, f_idx = self._s_idx, self._f_idx
        toplam = 0
        secilen = []
        ipucu = 0           # bisect icin alt sinir; isabetler artan sirada
        suzgecli = (si is not None) or (fi is not None)
        pencerede = ust_sinir is None or offset < ust_sinir
        for m in self._desen(igne).finditer(self._blob):
            i = m.start()
            if suzgecli:
                satir = bisect.bisect_right(bas, i, ipucu) - 1
                ipucu = satir
                if si is not None and s_idx[satir] != si:
                    continue
                if fi is not None and f_idx[satir] != fi:
                    continue
                if pencerede and offset <= toplam and (ust_sinir is None or toplam < ust_sinir):
                    secilen.append(satir)
            elif pencerede and offset <= toplam and (ust_sinir is None or toplam < ust_sinir):
                satir = bisect.bisect_right(bas, i, ipucu) - 1
                ipucu = satir
                secilen.append(satir)
            toplam += 1
        return {"toplam": toplam, "satirlar": [self._satir(r) for r in secilen]}

    def _ara_suzgec(self, si, fi, offset, ust_sinir):
        """Metin yok: suzgec kolonunu HAM BAYT uzerinde tara (bytes.find)."""
        n = self.n
        if si is None and fi is None:
            son = n if ust_sinir is None else min(n, ust_sinir)
            satirlar = [self._satir(i) for i in range(min(offset, n), son)]
            return {"toplam": n, "satirlar": satirlar}

        # Hangi kolon daha secici? Sayaclar dosyada hazir, saymaya gerek yok.
        f_say = self._forge_say[fi] if fi is not None else n + 1
        s_say = self._sinif_say[si] if si is not None else n + 1
        if fi is not None and f_say <= s_say:
            surucu, ikincil = ("forge", fi), (("sinif", si) if si is not None else None)
            toplam_tahmin = f_say
        else:
            surucu, ikincil = ("sinif", si), (("forge", fi) if fi is not None else None)
            toplam_tahmin = s_say

        if surucu[0] == "forge":
            gez = self._forge_gezgin(surucu[1])
        else:
            gez = self._sinif_gezgin(surucu[1])

        if ikincil is None:
            # Tek suzgec: toplam dosyadaki sayacin ta kendisi, satir aramaya gerek yok
            secilen = []
            for k, satir in enumerate(gez):
                if k < offset:
                    continue
                if ust_sinir is not None and k >= ust_sinir:
                    break
                secilen.append(satir)
            return {"toplam": toplam_tahmin,
                    "satirlar": [self._satir(r) for r in secilen]}

        kol = self._s_idx if ikincil[0] == "sinif" else self._f_idx
        deg = ikincil[1]
        toplam = 0
        secilen = []
        for satir in gez:
            if kol[satir] != deg:
                continue
            if offset <= toplam and (ust_sinir is None or toplam < ust_sinir):
                secilen.append(satir)
            toplam += 1
        return {"toplam": toplam, "satirlar": [self._satir(r) for r in secilen]}

    def _forge_gezgin(self, fi):
        """forge_idx kolonunda fi degerine sahip satir numaralarini uret (C hizli)."""
        kol = self._f_bayt
        hedef = bytes((fi,))
        pos = 0
        find = kol.find
        while True:
            i = find(hedef, pos)
            if i < 0:
                return
            pos = i + 1
            yield i

    def _sinif_gezgin(self, si):
        """sinif_idx (u16) kolonunda si degerine sahip satirlar. Iki baytlik
        desen TEK sayili ofsette de tutabilir (yanlis hizalama) -- eleniyor."""
        kol = self._s_bayt
        hedef = si.to_bytes(2, "little")
        pos = 0
        find = kol.find
        while True:
            i = find(hedef, pos)
            if i < 0:
                return
            pos = i + 1
            if not (i & 1):
                yield i >> 1

    # ------------------------------------------------------------ tekil sorgular
    def kayit(self, gid, icid=None):
        g = _kimlik(gid)
        if g is None:
            return None
        i = bisect.bisect_left(self._gid, g)
        n = self.n
        if i >= n or self._gid[i] != g:
            return None
        ic = _kimlik(icid) if icid is not None else None
        ilk = i
        while i < n and self._gid[i] == g:
            if ic is None:
                # icid verilmediyse GIRISIN KENDISI (icid == gid) tercih edilir
                if self._icid[i] == g:
                    return self._satir(i)
            elif self._icid[i] == ic:
                return self._satir(i)
            i += 1
        return None if ic is not None else self._satir(ilk)

    def siniflar(self):
        c = [{"ad": a, "sayi": int(self._sinif_say[i])}
             for i, a in enumerate(self._sinif_ad)]
        c.sort(key=lambda x: (-x["sayi"], x["ad"]))
        return c

    def forgeler(self, yenile=False):
        kok = self._oyun_kokunu_bul(yenile)
        out = []
        for i, a in enumerate(self._forge_ad):
            yol = os.path.join(kok, a) if kok else None
            var = bool(yol) and os.path.isfile(yol)
            out.append({"ad": a, "sayi": int(self._forge_say[i]),
                        "yol": yol if var else None, "var_mi": var})
        out.sort(key=lambda x: (-x["sayi"], x["ad"]))
        return out

    def istatistik(self):
        m = len(self._et_satir)
        return {"satir": self.n, "forge": len(self._forge_ad),
                "sinif": len(self._sinif_ad), "bayt": int(self.meta.get("bayt", 0)),
                "adli": self.n - m, "etiketli": m,
                "tam_mi": int(self.meta.get("tam_mi", 1)),
                # Oyunun kendi sinif sozlugunden gelen ceviri (calisma aninda).
                "sinif_oyun": dict(getattr(self, "sinif_oyun", None) or {})}

    # ---------------------------------------------------------------- oyun yolu
    def _oyun_kokunu_bul(self, yenile=False):
        """Oyun klasoru. outfit_core TEK dogruluk kaynagidir (kullanicinin elle
        sectigi klasoru o biliyor). Bu cagri ARSIV ACMAZ; outfit_core'un kendisi
        de import aninda yalnizca os.path.isfile ile arar (olculdu: 0 forge acma)."""
        if self._oyun_kok is not False and not yenile:
            return self._oyun_kok
        kok = None
        try:
            import outfit_core
            f = getattr(outfit_core, "FORGE", None)
            if f and os.path.isfile(f):
                kok = os.path.dirname(f)
            else:
                kok = outfit_core.find_game()
        except Exception:
            # outfit_core yoksa/yuklenmiyorsa indeks yine de calisir; sadece
            # "var_mi" bilgisi olmaz. Sessizce yutmuyoruz, hata()'ya yaziyoruz.
            kok = None
        self._oyun_kok = kok
        return kok


def _kimlik(v):
    """int, '0x...' ya da ondalik metin -> isaretsiz 64 bit tamsayi."""
    if v is None:
        return None
    if isinstance(v, int):
        return v & 0xFFFFFFFFFFFFFFFF
    s = str(v).strip().replace("_", "")
    try:
        return int(s, 16 if s[:2].lower() == "0x" else 10) & 0xFFFFFFFFFFFFFFFF
    except (ValueError, IndexError):
        return None


# --------------------------------------------------------------- modul cephesi
_KILIT = threading.Lock()
_INDEKS = None
_HATA = None
_DENENDI = False


def yukle(yol=None, zorla=False):
    """Indeksi bellege al (tembel; ilk cagride ~0,55 sn). Basarisizsa None
    doner ve sebebi hata() ile okunur -- CAGIRAN COKMEZ."""
    global _INDEKS, _HATA, _DENENDI
    with _KILIT:
        if zorla or yol is not None:
            _INDEKS, _HATA, _DENENDI = None, None, False
        if _INDEKS is None and not _DENENDI:
            _DENENDI = True
            try:
                _INDEKS = Indeks(yol)
                _HATA = None
            except IndeksHatasi as e:
                _INDEKS, _HATA = None, str(e)
            except Exception as e:          # bozuk dosya, disk hatasi, ...
                _INDEKS, _HATA = None, "Asset index could not be read: %s" % e
        return _INDEKS


def hata():
    """Son yukleme hatasinin kullaniciya gosterilebilir metni (yoksa None)."""
    return _HATA


def hazir_mi():
    return yukle() is not None


def ara(metin, sinif=None, forge=None, limit=200, offset=0):
    ix = yukle()
    if ix is None:
        return {"toplam": 0, "satirlar": [], "hata": _HATA}
    return ix.ara(metin, sinif, forge, limit, offset)


def siniflar():
    ix = yukle()
    return [] if ix is None else ix.siniflar()


def forgeler(yenile=False):
    ix = yukle()
    return [] if ix is None else ix.forgeler(yenile)


def kayit(gid, icid=None):
    ix = yukle()
    return None if ix is None else ix.kayit(gid, icid)


def istatistik():
    ix = yukle()
    if ix is None:
        return {"satir": 0, "forge": 0, "sinif": 0, "bayt": 0, "hata": _HATA}
    return ix.istatistik()


if __name__ == "__main__":
    import time
    t = time.time()
    ix = yukle()
    if ix is None:
        print(hata())
        sys.exit(1)
    print("load %.2fs  %s" % (time.time() - t, istatistik()))
    q = sys.argv[1] if len(sys.argv) > 1 else "Jackdaw"
    t = time.time()
    r = ara(q, limit=5)
    print("search '%s' %.1f ms  toplam=%d" % (q, (time.time() - t) * 1000, r["toplam"]))
    for s in r["satirlar"]:
        print("   ", s)
