# -*- coding: utf-8 -*-
"""WORKSHOP onyukleyici — baslatici exe'nin calistirdigi dosya.

Once YENI web arayuzu (WebView2) acilir; makinede WebView2/.NET eksikse ya da
kabuk herhangi bir sebeple kurulamadiysa KLASIK arayuze (Tk) sessizce dusulur —
kimse bos ekranla kalmaz. Iki arayuz de AYNI motoru kullanir.

Testler bu dosyayi MODUL olarak yukler: o durumda hicbir pencere acilmaz,
klasik arayuzun tum isimleri (App dahil) buradan disari verilir.
"""
import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(os.environ.get("LOCALAPPDATA", HERE),
                       "OutfitWorkshop", "logs")


def _klasik_modul():
    import importlib.util
    yol = os.path.join(HERE, "OutfitWorkshop_klasik.pyw")
    spec = importlib.util.spec_from_file_location("workshop_klasik", yol)
    m = importlib.util.module_from_spec(spec)
    sys.modules["workshop_klasik"] = m
    spec.loader.exec_module(m)
    return m


def _motw_temizle():
    """Internetten inen zip'in "Mark of the Web" damgasini kaldir.

    Windows Gezgini zip'i acarken her dosyaya Zone.Identifier akisi basar;
    .NET Framework damgali Python.Runtime.dll'i YUKLEMEYI REDDEDER ve web
    kabuk klasige duser (Nexus'tan inen kopyada olculdu, ZoneId=3 kanitli).
    Damga NTFS ek akisidir — silmek dosyanin kendi baytlarina dokunmaz.
    Web kabugu ilgilendiren yalniz DLL/PYD/EXE'ler; once onlari temizliyoruz
    ki ayni calistirmada import basarili olsun.
    """
    kok = os.path.dirname(HERE)
    for dp, _dn, fn in os.walk(kok):
        for f in fn:
            if f.lower().endswith((".dll", ".pyd", ".exe")):
                try:
                    os.remove(os.path.join(dp, f) + ":Zone.Identifier")
                except OSError:
                    pass                     # damga yoksa / silinemezse gec


def _log_dus(hata):
    # kullanicinin gonderebilecegi log INGILIZCE (topluluk kurali)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "shell-fallback.log"), "w",
                  encoding="utf-8") as f:
            f.write("The new Workshop interface could not start; falling back "
                    "to the classic interface.\nEverything still works — "
                    "installing Microsoft WebView2 Runtime usually brings the "
                    "new interface back:\n"
                    "https://developer.microsoft.com/microsoft-edge/webview2\n\n"
                    + hata)
    except OSError:
        pass


if __name__ == "__main__":
    try:
        _motw_temizle()
        sys.path.insert(0, os.path.join(os.path.dirname(HERE), "arayuz"))
        import sunucu
        sunucu.main()
    except Exception:                                           # noqa: BLE001
        _log_dus(traceback.format_exc())
        m = _klasik_modul()
        app = m.App()
        try:
            app.iconbitmap(os.path.join(os.path.dirname(HERE), "arayuz",
                                        "varlik", "workshop.ico"))
        except Exception:
            pass                             # ikon suslemedir, akisi bozamaz
        app.mainloop()
else:
    # test/ice aktarim uyumu: klasik arayuzun adlarini aynen sun
    _m = _klasik_modul()
    for _ad in dir(_m):
        if not _ad.startswith("__"):
            globals()[_ad] = getattr(_m, _ad)
