# -*- coding: utf-8 -*-
"""NESNE_XML -- forge ic dosyasini XML olarak ac, elle duzenle, agaca geri cevir.

Anvil'in AC oyunlarinda yaptigi is ("nesneyi XML olarak ac, duzenle, geri yaz")
bizde de var. Katman dizilimi:

    forge  --(export3d.forge_giris)-->  ic dosya
    ic dosya  --(nesne.oku)-->  NESNE AGACI          <- kayitlara ayirma
    agac  --(nesne_xml.xml_ver)-->  XML METNI        <- BU MODUL
    XML metni  --(nesne_xml.xml_al)-->  agac         <- BU MODUL
    agac  --(nesne.yaz)-->  GOVDE baytlari
    govde --(explorer_core / kur_mesh)--> kurulum    <- TEK YAZICI, bu modul DEGIL

⛔ BU MODUL HICBIR SEY YAZMAZ. Ne oyun arsivine, ne yedege, ne jurnale. `xml_ver`
forge'u SALT OKUNUR acar (nesne.oku uzerinden) ve kapatir; `xml_al` yalnizca
metin okur. Yazma yolu bilincli olarak YOKTUR -- kurulum explorer_core /
kur_mesh uzerinden gider (TEK YAZICI kurali).

=============================================================================
 XML NEDEN BOYLE
=============================================================================
1) KENDINI ANLATIR. `xml_al` semayi (build/nesne_semasi.json) HIC OKUMAZ: her
   alan elemani kendi tipini ve baytlarini tasir. Boylece sema yarin degisirse
   ya da hic yuklenemezse bile ELDEKI XML aynen geri yazilir. Sema YALNIZCA
   disa aktarmada, okunakliligi artirmak icin kullanilir.

2) HEX GIZLENMEZ. Kayit elemaninda `crc` niteligi DAIMA vardir. Sinif adi
   KANITLI ise (nesne.sinif_ad -> build/sinif_adlari_oyun.json = OYUNUN KENDI
   GlobalMetaFile tablosu, sonra build/sinif_adlari.json + alan_adlari.json)
   eleman adi o addir; degilse eleman `<sinif>` olur. crc32(ad) == crc esitligi
   yazarken de okurken de dogrulanir, yani ad tablosu bozulsa bile tur donusu
   kirilmaz. Ad oyunun kendi tablosundan geldiyse eleman `kaynak="oyun"` tasir --
   ucuncu taraf sozluk OKUNMAZ.

3) TAHMIN AD, AD DEGILDIR. build/ic_sinif_adlari.json'daki 317 ad crc32 sozluk
   saldirisiyla URETILMISTIR ve uretenin kendi olcumune gore desteksiz kumenin
   ~%11'i uydurmadir. Bu yuzden onlar ELEMAN ADI OLARAK KULLANILMAZ; yalnizca
   `ad_tahmini` / `ad_guveni` niteligi olarak, tahmin oldugu SOYLENEREK yazilir.

4) KIMLIK SAKLANMAZ, TURETILIR. `kimlik` niteligi okunakliligi icindir; `xml_al`
   onu (uzay, sira)'ya AYRISTIRIR ve `nesne.yaz` baytlari o ikiliden YENIDEN
   uretir. Ayrisamayan bir kimlik REDDEDILIR (sessizce kopyalanmaz).

5) OFSET VE BOY birer KAPIDIR, sus degil. Her alan elemaninin `ofset`i o kaydin
   KENDI baytlari icindeki calisan sayacla ayni olmak zorundadir; kaydin
   `boy`u da yeniden kurulan bayt sayisiyla. Bu iki kapi, uzunluk degistiren
   duzenlemeyi ACIK MESAJLA reddeden mekanizmadir.

6) GOVDE_BOY ZORUNLUDUR ve KOSULSUZ karsilastirilir (2026-09-08). Kok <nesne>
   elemaninin `govde_boy` niteligi, agacin okundugu ORIJINAL govdenin bayt
   sayisidir; `xml_ver_agac` onu HER ZAMAN agacin gercek bayt sayisindan
   hesaplayip yazar, `xml_al` onsuz dosyayi REDDEDER ve yeniden kurulan govde
   ondan farkliysa REDDEDER. Eski surumde nitelik istege bagliydi ve sifir/yok
   olunca kapi hic ateslenmiyordu: boy+ofset+govde_boy'u tutarli guncelleyen
   bir duzenleme (+1/-1 bayt, hatta 13 B'lik bir nesnenin silinmesi) geciyordu.
   ⚠ Bu kapi XML'in KENDI iddiasina bakar; niteligi bilerek degistiren birini
   yakalayamaz. CANLI arsivdeki uzunlukla karsilastiran ikinci, bagimsiz kapi
   nesne_yaz.xml_hazirla'dadir -- yazma yolu her zaman oradan gecer.

=============================================================================
 BU SURUMDE NE YAPILABILIR
=============================================================================
AYNI UZUNLUKTA degisiklik: bir sayiyi degistir, bir referansin kimligini
baska bir varlikla degistir, ham baytlari degistir. UZUNLUK DEGISTIREN
duzenleme (daha uzun metin, fazladan bayt, nesne ekleme/silme) REDDEDILIR --
cunku uzunluk degisince sayac alanlarinin ve YEREL nesne siralarinin yeniden
kurulmasi gerekir (silah_stat.py bunu TEK bir sinif ailesi icin yapiyor;
genellestirmek ayri bir istir). Red sessiz degildir: satir/sutun ve ne
beklendigi yazilir.

UZMAN MODU (v0.17, `xml_al(..., uzunluk_serbest=True)`): uzunluk kapilari
atesleme yerine farki OLCER; agac["uzunluk"] kayit basina eski/yeni boyu,
bayat ofset sayisini ve YEREL siralarin yeniden numaralandigini tasir.
TURETILMIS sira uydurulmaz (nesne.yeniden_numarala), nesne icindeki
KONUMSAL sayaclar da bu araci asar -- ikisi de uyari olarak bildirilir.

Kullanici metinleri INGILIZCE tam cumle; kod yorumlari TURKCE (ASCII).
"""
import json
import os
import re
import struct
import sys
import xml.parsers.expat as EXPAT

BURA = os.path.dirname(os.path.abspath(__file__))
KOK = os.path.dirname(BURA)
if BURA not in sys.path:
    sys.path.insert(0, BURA)

import nesne as N                                          # noqa: E402

__all__ = ["xml_ver", "xml_al", "xml_ver_agac", "XmlHatasi",
           "sema", "ref_ad", "sinif_etiketi", "alan_ad", "SURUM"]

SURUM = 1

# Kendi anlamimiz olan eleman adlari: bir sinif adi bunlardan biriyse eleman
# adi olarak KULLANILMAZ (karisma olmasin), `<sinif crc=...>` yazilir.
AYRILMIS = frozenset(("nesne", "sinif", "onek", "deger", "referans", "ham",
                      "metin", "yuk_son"))
_AD_KALIP = re.compile(r"^[A-Za-z_][A-Za-z0-9_.\-]*$")
_SATIR_HEX = 64                       # uzun hex bu genislikte satirlanir
_METIN_ALT, _METIN_UST = 0x20, 0x7E   # <metin> yalniz basilabilir ASCII tasir
_INF = float("inf")


class XmlHatasi(ValueError):
    """XML okunamadi ya da kabul edilmedi. `satir` / `sutun` doludur (1 tabanli).

    COKMEZ: cagiran bu istisnayi yakalar ve mesaji oldugu gibi gosterebilir --
    mesaj INGILIZCE tam cumledir ve ne beklendigini soyler.
    """

    def __init__(self, mesaj, satir=None, sutun=None):
        self.satir = satir
        self.sutun = sutun
        self.sade = mesaj
        if satir:
            mesaj = "Line %d, column %d: %s" % (satir, sutun or 1, mesaj)
        ValueError.__init__(self, mesaj)


# =====================================================================================
#  TABLOLAR (hepsi ISTEGE BAGLI -- yoksa modul yine calisir, XML daha az okunakli olur)
# =====================================================================================
_SEMA = None
_TAHMIN = None
_REF = None            # (indeks, icid bayt goruntusu) ya da False


def sema(crc):
    """Sinif crc'si -> alan semasi [{ofset, tip, boy, sabit}] ya da None.

    Kaynak nesne_semasi.json (`_sema` alani); yol nesne.veri_yolu ile cozulur:
    pakette src/nesne_veri/, gelistirmede build/. YALNIZ disa aktarmada
    kullanilir; `xml_al` bu tabloya HIC bakmaz.
    """
    global _SEMA
    if _SEMA is None:
        t = {}
        try:
            with open(N.veri_yolu("nesne_semasi.json"), encoding="utf-8") as f:
                ham = json.load(f)
            for k, v in ham.items():
                if k.startswith("_") or not isinstance(v, dict):
                    continue
                s = v.get("_sema")
                if s:
                    t[int(k, 16)] = s
        except Exception:
            pass                       # sema YOKSA her yuk <ham> olur, tur donusu ayni
        _SEMA = t
    return _SEMA.get(int(crc) & 0xFFFFFFFF)


def _tahmin(crc):
    """crc -> (tahmin edilen ad, guven) ya da None. TAHMINDIR, ad degildir."""
    global _TAHMIN
    if _TAHMIN is None:
        t = {}
        try:
            with open(N.veri_yolu("ic_sinif_adlari.json"), encoding="utf-8") as f:
                ham = json.load(f)
            for k, v in (ham.get("siniflar") or {}).items():
                ad = v.get("ad")
                # Kendi kapimiz: crc32(ad) == crc olmayan hicbir ad gosterilmez.
                if ad and N.crc_ad(ad) == int(k, 16):
                    t[int(k, 16)] = (ad, v.get("guven") or "bilinmiyor")
        except Exception:
            pass
        _TAHMIN = t
    return _TAHMIN.get(int(crc) & 0xFFFFFFFF)


def sinif_etiketi(crc):
    """crc -> (eleman_adi ya da None, tahmin ya da None).

    Eleman adi YALNIZCA KANITLI ad tablosundan gelir ve crc32(ad)==crc ile
    dogrulanir; tahminler eleman adi olmaz. Oyunun KENDI meta tablosundan
    (build/sinif_adlari_oyun.json) gelen adlar bu kapiyi kendiliginden gecer --
    o tabloda ad ile crc32'si AYNI kayitta durur.
    """
    crc = int(crc) & 0xFFFFFFFF
    ad = N.sinif_ad(crc)
    if ad and ad not in AYRILMIS and _AD_KALIP.match(ad) and N.crc_ad(ad) == crc:
        return ad, None
    return None, _tahmin(crc)


def sinif_ad_kaynagi(crc):
    """Eleman adinin nereden geldigi: "oyun" | "tablo" | None.

    "oyun" = ad oyunun kendi GlobalMetaFile tablosundan okundu; ucuncu taraf
    sozluk kullanilmadi. XML'de `kaynak="oyun"` niteligi olarak gorunur ve
    GOSTERIMDIR: `xml_al` bu niteligi HIC okumaz.
    """
    try:
        return N.sinif_ad_kaynak(int(crc) & 0xFFFFFFFF)
    except Exception:                       # noqa: BLE001 -- kaynak zorunlu degil
        return None


# =====================================================================================
#  ALAN ADLARI (EL) -- src/nesne_veri/alan_adlari_el.json, KENDI olcumlerimizden
# =====================================================================================
# 7) AD UYDURULMAZ. Bir alan adi bu tabloya ancak KENDI bir modulumuz o ofseti
#    okuyor/yaziyorsa girer (silah_stat, gemi_stat, doku_enjekte2, mesh_yapisal,
#    doku_png, ses_core); tablodaki `kaynak` hangi modulun kanitladigini soyler.
#    Baska bir aracin sema dosyasindan / sozlugunden AD KOPYALANMAZ.
# 8) AD YALNIZCA GORUNUMDUR. `xml_al` ne `ad`/`kaynak` niteligine ne de yoruma
#    bakar; baytlar deger metninden ve hex'ten gelir. Tablo yoksa modul eskisi
#    gibi calisir, XML yalniz daha az okunakli olur.
_EL = None
_TIP_BOY = {"u8": 1, "u16": 2, "u32": 4, "i32": 4, "f32": 4, "u64": 8, "u64ref": 8}
# Nitelik ancak yazilan elemanin tipi tabloya UYUYORSA yapisir; uymayan ad yoruma
# duser (or. sema 6..9'u tek u32 yapmis, bizim olcumumuz dort ayri bayt biliyor).
_TIP_UYUM = {"u32": ("u32", "i32"), "i32": ("u32", "i32"), "f32": ("f32",),
             "metin": ("metin",), "u64ref": ("u64ref", "u64")}
_EL_KAYNAK = "el"
# Guven seviyesi (alan_adlari_el.json `guven`; yoksa "kanitli" -- 58 eski giris bir
# yazicimizin OKUDUGU/YAZDIGI ofsetlerdir). Yalniz kanitli+olcumlu `ad=` olur;
# tahmin `ad_tahmini=` niteligiyle, TAHMIN oldugu soylenerek yazilir.
_GUVEN = ("kanitli", "olcumlu", "tahmin")


def _el_tablo():
    """{crc: {kapsam, cipa, cipa_kaydir, alanlar:{ofset: {...}}}} -- ISTEGE BAGLI."""
    global _EL
    if _EL is None:
        t = {}
        try:
            with open(N.veri_yolu("alan_adlari_el.json"), encoding="utf-8") as f:
                ham = json.load(f)
            for k, v in (ham.get("siniflar") or {}).items():
                alanlar = {}
                for a in v.get("alanlar") or []:
                    ad, tip = a.get("ad"), a.get("tip")
                    # Kendi kapimiz: ASCII ad kalibi + bildigimiz tip, digeri atlanir.
                    if not ad or not _AD_KALIP.match(ad) or tip not in _TIP_BOY:
                        if not (ad and _AD_KALIP.match(ad) and tip == "metin"):
                            continue
                    guven = a.get("guven") or "kanitli"
                    if guven not in _GUVEN:
                        continue                # bilinmeyen guven: ad yazilmaz
                    alanlar[int(a["ofset"])] = {
                        "ad": ad, "tip": tip, "aciklama": a.get("aciklama") or "",
                        "birim": a.get("birim") or "",
                        "gosterim": a.get("gosterim") or "", "guven": guven}
                if alanlar:
                    t[int(k, 16)] = {"kapsam": v.get("kapsam") or "yuk",
                                     "alanlar": alanlar}
        except Exception:
            pass                       # tablo YOKSA XML eskisi gibi adsiz cikar
        _EL = t
    return _EL


def alan_ad_bilgi(crc, ofset, tip, kapsam="yuk"):
    """(sinif crc, ofset, yazilan tip) -> {ad, guven, ...} ya da None."""
    if crc is None:
        return None
    g = _el_tablo().get(int(crc) & 0xFFFFFFFF)
    if not g or g["kapsam"] != kapsam:
        return None
    a = g["alanlar"].get(int(ofset))
    if a and tip in _TIP_UYUM.get(a["tip"], ()):
        return a
    return None


def alan_ad(crc, ofset, tip, kapsam="yuk"):
    """(sinif crc, ofset, yazilan tip) -> ad ya da None. Cipali sinifta nitelik YOK."""
    a = alan_ad_bilgi(crc, ofset, tip, kapsam)
    return a["ad"] if a else None


def _yorum_kac(s):
    """XML yorumuna guvenli metin: `--` dizisi ve kuyruktaki `-` yasaktir."""
    s = str(s).replace("\r", " ").replace("\n", " ")
    while "--" in s:
        s = s.replace("--", "-")
    return s.rstrip("-")


def _el_deger(veri, off, tip, gosterim=""):
    """Adli alanin degerini okunur metne cevirir; baytlar yetmiyorsa None."""
    if tip == "metin":
        # [u32 uzunluk][ASCII] -- silah stat etiketleri ve ses bankasi adi boyle durur.
        if off < 0 or off + 4 > len(veri):
            return None
        n = struct.unpack_from("<I", veri, off)[0]
        if n > 4096 or off + 4 + n > len(veri):
            return None
        h = veri[off + 4:off + 4 + n].rstrip(b"\x00")
        if any(not (_METIN_ALT <= c <= _METIN_UST) for c in h):
            return None
        return '"%s"' % h.decode("ascii")
    boy = _TIP_BOY.get(tip)
    if not boy or off < 0 or off + boy > len(veri):
        return None
    if tip == "f32":
        return _f32_metni(veri[off:off + 4])
    kod = {"u8": "<B", "u16": "<H", "u32": "<I", "i32": "<i",
           "u64": "<Q", "u64ref": "<Q"}[tip]
    v = struct.unpack_from(kod, veri, off)[0]
    if tip in ("u64", "u64ref") or gosterim == "hex":
        return "0x%X" % v
    return str(v)


def _ad_yorumu(crc, veri, taban, girinti, kapsam, atlanan=()):
    """Nitelige yapismamis adlari YORUM satirlarina cevirir. -> [satir].

    Yorumu ayristirici TAMAMEN yok sayar (expat'in yorum isleyicisi kurulmaz), yani
    tur donusune kordur. Bilerek boyle: <onek> ve <ham> bloklarinda gosterecegimiz
    bir alan elemani yok, ama okuyanin bilmesi gereken ad var.

    DEGER yalniz `govde` kapsaminda (yani <onek>) yazilir: orada gosterecek baska
    hicbir eleman yoktur. Kayit icinde (kapsam `yuk`) yorum bir EFSANEDIR, deger
    tasimaz -- tasisaydi tek bir sayi degisikligi XML'de IKI satiri degistirirdi ve
    "bir duzenleme = bir satir" kapisi (test_nesne_xml test_11b) korlesirdi.
    """
    g = _el_tablo().get(int(crc) & 0xFFFFFFFF) if crc is not None else None
    if not g or g["kapsam"] != kapsam:
        return []
    # `taban` = veri[0]'in kayit yuku / govde icindeki ofseti; tablodaki ofsetler o
    # yuke/govdeye goredir, bu yuzden veri icindeki yer (ofset - taban) olur.
    satir = []
    for off in sorted(g["alanlar"]):
        if off in atlanan:
            continue
        a = g["alanlar"][off]
        d = _el_deger(veri, off - taban, a["tip"], a["gosterim"])
        if d is None:
            continue                    # baytlar yetmiyor -> ad da yazilmaz
        guven = a.get("guven") or "kanitli"
        satir.append("0x%02X  %-6s %-21s %s%s%s   %s%s"
                     % (off, a["tip"], a["ad"],
                        ("= " + d) if kapsam == "govde" else "",
                        (" " + a["birim"]) if (a["birim"] and kapsam == "govde") else "",
                        ("" if kapsam == "govde" else ("(" + a["birim"] + ")")
                         if a["birim"] else ""),
                        a["aciklama"],
                        "" if guven == "kanitli" else
                        (" [measured, not proven]" if guven == "olcumlu"
                         else " [GUESS - name is a hypothesis]")))
    if not satir:
        return []
    out = ["%s<!-- named byte ranges below (Workshop's own schema, labels only):"
           % girinti]
    out += ["%s     %s" % (girinti, _yorum_kac(s)) for s in satir]
    out.append("%s-->" % girinti)
    return out


def ref_ad(kimlik):
    """u64 varlik kimligi -> {"ad", "sinif", "forge"} ya da None.

    BIZIM USTUNLUGUMUZ: Anvil bu sutunda hex gosterir. Kaynak
    src/varlik_indeks.bin (2.165.452 varlik). Indeks yoksa None doner ve XML'de
    yalnizca kimlik yazilir -- uydurma ad KONMAZ.

    Uyelik testi icin icid kolonunun HAM BAYT goruntusunde `bytes.find`
    kullanilir (varlik_indeks'in kendi suzgec taramasindaki desen): 2,1M satirlik
    bir sozluk ya da numpy gerekmez, arama C hizindadir.
    """
    global _REF
    if _REF is None:
        try:
            import varlik_indeks as VI
            ix = VI.yukle()
            _REF = (ix, ix._icid.tobytes(), {}) if ix is not None else False
        except Exception:
            _REF = False
    if _REF is False:
        return None
    ix, ham, onbellek = _REF
    v = int(kimlik) & 0xFFFFFFFFFFFFFFFF
    if v in onbellek:
        return onbellek[v]
    out = None
    hedef = struct.pack("<Q", v)
    q = ham.find(hedef)
    while q >= 0:
        if q % 8 == 0:
            s = ix._satir(q // 8)
            out = {"ad": s["ad"] or s["etiket"], "sinif": s["sinif"],
                   "forge": s["forge"]}
            break
        q = ham.find(hedef, q + 1)
    if len(onbellek) < 200000:
        onbellek[v] = out
    return out


# =====================================================================================
#  YARDIMCILAR
# =====================================================================================
def _kac(s):
    """XML metin/nitelik kacisi."""
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _hex(b):
    return b.hex().upper()


def _hex_satirli(b, girinti):
    """Uzun hex'i satirlara boler (okunakli); okuyucu bosluklari atar."""
    h = _hex(b)
    if len(h) <= _SATIR_HEX:
        return h
    parca = [h[i:i + _SATIR_HEX] for i in range(0, len(h), _SATIR_HEX)]
    return "\n" + "".join(girinti + p + "\n" for p in parca) + girinti[:-2]


def _f32_metni(h):
    """4 bayt -> AYNI baytlari geri veren EN KISA ondalik metin.

    repr(1.1'in float32'si) = '1.100000023841858' okunakli degil; en kisa %g
    gosterimini deneriz ve YALNIZCA geri paketleyince ayni 4 bayti verirse
    kullaniriz. Yani kisaltma bir tahmin degil, dogrulanmis bir esitliktir.
    """
    v = struct.unpack("<f", h)[0]
    for p in range(1, 10):
        s = "%.*g" % (p, v)
        try:
            if struct.pack("<f", float(s)) != h:
                continue
        except (ValueError, OverflowError):
            # Yuvarlama float32 tavanini asti (or. 3.403e+38). Bu ADAY duser,
            # arama DEVAM eder -- `break` deseydik daha uzun ama gecerli
            # gosterimleri kaybederdik.
            continue
        # '%g' 50.0'i '5e+01' yazar; repr AYNI float64'u verdigi icin AYNI 4 bayta
        # paketlenir -- ustel gosterim gereksizse okunakli olani secilir.
        d = repr(float(s))
        if "e" in s and "e" not in d:
            return d
        return d if len(d) < len(s) else s
    return repr(v)


def _kimlik_coz(idd, icid):
    """u64 -> (uzay, sira) ya da (None, None). YALNIZ nesne.py'nin acik API'siyle."""
    idd = int(idd) & 0xFFFFFFFFFFFFFFFF
    if idd >> 63:
        i = idd & 0xFFFF
        try:
            if N.kimlik("turetilmis", i, icid) == idd:
                return "turetilmis", i
        except ValueError:
            pass
    else:
        i = idd - N.YEREL_TABAN
        if 0 <= i <= 0xFFFF and N.kimlik("yerel", i) == idd:
            return "yerel", i
    return None, None


# =====================================================================================
#  SEMA UYGULAMA (yalniz disa aktarmada)
# =====================================================================================
def _coz(sm, yuk):
    """Yuk -> [(ofset, tip, ham_dilim, deger)] ya da None (sema uymuyor).

    ⭐ DEGISMEZ KURAL: bolumleme geri paketlendiginde ORIJINAL baytlari
    vermiyorsa None doneriz ve yuk butun halinde <ham> olur. Sema "yaklasik
    uyuyor" diye bayt uydurulmaz.
    """
    out = []
    p = 0
    n = len(yuk)
    try:
        for a in sm:
            o, b, t = a["ofset"], a.get("boy"), a["tip"]
            if o != p:
                return None                     # sema kendi icinde bosluklu: guvenme
            if t == "metin" and b is None:
                if o + 4 > n:
                    return None
                b = 4 + struct.unpack_from("<I", yuk, o)[0]
            if b is None or o + b > n:
                return None
            h = yuk[o:o + b]
            if t == "f32":
                v = struct.unpack("<f", h)[0]
                # ⛔ OLCULEN TUZAK (2026-09-08, Charleston 0x22ED9BDBBC1): NaN'in
                # ISARET BITI ve yuku baytta duruyor ama METINDE durmuyor.
                # `struct.pack("<f", v) == h` kapisi NaN'i GECIRIYORDU (Python
                # isareti korur), sonra float("nan") POZITIF NaN uretip 0xFF'i
                # 0x7F yapiyordu -- tur donusu bir govdede kirilmisti. Sonlu
                # olmayan her deger artik HAM tasinir: NaN/Inf bir SAYI degil,
                # bir BIT DESENIDIR, metne cevrilmesi kayipsiz degildir.
                if v != v or v in (_INF, -_INF) or struct.pack("<f", v) != h:
                    t = "bayt"
            elif t == "u32":
                v = struct.unpack("<I", h)[0]
            elif t == "i32":
                v = struct.unpack("<i", h)[0]
            elif t == "u64ref":
                v = struct.unpack("<Q", h)[0]
            elif t == "metin":
                g = h[4:]
                if any(c < _METIN_ALT or c > _METIN_UST for c in g):
                    t = "bayt"                  # basilamayan bayt: XML'e sokmayiz
                else:
                    v = g.decode("ascii")
            else:
                t = "bayt"
            if t == "bayt":
                v = None
            out.append((o, t, h, v))
            p = o + b
    except Exception:
        return None
    if p < n:
        out.append((p, "bayt", yuk[p:], None))
    # KAPI: cozulen parcalarin birlesimi ORIJINAL yuk olmali.
    if b"".join(x[2] for x in out) != yuk:
        return None
    return out


def _birlestir(alanlar):
    """Ardisik `bayt` alanlarini tek <ham>'da toplar (XML sismesin)."""
    out = []
    for o, t, h, v in alanlar:
        if t == "bayt" and out and out[-1][1] == "bayt":
            po, pt, ph, pv = out[-1]
            out[-1] = (po, pt, ph + h, None)
        else:
            out.append((o, t, h, v))
    return out


# =====================================================================================
#  DISA AKTARMA
# =====================================================================================
_BASLIK = """<?xml version="1.0" encoding="utf-8"?>
<!--
  Workshop - object dump of one inner file of the game archive (read-only export).

  WHAT THIS IS
    The inner file is a run of records. One record is one object:
        [u64 identity][u32 class crc][payload]
    Every <sinif> element below (or the element named after a proven class) is
    one of those records. Class names are read from the game's own metadata
    table; no third-party dictionary is used. An element that carries
    kaynak="oyun" got its name from that table, where the name sits next to
    its own crc32. The name is a label: reading this file back uses the crc.

  WHAT YOU MAY EDIT
    The text of <deger>, <metin> and <ham>, and the kimlik of <referans> - as
    long as the byte length stays exactly the same.

  WHAT THIS VERSION REFUSES
    Any edit that changes a length: a longer or shorter text, an extra or
    missing byte, an added or removed object. Changing a length also means
    rebuilding count fields and re-numbering local object ordinals, so this
    version stops with an explicit message instead of writing something it
    cannot prove.

  AFTER YOU EDIT
    This file is only the text form of the object. Installing it back into the
    game is a separate, guarded step in Workshop - this export never writes to
    the game archive, and neither does reading this file back.

  HOW TO READ IT
    crc         the class identity. The hex is always shown. When a class name
                is proven, it is used as the element name as well.
    ad_tahmini  a GUESSED class name from a crc32 dictionary attack. It is a
                guess, not a proven name, which is why it never becomes the
                element name.
    kimlik      the object identity. It is not stored in the archive: it is
                computed from (identity space, ordinal, inner file id), and it
                is re-derived when this file is read back.
    ofset       byte offset inside this object's own payload.
    boy         the payload byte length of this object - a safety gate.
    ad          the field's name, shown when Workshop's own tools already read or
                write that exact offset (weapon and ship stats, texture
                descriptors, mesh and material layouts, the sound fmt chunk).
                No name is invented and no other tool's schema file is used:
                what we cannot prove keeps its offset and type and no name.
    kaynak      where the name came from. "el" is Workshop's own hand-written
                table, src/nesne_veri/alan_adlari_el.json, which also records
                which module measured each offset.
    guven       "olcumlu" marks a name backed by a value-distribution
                measurement over the game's own data (ranges, monotonic series,
                orthonormal matrices) but not yet by a Workshop writer; a name
                without guven was proven by a Workshop reader/writer.
    ad_tahmini  a field name that is only a HYPOTHESIS. It never appears as
                ad=; the measurement behind it was consistent but no
                independent cross-check confirmed it.
                ad, ad_tahmini, kaynak and guven are LABELS ONLY - reading this
                file back ignores all of them, and ignores the "named byte
                ranges" comments as well. The bytes always come from the values
                and the hex.
    <ham>       bytes with no proven field layout. They are carried through
                unchanged; no field is invented. When a name is known for a byte
                range inside such a block, it is shown in a comment above it.
    <referans>  a u64 asset id. The text is that asset's name, taken from the
                Workshop asset index - Anvil shows only hex in this column.
                Only the kimlik is read back; the name and hedef_sinif are
                refreshed the next time this object is exported.
-->
"""


def _kayit_ac(d, icid, adlar, girinti, out, sayac=None):
    """Kayit elemanini acar ve `yuk` alanlarini yazar. -> eleman adi."""
    crc = int(d["sinif_crc"]) & 0xFFFFFFFF
    ad, tah = sinif_etiketi(crc)
    etiket = ad or "sinif"
    nit = ['crc="0x%08X"' % crc,
           'kimlik="0x%X"' % N.kimlik(d["kimlik_turu"], d["sira"], icid),
           'boy="%d"' % (len(d["yuk"]) + len(d["yuk_son"]))]
    # `kaynak` DAIMA crc/kimlik/boy'dan SONRA gelir: mevcut kapilar bu uc niteligi
    # cakili sirayla esliyor (test_nesne_xml _KAYIT_SATIR), araya girmek onlari
    # sessizce kor ederdi. Nitelik GOSTERIMDIR, `xml_al` onu HIC okumaz.
    if ad and sinif_ad_kaynagi(crc) == "oyun":
        nit.append('kaynak="oyun"')
    if tah:
        nit.append('ad_tahmini="%s" ad_guveni="%s"' % (_kac(tah[0]), _kac(tah[1])))
    if not d["yuk"] and not d["yuk_son"] and not d["cocuklar"]:
        out.append("%s<%s %s/>" % (girinti, etiket, " ".join(nit)))
        return None                     # kendi kendini kapatan eleman
    out.append("%s<%s %s>" % (girinti, etiket, " ".join(nit)))
    _alanlar_yaz(d["yuk"], 0, crc, adlar, girinti + "  ", out,
                 sema_uygula=not d["cocuklar"] and not d["yuk_son"], sayac=sayac)
    return etiket


def _alanlar_yaz(yuk, taban, crc, adlar, girinti, out, sema_uygula=True, sayac=None):
    """Bir yuk parcasini alan elemanlarina cevirir.

    NITELIK SIRASI YUKLUDUR: `ofset` ve `tip` ONCE gelir, `ad`/`kaynak` SONRA.
    Ad niteligi YALNIZ <deger>'e konur. <metin> ve <referans> icin nitelik seti
    OLDUGU GIBI KALIR: bu iki elemani mevcut kapilar bastan sona cakili kalipla
    esliyor (test_nesne_xml test_05 `<metin ofset="\\d+">`, test_11
    `kimlik="0x..." hedef_sinif="...">`), araya nitelik sokmak baytlari bozmaz ama
    o kapilari sessizce kor eder. O iki elemanin adi asagidaki YORUMDA gorunur.
    """
    if not yuk:
        return
    parca = None
    if sema_uygula:
        sm = sema(crc)
        if sm:
            parca = _coz(sm, yuk)
    if parca is None:
        parca = [(0, "bayt", yuk, None)]
    else:
        parca = _birlestir(parca)
    bas = len(out)
    yapisan = set()

    def _ad_nit(off, tip):
        """-> ' ad="..." kaynak="el"[ guven="olcumlu"]' / ' ad_tahmini="..." kaynak="el"'
        ya da ''. Ad TAKI'dir, kapi degil; xml_al ucunu de yok sayar."""
        a = alan_ad_bilgi(crc, off, tip, "yuk")
        if not a:
            return ""
        yapisan.add(off)
        guven = a.get("guven") or "kanitli"
        if guven == "tahmin":
            if sayac is not None:
                sayac["tahmin"] += 1
            return ' ad_tahmini="%s" kaynak="%s"' % (_kac(a["ad"]), _EL_KAYNAK)
        if sayac is not None:
            sayac["adli"] += 1
        if guven == "olcumlu":
            return ' ad="%s" kaynak="%s" guven="olcumlu"' % (_kac(a["ad"]), _EL_KAYNAK)
        return ' ad="%s" kaynak="%s"' % (_kac(a["ad"]), _EL_KAYNAK)

    for o, t, h, v in parca:
        off = taban + o
        if sayac is not None and t != "bayt":
            sayac["alan"] += 1
        if t == "bayt":
            out.append('%s<ham ofset="%d">%s</ham>'
                       % (girinti, off, _hex_satirli(h, girinti + "  ")))
        elif t == "f32":
            out.append('%s<deger ofset="%d" tip="f32"%s>%s</deger>'
                       % (girinti, off, _ad_nit(off, "f32"), _f32_metni(h)))
        elif t in ("u32", "i32"):
            out.append('%s<deger ofset="%d" tip="%s"%s>%d</deger>'
                       % (girinti, off, t, _ad_nit(off, t), v))
        elif t == "metin":
            out.append('%s<metin ofset="%d">%s</metin>' % (girinti, off, _kac(v)))
        elif t == "u64ref":
            s = ref_ad(v) if (adlar and v) else None
            if s and s.get("ad"):
                out.append('%s<referans ofset="%d" kimlik="0x%X" hedef_sinif="%s">'
                           '%s</referans>'
                           % (girinti, off, v, _kac(s.get("sinif") or ""),
                              _kac(s["ad"])))
            else:
                out.append('%s<referans ofset="%d" kimlik="0x%X"/>' % (girinti, off, v))
    # Nitelige yapismayan adlar (ham blok icinde kalanlar) yoruma gider.
    yorum = _ad_yorumu(crc, yuk, taban, girinti, "yuk", yapisan)
    if yorum:
        out[bas:bas] = yorum
        if sayac is not None:
            sayac["yorum"] += len(yorum) - 2


def _onek_yaz(onek, out, crc=None, sayac=None):
    """Ilk kayittan ONCEKI baytlar = kok nesnenin kayitlardan once gelen alanlari.

    Ayri fonksiyon, cunku BIR KAPI: testler bunu devre disi birakip tur donusunun
    gercekten dustugunu olcuyor (onek yazilmazsa govde kisalir).
    """
    if onek:
        # Ic dosyanin KAYITSIZ govdesi de buraya duser (gemi stat, doku tanimlayicisi,
        # ses bankasi). Orada gosterecek bir alan elemani YOK -- adlar yoruma yazilir;
        # yorum ayristiriciya gorunmez, bu yuzden tur donusu degismez.
        yorum = _ad_yorumu(crc, onek, 0, "  ", "govde")
        if yorum:
            out.extend(yorum)
            if sayac is not None:
                sayac["yorum"] += len(yorum) - 2
        out.append('  <onek boy="%d">%s</onek>'
                   % (len(onek), _hex_satirli(onek, "    ")))


def xml_ver_agac(agac, adlar=True):
    """Nesne agaci -> XML metni. SAF fonksiyon: forge acmaz, dosyaya yazmaz.

    `adlar=False` referans adlarini cozmez (varlik indeksi ~200 MB bellek ister);
    baytlar ve tur donusu bundan ETKILENMEZ, yalnizca okunakliliktan feragat
    edilir.
    """
    icid = int(agac["icid"])
    out = [_BASLIK.rstrip("\n")]
    if agac.get("bicim") == "supheli":
        out.append("<!-- WARNING: the record split of this inner file does not "
                   "satisfy the record invariants (overlapping records or repeated "
                   "ordinals).\n     The bytes round-trip exactly, but the object "
                   "tree below must not be treated as proven. -->")
    scrc = agac.get("sinif")
    nit = ['gid="0x%X"' % int(agac["gid"] or 0), 'icid="0x%X"' % icid]
    if scrc is not None:
        sad, stah = sinif_etiketi(scrc)
        nit.append('sinif_crc="0x%08X"' % (int(scrc) & 0xFFFFFFFF))
        if sad:
            nit.append('sinif="%s"' % _kac(sad))
            # Kayitsiz ic dosyada (gemi stat girislerinin 10'u boyle) HIC kayit
            # elemani yoktur; kaynak ancak burada gorunur.
            if sinif_ad_kaynagi(scrc) == "oyun":
                nit.append('kaynak="oyun"')
        elif stah:
            nit.append('sinif_tahmini="%s" sinif_guveni="%s"'
                       % (_kac(stah[0]), _kac(stah[1])))
    nit.append('bicim="%s"' % _kac(agac.get("bicim") or "bilinmiyor"))
    # HER ZAMAN yazilir ve agacin GERCEK bayt sayisidir (bkz. _govde_boyu).
    nit.append('govde_boy="%d"' % _govde_boyu(agac))
    nit.append('surum="%d"' % SURUM)
    out.append("<nesne %s>" % " ".join(nit))
    sayac = {"alan": 0, "adli": 0, "yorum": 0, "tahmin": 0}
    _onek_yaz(bytes(agac.get("onek") or b""), out, scrc, sayac)

    # DERINLIK-ONCELIKLI, OZYINELEMESIZ -- nesne.yaz ile AYNI sira.
    # Cerceve = [dugum, sonraki_cocuk, eleman_adi]. Dugum sozlugune HICBIR SEY
    # yazilmaz: cagiranin agaci bu islemden degismeden cikar.
    cerceve = []
    for kok in agac["kok"]:
        cerceve.append([kok, -1, None])
        while cerceve:
            d, i, etiket = cerceve[-1]
            girinti = "  " * len(cerceve)
            if i < 0:
                cerceve[-1][2] = _kayit_ac(d, icid, adlar, girinti, out, sayac)
                cerceve[-1][1] = 0
                continue
            coc = d["cocuklar"]
            if i < len(coc):
                cerceve[-1][1] = i + 1
                cerceve.append([coc[i], -1, None])
                continue
            if etiket is not None:
                if d["yuk_son"]:
                    out.append('%s  <yuk_son>' % girinti)
                    _alanlar_yaz(d["yuk_son"], len(d["yuk"]), d["sinif_crc"], adlar,
                                 girinti + "    ", out, sema_uygula=False, sayac=sayac)
                    out.append('%s  </yuk_son>' % girinti)
                out.append("%s</%s>" % (girinti, etiket))
            cerceve.pop()
    out.append("</nesne>")
    out.append("")
    # KAPSAM SATIRI: sayilar OLCULUR, ezberlenmez. Basligin hemen ardina girer ki
    # okuyan once "ne kadari adli" gorsun.
    out.insert(1, "<!-- FIELD NAMES: %d of %d field elements carry a name%s "
                  "(Workshop's own schema, src/nesne_veri/alan_adlari_el.json - no "
                  "third-party schema file is used). Names are labels only: reading "
                  "this file back ignores every ad= and kaynak= attribute. -->"
               % (sayac["adli"], sayac["alan"],
                  (("; %d more named byte ranges are noted in comments"
                    % sayac["yorum"]) if sayac["yorum"] else "")
                  + (("; %d field elements carry only a GUESSED name (ad_tahmini)"
                      % sayac["tahmin"]) if sayac["tahmin"] else "")))
    return "\n".join(out)


def xml_ver(gid, icid=None, forge=None, adlar=True):
    """CANLI forge'daki bir ic dosyayi XML metnine cevirir. SALT OKUMA.

    `icid` verilmezse gid ile ayni kimlikli ic dosya, yoksa ilki secilir.
    `forge` bir yol verilirse nesne.oku kendi salt-okuma taniticisini acar ve
    KAPATIR. Oyun arsivine tek bayt yazilmaz.
    """
    return xml_ver_agac(N.oku(gid, icid=icid, forge=forge), adlar=adlar)


# =====================================================================================
#  ICE AKTARMA
# =====================================================================================
class _El(object):
    __slots__ = ("tag", "nit", "satir", "sutun", "metin", "coc")

    def __init__(self, tag, nit, satir, sutun):
        self.tag = tag
        self.nit = nit
        self.satir = satir
        self.sutun = sutun
        self.metin = []
        self.coc = []


def _ayristir(metin):
    """Metin -> kok _El. Bozuk XML -> XmlHatasi (satir/sutun ile)."""
    p = EXPAT.ParserCreate()
    kok = []
    yigin = []

    def bas(tag, nit):
        e = _El(tag, nit, p.CurrentLineNumber, p.CurrentColumnNumber + 1)
        if yigin:
            yigin[-1].coc.append(e)
        else:
            kok.append(e)
        yigin.append(e)

    def son(_tag):
        yigin.pop()

    def veri(d):
        if yigin:
            yigin[-1].metin.append(d)

    def yasak(*_a, **_k):
        raise XmlHatasi("This file declares an entity or a DTD; the object XML "
                        "does not use either and they are not accepted.",
                        p.CurrentLineNumber, p.CurrentColumnNumber + 1)

    p.StartElementHandler = bas
    p.EndElementHandler = son
    p.CharacterDataHandler = veri
    p.EntityDeclHandler = yasak
    p.StartDoctypeDeclHandler = yasak
    try:
        p.Parse(metin.encode("utf-8") if isinstance(metin, str) else metin, 1)
    except EXPAT.ExpatError as e:
        raise XmlHatasi("The XML is not well-formed (%s)."
                        % EXPAT.ErrorString(e.code), e.lineno, e.offset + 1)
    if not kok:
        raise XmlHatasi("The XML is empty; a <nesne> element was expected.", 1, 1)
    return kok[0]


def _hata(el, mesaj):
    return XmlHatasi(mesaj, el.satir, el.sutun)


def _nit(el, ad, zorunlu=True):
    v = el.nit.get(ad)
    if v is None and zorunlu:
        raise _hata(el, "The <%s> element is missing the %s attribute."
                    % (el.tag, ad))
    return v


def _tam(el, ad, zorunlu=True, taban=0):
    v = _nit(el, ad, zorunlu)
    if v is None:
        return None
    try:
        return int(v.strip(), taban)
    except ValueError:
        raise _hata(el, "The %s attribute of <%s> is %r, which is not a number."
                    % (ad, el.tag, v))


def _hex_al(el):
    h = "".join("".join(el.metin).split())
    if len(h) % 2:
        raise _hata(el, "The hex bytes of <%s> have an odd number of digits (%d); "
                        "every byte needs two digits." % (el.tag, len(h)))
    try:
        return bytes.fromhex(h)
    except ValueError:
        raise _hata(el, "The content of <%s> is not hexadecimal." % el.tag)


# -- ayri fonksiyonlar: her biri BIR kapi; testler bunlari tek tek sabote eder --
def _ofset_kapisi(el, beklenen, gorulen):
    if gorulen is not None and gorulen != beklenen:
        raise _hata(el, "This element says ofset=\"%d\" but %d bytes of this object "
                        "come before it. Something was inserted, removed or "
                        "re-ordered; fix the order or the ofset value."
                    % (gorulen, beklenen))


def _boy_kapisi(el, beklenen, gorulen, etiket):
    if beklenen != gorulen:
        raise _hata(el, "This edit changes the length of object %s from %d to %d "
                        "bytes. This version can only apply edits that keep the same "
                        "byte length, because a length change also has to rebuild the "
                        "count fields and re-number the local object ordinals. Keep "
                        "the value the same width and try again."
                    % (etiket, beklenen, gorulen))


def _govde_kapisi(el, beklenen, gorulen):
    """KOSULSUZ: `beklenen` (kokteki govde_boy) her zaman bir sayidir, 0 dahil.

    Eski surum `if beklenen and ...` diyordu: nitelik 0 ya da eksikse kapi hic
    calismiyordu ve tutarli guncellenmis bir +1/-1 bayt duzenlemesi geciyordu."""
    if beklenen != gorulen:
        raise _hata(el, "This edit changes the length of the object body from %d to %d "
                        "bytes; only same-length edits can be written back. Keep every "
                        "field the same byte length - adding or removing an object, or "
                        "changing the bytes in front of the first record, is not "
                        "supported yet." % (beklenen, gorulen))


def _govde_boyu(agac):
    """Agacin YAZILACAK bayt sayisi -- nesne.yaz ile ayni sayim, baytlari kurmadan.

    `xml_ver_agac` kokteki govde_boy'u BURADAN alir, agacin `govde_boy` alanindan
    DEGIL: elle kurulmus bir agacta o alan 0 ya da eksik olabilir (test_10'daki
    1.500 derinlikli agac), oysa XML'in tasidigi sayi agacin GERCEK uzunlugu
    olmali ki `xml_al` onu kosulsuz karsilastirabilsin.
    """
    n = len(bytes(agac.get("onek") or b""))
    for d, _dr in N.gez(agac):
        n += N.BASLIK_BOY + len(d["yuk"]) + len(d["yuk_son"])
    return n


def _alan_bayt(el):
    """Bir alan elemani -> tasidigi baytlar. Sema OKUNMAZ: eleman kendini anlatir."""
    t = el.tag
    if t == "ham":
        return _hex_al(el)
    if t == "referans":
        v = _tam(el, "kimlik", taban=0)
        if not 0 <= v <= 0xFFFFFFFFFFFFFFFF:
            raise _hata(el, "The kimlik of <referans> does not fit in 8 bytes.")
        return struct.pack("<Q", v)
    if t == "metin":
        s = "".join(el.metin)
        try:
            g = s.encode("ascii")
        except UnicodeEncodeError:
            raise _hata(el, "A <metin> field can only hold ASCII characters; %r is "
                            "not ASCII." % s)
        return struct.pack("<I", len(g)) + g
    if t == "deger":
        tip = _nit(el, "tip")
        ham = "".join(el.metin).strip()
        # Once TIP dogrulanir: bilinmeyen bir tipte once "sayi degil" demek
        # kullaniciyi yanlis yere bakmaya gonderirdi.
        if tip not in ("f32", "i32", "u32", "u64ref"):
            raise _hata(el, "tip=\"%s\" is not a type this version knows; use f32, "
                            "i32, u32 or u64ref." % tip)
        if tip == "f32":
            try:
                return struct.pack("<f", float(ham))
            except (ValueError, OverflowError):
                raise _hata(el, "The value %r of this f32 field is not a 32-bit "
                                "floating point number." % ham)
        try:
            v = int(ham, 0)
        except ValueError:
            raise _hata(el, "The value %r of this %s field is not a whole number."
                        % (ham, tip))
        try:
            if tip == "u32":
                return struct.pack("<I", v)
            if tip == "i32":
                return struct.pack("<i", v)
            return struct.pack("<Q", v)              # u64ref
        except struct.error:
            raise _hata(el, "The value %d does not fit in a %s field." % (v, tip))
    raise _hata(el, "<%s> is not an element this version knows inside an object; "
                    "use <deger>, <referans>, <metin>, <ham> or a nested object."
                % t)


_ALAN = frozenset(("ham", "deger", "referans", "metin"))


def _kayit_mi(el):
    return el.tag not in _ALAN and el.tag not in ("onek", "yuk_son")


def _sinif_crc(el):
    """Kayit elemani -> sinif crc. Eleman adi ile `crc` niteligi CAKISAMAZ."""
    crc = _tam(el, "crc", zorunlu=(el.tag == "sinif"), taban=0)
    if el.tag != "sinif":
        ad_crc = N.crc_ad(el.tag)
        if crc is None:
            crc = ad_crc
        elif (crc & 0xFFFFFFFF) != ad_crc:
            raise _hata(el, "The element name %s hashes to 0x%08X but the crc "
                            "attribute says 0x%08X. Fix the name, or drop it and "
                            "use <sinif crc=\"0x%08X\">."
                        % (el.tag, ad_crc, crc & 0xFFFFFFFF, crc & 0xFFFFFFFF))
    if not 0 <= crc <= 0xFFFFFFFF:
        raise _hata(el, "The crc attribute does not fit in 4 bytes.")
    return crc & 0xFFFFFFFF


def _kayit_al(el, icid, topla=None):
    """Kayit elemani -> nesne.py dugumu (ozyinelemesiz, ic ice kayitlari destekler).

    `topla` verilirse (uzman modu / `uzunluk_serbest`) uzunluk ve ofset kapilari
    ATESLEMEZ: farklar `topla`ya YAZILIR ve cagiran onlari uyariya cevirir. Kapi
    fonksiyonlarinin KENDISI degismedi (testler onlari tek tek sabote ediyor)."""
    crc = _sinif_crc(el)
    idd = _tam(el, "kimlik", taban=0)
    uzay, sira = _kimlik_coz(idd, icid)
    if uzay is None:
        raise _hata(el, "The object identity 0x%X cannot be derived for inner file "
                        "0x%X. Identities are not stored in the archive: they are "
                        "computed from (identity space, ordinal, inner file id), so "
                        "only an identity this rule can produce is accepted." % (idd, icid))
    boy = _tam(el, "boy")
    yuk, yuk_son, coc = [], [], []
    hedef = yuk
    tipli = False
    # ONCE BUTUN ALANLARI TOPLA, SONRA KAPILARI SIRAYLA CALISTIR. Sebep: ortada
    # uzunlugu degistiren bir duzenleme varsa ondan SONRAKI her ofset de kayar;
    # ofset kapisi once atesleseydi kullanici "yanlis ofset" mesaji alirdi, oysa
    # gercek sebep UZUNLUKTUR. Once boy kapisi konusur, sonra ofset kapisi.
    for c in el.coc:
        if c.tag == "yuk_son":
            for cc in c.coc:
                if _kayit_mi(cc):
                    raise _hata(cc, "A nested object cannot live inside <yuk_son>; "
                                    "children are written before <yuk_son>.")
                yuk_son.append((cc, _alan_bayt(cc)))
                tipli = tipli or cc.tag != "ham"
            hedef = None
            continue
        if _kayit_mi(c):
            coc.append(c)
            hedef = yuk_son
            continue
        if hedef is None:
            raise _hata(c, "This field comes after <yuk_son>; every field of an "
                           "object belongs either before its children or inside "
                           "<yuk_son>.")
        hedef.append((c, _alan_bayt(c)))
        tipli = tipli or c.tag != "ham"
    yb = b"".join(b for _c, b in yuk)
    ysb = b"".join(b for _c, b in yuk_son)
    gor = len(yb) + len(ysb)
    if topla is None:
        _boy_kapisi(el, boy, gor, "0x%X (class 0x%08X)" % (idd, crc))
    elif boy != gor:
        topla["kayitlar"].append({"kimlik": idd, "crc": crc, "uzay": uzay, "sira": sira,
                                  "eski_boy": boy, "yeni_boy": gor,
                                  "fark": gor - boy})
    sayac = 0
    for c, b in yuk + yuk_son:
        o = _tam(c, "ofset", zorunlu=False)
        if topla is None:
            _ofset_kapisi(c, sayac, o)
        elif o is not None and o != sayac:
            # Uzunluk degistiginde ONDAN SONRAKI her ofset tanim geregi bayattir;
            # sayilir, reddedilmez -- bir sonraki disa aktarim tazesini yazar.
            topla["ofset_uyusmazlik"] += 1
        sayac += len(b)
    d = N.dugum_kur(uzay, sira, crc, yb, cocuklar=[], yuk_son=ysb,
                    opak=not tipli)
    return d, coc


def xml_al(xml_metni, uzunluk_serbest=False):
    """XML metni -> nesne agaci (nesne.yaz(agac) GOVDE baytlarini uretir).

    Bozuk XML COKERTMEZ: XmlHatasi atar ve `satir` / `sutun` ile ne beklendigini
    soyler. Uzunluk degistiren duzenleme ACIK MESAJLA reddedilir -- UZMAN MODU
    (`uzunluk_serbest=True`) disinda: o modda uzunluk/ofset kapilari atesleme
    yerine farki OLCER ve `agac["uzunluk"]` altinda bildirir. `govde_boy` niteligi
    IKI modda da ZORUNLUDUR (olmadan fark olculemez).
    """
    topla = ({"kayitlar": [], "ofset_uyusmazlik": 0, "govde": None,
              "yeniden_numaralanan": 0, "turetilmis_bosluk": []}
             if uzunluk_serbest else None)
    kok = _ayristir(xml_metni)
    if kok.tag != "nesne":
        raise _hata(kok, "The root element is <%s>; an object dump starts with "
                         "<nesne>." % kok.tag)
    icid = _tam(kok, "icid", taban=0)
    gid = _tam(kok, "gid", zorunlu=False, taban=0)
    scrc = _tam(kok, "sinif_crc", zorunlu=False, taban=0)
    onek = b""
    dugumler = []
    kayitlar = []
    for c in kok.coc:
        if c.tag == "onek":
            if kayitlar:
                raise _hata(c, "<onek> must come before the objects; it is the run "
                               "of bytes in front of the first record.")
            onek = _hex_al(c)
            continue
        if not _kayit_mi(c):
            raise _hata(c, "<%s> cannot sit directly inside <nesne>; only <onek> and "
                           "objects can." % c.tag)
        kayitlar.append(c)
    # OZYINELEMESIZ on-sira gecis (derinligi binlerce olan agac da okunur).
    yigin = [(c, dugumler) for c in reversed(kayitlar)]
    while yigin:
        el, liste = yigin.pop()
        d, coc = _kayit_al(el, icid, topla)
        liste.append(d)
        for c in reversed(coc):
            yigin.append((c, d["cocuklar"]))
    agac = {"ok": True, "gid": gid, "icid": icid, "sinif": scrc,
            "sinif_ad": N.sinif_ad(scrc) if scrc is not None else None,
            "onek": onek, "kok": dugumler,
            "opak_bayt": sum(len(d["yuk"]) + len(d["yuk_son"])
                             for d, _dr in N.gez(dugumler)),
            "bicim": kok.nit.get("bicim") or "bilinmiyor",
            "uyari": [], "atilan_aday": 0, "kaynak": "xml"}
    if topla is not None:
        # EKLEME/SILME sonrasi YEREL sayaclar 0..N-1 olmali (olculdu: 6.145/6.145
        # temiz govdede yerel indeks yazma sirasidir). TURETILMIS sira boyle
        # DEGILDIR ve uydurulmaz: bosluk varsa yalnizca BILDIRILIR.
        yerel, turet = [], []
        for d, _dr in N.gez(dugumler):
            (yerel if d["kimlik_turu"] == "yerel" else turet).append(d["sira"])
        if yerel != list(range(len(yerel))):
            topla["yeniden_numaralanan"] = N.yeniden_numarala(agac, zorla=True)
        if sorted(turet) != list(range(len(turet))):
            eksik = sorted(set(range(len(turet))) - set(turet))
            topla["turetilmis_bosluk"] = eksik[:20]
    govde = N.yaz(agac)
    agac["govde_boy"] = len(govde)
    # ZORUNLU nitelik: yoksa kapi calisamaz, dosya reddedilir. Kayit duzeyindeki
    # hatalar (yukarida) once konusur; buraya gelen dosyanin kayitlari saglamdir.
    if kok.nit.get("govde_boy") is None:
        raise _hata(kok, "The <nesne> element is missing the govde_boy attribute, which "
                         "is the byte length of the object body this file was exported "
                         "from. Every export writes it and it is the gate that catches "
                         "length-changing edits, so a file without it cannot be written "
                         "back. Put it back (it was govde_boy=\"%d\" if nothing changed) "
                         "or export the object again." % len(govde))
    if topla is None:
        _govde_kapisi(kok, _tam(kok, "govde_boy"), len(govde))
    else:
        topla["govde"] = [_tam(kok, "govde_boy"), len(govde)]
        # DAIMA takilir: bu okuyucu yalnizca XML'in KENDI iddiasini gorur. Kullanici
        # boy/govde_boy niteliklerini de tutarli guncellemisse burada fark GORUNMEZ;
        # CANLI arsivle karsilastirma nesne_yaz.xml_hazirla'nin isidir.
        topla["degisti"] = bool(topla["kayitlar"] or topla["govde"][0] != topla["govde"][1]
                                or topla["yeniden_numaralanan"])
        agac["uzunluk"] = topla
    if agac["bicim"] == "supheli":
        agac["uyari"].append(
            "This body does not satisfy the record invariants; the split was "
            "reported as-is and must not be treated as a proven object tree.")
    return agac
