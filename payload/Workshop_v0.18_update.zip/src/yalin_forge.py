#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bellek-dostu v50 forge okuyucu (seek tabanli, tum dosyayi yuklemez) + yelken arama."""
import struct, sys, os, re

TEXTUREMAP = 0xA2B7E917
RAWASSET   = 0x4C8BD3BF

class LeanForge:
    def close(self):
        """Dosya tanitici Windows'ta FILE_SHARE_DELETE vermez: forge acik durdugu
        surece Steam 'dosya butunlugunu dogrula'/guncelleme "Content file locked"
        ile BASARISIZ olur. Isi biten her yerde kapatilmali."""
        f = getattr(self, "f", None)
        if f is not None and not f.closed:
            try:
                f.close()
            except OSError:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
        return False

    def __init__(self, path):
        self.path = path
        self.f = open(path, "rb")
        hdr = self.f.read(64)
        assert hdr[:8] == b"scimitar", "scimitar degil"
        hoff = struct.unpack_from("<Q", hdr, 13)[0]
        self.f.seek(hoff)
        head = self.f.read(12)
        self.count = struct.unpack_from("<I", head, 0)[0]
        toc = struct.unpack_from("<Q", head, 4)[0]
        self.f.seek(toc)
        tocbytes = self.f.read(self.count * 24)
        self.entries = []      # (off, id, len, ext)
        self.by_id = {}
        for i in range(self.count):
            off, fid, ln, ext = struct.unpack_from("<QQII", tocbytes, i*24)
            self.entries.append((off, fid, ln, ext))
            self.by_id[fid] = (off, ln, ext)

    def read_raw(self, fid):
        off, ln, ext = self.by_id[fid]
        self.f.seek(off)
        return self.f.read(ln)

    def textures(self):
        return [(fid, off, ln) for off, fid, ln, ext in self.entries if ext == TEXTUREMAP]

# --- oodle decompress (resynced_doku_cikar'dan) ---
import ctypes, glob as _glob
BMS = b"\x33\xAA\xFB\x57\x99\xFA\x04\x10"


def oodle_dll_yolu():
    """Oodle DLL'ini ARAR (yuklemez). Sadece GORELI yollara bakar, hicbir makineye
    ozel mutlak yol icermez. Sirasiyla: OODLE_DLL cevre degiskeni, paket duzeni
    (src/ -> ../tools), dev duzeni (scriptler|tarama_* -> ../arac_calisma/Libs),
    modulun kendi klasoru."""
    kok = os.path.dirname(os.path.abspath(__file__))
    adaylar = []
    ev = os.environ.get("OODLE_DLL")
    if ev:
        adaylar.append(ev)
    for d in (os.path.join(kok, "..", "tools"), os.path.join(kok, "tools"),
              os.path.join(kok, "..", "arac_calisma", "Libs"), kok):
        adaylar.append(os.path.join(d, "oo2core_7_win64.dll"))
        adaylar.extend(sorted(_glob.glob(os.path.join(d, "oo2core_*_win64.dll"))))
    for c in adaylar:
        if c and os.path.isfile(c):
            return os.path.abspath(c)
    return None


DLL = oodle_dll_yolu()          # sadece bilgi amacli; yukleme asagida, CAGRI aninda
_OODLE = {}

OODLE_YOK = ("oo2core_7_win64.dll not found. It should be in the 'tools' folder next "
             "to this program. If your antivirus quarantined it, restore the file and "
             "add the folder to your exclusions.")


def _oodle_fn():
    """DLL'i ILK KULLANIMDA yukler ve hatirlar.

    Eskiden bu is import aninda yapiliyordu: DLL yoksa veya antivirus onu
    karantinaya aldiysa modulu import eden GUI hic pencere acmadan, hicbir hata
    vermeden oluyordu ("cift tikliyorum, hicbir sey olmuyor"). Simdi hata
    okunabilir ve ancak gercekten forge'a dokunuldugunda ortaya cikar."""
    if "fn" not in _OODLE:
        yol = oodle_dll_yolu()
        if not yol:
            raise RuntimeError(OODLE_YOK)
        lib = ctypes.CDLL(yol)
        fn = lib.OodleLZ_Decompress
        fn.restype = ctypes.c_longlong
        fn.argtypes = [ctypes.c_char_p, ctypes.c_longlong, ctypes.c_char_p, ctypes.c_longlong,
                       ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_longlong,
                       ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_longlong, ctypes.c_int]
        _OODLE["lib"] = lib
        _OODLE["fn"] = fn
    return _OODLE["fn"]


def oodle(comp, rawlen):
    fn = _oodle_fn()
    out = ctypes.create_string_buffer(rawlen + 64)
    n = fn(comp, len(comp), out, rawlen, 1, 0, 0, None, 0, None, None, None, 0, 3)
    return out.raw[:rawlen] if n == rawlen else None
def read_block(d, off):
    if d[off:off+8] != BMS: return None, off
    p = off+8; ver = struct.unpack_from("<H", d, p)[0]; p += 2; p += 1+4
    t = struct.unpack_from("<I", d, p)[0]
    if t >= 0x10000: pc = struct.unpack_from("<H", d, p)[0]; p += 2
    else: pc = t; p += 4
    sizes = []
    for _ in range(pc):
        if ver <= 1: sizes.append((struct.unpack_from("<H", d, p)[0], struct.unpack_from("<H", d, p+2)[0])); p += 4
        else: sizes.append((struct.unpack_from("<I", d, p)[0], struct.unpack_from("<I", d, p+4)[0])); p += 8
    ham = bytearray(); cur = p
    for u, c in sizes:
        v = d[cur+4:cur+4+c]; ham += v if c==u else (oodle(v,u) or b""); cur += 4+c
    return bytes(ham), cur
def decompress(raw):
    if raw[:8] != BMS: return raw
    b1, n1 = read_block(raw, 0); b2, n2 = read_block(raw, n1)
    return b2 if b2 is not None else b1

if __name__ == "__main__":
    forge = sys.argv[1]
    if not os.path.isabs(forge):
        forge = os.path.join(r"C:\Program Files (x86)\Steam\steamapps\common\Assassin's Creed Black Flag Resynced", forge)
    print(f"Aciliyor: {os.path.basename(forge)}")
    lf = LeanForge(forge)
    texs = lf.textures()
    print(f"  {lf.count} entry, {len(texs)} TextureMap")
    # metafile'da yelken/gemi isimleri
    if 16 in lf.by_id:
        res = decompress(lf.read_raw(16))
        kw = ('sail','voile','jackdaw','pavillon','banner','mast','rig','ship','boat','flag')
        found = set()
        for m in re.finditer(rb"[A-Za-z][A-Za-z0-9_]{4,80}", res):
            s = m.group().decode('ascii')
            sl = s.lower()
            if any(k in sl for k in kw):
                found.add(s)
        print(f"  metafile'da gemi/yelken benzeri isimler ({len(found)}):")
        for s in sorted(found)[:60]:
            print("    ", s)
