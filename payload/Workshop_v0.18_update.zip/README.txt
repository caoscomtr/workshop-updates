==========================================
  WORKSHOP   (v0.18)
  Assassin's Creed IV Black Flag Resynced
==========================================

Unofficial fan-made tool: Assassin's Creed IV Black Flag is a trademark of
Ubisoft Entertainment, and this utility is not affiliated with or endorsed
by Ubisoft.

One desktop app for modding your own game files. No coding required.

  Characters  - play as 52 characters (NPC swap on an outfit slot)
  Outfits     - repaint 25 outfits         (EXPORT PNGs -> paint -> APPLY)
  Weapons     - repaint 88 weapons          (same flow, beta)
  Ships       - repaint the Jackdaw and everything around it: hulls, sails,
                flags & streamers, figureheads, wheels, cabin, cannons, crew,
                enemy ships, fort banners, paint ramps, normal maps (598 targets)
  Sounds      - browse 25,851 game sounds, preview them, MUTE the ones you
                hate (the notification beep), replace one with another
  3D          - export any outfit, character or weapon to .glb for Blender,
                edit it (reshape, delete, add geometry, repaint textures) and
                import it straight back into the game            (beta)
  Cheats      - edit values in your save file (money, resources)
  Explorer    - every entry of every archive: export it, EDIT AS XML,
                UNPACK ALL and put the changed files back
  Add a Mod   - install a pile of PNGs (recognised by content) or a ready
                .forge mod file
  Health Check- read-only diagnosis you can copy and share
  Restore All - undo every change the app ever made

Every change keeps a byte-exact backup and can be reverted from inside the
app. The app never touches your saves except in the Cheats tab, and there it
backs up the save first.


WHAT'S NEW IN v0.18
-------------------
PATCHED       16 outfits were replaced by the September game patch (Altair,
OUTFITS       Connor, Ezio, Templar, ...). Workshop now reads and writes the
              copy the game uses, so exports, Hide parts and Import 3D show
              in game; Altair's new skirt pieces appear in the parts list.
STUCK JOB     After an interrupted paint job: Health Check > Clear stuck job
              (moves the old record to a dated folder, deletes nothing).
GAME FOLDER   New panel: installs found on this PC + paste a path; the
              Windows folder window is only used if you press Browse.
SOUNDS        Search by what you hear: assassination, hidden blade, kill...
HEALTH CHECK  Lists leftover DLL/ASI mods; tests the texture encoder and
              says so if Windows Smart App Control blocks it.
NAMED FIELDS  114 fields in 30 classes in the XML view (entity placement,
              LOD distances, ship upgrade prices, cannon damage, ammo).

WHAT'S NEW IN v0.17
-------------------
CLASS NAMES   Class names are read from the game's own metadata table; no
              third-party dictionary is used. Each of the 10,051 names is
              proved by its own crc32, and the Explorer tree, the entry
              list, the XML view and Health Check all show the same name.
RAW ENTRIES   The Explorer tree also lists the archive's raw entries (external
              mip levels, streamed mesh pages) under the raw type: id, size,
              export as bytes; they are not containers, so no XML.
DUPLICATE     Pick a container entry, give it a new name, and Workshop appends
              a copy as a new row in the table of contents with its own id;
              Revert removes it. The game will not use it until a data record
              points at it - this is the first half of adding content.
NAMED FIELDS  The XML view names the fields Workshop itself understands (ship
              and weapon stats, texture descriptors and slots, mesh headers,
              sound ids) with source and value comments; the rest stay
              positional until we learn them.
EXPERT MODE   In Edit as XML, tick Expert mode and an edit that changes an
              object's byte length is written instead of refused: the
              container's size field is rebuilt and the table of contents
              redirected. Counts inside the object are yours to keep right;
              Revert restores the original. Off by default.
DDS TEXTURES  Export any texture as .dds with every mip level as stored; import
              a .dds back without re-encoding when format, size and mips match.
              Add a Mod accepts community .dds files. A writer bug for
              non-square textures (mip pool layout) was found and fixed.
EXPLORER 3D   A mesh exported from the Explorer now takes its materials and
              textures from the game's other archives too (boot, shared_00 and
              their patch files; the patch copy wins, as in the game). Before,
              a prop stored in shared_00 whose material lives in boot came out
              without textures. manifest.json records which archive each
              texture came from (kap_forge). Texture format 6 is read as BC1
              (measured on the game's own files, not from a specification);
              such textures export but cannot be written back yet.

WHAT'S NEW IN v0.16
-------------------
EXPLORER TREE The Explorer lists an archive as a tree: archive, type, class,
              entry and the files inside each entry. Every row shows its
              class, type and size; the type chips and the search box narrow
              the list instantly. Click an inner file to open it as XML.
RAW EDITS     A .bin you exported (Explorer or Unpack all) can be put back
              even when its size changed. Workshop rewrites the inner file's
              own size field, appends the new bytes and redirects the table
              of contents; Revert restores the original. A file with a
              damaged wrapper header is refused before anything is written.
RESTORE ALL   Now reverts every record Workshop wrote - hidden parts, ship
              stats, XML edits, imported meshes and Ships-tab textures too -
              and says what it could not.

WHAT'S NEW IN v0.15
-------------------
SHIP STATS    Ships tab: change the Jackdaw's hull health, ram damage and
              speed. Hull levels 1-5 are the game's own upgrade ladder (600
              to 5000), so a new game starts at whatever you set level 1 to.
              Apply shows exactly which bytes change, Write to the game
              writes them, Revert ship stats puts the original numbers back.
              Proven in the real game: the archive loaded to the main menu
              with the change in place and came back byte-for-byte after
              Revert. (The speed value's in-game effect is still unproven;
              see SHIPS below.)
HIDE PARTS    On any outfit, character or weapon, tick the parts you do not
              want - a hood, a coat, a holster, a long skirt - and they are
              hidden in the game without Blender. Every distance level of
              the part is hidden, not just the closest one, and Show all
              again restores them. This also fixes Swap parts, which used to
              write only the closest distance level, so the change showed
              in the preview but the original came back the moment the
              camera pulled away.
EDIT AS XML   Explorer tab: open any entry as a readable XML dump, change a
              value or a reference, see which bytes will change, and write
              it back. Edits that would change the length of an object are
              refused with a message that says so.
UNPACK ALL    Explorer tab: extract every entry of an archive to a folder,
              edit what you want, then Find changed files and Put them
              back - only the files you touched are written.
MERGE PATCHES Add a Mod: drop two ready-made .forge patches at once, or a
              second one while another is installed, and the Workshop
              combines them into one patch instead of overwriting. Where
              both change the same part of the game it tells you which one
              wins.
Also fixed: a texture you had reverted could still show as PATCHED on the
Ships tab (stale records from an older archive identity are now closed on
revert and ignored when reading). Rolling back an update twice used to
restore the same backup twice; each backup is now used once, and when none
is left the Workshop says so instead of pretending.


INSTALL
-------
1. IF WINDOWS BLOCKS IT: right-click the downloaded ZIP -> Properties ->
   tick "Unblock" -> OK, BEFORE extracting. (Windows marks files downloaded
   from the internet; the .NET runtime refuses to load marked DLLs and the
   modern interface would silently fall back to the classic one.)
2. Extract the ZIP anywhere (not inside the game folder).
3. Run Workshop.exe. The game folder is found automatically (Steam). If not,
   click the game-folder line at the bottom left and pick the folder that
   contains DataPC_boot.forge.
4. Close the game before applying anything. Reading/previewing works with
   the game open; writing is refused while ACBlackFlag.exe is running.

Requires Microsoft Edge WebView2 Runtime (on every Windows 11 and most
Windows 10 PCs already). Without it the classic interface opens instead.


SHIPS
-----
Pick a texture in the list, press 1. EXPORT PNG (the paintable template lands
in Documents\ShipWorkshop\tasarimlar and the folder opens), paint it in any
editor, then 2. APPLY PNG... and pick your painted file. Revert puts the
original back byte for byte.

Risk badges:  SAFE = only this item changes.  CAUTION = a few other objects
share the texture.  SHARED = enemy or civilian ships, or many props, use the
same texture - the panel tells you exactly what. Hull woods are SHARED by
design: the game paints enemy hulls with the same library.

Flags & sails are stored upside-down in the archive; the app flips them for
you in both directions. Their alpha channel is the emblem SHAPE, not
transparency - leave the alpha option on "Full design" unless you know why.

Normal maps (tick the "Normal maps" filter): data, not pictures. Bake them in
Substance / Blender / xNormal. The alpha channel carries gloss and is always
kept.

Ship mods: a folder of exported PNGs is already a ship mod. "Install a ship
mod..." matches every <target>.png by name and applies them one after
another; "Remove all ship changes" reverts every patched ship texture.

SHIP STATS... (beta): hull health per armour level (600 / 1200 / 2000 / 3200 /
5000), ram damage per level and the Jackdaw's speed setting. Type a number,
Apply shows exactly which value changes and by how many bytes, Write to the
game writes it; Revert ship stats puts the original numbers back. The hull
value was seen working in game; the speed setting is written correctly but
its in-game effect is not proven yet, and the panel says so.

Limits (honest):
* A diffuse texture and its normal map live in the same archive entry. The
  engine patches ONE texture per entry at a time - to patch both, apply one,
  and revert it before applying the other. The panel warns you.
* New v0.10 targets (streamers, nation emblems, fort banner, legendary
  items, extra crews, LUT ramps, enemy-ship LOD proxies) have risk badges
  estimated from names and material references, not from the full usage
  graph. Fort banner orientation is unverified in game.
* Paint ramps (LUT) are colour ramps, not pictures. They recolour every
  surface painted with that ramp game-wide (the Jackdaw's black hull uses
  Paint_Black).
* Encoding a 4096x4096 texture with 13 mip levels takes several minutes.
  The app stays responsive; do not close it while the bar moves.


SOUNDS
------
The list shows 25,851 sounds: 24,767 embedded effects (menu, HUD, combat,
assassinations, ship, ambience, animals, footsteps, objects, cutscenes) plus
1,084 streamed music/shanty tracks. Dialogue lines and sounds that are more
than 90% silence are hidden by default (tick the boxes to show them).

* Click a row or the play button to PREVIEW it.
* MUTE writes one number in the sound's header so the game plays 0.00 s of
  it - the original bytes are backed up and UNMUTE puts them back.
  Verified: the game starts and reaches the main menu with a muted sound;
  whether the mute is audible in every situation is for your ears.
* REPLACE: select the sound to replace, ctrl+click the sound to play instead,
  press Replace sound. The replacement must be the same length or shorter.
* EXPORT saves the sound as .wav and .wem in Documents\OutfitWorkshop\sounds.
* Revert all sounds undoes every mute and replacement.


CHEATS
------
Edits your SAVE file (not the game archive). Search the value you can see in
game, narrow it down by changing it in game and saving again, then set it.
A backup of the save is made before every write; the game must be closed.
If Ubisoft cloud sync is on it may undo your change - turn it off while you
use this. With several Ubisoft accounts on the PC the most recently played
one is used.


CHARACTERS, OUTFITS, WEAPONS, ADD A MOD
---------------------------------------
Characters: pick a character, choose an outfit slot, press INSTALL, then
equip that outfit in game to transform. "Remove all" deletes the patch and
restores any other mod's patch it had backed up.

Outfits / Weapons: EXPORT PNGs writes every texture of the item to
Documents\OutfitWorkshop\<item>\ and opens the folder. Paint only the files
inside EDIT (keep names and sizes). APPLY... picks the painted folder; a
read-only safety pass runs first, then the single writer patches the archive.
"Revert this" undoes one item, "Revert all" undoes everything.

Add a Mod: PNG files with broken names are recognised by CONTENT and shown
in a review table before anything is written. A downloaded
DataPC_boot_patch_02.forge mod can be installed directly; the existing patch
is backed up and Restore All brings it back.


3D EXPORT AND IMPORT  (Outfits, Characters, Weapons)
---------------------------------------------------
EXPORT 3D (GLB) writes the selected outfit, character or weapon to
Documents\OutfitWorkshop\3D\<name>\ as a single .glb plus a textures\ folder.
Open the .glb in Blender with File > Import > glTF 2.0 (drag it into the 3D
viewport, not onto the start screen). Meshes, skeleton, bone weights, materials
and textures come through. A large outfit is big: U_Edward_Yasuke is 112 MB of
.glb plus 141 MB of loose PNGs. The loose PNGs are there on purpose - they are
the surface you paint.

IMPORT 3D takes that folder back. You may reshape, delete and add geometry, and
repaint the PNGs. The app validates first and shows you what it found before it
writes anything; nothing is written until you confirm. Every write is recorded
and Revert puts the archive back byte for byte.

What you can do:
  - move, sculpt and reshape vertices
  - delete geometry, add geometry, model something new in its place
  - repaint any texture (keep the pixel size)
  - change a weapon's damage, draw speed, shot distance and max chain
    takedown (Weapons tab -> WEAPON STATS). This is balance data, not
    geometry, and it has not been tested in game yet.

What you cannot do yet:
  - make a model much larger than the original. Each mesh has a size band and
    the position scale cannot be changed yet; growing past the band is refused
    with a message. Shrinking and reshaping are free.
  - change animations or item names - those are game data, not geometry.
    A modelled axe still swings like the sword it replaced. Weapon perks
    are data we can reach but their description text lives in the localisation
    package, which is not decoded yet.
  - 16 weapons and the ship hull use a streamed mesh format we have not
    decoded; they are listed as not exportable.
  - character heads, faces and hands are not part of the character groups, so
    a character exports as clothing, hair and accessories.

A weapon is drawn at several distance bands, each a separate mesh in the archive.
IMPORT 3D writes your shape to every band the game draws up close and at mid
range, so the weapon no longer changes back to the original when the camera
pulls away in a fight. The far proxy meshes keep the game's original outline.
Writing a band costs space: a band entry grows to about twice its original size,
so one weapon import can add up to ~600 KB to the archive. Revert trims all of it
back and the report tells you how many bytes were trimmed.

Close the game before importing. The app refuses to write while it runs.

What happens to the things people actually do in Blender (all of this was measured
with Blender 5.2 on a real outfit):
  - You deleted the armature (the "skeleton"). Fine. The model drifts by a few
    degrees without it; the Workshop lines it up again from the meshes and tells
    you so. Untouched parts are still skipped.
  - You deleted a whole object (a coat, a belt). The report lists it as MISSING.
    Tick "Hide parts missing from my file" and that part disappears in the game:
    its triangles are collapsed the same way the game's own packer pads meshes,
    the file keeps its size, Revert brings it back.
  - You joined new geometry to a part. The new material group is merged into
    that part (a game mesh cannot gain material slots) and the report says so.
  - You joined two objects. The swallowed part shows as MISSING; the merged one
    is written.
  - You renamed objects, exported with +Y Up off, or moved the whole model. All
    handled; the names, the rotation and the offset are resolved before comparing.
  - You exported with "Selected Objects" on. The report says only N of M parts
    are in the file and asks you to untick it.
  - You scaled a part up past its slot. Refused, with the factor to scale back.
  - You deleted a material slot. Refused; every slot must survive.

DELETING A PART (making it disappear in game)
  You deleted the coat in Blender and you want it gone in the game too. This is
  the flow, and it has been seen working in game: on the Ferraro Diplomat outfit
  the coat, the boots, the belt and the second layer were deleted, four parts
  were hidden, and in game those four are gone with the rest of the outfit
  intact.

  1. Select the item, press EXPORT 3D (GLB) and open the .glb in Blender.
  2. In Object Mode select the parts you do not want and delete them (X). You
     may delete the armature as well - it makes no difference, the Workshop
     lines the model up again from the meshes and tells you it did.
  3. File > Export > glTF 2.0 and save into the SAME folder, named
     <item>_edit.glb (the export folder's README prints the exact name).
     Leave "Selected Objects" UNTICKED, or the parts you did not have selected
     will look deleted too.
  4. Close the game.
  5. In the Workshop select the same item, press IMPORT 3D and pick that folder.
     The report lists the deleted parts as MISSING and does not write them.
  6. Tick "Hide N part(s) missing from my file". The MISSING lines become HIDE
     lines, one per part.
  7. Press Write to the game, then start the game. Those parts are gone.

  "Revert all" puts every hidden part back, byte for byte.

  HIDE PARTS... does the same thing WITHOUT Blender: select the item, press
  HIDE PARTS..., tick the parts you do not want, Apply shows what will be
  written (every distance band, how much the archive grows), Write to the
  game hides them, and "Show all again" brings every hidden part of that
  item back. Anvil has no equivalent for this; it is the answer to the
  "outfit without the dress" and "hide the blowpipe / holster" requests.

  Deleting a whole object is not the same as deleting its faces. Delete the
  object and the part is HIDDEN: its triangles are collapsed the way the game's
  own packer pads meshes, so the archive entry keeps exactly the same number of
  bytes - nothing is removed from the archive and the archive does not grow.
  Delete only some faces in Edit Mode and the part is still worn: it is
  rewritten with the smaller shape, and you will see through the holes you made.
  To remove a part, delete the whole object.

CROSS-IMPORT (one item's model onto another item)
  Select the TARGET item in the list, press IMPORT 3D and pick the SOURCE item's
  export folder. The title says "cross-import: A into B" so it cannot happen by
  accident. The source's shape goes into the target's slot AND the target is
  pointed at the source's material, so the textures follow the shape (mesh
  references and the LODSelector band records are both rewritten). A weapon has
  several LOD bands (a close-up mesh drawn to about 1 m, a second one drawn to
  about 4 m, plus low-detail proxies for shadows and the far distance): the shape
  is written into every MAIN band mesh, and the report's "LOD bands:" line says
  which bands are covered and from what distance the target's original outline
  still shows (the proxies are not rewritten). The target keeps its
  own stats, sounds and animations. Weapons match 1:1 (216 of 241 have a single
  part). Outfits match part-by-part by family (Tunic, Pants, Boots, ...); parts
  with no counterpart are reported as NO PLACE / TARGET ONLY and can be hidden.
  No edited .glb is needed: with none in the folder, the export itself is the
  source. Repainting the source's textures afterwards changes both items.
  Cross-import has NOT been checked in game yet - Revert all is one click away.

THE WHOLE INVENTORY
  Characters, Outfits and Weapons now list everything the game archive holds:
  288 characters (52 player, 233 NPC, crew), 182 outfits and 241 weapons. The
  chips (Player / NPC / Crew / Cinematic / Holstered / Prop) filter the list.
  Items outside the original catalogue are 3D-only: EXPORT 3D and IMPORT 3D work,
  PNG painting and character swap do not (the buttons say why). Items the reader
  cannot decode yet are hidden behind "Show items that cannot be exported yet"
  with the reason (54 weapons and 33 characters use a streamed mesh or hair
  strands format that is not decoded).

UPDATES
  The Workshop checks for a newer version when it starts and shows a banner on
  the Dashboard. "Update now" downloads the update package, verifies its SHA-256,
  backs up the current files and replaces only data, scripts and the interface -
  Workshop.exe, the bundled Python and tools\ are never changed. Restart to use
  the new version. Nothing is downloaded or installed without pressing the
  button. The update address can be changed in ayarlar.json ("guncelleme_url").

BACKUP AND REVERT
-----------------
Backups and undo records live in %LOCALAPPDATA%\ACBFR_Modding (textures,
ships, sounds) and %LOCALAPPDATA%\OutfitWorkshop (settings, logs, character
swap record). Do not delete them while a change is installed: they are the
only copy of the original bytes. Restore All reverts textures, characters,
ships and sounds in one go and reports what it could not do.

Always undo from inside the app - never by deleting files in the game folder.
Mesh and texture edits are written into DataPC_boot.forge, so deleting
DataPC_boot_patch_02.forge does NOT undo them; Health Check will still look
clean because the undo records are untouched. That patch file is where OTHER
people's mods live, so deleting it removes those instead. Use "Revert this",
"Revert all" or Restore All - each of them puts the original bytes back and
clears the record at the same time.


IF SOMETHING GOES WRONG
-----------------------
Open Health Check (top right), press Copy report and paste it on the mod page
or Discord. Logs are in %LOCALAPPDATA%\OutfitWorkshop\logs. If the modern
interface does not start, the classic interface opens instead and the reason
is written to shell-fallback.log there.


THIRD-PARTY COMPONENTS
----------------------
See THIRD-PARTY-NOTICES.txt (pywebview, vgmstream and the FFmpeg libraries
it ships under the LGPL, Lucide icons, DirectXTex, the Oodle decompression
DLL - commercial middleware, not ours to relicense, CPython + NumPy +
Pillow + lz4 + texture2ddecoder, the .NET runtime). The same file explains
where the pictures in this package come from: they were extracted or
rendered from the game's archives, they ship inside the download, and (like
every item name shown here) they belong to Ubisoft Entertainment.


Fair winds, Captain.
  -- zuynes
