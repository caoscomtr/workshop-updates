# -*- coding: utf-8 -*-
"""OUTFIT WORKSHOP v0.9 — WEB ARAYUZ KABUGU (pywebview + WebView2).

Motor AYNEN v0.8: outfit_core (tek yazici disiplini), karakter_takas (26 kapili
uretec), onizleme3d (3D kareler), eslestir (icerikten mod eslestirme).
Bu dosya yalniz KOPRU: Tk kabugunun cagirdigi AYNI cekirdek fonksiyonlar,
AYNI kapi sirasiyla cagrilir — kural kopyasi yok.
"""
import base64
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback

BURA = os.path.dirname(os.path.abspath(__file__))
KOK = os.path.dirname(BURA)
sys.path.insert(0, os.path.join(KOK, "src"))
# gelistirme agacinda motor moduller ayri klasorlerde yasar; pakette hepsi
# src/ icindedir — olmayan yollar sessizce atlanir (tasinabilirlik)
for _ek in (os.path.join(KOK, "onizleme3d"),
            ):
    if os.path.isdir(_ek):
        sys.path.insert(1, _ek)

import outfit_core as C                                          # noqa: E402
import karakter_takas as KT                                      # noqa: E402

OYUN = os.path.dirname(C.DE.FORGE) if C.game_found() else None
OUTPUT = os.path.join(os.path.expanduser("~"), "Documents", "OutfitWorkshop")
DURUM_DOSYA = os.path.join(os.environ.get("LOCALAPPDATA", tempfile.gettempdir()),
                           "OutfitWorkshop", "charswap.json")
AYAR_DOSYA = os.path.join(os.path.dirname(DURUM_DOSYA), "ayarlar.json")
_PENCERE = [None]
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# Guncelleme ilerlemesinin ASAMA adlari. Cevrilebilir olmasi icin sozlukte tutulur
# (ceviri envanteri SABIT_METINLER'den toplar); ham "download" gostermek 5 dilde
# yayinlanan bir uygulamada Ingilizce ic terim sizdirmak olurdu.
ASAMA_AD = {
    "download": "Downloading",
    "verify": "Checking the download",
    "install": "Installing",
}


def oyun_acik_mi():
    """Oyun calisiyor mu? (tasklist)

    Ciktiyi METIN olarak cozmuyoruz: Turkce/Rusca Windows'ta tasklist'in OEM
    kod sayfali ciktisi UnicodeDecodeError firlatiyor ve eski surum bunu
    yutup False donuyordu -> "oyunu kapat" kapisi sessizce devre disi
    kaliyordu (denetimde olculdu). Bayt karsilastirmasi kod sayfasindan
    bagimsizdir. CREATE_NO_WINDOW: penceresiz uygulamada konsol yanip sonmesin.
    """
    try:
        c = subprocess.run(["tasklist", "/FI", "IMAGENAME eq ACBlackFlag.exe"],
                           capture_output=True, timeout=10, creationflags=NO_WINDOW)
        return b"ACBlackFlag.exe" in (c.stdout or b"")
    except Exception:
        return False


# ---------------------------------------------------------------- PARCA TAKASI (SWAP PARTS)
# Discord istegi (2026-09-05, CasinoCalculator): "cift kiliclarin iki elinde de AYNI model
# olsun". Oyunda cift silah IKI AYRI mesh'tir (Weapon_Sword_19 = ..._R_01A + ..._L_01A, ayri
# gid/icid, ayri materyal), bu yuzden Blender'da tek nesneyi kopyalamak ise yaramaz. Motor
# tarafi hazir: mesh_ithal.plan(hedef=<ayni oge>, capraz_esleme={kaynak: hedef}) sekli VE
# materyali tasir. Buradaki iki yardimci arayuzun tek tikli kisayolunu besler.
def _lr_aynasi(taban):
    """Bir parca adinin SAG/SOL aynasi. Doner (ayna_ad, taraf) ya da (None, None);
    taraf 'sag' = verilen ad sag parca, 'sol' = sol parca.

    Sira onemli: once '_R_'/'_L_' jetonu (Sword_W_P_DrakesDual_R_01A), sonra sondaki
    '_R'/'_L', en son 'Right'/'Left' sozcugu (buyuk-kucuk harf duzeni korunur)."""
    t = str(taban or "")
    if not t:
        return None, None
    if "_R_" in t and "_L_" not in t:
        return t.replace("_R_", "_L_"), "sag"
    if "_L_" in t and "_R_" not in t:
        return t.replace("_L_", "_R_"), "sol"
    if t.endswith("_R"):
        return t[:-2] + "_L", "sag"
    if t.endswith("_L"):
        return t[:-2] + "_R", "sol"
    m = re.search(r"(?i)(right|left)", t)
    if m:
        soz = m.group(1)
        sag_mi = soz.lower() == "right"
        yeni = "Left" if sag_mi else "Right"
        if soz.isupper():
            yeni = yeni.upper()
        elif soz.islower():
            yeni = yeni.lower()
        return t[:m.start(1)] + yeni + t[m.end(1):], ("sag" if sag_mi else "sol")
    return None, None


def _lr_ciftleri(parcalar):
    """Parca listesinde SAG/SOL eslerini bulur. Girdi: [{ad, taban}].
    Doner [{sag, sol, taban_sag, taban_sol}] (ad = manifest'teki GERCEK ad).

    Esleme TABAN adlar uzerinde yapilir: export adlari 'Sword_..._R_01A_L???' gibi kirpik
    LOD ekleri tasiyabilir ve ham adda '_L' aramak yanlis es uretir (olculdu)."""
    kayit = []
    for p in parcalar or []:
        ad = str((p or {}).get("ad") or "")
        if ad:
            kayit.append((ad, str((p or {}).get("taban") or "") or ad))
    taban_ad = {}
    for ad, tb in kayit:
        taban_ad.setdefault(tb, ad)
    ciftler, gorulen = [], set()
    for _ad, tb in kayit:
        ayna, taraf = _lr_aynasi(tb)
        if not ayna or ayna == tb or ayna not in taban_ad:
            continue
        sag_tb, sol_tb = (tb, ayna) if taraf == "sag" else (ayna, tb)
        if (sag_tb, sol_tb) in gorulen:
            continue
        gorulen.add((sag_tb, sol_tb))
        ciftler.append({"sag": taban_ad[sag_tb], "sol": taban_ad[sol_tb],
                        "taban_sag": sag_tb, "taban_sol": sol_tb})
    return ciftler


def _esleme_temizle(esleme):
    """Arayuzden gelen {kaynak_parca: hedef_parca} haritasini guvenli hale getirir:
    bos anahtar duser; deger None/bos = 'bu parcayi YAZMA' anlamiyla KORUNUR (motor bunu
    boyle okur). Gecerli tek cift bile yoksa None doner -> eski davranis (otomatik esleme)."""
    if not isinstance(esleme, dict):
        return None
    out = {}
    for k, v in esleme.items():
        k = str(k or "").strip()
        if not k:
            continue
        out[k] = (None if v is None else (str(v).strip() or None))
    return out or None


def ayar_oku():
    try:
        with open(AYAR_DOSYA, encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def ayar_yaz(d):
    os.makedirs(os.path.dirname(AYAR_DOSYA), exist_ok=True)
    t = AYAR_DOSYA + ".yeni"
    with open(t, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1)
    os.replace(t, AYAR_DOSYA)


def dosya_parmak_izi(yol):
    """patch_02 kimligi: boyut + mtime + ilk 1 MB'in sha256'si (hizli, ayirt edici)."""
    try:
        st = os.stat(yol)
        import hashlib
        with open(yol, "rb") as f:
            sha = hashlib.sha256(f.read(1 << 20)).hexdigest()[:16]
        return {"boyut": st.st_size, "mtime_ns": st.st_mtime_ns, "sha1mb": sha}
    except OSError:
        return None


def _kiyafet_adi(kod):
    """Katalog kodundan okunabilir ad ('U_Edward_Whaler' -> 'Whaler Outfit')."""
    try:
        return C.get_outfit(kod).get("gorunen_ad") or str(kod)
    except Exception:
        try:
            return C._pretty_outfit(kod)
        except Exception:
            return str(kod)


def guvenlik_en(etiket):
    return {"YESIL": "SAFE", "SARI": "CAUTION", "KIRMIZI": "RISK"}.get(etiket, etiket)


# ==================================================== VARLIK LISTELERI (kart)
# Characters / Outfits / Weapons sekmelerinin kart listeleri. Kaynak kataloglar
# NPC, murettebat ve sinematik varliklarla BUYUYOR (indeksleri baska araclar
# yazar); liste bu yuzden sunucuda suzulur ve SAYFALANIR — sozlesme Sounds
# sekmesiyle ayni: {sayi, kayitlar, baslangic, bitti}.
#
# Kategori ve okunabilirlik alanlari indekslerden gelir. HENUZ YOKSA guvenli
# varsayilan kullanilir (kategori = player, okunabilir = evet), yani arayuz
# alanlar gelmeden de bugunku listeyi aynen gosterir; alanlar gelince cipler
# ve rozetler kendiliginden acilir. Sayilar HER ZAMAN indeksten okunur,
# hicbir yerde sabit sayi yoktur.
VARLIK_SAYFA = 120                       # kart sayfa boyu (Sounds'ta 400 satir)

# indeksten gelen ham kategori adi -> sabit kod. Bilinmeyen ad KENDI kodu olur
# (yeni bir kategori kendi cipini alir; yanlis kovaya dusmez).
_KAT_ES = {"player": "player", "oyuncu": "player", "catalog": "player",
           "katalog": "player", "edward": "player",
           "npc": "npc", "cinematic": "cinematic", "cutscene": "cinematic",
           "sinematik": "cinematic", "crew": "crew", "murettebat": "crew"}
KAT_SIRA = ["player", "npc", "crew", "cinematic"]
# Ingilizce cip etiketleri: arayuz bunlari T() ile cevirir (anahtarlar
# arayuz.html icinde acik yazilidir, ceviri envanteri oradan toplar).
KAT_ADLARI = {"player": "Player", "npc": "NPC", "crew": "Crew",
              "cinematic": "Cinematic"}

# okunamama gerekcesi -> kod. Arayuz kodu bilinen bir Ingilizce cumleye cevirir;
# kod cikmazsa indeksin ham metni oldugu gibi gosterilir (dilsiz ama dogru).
_NEDEN_DESEN = ((("mph", "stream"), "mph"),
                (("sub-variant", "subvariant", "alt bicim", "altbicim"), "altbicim"),
                (("stride", "skin layout", "iskelet"), "iskelet"),
                (("not found", "bulunamad", "missing", "eksik"), "yok"))


def _ilk_alan(d, adlar):
    """Kayitta gecen ILK alan. Indeksi yazan arac alan adini secebilsin diye
    esanlamlilar denenir (kategori/category, okunabilir/readable ...)."""
    if not isinstance(d, dict):
        return None
    for a in adlar:
        if d.get(a) is not None:
            return d[a]
    return None


def kategori_kodu(*kaynaklar):
    """Kayit(lar)dan kategori kodu; alan hic yoksa 'player' (bugunku secilmis
    katalog oyuncu varliklarindan olusur, varsayilan gorunum de odur)."""
    for d in kaynaklar:
        ham = _ilk_alan(d, ("kategori", "category", "varlik_kategorisi",
                            "kategori_kodu"))
        if ham is None:
            continue
        k = re.sub(r"[^a-z0-9]+", "", str(ham).strip().lower())
        if k:
            return _KAT_ES.get(k, k)
    return "player"


def _neden_kodu(neden):
    t = str(neden or "").lower()
    if not t:
        return "belirsiz"
    for desenler, kod in _NEDEN_DESEN:
        if any(x in t for x in desenler):
            return kod
    return ""                            # bilinmiyor: ham metin gosterilir


def okunabilirlik(*kaynaklar):
    """(okunabilir, neden_kod, ham_neden). Alan hic yoksa okunabilir sayilir —
    bugun listedeki her sey disa aktarilabiliyor; indeks 'okunamaz' dedigi anda
    satir rozetlenir ve EXPORT 3D dugmesi kilitlenir."""
    okunabilir, neden = None, None
    for d in kaynaklar:
        if not isinstance(d, dict):
            continue
        if neden is None:
            n = _ilk_alan(d, ("okunamama_nedeni", "neden", "reason",
                              "unsupported_reason", "desteklenmiyor_nedeni"))
            if isinstance(n, str) and n.strip():
                neden = n.strip()
        if okunabilir is None:
            v = _ilk_alan(d, ("okunabilir", "readable", "disa_aktarilabilir",
                              "exportable"))
            if isinstance(v, bool):
                okunabilir = v
            else:
                v2 = _ilk_alan(d, ("okunamaz", "unsupported", "desteklenmiyor"))
                if isinstance(v2, bool):
                    okunabilir = not v2
    if okunabilir is None:
        okunabilir = not neden           # yalniz gerekce yazildiysa: okunamaz
    if okunabilir:
        return True, "", ""
    return False, _neden_kodu(neden), neden or ""


def _arama_puani(kayit, kelimeler):
    """Kart arama puani (dusuk daha iyi); kelimelerden biri gecmiyorsa None.
    Katmanlar: gorunen adin BASINDA 0 · gorunen adin icinde 1 · yalniz kod
    adinda/kategoride 2 (ses aramasiyla ayni mantik, kartlara sadelestirilmis)."""
    if not kelimeler:
        return 0
    ara = kayit["_ara"]
    ad = str(kayit.get("gorunen") or "").lower()
    puan = 0
    for k in kelimeler:
        if k not in ara:
            return None
        if ad.startswith(k):
            continue
        puan += 1 if k in ad else 2
    return puan


# ---------------------------------------------------------------- GERI ALMA DURUSTLUGU
# `kur_mesh.geri_al_hepsi` IKI ayri sayi dondurur ve ikisi de kullaniciyi ilgilendirir:
#   kirpilan    = bu geri almada arsivin SONUNDAN gercekten kirpilan bayt,
#   kuyruk_bayt = arsivin, bu arac ILK kez yazmadan onceki boyutunun hala kac bayt
#                 USTUNDE oldugu (None = o taban kayitta yok, olculemez).
# Ikincisi 0 degilse arsiv, yamalar geri alinmis olsa bile KUCULMEMISTIR. Eski surum
# bu durumda da "archive restored to original" diyordu (kur_mesh olcumu: ic ice iki
# ithalattan sonra 29.917.184 -> 29.970.627 B kalmisti, donus {"ok": true} idi).
# Buradaki hukum o yalani kapatir: "restored to original" YALNIZ kuyruk 0 iken gecer.
GERIAL_YOK = "yok"                  # mesh yamasi yoktu -> kuyruk hakkinda hukum verme
GERIAL_TEMIZ = "temiz"              # arsiv tabana dondu (kuyruk == 0)
GERIAL_ARTIK = "artik"              # arsiv hala buyuk (kuyruk > 0)
GERIAL_BILINMIYOR = "bilinmiyor"    # eski kayit: taban saklanmamis (kuyruk is None)

# Kuyruk kirpilamadiginda NEDEN: kur_mesh kendi cumlesini `mesaj`ta verir (hangi yama,
# hangi arac). Vermezse bu genel cumle basilir -- "bilmiyorum" demek yerine susmak,
# kullaniciyi arsiv buyumus halde bilgisiz birakirdi.
GERIAL_NEDEN_GENEL = (
    "This happens when another tool wrote to the end of the archive after Workshop did: "
    "the space behind that block cannot be reclaimed without risking it. Revert that "
    "tool's patches as well, then press Revert here once more and the space comes back.")


def _gerial_hukmu(mr, kuyruk):
    """Mesh geri almasinin DURUST hukmu (yalniz olcum + cumle; hicbir sey yazmaz).

    `mr`     = kur_mesh.geri_al_hepsi donusu — BASKA bir ajanin sozlesmesi, hepsi
               `.get()` ile nazik okunur; alan yoksa 0/None kabul edilir.
    `kuyruk` = geri almalarin HEPSI bittikten SONRA olculen `kuyruk_bayt` (None =
               bilinmiyor). Neden sonra: doku geri almasi mesh geri almasindan SONRA
               kosar ve arsivi kucultebilir; mesh aninda okunan sayi BAYAT olurdu.

    Doner {"kod", "kirpilan", "geri_alindi", "kuyruk", "satirlar"}; `satirlar` log'a
    basilacak tam Ingilizce cumlelerdir, `kod` ile arayuz ozet cumlesini secer."""
    mr = mr or {}
    n = int(mr.get("geri_alindi") or 0)
    kirpilan = int(mr.get("kirpilan") or mr.get("kirpildi") or 0)
    out = {"kirpilan": kirpilan, "geri_alindi": n, "kuyruk": kuyruk, "satirlar": []}
    if n <= 0 and not kirpilan:
        # Bu geri almada mesh tarafi hic calismadi -> arsivin boyutu hakkinda BU is'in
        # soyleyebilecegi dogru bir sey yok (doku tarafinin kendi kaydi var).
        out["kod"] = GERIAL_YOK
        return out
    if kuyruk is None:
        out["kod"] = GERIAL_BILINMIYOR
        out["satirlar"].append(
            "  The archive size from before the first patch was not recorded, so "
            "Workshop cannot check here whether the archive shrank back.")
        return out
    if int(kuyruk) <= 0:
        out["kod"] = GERIAL_TEMIZ
        out["satirlar"].append(
            "  %d bytes were trimmed back and the archive is now the size it had "
            "before this tool first wrote to it." % kirpilan)
        return out
    out["kod"] = GERIAL_ARTIK
    if kirpilan:
        out["satirlar"].append(
            "  %d bytes were trimmed back, but the archive is still %d bytes larger "
            "than before this tool first wrote to it." % (kirpilan, int(kuyruk)))
    else:
        out["satirlar"].append(
            "  Nothing could be trimmed back: the archive is still %d bytes larger "
            "than before this tool first wrote to it." % int(kuyruk))
    neden = str(mr.get("mesaj") or "").strip()
    out["satirlar"].append("  " + (neden or GERIAL_NEDEN_GENEL))
    return out


# ---------------------------------------------------------------- BAYAT KAYIT UYARISI
# kur_mesh, oyun guncellendikten sonra eski yama kayitlarini "bayat" isaretleyip
# kurulumu GECIRIR (ok=True) ve donusune BAYAT_MESAJ koyar. Bu, basarili bir isin
# icindeki KOTU haberdir: o eski yamalar artik geri ALINAMAZ. Basari yolunda
# gosterilmezse kullanici bunu hic ogrenmez.
BAYAT_ANAHTAR = ("out of date", "marked out of date")


def _bayat_izi(veri, derinlik=0):
    """`veri` icindeki (sozluk/liste/dize) "out of date" gecen ILK cumleyi dondurur.

    Neden tarama: bayat uyarisi bugun `kur_mesh.kur` donusundedir ve `mesh_ithal`
    onu ust sozlesmeye tasimaz. Tasidigi gun (alan adi ne olursa olsun) bu tarama
    onu KENDILIGINDEN yakalar; tasimadigi gun ise `_mesh_bayat_sayisi` sayar."""
    if derinlik > 4:
        return None
    if isinstance(veri, str):
        d = veri.lower()
        return veri if any(a in d for a in BAYAT_ANAHTAR) else None
    if isinstance(veri, dict):
        veri = list(veri.values())
    if isinstance(veri, (list, tuple)):
        for x in veri:
            b = _bayat_izi(x, derinlik + 1)
            if b:
                return b
    return None


def _duz_metin(m):
    """{"t": "... {0} ...", "a": [...]} kalibini DUZ metne cevir.

    Arayuzdeki msj() ile ayni doldurma kurali; log satirlari ve birlestirilen
    sonuc cumleleri sozluk kalibini tasiyamaz."""
    if isinstance(m, dict) and m.get("t"):
        s = str(m["t"])
        for i, d in enumerate(m.get("a") or []):
            s = s.replace("{%d}" % i, str(d))
        return s
    return "" if m is None else str(m)


class Api:
    def __init__(self):
        self._oturum = None
        self._kare_onbellek = {}
        self._kilit = threading.Lock()
        self._mesgul = False
        # MODS sekmesi: ekrandaki plan + kiyafet sahneleme klasoru + birakma olcumu
        self._md_plan = None
        self._md_sahne = None
        self._md_birakma = {"olay": 0, "dosya": 0, "yol": 0}
        # MERGE bayragi (v0.15): "Merge with the installed patch" dugmesi bunu
        # kaldirir; _md_kur_isi girer girmez okuyup sifirlar. Parametre DEGIL,
        # cunku _md_kur_isi imzasi ve INSTALL cagrisi tek kurulum yolunun
        # kapisidir (test_mod_arayuz K13) -- ikinci bir kurulum yolu ACILMAZ.
        self._md_birlestir = False
        # SAYFA CANLILIK BAYRAGI: WebView2 kurulumu basarisiz olursa pywebview
        # sessizce pes eder (edgechromium.on_webview_ready: IsSuccess False ->
        # sadece log + return, ISTISNA YOK) ve pencere BOS kalir. Bu bayrak
        # sayfanin gercekten acildigini kanitlar; bekci buna bakip klasige duser.
        self._sayfa_canli = False
        # IPTAL BAYRAGI (v0.15): toplu ac / geri koy dongusu her giriste bakar.
        # iptal_et() set eder; _is() her yeni iste sifirlar. Bayrak forge'a
        # dokunmaz: toplu.py girisi bitirir, kaydi yazar, sonra durur.
        self._iptal = threading.Event()

    # ================================================== ortak yardimcilar
    def _bildir(self, tip, veri):
        p = _PENCERE[0]
        if p is None:
            return
        try:
            p.evaluate_js("isOlay(%s,%s)" % (json.dumps(tip), json.dumps(veri)))
        except Exception:
            pass

    def _log(self, metin):
        print(metin)
        self._bildir("log", str(metin).rstrip("\n"))
        s = str(metin)
        m = re.search(r"\b(\d+)\s*/\s*(\d+)\b", s)
        if m and int(m.group(2)):
            self._bildir("bar", 100.0 * int(m.group(1)) / int(m.group(2)))
            return
        # YUZDE bicimi (or. mod_kutuphane "downloaded 42% (18.3 MB)"). Onek SARTI var:
        # log'daki alakasiz bir yuzde ("BC7 90% quality") bari ziplatmasin -- bar geri
        # giderse kullanici bunu hata sanar.
        m = re.search(r"\b(?:downloaded|downloading|extracting|installing|writing|reading|"
                      r"checking|scanning)\b[^%\n]{0,40}?(\d{1,3}(?:\.\d+)?)\s*%", s, re.I)
        if m:
            try:
                self._bildir("bar", max(0.0, min(100.0, float(m.group(1)))))
            except ValueError:
                pass

    def _bar(self, d):
        """guncelle.py'nin SAYISAL ilerleme geri cagrisi -> arayuzun bar olayi.

        Metin kazimaya (regex) guvenmez: yuzdeyi ureten yer verir. `asama` alani hangi
        adimda oldugumuzu soyler (download / verify / install)."""
        try:
            if not isinstance(d, dict):
                return
            self._bildir("bar", float(d.get("yuzde") or 0.0))
            metin = d.get("metin")
            asama = ASAMA_AD.get(d.get("asama"), d.get("asama"))
            if metin and asama:
                self._bildir("asama", {"t": "{0} — {1}", "a": [asama, metin]})
        except Exception:                                       # noqa: BLE001
            pass

    def _mesgul_mu(self):
        """Kilit atomik: iki kopru cagrisi ayni anda gelirse ikisi de gecemez."""
        with self._kilit:
            if self._mesgul:
                return True
            self._mesgul = True
            return False

    def _serbest(self):
        self._mesgul = False

    def _is(self, fn):
        """Tek is disiplini: ayni anda IKINCI is baslamaz (Tk'daki busy kilidi)."""
        if self._mesgul_mu():
            return {"ok": False, "mesaj": "Another job is still running."}
        self._iptal.clear()              # eski isin iptali yeni ise SIZMASIN
        self._bildir("mesgul", True)

        def sarici():
            try:
                fn()
            except Exception as e:
                print(traceback.format_exc())
                self._bildir("hata", str(e)[:400])
            finally:
                self._mesgul = False
                self._bildir("mesgul", False)
        # daemon DEGIL: arsive yazan bir is, pencere kapansa da tamamlanir
        # (yarim yazim riski smoke testte OLCULDU — surec cikisi isi kesiyordu)
        threading.Thread(target=sarici, daemon=False).start()
        return {"ok": True}

    def _oyun_acik_mi(self):
        return oyun_acik_mi()

    def dil_kaydet(self, kod):
        """Dil secimi KALICI olarak Python tarafinda tutulur: pywebview'in
        InPrivate profili + rastgele port yuzunden localStorage her acilista
        siliniyordu (denetimde olculdu: dil hep Ingilizce'ye donuyordu)."""
        kod = str(kod or "en")[:5]
        try:
            d = ayar_oku(); d["dil"] = kod; ayar_yaz(d)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:120]}

    def uzman_durum(self):
        """EXPERT MODE anahtarinin durumu. Arsive DOKUNMAZ, is baslatmaz."""
        try:
            import uzman as UZ
            acik = bool(UZ.acik())
            return {"ok": True, "acik": acik,
                    "metin": UZ.metin("ui.acik" if acik else "ui.kapali"),
                    "baslik": UZ.metin("ui.baslik"),
                    "aciklama": UZ.metin("ui.aciklama")}
        except Exception as e:
            return {"ok": False, "acik": False, "mesaj": str(e)[:160]}

    def uzman_ayarla(self, deger):
        """EXPERT MODE anahtarini yaz (dil ile AYNI ayarlar.json). Arsive DOKUNMAZ."""
        try:
            import uzman as UZ
            UZ.ayarla(bool(deger))
            return self.uzman_durum()
        except Exception as e:
            return {"ok": False, "acik": False, "mesaj": str(e)[:160]}

    def nexus_modlar(self):
        """Oyunun Nexus'taki SON modlari — anahtarsiz v2 GraphQL (sitenin kendi
        ucu, 2026-08-30 olculdu). Basarisizsa onbellekten doner (cevrimdisi)."""
        onbellek = os.path.join(os.path.dirname(DURUM_DOSYA), "nexus_cache.json")
        try:
            import urllib.request
            sorgu = {"query": """query { mods(filter: {gameDomainName:
                {value: "assassinscreedblackflagresynced", op: EQUALS}},
                sort: {createdAt: {direction: DESC}}, count: 8) { nodes {
                name summary createdAt downloads endorsements pictureUrl
                modId uploader { name } } } }""".replace("\n", " ")}
            req = urllib.request.Request(
                "https://api.nexusmods.com/v2/graphql",
                data=json.dumps(sorgu).encode(),
                headers={"Content-Type": "application/json",
                         # durust kimlik: ToS dostu, olculdu — calisiyor
                         "User-Agent": "BlackFlagResyncedWorkshop/0.9 "
                                       "(community modding tool)"})
            d = json.loads(urllib.request.urlopen(req, timeout=12).read())
            modlar = [{
                "ad": m["name"], "yazar": (m.get("uploader") or {}).get("name", "?"),
                "indirme": m.get("downloads", 0),
                "begeni": m.get("endorsements", 0),
                "gorsel": m.get("pictureUrl") or "",
                "link": "https://www.nexusmods.com/games/"
                        "assassinscreedblackflagresynced/mods/%s" % m["modId"],
            } for m in d["data"]["mods"]["nodes"]]
            os.makedirs(os.path.dirname(onbellek), exist_ok=True)
            with open(onbellek, "w", encoding="utf-8") as f:
                json.dump({"modlar": modlar}, f)
            return {"ok": True, "modlar": modlar, "kaynak": "canli"}
        except Exception as e:
            try:
                with open(onbellek, encoding="utf-8") as f:
                    return {"ok": True, "modlar": json.load(f)["modlar"],
                            "kaynak": "onbellek"}
            except Exception:
                return {"ok": False, "mesaj": str(e)[:120]}

    def oyun_adaylari(self):
        """Oyun klasoru paneli: bulunan TUM gecerli kurulumlar + su anki. Windows klasor
        penceresi yalniz 'Browse...' ile acilir (2026-10-12, Nexus ryanryanx1)."""
        try:
            return {"ok": True, "adaylar": C.find_games(), "simdiki": OYUN}
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:200], "adaylar": [], "simdiki": OYUN}

    def oyun_yol_ayarla(self, yol):
        """Listeden secilen ya da yapistirilan yolu uygula. Gecersizse HICBIR SEY degismez."""
        if self._mesgul:
            return {"ok": False, "mesaj": "Another job is still running."}
        yol = str(yol or "").strip().strip('"').strip()
        if not yol:
            return {"ok": False, "mesaj": "Paste the game folder path first."}
        return self._oyun_uygula(yol)

    def oyun_degistir(self):
        """Oyun klasorunu degistir: sec -> dogrula -> yaziciyi yeniden bagla.
        Gecersiz klasor secilirse HICBIR SEY degismez (mevcut baglanti korunur)."""
        if self._mesgul:
            return {"ok": False, "mesaj": "Another job is still running."}
        import webview
        bas = os.path.dirname(OYUN) if OYUN else ""
        s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG, directory=bas)
        if not s:
            return {"ok": False, "mesaj": "cancelled"}
        return self._oyun_uygula(s[0])

    def _oyun_uygula(self, yol):
        """Ortak dogrula + bagla adimi (oyun_degistir / oyun_yol_ayarla)."""
        try:
            if not os.path.isfile(os.path.join(yol, "DataPC_boot.forge")):
                return {"ok": False, "mesaj":
                        "That folder has no DataPC_boot.forge — pick the game's "
                        "install folder."}
            C.set_game(yol)
            global OYUN
            OYUN = os.path.dirname(C.DE.FORGE)
            with self._kilit:
                self._kare_onbellek.clear()
                if self._oturum is not None:
                    try:
                        self._oturum.kapat()
                    except Exception:
                        pass
                    self._oturum = None
            return {"ok": True, "yol": OYUN}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:250]}

    def ac(self, url):
        """Dis baglanti: SISTEM tarayicisinda ac (pencere icinde degil).

        Kullananlar: Follow Us · Nexus mod satirlari · guncelleme afisinin
        "Get the full package" dugmesi. Yalniz https kabul edilir."""
        if not str(url).startswith("https://"):
            return {"ok": False}
        import webbrowser
        webbrowser.open(url)
        return {"ok": True}

    # ================================================== baslangic verisi
    def _patch_yolu(self):
        return os.path.join(OYUN, "DataPC_boot_patch_02.forge")

    def _patch_bizim_mi(self, d):
        """charswap.json'daki parmak izi diskteki patch_02 ile tutuyor mu?

        Tutmuyorsa patch'i BASKA bir arac yazmis demektir: onu "bizim"
        sayip ustune yedeksiz yazmak (kur) ya da "Remove all"da silmek
        ucuncu-taraf modu kaybettirirdi (denetimde olculdu). Eski kayitlarda
        parmak izi yoksa (v0.9 oncesi) geriye uyum icin "bizim" sayilir.
        """
        pi = d.get("patch")
        if not pi:
            return True
        canli = dosya_parmak_izi(self._patch_yolu())
        if not canli:
            return False
        if canli["boyut"] != pi.get("boyut"):
            return False
        if canli["mtime_ns"] == pi.get("mtime_ns"):
            return True
        return canli["sha1mb"] == pi.get("sha1mb")

    def _durum_yaz(self, atamalar, ek=None):
        os.makedirs(os.path.dirname(DURUM_DOSYA), exist_ok=True)
        gorunen = {r["ad"]: r["gorunen_ad"] for r in KT.roster()}
        d = {"atamalar": {s: {"ad": x, "gorunen": gorunen.get(x, x)}
                          for s, x in atamalar.items()},
             "patch": dosya_parmak_izi(self._patch_yolu())}
        if ek:
            d.update(ek)
        with open(DURUM_DOSYA, "w", encoding="utf-8") as f:
            json.dump(d, f)

    def _atamalar(self):
        try:
            if not os.path.exists(self._patch_yolu()):
                return {}
            with open(DURUM_DOSYA, encoding="utf-8") as f:
                d = json.load(f)
            if not self._patch_bizim_mi(d):
                return {}
            if "atamalar" in d:
                return {s: v["ad"] for s, v in d["atamalar"].items()}
            if d.get("karakter"):
                return {"Whaler": d["karakter"]}
        except Exception:
            pass
        return {}

    # ---------------------------------------- kart listeleri (kategori + 3D)
    def _ek_indeksler(self):
        """Indeks araclarinin yazdigi yan dosyalar: kategori ve okunabilirlik
        alanlari once BURADAN, sonra katalog kaydinin kendisinden okunur.
        Dosya yoksa, bozuksa ya da bicimi degistiyse sessizce bos donulur —
        arayuz o zaman bugunku (kategorisiz) listeyi gosterir."""
        yollar = (
            ("out", os.path.join(KOK, "onizleme3d", "onizleme3d_indeks.json"), "kiyafetler"),
            ("wpn", os.path.join(KOK, "src", "export3d", "silah_indeks.json"), "silahlar"),
            ("chr", os.path.join(KOK, "src", "export3d", "karakter_indeks.json"), "karakterler"),
        )
        imza = []
        for _t, y, _a in yollar:
            try:
                st = os.stat(y)
                imza.append((y, st.st_mtime_ns, st.st_size))
            except OSError:
                imza.append((y, 0, 0))
        imza = tuple(imza)
        if getattr(self, "_ek_imza", None) == imza and getattr(self, "_ek_veri", None):
            return self._ek_veri
        out = {"chr": {}, "out": {}, "wpn": {}}
        for tur, yol, alan in yollar:
            try:
                with open(yol, encoding="utf-8") as f:
                    d = json.load(f)
                kayitlar = d.get(alan) if isinstance(d, dict) else None
                if isinstance(kayitlar, dict):
                    out[tur] = {str(k): v for k, v in kayitlar.items()
                                if isinstance(v, dict)}
                elif isinstance(kayitlar, list):
                    out[tur] = {str(v.get("ad")): v for v in kayitlar
                                if isinstance(v, dict) and v.get("ad")}
            except Exception:
                pass
        self._ek_imza, self._ek_veri = imza, out
        return out

    def _kart_listeleri(self):
        """{chr,out,wpn} -> kart kayitlari. Katalog + yan indeks BIR KEZ
        okunur (dosya damgasi degisince tazelenir): arama/sayfalama her
        cagrida binlerce dosya damgasi sorgulamasin."""
        ek = self._ek_indeksler()
        # imza UCUZ olmali (her aramada bakilir): katalog ve roster surece BIR
        # KEZ (import aninda) okunur, yan indeks dosyalari ise degisebilir
        imza = (getattr(self, "_ek_imza", None), len(getattr(C, "CATALOG", ()) or ()))
        if getattr(self, "_kart_imza", None) == imza and getattr(self, "_kart_veri", None):
            return self._kart_veri
        karakterler = []
        for r in KT.roster():
            kayit = {
                "ad": r["ad"], "gorunen": r["gorunen_ad"],
                "parca": r["parca_sayisi"], "kiyafet_n": len(r["kiyafetler"]),
                "portre": "varlik/portre/CHR_%s.png" % r["ad"],
                "render": "varlik/render/CHR_%s.png" % r["ad"],
            }
            # RESMI tanitim sanati (ansiklopediden cikarildi) varsa kapak odur
            kapak = os.path.join(BURA, "varlik", "sanat_kisi",
                                 "CHR_%s.png" % r["ad"])
            if os.path.isfile(kapak):
                kayit["kapak"] = "varlik/sanat_kisi/CHR_%s.png" % r["ad"]
                # kart icin TEPEDEN kirpilmis bust karesi (kafa garantili)
                kayit["kapak_bust"] = "varlik/kapak_bust/CHR_%s.png" % r["ad"]
            karakterler.append(self._kart_zenginlestir(kayit, r, ek["chr"]))
        kiyafetler, silahlar = [], []
        for o in C.list_outfits():
            kayit = {
                "ad": o["ad"], "gorunen": o["gorunen_ad"],
                "guvenlik": guvenlik_en(o["guvenlik_etiketi"]),
                "guvenlik_renk": o["guvenlik_etiketi"],
                "puan": o.get("guvenlik_puani") or 0,
                "materyal": o["materyal_sayisi"], "boyanabilir": o["boyanabilir_slot"],
            }
            # oyunun KENDI kapak ikonu (79 adet cozuldu; yoksa 3D render / arma)
            ikon = os.path.join(BURA, "varlik", "ikon", o["ad"] + ".png")
            if os.path.isfile(ikon):
                kayit["ikon"] = "varlik/ikon/%s.png" % o["ad"]
            if o.get("sinif") == "weapon":
                silahlar.append(self._kart_zenginlestir(kayit, o, ek["wpn"]))
            else:
                kayit["render"] = "varlik/render_outfit/%s.png" % o["ad"]
                kiyafetler.append(self._kart_zenginlestir(kayit, o, ek["out"]))
        # --- ENVANTERIN GERI KALANI (yalniz 3D): katalog disi silahlar + NPC kiyafet/
        #     karakter/murettebat. PNG boyama ve karakter takasi bu kartlarda YOK.
        if getattr(self, "ENVANTER_EKLE", True):        # testler sentetik katalogla kapatir
            try:
                self._envanter_kartlari(karakterler, kiyafetler, silahlar, ek)
            except Exception as e:                              # noqa: BLE001
                print("envanter kartlari eklenemedi:", e)
        self._kart_imza = imza
        self._kart_veri = {"chr": karakterler, "out": kiyafetler, "wpn": silahlar}
        return self._kart_veri

    _ENV_KAT = {"npc_outfit": "npc", "player_outfit": "player", "npc_character": "npc",
                "player_character": "player", "crew": "crew"}

    def _envanter_kartlari(self, karakterler, kiyafetler, silahlar, ek):
        """Katalog/roster disindaki her seyi SADECE-3D kart olarak ekler (yerinde)."""
        from export3d import sahne as S3
        var = {k["ad"] for k in karakterler} | {k["ad"] for k in kiyafetler} | \
              {k["ad"] for k in silahlar}
        # 1) silahlar: silah_indeks.json (241) - katalogdakiler (88)
        try:
            sidx, _y = S3.silah_indeks_yukle()
        except Exception:                                       # noqa: BLE001
            sidx = {}
        for ad, v in sidx.items():
            if ad in var or not isinstance(v, dict):
                continue
            okunur = bool(v.get("okunur", v.get("mesh_okunur", 0)))
            neden = None
            if not okunur:
                seb = v.get("okunmama_sebepleri") or {}
                neden = next(iter(seb), None) if isinstance(seb, dict) else str(seb or "")
            k = {"ad": ad, "gorunen": v.get("gorunen_ad") or ad, "guvenlik": "3D ONLY",
                 "guvenlik_renk": "", "puan": 0, "materyal": len(v.get("katalog_materyal") or []),
                 "boyanabilir": 0, "sadece_3d": True,
                 "kategori": kategori_kodu(v) or "player", "okunabilir": okunur}
            if not okunur:
                k["neden_kod"], k["neden"] = "altbicim", (neden or "unsupported mesh sub-variant")
            k["_ara"] = " ".join(str(x).lower() for x in (k["gorunen"], k["ad"], k["kategori"]))
            silahlar.append(k)
            var.add(ad)
        # 2) kiyafetler + karakterler: parca_envanteri.json (446) - indekstekiler (77)
        env, _y = S3.envanter_yukle()
        for ad, v in env.items():
            if ad in var or not isinstance(v, dict):
                continue
            kat = self._ENV_KAT.get(str(v.get("kategori") or ""), "npc")
            parcalar = v.get("parcalar") or []
            okunur_n = sum(1 for p in parcalar if p.get("okunabilir", True) and (p.get("lodlar") or []))
            okunur = okunur_n > 0
            k = {"ad": ad, "gorunen": v.get("gorunen_ad") or ad, "kategori": kat,
                 "okunabilir": okunur, "sadece_3d": True}
            if not okunur:
                seb = next((p.get("sebep") for p in parcalar if p.get("sebep")), None)
                k["neden_kod"], k["neden"] = "altbicim", (seb or "no readable part")
            k["_ara"] = " ".join(str(x).lower() for x in (k["gorunen"], k["ad"], k["kategori"]))
            # bolme KATEGORIYE gore: *_character -> karakterler; *_outfit -> kiyafetler;
            # crew: CHR_ anahtari karakter, digerleri (S_AsianCrew...) murettebat kiyafeti
            kat_ham = str(v.get("kategori") or "")
            kiyafet_mi = kat_ham.endswith("_outfit") or (kat_ham == "crew" and not ad.startswith("CHR_"))
            if kiyafet_mi:
                k.update({"guvenlik": "3D ONLY", "guvenlik_renk": "", "puan": 0,
                          "materyal": sum(len(p.get("materyaller") or []) for p in parcalar),
                          "boyanabilir": 0})
                kiyafetler.append(k)
            else:
                k.update({"parca": len(parcalar), "kiyafet_n": 0, "takas": False,
                          "portre": "", "render": ""})
                karakterler.append(k)
            var.add(ad)

    def _kart_zenginlestir(self, kayit, katalog, ek):
        """Kategori + okunabilirlik + arama metni. Kaynak sirasi: yan indeks
        kaydi, sonra katalog kaydinin kendisi."""
        yan = ek.get(kayit["ad"]) or {}
        kayit["kategori"] = kategori_kodu(yan, katalog)
        okunur, kod, ham = okunabilirlik(yan, katalog)
        kayit["okunabilir"] = okunur
        if not okunur:
            kayit["neden_kod"] = kod
            kayit["neden"] = ham
        kayit["_ara"] = " ".join(str(x).lower() for x in
                                 (kayit["gorunen"], kayit["ad"], kayit["kategori"]))
        return kayit

    def _kart_suz(self, tur, kelime="", kategori=None, secenek=None):
        """(eslesenler, kategori_sayilari, okunamaz_sayisi). Kategori sayilari
        SECILI kategoriden ve arama kutusundan BAGIMSIZ, ama okunamaz/kurulu
        onay kutulariyla uyumlu sayilir (Sounds sekmesindeki davranisin ayni)."""
        s = secenek or {}
        okunamaz_goster = bool(s.get("okunamaz"))
        yalniz_kurulu = bool(s.get("kurulu")) and tur == "chr"
        kurulu = set(self._atamalar().values()) if yalniz_kurulu else set()
        kelimeler = [k for k in re.split(r"\s+", str(kelime or "").strip().lower()) if k]
        eslesen, sayilar, okunamaz_n = [], {}, 0
        for sira, k in enumerate(self._kart_listeleri().get(tur) or []):
            if yalniz_kurulu and k["ad"] not in kurulu:
                continue
            if not k.get("okunabilir", True):
                okunamaz_n += 1
                if not okunamaz_goster:
                    continue
            kod = k.get("kategori") or "player"
            sayilar[kod] = sayilar.get(kod, 0) + 1
            if kategori and kod != kategori:
                continue
            p = _arama_puani(k, kelimeler)
            if p is None:
                continue
            eslesen.append((p, sira, k))
        eslesen.sort(key=lambda x: (x[0], x[1]))   # esit puanda KATALOG sirasi
        return eslesen, sayilar, okunamaz_n

    def varlik_durum(self, tur="chr", secenek=None):
        """Cip satiri: hangi kategoriler VAR ve kacar satir tasiyorlar +
        disa aktarilamayan satir sayisi. Sayilar indeksten okunur."""
        try:
            if tur not in ("chr", "out", "wpn"):
                return {"ok": False, "mesaj": "This list is not available."}
            _e, sayilar, okunamaz_n = self._kart_suz(tur, "", None, secenek)
            sirali = sorted(sayilar.items(),
                            key=lambda x: (KAT_SIRA.index(x[0]) if x[0] in KAT_SIRA
                                           else 99, x[0]))
            return {"ok": True, "toplam": sum(sayilar.values()),
                    "okunamaz": okunamaz_n,
                    "kategoriler": [{"kod": k, "ad": KAT_ADLARI.get(k, k.title()),
                                     "sayi": n} for k, n in sirali]}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def varlik_ara(self, tur="chr", kelime="", kategori=None, secenek=None):
        """Kart listesi (SAYFALI — Sounds ile ayni sozlesme). secenek:
        {okunamaz, kurulu, baslangic}. Doner {ok, sayi, kayitlar, baslangic,
        bitti}; sayfa boyu sunucuda sabittir (VARLIK_SAYFA)."""
        try:
            if tur not in ("chr", "out", "wpn"):
                return {"ok": False, "mesaj": "This list is not available."}
            s = secenek or {}
            try:
                baslangic = max(0, int(s.get("baslangic") or 0))
            except (TypeError, ValueError, OverflowError):   # OverflowError: int(inf)
                baslangic = 0
            eslesen, _sayilar, _n = self._kart_suz(tur, kelime, kategori, secenek)
            dilim = eslesen[baslangic:baslangic + VARLIK_SAYFA]
            kayitlar = [{a: b for a, b in k.items() if a != "_ara"}
                        for _p, _i, k in dilim]
            return {"ok": True, "sayi": len(eslesen), "kayitlar": kayitlar,
                    "baslangic": baslangic,
                    "bitti": baslangic + len(kayitlar) >= len(eslesen)}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def baslangic(self):
        self._sayfa_canli = True          # kopru calisti = arayuz gercekten acildi
        L = self._kart_listeleri()
        karakterler = [{a: b for a, b in k.items() if a != "_ara"} for k in L["chr"]]
        kiyafetler = [{a: b for a, b in k.items() if a != "_ara"} for k in L["out"]]
        silahlar = [{a: b for a, b in k.items() if a != "_ara"} for k in L["wpn"]]
        return {"karakterler": karakterler, "kiyafetler": kiyafetler,
                "silahlar": silahlar, "slotlar": KT.hedef_slotlar(),
                "atamalar": self._atamalar(), "oyun": OYUN,
                "cikti_klasoru": OUTPUT, "dil": ayar_oku().get("dil") or "",
                "surum": self._surum()}

    def _surum(self):
        try:
            import guncelle as G
            return G.yerel_surum().get("surum") or "?"
        except Exception:                                       # noqa: BLE001
            return "?"

    # ---------------------------------------- kendi kendine guncelleme
    def guncelleme_kontrol(self):
        """Uzak surum.json'u okur (ag; kisa zaman asimi). Hicbir sey indirmez/kurmaz."""
        try:
            import guncelle as G
            r = G.kontrol(ayar=ayar_oku())
            r.pop("uzak_ham", None)
            return r
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "yeni_var": False, "mesaj": str(e)[:200]}

    def guncelleme_kur(self):
        """Indir + sha dogrula + izinli koklere yaz + yedekle. Kullanici onayindan sonra
        cagrilir; oyun acikken de calisir (oyun dosyasina dokunmaz)."""
        try:
            import guncelle as G
            k = G.kontrol(ayar=ayar_oku())
            # TAM PAKET durumu: kullanicinin surumu delta tabanindan eski. "nothing to
            # update" demek kullaniciyi sessizce geride birakirdi -- kurtarma yolunu
            # (Nexus tam paketi) ADRESIYLE birlikte soyleriz; arayuz bunu afiste gosterir.
            if k.get("ok") and k.get("tam_paket_gerek"):
                adres = k.get("nexus") or ""
                m = k.get("mesaj") or ("your copy is older than this update's base package, so the "
                                       "small update would not be enough.")
                if adres and adres not in m:
                    m += " Full package: %s" % adres
                return {"ok": False, "tam_paket_gerek": True, "nexus": adres, "mesaj": m}
            if not k.get("ok") or not k.get("yeni_var"):
                return {"ok": False, "mesaj": k.get("mesaj") or "nothing to update."}
            self._log("- update: %s" % k.get("mesaj"))
            # `bar` SAYISAL ilerleme tasir (guncelle.py uretir). Eskiden yalniz `progress`
            # geciriliyordu ve _log'un "N/M" regexi bu yolda hicbir sey yakalamadigi icin
            # 105 MB'lik indirme boyunca bar %0'da duruyordu.
            ind = G.indir(k["uzak"], progress=self._log, bar=self._bar)
            if not ind.get("ok"):
                return {"ok": False, "mesaj": ind.get("mesaj")}
            r = G.kur(ind["zip"], k["uzak"], progress=self._log, bar=self._bar)
            self._log("- update: %s" % r.get("mesaj"))
            return r
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:200]}

    def guncelleme_geri_al(self):
        try:
            import guncelle as G
            return G.geri_al()
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:200]}

    def atamalar_durum(self):
        """Yalniz kurulu karakter atamalari. yenile() bunu cagirir:
        baslangic() TUM kart listelerini tasir ve listeler binlere
        cikinca her is bitiminde bosuna 1 MB kopru trafigi olurdu."""
        return {"ok": True, "atamalar": self._atamalar()}

    def durum_ozet(self):
        """Dashboard istatistikleri (salt okunur; yazicinin kendi on-kontrolu)."""
        ozet = {"karakter_kurulu": len(self._atamalar()),
                "boyali": 0, "boyali_atlanan": 0, "kayit_var": False}
        try:
            if os.path.exists(C.DE.KAYIT):
                rc = C.revert_check()
                ozet["kayit_var"] = bool(rc.get("kayit"))
                ozet["boyali"] = rc.get("geri_alinacak", 0)
                ozet["boyali_atlanan"] = rc.get("atlanan", 0)
        except Exception:
            pass
        return ozet

    # ================================================== HEALTH CHECK
    def boyama_takili_temizle(self):
        """Saglik kontrolundeki 'Clear stuck job' dugmesi. Arsive YAZMAZ; yalniz takili
        boyama kaydini ve yedeklerini tarihli klasore tasir (outfit_core)."""
        try:
            r = C.boyama_takili_temizle(progress=self._log)
            self._log("- stuck paint job: %s" % (r.get("klasor") or r.get("mesaj")))
            return r
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:200]}

    def saglik_kontrol(self):
        """HEALTH CHECK — tamamen SALT-OKUMA tanilama.

        Arsive TEK BAYT yazmaz; yalnizca okur ve raporlar. Sahadan gelen uc
        kusurun (MOTW · bos pencere · 0xFFA) hepsini ONCEDEN yakalayabilecek
        kontrolleri tek yerde toplar ve kullanicinin paylasabilecegi duz-metin
        rapor uretir. Kullaniciya giden her metin INGILIZCE.
        """
        K = []

        def ekle(ad, durum, deger, oneri="", eylem=None):
            K.append({"ad": ad, "durum": durum, "deger": str(deger),
                      "oneri": oneri})
            if eylem:
                K[-1]["eylem"] = eylem

        # ---- 1) oyun kurulumu -------------------------------------------
        forge_yolu = oyun_kok = None
        try:
            if C.game_found():
                forge_yolu = C.DE.FORGE
                oyun_kok = os.path.dirname(forge_yolu)
        except Exception:
            pass
        if oyun_kok and os.path.isfile(forge_yolu):
            try:
                gb = os.path.getsize(forge_yolu) / (1024.0 ** 3)
            except OSError:
                gb = 0.0
            ekle("Game installation", "YESIL",
                 "%s  (DataPC_boot.forge, %.1f GB)" % (oyun_kok, gb))
        else:
            ekle("Game installation", "KIRMIZI", "not found",
                 "Use the game-folder button at the bottom left and pick the "
                 "folder that contains DataPC_boot.forge.")

        # ---- 2) ucuncu-taraf mod arsivleri (0xFFA kusurunun sebebi) -----
        if oyun_kok:
            ekstra = None                # None = OLCULEMEDI (bos liste DEGIL)
            try:
                from karakter_takas.sistem_giris import ucuncu_taraf_kap_mi
                ekstra = sorted(f for f in os.listdir(oyun_kok)
                                if f.lower().endswith(".forge")
                                and ucuncu_taraf_kap_mi(f))
            except Exception as e:
                # olculemeyeni YESIL gostermek sahte guven olur
                ekle("Third-party mod archives", "SARI",
                     "could not be checked", str(e)[:120])
            if ekstra is None:
                pass
            elif not ekstra:
                ekle("Third-party mod archives", "YESIL", "none")
            else:
                gorunen = ", ".join(ekstra[:4]) + (" ..." if len(ekstra) > 4 else "")
                ekle("Third-party mod archives", "SARI",
                     "%d found: %s" % (len(ekstra), gorunen),
                     "Other .forge mods are installed. That is fine, but if a "
                     "character install ever fails, remove them and try again.")

        # ---- 2b) forge DISI mod dosyalari (2026-10-12) -------------------
        # Nexus, Crybox95: kayit yuklenince cokus; sebep klasorde kalmis ucuncu taraf
        # modlardi ve rapor "Third-party mod archives: none" diyordu (yalniz .forge
        # bakiyordu). Bilgi satiri YESIL: ReShade gibi bilincli kurulumlar sorun degil.
        if oyun_kok:
            try:
                adlar = os.listdir(oyun_kok)
                kucuk = {a.lower(): a for a in adlar}
                yukleyici = [kucuk[d] for d in (
                    "dinput8.dll", "winmm.dll", "version.dll", "d3d9.dll", "d3d11.dll",
                    "d3d12.dll", "dxgi.dll", "xinput1_3.dll", "xinput1_4.dll", "dsound.dll",
                    "winhttp.dll") if d in kucuk]
                asi = [a for a in adlar if a.lower().endswith(".asi")]
                for alt in ("scripts", "plugins", "asi"):
                    ad = os.path.join(oyun_kok, alt)
                    if os.path.isdir(ad):
                        asi += [alt + "/" + a for a in os.listdir(ad)
                                if a.lower().endswith(".asi")]
                bulunan = yukleyici + asi
                if "reshade.ini" in kucuk and bulunan:
                    bulunan[0] = bulunan[0] + " (ReShade)"
                if bulunan:
                    gorunen = ", ".join(bulunan[:5]) + (" ..." if len(bulunan) > 5 else "")
                    ekle("Other mod files (DLL/ASI)", "YESIL",
                         "%d found: %s" % (len(bulunan), gorunen),
                         "These are not Workshop files. If the game crashes while loading "
                         "a save, move them out of the game folder first and try again.")
                else:
                    ekle("Other mod files (DLL/ASI)", "YESIL", "none")
            except Exception as e:                              # noqa: BLE001
                ekle("Other mod files (DLL/ASI)", "SARI", "could not be checked",
                     str(e)[:120])

        # ---- 3) tarayici motoru (bos pencere kusurunun sebebi) ----------
        try:
            wv = _webview2_hazir_mi()
        except Exception:
            wv = None
        if wv is True:
            ekle("Browser engine (WebView2)", "YESIL", "installed")
        elif wv is False:
            ekle("Browser engine (WebView2)", "SARI", "not installed",
                 "The modern interface needs it. Install the free runtime from "
                 "https://developer.microsoft.com/microsoft-edge/webview2")
        else:
            ekle("Browser engine (WebView2)", "SARI", "could not be checked")

        # ---- 4) boyanmis dokular + geri alma kaydi ----------------------
        try:
            kayit_yolu = C.DE.KAYIT
        except Exception:
            kayit_yolu = None
        if kayit_yolu and os.path.exists(kayit_yolu):
            try:
                rc = C.revert_check()
                sorun = rc.get("sorunlar") or []
                n = rc.get("geri_alinacak", 0)
                # TAKILI IS (2026-10-12, Nexus Ninjozzo): eskiden burada "Revert may refuse"
                # ve hemen altinda "Running Revert will put the archive back" birlikte
                # basiliyordu -- ikisi celisiyordu ve kullanicinin cikis yolu yoktu.
                takili = bool(getattr(C, "boyama_takili_mi", None) and C.boyama_takili_mi(rc))
                if takili:
                    ekle("Painted textures", "KIRMIZI", "a previous Apply was interrupted",
                         "Revert cannot undo it: the record does not show what was written. "
                         "1) In Steam: Properties > Installed Files > Verify integrity of "
                         "game files. 2) Then press Clear stuck job. Nothing is deleted - "
                         "the old record and its backups are moved to a dated folder.",
                         eylem={"api": "boyama_takili_temizle", "etiket": "Clear stuck job",
                                "onay": "Did you already run Verify integrity of game files "
                                        "in Steam? Clear the stuck paint job now?"})
                elif sorun:
                    ekle("Painted textures", "KIRMIZI",
                         "%d entries, %d problem(s)" % (n, len(sorun)),
                         "Revert may refuse to run. First problem: %s"
                         % str(sorun[0])[:150])
                else:
                    ekle("Painted textures", "YESIL",
                         "%d entries, revert is ready" % n)
                if rc.get("durum") != "done" and not takili:
                    ekle("Last paint job", "SARI", str(rc.get("durum", "?")),
                         "A previous Apply did not finish cleanly. Running "
                         "Revert will put the archive back.")
            except Exception as e:
                ekle("Painted textures", "SARI", "record unreadable",
                     str(e)[:150])
        else:
            ekle("Painted textures", "YESIL", "none (nothing to revert)")

        # ---- 4b) IMPORT 3D ile yazilmis MESH yamalari --------------------
        # Doku ve mesh AYRI depolarda durur ama ayni arsive yazar. Kullanici
        # ikisini TEK ekranda gormezse birini geri alip "temiz" sanir.
        try:
            from export3d import kur_mesh as KM
            md = KM.durum(forge_yolu) if forge_yolu else KM.durum()
            if md.get("aktif"):
                gorunen = ", ".join(y["etiket"] or y["gid"] for y in md["yamalar"][:3])
                if len(md["yamalar"]) > 3:
                    gorunen += " ..."
                ekle("Imported 3D models (mesh patches)", "YESIL",
                     "%d active, %.1f MB added to the archive: %s"
                     % (md["aktif"], md.get("buyume", 0) / 1e6, gorunen),
                     "Revert puts every one of them back.")
                yarim = [y for y in md["yamalar"] if y.get("durum") != "uygulandi"]
                if yarim:
                    ekle("Last model import", "SARI",
                         "%d patch(es) did not finish cleanly" % len(yarim),
                         "Running Revert will put the archive back.")
            else:
                ekle("Imported 3D models (mesh patches)", "YESIL", "none")
            # ARSIV BOYU: kur_mesh, arsivin kendi tabanindan kac bayt buyuk oldugunu
            # olcer. None = bu depoda taban tasiyan kayit yok -> HICBIR SEY yazma
            # (bilmedigimizi bilmek, sahte "temiz" satirindan iyidir). 0 da satir
            # uretmez: soylenecek bir sey yoktur. Yamalar KURULUYKEN buyume
            # BEKLENENDIR ve YESIL basilir — "uyari sadece sorun varsa".
            kb = md.get("kuyruk_bayt")
            # BILINMIYOR (None) ile TEMIZ (0) ayni sey DEGIL. Eskiden `if kb:` ikisini de
            # ayni kefeye koyuyordu ve Health Check hicbir satir basmiyordu; kullanici
            # icin SUSMAK "temiz" demekle ayni sey. kur_mesh artik neden bilmedigini de
            # bildiriyor (kuyruk_biliniyor / kuyruk_kaynak / kuyruk_mesaj) -- okuyalim.
            # `forge_yolu` SARTI onemli: oyun klasoru bulunamadiginda durum() argumansiz
            # cagriliyor ve dogal olarak "bilmiyorum" donuyor. Orada sari satir basmak
            # GURULTU olurdu -- oyunun bulunamadigini zaten baska satirlar soyluyor.
            # Uyari yalniz ARSIV ELDEYKEN ama taban BILINMIYORKEN anlamli.
            if forge_yolu and kb is None and md.get("kuyruk_biliniyor") is False:
                ekle("Archive size", "SARI",
                     md.get("kuyruk_mesaj")
                     or "The tool could not work out the archive's original size.",
                     "This check needs a record of how big the archive was before the "
                     "first patch. That record is missing here, so the archive may or "
                     "may not be carrying leftover bytes - this panel cannot tell. "
                     "Press Revert all to put every patch back, then run this check again.")
            elif kb:
                if md.get("aktif"):
                    ekle("Archive size", "YESIL",
                         "%d bytes above the size it had before the first model "
                         "patch (expected while patches are installed)" % kb)
                else:
                    ekle("Archive size", "SARI",
                         "%d bytes above the size it had before the first model "
                         "patch, with no model patch installed" % kb,
                         "Every model patch was reverted but the archive did not "
                         "shrink back. That happens when another tool wrote to the "
                         "end of the archive after Workshop did. Revert that tool's "
                         "patches as well, then press Revert all here once more and "
                         "the space comes back.")
        except Exception as e:                                  # noqa: BLE001
            ekle("Imported 3D models (mesh patches)", "SARI", "could not be checked",
                 str(e)[:150])

        # ---- 5) kurulu karakterler + yedek ------------------------------
        try:
            atamalar = self._atamalar()
        except Exception:
            atamalar = {}
        if atamalar:
            yedek = os.path.join(oyun_kok or "",
                                 "DataPC_boot_patch_02.forge.charswap_bak")
            if os.path.exists(yedek):
                ekle("Installed characters", "YESIL",
                     "%d installed, previous archive backed up" % len(atamalar))
            else:
                ekle("Installed characters", "SARI",
                     "%d installed, no backup of a previous mod" % len(atamalar),
                     "This is normal if you had no character mod before.")
        else:
            ekle("Installed characters", "YESIL", "none")

        # ---- 5b) ucuncu-taraf patch_02 (bizim kaydimizla uyusmuyor) -----
        try:
            if oyun_kok and os.path.exists(self._patch_yolu()) and not atamalar \
                    and os.path.exists(DURUM_DOSYA):
                with open(DURUM_DOSYA, encoding="utf-8") as f:
                    d0 = json.load(f)
                if d0.get("atamalar") and not self._patch_bizim_mi(d0):
                    ekle("Character patch", "SARI",
                         "DataPC_boot_patch_02.forge was replaced by another tool",
                         "Your character swaps are not active. Install a character "
                         "again to write a fresh patch (the other mod is backed up).")
        except Exception:
            pass

        # ---- 5c) ses degisiklikleri -------------------------------------
        try:
            import ses_core as SS
            sd = SS.durum()
            n_t, n_m = sd.get("takas", 0), sd.get("sustur", 0)
            if n_t or n_m:
                ekle("Sound changes", "YESIL",
                     "%d replaced, %d muted - revert is ready" % (n_t, n_m))
            else:
                ekle("Sound changes", "YESIL", "none")
        except Exception:
            pass

        # ---- 6) yazma izni + disk alani ---------------------------------
        if oyun_kok:
            yazilir = os.access(oyun_kok, os.W_OK)
            ekle("Write access to game folder",
                 "YESIL" if yazilir else "KIRMIZI",
                 "yes" if yazilir else "no",
                 "" if yazilir else
                 "Windows is blocking writes to the game folder. Run Workshop "
                 "as administrator, or move the game out of a protected folder.")
            try:
                bos = shutil.disk_usage(oyun_kok).free / (1024.0 ** 3)
                ekle("Free disk space", "YESIL" if bos >= 5 else "SARI",
                     "%.1f GB" % bos,
                     "" if bos >= 5 else
                     "Painting and character installs need a few GB of room.")
            except Exception:
                pass

        # ---- 7) araclar --------------------------------------------------
        try:
            # Dosyanin VARLIGI yetmez (2026-10-25): Smart App Control acik makinede dosya
            # durur ama yuklenemez; satir "found" deyip boyamanin neden dustugunu gizliyordu.
            td = C.tex_encode_durumu() if hasattr(C, "tex_encode_durumu") else {
                "var": os.path.isfile(os.path.join(C.TOOLS_DIR, "TexEncode.exe")), "sac": False}
            if not td.get("var"):
                ekle("Texture encoder", "KIRMIZI", "missing",
                     "TexEncode.exe is missing - your antivirus may have "
                     "quarantined it. Re-extract the download and allow the folder.")
            elif td.get("sac"):
                ekle("Texture encoder", "KIRMIZI", "blocked by Windows Smart App Control",
                     "Painting textures and installing PNG textures will not work on this PC "
                     "while Windows blocks the encoder. Everything else works. The setting is "
                     "in Windows Security > App & browser control > Smart App Control.")
            else:
                ekle("Texture encoder", "YESIL", "found")
        except Exception:
            pass
        try:
            oodle = C.DE.OODLE_DLL
            var = bool(oodle) and os.path.isfile(oodle)
            ekle("Compression library", "YESIL" if var else "KIRMIZI",
                 "found" if var else "missing",
                 "" if var else
                 "The oo2core compression DLL was not found - re-extract the "
                 "download.")
        except Exception:
            pass

        # ---- genel hukum + paylasilabilir rapor -------------------------
        if any(k["durum"] == "KIRMIZI" for k in K):
            genel = "KIRMIZI"
        elif any(k["durum"] == "SARI" for k in K):
            genel = "SARI"
        else:
            genel = "YESIL"
        ETIKET = {"YESIL": "OK", "SARI": "WARN", "KIRMIZI": "FAIL"}
        satirlar = ["Workshop health check", "=" * 52]
        for k in K:
            satirlar.append("[%-4s] %-28s %s"
                            % (ETIKET[k["durum"]], k["ad"], k["deger"]))
            if k["oneri"]:
                satirlar.append("         -> %s" % k["oneri"])
        satirlar.append("=" * 52)
        satirlar.append("overall: %s" % ETIKET[genel])
        return {"ok": True, "genel": genel, "kontroller": K,
                "rapor": "\n".join(satirlar)}

    def panoya(self, metin):
        """Raporu panoya kopyala — kullanici Discord/Nexus'a yapistirabilsin."""
        try:
            p = subprocess.run(["clip"], input=str(metin), text=True,
                               timeout=10,
                               creationflags=getattr(subprocess,
                                                     "CREATE_NO_WINDOW", 0))
            return {"ok": p.returncode == 0}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:120]}

    # ================================================== CHEATS (kayit duzenleyici)
    def _kayitlar(self):
        """Kayit oturumunu tembel kur (hesap otomatik bulunur)."""
        if getattr(self, "_kyt", None) is None:
            import save_core as SV
            self._kyt = SV.Kayitlar()
        return self._kyt

    def save_durum(self):
        """Kayit sistemi hazir mi? (salt-okuma)"""
        try:
            import save_core as SV
        except Exception as e:
            return {"ok": False, "mesaj": "Save editor unavailable: %s" % str(e)[:120]}
        try:
            K = self._kayitlar()
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        try:
            L = K.liste()
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        try:
            hesaplar = [{"uuid": x["uuid"], "kayit": x["kayit_sayisi"],
                         "son": time.strftime("%Y-%m-%d %H:%M",
                                              time.localtime(x["son_oynama"]))}
                        for x in SV.dogrulanmis_hesaplar()]
        except Exception:
            hesaplar = []
        return {"ok": True, "hesap": K.uuid, "klasor": K.klasor,
                "hesaplar": hesaplar,
                "oyun_acik": K.oyun_acik_mi(),
                "kayitlar": [x for x in L if x["okunur"]],
                "alanlar": SV.alanlar()}

    def save_hesap_sec(self, uuid):
        """Birden fazla Ubisoft hesabi varsa kullanici secsin."""
        import save_core as SV
        try:
            h = next(x for x in SV.dogrulanmis_hesaplar() if x["uuid"] == uuid)
            self._kyt = SV.Kayitlar(h["klasor"], h["uuid"])
            self._save_adaylar = None
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def save_ara(self, kayit, deger, turler=None):
        """Kayitta bir degeri ARA (Cheat Engine mantigi, dosya uzerinde).

        Kullanici oyunda gordugu degeri girer; kayitta o degerin gectigi tum
        konumlar doner. Birden fazlaysa `save_daralt` ile teke indirilir.
        """
        import save_core as SV
        try:
            K = self._kayitlar()
            _b, g = K.govde(kayit)
            d = int(deger)
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        t = tuple(turler) if turler else ("u32", "i32")
        bul = SV.ara_deger(g, d, turler=t)
        self._save_adaylar = bul
        self._save_adaylar_kayit = kayit
        return {"ok": True, "sayi": len(bul), "deger": d,
                "adaylar": [{"ofset": x["ofset"], "tur": x["tur"]}
                            for x in bul[:200]]}

    def save_daralt(self, kayit, yeni_deger):
        """Ikinci tarama: deger degistikten sonra aday listesini daralt."""
        import save_core as SV
        adaylar = getattr(self, "_save_adaylar", None)
        if not adaylar:
            return {"ok": False, "mesaj": "Search for a value first."}
        if getattr(self, "_save_adaylar_kayit", None) not in (None, kayit):
            return {"ok": False, "mesaj": "The candidates were found in another "
                                          "save. Search again for this save."}
        try:
            K = self._kayitlar()
            _b, g = K.govde(kayit)
            kalan = SV.daralt(g, adaylar, int(yeni_deger))
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        self._save_adaylar = kalan
        return {"ok": True, "sayi": len(kalan),
                "adaylar": [{"ofset": x["ofset"], "tur": x["tur"]}
                            for x in kalan[:200]]}

    def save_oku(self, kayit, ofset, tur="u32"):
        """Tek bir konumdaki degeri oku (salt-okuma)."""
        import save_core as SV
        try:
            K = self._kayitlar()
            _b, g = K.govde(kayit)
            return {"ok": True, "deger": SV.deger_oku(g, int(ofset), tur)}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def save_yaz(self, kayit, ofset, deger, tur="u32"):
        """Degeri YAZ. Once otomatik yedek, sonra kapili yazim.

        Oyun acikken REDDEDER (Anvil cikista kaydi ezer).
        """
        import save_core as SV
        try:
            K = self._kayitlar()
            veri = SV.deger_paketle(int(deger), tur)
            r = K.yaz(kayit, [(int(ofset), veri)])
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:250]}
        return {"ok": True, "degisen_bayt": r["degisen_bayt"],
                "yedek": r["yedek"]}

    def save_alan_ekle(self, ad, ofset, tur="u32", en_az=0, en_cok=0):
        """Bulunan bir alani KALICI olarak katalogla — bir daha aranmasin."""
        import json as _json
        import save_core as SV
        y = SV.katalog_yolu()
        try:
            veri = {"alanlar": []}
            if os.path.isfile(y):
                with open(y, encoding="utf-8") as f:
                    veri = _json.load(f)
            veri.setdefault("alanlar", [])
            veri["alanlar"] = [a for a in veri["alanlar"]
                               if a.get("ad") != ad]
            veri["alanlar"].append({"ad": ad, "ofset": int(ofset), "tur": tur,
                                    "en_az": int(en_az), "en_cok": int(en_cok)})
            with open(y, "w", encoding="utf-8") as f:
                _json.dump(veri, f, indent=1, ensure_ascii=False)
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        return {"ok": True, "alanlar": SV.alanlar()}

    def save_yedek_ac(self):
        """Yedek klasorunu Gezgin'de ac."""
        try:
            k = self._kayitlar().yedek_klasoru()
            os.makedirs(k, exist_ok=True)
            os.startfile(k)                                   # noqa: S606
            return {"ok": True, "yol": k}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    # ================================================== SOUNDS (v2)
    def _onizleme_sunucusu(self):
        """On dinleme WAV'lari icin yerel HTTP sunucusu (127.0.0.1, rastgele port).

        Sayfa pywebview'in kendi sunucusundan gelir; WAV dosyalari
        %LOCALAPPDATA% altinda oldugu icin ayri, salt-okunur, yalniz
        yerel adrese bagli bir sunucu gerekir. <audio src> ayni-kaynak
        gerektirmez.
        """
        if getattr(self, "_onz_port", None):
            return self._onz_port
        import ses_core as SS
        from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
        import functools
        os.makedirs(SS.ONIZLEME_DIR, exist_ok=True)

        class Sessiz(SimpleHTTPRequestHandler):
            def log_message(self, *a):        # konsola dokme
                pass

            def end_headers(self):
                self.send_header("Cache-Control", "no-store")
                SimpleHTTPRequestHandler.end_headers(self)

        H = functools.partial(Sessiz, directory=SS.ONIZLEME_DIR)
        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self._onz_srv = srv
        self._onz_port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return self._onz_port

    def ses_durum(self, diyalog=False, bos=False):
        """Ses sistemi hazir mi + kategoriler + ozet + aktif degisiklikler."""
        try:
            import ses_core as SS
        except Exception as e:
            return {"ok": False, "mesaj": "Sound tools unavailable: %s"
                                          % str(e)[:120]}
        try:
            yol = SS.ses_forge_yolu()
            if not yol or not os.path.isfile(yol):
                return {"ok": False, "mesaj":
                        "The game's sound archive was not found. Set the game "
                        "folder first."}
            return {"ok": True, "kategoriler": SS.kategoriler(bool(diyalog), bool(bos)),
                    "ozet": SS.ozet(), "oyun_acik": SS.oyun_acik_mi(),
                    "durum": SS.durum(), "vgmstream": bool(SS.vgmstream_yolu())}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def ses_ara(self, kelime="", kategori=None, secenek=None):
        """Ses ara. secenek: {diyalog, bos, susturulabilir, sirala, en_az, en_cok,
        baslangic}. baslangic = sayfa ofseti (sonsuz kaydirma); sayfa boyu 400
        SABIT, yanit {ok, sayi, sesler, baslangic, bitti}."""
        try:
            import ses_core as SS
            s = secenek or {}
            try:
                baslangic = max(0, int(s.get("baslangic") or 0))
            except (TypeError, ValueError, OverflowError):   # OverflowError: int(inf)
                baslangic = 0
            r = SS.ara(kelime or "", kategori or None,
                       diyalog=bool(s.get("diyalog")), bos=bool(s.get("bos")),
                       yalniz_susturulabilir=bool(s.get("susturulabilir")),
                       en_az_sure=s.get("en_az"), en_cok_sure=s.get("en_cok"),
                       sirala=s.get("sirala") or "ad", en_fazla=400,
                       baslangic=baslangic)
            r["ok"] = True
            return r
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def ses_onizle(self, anahtar):
        """Sesi WAV'a cevir, yerel adresini dondur (sayfa <audio> ile calar)."""
        try:
            import ses_core as SS
            wav, hata = SS.wav_uret(anahtar)
            if not wav:
                return {"ok": False, "mesaj": hata or "preview failed"}
            port = self._onizleme_sunucusu()
            import urllib.parse
            return {"ok": True, "url": "http://127.0.0.1:%d/%s?t=%d"
                    % (port, urllib.parse.quote(os.path.basename(wav)),
                       int(os.path.getmtime(wav)))}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def ses_sustur_plan(self, anahtar):
        try:
            import ses_core as SS
            return SS.sustur_plani(anahtar)
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def ses_sustur(self, anahtar, etiket=""):
        """Sesi sustur (kisa is; kilit altinda, sonucu dogrudan doner)."""
        if self._mesgul_mu():
            return {"ok": False, "mesaj": "Another job is still running."}
        try:
            import ses_core as SS
            r = SS.sustur(anahtar, etiket or "")
            if r.get("ok"):
                r["mesaj"] = {"t": "Muted. {0} copy/copies written - start the game to check.",
                              "a": [r.get("yazilan", 1)]}
            return r
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        finally:
            self._serbest()

    def ses_sesi_ac(self, anahtar):
        if self._mesgul_mu():
            return {"ok": False, "mesaj": "Another job is still running."}
        try:
            import ses_core as SS
            r = SS.sesi_ac(anahtar)
            if r.get("ok"):
                r["mesaj"] = "Unmuted - the original bytes are back."
            return r
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        finally:
            self._serbest()

    def ses_plan(self, hedef, kaynak):
        """Takas mumkun mu? (salt-okuma on kontrol)"""
        try:
            import ses_core as SS
            return SS.takas_plani(hedef, kaynak)
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def ses_takas(self, hedef, kaynak, etiket=""):
        """Sesi takas et (arka planda; kapilardan gecmezse yazilmaz)."""
        def is_():
            import ses_core as SS
            self._log("- replacing sound...")
            r = SS.takas(hedef, kaynak, etiket or "")
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "swap failed")
                return
            self._log("SUCCESS: %d chunk(s) written." % r.get("parca", 0))
            self._bildir("bitti",
                         "Sound replaced. Start the game to hear it."
                         + ("" if r.get("dogrulandi") else
                            " (verification was inconclusive)"))
        return self._is(is_)

    def ses_geri_al(self):
        """Tum ses degisikliklerini (takas + susturma) geri al."""
        def is_():
            import ses_core as SS
            self._log("- reverting sound changes...")
            r = SS.geri_al()
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "revert failed")
                return
            n = r.get("geri_alindi", 0)
            self._bildir("bitti", {"t": "All sound changes reverted ({0}).", "a": [n]}
                         if n else "Nothing to revert.")
        return self._is(is_)

    def ses_disa_aktar(self, anahtar):
        """Sesi Belgeler klasorune .wem + .wav olarak cikar ve klasoru ac."""
        try:
            import ses_core as SS
            s = SS.ses_bul(anahtar)
            if not s:
                return {"ok": False, "mesaj": "unknown sound"}
            hedef = os.path.join(OUTPUT, "sounds")
            os.makedirs(hedef, exist_ok=True)
            w = SS.ses_baytlari(s)
            if not w:
                return {"ok": False, "mesaj": "That sound could not be read."}
            temiz = "".join(c if c.isalnum() or c in "._- " else "_"
                            for c in s["ad"])[:60].strip()
            dosya = "%s_%d_%.1fs" % (temiz or "sound", s["sid"], s.get("sure") or 0)
            with open(os.path.join(hedef, dosya + ".wem"), "wb") as f:
                f.write(w)
            wav, _h = SS.wav_uret(anahtar)
            if wav:
                shutil.copy2(wav, os.path.join(hedef, dosya + ".wav"))
            try:
                os.startfile(hedef)                           # noqa: S606
            except Exception:
                pass
            return {"ok": True, "dosya": dosya + (".wav" if wav else ".wem"),
                    "klasor": hedef}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    # ================================================== SHIPS (ship_core koprusu)
    def _ship(self):
        """ship_core'u tembel yukle ve oyuna bagla (bir kez)."""
        import ship_core as SC
        if not SC.bagli_mi():
            if not OYUN:
                raise RuntimeError("Set the game folder first.")
            r = SC.baslat(OYUN)
            if not r.get("ok"):
                raise RuntimeError(r.get("mesaj") or "ship engine failed to start")
            self._ship_bilgi = r
        return SC

    def ship_durum(self):
        """Ships sekmesi hazir mi + gruplar + yazma izni (salt-okuma)."""
        try:
            SC = self._ship()
            h = SC.hedefler()
            b = getattr(self, "_ship_bilgi", {}) or {}
            return {"ok": True, "gruplar": h["gruplar"], "meta": h["meta"],
                    "yazma": bool(b.get("yazma")), "salt_okunur": bool(b.get("salt_okunur")),
                    "mesaj": b.get("mesaj", ""), "sapan": b.get("sapan", 0)}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}

    def ship_hedefler(self, taze=False):
        try:
            SC = self._ship()
            return {"ok": True, "hedefler": SC.hedefler(bool(taze))["hedefler"]}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}

    def ship_onizleme(self, anahtar):
        try:
            SC = self._ship()
            return SC.onizleme(anahtar)
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}

    def ship_tahmin(self, anahtar):
        try:
            SC = self._ship()
            return {"ok": True, "sn": SC.tahmini_sure(anahtar)}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def ship_disa_aktar(self, anahtar):
        """Boyanabilir PNG sablonunu Documents'a yaz ve klasoru ac."""
        try:
            SC = self._ship()
            r = SC.disa_aktar(anahtar)
            try:
                os.startfile(r["klasor"])                    # noqa: S606
            except Exception:
                pass
            r["mesaj"] = {"t": "Exported {0} ({1}x{2}) - paint it, then APPLY.",
                          "a": [os.path.basename(r["yol"]), r.get("w"), r.get("h")]}
            return r
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}

    def ship_png_sec(self, anahtar=""):
        """Uygulanacak PNG'yi sec (dosya diyalogu; Documents/ShipWorkshop/tasarimlar)."""
        import webview
        import ship_core as SC
        bas = SC.TASARIM if os.path.isdir(SC.TASARIM) else os.path.expanduser("~")
        s = _PENCERE[0].create_file_dialog(
            webview.OPEN_DIALOG, directory=bas,
            file_types=("PNG image (*.png)", "All files (*.*)"))
        return (s[0] if s else None)

    def ship_uygula(self, anahtar, png, alfa="auto"):
        """Tek hedefe uygula (arka planda; motorun kapilari + ilerleme)."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            SC = self._ship()
            self._log("- ship: applying %s" % anahtar)

            def ilerleme(f, etiket=""):
                self._bildir("bar", max(0.0, min(100.0, float(f) * 100.0)))
                if etiket:
                    self._bildir("log", "  %s" % etiket)
            r = SC.uygula(anahtar, png, alfa=alfa or "auto", gunluk=self._log,
                          ilerleme=ilerleme)
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "apply failed")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "Applied {0} - start the game to see it. "
                                        "Revert restores the original.", "a": [anahtar]})
        return self._is(is_)

    def ship_geri_al(self, anahtar):
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            SC = self._ship()
            self._log("- ship: reverting %s" % anahtar)
            r = SC.geri_al(anahtar, gunluk=self._log)
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "revert failed")
                return
            self._bildir("bitti", r.get("mesaj") or
                         {"t": "{0} is back to original.", "a": [anahtar]})
        return self._is(is_)

    def ship_mod_sec(self):
        """Mod klasoru sec ve PNG'leri hedeflerle esle (salt-okuma)."""
        import webview
        s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG)
        if not s:
            return {"ok": False, "mesaj": "cancelled"}
        try:
            SC = self._ship()
            r = SC.mod_tara(s[0])
            r["klasor"] = s[0]
            return r
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}

    def ship_mod_kur(self, klasor, dosyalar, alfa="auto"):
        """Secilen dosyalari sirayla uygula (tek is; her hedef kendi kapilarindan gecer)."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        dosyalar = list(dosyalar or [])
        if not dosyalar:
            return {"ok": False, "mesaj": "Nothing selected."}

        def is_():
            SC = self._ship()
            basari, hata = 0, []
            for i, d in enumerate(dosyalar):
                self._log("- [%d/%d] %s" % (i + 1, len(dosyalar), d["anahtar"]))

                def ilerleme(f, etiket="", _i=i):
                    self._bildir("bar", 100.0 * (_i + max(0.0, min(1.0, float(f)))) / len(dosyalar))
                r = SC.uygula(d["anahtar"], os.path.join(klasor, d["dosya"]),
                              alfa=alfa or "auto", gunluk=self._log, ilerleme=ilerleme)
                if r.get("ok"):
                    basari += 1
                else:
                    hata.append("%s: %s" % (d["anahtar"], r.get("mesaj")))
                    self._log("  FAILED: %s" % r.get("mesaj"))
            self._bildir("bar", 100.0)
            if hata and not basari:
                self._bildir("hata", {"t": "No target could be applied ({0} failed).",
                                      "a": [len(hata)]})
            elif hata:
                self._bildir("bitti", {"t": "Mod installed: {0} applied, {1} failed (see log).",
                                       "a": [basari, len(hata)]})
            else:
                self._bildir("bitti", {"t": "Mod installed: {0} texture(s) applied.",
                                       "a": [basari]})
        return self._is(is_)

    def ship_mod_kaldir(self):
        """Yamali TUM gemi hedeflerini geri al."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            SC = self._ship()
            liste = SC.yamali_hedefler()
            if not liste:
                self._bildir("bitti", "No ship texture is patched.")
                return
            n, hata = 0, 0
            for i, a in enumerate(liste):
                self._bildir("bar", 100.0 * i / len(liste))
                r = SC.geri_al(a, gunluk=self._log)
                if r.get("ok"):
                    n += 1
                else:
                    hata += 1
                    self._log("  FAILED %s: %s" % (a, r.get("mesaj")))
            self._bildir("bar", 100.0)
            if hata:
                self._bildir("hata", {"t": "{0} reverted, {1} refused - see the log.",
                                      "a": [n, hata]})
            else:
                self._bildir("bitti", {"t": "All ship textures reverted ({0}).", "a": [n]})
        return self._is(is_)

    # ================================================== EXPLORER (her TOC girisi)
    # Kuratorlu sekmeler (Outfits/Weapons/Sounds/Ships/Characters) bir SECKIDIR.
    # Explorer onlarin ALTINDAKI kattir: adi cozulmus her girisi arar, tanir,
    # disa aktarir, geri koyar. Motor YOK -- burasi yalniz kopru:
    #     arama/sozluk  -> src/varlik_indeks.py   (SALT OKUR, forge ACMAZ)
    #     tani/aktar/koy-> src/explorer_core.py   (TEK YAZICI: kur_mesh/doku_enjekte2)
    #
    # TEMBEL YUKLEME: varlik_indeks 17,04 MB dosyayi okur ve 143 MB bellek tutar
    # (olculdu, testler/test_varlik_indeks.py). Bu bedel uygulama acilisinda DEGIL,
    # ilk explorer_* cagrisinda odenir -- sekmeye hic girmeyen kullanici odemez
    # (kaptanin pil kurali). Asagidaki iki yardimci bu yuzden `import` satirini
    # metot govdesinde tutar; modul basinda DEGIL.
    def _vi(self):
        """varlik_indeks modulu (ilk cagride yuklenir)."""
        import varlik_indeks as VI
        return VI

    def _ex(self):
        """explorer_core modulu (ilk cagride yuklenir)."""
        import explorer_core as EX
        return EX

    def _explorer_arsiv(self, forge):
        """Forge ADINI (indeksin verdigi 'DataPC_boot.forge') TAM YOLA cevir.

        Zaten tam yol verilmisse dokunulmaz. Bulunamazsa None doner ve cekirdek
        kendi varsayilan arsivine bakar -- uydurma bir yol UYDURULMAZ."""
        if not forge:
            return None
        f = str(forge)
        if os.path.isfile(f):
            return os.path.abspath(f)
        kok = OYUN or (os.path.dirname(C.DE.FORGE) if C.game_found() else None)
        if kok:
            y = os.path.join(kok, os.path.basename(f))
            if os.path.isfile(y):
                return y
        return None

    def _explorer_indeks_yok(self, VI):
        """Indeks dosyasi yoksa arayuzun BOS DURUM'u icin tek bicimli yanit."""
        return {"ok": False, "indeks_yok": True,
                "mesaj": VI.hata() or "Asset index not found.",
                "nasil": ("The Explorer needs src/varlik_indeks.bin. It ships with the "
                          "Workshop package; reinstall or update to get it back. "
                          "Every other tab keeps working without it.")}

    # ================================================== SHIP STATS + HIDE PARTS (v0.15)
    # Iki yeni panel. Cekirdekler src/gemi_stat.py (gemi cani / koc hasari / Jackdaw
    # hizi; silah_stat'in ikizi) ve src/parca_gizle.py (Blender'siz parca gizleme).
    # Burasi YALNIZ kopru: kural kopyasi yok, kendi yazicisi yok. Yazan metotlar
    # cekirdegin tek yazicisindan gecer (gemi_stat -> nesne_yaz.xml_yaz -> kur_mesh.kur;
    # parca_gizle -> kur_mesh.kur), _is'ten gecer ve oyun aciksa dugmeye basar basmaz
    # reddeder; okuyanlar _is kullanmaz. Cekirdek eski bir kurulumda BULUNMAYABILIR:
    # _silah_stat_fn kalibiyla getattr ile bakilir ve ACIK bir mesajla reddedilir.
    def _gemi_stat_fn(self, ad):
        """gemi_stat modulundeki `ad` fonksiyonu (yoksa None)."""
        try:
            import gemi_stat as GS
        except Exception as e:                                  # noqa: BLE001
            print("gemi_stat yuklenemedi:", e)
            return None
        return getattr(GS, ad, None)

    def gemi_stat_katalog(self):
        """SHIP STATS paneli: katalog + CANLI degerler + durum. SALT OKUMA -- forge
        yalniz okunur. `canli` katalog sirasindadir; okunamayan satir ok=False + mesaj
        tasir (panel o satiri kilitler, sebebini yazar)."""
        kat = self._gemi_stat_fn("katalog")
        oku = self._gemi_stat_fn("hepsini_oku")
        if kat is None or oku is None:
            return {"ok": False, "mesaj": "Ship stats are not available in this build.",
                    "katalog": [], "canli": []}
        try:
            r = {"ok": True, "katalog": kat(), "canli": oku(), "durum": None}
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300], "katalog": [], "canli": []}
        durum = self._gemi_stat_fn("durum")
        try:
            r["durum"] = durum() if durum else None
        except Exception as e:                                  # noqa: BLE001
            r["durum"] = {"ok": False, "mesaj": str(e)[:200]}
        return r

    def gemi_stat_oku(self, anahtar=None):
        """Tek statin (anahtar) ya da hepsinin CANLI degeri. SALT OKUMA."""
        fn = self._gemi_stat_fn("oku" if anahtar else "hepsini_oku")
        if fn is None:
            return {"ok": False, "mesaj": "Ship stats are not available in this build."}
        try:
            if anahtar:
                return fn(str(anahtar))
            return {"ok": True, "canli": fn()}
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def gemi_stat_plan(self, degisiklikler):
        """APPLY'in ilk asamasi: ne yazilacagini SALT OKUNUR hesaplar (gemi_stat.plan).
        Arsive tek bayt gitmez; kullanici ozeti gormeden yazma cagrisi yapilmaz.
        `degisiklikler` = {"hull_L1": 6000, ...}."""
        fn = self._gemi_stat_fn("plan")
        if fn is None:
            return {"ok": False, "mesaj": "Ship stats are not available in this build."}
        try:
            return fn(dict(degisiklikler or {}))
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def gemi_stat_uygula(self, degisiklikler, etiket=""):
        """OYUNA YAZAR: gemi_stat.uygula -> nesne_yaz.xml_yaz -> kur_mesh.kur (tek yazici,
        hep-ya-da-hic: bir yazma duserse bu kosunun her yazmasi geri sarilir). Kapilar:
        bos istek, oyun acik (burada), yazma kilidi + golge + geri okuma (cekirdekte).
        _is'ten gecer: tek is, ilerleme _log'a, sonuc _bildir ile."""
        fn = self._gemi_stat_fn("uygula")
        if fn is None:
            return {"ok": False, "mesaj": "Ship stats are not available in this build."}
        istek = dict(degisiklikler or {})
        if not istek:
            return {"ok": False, "mesaj": "Nothing to change."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            self._log("- ship stats: %d value(s) requested" % len(istek))
            for a, v in sorted(istek.items()):
                self._log("  requested %s = %s" % (a, v))
            r = fn(istek, etiket=str(etiket or ""), progress=self._log) or {}
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj_kalip") or r.get("mesaj")
                             or "Nothing was written - see the log.")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", r.get("mesaj_kalip") or r.get("mesaj")
                         or {"t": "Ship stats written. Start the game to see them; Revert ship stats puts the original numbers back."})
        return self._is(is_)

    def gemi_stat_geri_al(self):
        """Kurulu TUM gemi-stat yamalarini geri al (yalniz 'ship stat' etiketli kayitlar;
        baska aracin yamasina dokunulmaz). _is'ten gecer."""
        fn = self._gemi_stat_fn("geri_al")
        if fn is None:
            return {"ok": False, "mesaj": "Ship stats are not available in this build."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            self._log("- reverting ship stats...")
            r = fn() or {}
            for s in (r.get("sonuclar") or []):
                if not s.get("ok"):
                    self._log("  FAILED: %s" % s.get("mesaj"))
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj_kalip") or r.get("mesaj")
                             or "Nothing was reverted.")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", r.get("mesaj_kalip") or r.get("mesaj")
                         or {"t": "Ship stats reverted - the original numbers are back."})
        return self._is(is_)

    # --- HIDE PARTS (parca_gizle koprusu) --------------------------------------------
    def _parca_gizle_fn(self, ad):
        """parca_gizle modulundeki `ad` fonksiyonu (yoksa None)."""
        try:
            import parca_gizle as PG
        except Exception as e:                                  # noqa: BLE001
            print("parca_gizle yuklenemedi:", e)
            return None
        return getattr(PG, ad, None)

    def parca_gizle_liste(self, ad, tur="out"):
        """HIDE PARTS penceresinin veri kaynagi: bu ogenin parcalari + hangisi gizli
        (baytlardan olculur, bayrak dosyasindan degil). SALT OKUMA. `tur`: out/chr/wpn;
        karakterde CHR_ onekini cekirdek ekler (sunucu._3d_anahtar ile ayni kural)."""
        fn = self._parca_gizle_fn("parcalar")
        if fn is None:
            return {"ok": False, "mesaj": "Hiding parts is not available in this build.",
                    "parcalar": []}
        if not ad:
            return {"ok": False, "mesaj": "Pick an item first.", "parcalar": []}
        try:
            return fn(str(ad), str(tur or "out"))
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300], "parcalar": []}

    def parca_gizle_plan(self, ad, secilen, tur="out"):
        """APPLY'in ilk asamasi: secilen parcalar icin NE YAZILACAGI (parca_gizle.plan).
        YAZMAZ: gizleme baytlari bellekte uretilir, arsiv yalniz okunur."""
        fn = self._parca_gizle_fn("plan")
        if fn is None:
            return {"ok": False, "mesaj": "Hiding parts is not available in this build."}
        if not ad:
            return {"ok": False, "mesaj": "Pick an item first."}
        try:
            return fn(str(ad), [str(s) for s in (secilen or []) if s], str(tur or "out"))
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def parca_gizle_uygula(self, ad, secilen, tur="out", etiket=""):
        """OYUNA YAZAR: parca_gizle.uygula -> kur_mesh.kur (tek yazici; her LOD bandi,
        ilk dusen -> bu kosunun her yazmasi geri sarilir). Kapilar: bos secim, oyun acik
        (burada), yazma kilidi + geri okuma (cekirdekte). _is'ten gecer."""
        fn = self._parca_gizle_fn("uygula")
        if fn is None:
            return {"ok": False, "mesaj": "Hiding parts is not available in this build."}
        sec = [str(s) for s in (secilen or []) if s]
        if not ad:
            return {"ok": False, "mesaj": "Pick an item first."}
        if not sec:
            return {"ok": False, "mesaj": "Nothing selected - tick at least one part."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            self._log("- hide parts: %s (%d part(s))" % (ad, len(sec)))
            r = fn(str(ad), sec, str(tur or "out"), etiket=str(etiket or ""),
                   progress=self._log) or {}
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj_kalip") or r.get("mesaj")
                             or "Nothing was hidden - see the log.")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", r.get("mesaj_kalip") or r.get("mesaj")
                         or {"t": "Parts hidden. Start the game to see it; Show all again brings them back."})
        return self._is(is_)

    def parca_gizle_goster(self, ad, anahtarlar=None, tur="out"):
        """GERI AL: bu ogenin gizli parcalarini geri getir (parca_gizle.goster ->
        kur_mesh.geri_al). anahtarlar=None -> bu ogenin BUTUN gizli parcalari. _is'ten
        gecer; yalniz 'hide:' etiketli kayitlara dokunur."""
        fn = self._parca_gizle_fn("goster")
        if fn is None:
            return {"ok": False, "mesaj": "Hiding parts is not available in this build."}
        if not ad:
            return {"ok": False, "mesaj": "Pick an item first."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        sec = None if anahtarlar is None else [str(s) for s in anahtarlar if s]

        def is_():
            self._log("- show again: %s" % ad)
            r = fn(str(ad), sec, str(tur or "out"), progress=self._log) or {}
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj_kalip") or r.get("mesaj")
                             or "Nothing was reverted.")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", r.get("mesaj_kalip") or r.get("mesaj")
                         or {"t": "The hidden parts are back."})
        return self._is(is_)

    def parca_gizle_durum(self, ad, tur="out"):
        """Bu ogenin gizleme durumu (parca_gizle.durum). SALT OKUMA."""
        fn = self._parca_gizle_fn("durum")
        if fn is None:
            return {"ok": False, "mesaj": "Hiding parts is not available in this build."}
        if not ad:
            return {"ok": False, "mesaj": "Pick an item first."}
        try:
            return fn(str(ad), str(tur or "out"))
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    # ================================================== EDIT AS XML + UNPACK ALL (v0.15)
    # Explorer'in iki yeni yolu. Cekirdekler src/nesne_xml.py (dokum), src/nesne_yaz.py
    # (XML -> forge) ve src/toplu.py (toplu ac / geri koy); burasi YALNIZ kopru, kural
    # kopyasi yok. Hicbir metot forge'a kendi eliyle yazmaz: yazan iki metot da
    # nesne_yaz.xml_yaz / toplu.geri_koy -> explorer_core.geri_yukle -> kur_mesh.kur
    # zincirinden gecer; Health Check ve Revert onlari da gorur.
    #
    # XML BOYUT KAPISI (olculdu 2026-09-08): 8,4 MB'lik bir giris 18,6 MB / 262.271 satir
    # XML uretiyor ve <textarea> WebView2'yi kilitliyor; 67 MB govdeli bir giris 144,7 MB.
    # Uretim ucuz (144,7 MB icin 0,68 sn), bu yuzden TAHMIN degil GERCEK boyut olculur:
    # 2 MB ya da 40.000 satirin ustu arayuze GONDERILMEZ (xml bos, cok_buyuk=True).
    _XML_SINIR_BAYT = 2 * 1024 * 1024
    _XML_SINIR_SATIR = 40000

    def _nesne_xml_kimlik(self, gid, icid):
        """Arayuzden gelen '0x..' kimlikler -> (int, int|None). Bos icid None'dir."""
        EX = self._ex()
        g = EX._int(gid)
        i = EX._int(icid) if icid not in (None, "") else None
        if g is None:
            raise ValueError("an entry id is required")
        return g, i

    def nesne_xml_ver(self, gid, icid=None, forge=None):
        """SALT OKUMA: girisin ic dosyasi -> XML metni (nesne_xml.xml_ver_agac).

        Yanit: {ok, xml, boyut_bayt, satir, cok_buyuk, mesaj, gid, icid, sinif}.
        cok_buyuk=True iken xml BOS doner ve mesaj ne yapilacagini soyler (EXPORT).
        Forge yalniz okunur: nesne.oku kendi salt-okuma taniticisini acar ve kapatir."""
        r = {"ok": False, "xml": "", "boyut_bayt": 0, "satir": 0, "cok_buyuk": False,
             "mesaj": None, "gid": None, "icid": None, "sinif": None}
        try:
            import nesne as N
            import nesne_xml as X
            EX = self._ex()
            g, i = self._nesne_xml_kimlik(gid, icid)
            agac = N.oku(g, icid=i, forge=self._explorer_arsiv(forge))
            xml = X.xml_ver_agac(agac)
            n_bayt = len(xml.encode("utf-8"))
            n_satir = xml.count("\n") + 1
            r.update({"ok": True, "boyut_bayt": n_bayt, "satir": n_satir,
                      "gid": EX._hex(g if agac.get("gid") is None else agac.get("gid")),
                      "icid": EX._hex(agac.get("icid")),
                      "sinif": agac.get("sinif_ad") or None})
            if n_bayt > self._XML_SINIR_BAYT or n_satir > self._XML_SINIR_SATIR:
                r["cok_buyuk"] = True
                r["mesaj"] = {"t": "This entry is too large to edit here ({0} MB of XML). Export it and edit the file instead.", "a": [round(n_bayt / 1048576.0, 1)]}
                return r
            r["xml"] = xml
            return r
        except (KeyError, ValueError) as e:
            # BEKLENEN red (raw asset, kapta olmayan ic dosya): mesaj yeter, iz yok
            r["mesaj"] = str(e)[:300]
            return r
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            r["mesaj"] = str(e)[:300]
            return r

    def nesne_xml_hazirla(self, gid, icid, xml, forge=None):
        """APPLY'in ilk asamasi: XML'i CANLI arsivle karsilastir, kac bayt degisecegini
        soyle. YAZMAZ (nesne_yaz.xml_hazirla). Bayt alanlari (govde/orijinal/yeni_ic)
        JSON'a tasinamaz ve arayuzun isine yaramaz; yalniz ozet doner."""
        try:
            import nesne_yaz as NY
            g, i = self._nesne_xml_kimlik(gid, icid)
            h = NY.xml_hazirla(str(xml or ""), gid=g, icid=i,
                               forge=self._explorer_arsiv(forge))
            return {k: h.get(k) for k in ("ok", "gid", "icid", "forge", "degisen_bayt",
                                          "degisen_yer", "degisti", "sarmalayici",
                                          "mesaj", "satir", "sutun",
                                          "uzunluk", "degisen_kayit", "uzman_uyarilari",
                                          "uzman")}
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def nesne_xml_yaz(self, gid, icid, xml, forge=None):
        """OYUNA YAZAR: nesne_yaz.xml_yaz -> explorer_core.geri_yukle -> kur_mesh.kur.
        Kapilar: oyun acik mi (burada, dugmeye basar basmaz) -> yazma kilidi + golge +
        kimlik + ayni-uzunluk (cekirdekte). _is'ten gecer: tek is, ilerleme _log'a."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        metin = str(xml or "")
        if not metin.strip():
            return {"ok": False, "mesaj": "Nothing to change."}
        try:
            g, i = self._nesne_xml_kimlik(gid, icid)
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:200]}
        yol = self._explorer_arsiv(forge)

        def is_():
            import nesne_yaz as NY
            EX = self._ex()
            self._log("- xml: writing %s/%s" % (EX._hex(g), "-" if i is None else EX._hex(i)))
            r = NY.xml_yaz(metin, gid=g, icid=i, forge=yol, etiket="edited in the Workshop",
                           progress=self._log)
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "The XML could not be written - see the log.")
                return
            # UZMAN UYARILARI: yazma BASARILI olsa da kullanici bunlari GORMELI.
            for u in (r.get("uzman_uyarilari") or []):
                self._log("EXPERT %s" % u)
                self._bildir("uyari", u)
            self._log("SUCCESS: %s" % (r.get("mesaj") or "written"))
            self._bildir("bar", 100.0)
            self._bildir("bitti", "Written. Start the game to see it, or open Health Check to revert.")
        return self._is(is_)

    # --- UNPACK ALL (toplu) ----------------------------------------------------------
    def _tp(self):
        """toplu modulu (ilk cagride yuklenir; LeanForge + explorer_core'u ceker)."""
        import toplu as TP
        return TP

    def _toplu_ilerleme(self, s):
        """toplu'nun '25 of 40 entries unpacked' satirlari -> ilerleme cubugu.

        _log'un genel regex'i yalniz 'N/M' bicimini tanir. 'of' bicimini GENELE eklemek
        olculdu ve reddedildi: mod kurulumunda 'Part 2 of 3 done.' ardindan 'slot 1 of 4'
        gelir, bar GERI giderdi (kullanici bunu hata sanar). 'of' bu yuzden yalnizca bu
        isin kancasinda ve yalnizca toplu'nun iki sayac satirinda taninir."""
        self._log(s)
        m = re.search(r"\b(\d+) of (\d+) (?:entries unpacked|files written)\b", str(s))
        if m and int(m.group(2)):
            self._bildir("bar", 100.0 * int(m.group(1)) / int(m.group(2)))

    def _toplu_forge(self, forge):
        """Arsiv adi/yolu -> tam yol; verilmemisse Explorer'in baktigi arsiv."""
        return self._explorer_arsiv(forge) or self._ex().arsiv_yolu()

    def _toplu_varsayilan_klasor(self, yol):
        """Documents\\OutfitWorkshop\\Unpacked\\<arsiv adi> -- olusturulmaz, onerilir."""
        ad = os.path.splitext(os.path.basename(yol or "archive"))[0]
        return os.path.join(OUTPUT, "Unpacked", ad)

    def toplu_klasor_sec(self, klasor=None):
        """Cikti klasoru secme penceresi (ana is parcaciginda; _is'ten gecmez)."""
        import webview
        bas = None
        for aday in (klasor, os.path.join(OUTPUT, "Unpacked"), OUTPUT):
            if aday and os.path.isdir(str(aday)):
                bas = str(aday)
                break
        s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG,
                                           directory=bas or self._mod_dialog_klasoru())
        if not s:
            return {"ok": False, "mesaj": "cancelled"}
        return {"ok": True, "klasor": s[0]}

    def toplu_tahmin(self, forge=None, klasor=None):
        """SALT OKUMA: kac giris, tahmini kac dosya / bayt / saniye (toplu.tahmin).

        toplu.ac(onay=False) KULLANILMAZ: esigin altindaki bir arsivde o cagri YAZAR.
        tahmin() yalniz olcer. Klasor ONERILIR, olusturulmaz. Bos alan da olculur ki
        arayuz disk kapisini yazmaya kalkmadan once gosterebilsin."""
        try:
            TP = self._tp()
            yol = self._toplu_forge(forge)
            t = TP.tahmin(yol, progress=None)
            hedef = str(klasor) if klasor else self._toplu_varsayilan_klasor(yol)
            bos = None
            try:
                kok = hedef
                while kok and not os.path.isdir(kok):
                    ust = os.path.dirname(kok)
                    if ust == kok:
                        break
                    kok = ust
                if kok and os.path.isdir(kok):
                    bos = shutil.disk_usage(kok).free
            except OSError:
                bos = None
            r = {k: t.get(k) for k in ("ok", "mesaj", "forge", "forge_ad", "toc_giris",
                                       "secilen", "arsiv_bayt", "tahmin_bayt",
                                       "tahmin_dosya", "tahmin_sure", "gerekli_bayt",
                                       "kesin", "olcum", "uyari")}
            r["klasor"] = hedef
            r["disk_bos"] = bos
            r["rapor"] = TP.rapor(t)
            return r
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def toplu_ac(self, forge=None, klasor=None):
        """UZUN IS: arsivin girislerini klasore ac (toplu.ac, onay=True: arayuzdeki tahmin
        satiri onayin kendisidir; DISK kapisi cekirdekte kalir, onay onu gecmez). Oyun
        arsivini yalnizca OKUR, bu yuzden 'Close the game first.' kapisi YOKTUR.
        Iptal: iptal_et() -> self._iptal, dongu bir sonraki giriste durur."""
        if not klasor:
            return {"ok": False, "mesaj": "Pick an output folder first."}
        yol = self._toplu_forge(forge)
        hedef = os.path.abspath(str(klasor))

        def is_():
            TP = self._tp()
            self._log("- batch: unpacking %s into %s" % (os.path.basename(yol), hedef))
            r = TP.ac(yol, hedef, onay=True, iptal=self._iptal, progress=self._toplu_ilerleme)
            ozet = {k: r.get(k) for k in ("ok", "klasor", "acilan", "atlanan_sayi",
                                          "basarisiz_sayi", "dosya", "bayt", "iptal",
                                          "mesaj", "sure", "onay_gerekli")}
            ozet["asama"] = "ac"
            ozet["rapor"] = TP.rapor(r)
            self._bildir("toplu", ozet)
            if r.get("iptal"):
                self._bildir("hata", {"t": "Stopped after {0} entries. What was unpacked is complete and can still be put back.", "a": [int(r.get("acilan") or 0)]})
                return
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "Nothing was unpacked - see the log.")
                return
            try:
                os.startfile(r.get("klasor") or hedef)          # noqa: S606
            except Exception:                                   # noqa: BLE001
                pass
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "{0} entries unpacked into {1} ({2} files). Edit the files, then press Find changed files.", "a": [int(r.get("acilan") or 0), r.get("klasor") or hedef, int(r.get("dosya") or 0)]})
        return self._is(is_)

    def toplu_plan(self, klasor=None, forge=None):
        """UZUN IS (sha256 taramasi, yazmaz): klasordeki DEGISMIS dosyalari bul
        (toplu.plan_geri_koy). Sonuc 'toplu' olayiyla (asama=plan) arayuze gider."""
        if not klasor or not os.path.isdir(str(klasor)):
            return {"ok": False, "mesaj": "Pick an unpacked folder first."}
        yol = self._toplu_forge(forge)
        hedef = os.path.abspath(str(klasor))

        def is_():
            TP = self._tp()
            self._log("- batch: looking for changed files in %s" % hedef)
            p = TP.plan_geri_koy(hedef, forge=yol, progress=self._log)
            ozet = {k: p.get(k) for k in ("ok", "klasor", "giris", "dosya", "degisti",
                                          "degismedi", "uyari", "mesaj", "sure")}
            ozet.update({"asama": "plan", "yazilacak": len(p.get("yazilacak") or []),
                         "red": len(p.get("red") or []), "eksik": len(p.get("eksik") or []),
                         "kayitsiz": len(p.get("kayitsiz") or []), "rapor": TP.rapor(p)})
            self._bildir("toplu", ozet)
            if not p.get("ok"):
                self._bildir("hata", p.get("mesaj") or "The folder could not be read.")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "{0} of {1} files changed; {2} can be written back.", "a": [int(p.get("degisti") or 0), int(p.get("dosya") or 0), ozet["yazilacak"]]})
        return self._is(is_)

    def toplu_geri_koy(self, klasor=None, forge=None):
        """OYUNA YAZAR: klasordeki degismis dosyalar tek tek explorer_core.geri_yukle ile
        (toplu.geri_koy; kendi yazicisi YOK). Plan yazma aninda YENIDEN olculur: 'Find
        changed files' ile bu dugme arasinda kullanici dosya degistirmis olabilir; bayat
        bir plana gore yazmak yanlis baytlari yazardi."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        if not klasor or not os.path.isdir(str(klasor)):
            return {"ok": False, "mesaj": "Pick an unpacked folder first."}
        yol = self._toplu_forge(forge)
        hedef = os.path.abspath(str(klasor))

        def is_():
            TP = self._tp()
            self._log("- batch: writing changed files from %s into %s"
                      % (hedef, os.path.basename(yol)))
            r = TP.geri_koy(hedef, forge=yol, progress=self._toplu_ilerleme,
                            iptal=self._iptal)
            ozet = {k: r.get(k) for k in ("ok", "yazilan_sayi", "basarisiz_sayi",
                                          "ic_yazma", "iptal", "mesaj", "sure")}
            ozet["asama"] = "geri_koy"
            ozet["rapor"] = TP.rapor(r)
            self._bildir("toplu", ozet)
            if r.get("iptal"):
                self._bildir("hata", {"t": "Stopped after {0} file(s). Every write so far is in the undo record.", "a": [int(r.get("yazilan_sayi") or 0)]})
                return
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "Nothing was written - see the log.")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "{0} file(s) written into the game. Start the game to see them, or open Health Check to revert.", "a": [int(r.get("yazilan_sayi") or 0)]})
        return self._is(is_)

    def iptal_et(self):
        """Kosan toplu isi bir sonraki giriste durdur. Is yoksa zararsizdir; bayrak her
        yeni iste (_is) sifirlanir. Forge'a dokunmaz."""
        self._iptal.set()
        return {"ok": True, "mesgul": bool(self._mesgul)}

    # --- OKUYANLAR: _is KULLANMAZ (arsive tek bayt yazmazlar, is kilidi tutmazlar)
    def explorer_ara(self, metin="", sinif=None, forge=None, limit=200, offset=0, tur=None):
        """SALT OKUMA: indekste ara. Sayfa = TEK ara() cagrisi (offset yerlisidir).

        Yanit: {ok, toplam, satirlar, offset, limit, kapsam:{satir,forge,sinif}}
        `satir` = {forge, sinif, gid, icid, ad, boyut, tur}. Sondaki '?' cozulemeyen
        1-3 bayttir (tahmin degil); arayuz onu ISARETLER, tam ad gibi sunmaz.
        `tur` (mesh/texture/material/sound/data/raw, None = hepsi) sinif verilmemisse
        suzer (explorer_core.tur_ara); sinif verilmisse sinif daha dar oldugundan
        tur yok sayilir. Her satira `tur` alani EKLENIR, sozlesme bozulmaz."""
        try:
            VI = self._vi()
            EX = self._ex()
            try:
                limit = max(1, min(500, int(limit or 200)))
                offset = max(0, int(offset or 0))
            except (TypeError, ValueError, OverflowError):      # int(inf) dahil
                limit, offset = 200, 0
            tur = str(tur or "").strip().lower() or None
            if tur and not sinif:
                ix = VI.yukle()
                if ix is None:
                    return self._explorer_indeks_yok(VI)
                r = EX.tur_ara(ix, metin or "", tur, forge or None, limit, offset)
                if r.get("hata"):
                    return {"ok": False, "mesaj": r["hata"]}
            else:
                r = VI.ara(metin or "", sinif or None, forge or None, limit, offset)
                # HAM TOC girisleri indekste YOKTUR (uretici BMS olmayani atlar): tek bir
                # arsiv secilince canli TOC'tan gelip listenin SONUNA eklenirler.
                if not r.get("hata"):
                    r = EX.ham_kuyruk(r, metin or "", tur, sinif or None, forge or None,
                                      limit, offset)
            if r.get("hata"):
                return self._explorer_indeks_yok(VI)
            ist = VI.istatistik()
            satirlar = r.get("satirlar") or []
            for s in satirlar:
                if not s.get("tur"):                    # ham satir turunu KENDI tasir
                    s["tur"] = EX.tur_ad(s.get("sinif"))
            return {"ok": True, "toplam": int(r.get("toplam") or 0),
                    "satirlar": satirlar,
                    "offset": offset, "limit": limit,
                    "kapsam": {"satir": ist.get("satir", 0),
                               "forge": ist.get("forge", 0),
                               "sinif": ist.get("sinif", 0)}}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    def explorer_siniflar(self):
        """SALT OKUMA: sinif sozlugu, COK GECEN ONCE.

        OLCULDU (2026-09-09, v0.18): 2.436 sinifin 2.319'u cozulmus ad tasir
        (oyunun kendi sinif sozlugu okunmadan once 1.502 idi). Kalan 117'si
        '0xXXXXXXXX' olarak GELIR ve arayuz onu oldugu gibi gosterir
        (uydurma ad yok). Sayi CANLI hesaplanir (`cozulmus`), ezberlenmez."""
        try:
            VI = self._vi()
            s = VI.siniflar()
            if not s:
                r = self._explorer_indeks_yok(VI)
                r["siniflar"] = []
                return r
            return {"ok": True, "siniflar": s,
                    "cozulmus": sum(1 for x in s if not str(x.get("ad", "")).startswith("0x")),
                    "kismi_ad": self._explorer_kismi_ad(VI)}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200], "siniflar": []}

    def _explorer_kismi_ad(self, VI):
        """Icinde '?' gecen ad sayisi = adi TAM COZULEMEMIS giris sayisi.

        '?' bir tahmin degildir: cozulemeyen 1-3 baytin yerine yazilir. Arayuz
        bu sayiyi kapsam cumlesinde gosterir ki "her sey cozuldu" izlenimi
        dogmasin. OLCULDU: bu tarama 0,42 sn surer (1,67 M ad) -- bu yuzden
        oturum basina BIR kez calisir ve sonucu burada onbelleklenir; arama
        yolunda ASLA cagrilmaz. Sayilamazsa None doner ve arayuz sayiyi yazmaz
        (uydurma sayi YOK)."""
        k = getattr(self, "_ex_kismi", "yok")
        if k != "yok":
            return k
        try:
            k = int(VI.ara("?", limit=0).get("toplam") or 0) or None
        except Exception:                                       # noqa: BLE001
            k = None
        self._ex_kismi = k
        return k

    def explorer_forgeler(self):
        """SALT OKUMA: indekste adi gecen arsivler + oyun klasorunde VAR MI.

        `var_mi` yalnizca os.path.isfile'dir -- bu cagri hicbir forge ACMAZ.
        Arayuz olmayanlari SOLUK + 'not installed' gosterir, listeden gizlemez."""
        try:
            VI = self._vi()
            f = VI.forgeler()
            if not f:
                r = self._explorer_indeks_yok(VI)
                r["forgeler"] = []
                return r
            return {"ok": True, "forgeler": f,
                    "kurulu": sum(1 for x in f if x.get("var_mi"))}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200], "forgeler": []}

    def explorer_tani(self, gid, icid=None, forge=None):
        """SALT OKUMA: bu giris NE, ne yapabiliriz, yapamiyorsak NEDEN.

        explorer_core.tani ciktisina bir sey EKLENMEZ, biri haric: bu girise ait
        Explorer yamalari (`yamalar`) kur_mesh kaydindan suzulur, boylece panel
        REVERT dugmesini dogru kayda baglar. Yama listesi bos ise dugme pasiftir."""
        try:
            EX = self._ex()
            yol = self._explorer_arsiv(forge)
            t = EX.tani(gid, icid or None, yol)
            try:
                d = EX.durum(yol or (t.get("forge") if isinstance(t, dict) else None))
                g = str((t or {}).get("gid") or "").lower()
                t["yamalar"] = [y for y in (d.get("yamalar") or [])
                                if g and g in str(y.get("aciklama") or "").lower()]
                t["yama_hepsi"] = d.get("toplam", 0)
            except Exception:                                   # noqa: BLE001
                t["yamalar"] = []                               # kayit okunamadi: sessiz
                t["yama_hepsi"] = 0
            return t
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}

    # --- YAZANLAR / UZUN ISLER: _is deseninden gecer
    def explorer_disa_aktar(self, gid, icid=None, bicim=None, forge=None, klasor=None):
        """Girisi diske cikar. Oyun arsivini yalnizca OKUR; dosyalar Documents'a
        yazilir -- bu yuzden 'Close the game first.' kapisi YOKTUR (kapatmak
        gerekmeyen bir isi reddetmek yalan olurdu).

        _is'ten gecer cunku UZUN surebilir (mesh -> GLB) ve ilerleme bildirir."""
        hedef = klasor or os.path.join(OUTPUT, "Explorer")

        def is_():
            EX = self._ex()
            self._log("- explorer: exporting %s (%s)" % (gid, bicim or "auto"))
            r = EX.disa_aktar(gid, icid or None, klasor=hedef, bicim=bicim or None,
                              forge=self._explorer_arsiv(forge), progress=self._log)
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "export failed")
                return
            if r.get("uyari"):
                self._bildir("uyari", r["uyari"])
            try:
                os.startfile(r["klasor"])                       # noqa: S606
            except Exception:                                   # noqa: BLE001
                pass
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "Exported {0} file(s) as {1} to {2}",
                                   "a": [len(r.get("dosyalar") or []), r.get("bicim"),
                                         r.get("klasor")]})
        return self._is(is_)

    def explorer_geri_yukle(self, kaynak=None, gid=None, icid=None, forge=None):
        """OYUNA YAZAR. Kapilar: oyun acik mi -> yazma kilidi (cekirdekte) ->
        bilgi.json hedef dogrulamasi (cekirdekte). Klasor verilmezse SECTIRILIR
        (dialog _is'ten ONCE, ana is parcaciginda acilir)."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        if not kaynak:
            import webview
            bas = os.path.join(OUTPUT, "Explorer")
            if not os.path.isdir(bas):
                bas = OUTPUT if os.path.isdir(OUTPUT) else os.path.expanduser("~")
            s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG, directory=bas)
            if not s:
                return {"ok": False, "mesaj": "cancelled"}
            kaynak = s[0]

        def is_():
            EX = self._ex()
            self._log("- explorer: importing %s" % kaynak)
            r = EX.geri_yukle(kaynak, gid=gid or None, icid=icid or None,
                              forge=self._explorer_arsiv(forge),
                              etiket="%s %s" % (gid or "", os.path.basename(kaynak)),
                              progress=self._log)
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "import failed")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "Written back as {0}. Revert puts the original "
                                        "bytes back.", "a": [r.get("bicim")]})
        return self._is(is_)

    def explorer_cogalt_plani(self, gid, forge=None, yeni_ad=""):
        """SALT OKUMA: bu giris YENI bir giris olarak eklenebilir mi, kimligi ne olur?

        Yazma dugmesine basilmadan ONCE cagrilir: ad kurali, kap tipi, TOC'ta yer ve
        kimlik cakismasi burada olculur, arsive TEK BAYT yazilmaz."""
        try:
            EX = self._ex()
            return EX.TE.cogalt_plani(self._explorer_arsiv(forge), EX._int(gid),
                                      (yeni_ad or "").strip())
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:400]}

    def explorer_giris_cogalt(self, gid, forge=None, yeni_ad=""):
        """OYUNA YAZAR: bu girisin kopyasini YENI bir TOC girisi olarak ekler.

        Kaynak girise dokunulmaz. Kapilar: oyun acik mi -> yazma kilidi (cekirdekte)
        -> ad kurali -> TOC'ta bos satir yeri -> yazdiktan sonra diskten dogrulama.
        DURUSTLUK: yeni giris arsive girer ama OYUN ONU KULLANMAZ; kullanmasi icin
        ona isaret eden bir veri kaydi gerekir. Mesaj bunu acikca soyler."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        ad = (yeni_ad or "").strip()

        def is_():
            EX = self._ex()
            self._log("- explorer: adding a copy of %s as %s" % (gid, ad))
            r = EX.cogalt(gid, ad, forge=self._explorer_arsiv(forge), progress=self._log)
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "the entry could not be added")
                return
            self._bildir("bar", 100.0)
            self._bildir("bitti", {"t": "Added {0} as a new entry ({1}). The game will not "
                                        "use it until something points at it. Revert removes "
                                        "the entry again.",
                                   "a": [ad, r.get("yeni_gid")]})
        return self._is(is_)

    def explorer_geri_al(self, kayit_id=None, forge=None):
        """OYUNA YAZAR (eski baytlari geri koyar). kayit_id yoksa Explorer'in
        HEPSI. Baska bir aracin yamasi cekirdekte REDDEDILIR."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            EX = self._ex()
            self._log("- explorer: reverting %s" % (kayit_id or "everything it wrote"))
            r = EX.geri_al(kayit_id or None, forge=self._explorer_arsiv(forge))
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "revert failed")
                return
            self._bildir("bitti", r.get("mesaj") or "Reverted.")
        return self._is(is_)

    def ac_klasor(self, ad=""):
        """Bilinen bir cikti klasorunu Gezgin'de ac. BEYAZ LISTE: sayfadan gelen
        serbest yol ACILMAZ (arayuz.html'deki #sh-klasor bu metodu cagiriyordu
        ama metot HIC YOKTU -- dugme sessizce oluydu)."""
        try:
            ad = str(ad or "")
            if ad == "ship":
                import ship_core as SC
                yol = SC.TASARIM
            elif ad == "explorer":
                yol = os.path.join(OUTPUT, "Explorer")
            else:
                yol = OUTPUT
            os.makedirs(yol, exist_ok=True)
            os.startfile(yol)                                   # noqa: S606
            return {"ok": True, "yol": yol}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}

    # ================================================== EXPLORER AGAC (arsiv > tur > sinif)
    # FModel/Anvil tarzi sol agac + satir altinda ic dosyalar. Ikisi de SALT OKUMA:
    # agac indeks kolonlarindan kurulur (forge ACILMAZ), cocuklar explorer_core.tani'yi
    # sarar (forge yalniz okunur). Agac oturumda BIR kez kurulur ve onbelleklenir
    # (olculdu: tablo 0,25 sn, sonraki cagrilar <5 ms).
    def explorer_agac(self, forge=None):
        """{ok, dallar:[{forge, sayi, turler:[{tur, sayi, siniflar:[{sinif, sayi}]}]}],
            turler:[{tur, sayi}]} -- forge verilirse yalniz o dal."""
        try:
            VI = self._vi()
            EX = self._ex()
            ix = VI.yukle()
            if ix is None:
                r = self._explorer_indeks_yok(VI)
                r["dallar"] = []
                return r
            onbellek = getattr(self, "_ex_agac", None)
            if onbellek is None or onbellek[0] is not ix:
                onbellek = (ix, EX.agac(ix))
                self._ex_agac = onbellek
            a = onbellek[1]
            if not forge:
                return a
            # TEK ARSIV: dal onbellekten SUZULMEZ, yeniden kurulur -- yalniz boylece o
            # arsivin ham (BMS olmayan) TOC girisleri de sayilara girer. Ham liste
            # explorer_core'da arsiv basina onbelleklidir (olculdu: boot 0,23 sn).
            return EX.agac(ix, str(forge).strip())
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200], "dallar": []}

    def explorer_cocuklar(self, gid, forge=None):
        """Girisin ic dosyalari: {ok, cocuklar:[{icid, ad, sinif, tip, boyut, xml_acilir}]}.
        xml_acilir=True olan satir arayuzde nesne_xml_ver(gid, icid, forge) ile acilir."""
        try:
            EX = self._ex()
            return EX.cocuklar(gid, self._explorer_arsiv(forge))
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300], "cocuklar": []}

    # ================================================== WEAPON STATS (silah_stat koprusu)
    # Cekirdek src/silah_stat.py'de yasar; burasi YALNIZ kopru -- kural kopyasi yok.
    # Cekirdegin panel fonksiyonlari (silah_kartlari / silah_plani / silah_uygula) eski bir
    # kurulumda BULUNMAYABILIR: getattr ile bakilir ve ACIK bir mesajla reddedilir, boylece
    # arayuze AttributeError ya da 'undefined' dusmez.
    def _silah_stat_fn(self, ad):
        """silah_stat modulundeki `ad` fonksiyonu (yoksa None)."""
        try:
            import silah_stat as SS
        except Exception as e:                                  # noqa: BLE001
            print("silah_stat yuklenemedi:", e)
            return None
        return getattr(SS, ad, None)

    def silah_stat_kartlari(self):
        """WEAPON STATS paneli: her silahin duzenlenebilir stat satirlari + o degeri
        paylasan silah sayisi. SALT OKUMA -- forge yalniz 'rb' acilir, tek bayt yazilmaz.
        Kademe sistemi yuzunden PAYLASIM sayisi kritiktir: arayuz onu her secenekte gosterir."""
        fn = self._silah_stat_fn("silah_kartlari")
        if fn is None:
            return {"ok": False, "mesaj": "Weapon stats are not available in this build."}
        try:
            return fn()
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def silah_stat_plan(self, anahtar, istekler):
        """PREVIEW / APPLY'in ilk asamasi: ne yazilacagini SALT OKUNUR hesaplar.
        Arsive tek bayt gitmez; kullanici ozeti gormeden yazma cagrisi yapilmaz.
        `istekler` = {"sword_dmg": 25, ...} (degerler ETKIN deger olarak)."""
        fn = self._silah_stat_fn("silah_plani")
        if fn is None:
            return {"ok": False, "mesaj": "Weapon stats are not available in this build."}
        try:
            return fn(anahtar, dict(istekler or {}))
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False, "mesaj": str(e)[:300]}

    def silah_stat_uygula(self, anahtar, istekler):
        """APPLY: kullanici ozeti ONAYLADIKTAN sonra yazar. disa_aktar_3d/ice_aktar_3d ile
        ayni disiplin: tek is kilidi (_is), ilerleme _log'a, sonuc _bildir ile. Asil
        'oyun acik' kapisi kur_mesh'te; mesaji buradan da AYNEN verilir ki kullanici
        yarim yolda degil, dugmeye basar basmaz ogrensin."""
        fn = self._silah_stat_fn("silah_uygula")
        if fn is None:
            return {"ok": False, "mesaj": "Weapon stats are not available in this build."}
        istek = dict(istekler or {})
        if not istek:
            return {"ok": False, "mesaj": "Nothing to change."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            self._log("- weapon stats: %s" % anahtar)
            for a, v in sorted(istek.items()):
                self._log("  requested %s = %s" % (a, v))

            def ilerleme(d):
                try:
                    self._log("  writing %s  %d / %d"
                              % (d.get("set"), int(d.get("i", 0)) + 1, int(d.get("n", 1))))
                except Exception:                               # noqa: BLE001
                    pass
            r = fn(anahtar, istek, etiket="weapon stats", ilerleme=ilerleme) or {}
            for s in (r.get("sonuc") or []):
                for d in (s.get("degisim") or []):
                    self._log("  %s: %s" % (s.get("set"), d))
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj")
                             or "Nothing was written - see the log.")
                return
            self._log("SUCCESS: every write is in the undo record.")
            self._bildir("bitti", {"t": "Weapon stats written for {0} - start the game to see it. Revert stats puts the original numbers back.", "a": [anahtar]})
        return self._is(is_)

    def silah_stat_geri_al(self):
        """Kurulu TUM silah-stat yamalarini geri al (kur_mesh geri alma kaydi)."""
        fn = self._silah_stat_fn("geri_al")
        if fn is None:
            return {"ok": False, "mesaj": "Weapon stats are not available in this build."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            self._log("- reverting weapon stats...")
            r = fn() or {}
            for o in (r.get("sonuc") or []):
                if not o.get("ok"):
                    self._log("  FAILED: %s" % o.get("mesaj"))
            if not r.get("ok"):
                self._bildir("hata", r.get("mesaj") or "Nothing was reverted.")
                return
            self._bildir("bitti", "Weapon stats reverted - the original numbers are back.")
        return self._is(is_)

    def parcalar(self, ad):
        """Kiyafet/silah parcalari (Tk parca tablosunun verisi)."""
        try:
            o = C.get_outfit(ad)
            cikti = []
            for m in C.outfit_materials(o):
                p = m.get("paylasim", {})
                cikti.append({
                    "ad": m.get("parca_adi", m["mat_id"]),
                    "dokusuz": bool(m.get("dokusuz")),
                    "renk": p.get("renk", "YESIL"),
                    "boyanabilir": sum(1 for s in m.get("slotlar", [])
                                       if s.get("duzenlenebilir")),
                    "etki": (p.get("aciklama") or p.get("ozet") or ""),
                })
            return cikti
        except Exception as e:
            print("parcalar hata:", e)
            return []

    # ================================================== 3D vitrin
    def _boya_imza(self, ad):
        klasor = os.path.join(OUTPUT, ad)
        if not os.path.isdir(klasor):
            return ""
        try:
            import glob as g
            iz = []
            for png in sorted(g.glob(os.path.join(klasor, "**", "*.png"),
                                     recursive=True)):
                st = os.stat(png)
                iz.append("%s:%d:%d" % (os.path.basename(png),
                                        int(st.st_mtime), st.st_size))
            return "|".join(iz)
        except OSError:
            return ""

    def dondur(self, ad, aci, tur="chr"):
        """Vitrin karesi (gercek 3D motor, onbellekli sicak oturum).
        Kiyafette kullanicinin BOYADIGI dokular kareye islenir (Tk ile ayni)."""
        anahtar_ad = ("CHR_" + ad) if tur == "chr" else ad
        imza = "" if tur == "chr" else self._boya_imza(ad)
        a = (anahtar_ad, int(aci) % 360, imza)
        with self._kilit:
            if a in self._kare_onbellek:
                return self._kare_onbellek[a]
            try:
                import onizleme3d as O3
                from PIL import Image
                if self._oturum is None:
                    self._oturum = O3.Oturum()
                ust = {}
                if tur != "chr":
                    try:
                        kaynak = C._design_kaynak(os.path.join(OUTPUT, ad))
                        adaylar, _t = C._design_adaylari(kaynak)
                        for png, mat_id, slot, _cs in adaylar:
                            if slot == 0:
                                ust[mat_id] = Image.open(png).convert("RGB")
                    except Exception:
                        ust = {}
                im = self._oturum.render(anahtar_ad, doku_ust_yazim=ust or None,
                                         aci=a[1], boyut=420, ssaa=1)
                if im is None:
                    return None
                buf = io.BytesIO()
                im.save(buf, "PNG")
                uri = ("data:image/png;base64,"
                       + base64.b64encode(buf.getvalue()).decode())
                if len(self._kare_onbellek) > 240:
                    self._kare_onbellek.clear()
                self._kare_onbellek[a] = uri
                return uri
            except Exception as e:
                print("dondur hata:", e)
                return None

    # ================================================== KARAKTER akisi
    def kur(self, ad, slot):
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        if self._mesgul_mu():
            return {"ok": False, "mesaj": "Another job is still running."}
        try:
            atamalar = self._atamalar()
            atamalar[slot] = ad
            import uuid as _u
            tmp = os.path.join(tempfile.gettempdir(),
                               "OW_v09_%s.forge" % _u.uuid4().hex[:8])
            if len(atamalar) == 1:
                KT.uret(ad, OYUN, tmp, slotlar=(slot,))
            else:
                KT.uret_coklu(atamalar, OYUN, tmp)
            hedef = self._patch_yolu()
            bizim = bool(self._atamalar())
            if os.path.exists(hedef) and not bizim \
                    and not os.path.exists(hedef + ".charswap_bak"):
                shutil.move(hedef, hedef + ".charswap_bak")
            shutil.copy2(tmp, hedef)
            try:
                os.remove(tmp)
            except OSError:
                pass
            self._durum_yaz(atamalar)
            return {"ok": True, "atamalar": atamalar}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}
        finally:
            self._serbest()

    def kaldir(self):
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        if self._mesgul_mu():
            return {"ok": False, "mesaj": "Another job is still running."}
        try:
            hedef = self._patch_yolu()
            if os.path.exists(hedef):
                os.remove(hedef)
            if os.path.exists(hedef + ".charswap_bak"):
                shutil.move(hedef + ".charswap_bak", hedef)
            try:
                os.remove(DURUM_DOSYA)
            except OSError:
                pass
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:300]}
        finally:
            self._serbest()

    # ================================================== KIYAFET/SILAH akisi
    def disa_aktar(self, ad):
        o = C.get_outfit(ad)
        if not o:
            return {"ok": False, "mesaj": "outfit not found"}

        def is_():
            self._log("- exporting %s ..." % o["gorunen_ad"])
            res = C.export_outfit(o, OUTPUT, progress=self._log)
            klasor = (res or {}).get("klasor") or os.path.join(OUTPUT, o["ad"])
            self._log("SUCCESS: exported to %s" % klasor)
            try:
                os.startfile(klasor)
            except OSError:
                pass
            self._bildir("bitti", "Exported — the folder is open. Paint the "
                                  "PNGs in EDIT, then press APPLY.")
        return self._is(is_)

    # ================================================== 3D DISA AKTARMA (GLB)
    def disa_aktar_3d(self, ad, tur="out"):
        """Secili kiyafeti Blender'a hazir GLB olarak yazar (tek yon, SALT OKUMA).

        disa_aktar kalibi: tek is kilidi (_is), ilerleme _log, sonuc _bildir.
        Oyun acikken reddetmeye gerek yok: forge yalniz 'rb' acilir. Sayilar
        _log'a gider; _bildir metni SABIT (ceviri harvester'i % iceren dizeyi
        atlar). Cikti OUTPUT\\3D\\<ad>[_N] — APPLY'in taradigi OUTPUT\\<ad> ile
        ayrik; PNG'ler TEX_ onekli oldugundan apply adayi uretmez.
        tur="chr" 52/52 kapisi gectigi icin arayuzde ACIK; anahtar CHR_ onekiyle kurulur.
        tur="wpn" Weapons sekmesi: AYRI indeks (silah_indeks.json) + sahne.kur(silah=True);
        pistol/musket rigid oldugu icin o GLB'lerde armature YOKTUR (dogru davranis)."""
        anahtar = str(ad or "")
        if tur == "chr" and not anahtar.startswith("CHR_"):
            anahtar = "CHR_" + anahtar
        silah = (tur == "wpn")
        try:
            from export3d import sahne as S3
            idx, _yol = S3.silah_indeks_yukle() if silah else S3.indeks_yukle()
        except Exception as e:
            print("export3d yuklenemedi:", e)
            return {"ok": False, "mesaj": "3D export module is missing."}
        if anahtar not in idx and not S3.anahtar_var(anahtar, silah):
            # ceviri hasatcisi '"mesaj": "..."' kalibini satir satir tarar; tek tek yazilir
            if silah:
                return {"ok": False, "mesaj": "weapon not found"}
            if tur == "chr":
                return {"ok": False, "mesaj": "character not found"}
            return {"ok": False, "mesaj": "outfit not found"}

        def is_():
            self._log("- exporting 3D %s ..." % anahtar)
            try:
                res = S3.kur(anahtar, progress=self._log, silah=silah)
            finally:
                C.release_forge(onbellek=False)
            self._log("parts exported: %d / %d" % (res["cikan"], res["parca_sayisi"]))
            for a in res["atlanan"]:
                self._log("  skipped %s: %s" % (a["ad"], a["sebep"]))
            if silah:
                self._log("rigid parts %d, armature %s; GLB %.1f MB, loose PNG %.1f MB; %.1f s"
                          % (res.get("rigid_parca", 0), "yes" if res.get("armature") else "no",
                             res.get("glb_bayt", 0) / 1e6, res.get("gevsek_png_bayt", 0) / 1e6,
                             res["sure"]))
            else:
                self._log("rig: hierarchical %d, flat %d; GLB %.1f MB, loose PNG %.1f MB; %.1f s"
                          % (res["rig"]["hiyerarsik"], res["rig"]["duz"],
                             res.get("glb_bayt", 0) / 1e6, res.get("gevsek_png_bayt", 0) / 1e6,
                             res["sure"]))
            if not res.get("ok"):
                self._bildir("hata", "No part could be exported.")
                return
            self._log("SUCCESS: exported to %s" % res["klasor"])
            try:
                os.startfile(res["klasor"])
            except OSError:
                pass
            self._bildir("bitti", "Export 3D done. Open the .glb in Blender (File > Import > glTF 2.0).")
        return self._is(is_)

    # ================================================== 3D ICE AKTARMA (IMPORT)
    def _3d_klasor(self, ad, tur):
        """Bu anahtarin varsayilan export klasoru: OUTPUT\\3D\\<anahtar> (yoksa OUTPUT\\3D)."""
        anahtar = str(ad or "")
        if tur == "chr" and not anahtar.startswith("CHR_"):
            anahtar = "CHR_" + anahtar
        kok = os.path.join(OUTPUT, "3D")
        aday = os.path.join(kok, anahtar)
        if os.path.isdir(aday):
            return aday
        return kok if os.path.isdir(kok) else OUTPUT

    def _3d_anahtar(self, ad, tur):
        """Manifest'te yazan anahtar (_3d_klasor ile AYNI CHR_ oneki kurali)."""
        anahtar = str(ad or "")
        if tur == "chr" and not anahtar.startswith("CHR_"):
            anahtar = "CHR_" + anahtar
        return anahtar

    def _3d_export_klasoru(self, ad, tur):
        """(klasor, manifest) ya da (None, None). Klasor bulma mantigi ice_aktar_3d ile
        AYNI (`_3d_klasor`); tek fark, SWAP PARTS penceresinde dosya dialogu YOK, bu yuzden
        bulunan klasorun manifest'i gercekten BU ogeye ait mi diye bakilir. `_3d_klasor`
        alt klasor yoksa OUTPUT\\3D kokune duser ve orada baska bir ogenin manifest'i
        durabilir -- o zaman kullaniciya "once EXPORT 3D" demek dogru cevaptir."""
        k = self._3d_klasor(ad, tur)
        y = os.path.join(k, "manifest.json")
        if not os.path.isfile(y):
            return None, None
        try:
            with open(y, encoding="utf-8") as f:
                man = json.load(f)
        except Exception:                                       # noqa: BLE001
            return None, None
        if str(man.get("anahtar") or "") != self._3d_anahtar(ad, tur):
            return None, None
        return k, man

    def parca_listesi(self, ad, tur="out"):
        """SWAP PARTS penceresinin veri kaynagi: bu ogenin export manifestindeki parcalar.

        SALT OKUNUR -- oyun arsivi hic acilmaz, yalniz manifest.json okunur. Export klasoru
        yoksa (ya da baska bir ogeye aitse) {ok: False, sebep: "export first"} doner; arayuz
        bunu gorunce kullaniciyi EXPORT 3D dugmesine yonlendirir.

        Doner: {ok, klasor, anahtar, gorunen_ad, silah,
                parcalar:[{ad, taban, gorunen, NV, NT, materyal, materyaller, gid, icid}],
                ciftler:[{sag, sol, taban_sag, taban_sol}]}"""
        if not ad:
            return {"ok": False, "sebep": "no item", "mesaj": "Pick an item first."}
        klasor, man = self._3d_export_klasoru(ad, tur)
        if not klasor:
            # metin arayuzdeki T(...) anahtarinin BIREBIR aynisi: tek ceviri anahtari
            return {"ok": False, "sebep": "export first",
                    "mesaj": "Export this item first (EXPORT 3D). The Workshop reads the "
                             "part list from that export folder."}
        parcalar = []
        for p in (man.get("parcalar") or []):
            if p.get("durum") != "cikan":
                continue
            mats = [m for m in (p.get("materyaller") or []) if m]
            ad_p = str(p.get("ad") or "")
            # gorunen ad = TABAN (kirpik LOD eki olmadan). Ingilizce sozcuk EKLENMEZ:
            # "(right hand)" gibi etiketleri arayuz T() ile kendi dilinde ekler.
            parcalar.append({"ad": ad_p, "taban": str(p.get("taban") or "") or ad_p,
                             "gorunen": (str(p.get("taban") or "")
                                         or ad_p.split("?")[0].rstrip("_")),
                             "NV": int(p.get("NV") or 0), "NT": int(p.get("NT") or 0),
                             "materyal": (mats[0] if mats else None), "materyaller": mats,
                             "gid": p.get("gid"), "icid": p.get("icid")})
        if not parcalar:
            return {"ok": False, "sebep": "no parts",
                    "mesaj": "That export has no parts that can be swapped."}
        return {"ok": True, "klasor": klasor, "tur": tur,
                "anahtar": man.get("anahtar"), "gorunen_ad": man.get("gorunen_ad"),
                "silah": bool(man.get("silah")),
                "parcalar": parcalar, "ciftler": _lr_ciftleri(parcalar)}

    def ice_aktar_3d(self, ad, tur="out", klasor=None, onay=False, imza=None,
                     gizle_eksik=False, capraz_esleme=None):
        """Duzenlenmis 3D export klasorunu geri okur (IMPORT 3D). IKI ASAMALI.

        Asama 1 -- DOGRULA (onay=False): klasor secilir (verilmediyse dialog,
          baslangic = o anahtarin export klasoru), SALT-OKUNUR taranir ve duz
          Ingilizce bir rapor DONER: hangi parca nasil degismis (vertex eklendi/
          silindi/oynadi), hangi doku yeniden boyanmis, NE YAZILACAK, ne REDDEDILDI
          ve NEDEN. Bu asamada arsive tek bayt yazilmaz -- forge yalniz 'rb' acilir.
        Asama 2 -- UYGULA (onay=True): kullanici raporu gorup onayladiktan sonra
          yazar. Kapilar: oyun acik mi · yarim kalmis bir yazim var mi · onaydan
          beri klasor degisti mi (imza) · is boyunca oyun klasoru degisti mi.
          Yazim GERI ALMA KAYDINA girer (dokular doku_enjekte2, mesh'ler kur_mesh)
          ve yazimdan SONRA arsivden geri okunup dogrulanir.

        Mesh geri yazimi bu surumde ACIK (doku_ithal.MESH_YAZIM = True):
        ayni topolojide `mesh_yaz.yaz`, topoloji degistiyse `mesh_yaz.yaz_serbest`.

        `capraz_esleme` (SWAP PARTS penceresi) = {kaynak_parca: hedef_parca}: verilirse
        otomatik eslemenin USTUNE yazar ve yalniz eslenen parcalar yazilir. AYNI ogenin
        icinde de calisir ("sag kilici sol yuvaya koy"). Bu harita HER IKI asamaya da
        gecer -- dogrulamada ve yazmada: yalniz birine gecirmek "kullanici eslemeyi secer,
        yazma asamasi unutur" hatasini uretir (daha once yasandi)."""
        try:
            from export3d import doku_ithal as DI
        except Exception as e:                                  # noqa: BLE001
            print("doku_ithal yuklenemedi:", e)
            return {"ok": False, "mesaj": "3D import module is missing."}
        esleme = _esleme_temizle(capraz_esleme)
        if not klasor:
            import webview
            bas = self._3d_klasor(ad, tur)
            s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG, directory=bas)
            klasor = (s[0] if s else None)
            if not klasor:
                return {"ok": False, "mesaj": "cancelled"}
        klasor = os.path.normpath(klasor)
        if not onay:
            try:
                r = DI.tara(klasor, gizle_eksik=bool(gizle_eksik),
                            hedef=ad, hedef_silah=(tur == "wpn"),
                            capraz_esleme=esleme)
            except FileNotFoundError as e:
                return {"ok": False, "mesaj": str(e)}
            except Exception as e:                              # noqa: BLE001
                print(traceback.format_exc())
                return {"ok": False, "mesaj": "That folder could not be read: %s" % e}
            m = r.get("mesh") or {}
            return {"ok": True, "klasor": klasor, "asama": "rapor",
                    "imza": r.get("imza"),
                    "yazilacak": len(r["yazilacak"]), "red": len(r["red"]),
                    "degismeyen": r.get("degismeyen", 0),
                    "mesh_yazilacak": r.get("mesh_yazilacak", 0),
                    "mesh_red": len(m.get("red") or []),
                    "mesh_atlanan": m.get("atlanan", 0),
                    "mesh_degisen": len(m.get("degisen") or []),
                    "mesh_tasinan": len(m.get("tasinan") or []),
                    "mesh_eksik": len(m.get("eksik") or []),
                    "mesh_gizlenecek": int(m.get("gizlenecek") or 0),
                    "gizle_eksik": bool(gizle_eksik),
                    "capraz": bool(r.get("capraz")),
                    "capraz_kaynak": (r.get("anahtar") if r.get("capraz") else None),
                    "capraz_hedef": (ad if r.get("capraz") else None),
                    # PARCA TAKASI: esleme raporla birlikte GERI DONER; arayuz onu saklamak
                    # zorunda kalmaz ve "gizle" kutusu yeniden dogrulama yaptiginda da,
                    # yazma cagrisinda da AYNI harita kullanilir.
                    "takas": bool(r.get("takas")),
                    "esleme": esleme,
                    "toplam": len(r["yazilacak"]) + int(r.get("mesh_yazilacak") or 0),
                    "satirlar": DI.rapor_metni(r)}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        erken = C.DE.uygula_kontrol() if hasattr(C.DE, "uygula_kontrol") else None
        if erken:
            return {"ok": False, "mesaj": "Nothing was imported.\n%s" % erken}
        forge0 = C.DE.FORGE          # is boyunca oyun klasoru DEGISMEMELI

        def is_():
            if C.DE.FORGE != forge0:
                self._bildir("hata", "The game folder changed while the job was "
                                     "starting - nothing was written.")
                return
            self._log("- import folder: %s" % klasor)
            # Bayat sayacinin BASLANGIC degeri: sonra ARTISI olcecegiz, boylece
            # bu isin isaretledigi kayitlar, eskiden duran bayat kayitlardan ayrilir.
            bayat0 = self._mesh_bayat_sayisi()
            # Onay ekranindaki rapor hala GECERLI mi? (kullanici onayladiktan sonra
            # Blender'da kaydetmis olabilir -- o zaman onayladigi sey yazilmaz.)
            r = DI.tara(klasor, progress=self._log, gizle_eksik=bool(gizle_eksik),
                        hedef=ad, hedef_silah=(tur == "wpn"),
                        capraz_esleme=esleme)
            if imza and r.get("imza") and imza != r["imza"]:
                self._bildir("hata", "The folder changed after you confirmed, so nothing "
                                     "was written. Press IMPORT 3D again to see a fresh "
                                     "report.")
                return
            r = DI.uygula(klasor, progress=self._log, rapor=r)
            for x in r["red"]:
                self._log("  REFUSED %s: %s" % (x.get("dosya"), x["sebep"]))
            ms = r.get("mesh_sonuc") or {}
            n_doku = len(r["yazilacak"]) if r.get("yazilan_giris") else 0
            n_mesh = len(ms.get("yazilan") or [])
            for w in ms.get("yazilan") or []:
                self._log("  mesh written: %s  %d B -> %d B  (undo record %s)"
                          % (w["ad"], w["eski_bayt"], w["yeni_bayt"], w["kayit_id"]))
            if not n_doku and not n_mesh:
                self._bildir("hata", "Nothing was imported - every change was refused "
                                     "or unchanged. See the log.")
                return
            # SOZCUK: "part" raporda IKI ayri sey demeye basladi. Kullanicinin
            # Blender'da gordugu sey PART; arsivde yer kaplayan sey MESH ENTRY
            # (bir part, LOD bantlari yuzunden birden cok giris tutabilir).
            # Sayilar ayrildiginda bu ACIKCA soylenir, yoksa kullanici "4 part
            # yazdim ama 2 parcam vardi" diye okur.
            n_parca = len([g for g in (ms.get("gruplar") or []) if g.get("ok")])
            if n_parca and n_mesh > n_parca:
                self._log("  %d part(s) needed %d mesh entr(ies): one part can occupy "
                          "several LOD entries in the archive." % (n_parca, n_mesh))
            self._log("SUCCESS: %d texture(s) and %d mesh entr(ies) imported; every write is "
                      "in the undo record." % (n_doku, n_mesh))
            # BAYAT KAYIT: kurulum GECTI ama eski yamalar artik geri alinamaz.
            # Once dogrudan sozlesmede ara (mesh_ithal tasidigi gun kendiliginden
            # yakalanir), sonra kaydin bayat sayacindaki ARTISa bak: artis, bu isin
            # isaretledigi kayitlari gosterir, eskiden kalanlari degil.
            uy = _bayat_izi(ms) or _bayat_izi(r.get("uyari"))
            yeni_bayat = max(0, self._mesh_bayat_sayisi() - bayat0)
            if not uy and yeni_bayat:
                # {t, a} kalibi: duz "%d" dizesi hicbir sozluge giremez ve bes dilin
                # hepsinde Ingilizce kalirdi. Sozlesmeden GELEN metin (yukaridaki
                # `_bayat_izi`) ise bizim degil, oldugu gibi gecirilir.
                uy = {"t": "{0} older mesh patch record(s) were marked out of date and "
                           "can no longer be reverted: the game archive changed (it was "
                           "updated or its files were verified) after those patches "
                           "were installed. The bytes that were in the archive just now "
                           "have been backed up, so this import can still be reverted.",
                      "a": [yeni_bayat]}
            if uy:
                # log DUZ metin ister; arayuzdeki msj() ile ayni doldurma kurali.
                metin = uy if isinstance(uy, str) else str(uy["t"]).replace(
                    "{0}", str(uy["a"][0]))
                self._log("WARNING: %s" % metin)
                self._bildir("uyari", uy)
                self._bildir("bitti", {"t": "Imported {0} texture(s) and {1} mesh entr(ies) - "
                                            "start the game to see it. One warning needs "
                                            "reading: see the log.",
                                       "a": [n_doku, n_mesh]})
                return
            self._bildir("bitti", {"t": "Imported {0} texture(s) and {1} mesh entr(ies) - start "
                                        "the game to see it. Revert restores the original.",
                                   "a": [n_doku, n_mesh]})
        return self._is(is_)

    def klasor_sec(self, ad):
        """Uygulanacak tasarim klasorunu sec (Tk _apply ile ayni baslangic)."""
        import webview
        baslangic = os.path.join(OUTPUT, ad) if ad else OUTPUT
        if not os.path.isdir(baslangic):
            baslangic = OUTPUT if os.path.isdir(OUTPUT) else os.path.expanduser("~")
        s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG,
                                           directory=baslangic)
        return (s[0] if s else None)

    def _apply_on_kapi(self, design):
        """Kiyafet yazmanin SENKRON on kapilari (dugmeye basar basmaz cevap).

        Doner (design, scan, hata_metni). hata_metni doluysa is HIC baslamaz."""
        if not design:
            return None, None, "no folder"
        if self._oyun_acik_mi():
            return None, None, "Close the game first."
        design = os.path.normpath(design)
        try:
            scan = C.scan_design_dir(design)
        except Exception as e:
            return None, None, "Could not read that folder: %s" % e
        if scan["sayi"] == 0:
            if scan.get("alt_tasarimlar"):
                return None, None, ("That folder holds several designs. Open it "
                                    "and pick one of:\n"
                                    + "\n".join(scan["alt_tasarimlar"][:8]))
            return None, None, "No recognisable texture files in that folder."
        return design, scan, None

    def _apply_kapisi(self, design, progress=None, scan=None):
        """STANDART kiyafet yazma kapisi — TEK YER.

        Hem APPLY dugmesi (`uygula`) hem MODS sekmesindeki mod kurulumu
        (`mod_kayit.OUTFIT_UYGULA`) BURAYI cagirir; kapi dizisi
        (on kapilar -> uygula_kontrol -> status_outfit -> base-shift 'safe' ->
        reddedilenler -> DE.uygula) hicbir yere KOPYALANMAZ.

        Imza `mod_kayit`in bekledigi sozlesmedir: callable(klasor, progress)
        -> {ok, yazilan_giris, red_sebep?}."""
        gunluk = progress or self._log
        if scan is None:
            design, scan, hata = self._apply_on_kapi(design)
            if hata:
                return {"ok": False, "yazilan_giris": 0, "red_sebep": hata}
        gunluk("- design folder: %s" % design)
        atilan = (scan.get("tani") or {}).get("gormezden_gelinen") or []
        for x in atilan[:8]:
            gunluk("  not used (wrong location): %s" % x)
        erken = C.DE.uygula_kontrol() if hasattr(C.DE, "uygula_kontrol") else None
        if erken:
            gunluk("REFUSED before encoding: %s" % erken)
            return {"ok": False, "yazilan_giris": 0,
                    "red_sebep": "Nothing was applied.\n%s" % erken}
        gunluk("- checking design is safe (read-only)...")
        st = C.status_outfit(design, progress=gunluk)
        if st.get("kabul", 0) == 0:
            red = st.get("reddedilen") or []
            if red:
                msj = "Every texture was rejected:\n" + "\n".join(
                    "%s — %s" % (a, s) for a, s in red[:6])
            elif st.get("atlanan") and st.get("atlanan") == st.get("toplam"):
                msj = ("All %d files are identical to the export — nothing "
                       "new to write." % st["toplam"])
            else:
                msj = "No usable texture files found."
            gunluk("Nothing to apply.")
            return {"ok": False, "yazilan_giris": 0, "red_sebep": msj}
        if st.get("safe") is False:
            gunluk("REFUSED: base-shift check is NOT safe.")
            return {"ok": False, "yazilan_giris": 0,
                    "red_sebep": "Safety check failed — nothing was written."}
        red = st.get("reddedilen") or []
        if red:
            gunluk("REFUSED: %d file(s) failed the gates." % len(red))
            return {"ok": False, "yazilan_giris": 0,
                    "red_sebep": "%d file(s) were rejected; nothing was written:\n%s"
                                 % (len(red), "\n".join("%s — %s" % (a, s)
                                                        for a, s in red[:6]))}
        gunluk("Safety check passed (%d slots)." % st["kabul"])
        gunluk("- writing via the single writer...")
        # GOLGE BILINCLI YAZMA (2026-10-25): yama ile guncellenen materyallerde yalniz tam boy
        # dokular (harici mip; oyun bunlari boot'tan okur) yazilir, gomulu kucuk mip'ler atlanir
        # ve NOT dusulur; tam boy dokunun kendisi golgeliyse red_sebep (C.doku_yaz_golge_bilincli).
        r = (C.doku_yaz_golge_bilincli(st["dds_dir"], progress=gunluk)
             if hasattr(C, "doku_yaz_golge_bilincli") else (C.DE.uygula(st["dds_dir"]) or {}))
        if r.get("red_sebep"):
            gunluk("REFUSED by the writer: %s" % r["red_sebep"])
            return {"ok": False, "yazilan_giris": 0,
                    "red_sebep": "Nothing was applied.\n%s" % r["red_sebep"]}
        yazilan = r.get("harici", 0) + r.get("gomulu", 0)
        if yazilan == 0:
            return {"ok": False, "yazilan_giris": 0,
                    "red_sebep": "Nothing was written — see the log."}
        return {"ok": True, "yazilan_giris": yazilan,
                "harici": r.get("harici", 0), "gomulu": r.get("gomulu", 0),
                "uyari": r.get("golge_notu")}

    def uygula(self, design, etiket=None):
        """Tk _apply_klasoru'nun birebir portu: ayni kapilar, ayni sira."""
        design, scan, hata = self._apply_on_kapi(design)
        if hata:
            return {"ok": False, "mesaj": hata}

        forge0 = C.DE.FORGE          # is boyunca oyun klasoru DEGISMEMELI

        def is_():
            if C.DE.FORGE != forge0:
                self._bildir("hata", "The game folder changed while the job "
                                     "was starting - nothing was written.")
                return
            r = self._apply_kapisi(design, progress=self._log, scan=scan)
            if not r.get("ok"):
                self._bildir("hata", r.get("red_sebep") or "Nothing was applied.")
                return
            son = etiket or os.path.basename(design)
            if r.get("uyari"):
                self._log("NOTE: %s" % r["uyari"])
            self._log("SUCCESS: %d entries written for %s."
                      % (r["yazilan_giris"], son))
            self._bildir("bitti", {"t": "Applied {0} — start the game to see it. "
                                        "Revert restores the original.", "a": [son]})
        return self._is(is_)

    def _mesh_durum(self):
        """kur_mesh (IMPORT 3D mesh yamalari) durumu; modul yoksa None."""
        try:
            from export3d import kur_mesh as KM
            return KM, KM.durum(C.DE.FORGE)
        except Exception:                                       # noqa: BLE001
            return None, None

    def _mesh_kuyruk(self):
        """Arsiv, kur_mesh'in TABANININ kac bayt ustunde? Bilinmiyorsa None.

        Sozlesmenin iki kapisi da denenir (kur_mesh ikisini de ayni sayiyla
        besler): once `kuyruk_bayt(forge)`, olmazsa `saglik(forge)["mesh"]
        ["kuyruk_bayt"]`. 0 GECERLI bir cevaptir — "None mi 0 mi" ayrimi bu
        ozelligin tamami oldugu icin `or` ile ezilmez."""
        KM, _d = self._mesh_durum()
        if KM is None:
            return None
        try:
            forge = C.DE.FORGE
        except Exception:                                       # noqa: BLE001
            return None
        try:
            fn = getattr(KM, "kuyruk_bayt", None)
            if fn is not None:
                v = fn(forge)
                if v is not None:
                    return int(v)
        except Exception:                                       # noqa: BLE001
            pass
        try:
            sg = KM.saglik(forge) or {}
            v = (sg.get("mesh") or {}).get("kuyruk_bayt")
            if v is None:
                v = sg.get("kuyruk_bayt")
            return None if v is None else int(v)
        except Exception:                                       # noqa: BLE001
            return None

    def _mesh_bayat_sayisi(self):
        """Bayat (out of date) isaretli mesh yama kaydi sayisi; olculemezse 0."""
        _KM, d = self._mesh_durum()
        try:
            return int((d or {}).get("bayat") or 0)
        except Exception:                                       # noqa: BLE001
            return 0

    def _mesh_geri_al(self, log=None):
        """Mesh yamalarini geri al. DOKUDAN ONCE cagrilir: iki depo da arsivin
        SONUNA yazar ve kuyrugu ancak KENDI bloklari en sondayken kirpabilir.
        Ithalat once doku sonra mesh yazdigi icin geri alma TERS sirada olmali."""
        KM, d = self._mesh_durum()
        if KM is None or not d or not d.get("aktif"):
            return {"ok": True, "geri_alindi": 0}
        if log:
            log("- reverting %d mesh patch(es)..." % d["aktif"])
        r = KM.geri_al_hepsi(C.DE.FORGE) or {}
        if log:
            log("  mesh patches reverted: %d (%d B trimmed back)"
                % (r.get("geri_alindi", 0), r.get("kirpilan", 0)))
            # NOT: kur_mesh'in kuyruk SEBEBI burada BASILMAZ -- `_gerial_hukmu`
            # onu tam olcumun yanina koyar. Iki yerde basilirsa kullanici ayni
            # uzun cumleyi ust uste iki kez okur (olculdu: test_gerial_durustluk K2).
            for b in (r.get("basarisiz") or []):
                log("  NOT reverted (%s): %s" % (b.get("id"), b.get("mesaj")))
        return r

    def geri_al(self):
        """Dokulari VE ithal edilmis mesh'leri geri al — karakterlerden AYRI."""
        _KM, md = self._mesh_durum()
        mesh_var = bool(md and md.get("aktif"))
        if not os.path.exists(C.DE.KAYIT) and not mesh_var:
            return {"ok": False, "mesaj": "Nothing to revert — the archive is "
                                          "original."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            mr = self._mesh_geri_al(self._log)
            if not mr.get("ok"):
                self._bildir("hata", "Revert refused: %s"
                             % (mr.get("mesaj") or (mr.get("basarisiz") or [{}])[0].get("mesaj")))
                return
            if os.path.exists(C.DE.KAYIT):
                self._log("- reverting all textures...")
                r = C.revert_outfit(progress=self._log) or {}
                if r.get("red_sebep"):
                    self._bildir("hata", "Revert refused: %s" % r["red_sebep"])
                    return
            # DURUSTLUK: "ok" demek "arsiv eski boyuna dondu" DEMEK DEGIL. Kuyruk
            # HER IKI geri alma bittikten sonra olculur (doku tarafi mesh'ten sonra
            # kosar ve arsivi kucultebilir), sonra hukum verilir.
            h = _gerial_hukmu(mr, self._mesh_kuyruk())
            for satir in h["satirlar"]:
                self._log(satir)
            if h["kod"] == GERIAL_ARTIK:
                self._log("DONE: the patches are reverted but the archive is still "
                          "larger than it was.")
                self._bildir("bitti", {"t":
                             "All textures and imported models were reverted, but "
                             "the archive is still {0} bytes larger than before this "
                             "tool first wrote to it — the log says what to do "
                             "about it.",
                             "a": [h["kuyruk"]]})
                return
            if h["kod"] == GERIAL_BILINMIYOR:
                self._log("DONE: every patch was reverted.")
                self._bildir("bitti",
                             "All textures and imported models were reverted. These "
                             "patch records do not store the archive size from before "
                             "the first patch, so Workshop cannot confirm the archive "
                             "is back to its original size.")
                return
            if h["kod"] == GERIAL_TEMIZ:
                self._log("SUCCESS: archive restored to original.")
                self._bildir("bitti", {"t":
                             "All textures and imported models were reverted and {0} "
                             "bytes were trimmed back — the archive is restored to "
                             "its original size.",
                             "a": [h["kirpilan"]]})
                return
            self._log("SUCCESS: archive restored to original.")
            self._bildir("bitti", "All textures and imported models reverted — the "
                                  "archive is back to original.")
        return self._is(is_)

    def revert_kapsam(self, ad):
        """SALT OKUNUR: 'sadece bu kiyafeti geri al' ne yapar? (onay metni icin)

        Kullanici REVERT'e basmadan ONCE ne olacagini gorsun diye ayri bir
        salt-okuma cagrisi; forge'a tek bayt yazmaz.
        """
        try:
            k = C.revert_scope(ad)
        except Exception as e:
            return {"ok": False, "mesaj": str(e)[:200]}
        return {"ok": True, "giris": k["giris"],
                "materyal": len(k["kendi_materyal"]),
                "diger_kalan": k["diger_kalan"], "tumu_mu": k["tumu_mu"],
                "sorunlar": [str(x)[:200] for x in k["sorunlar"]],
                "paylasilan": [{"parca": p["parca"],
                                "etkilenen": [_kiyafet_adi(x)
                                              for x in p["etkilenen"]]}
                               for p in k["paylasilan"]]}

    def geri_al_secili(self, ad):
        """Yalniz SECILI kiyafetin boyanmis dokularini geri al.

        Tam revert'ten farki: kayittaki diger kiyafetlerin girisleri KALIR.
        Guvenlik kapisi ayni — yazici kayittaki her girisi dogrular, biri bile
        tutmazsa tek bayt yazilmaz.
        """
        if not os.path.exists(C.DE.KAYIT):
            return {"ok": False, "mesaj": "Nothing to revert — the archive is "
                                          "original."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            self._log("- reverting only this outfit...")
            r = C.revert_outfit_only(ad, progress=self._log) or {}
            n = r.get("geri_alindi", 0)
            if not n:
                self._bildir("bitti", r.get("mesaj")
                             or "Nothing to revert for this outfit.")
                return
            kalan = r.get("kalan", 0)
            self._log("SUCCESS: %d entr%s reverted."
                      % (n, "y" if n == 1 else "ies"))
            self._bildir("bitti",
                         {"t": "This outfit is back to original. {0} painted "
                               "entries from other outfits kept.", "a": [kalan]}
                         if kalan else
                         "This outfit is back to original. Nothing else was painted.")
        return self._is(is_)

    # ================================================== RESTORE ALL (v0.16)
    # "Undo every change this app made" TEK dugmedir, ama arkasinda BES ayri defter
    # var. Eskiden yalniz ucu kapaniyordu (boyali dokular, bizim patch_02, sesler);
    # kur_mesh defteri (Hide Parts, Ship Stats, Weapon Stats, Edit as XML, Unpack All
    # geri koyma, Explorer ham geri koyma, IMPORT 3D, mod kurulumunun mesh parcalari)
    # ve Ships sekmesinin doku defteri HIC acilmiyordu -- dugme yine de "Everything
    # restored" diyordu (olculdu: testler/test_restore_all_kum.py; R11 sabotaj kapisi
    # eski davranisi yeniden uretir ve arsivin vanilla'ya DONMEDIGINI gosterir).
    #
    # TEK YAZICI kurali burada da gecerli: bu metotlar forge'a KENDI ELIYLE dokunmaz.
    #   kur_mesh defteri   -> kur_mesh.geri_al_hepsi(forge) + kuyruk_temizle(forge)
    #   Ships dokulari     -> ship_core.geri_al(anahtar)   (icinde bayat_kayitlari_kapat)
    #   boyali dokular     -> outfit_core.revert_outfit    (doku_enjekte2.gerial)
    #   patch_02 / sesler  -> eskisi gibi
    #
    # SIRA OFSETLE SECILIR. Uc yazici da bloklarini arsivin SONUNA ekler ve yalniz
    # kendi blogu dosyanin EN SONUNDAYSA kirpabilir (ship_yerinde.geri_al,
    # doku_enjekte2.gerial). kur_mesh'in supurmesi (kuyruk_temizle) yeniden
    # kosturulabilir, otekiler DEGIL. Bu yuzden en son yazan (en yuksek ofset) ILK
    # geri alinir, kur_mesh supurmesi en SONA konur. Yine de kalan bayt varsa
    # DURUSTCE soylenir ("still N bytes larger"); "restored" DENMEZ.
    #
    # Donus sozlesmesi: {ok, kismi, parcalar:[kalip], sorunlar:[kalip], ayrinti, mesaj}
    #   ok       = hicbir sorun yok (kismi False)
    #   kismi    = en az bir sey geri alinamadi ya da olculemedi -> arayuz uyari basar
    #   parcalar = yapilanlar, sorunlar = geri alinamayanlar + sebebi; ikisi de
    #              {"t": ..., "a": [...]} kaliplaridir (arayuz msj() ile cevirir)
    #   mesaj    = ayni seyin INGILIZCE duz metni (log + testler)
    _RESTORE_MESH_METIN = {
        "hide": {"t": "{0} hidden part(s) shown again"},
        "ship_stat": {"t": "{0} ship stat(s) back to original"},
        "weapon_stat": {"t": "{0} weapon stat(s) back to original"},
        "xml": {"t": "{0} XML edit(s) reverted"},
        "batch": {"t": "{0} Unpack All write(s) reverted"},
        "explorer": {"t": "{0} Explorer write(s) reverted"},
        "mesh": {"t": "{0} imported model or mod mesh patch(es) reverted"},
    }
    _RESTORE_MESH_SIRA = ("hide", "ship_stat", "weapon_stat", "xml", "batch", "explorer",
                          "mesh")
    # gemi_stat._ETIKET_RE'nin "explorer:" onekli hali (aciklama = etiket - onek)
    _RESTORE_SHIP_STAT_RE = re.compile(
        r"^explorer:xml\s+0x[0-9A-Fa-f]+/0x[0-9A-Fa-f]+\s+ship stat")

    @staticmethod
    def _kalip_metin(p):
        """Kalibi INGILIZCE duz metne cevir (log + `mesaj`; arayuz msj() ile cevirir)."""
        if isinstance(p, dict) and p.get("t"):
            try:
                return str(p["t"]).format(*(p.get("a") or []))
            except (IndexError, KeyError, ValueError):
                return str(p["t"])
        return str(p or "")

    def _restore_mesh_kategori(self, etiket):
        """kur_mesh kaydinin etiketinden hangi panelin yazdigini cikar."""
        e = str(etiket or "")
        if e.startswith("hide:"):
            return "hide"
        if self._RESTORE_SHIP_STAT_RE.match(e):
            return "ship_stat"
        if e.startswith("explorer:xml"):
            return "xml"
        if e.startswith("explorer:batch"):
            return "batch"
        if e.startswith("explorer:"):
            return "explorer"
        if e.startswith("weapon stats"):
            return "weapon_stat"
        return "mesh"

    @staticmethod
    def _restore_hide_parcasi(etiket):
        """'hide:<oge>:<parca>[ [LOD band N]][ | not]' -> '<oge>:<parca>'. Bir parca
        5 LOD bandi = 5 kayit; kullaniciya PARCA sayisi soylenir, kayit sayisi degil."""
        e = str(etiket or "")[len("hide:"):]
        for ayrac in (" [LOD band", " | "):
            i = e.find(ayrac)
            if i >= 0:
                e = e[:i]
        return e.strip()

    def _restore_mesh_sayim(self, girisler):
        """{kategori: sayi} -- hide icin parca sayisi, digerleri kayit sayisi."""
        sayim, parcalar = {}, set()
        for g in girisler:
            kat = self._restore_mesh_kategori(g.get("etiket"))
            if kat == "hide":
                parcalar.add(self._restore_hide_parcasi(g.get("etiket")))
            else:
                sayim[kat] = sayim.get(kat, 0) + 1
        if parcalar:
            sayim["hide"] = len(parcalar)
        return sayim

    @staticmethod
    def _restore_mesh_aktif(KM):
        """kur_mesh defterindeki ETKIN kayitlar (her arsiv; tam yol `forge` alaninda)."""
        kayit = KM._kayit_oku()
        return [g for g in (kayit.get("girisler") or [])
                if g.get("durum") in ("uygulandi", "yarim", "yaziliyor")]

    def _restore_sira(self, R):
        """Geri alma sirasi: ana arsivde EN YUKSEK ofsete yazan ILK. Olculemeyen sona.

        Esitlikte mesh once (supurmesi yeniden kosturulabilir), sonra doku, sonra gemi.
        Yalniz OKUR; sonucu `ayrinti.sira_ofset`e yazar."""
        boot = (os.path.normcase(os.path.abspath(C.DE.FORGE))
                if getattr(C.DE, "FORGE", None) else None)
        son = {"mesh": -1, "doku": -1, "gemi": -1}
        try:
            from export3d import kur_mesh as KM
            for g in self._restore_mesh_aktif(KM):
                yol = os.path.normcase(os.path.abspath(str(g.get("forge") or "")))
                if boot and yol != boot:
                    continue
                off = g.get("yeni_off") if g.get("yeni_off") is not None else g.get("plan_off")
                if off is not None:
                    son["mesh"] = max(son["mesh"], int(off))
        except Exception as e:                                  # noqa: BLE001
            self._log("restore order: mesh ledger unreadable (%s)" % e)
        try:
            if os.path.exists(C.DE.KAYIT):
                with open(C.DE.KAYIT, encoding="utf-8") as f:
                    k = json.load(f)
                for blok in (k.get("ek_bloklar") or []):
                    son["doku"] = max(son["doku"], int(blok[0]))
                for g in (k.get("gomulu") or []):
                    if g.get("yeni_off") is not None:
                        son["doku"] = max(son["doku"], int(g["yeni_off"]))
        except Exception as e:                                  # noqa: BLE001
            self._log("restore order: texture record unreadable (%s)" % e)
        try:
            SC = self._ship()
            _A, _M, Y = SC._motor()
            for anahtar in SC.yamali_hedefler():
                h = SC.hedef_bul(anahtar)
                yol = os.path.join(SC._D.get("oyun") or "", h["forge"])
                if boot and os.path.normcase(os.path.abspath(yol)) != boot:
                    continue
                try:
                    k, _p = Y.kayit_oku(yol, int(h["id"], 16))
                except Exception:                               # noqa: BLE001
                    continue
                off = ((k or {}).get("giris") or {}).get("yeni_off")
                if off is not None:
                    son["gemi"] = max(son["gemi"], int(off))
        except Exception as e:                                  # noqa: BLE001
            self._log("restore order: ship records unreadable (%s)" % e)
        R["ayrinti"]["sira_ofset"] = dict(son)
        oncelik = {"mesh": 0, "doku": 1, "gemi": 2}
        return sorted(son, key=lambda a: (-son[a], oncelik[a]))

    def _restore_doku(self, R):
        """Boyali dokular (Outfits / Weapons / Characters / Explorer PNG): TEK doku
        defteri, TEK yazici (doku_enjekte2.gerial). Red = sorun; oteki adimlar surer."""
        if not os.path.exists(C.DE.KAYIT):
            R["parcalar"].append({"t": "no painted textures"})
            return
        try:
            r = C.revert_outfit(progress=self._log) or {}
        except Exception as e:                                  # noqa: BLE001
            R["sorunlar"].append({"t": "Texture revert failed: {0}", "a": [str(e)[:200]]})
            R["kismi"] = True
            return
        R["ayrinti"]["doku"] = {"geri_alindi": r.get("geri_alindi"),
                                "kayit_var": r.get("kayit_var")}
        if r.get("kayit_var"):
            # Yazici red vermedi ama defter hala duruyor: geri alinmis SAYILMAZ.
            R["sorunlar"].append({"t": "Texture revert refused: {0}",
                                  "a": ["the texture record is still in place"]})
            R["kismi"] = True
            return
        R["parcalar"].append({"t": "painted textures back to original"})

    def _restore_mesh(self, R):
        """kur_mesh defteri: ETKIN her kayit, arsiv arsiv. En yeniden eskiye siralamayi
        kur_mesh.geri_al_hepsi yapar (ek bloklar ancak o sirada kirpilabilir)."""
        try:
            from export3d import kur_mesh as KM
            aktif = self._restore_mesh_aktif(KM)
        except Exception as e:                                  # noqa: BLE001
            R["sorunlar"].append({"t": "Mesh patches could not be checked: {0}",
                                  "a": [str(e)[:200]]})
            R["kismi"] = True
            return
        if not aktif:
            R["parcalar"].append({"t": "no mesh patches"})
            return
        once = self._restore_mesh_sayim(aktif)
        forgeler = {}
        for g in aktif:
            yol = str(g.get("forge") or "")
            forgeler.setdefault(os.path.normcase(os.path.abspath(yol)), yol)
        R["ayrinti"]["mesh"] = {"once": once, "sonuc": {},
                                "arsiv": [os.path.basename(y) for y in forgeler.values()]}
        R["_mesh_forgeler"] = list(forgeler.values())
        C.release_forge(onbellek=True)
        try:
            for yol in sorted(forgeler.values(), key=lambda y: os.path.basename(y).lower()):
                self._log("- reverting mesh patches in %s ..." % os.path.basename(yol))
                try:
                    r = KM.geri_al_hepsi(forge=yol) or {}
                except Exception as e:                          # noqa: BLE001
                    r = {"ok": False, "basarisiz": [{"id": "*", "mesaj": str(e)[:200]}]}
                R["ayrinti"]["mesh"]["sonuc"][os.path.basename(yol)] = {
                    "ok": r.get("ok"), "geri_alindi": r.get("geri_alindi"),
                    "kirpilan": r.get("kirpilan"), "basarisiz": r.get("basarisiz") or [],
                    "kuyruk_bayt": r.get("kuyruk_bayt")}
                for b in (r.get("basarisiz") or []):
                    self._log("  FAILED %s: %s" % (b.get("id"), b.get("mesaj")))
        finally:
            C._invalidate_cache()
        try:
            kalan = self._restore_mesh_aktif(KM)
        except Exception:                                       # noqa: BLE001
            kalan = []
        sonra = self._restore_mesh_sayim(kalan)
        for kat in self._RESTORE_MESH_SIRA:
            if once.get(kat):
                n = max(0, once.get(kat, 0) - sonra.get(kat, 0))
                R["parcalar"].append(dict(self._RESTORE_MESH_METIN[kat], a=[n]))
        if kalan:
            sebep = None
            for s in R["ayrinti"]["mesh"]["sonuc"].values():
                if s["basarisiz"]:
                    sebep = s["basarisiz"][0].get("mesaj")
                    break
            R["sorunlar"].append({"t": "{0} mesh patch(es) could not be reverted: {1}",
                                  "a": [len(kalan), sebep or "no reason was given"]})
            R["kismi"] = True

    def _restore_gemi(self, R):
        """Ships sekmesi dokulari: ship_core.geri_al her yamali hedef icin (icinde
        KONUM kapisi + bayat_kayitlari_kapat; motor kendi defterini kendi kapatir)."""
        try:
            SC = self._ship()
            try:
                SC._motor()[2].onbellekleri_gecersiz_kil()     # TOC onbellegi taze olsun
            except Exception:                                   # noqa: BLE001
                pass
            liste = list(SC.yamali_hedefler())
        except Exception as e:                                  # noqa: BLE001
            R["sorunlar"].append({"t": "Ship textures could not be checked: {0}",
                                  "a": [str(e)[:200]]})
            R["kismi"] = True
            return
        if not liste:
            R["parcalar"].append({"t": "no ship textures"})
            return
        n, hata = 0, []
        for anahtar in liste:
            self._log("- ship: reverting %s" % anahtar)
            try:
                r = SC.geri_al(anahtar, gunluk=self._log) or {}
            except Exception as e:                              # noqa: BLE001
                r = {"ok": False, "mesaj": str(e)[:200]}
            if r.get("ok"):
                n += 1
            else:
                hata.append([anahtar, r.get("mesaj") or "refused"])
                self._log("  FAILED %s: %s" % (anahtar, r.get("mesaj")))
        try:
            kalan = list(SC.yamali_hedefler())
        except Exception:                                       # noqa: BLE001
            kalan = [a for a, _m in hata]
        R["ayrinti"]["gemi"] = {"istenen": liste, "geri_alinan": n, "hata": hata,
                                "kalan": kalan}
        R["parcalar"].append({"t": "{0} ship texture(s) back to original", "a": [n]})
        if hata or kalan:
            ilk = hata[0] if hata else [kalan[0], "the record is still marked as patched"]
            R["sorunlar"].append({"t": "{0} ship texture(s) could not be reverted ({1}): {2}",
                                  "a": [len(hata) or len(kalan), ilk[0], ilk[1]]})
            R["kismi"] = True

    def _restore_supur(self, R):
        """kur_mesh kuyruk supurmesi + OLCUM. Dokular / gemi geri alininca 'sonra gelen
        blok canli' diye kirpilamayan olu mesh bloklari artik kirpilabilir. Sonra arsiv
        hala buyukse SOYLENIR (bilinmiyorsa susulur: kur_mesh.kuyruk_olc sozlesmesi)."""
        try:
            from export3d import kur_mesh as KM
        except Exception:                                       # noqa: BLE001
            return
        yollar = list(R.pop("_mesh_forgeler", None) or [])
        ana = getattr(C.DE, "FORGE", None)
        if ana and os.path.isfile(ana) and os.path.normcase(os.path.abspath(ana)) not in \
                {os.path.normcase(os.path.abspath(y)) for y in yollar}:
            yollar.append(ana)
        R["ayrinti"]["kuyruk"] = {}
        for yol in yollar:
            if not os.path.isfile(yol):
                continue
            try:
                s = KM.kuyruk_temizle(yol) or {}
            except Exception as e:                              # noqa: BLE001
                s = {"ok": False, "mesaj": str(e)[:200]}
            try:
                o = KM.kuyruk_olc(yol)
            except Exception as e:                              # noqa: BLE001
                o = {"bayt": None, "biliniyor": False, "mesaj": str(e)[:200]}
            ad = os.path.basename(yol)
            R["ayrinti"]["kuyruk"][ad] = {
                "kirpilan": s.get("kirpilan"), "bayt": o.get("bayt"),
                "biliniyor": o.get("biliniyor"), "kaynak": o.get("kaynak"),
                "boyut": o.get("boyut")}
            if s.get("kirpilan"):
                self._log("- %s: %d dead byte(s) trimmed from the end" % (ad, s["kirpilan"]))
            if o.get("biliniyor") and o.get("bayt"):
                R["sorunlar"].append({"t": "{0} is still {1} bytes larger than before this "
                                           "app first wrote to it.", "a": [ad, o["bayt"]]})
                R["kismi"] = True

    def _restore_patch(self, R):
        """patch_02 (karakter/mod) -- yalniz BIZIM yazdigimiz patch silinir."""
        hedef = self._patch_yolu()
        try:
            if not os.path.exists(hedef):
                R["parcalar"].append({"t": "no character swap installed"})
                return
            bizim = bool(self._atamalar()) or not os.path.exists(DURUM_DOSYA)
            try:
                with open(DURUM_DOSYA, encoding="utf-8") as f:
                    d0 = json.load(f)
                bizim = self._patch_bizim_mi(d0)
            except Exception:                                   # noqa: BLE001
                pass
            if not bizim:
                R["parcalar"].append({"t": "a patch from another tool was left in place"})
                return
            os.remove(hedef)
            if os.path.exists(hedef + ".charswap_bak"):
                shutil.move(hedef + ".charswap_bak", hedef)
                R["parcalar"].append({"t": "characters removed, previous mod restored"})
            else:
                R["parcalar"].append({"t": "characters/mod removed"})
            try:
                os.remove(DURUM_DOSYA)
            except OSError:
                pass
        except Exception as e:                                  # noqa: BLE001
            self._log("patch remove failed: %s" % e)
            R["sorunlar"].append({"t": "The character patch could not be removed: {0}",
                                  "a": [str(e)[:200]]})
            R["kismi"] = True

    def _restore_ses(self, R):
        """Sesler (takas + susturma): ses_core.geri_al once TUM yedekleri dogrular."""
        try:
            import ses_core as SS
            r = SS.geri_al() or {}
        except Exception as e:                                  # noqa: BLE001
            self._log("sound revert failed: %s" % e)
            R["sorunlar"].append({"t": "Sound revert failed: {0}", "a": [str(e)[:200]]})
            R["kismi"] = True
            return
        if not r.get("ok"):
            self._log("sound revert: %s" % r.get("mesaj"))
            R["sorunlar"].append({"t": "Sound revert refused: {0}",
                                  "a": [r.get("mesaj") or "no reason was given"]})
            R["kismi"] = True
        elif r.get("geri_alindi"):
            R["parcalar"].append({"t": "sound changes reverted"})
        else:
            R["parcalar"].append({"t": "no sound changes"})

    def hepsini_geri_al(self):
        """RESTORE ALL: bu uygulamanin yazdigi HER SEYI geri al (blok notuna bak).

        Kismi durumlar DURUSTCE raporlanir: hangi parca geri alinamadi, neden. Bir adim
        duserse otekiler yine kosar; hicbir adim yakalanmamis istisna birakmaz (eskiden
        2. adim patlayinca JS'e reddedilen promise gidiyordu, kullanici hicbir sey
        gormuyordu -- denetimde olculdu). Senkron doner (eskisi gibi)."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        if self._mesgul_mu():
            return {"ok": False, "mesaj": "Another job is still running."}
        R = {"ok": True, "kismi": False, "parcalar": [], "sorunlar": [], "ayrinti": {}}
        t0 = time.time()
        try:
            self._log("- restore all: starting")
            sira = self._restore_sira(R)
            R["ayrinti"]["sira"] = list(sira)
            adimlar = {"mesh": self._restore_mesh, "doku": self._restore_doku,
                       "gemi": self._restore_gemi}
            for adim in sira:
                adimlar[adim](R)
            self._restore_supur(R)
            self._restore_patch(R)
            self._restore_ses(R)
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            R["sorunlar"].append({"t": "Restore stopped unexpectedly: {0}",
                                  "a": [str(e)[:200]]})
            R["kismi"] = True
        finally:
            self._serbest()
        R.pop("_mesh_forgeler", None)
        R["ok"] = not R["kismi"]
        R["sure"] = round(time.time() - t0, 1)
        yapilan = " · ".join(self._kalip_metin(p) for p in R["parcalar"])
        sorun = " · ".join(self._kalip_metin(p) for p in R["sorunlar"])
        R["mesaj"] = yapilan + ((" -- " + sorun) if sorun else "")
        self._log("- restore all: %s (%.1f s)" % ("done" if R["ok"] else "INCOMPLETE",
                                                  R["sure"]))
        if sorun:
            self._log("  not restored: %s" % sorun)
        return R

    def forge_dosya_kur(self):
        """Hazir .forge modunu (patch_02) OYUNA kur — dosya gercekten forge mu
        diye 'scimitar' imzasi denetlenir; mevcut patch yedeklenir.

        Yerinde bir yama VARSA once SORULUR: kullanici neyin yerine ne
        gectigini gormeden bu dugme yazmaz (MODS sekmesinde ayni uyari
        kurulum ekraninda cikar)."""
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        import webview
        s = _PENCERE[0].create_file_dialog(
            webview.OPEN_DIALOG, directory=self._mod_dialog_klasoru(),
            file_types=("Forge mod (*.forge)", "All files (*.*)"))
        if not s:
            return {"ok": False, "mesaj": "cancelled"}
        onay = self._forge_ustune_onayi(os.path.basename(s[0]))
        if not onay.get("ok"):
            return onay
        return self._forge_kur_dosya(s[0])

    # ------------------------------------------- hazir .forge yamasi (patch_02)
    # DENETIM 2026-09-07 (ENGEL 4): bu yol UC kapiyi atliyordu.
    #   (1) YAZMA_KILIDI: kilit dosyasi VARKEN bile oyun klasorune yaziyordu
    #       (kilit "olcum yapan ajanlar yazmasin" diye konmustu; delik buydu).
    #   (2) YEDEK: yedek TEK SLOTTU (`.charswap_bak`) ve kosul "yedek YOKSA
    #       yedekle" oldugu icin A->B->C sirasinda B'nin TEK KOPYASI yedeksiz
    #       eziliyordu (olculdu: B geri getirilemiyordu).
    #   (3) DEFTER: kurulan yama mod defterine girmiyordu, yani mod_kayit'in
    #       catisma/geri sarma/kaldirma makinesinin hicbiri isletilmiyordu.
    # Ucu de burada. Yazma yine TEK YERDE (`_forge_kur_dosya`); bu blok onun
    # kapilari, yedegi ve geri alma bileti.
    FORGE_ANAHTARI = "patch:DataPC_boot_patch_02.forge"

    def _forge_yazma_kapisi_kalip(self):
        """Yazma kapisinin CEVRILEBILIR hali: {"t": ..., "a": [...]} ya da None.

        Cumleyi URETEN tek yer burasi; `_forge_yazma_kapisi` bunun duz metnini
        dondurur. Ikiye ayirmanin sebebi olculdu: kilit cumlesi icinde bir DOSYA
        YOLU tasiyor, yani duz metin sozlukte anahtar olamaz ve dort dilde
        Ingilizce kaliyordu (kaptanin 2026-09-07 ekran goruntusu)."""
        if self._oyun_acik_mi():
            return {"t": "The game is running. Close Assassin's Creed IV before "
                         "installing or removing a mod."}
        try:
            from export3d import kur_mesh as KM
            kilit = KM.yazma_kilidi()
        except Exception:                                       # noqa: BLE001
            kilit = None
        if kilit:
            return {"t": "Writing to the game files is locked on this computer by "
                         "the file {0}. Delete that file if you want to write "
                         "again.", "a": [kilit]}
        if not OYUN:
            return {"t": "The game folder was not found, so there is nowhere to "
                         "install this patch."}
        return None

    def _forge_yazma_kapisi(self):
        """Yazmadan ONCE gecilmesi gereken kapilar. Sorun varsa INGILIZCE metin.

        mod_kayit._yazma_kapisi ile AYNI iki soru (oyun acik mi · yazma kilidi
        var mi) — kural kopyalanmaz, kilit dosyasi da kur_mesh'inkiyle AYNI
        dosyadir. AYRI FONKSIYON: test bunu etkisiz hale getirip kapinin
        gercekten ayirt edici oldugunu olcer."""
        k = self._forge_yazma_kapisi_kalip()
        return _duz_metin(k) if k else None

    def _forge_dosya_denetimi(self, yol):
        """Bu dosya gercekten kurulabilir bir oyun yamasi mi? -> (ok, mesaj)"""
        try:
            if not yol or not os.path.isfile(yol):
                return False, "That patch file is not there any more."
            with open(yol, "rb") as f:
                bas = f.read(9)
            if not bas.startswith(b"scimitar"):
                # "scimitar imzasi yok" bizim ic terimimiz; kullanici ne yapacagini
                # anlamali, ic biciminden haberdar olmak zorunda degil.
                return False, ("That file is not a game archive, so it was not installed. "
                               "A ready-made patch is a .forge file named "
                               "DataPC_boot_patch_02.forge.")
            boyut = os.path.getsize(yol)
            if boyut < 4096 or boyut > 2_000_000_000:
                return False, ("That file is %s, which is too %s to be a game patch, so it "
                               "was not installed."
                               % (("%.1f MB" % (boyut / 1048576.0)) if boyut >= 1048576
                                  else ("%d bytes" % boyut),
                                  "small" if boyut < 4096 else "large"))
            if os.path.abspath(yol) == os.path.abspath(self._patch_yolu()):
                return False, "That IS the installed patch."
        except OSError as e:
            return False, ("That patch file could not be read (%s)." % str(e)[:120])
        return True, ""

    def _forge_sha(self, yol):
        """Dosyanin tam sha256'si (yedek kimligi + 'hala oyunda mi' sorusu)."""
        import hashlib
        h = hashlib.sha256()
        with open(yol, "rb") as f:
            for parca in iter(lambda: f.read(1 << 22), b""):
                h.update(parca)
        return h.hexdigest()

    def _forge_yedek_kok(self):
        return os.path.join(os.path.dirname(DURUM_DOSYA), "patch_yedek")

    def _forge_yedekle(self, hedef):
        """Yerindeki yamayi ADIYLA yedekle. Doner: yedek yolu ya da None.

        Ad ICERIKTEN turer (sha256'nin ilk 16'si): ayni bayt iki kez
        kopyalanmaz, FARKLI bayt ise ASLA ustune yazilmaz. Eski tek slotlu
        `.charswap_bak` ucuncu kurulumda ikincinin tek kopyasini kaybediyordu."""
        if not hedef or not os.path.exists(hedef):
            return None
        sha = self._forge_sha(hedef)
        kok = self._forge_yedek_kok()
        os.makedirs(kok, exist_ok=True)
        y = os.path.join(kok, "%s_%s.forge"
                         % (os.path.splitext(os.path.basename(hedef))[0], sha[:16]))
        if os.path.exists(y) and os.path.getsize(y) == os.path.getsize(hedef):
            return y                                    # ayni bayt, zaten duruyor
        gecici = y + ".yaziliyor"
        shutil.copy2(hedef, gecici)
        os.replace(gecici, y)
        return y

    def _forge_durum_oku(self):
        """charswap.json'in BUGUNKU icerigi (yoksa None) — geri alma bileti."""
        try:
            with open(DURUM_DOSYA, encoding="utf-8") as f:
                return json.load(f)
        except Exception:                                       # noqa: BLE001
            return None

    def _forge_durum_yaz(self, d):
        """charswap.json'i eski haline dondur (None ise dosyayi kaldir)."""
        try:
            if d is None:
                if os.path.exists(DURUM_DOSYA):
                    os.remove(DURUM_DOSYA)
                return
            os.makedirs(os.path.dirname(DURUM_DOSYA), exist_ok=True)
            with open(DURUM_DOSYA, "w", encoding="utf-8") as f:
                json.dump(d, f)
        except Exception as e:                                  # noqa: BLE001
            print("charswap durumu geri yazilamadi:", e)

    def _forge_kurulu_ne(self):
        """Su an patch_02 yerinde NE var? Doner None ya da {ad, boyut, cumle}.

        Ustune yazmadan ONCE soylenecek cumle burada uretilir; "bir sey vardi"
        demek yetmez, NE oldugu soylenir."""
        if not OYUN:
            return None
        hedef = self._patch_yolu()
        if not os.path.exists(hedef):
            return None
        try:
            boyut = os.path.getsize(hedef)
        except OSError:
            return None
        mb = "%.1f MB" % (boyut / 1e6)
        d = self._forge_durum_oku() or {}
        if self._atamalar():
            # Karakter takasinin GORUNEN adlari durum dosyasinda duruyor.
            kimler = ", ".join(sorted({(v.get("gorunen") or v.get("ad") or "")
                                       for v in (d.get("atamalar") or {}).values()
                                       if isinstance(v, dict)}) or ["a character"])
            return {"ad": kimler, "boyut": boyut,
                    "cumle": ("A character swap you installed (%s) is in that same "
                              "patch file. Installing this one replaces it." % kimler)}
        ad = d.get("harici_mod")
        if ad:
            return {"ad": ad, "boyut": boyut,
                    "cumle": ("The ready-made patch \"%s\" is installed. Installing "
                              "this one replaces it." % ad)}
        return {"ad": os.path.basename(hedef), "boyut": boyut,
                "cumle": ("A ready-made patch put there by another tool is installed "
                          "(%s). Installing this one replaces it." % mb)}

    def _forge_ustune_uyarisi(self):
        """Kurulumdan ONCE ekranda gosterilecek uyari cumlesi (ya da None)."""
        k = self._forge_kurulu_ne()
        if not k:
            return None
        return (k["cumle"] + " The one that is there now is kept, so Remove puts "
                             "it back.")

    def _forge_ustune_onayi(self, yeni_ad=""):
        """Eski "INSTALL .FORGE FILE…" dugmesinin ONAY kapisi.

        MODS sekmesinde uyari kurulum ekraninda gorunur ve INSTALL onaydir;
        bu dugmenin ekrani yok, o yuzden isletim sisteminin onay penceresi
        kullanilir. Onay penceresi acilamazsa YAZMAYIZ: kullanicinin gormedigi
        bir karari onun adina vermeyiz."""
        uyari = self._forge_ustune_uyarisi()
        if not uyari:
            return {"ok": True}
        mesaj = uyari + (("\n\nInstall %s now?" % yeni_ad) if yeni_ad
                         else "\n\nInstall it now?")
        try:
            evet = _PENCERE[0].create_confirmation_dialog(
                "Replace the installed patch?", mesaj)
        except Exception:                                       # noqa: BLE001
            evet = None
        if evet:
            return {"ok": True}
        if evet is None:
            return {"ok": False, "mesaj": uyari + " Use the MODS tab to install this "
                                                  "patch, so you can read what it "
                                                  "replaces before it is written."}
        return {"ok": False, "mesaj": "Nothing was installed."}

    def _forge_dogrula(self, tutamak):
        """Bu yama HALA oyunda mi? -> ('taze'|'bayat'|'kayip', mesaj)

        mod_kayit "bayat"/"kayip" gorurse GERI YAZMAZ: ustumuze baska bir yama
        kurulduysa onu ezerek 'kaldirma' yapmayiz."""
        tutamak = tutamak or {}
        hedef = tutamak.get("hedef") or self._patch_yolu()
        if not hedef or not os.path.exists(hedef):
            return ("kayip", "The ready-made patch is not in the game folder any more.")
        try:
            if tutamak.get("boyut") and os.path.getsize(hedef) != tutamak["boyut"]:
                return ("bayat", "Another patch was installed over this one.")
            if tutamak.get("sha") and self._forge_sha(hedef) != tutamak["sha"]:
                return ("bayat", "Another patch was installed over this one.")
        except OSError as e:
            return ("bayat", "The installed patch could not be read (%s)."
                    % str(e)[:120])
        return ("taze", "")

    def _forge_geri_koy(self, tutamak, progress=None):
        """Defterden "Remove": yamayi kaldir, ONCEKINI adiyla geri koy."""
        kapi = self._forge_yazma_kapisi()
        if kapi:
            return {"ok": False, "mesaj": kapi}
        tutamak = tutamak or {}
        hedef = tutamak.get("hedef") or self._patch_yolu()
        yedek = tutamak.get("yedek")
        try:
            if yedek and os.path.exists(yedek):
                shutil.copy2(yedek, hedef)
                mesaj = ("The ready-made patch was removed and the patch that was "
                         "there before it was put back.")
            else:
                if os.path.exists(hedef):
                    os.remove(hedef)
                mesaj = ("The ready-made patch was removed. There was no patch "
                         "before it, so none was put back.")
            self._forge_durum_yaz(tutamak.get("durum_once"))
            if progress:
                progress(mesaj)
            return {"ok": True, "mesaj": mesaj}
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": ("The ready-made patch could not be put "
                                           "back (%s)." % str(e)[:150])}

    def _forge_kur_dosya(self, yol):
        """.forge (patch_02) kurulumu — TEK YER.

        Hem eski "INSTALL .FORGE FILE…" dugmesi hem MODS sekmesine birakilan
        paket buradan gecer; imza/boyut/yedek kurallari kopyalanmaz.
        Doner: {ok, mesaj, tutamak?} — `tutamak` mod defterinin geri alma bileti
        (hangi yedek, hangi durum dosyasi, yazilan baytin sha'si)."""
        kapi = self._forge_yazma_kapisi()
        if kapi:
            return {"ok": False, "mesaj": kapi}
        ok, sebep = self._forge_dosya_denetimi(yol)
        if not ok:
            return {"ok": False, "mesaj": sebep}
        try:
            hedef = self._patch_yolu()
            onceki = self._forge_kurulu_ne()
            # 1) ADIYLA yedek: once yazilan hicbir yama kaybolmaz.
            yedek = self._forge_yedekle(hedef)
            durum_once = self._forge_durum_oku()
            # 2) Eski TEK SLOTLU yedek bozulmadan kalir (karakter takasinin
            #    "Remove" yolu hala onu geri koyar) — geriye uyum.
            bizim = bool(self._atamalar())
            if os.path.exists(hedef) and not bizim \
                    and not os.path.exists(hedef + ".charswap_bak"):
                shutil.move(hedef, hedef + ".charswap_bak")
            try:
                shutil.copy2(yol, hedef)
            except Exception as e:                              # noqa: BLE001
                # 3) Yarim kalan kopya oyunda BOZUK bir yama birakmasin: yedek
                #    zaten alinmisti, hemen geri konur (disk dolma / kilitli
                #    dosya durumunda oyun calisir halde kalir).
                geri = self._forge_geri_koy({"hedef": hedef, "yedek": yedek,
                                             "durum_once": durum_once})
                if geri.get("ok"):
                    return {"ok": False, "mesaj":
                            "The patch could not be written (%s). The game files "
                            "were put back the way they were." % str(e)[:120]}
                # Geri koyma da tutmadi: SESSIZ KALMAYIZ, elle duzeltmenin
                # yolunu yaziyoruz (yedek dosyanin yeri dahil).
                return {"ok": False, "mesaj":
                        "The patch could not be written (%s) and the file that was "
                        "there before could not be put back either. Copy %s over %s "
                        "by hand before you start the game."
                        % (str(e)[:100], yedek or "your own backup copy", hedef)}
            boyut = os.path.getsize(hedef)
            self._durum_yaz({}, {"harici_mod": os.path.basename(yol)})
            tutamak = {"hedef": hedef, "ad": os.path.basename(yol), "yedek": yedek,
                       "durum_once": durum_once, "boyut": boyut,
                       "sha": self._forge_sha(hedef)}
            if onceki:
                mesaj = {"t": "{0} installed as DataPC_boot_patch_02.forge ({1} MB). "
                              "{2} was saved, so Remove puts it back.",
                         "a": [os.path.basename(yol), "%.1f" % (boyut / 1e6),
                               onceki["ad"]]}
            else:
                mesaj = {"t": "{0} installed as DataPC_boot_patch_02.forge ({1} MB).",
                         "a": [os.path.basename(yol), "%.1f" % (boyut / 1e6)]}
            return {"ok": True, "mesaj": mesaj, "tutamak": tutamak}
        except Exception as e:                                  # noqa: BLE001
            # Ham istisna KULLANICIYA gitmez: errno jargonu ve cift ters bolu
            # ekranda duruyordu. Tam izi LOG'a birakiriz, ekrana duz cumle gider.
            self._log("- patch install failed: %r" % (e,))
            try:
                import mod_kayit as _MKY
                m = _MKY._kullanici_cumlesi(str(e), "the patch could not be written")
            except Exception:                                   # noqa: BLE001
                m = "The patch could not be written."
            return {"ok": False, "mesaj":
                    "That patch was not installed. %s" % m}

    # ================================================== MODS sekmesi
    # KAPTANIN KURALI: mod kurmak "birak -> INSTALL" = IKI adim. Burasi YALNIZ
    # KOPRU; motor uc modulde yasar ve hicbiri yeni yazici acmaz:
    #   mod_paket      -> birakilan seyi (zip / rar / klasor / .forge / PNG
    #                     yigini) KURULUM PLANINA cevirir. SALT OKUMA.
    #   mod_kayit      -> plandaki her ogeyi ILGILI MEVCUT YAZICIYA yollar ve
    #                     hepsini TEK mod kaydi altinda tutar (kaldirma icin).
    #   mod_kutuphane  -> GitHub kanalindaki mod katalogu (guncelle.py'nin
    #                     kanalinin ayni dosyasi degil, ayni MEKANIZMASI).
    # Yazicilar: kiyafet -> bu dosyanin `_apply_kapisi`si · gemi -> ship_core ·
    # mesh/ham -> export3d.kur_mesh · .forge -> bu dosyanin `_forge_kur_dosya`si.
    #
    # ESKI AKISLAR BURAYA KATILDI: "PICK PNG FILES…" (icerikten eslestirme,
    # motoru `eslestir`) ve "INSTALL .FORGE FILE…" ayri ekranlar degil, ayni
    # birakma alaninin iki girdisidir. Yetenek kaybi yok, yer kaybi var.
    def _mp(self):
        """mod_paket (paket cozucu). TEMBEL: sekmeye girmeyen bedelini odemez."""
        import mod_paket as MP
        return MP

    def _mk(self):
        """mod_kayit (kurulu modlar defteri) + kiyafet kapisinin baglanmasi.

        `OUTFIT_UYGULA` BURADA takilir: mod kurulumu outfit_core'un kapisini
        degil, APPLY dugmesinin kullandigi AYNI kapiyi kullanir. Kapi dizisi
        tek yerde (`_apply_kapisi`) kalir, mod_kayit'e kopyalanmaz.

        Hazir .forge yamasi da AYNI sekilde kanca olarak takilir: defter onu
        artik oteki degisiklikler gibi taniyor (catisma · hepsi-ya-da-hic geri
        sarma · tek tikla Remove), ama YAZAN yine bu dosyadaki tek yazicidir."""
        import mod_kayit as MK
        MK.OUTFIT_UYGULA = self._apply_kapisi
        MK.ADAPTORLER["forge"] = self._forge_adaptoru()
        return MK

    def _forge_adaptoru(self):
        """mod_kayit'in ADAPTOR sozlesmesi ile hazir .forge yamasi arasindaki
        kopru. Yeni yazici DEGIL: kurma `_forge_kur_dosya`ya, geri alma
        `_forge_geri_koy`a gider.

        anahtar: yama TEK dosyadir, dolayisiyla catisma tanecigi de tek: iki
        farkli mod ayni patch_02'yi tutamaz, defter bunu ONCEDEN soyler."""
        def anahtar(oge):
            # Bozuk/eksik dosya BURADA yakalanir: mod_kayit anahtari cozulemeyen
            # bir plan icin TEK BAYT yazmaz.
            ok, sebep = self._forge_dosya_denetimi(oge.get("dosya"))
            if not ok:
                raise ValueError(sebep)
            return [self.FORGE_ANAHTARI]

        def ozet(oge):
            return ("Installs the ready-made game patch %s."
                    % os.path.basename(str(oge.get("kaynak") or oge.get("dosya") or "")))

        def arsivler(_oge):
            return [self._patch_yolu()]

        def kur(oge, progress=None, ustune=False):
            f = oge
            if progress:
                progress("- installing the ready-made patch %s ..."
                         % os.path.basename(str(f.get("kaynak") or f.get("dosya"))))
            rf = self._forge_kur_dosya(f["dosya"])
            if not rf.get("ok"):
                return rf
            yedek = (rf.get("tutamak") or {}).get("yedek")
            if yedek and progress:
                # Yedek SESSIZ kalmaz: kullanici hem geri alinabilecegini bilsin
                # hem de o klasorun yer kapladigini gorebilsin.
                progress("  the patch that was there before was saved in %s"
                         % os.path.dirname(yedek))
            return {"ok": True, "tutamak": rf.get("tutamak") or {},
                    "mesaj": _duz_metin(rf.get("mesaj"))}

        return {"anahtar": anahtar, "ince": anahtar, "ozet": ozet, "arsivler": arsivler,
                "kur": kur, "kaldir": self._forge_geri_koy,
                "dogrula": self._forge_dogrula}

    def _mkut(self):
        """mod_kutuphane (indirilebilir mod katalogu)."""
        import mod_kutuphane as ML
        return ML

    # ------------------------------------------------ plani EKRANA cevirmek
    def _md_dosya_adi(self, gorece):
        """Kullaniciya gosterilecek dosya adi.

        Ilk ekranda teknik kimlik GORUNMEZ: adi zaten bir kimlik olan dosya
        ("IC_22373CF86E6_tm…") adiyla degil, ne oldugu soylenerek anilir."""
        # CEVIRI: doner deger DUZ metindir (gercek dosya adi cevrilmez), ama iki
        # ozel karsilik kullanici cumlesidir. `_duz_metin({"t": ...})` yazmanin
        # sebebi olculdu: ceviri_envanter yalniz `{"t": "..."` seklini tarar,
        # ciplak `return "a file"` sozluge HIC girmez ve soru satiri dort dilde
        # yarim Ingilizce cikar. Arayuz bu alani T()'den gecirir; gercek dosya
        # adi sozlukte olmadigi icin oldugu gibi kalir.
        ad = os.path.basename(str(gorece or "")) or _duz_metin({"t": "a file"})
        try:
            if self._mp().TEKNIK_RE.search(ad):
                return _duz_metin({"t": "a picture whose name is only a code"})
        except Exception:                                       # noqa: BLE001
            pass
        return ad

    def _md_soru_listesi(self, plan):
        """Karar bekleyen ogeler -> TEK SATIRLIK sorular (tablo degil).

        CEVIRI: her kullanici metninin yaninda `*_kalip` ikizi gider
        (mod_paket'in sozlesmesi). Arayuz kalip varsa onu Tf() ile doldurur,
        yoksa duz metne duser -- eski bir paketten gelen plan da calisir."""
        sorular = []
        for i, o in enumerate(plan.get("ogeler") or []):
            if not o.get("kurulabilir") or not o.get("karar_gerekli"):
                continue
            secenekler = [{"deger": j,
                           "metin": a.get("metin") or "one of the outfits",
                           "metin_kalip": a.get("metin_kalip") or
                           (None if a.get("metin") else {"t": "one of the outfits"})}
                          for j, a in enumerate(o.get("adaylar") or [])]
            if not secenekler:
                continue
            sorular.append({
                "oge": i,
                "dosya": self._md_dosya_adi(o.get("kaynak")),
                "soru": o.get("soru") or "Which part of the game should this "
                                         "picture replace?",
                # Kalip YOKSA duz metne duseriz. Ogenin kendi sorusu varken
                # buraya genel kalibi koymak YANLIS ceviri olurdu; genel kalip
                # yalniz oge hic soru tasimadiginda (yani duz metin de
                # buradaki varsayilan oldugunda) kullanilir.
                "soru_kalip": o.get("soru_kalip") or (None if o.get("soru") else
                    {"t": "Which part of the game should this picture replace?"}),
                "secenekler": secenekler})
        return sorular

    def _md_ekran(self, plan, catisma=None):
        """M1 planini EKRAN MODELINE cevirir: birinci ekranda DUZ DIL, teknik
        kimlik YOK. Teknik dokum ayri alanda ("detay") durur ve arayuzde
        'Show details' arkasindadir."""
        ogeler = plan.get("ogeler") or []
        kurulabilir = [o for o in ogeler if o.get("kurulabilir")]
        mesh = [o for o in kurulabilir if o.get("yol") == "mesh"]
        # Birlesik yamaya ALINAN kaynak yamalar (mod_paket `birlesik_icinde`) ayrica
        # sayilmaz: "2 patches, none installed" notu yalan olurdu. Ust uste gelen ama
        # birlestirilemeyen yamalar (Nosso: boot + shared_00) eski yoldan ayni notu alir.
        forge = [o for o in kurulabilir if o.get("yol") == "forge"
                 and not o.get("birlesik_icinde")]
        birlesik = [o for o in kurulabilir if o.get("yol") == "forge_birlesik"]
        yazilabilir = [o for o in kurulabilir if o.get("yol") in ("outfit", "ship")]
        ozet = list(plan.get("ozet") or [])
        # CEVIRI (2026-09-07): bu ekranin HER kullanici metninin yaninda bir
        # `*_kalip` ikizi gider ({"t": "... {0} ...", "a": [...]}). Duz alanlar
        # AYNEN durur -- eski bir arayuzden gelen istek de calisir (kademeli
        # bozulma). `bilgi` ve `bilgi_kalip` PARALEL LISTELERDIR: ayni indis,
        # ayni cumle. Bu yuzden ikisi TEK dongude, birlikte doldurulur.
        # NOT: kaliplar TAM SOZLUK LITERALI olarak yazilir ({"t": "..."} biciminde,
        # kume parantezinden hemen sonra "t"). ceviri_envanter.py bu SEKLI tarar;
        # kalip metnini bir yardimci fonksiyona arguman olarak verirsek envanter
        # onu GORMEZ ve cumle sessizce dort dilde Ingilizce kalir.
        notlar_kalip = []
        if mesh:
            # DURUSTLUK: 3D sekil ithalati IKI ASAMALIDIR (once okunan bir rapor,
            # sonra onay). Tek tikla kurulamaz; bunu SOYLERIZ, sessizce atmayiz.
            notlar_kalip.append({"t": "This mod also changes the shape of {0} "
                                      "model(s). Shapes are put in from the Outfits "
                                      "or Weapons tab with IMPORT 3D, because they "
                                      "come with a report you have to read first.",
                                 "a": [len(mesh)]})
        if len(forge) > 1:
            notlar_kalip.append({"t": "This package holds {0} ready-made game "
                                      "patches. The game can only hold one at a "
                                      "time, so none of them was installed.",
                                 "a": [len(forge)]})
        notlar = [_duz_metin(k) for k in notlar_kalip]
        var = bool(yazilabilir) or (len(forge) == 1) or bool(birlesik)
        ekran = {
            "ok": bool(plan.get("ok")),
            "var": var,
            "ad": plan.get("ad") or "This mod",
            "yazar": plan.get("yazar") or "",
            "notlar_metni": plan.get("notlar") or "",
            "ozet": ozet,
            "ozet_kalip": list(plan.get("ozet_kalip") or []),
            "sorular": self._md_soru_listesi(plan),
            "bilgi": notlar,
            "bilgi_kalip": notlar_kalip,
            "uyarilar": list(plan.get("uyarilar") or []),
            "uyarilar_kalip": list(plan.get("uyarilar_kalip") or []),
            "mesaj": plan.get("mesaj") or "",
            "mesaj_kalip": plan.get("mesaj_kalip"),
            "tur": plan.get("tur"),
            "sayi": dict(plan.get("sayi") or {}),
            "catisma": catisma or {"var": False, "mesaj": "", "mesaj_kalip": None,
                                   "satirlar": []},
            # 'detay' ILK EKRANDA GORUNMEZ: 'Show details' acar.
            "detay": {
                "ogeler": [{"kaynak": o.get("kaynak"), "aciklama": o.get("aciklama"),
                            "aciklama_kalip": o.get("aciklama_kalip"),
                            "kurulabilir": bool(o.get("kurulabilir")),
                            "sebep": o.get("sebep") or "",
                            "sebep_kalip": o.get("sebep_kalip"),
                            "paylasilan": o.get("paylasilan") or []}
                           for o in ogeler],
                "tanimayan": plan.get("tanimayan") or [],
                "atlanan": plan.get("atlanan") or [],
                "cakisan": plan.get("cakisan") or []},
        }
        if not var and not ekran["mesaj"]:
            # Sebebi zaten `bilgi` satirinda yaziyorsa (ornegin paket YALNIZ 3D
            # sekil tasiyor) genel bir "hicbir sey kurulamaz" cumlesi eklemeyiz:
            # kullanici iki cumleyi celisik okur.
            ekran["mesaj_kalip"] = (None if notlar else
                {"t": "Nothing in this package can be installed by this tool."})
            ekran["mesaj"] = _duz_metin(ekran["mesaj_kalip"])
        return ekran

    # ------------------------------------------------ M1 plani -> M2 plani
    def _md_m2plan(self, plan, cevaplar=None, sahne=None):
        """mod_paket plani -> mod_kayit plani. Ceviri BURADA yasar: paketleyici
        "bu dosya nereye ait" der, defter "hangi yaziciya gider" ister.

        sahne=None: yalniz TARIF (catisma onizlemesi) — hicbir dosya kopyalanmaz.
        sahne=<klasor>: kiyafet PNG'leri o klasore standart export adiyla
        sahnelenir (APPLY dugmesinin okudugu bicim).
        Doner (m2plan, disarida_kalan_sayisi, forge_ogeleri, atlanan[]).

        DENETIM 2026-09-07 (ENGEL 4/7): hazir .forge yamasi ARTIK m2 planinin
        ogesidir. Once ayri bir yoldan kuruluyordu; o yol defteri, yazma
        kilidini ve hepsi-ya-da-hic geri sarmayi atliyordu. `forge_ogeleri`
        artik "plana KATILAN yama ogeleri"dir (bilgi amacli)."""
        cevaplar = {int(k): v for k, v in (cevaplar or {}).items()
                    if v is not None and v != ""}
        ogeler, forgeler, atlanan = [], [], []
        birlesikler = []
        outfit_slot, outfit_dosya = [], 0
        for i, o in enumerate(plan.get("ogeler") or []):
            if not o.get("kurulabilir"):
                continue
            yol = o.get("yol")
            hedef = o.get("hedef")
            if o.get("karar_gerekli"):
                sec = cevaplar.get(i)
                aday = (o.get("adaylar") or [])
                if sec is None or not (0 <= int(sec) < len(aday)):
                    atlanan.append({"kaynak": o.get("kaynak"),
                                    "sebep": "you did not say where it belongs"})
                    continue
                hedef = aday[int(sec)]["hedef"]
            if yol == "forge_birlesik":
                # N boot yamasi TEK ogede (mod_paket): kaynaklari mod_kayit'in
                # forge_birlesik adaptoru birlestirir ve MEVCUT yaziciya verir --
                # yeni yazici yok. Kaynak dosyalar planin gecici klasorunde durur.
                birlesikler.append({"tur": "forge_birlesik",
                                    "kaynaklar": list(o.get("kaynaklar") or []),
                                    "kaynak": o.get("kaynak")})
                continue
            if yol == "forge":
                if o.get("birlesik_icinde"):
                    # birlesik ogenin ICINDE kuruluyor: ayrica yama sayilmaz,
                    # atlanan'a da yazilmaz (kurulmayan bir sey degil).
                    continue
                forgeler.append(o)
                continue
            if yol == "mesh":
                atlanan.append({"kaynak": o.get("kaynak"),
                                "sebep": "shapes are put in with IMPORT 3D"})
                continue
            if yol == "ship":
                ogeler.append({"tur": "ship", "anahtar": (hedef or {}).get("anahtar"),
                               "png": o.get("dosya"), "alfa": "auto"})
                continue
            if yol == "outfit" and hedef:
                mat, slot = hedef.get("mat_id"), int(hedef.get("slot_idx"))
                cs = C._catalog_slot(mat, slot)
                if not cs:
                    atlanan.append({"kaynak": o.get("kaynak"),
                                    "sebep": "this outfit part is not in the "
                                             "tool's catalogue"})
                    continue
                outfit_slot.append({"mat": mat, "slot": slot})
                if sahne:
                    # .dds sahneye KENDI uzantisiyla girer: _encode_design_dir onu
                    # uyuyorsa yeniden kodlamadan gecirir (kayipsiz), uymuyorsa cevirir.
                    _uz = "dds" if (hedef.get("bicim") == "dds") else "png"
                    fn = C._slot_filename(mat, slot, cs["W"], cs["H"], cs["aile"], ext=_uz)
                    shutil.copy2(o["dosya"], os.path.join(sahne, fn))
                outfit_dosya += 1
        if outfit_slot:
            # TEK kiyafet ogesi: APPLY kapisi bir KLASOR alir, dosya degil.
            ogeler.insert(0, {"tur": "outfit",
                              "klasor": sahne or os.path.join(tempfile.gettempdir(),
                                                              "OutfitWorkshop_mod_onizleme"),
                              "slotlar": outfit_slot})
        # Hazir yama EN SONA: oyun tek yama tutabilir, o yuzden birden fazlasi
        # varsa HICBIRI kurulmaz (hangisini istedigini biz secemeyiz).
        if len(forgeler) == 1:
            f = forgeler[0]
            ogeler.append({"tur": "forge", "dosya": f.get("dosya"),
                           "kaynak": f.get("kaynak")})
        elif len(forgeler) > 1:
            for f in forgeler:
                atlanan.append({"kaynak": f.get("kaynak"),
                                "sebep": "the game can only hold one ready-made "
                                         "patch at a time"})
            forgeler = []
        # Birlesik yama da EN SONA (yuva tek; kiyafet/gemi ogeleri once yazilir).
        ogeler.extend(birlesikler)
        m2 = {"ad": plan.get("ad") or "This mod", "yazar": plan.get("yazar") or "",
              "surum": (plan.get("manifest") or {}).get("surum")
                       or (plan.get("manifest") or {}).get("version") or "",
              "kaynak": plan.get("_kaynak") or "", "ogeler": ogeler}
        return m2, outfit_dosya, forgeler, atlanan

    # ------------------------------------------------ birakma / secme
    def _md_plani_kur(self, yol, kaynak_etiketi=""):
        """Verilen yolu (dosya / klasor / liste) PLANA cevirip ekrana hazirlar.
        SALT OKUMA: bu cagri oyun arsivine dokunmaz."""
        self.mod_vazgec()
        try:
            MP = self._mp()
            plan = MP.coz(yol)
        except Exception as e:                                  # noqa: BLE001
            print(traceback.format_exc())
            return {"ok": False,
                    "mesaj": {"t": "That mod could not be read ({0}).",
                              "a": [str(e)[:180]]}}
        plan["_kaynak"] = kaynak_etiketi or (yol if isinstance(yol, str) else "")
        self._md_plan = plan
        if not plan.get("ok") or not plan.get("kurulabilir_var"):
            return self._md_ekran(plan)
        # CATISMA salt-okunur olcum: forge'a tek bayt yazmaz. (Bedeli: kiyafet
        # ogeleri icin varlik adlari okunur, yani varlik indeksi yuklenir.)
        catisma = {"var": False, "mesaj": "", "mesaj_kalip": None, "satirlar": [],
                   "birlestirilebilir": {"var": False}}
        try:
            MK = self._mk()
            m2, _n, _f, _a = self._md_m2plan(plan)
            c = MK.catisma(m2)
            adlar = sorted({x.get("mod_ad") or x.get("mod_id") or "another mod"
                            for x in (c.get("catismalar") or [])})
            # Ozeti mod_kayit URETIR, burada YENIDEN YAZILMAZ. Eskiden bu satirlar
            # kendi cumlesini kuruyordu ("Installing this one replaces those changes.")
            # ve o cumle "birlikte" turu catismada YALANDI: iki mod da yasiyor, gercek
            # tehlike ise birini kaldirmanin otekini de geri almasi. Dogru cumle zaten
            # uretiliyordu ama yalniz "Show details" arkasindaki panelde gorunuyordu.
            # mod_kayit CATISMA YOKKEN DE bir cumle donduruyor ("This mod does not
            # clash with anything you have installed."). Onu afise koymak iki sey
            # bozar: (a) afis bos durum icin gereksiz yere dolar, (b) defterde
            # olmayan yamanin uyarisi asagidaki dalda "satirlar"a dusup gizlenir.
            # Bu yuzden ozet YALNIZ gercek catismada alinir.
            # CEVIRI: mod_kayit'in kendi ozeti (`c["mesaj"]`) hala duz Ingilizce
            # dizedir -- o katman kaliba cevrilmedi, bu yuzden kalibi None kalir
            # ve arayuz duz metne duser (kademeli bozulma, gerileme degil).
            # BURADA kurulan iki cumlenin kalibi vardir.
            ozet = (c.get("mesaj") or "") if c.get("var") else ""
            ozet_kalip = None
            if not ozet and adlar:
                ozet_kalip = ({"t": "The mod \"{0}\" already changes some of the "
                                    "same things.", "a": [adlar[0]]}
                              if len(adlar) == 1 else
                              {"t": "{0} mods you already have change some of the "
                                    "same things.", "a": [len(adlar)]})
                ozet = _duz_metin(ozet_kalip)
            # BIRLESTIRILEBILIR (v0.15): kurulu bir hazir yama varken yeni bir hazir
            # yama geliyor (mod_kayit tur="birlestirilebilir"). Tek catisma buysa afis
            # cumlesi KALIPLI kurulur (mod_kayit'inki duz dizedir, cevrilemez) ve
            # arayuz iki dugme acar: Merge / Replace. `taze` degilse (yuvadaki dosya
            # artik listedeki degil) birlestirme teklif edilmez, eski akis surer.
            b = c.get("birlestirilebilir") or {}
            hepsi_yama = bool(c.get("catismalar")) and all(
                x.get("tur") == "birlestirilebilir" for x in (c.get("catismalar") or []))
            if b.get("var") and hepsi_yama:
                ozet_kalip = {"t": "A ready-made patch is already installed ({0}). This one can be merged with it, or replace it.", "a": [" + ".join(b.get("kaynaklar") or [b.get("mod_ad") or "another patch"])]}
                ozet = _duz_metin(ozet_kalip)
            catisma = {"var": bool(c.get("var")), "mesaj": ozet,
                       "mesaj_kalip": ozet_kalip,
                       "satirlar": [x.get("mesaj") for x in (c.get("catismalar") or [])],
                       "birlestirilebilir": {
                           "var": bool(b.get("var") and b.get("taze")),
                           "mod_ad": b.get("mod_ad"),
                           "kaynaklar": list(b.get("kaynaklar") or [])}}
            if c.get("ic_catismalar") and not catisma["var"]:
                catisma["mesaj_kalip"] = {"t": "Two files in this mod change the "
                                               "same thing; only one of them can win."}
                catisma["mesaj"] = _duz_metin(catisma["mesaj_kalip"])
            # ENGEL 4(4): defterde OLMAYAN bir yama da (baska bir aracin, eski
            # bir surumun ya da karakter takasinin koydugu) USTUNE YAZILMADAN
            # ONCE soylenir -- mod_kayit onu bilemez, defterinde yoktur.
            # Birlestirme teklif edilirken bu uyari MUKERRER basilmaz: afis zaten
            # "kurulu yama X, birlestir ya da degistir" diyor.
            if any(o.get("tur") in ("forge", "forge_birlesik") for o in m2["ogeler"]) \
                    and not catisma["birlestirilebilir"]["var"]:
                u = self._forge_ustune_uyarisi()
                if u:
                    if catisma["mesaj"]:
                        catisma["satirlar"] = list(catisma["satirlar"]) + [u]
                    else:
                        catisma["mesaj"] = u
                    catisma["var"] = True
        except Exception as e:                                  # noqa: BLE001
            print("catisma onizlemesi:", e)
        return self._md_ekran(plan, catisma)

    def mod_birak(self, yollar):
        """SURUKLE-BIRAK: pencereye birakilan dosya/klasor yollari.

        Not: yollari JS DEGIL, pywebview'in kendi DOM olay koprusu verir
        (WebView2 `postMessageWithAdditionalObjects`); tarayicida bir File
        nesnesinin diskteki yolu YOKTUR."""
        if isinstance(yollar, str):
            yollar = [yollar]
        yollar = [y for y in (yollar or []) if y]
        if not yollar:
            return {"ok": False, "mesaj": "Nothing was dropped."}
        return self._md_plani_kur(yollar if len(yollar) > 1 else yollar[0])

    def _mod_dialog_klasoru(self):
        """Dosya secme penceresinin ACILACAGI klasor.

        `directory` verilmezse pencere UYGULAMANIN KENDI klasorunde acilir
        (main() oraya chdir eder) -- kullanicinin indirdigi mod orada degildir.
        Indirilenler klasoru varsa oradan baslariz; oteki dialoglarda da
        (1948/2420/2546) ayni kalip kullaniliyor."""
        for aday in (os.path.join(os.path.expanduser("~"), "Downloads"),
                     OUTPUT, os.path.expanduser("~")):
            if aday and os.path.isdir(aday):
                return aday
        return ""

    def mod_dosya_sec(self):
        """Surukleme yerine dosya secme (yedek yol; ayni plana cikar).

        Suzgecte `.dds` de var: topluluk modlarinin cogu DDS tasir ve dosya
        secilemezse aracin o dosya icin hazirladigi "save it as a PNG" tavsiyesi
        de gorunmez (kullanici sebebini ogrenemeden takilir)."""
        import webview
        s = _PENCERE[0].create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=True,
            directory=self._mod_dialog_klasoru(),
            file_types=("Mods (*.zip;*.7z;*.rar;*.forge;*.png;*.dds)",
                        "All files (*.*)"))
        if not s:
            return {"ok": False, "mesaj": "cancelled"}
        s = list(s)
        return self._md_plani_kur(s if len(s) > 1 else s[0])

    def mod_klasor_sec(self):
        """Surukleme yerine klasor secme (yedek yol; ayni plana cikar)."""
        import webview
        s = _PENCERE[0].create_file_dialog(webview.FOLDER_DIALOG,
                                           directory=self._mod_dialog_klasoru())
        if not s:
            return {"ok": False, "mesaj": "cancelled"}
        return self._md_plani_kur(s[0])

    def mod_vazgec(self):
        """Ekrandaki plani birak; paketin acildigi gecici klasoru sil."""
        try:
            if self._md_plan:
                self._mp().temizle(self._md_plan)
        except Exception:                                       # noqa: BLE001
            pass
        self._md_plan = None
        if self._md_sahne and os.path.isdir(self._md_sahne):
            shutil.rmtree(self._md_sahne, ignore_errors=True)
        self._md_sahne = None
        return {"ok": True}

    # ------------------------------------------------ kurulum
    def _md_kur_isi(self, plan, cevaplar=None, ustune=False):
        """Kurulumun GOVDESI (is ipliginde calisir) - TEK YER.

        Hem INSTALL dugmesi hem kutuphaneden indirilen mod buradan gecer;
        ikinci bir kurulum yolu YOKTUR.

        DENETIM 2026-09-07 (ENGEL 7): paket ARTIK TEK IS. Hazir .forge yamasi
        da ayni mod_kayit islemine girer. Sebep: o islem HEPSI-YA-DA-HIC
        calisir; bir parca reddedilirse o ana kadar yazilanlar GERI ALINIR ve
        geri alma tutmazsa NE KURULDU / NE KURULMADI acikca yazilir. Onceki
        halinde kiyafet yazilip yama reddedilince kullaniciya yalniz "The patch
        was refused." deniyor, modun oteki yarisinin oyunda KALDIGI
        soylenmiyordu (olculdu). Geri almayi secmemizin sebebi: yama kurulumu
        dosya kopyasidir, geri alinmasi tam ve kesindir — dogru olani yapabilecekken
        "yarim kaldi" demek kullaniciyi bozuk bir oyunla birakmaktir.
        Gecici sahne klasoru HER YOLDA silinir (finally).

        MERGE (v0.15): `self._md_birlestir` kaldirilmissa plan mod_kayit.birlesik_plan
        ile KURULU yamayi kaynak alan tek forge_birlesik ogesine cevrilir ve AYNI
        MK.kur'a verilir; `ustune` gerekmez (icine alinan yama catisma degil,
        kaynaktir). Bayrak girer girmez sifirlanir: bir sonraki INSTALL temiz baslar."""
        birlestir = bool(self._md_birlestir)
        self._md_birlestir = False
        sahne = os.path.join(tempfile.gettempdir(),
                             "OutfitWorkshop_mod_%d" % os.getpid())
        if os.path.isdir(sahne):
            shutil.rmtree(sahne, ignore_errors=True)
        os.makedirs(sahne, exist_ok=True)
        self._md_sahne = sahne
        try:
            try:
                m2, _n, _forgeler, atlanan = self._md_m2plan(plan, cevaplar, sahne)
            except Exception as e:                              # noqa: BLE001
                print(traceback.format_exc())
                self._bildir("hata", {"t": "This mod could not be prepared ({0}). "
                                           "Nothing was written.",
                                      "a": [str(e)[:160]]})
                return False
            for a in atlanan:
                self._log("  not installed (%s): %s"
                          % (a["sebep"], os.path.basename(a["kaynak"] or "?")))
            if not m2["ogeler"]:
                self._bildir("hata", "Nothing in this mod could be installed.")
                return False
            MK = self._mk()
            if birlestir:
                bp = MK.birlesik_plan(m2)
                if not bp.get("ok"):
                    self._bildir("hata", bp.get("mesaj_kalip") or bp.get("mesaj")
                                 or {"t": "These patches could not be combined. Nothing was written."})
                    return False
                m2 = bp["plan"]
                self._log("- merging with the installed patch: %s"
                          % " + ".join(str(x) for x in (bp.get("kaynaklar") or [])))
            r = MK.kur(m2, progress=self._log, ustune=bool(ustune))
            if not r.get("ok"):
                self._bildir("hata", self._md_hata_metni(r))
                return False
            self._bildir("bitti", r.get("mesaj_kalip") or _duz_metin(r.get("mesaj"))
                         or {"t": "The mod is installed. Start the game to see it."})
            # Kurulum bitti: acilmis paket artik gereksiz -- yazicilar bayti
            # arsive KOYDU, geri alma kaydi defterdedir.
            self.mod_vazgec()
            self._bildir("mod_kuruldu", True)
            return True
        finally:
            # Basarili da olsa reddedilse de sahneleme klasoru DISKTE KALMAZ.
            # (mod_vazgec basarili yolda zaten sildi; burasi oteki butun yollar.)
            self._md_sahne_temizle()

    def _md_sahne_temizle(self):
        """Sahneleme klasorunu sil. Plan DURUR: kullanici uyariyi okuyup
        INSTALL'a yeniden basabilsin diye acilmis paket yerinde birakilir
        (onu `mod_vazgec` ya da yeni bir birakma temizler)."""
        if self._md_sahne and os.path.isdir(self._md_sahne):
            shutil.rmtree(self._md_sahne, ignore_errors=True)
        self._md_sahne = None

    def _md_hata_metni(self, r):
        """Kurulum reddedildiginde kullaniciya GERCEGI yazan TEK yer.

        mod_kayit'in kendi cumlesi "geri alindi mi" sorusunu yanitlar; buraya
        NE KURULU KALDI / NE KURULMADI satirlarini ekleriz. "The patch was
        refused." demek yetmiyordu: modun oteki yarisi oyunda kalmis olabilir.

        CEVIRI (2026-09-07): doner deger artik PARCA LISTESIDIR. Her parca ya
        duz Ingilizce dizedir ya da {"t","a"} kalibidir; arayuzdeki `msj()`
        listeyi parca parca cevirip bosluklarla birlestirir. Once burada
        " ".join yapiliyordu ve birlesik cumle hicbir sozlukte anahtar
        olamiyordu -- kaptanin ekranindaki kilit cumlesi bu yuzden Ingilizce
        kaliyordu (yazma kapisinin cumlesi TEK parcadir)."""
        parca = [r.get("mesaj_kalip") or _duz_metin(r.get("mesaj"))
                 or {"t": "This mod could not be installed."}]
        for s in r.get("sorunlu_ogeler") or []:
            m = s.get("mesaj_kalip") or _duz_metin(s.get("mesaj"))
            if m:
                parca.append(m)
        b = r.get("basarisiz_oge") or {}
        if b.get("ozet"):
            parca.append({"t": "Not installed: {0}", "a": [_duz_metin(b["ozet"])]})
        gs = r.get("geri_sarma") or {}
        if gs and not gs.get("temiz"):
            for a in gs.get("ayrinti") or []:
                # Kalip metni SART IFADESINE gomulmez: envanter yalniz
                # {"t": "..." biciminde bir literal gorurse toplar.
                ozet = _duz_metin(a.get("ozet")) or _duz_metin({"t": "one change"})
                parca.append({"t": "Put back: {0}", "a": [ozet]} if a.get("ok")
                             else {"t": "STILL IN THE GAME: {0}", "a": [ozet]})
        return [x for x in parca if x]

    def mod_kur(self, cevaplar=None, ustune=False):
        """Ekrandaki plani kur. Tek is; her oge kendi MEVCUT yazicisindan gecer."""
        plan = self._md_plan
        if not plan or not plan.get("ok"):
            return {"ok": False, "mesaj": "Drop a mod first."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        self._md_birlestir = False
        return self._is(lambda: self._md_kur_isi(plan, cevaplar, ustune))

    def mod_birlestir_kur(self, cevaplar=None):
        """"Merge with the installed patch": ekrandaki plani KURULU hazir yamayla
        BIRLESTIREREK kur. Ayri bir kurulum yolu DEGIL: bayrak `_md_kur_isi`ye gider,
        o da plani mod_kayit.birlesik_plan ile cevirip ayni MK.kur'a verir. `ustune`
        istenmez -- icine alinan yama catisma degil, kaynaktir (mod_kayit bunu bilir).
        Cakisan varlikta YENI yama kazanir (mod_birlestir: sonuncu kazanir)."""
        plan = self._md_plan
        if not plan or not plan.get("ok"):
            return {"ok": False, "mesaj": "Drop a mod first."}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        self._md_birlestir = True
        r = self._is(lambda: self._md_kur_isi(plan, cevaplar, False))
        if not r.get("ok"):
            self._md_birlestir = False       # is baslamadi: bayrak sizmasin
        return r

    # ------------------------------------------------ kurulu modlar
    def mod_kurulu(self):
        """Kurulu modlar listesi (defter) + kurulu hazir .forge yamasi.

        SALT OKUNUR. Defter bozuksa cokmez: mod_kayit bunu bir satir olarak
        bildirir ve arayuz onu gosterir."""
        satirlar = []
        try:
            for m in self._mk().liste():
                if m.get("durum") == "kaldirildi":
                    continue
                satirlar.append({
                    "id": m.get("id"), "ad": m.get("ad"), "yazar": m.get("yazar"),
                    "tarih": m.get("tarih"), "ozet": (m.get("ozet") or [])[:4],
                    "oge_sayisi": m.get("oge_sayisi"), "durum": m.get("durum"),
                    "silinebilir": m.get("durum") in ("kurulu", "yarim"),
                    "unutulabilir": m.get("durum") in ("ustune_yazildi", "yarim"),
                    # birlesik yama: icindeki yamalarin adlari (arayuz "A + B" yazar);
                    # icine ALINAN yama: hangi kaydin icinde yasadigi
                    "kaynaklar": list(m.get("kaynaklar") or []),
                    "birlesik_icinde": m.get("birlesik_icinde")})
        except Exception as e:                                  # noqa: BLE001
            print("mod defteri:", e)
            satirlar.append({"id": None, "ad": "The list of installed mods could "
                                               "not be read.",
                             "ozet": [str(e)[:160]], "durum": "bozuk",
                             "silinebilir": False, "unutulabilir": False})
        # ESKI SURUMLERIN yamasi: v0.13'ten once kurulan hazir .forge defterde
        # degildi (kendi yedegi ve kendi kaldirma yolu vardi). O kayitlar hala
        # gorunsun ki kullanici onlari kaldirabilsin. Defterdeki bir mod bugun
        # yamayi tutuyorsa bu satir EKLENMEZ: ayni yama iki kez listelenirdi.
        try:
            if OYUN and os.path.exists(self._patch_yolu()) \
                    and not self._defterdeki_forge_modu():
                with open(DURUM_DOSYA, encoding="utf-8") as f:
                    d = json.load(f)
                ad = d.get("harici_mod")
                if ad and not d.get("atamalar"):
                    satirlar.append({
                        "id": "forge:patch_02", "ad": ad, "yazar": "",
                        "tarih": "", "oge_sayisi": 1, "durum": "kurulu",
                        # `_duz_metin({"t": ...})` yazilmasinin sebebi: ozet
                        # satirlari duz metin listesidir (defterde de oyle
                        # saklanir), ama ceviri_envanter yalniz {"t": "..."
                        # seklini tarar. Boyle yazilinca cumle sozluge girer ve
                        # arayuzdeki msj() onu cevirir.
                        "ozet": [_duz_metin(
                            {"t": "Installs a ready-made game patch."})],
                        "silinebilir": True, "unutulabilir": False})
        except Exception:                                       # noqa: BLE001
            pass
        return {"ok": True, "modlar": satirlar,
                "bos_metin": "No mod is installed yet. Drop one above and it will "
                             "be listed here, with a Remove button next to it."}

    def _defterdeki_forge_modu(self):
        """Hazir yamayi BUGUN tutan defter kaydi (ya da None).

        Defterin kendi ozetinden okunur (`arsivler` alani), bicimi burada
        yeniden cozulmez."""
        try:
            ad = os.path.basename(self._patch_yolu())
            for m in self._mk().liste():
                if m.get("durum") == "kurulu" and ad in (m.get("arsivler") or []):
                    return m
        except Exception as e:                                  # noqa: BLE001
            print("defterdeki yama:", e)
        return None

    def mod_kaldir(self, mod_id):
        """Tek modu kaldir: yalniz O modun dokundugu girisler geri yazilir."""
        if not mod_id:
            return {"ok": False, "mesaj": "Which mod?"}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}
        if mod_id == "forge:patch_02":
            r = self.kaldir()               # mevcut patch_02 kaldirma yolu
            if r.get("ok"):
                r["mesaj"] = ("The ready-made patch was removed and the patch that "
                              "was there before it was put back.")
            return r

        def is_():
            r = self._mk().kaldir(mod_id, progress=self._log)
            # Kalip varsa (or. yazma kapisinin reddi) o gider; yoksa mod_kayit'in
            # duz cumlesine, o da yoksa buradaki kaliba duseriz.
            if r.get("ok"):
                self._bildir("bitti", r.get("mesaj_kalip") or r.get("mesaj")
                             or {"t": "The mod was removed."})
            else:
                self._bildir("hata", r.get("mesaj_kalip") or r.get("mesaj")
                             or {"t": "The mod could not be removed."})
            self._bildir("mod_kuruldu", True)
        return self._is(is_)

    def mod_unut(self, mod_id):
        """Defterden dus (arsive DOKUNMADAN) — ustune yazilmis / yarim kayitlar."""
        try:
            return self._mk().unut(mod_id)
        except Exception as e:                                  # noqa: BLE001
            return {"ok": False, "mesaj": str(e)[:200]}

    # ------------------------------------------------ kutuphane
    def mod_kutuphane(self, yenile=True):
        """Indirilebilir mod katalogu. Cevrimdisiysa COKMEZ: onbellege duser."""
        try:
            k = self._mkut().katalog(yenile=bool(yenile))
        except Exception as e:                                  # noqa: BLE001
            print("mod kutuphanesi:", e)
            return {"ok": False, "durum": "offline", "modlar": [],
                    "mesaj": "The mod library could not be opened (%s)."
                             % str(e)[:160]}
        return {"ok": bool(k.get("ok")), "durum": k.get("durum"),
                "cevrimdisi": bool(k.get("cevrimdisi")),
                "modlar": k.get("modlar") or [], "sayi": k.get("sayi") or 0,
                "mesaj": k.get("mesaj") or ""}

    def mod_kutuphane_kur(self, mod_id):
        """Katalogdaki modu indir (sha256 dogrulanir), PLANA cevir ve KUR.

        Indirme ve dogrulama mod_kutuphane'nin isi (guncelle.py'nin kanali);
        kurulum yine ayni plan yolundan gecer — ikinci bir kurulum yolu yok."""
        if not mod_id:
            return {"ok": False, "mesaj": "Which mod?"}
        if self._oyun_acik_mi():
            return {"ok": False, "mesaj": "Close the game first."}

        def is_():
            r = self._mkut().indir(mod_id, progress=self._log)
            if not r.get("ok"):
                self._bildir("hata", {"t": "The mod could not be downloaded: {0}",
                                      "a": [_duz_metin(r.get("mesaj"))
                                            or "unknown reason"]})
                return
            self._log("- reading what is inside the package ...")
            e = self._md_plani_kur(r.get("klasor"),
                                   kaynak_etiketi="library:%s" % mod_id)
            if not e.get("var"):
                # Kutuphane yolu da AYNI planin metnini gosterir: kalip varsa
                # onu gondeririz, yoksa duz metne duseriz (surukle-birak yolunda
                # oldugu gibi). Bu satir kalibi gecirmeyi UNUTUYORDU ve indirilen
                # bos paketin sebebi dort dilde Ingilizce cikiyordu.
                self._bildir("hata", e.get("mesaj_kalip") or e.get("mesaj")
                             or {"t": "Nothing in that mod could be installed."})
                return
            self._bildir("mod_plan", e)
            # Dugme "DOWNLOAD & INSTALL" der; sorulacak bir sey YOKSA sozunu
            # tutar ve ayni iste kurar. Sorulacak bir sey VARSA (kurulu bir
            # modun ustune yazacak, ya da bir dosyanin yeri belirsiz) DURUR:
            # kullanicinin gormedigi bir karari onun adina vermeyiz.
            if e.get("sorular") or (e.get("catisma") or {}).get("var"):
                self._bildir("bitti", {"t": "{0} is downloaded and checked. Read "
                                            "the line above, then press INSTALL.",
                                       "a": [e.get("ad") or "The mod"]})
                return
            self._md_kur_isi(self._md_plan)
        return self._is(is_)

    # ------------------------------------------------ surukle-birak olcumu
    def mod_birakildi(self, olay):
        """pywebview DOM 'drop' olayi (Python tarafinda calisir).

        WebView2 dosyalarin GERCEK yolunu ayri bir mesajda yollar; pywebview
        onu `pywebviewFullPath` olarak olaya ilistirir. Tarayici tarafinda bu
        yol YOKTUR, bu yuzden birakma koprusu Python'dadir."""
        self._md_birakma["olay"] += 1
        try:
            dosyalar = ((olay or {}).get("dataTransfer") or {}).get("files") or []
        except Exception:                                       # noqa: BLE001
            dosyalar = []
        yollar = [f.get("pywebviewFullPath") for f in dosyalar
                  if isinstance(f, dict) and f.get("pywebviewFullPath")]
        self._md_birakma["dosya"] += len(dosyalar)
        self._md_birakma["yol"] += len(yollar)
        if self._mesgul:
            # Is surerken plani degistirmek, kurulmakta olan modun altindan
            # zemini cekerdi.
            self._bildir("mod_birakma", {
                "ok": False, "mesaj": "Another job is still running. Wait for it "
                                      "to finish, then drop the mod again."})
            return
        if not yollar:
            # Olay geldi ama yol gelmedi: sessiz kalmak yerine SOYLE.
            if dosyalar:
                self._bildir("mod_birakma", {
                    "ok": False,
                    "mesaj": "Windows did not hand over the location of the "
                             "dropped file. Use the button below to pick it "
                             "instead."})
            return
        try:
            e = self._md_plani_kur(yollar if len(yollar) > 1 else yollar[0])
            self._bildir("mod_plan", e)
        except Exception as ex:                                 # noqa: BLE001
            print(traceback.format_exc())
            self._bildir("mod_birakma", {"ok": False,
                                         "mesaj": "That mod could not be read (%s)."
                                                  % str(ex)[:160]})

    def mod_birakma_durumu(self):
        """Surukle-birak koprusu GERCEKTEN kurulu mu? ("kod var" kanit degil)

        `dinleyici` pywebview'in kendi sayacidir: 0 ise WebView2'ye dosya
        birakildiginda hicbir sey olmaz ve yalniz dugme yolu calisir."""
        dinleyici = None
        try:
            from webview.dom.element import _dnd_state
            dinleyici = int(_dnd_state.get("num_listeners") or 0)
        except Exception:                                       # noqa: BLE001
            pass
        d = dict(self._md_birakma)
        d["dinleyici"] = dinleyici
        d["destek"] = bool(dinleyici)
        return d


def _ikon_muhurle(baslik):
    """Pencere + gorev cubugu ikonu: pythonw'un mirasi yerine bizim capa.

    pywebview'in icon parametresi Windows'ta islevsiz (GTK/QT'ye ozel);
    dogru yol Win32 WM_SETICON. AppUserModelID de ayrica sart: onsuz gorev
    cubugu pencereyi python.exe kimligiyle gruplayip Python logosunu basiyor.
    """
    import ctypes
    u32 = ctypes.windll.user32
    yol = os.path.join(BURA, "varlik", "workshop.ico")
    if not os.path.exists(yol):
        return
    for _ in range(40):                      # pencere olusana dek bekle (~10 sn)
        hwnd = u32.FindWindowW(None, baslik)
        if hwnd:
            break
        time.sleep(0.25)
    else:
        return
    LR_LOADFROMFILE, IMAGE_ICON, WM_SETICON = 0x10, 1, 0x80
    for boy, tip in ((16, 0), (32, 1)):      # ICON_SMALL=0, ICON_BIG=1
        h = u32.LoadImageW(None, yol, IMAGE_ICON, boy, boy, LR_LOADFROMFILE)
        if h:
            u32.SendMessageW(hwnd, WM_SETICON, tip, h)


def _webview2_hazir_mi():
    """WebView2 Runtime kurulu mu? (pywebview'in kendi olcutunun kopyasi)

    Neden gerekli: WebView2 YOKSA pywebview istisna firlatmaz — sessizce eski
    IE motoruna (MSHTML) duser ve modern arayuz BOZUK cizilir (2026-08-31
    olculdu: beyaz zemin, dagilmis duzen, kart yok). Boyle bir makinede
    kabugu hic denemeyip KLASIK arayuzu acmak dogru davranis.
    pywebview.platforms.winforms'u ICE AKTARMIYORUZ: o modul chromium yokken
    ice aktarilirken IE uyumluluk kayitlarini YAZIYOR (yan etki).
    Tespit edemezsek True doneriz; bos-pencere bekcisi yine de agi olusturur.
    """
    try:
        import winreg
    except Exception:
        return True
    gidler = ("{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",   # Runtime
              "{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}",   # Beta
              "{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}",   # Dev
              "{65C35B14-6C1D-4122-AC46-7148CC9D6497}")   # Canary
    koklar = ((winreg.HKEY_CURRENT_USER,
               r"SOFTWARE\Microsoft\EdgeUpdate\Clients\%s"),
              (winreg.HKEY_LOCAL_MACHINE,
               r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\%s"),
              (winreg.HKEY_LOCAL_MACHINE,
               r"SOFTWARE\Microsoft\EdgeUpdate\Clients\%s"))
    for gid in gidler:
        for kok, yol in koklar:
            try:
                with winreg.OpenKey(kok, yol % gid) as k:
                    surum = winreg.QueryValueEx(k, "pv")[0]
                if surum and str(surum) != "0.0.0.0":
                    return True
            except OSError:
                pass
    return False


def _tani_gunlugu():
    """pywebview'in KENDI gunlugunu dosyaya al.

    WebView2 baslatma hatasi pywebview'de `logger.error(...)` ile bildirilir ve
    ISTISNA FIRLATILMAZ. Penceresiz (.pyw) calismada stderr kayboldugu icin
    sahadan gelen "bos pencere" raporlarinda GERCEK sebep elimizde olmuyordu
    (2026-08-31, Discord). Artik bekci tetiklendiginde sebep bu dosyada olur.
    Gunluk INGILIZCE kalir: kullanici dogrudan paylasabilsin."""
    import logging
    kok = os.path.join(os.environ.get("LOCALAPPDATA", tempfile.gettempdir()),
                       "OutfitWorkshop", "logs")
    try:
        os.makedirs(kok, exist_ok=True)
        tutamac = logging.FileHandler(os.path.join(kok, "webview.log"),
                                      mode="w", encoding="utf-8")
        tutamac.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s: %(message)s"))
        gunluk = logging.getLogger("pywebview")
        gunluk.setLevel(logging.DEBUG)
        gunluk.addHandler(tutamac)
        return os.path.join(kok, "webview.log")
    except Exception:
        return None                      # gunluk suslemedir, akisi bozamaz


def _ekran_al(baslik, yol):
    """Pencerenin KENDI icerigini cek (PrintWindow) — ustune binen pencereler
    goruntuyu bozmaz (ImageGrab ekran bolgesini alir, SetForegroundWindow arka
    plandan calismayabilir; ilk turda olculdu: baska pencere goruntuye girdi).
    PW_RENDERFULLCONTENT=2, WebView2 gibi donanim hizlandirmali icerigi de alir.
    Basari -> True."""
    try:
        import ctypes
        from ctypes import wintypes
        from PIL import Image
        u, g = ctypes.windll.user32, ctypes.windll.gdi32
        hwnd = u.FindWindowW(None, baslik)
        if not hwnd:
            return False
        r = wintypes.RECT()
        u.GetClientRect(hwnd, ctypes.byref(r))
        w, hh = r.right - r.left, r.bottom - r.top
        if w <= 0 or hh <= 0:
            return False
        hdc = u.GetDC(hwnd)
        mdc = g.CreateCompatibleDC(hdc)
        bmp = g.CreateCompatibleBitmap(hdc, w, hh)
        g.SelectObject(mdc, bmp)
        ok = u.PrintWindow(hwnd, mdc, 3)         # 1 CLIENTONLY | 2 RENDERFULLCONTENT

        class BMI(ctypes.Structure):
            _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                        ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                        ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                        ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                        ("biClrImportant", wintypes.DWORD), ("rgb", wintypes.DWORD * 3)]
        bi = BMI()
        bi.biSize, bi.biWidth, bi.biHeight = 40, w, -hh      # ust-asagi
        bi.biPlanes, bi.biBitCount, bi.biCompression = 1, 32, 0
        buf = ctypes.create_string_buffer(w * hh * 4)
        g.GetDIBits(mdc, bmp, 0, hh, buf, ctypes.byref(bi), 0)
        g.DeleteObject(bmp); g.DeleteDC(mdc); u.ReleaseDC(hwnd, hdc)
        im = Image.frombuffer("RGBA", (w, hh), buf.raw, "raw", "BGRA", 0, 1).convert("RGB")
        os.makedirs(os.path.dirname(yol), exist_ok=True)
        im.save(yol)
        return bool(ok)
    except Exception as e:
        print("ekran goruntusu alinamadi:", e)
        return False


def _prob_kostur(p, api, baslik):
    """OW_PROBE=1 -> arayuz KENDINI denetler ve JSON rapor yazar.

    Neden var: 2026-09-02'de olu bir $("n-ses") satiri init'i yarida kesmisti,
    18 baglanti sessizce kurulmamisti; dosyada kod ARAMAK bunu yakalayamadi.
    Bu prob "dosyada var mi" degil "CALISIYOR mu" sorusunu olcer ve KULLANICI
    YOLUNU izler: sekmeleri NAV'a tiklayarak acar, dili MENUDEN secer.

    Olculenler: init zinciri sonuna ulasti mi - her sekmede gorunur her
    tiklanabilir oge bagli mi - 5 dilde hangi metinler cevrilmeden kaldi -
    sayfada biriken JS hatalari - (OW_EKRAN=<klasor> ise) her sekmenin ve
    dillerin ekran goruntusu.
    Cikti: OW_PROBE_CIKTI=<json yolu> (yoksa stdout'a ozet).
    """
    import json as _j
    cikti = os.environ.get("OW_PROBE_CIKTI")
    ekran = os.environ.get("OW_EKRAN")
    SEKMELER = ["dash", "chr", "out", "wpn", "mod", "hc", "ch", "ses", "ship",
                "exp"]
    rapor = {"init_tamam": False, "sayfa_canli": False, "hatalar": [],
             "sekmeler": {}, "diller": {}, "ekran": [], "prob_hata": []}

    def js(ifade):
        return p.evaluate_js(ifade)

    def jsj(ifade):
        r = js(ifade)
        return _j.loads(r) if isinstance(r, str) else r

    def sekme_ac(g):
        # kullanici yolu: nav'daki gercek baglantiya tikla (hc ust bardadir)
        return js("(function(){var a=document.querySelector("
                  "'.nav a[data-g=\"%s\"], .ust-arac [data-g=\"%s\"]');"
                  "if(!a) return 'yok'; a.click(); return 'ok';})()" % (g, g))

    def sekme_yerlesti(g, sure=6.0, dinlen=1.1):
        """GORUNUM gercekten `g` olana kadar bekle.

        Sabit `sleep` YETMIYOR: yuklu makinede olcum gecis ortasinda yapildi ve
        prob `wpn` isterken `chr`in dugmesini olcup "bagli degil" dedi (olculdu
        2026-09-08). Bekleme kosullu olunca yanlis alarm biter; sekme gercekten
        acilmiyorsa sure dolar ve olcum yine yapilir -- yani kapi korlesmez.
        """
        t = time.time()
        while time.time() - t < sure:
            try:
                if js("(function(){try{return GORUNUM;}catch(e){return null;}})()") == g:
                    # GORUNUM degisti != CIZIM BITTI. `dinlen`i KISALTMAYIN:
                    # ilk denememde 0,35 sn koydum, G7 duzeldi ama G5b dustu --
                    # Sounds sayaci henuz yeniden cevrilmemisti ("400 / 24290
                    # gosteriliyor" Ingilizce arayuzde). Kosullu bekleme eski
                    # sabit uykunun YERINE degil, ONUNE eklenir.
                    time.sleep(dinlen)
                    return True
            except Exception:                                   # noqa: BLE001
                pass
            time.sleep(0.15)
        return False

    try:
        t0 = time.time()                       # 1) init'i bekle (en cok 30 sn)
        while time.time() - t0 < 30:
            time.sleep(0.5)
            try:
                d = jsj("JSON.stringify({i:!!window.__INIT_TAMAM,"
                        "t:document.title})")
                if d and (d["i"] or "INIT ERROR" in d["t"]):
                    break
            except Exception:
                pass
        rapor["sayfa_canli"] = bool(api._sayfa_canli)
        d = jsj("JSON.stringify({i:!!window.__INIT_TAMAM,t:document.title})")
        rapor["init_tamam"] = bool(d and d["i"])
        rapor["baslik"] = d and d["t"]
        onceki_dil = js("(function(){try{return localStorage.getItem('ow_dil')"
                        "||'en'}catch(e){return 'en'}})()")

        for g in SEKMELER:                     # 2) sekmeler + baglantilar
            r = sekme_ac(g)
            sekme_yerlesti(g, dinlen=1.6)
            b = jsj("JSON.stringify(window.__probeBaglantilar())")
            b["nav_tik"] = r
            if g in ("out", "chr", "wpn"):        # 3D dugmesi: acik/bagli/cevrili mi
                b["e3d"] = jsj("JSON.stringify(window.__probe3D(true))")
            if g == "exp":                        # Explorer: liste GERCEKTEN doldu mu
                time.sleep(2.5)                   # indeks TEMBEL yuklenir + ilk arama
                b["ex"] = jsj("JSON.stringify(window.__probeExplorer())")
            if g == "mod":                        # MODS: ekran + birakma koprusu
                time.sleep(1.2)                   # kurulu modlar listesi gelsin
                b["md"] = jsj("JSON.stringify(window.__probeMod())")
                # "kod dosyada var" kanit degil: SENTETIK bir drop olayi atip
                # olayin Python'a ULASTIGINI olceriz. Isletim sisteminin verdigi
                # dosya yollari boyle uretilemez (o yuzden yol sayisi 0 kalir);
                # olculen sey KOPRUNUN CANLILIGIDIR.
                try:
                    js("(function(){var e=document.getElementById('md-birak');"
                       "if(!e) return 'yok';"
                       "var d=new DataTransfer();"
                       "e.dispatchEvent(new DragEvent('drop',{dataTransfer:d,"
                       "bubbles:true,cancelable:true})); return 'ok';})()")
                    time.sleep(1.0)
                except Exception as e:            # noqa: BLE001
                    rapor["prob_hata"].append("sentetik drop: %s" % str(e)[:200])
                b["md_birakma"] = api.mod_birakma_durumu()
                # kutuphane alt sekmesi: cevrimdisiyken COKMEDIGI olculur
                js("(function(){var b=document.getElementById('md-seg-kut');"
                   "if(b) b.click();})()")
                time.sleep(2.5)
                b["md_kut"] = jsj("JSON.stringify(window.__probeMod())")
                js("(function(){var b=document.getElementById('md-seg-kur');"
                   "if(b) b.click();})()")
                time.sleep(0.4)
            rapor["sekmeler"][g] = b
            if ekran and _ekran_al(baslik, os.path.join(ekran, "sekme_%s.png" % g)):
                rapor["ekran"].append("sekme_%s.png" % g)

        diller = jsj("JSON.stringify(Object.keys(window.DILLER||{}))") or ["en"]
        for dil in diller:                     # 3) diller: MENU yoluyla
            js("document.getElementById('dil-btn').click()")
            time.sleep(0.3)
            r = js("(function(){var b=document.querySelector("
                   "'#dil-menu button[data-dil=\"%s\"]');"
                   "if(!b) return 'yok'; b.click(); return 'ok';})()" % dil)
            time.sleep(0.9)
            per = {"tiklandi": r == "ok",
                   "etiket": js("(document.getElementById('dil-etiket')||{})"
                                ".textContent"),
                   "html_lang": js("document.documentElement.lang"),
                   "sekmeler": {}}
            for g in SEKMELER:
                sekme_ac(g)
                sekme_yerlesti(g)
                per["sekmeler"][g] = jsj("JSON.stringify(window.__probeCeviri())")
                if g == "ses":
                    # Sounds satirlari [data-notr] altinda: __probeCeviri onlara
                    # BAKMAZ. Sayac, ilk satirin kategori etiketi ve on dinleme
                    # dugmesinin basligi ACIKCA okunur (G5b bunlari Ingilizce
                    # kalintiya karsi sinar). Sayfa 0 gelene dek (en cok 4 sn) bekle.
                    SX_JS = ("JSON.stringify((function(){var s=document.getElementById('sx-sayac'),"
                             "k=document.querySelector('#sx-satirlar .sx-sat .kat'),"
                             "o=document.querySelector('#sx-satirlar .sx-oyn');"
                             "return {sayac:s?s.textContent:null,kat:k?k.textContent:null,"
                             "baslik:o?o.getAttribute('title'):null,"
                             "satir:document.querySelectorAll('#sx-satirlar .sx-sat').length};})())")
                    t1 = time.time()
                    sx = jsj(SX_JS)
                    while time.time() - t1 < 4 and not (sx and sx.get("satir")):
                        time.sleep(0.3)
                        sx = jsj(SX_JS)
                    per["sekmeler"][g]["sx"] = sx
                if g in ("out", "chr", "wpn"):
                    # 3D dugmesi bu dilde: metin + title sozlukteki karsiligi mi?
                    # (kaydir=True: dugme satiri goruse gelir, ekran goruntusunde
                    #  panelin altinda kalmaz -- Characters'ta oyleydi, olculdu)
                    per["sekmeler"][g]["e3d"] = jsj(
                        "JSON.stringify(window.__probe3D(true))")
                    time.sleep(0.4)
                if ekran and dil != "en" \
                        and g in ("dash", "ses", "ch", "ship", "out", "chr", "wpn") \
                        and _ekran_al(baslik, os.path.join(
                            ekran, "dil_%s_%s.png" % (dil, g))):
                    rapor["ekran"].append("dil_%s_%s.png" % (dil, g))
            rapor["diller"][dil] = per
        # kullanicinin dilini geri koy (localStorage kalicidir!)
        js("dilUygula(%r)" % (onceki_dil or "en"))
        time.sleep(0.5)

        # 4) WEAPON STATS paneli: dugmeye TIKLA, panel acilip doluyor mu OLC.
        #    (Panel salt-okuma acilir; bu adim arsive tek bayt yazmaz.)
        ST_JS = ("JSON.stringify((function(){"
                 "var o=document.getElementById('st-ort'),"
                 "s=document.getElementById('st-satirlar'),"
                 "y=document.getElementById('st-yok'),"
                 "n=document.getElementById('st-onay'),"
                 "b=document.getElementById('st-baslik-metin');"
                 "return {acik:!!(o&&o.classList.contains('acik')),"
                 "baslik:b?b.textContent:null,"
                 "satir:s?s.querySelectorAll('.st-satir').length:0,"
                 "secenek:s?s.querySelectorAll('select option').length:0,"
                 "yok:y?y.style.display:null,"
                 "onay:n?n.style.display:null,"
                 "secili:(typeof SECILI!=='undefined'?SECILI:null)};})())")
        sekme_ac("wpn")
        time.sleep(1.8)
        js("(function(){var b=document.getElementById('b-stats-wpn');"
           "if(b&&!b.disabled) b.click();})()")
        t1 = time.time()
        st = jsj(ST_JS)
        while time.time() - t1 < 10 and not (st and st.get("acik") and st.get("satir")):
            time.sleep(0.4)
            st = jsj(ST_JS)
        rapor["silah_stat"] = st
        js("(function(){if(typeof stKapat==='function') stKapat();})()")
        time.sleep(0.4)
        # ayni panel, istatistigi OLAN bir silahla (liste sayfali yuklendigi icin
        # kart tiklamasi yerine secim dogrudan kurulur; olculen sey PANELDIR)
        js("SECILI='Weapon_Sword_19'")
        js("(function(){if(typeof stAc==='function') stAc();})()")
        t1 = time.time()
        st2 = jsj(ST_JS)
        while time.time() - t1 < 12 and not (st2 and st2.get("satir")):
            time.sleep(0.4)
            st2 = jsj(ST_JS)
        rapor["silah_stat_dolu"] = st2
        # secim kutularinin gercekten dolu geldigini de yaz (ilk satirin etiketleri)
        rapor["silah_stat_ornek"] = jsj(
            "JSON.stringify((function(){var s=document.querySelector('#st-satirlar .st-satir select');"
            "if(!s) return null; var o=[];for(var i=0;i<s.options.length;i++)o.push(s.options[i].textContent);"
            "return {ad:(document.querySelector('#st-satirlar .st-satir b')||{}).textContent, secenekler:o};})())")
        js("(function(){if(typeof stKapat==='function') stKapat();})()")
        time.sleep(0.4)
        rapor["hatalar"] = jsj("JSON.stringify(window.__HATALAR||[])") or []
    except Exception as e:
        rapor["prob_hata"].append(str(e)[:400])
    # ozet (ASCII: konsol kod sayfasi ne olursa olsun okunsun)
    bagsiz = sum(len(s.get("bagsiz", [])) for s in rapor["sekmeler"].values())
    kalan = {d: sum(len(s["ingilizce_kalan"]) + len(s["latin_kalan"])
                    for s in v["sekmeler"].values())
             for d, v in rapor["diller"].items()}
    print("PROBE init_tamam=%s hatalar=%d bagsiz=%d dil_kalan=%s"
          % (rapor["init_tamam"], len(rapor["hatalar"]), bagsiz,
             _j.dumps(kalan)))
    if cikti:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(cikti)), exist_ok=True)
            with open(cikti, "w", encoding="utf-8") as f:
                _j.dump(rapor, f, ensure_ascii=False, indent=1)
            print("PROBE-JSON " + cikti)
        except Exception as e:
            print("PROBE-JSON-HATA " + str(e))
    else:
        print("PROBE " + _j.dumps(rapor)[:3000])
    time.sleep(0.8)                            # kopru cagrilari bitsin
    try:
        p.destroy()
    except Exception:
        pass


def _stdout_dosyaya():
    """pythonw altinda sys.stdout/err None'dir: her print() ve is-ipligi
    traceback'i kayboluyordu (sahadan gelen raporlarda GERCEK sebep yoktu).
    Son 4 oturum gunlugu %LOCALAPPDATA%/OutfitWorkshop/logs altinda tutulur."""
    if sys.stdout is not None and sys.stderr is not None:
        return None
    kok = os.path.join(os.environ.get("LOCALAPPDATA", tempfile.gettempdir()),
                       "OutfitWorkshop", "logs")
    try:
        os.makedirs(kok, exist_ok=True)
        eski = sorted(f for f in os.listdir(kok) if f.startswith("session-web-"))
        for f in eski[:-3]:
            try:
                os.remove(os.path.join(kok, f))
            except OSError:
                pass
        yol = os.path.join(kok, "session-web-%s.log" % time.strftime("%Y%m%d-%H%M%S"))
        f = open(yol, "w", encoding="utf-8", errors="replace", buffering=1)
        if sys.stdout is None:
            sys.stdout = f
        if sys.stderr is None:
            sys.stderr = f
        return yol
    except Exception:
        return None


def _birakma_baglantisi(p, api):
    """MODS sekmesinin birakma alanini pywebview'in DOM olay koprusune bagla.

    NEDEN PYTHON TARAFI: tarayicida birakilan bir dosyanin DISKTEKI YOLU yoktur
    (File.path yalniz Electron'da vardir). WebView2 yollari ayri bir mesajda
    yollar (`postMessageWithAdditionalObjects`) ve pywebview onlari olaya
    `pywebviewFullPath` olarak iliktirir — ama YALNIZ Python tarafinda kayitli
    bir 'drop' dinleyicisi varsa (pywebview kendi sayacina bakar). Bu yuzden
    dinleyici burada, sayfa yuklendikten sonra kurulur.

    Basarisiz olursa arayuz olmez: birakma alaninin altindaki iki dugme
    (dosya sec / klasor sec) AYNI plan yoluna cikar."""
    try:
        from webview.dom import DOMEventHandler
        alan = p.dom.get_element("#md-birak")
        if alan is None:
            print("drag-drop: #md-birak bulunamadi (arayuz surumu eski)")
            return
        alan.events.drop += DOMEventHandler(api.mod_birakildi, prevent_default=True,
                                            stop_propagation=True)
        # dragover'da preventDefault olmazsa WebView2 birakilan dosyaya GIDER
        # (sayfa kaybolur). Bunu JS tarafinda da yapiyoruz; burasi ikinci kemer.
        alan.events.dragover += DOMEventHandler(lambda e: None, prevent_default=True,
                                                stop_propagation=True)
        print("drag-drop: birakma alani baglandi (%s)"
              % api.mod_birakma_durumu().get("dinleyici"))
    except Exception as e:                                      # noqa: BLE001
        print("drag-drop baglanamadi (dugme yolu calismaya devam eder): %s" % e)


def main():
    import webview
    _stdout_dosyaya()
    _gunluk_yolu = _tani_gunlugu()
    if not _webview2_hazir_mi():
        raise RuntimeError(
            "Microsoft Edge WebView2 Runtime is not installed on this machine, "
            "so the modern interface cannot be displayed.")
    api = Api()
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "Zuynes.BlackFlagResynced.Workshop")
    except Exception:
        pass                                 # ikon suslemedir, akisi bozamaz
    # MUTLAK yol sart: pywebview goreli yolu GIRIS BETIGININ klasorune gore
    # cozuyor (pakette giris = src/OutfitWorkshop.pyw -> 404, sahada olculdu).
    # Mutlak yol verilince dahili sunucu HTML'in klasorunu kok yapar.
    os.chdir(BURA)
    baslik = "Workshop — AC IV Black Flag Resynced"
    # test kancasi: OW_HTML=<dosya> baska bir arayuz dosyasi yukler. Amaci,
    # probun HATALI surumde de kosturulup kapinin ayirt edici oldugunu
    # kanitlamak (hatali surumde gecen kapi deger tasimaz).
    _html = os.environ.get("OW_HTML") or os.path.join(BURA, "arayuz.html")
    if not os.path.isabs(_html):
        _html = os.path.join(BURA, _html)
    p = webview.create_window(
        baslik,
        url=_html,
        js_api=api, width=1380, height=860, min_size=(1180, 760),
        x=20, y=20, background_color="#0a0d13")
    _PENCERE[0] = p
    threading.Thread(target=_ikon_muhurle, args=(baslik,),
                     daemon=True).start()
    p.events.loaded += lambda: _birakma_baglantisi(p, api)

    # ---- BOS PENCERE BEKCISI (sahadan gelen kusur, 2026-08-31) -------------
    # WebView2 kurulumu basarisiz olursa pywebview ISTISNA FIRLATMAZ; pencere
    # bizim arka plan rengimizle BOS kalir ve onyukleyicinin klasige dusme
    # mekanizmasi hic tetiklenmez (kullanici sonsuza dek bos ekrana bakar).
    # Bekci iki bagimsiz canlilik sinyaline bakar:
    #   p.events.loaded   -> tarayici motoru DOM'u kurdu
    #   api._sayfa_canli  -> JS koprusu baslangic() cagirdi
    # Ikisi de gelmezse pencere kapatilir, main() hata firlatir, onyukleyici
    # KLASIK arayuzu acar. Yerel HTML icin 30 sn fazlasiyla comert.
    def _bekci():
        # sure: normalde 30 sn; testler ve destek icin OW_BEKCI_SN ile kisilir
        try:
            _sure = float(os.environ.get("OW_BEKCI_SN") or 30)
        except ValueError:
            _sure = 30
        for _ in range(max(2, int(_sure / 0.5))):
            time.sleep(0.5)
            if api._sayfa_canli or p.events.loaded.is_set():
                return                       # arayuz yasiyor, bekci cekilir
        print("web shell watchdog: interface never rendered, "
              "falling back to the classic interface")
        if _gunluk_yolu:
            print("the underlying WebView2 error was written to: %s"
                  % _gunluk_yolu)
        try:
            p.destroy()                      # webview.start() geri doner
        except Exception:
            pass
    threading.Thread(target=_bekci, daemon=True).start()
    # test kancasi: dili disaridan zorla (OW_DIL=tr/ru/es/zh)
    _dil = os.environ.get("OW_DIL")
    if _dil:
        def _dil_ac():
            import time as _t
            _t.sleep(7)
            try:
                p.evaluate_js("dilUygula(%r)" % _dil)
            except Exception as e:
                print("dil kancasi:", e)
        threading.Thread(target=_dil_ac, daemon=True).start()
    # test kancasi: OW_PROBE=1 -> arayuzun kendini denetlemesini istet.
    # SABIT ifade calisir (keyfi JS yok). Amaci: "kod dosyada var mi" degil,
    # "dugme gercekten bagli mi" sorusunu cevaplamak. 2026-09-02'de olu bir
    # $("n-ses") satiri init'i yarida kesmisti ve 18 baglanti sessizce
    # kurulmamisti; dosyada kod ARAMAK bunu yakalayamadi.
    if os.environ.get("OW_PROBE"):
        threading.Thread(target=_prob_kostur, args=(p, api, baslik),
                         daemon=True).start()
    hedef = os.environ.get("OW_GORUNUM")
    if hedef:
        # test kancasi: pencere yuklendikten sonra istenen gorunumu ac
        def _ac():
            import time as _t
            _t.sleep(6)
            try:
                p.evaluate_js("gorunumAc(%r)" % hedef)
            except Exception as e:
                print("gorunum kancasi:", e)
        threading.Thread(target=_ac, daemon=True).start()
    webview.start(debug=False, http_server=True)
    # start() geri dondu: ya kullanici kapatti (sayfa yasamisti) ya da bekci
    # bos pencereyi kapatti. Ikincisinde onyukleyiciye HATA bildir ki klasik
    # arayuz acilsin — sessizce cikmak kullaniciyi bos ekranla birakirdi.
    if not (api._sayfa_canli or p.events.loaded.is_set()):
        raise RuntimeError(
            "The web interface never rendered - WebView2 runtime is missing "
            "or failed to initialize on this machine."
            + (" Details: %s" % _gunluk_yolu if _gunluk_yolu else ""))


if __name__ == "__main__":
    main()
